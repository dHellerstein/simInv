//  Note that indexDb storage is used for "local" mode
//  localStorage is just used to cache displayable retsults (if it disappears or is not accessible, the results are regenerated)

///=========
// read a var from localStorage, specific to a userName
// if problem, returns null
// if no such var, returns defval (or returns null if defval not specified)

function simInv_readLocal(varname,defval) {
  let isnull ;
  if (simInvGlobals['cacheStuff']['cacheDisplayResults']===false) return isnull  ;

   let aname='simInv_'+userName+'@'+varname ;  // username is global

   let aval2=localStorage.getItem(aname);
   if (aval2===null) {      // no such variable stored
      if (arguments.length<2) return aval2
      return defval ;
   }
   let zz1=JSON.parse(aval2);
   return  zz1['saveData'];                    // got a localStorage version that is not out of date!

}


//===========
// write a variable to local storage (username specific)
// if fail, return false  ( simInvLocalStorage does not exist, or simInvLocalStorage['enabled'] not strue
// otherwise, return [datestamp,bytesSaved] -- bytes saved AFTER stringify (so an  oversized approximation)

function simInv_writeLocal(varname,aval) {
  let isnull ;

  if (simInvGlobals['cacheStuff']['cacheDisplayResults']===false) return false ;

   let aname='simInv_'+userName+'@'+varname ;  // username is global
   let nowTime=wsurvey.get_currentTime(0) ;
   let zz={'saveTime':nowTime,'saveLength':aval.length,'saveData':aval};        // aval CAN be an object  -- it will be stringified!
   let zz1=JSON.stringify(zz);
   let lenzz1=zz1.length;

   localStorage.setItem(aname,zz1);               // this varname  in localStraoge   (for this user)

   let anameZ='simInv_'+userName+'!lastUpdate' ;
   localStorage.setItem(anameZ,nowTime);         // lastUpdate timestamp for this user

   return [nowTime,lenzz1] ;
}

//===========
// remove  a variable from local storage (username specific)
// if fail, return false  ( simInvLocalStorage does not exist, or simInvLocalStorage['enabled'] not strue
// otherwise, return true
function simInv_removeLocal(varname) {
   if (simInvGlobals['cacheStuff']['cacheDisplayResults']===false) return false ;
   let aname='simInv_'+userName+'@'+varname ;
   localStorage.removeItem(aname);
   return true;
}


///================
// get local storage stats (asynchrous) and display/enable button
function simInv_localStorageStats(ifoo) {

  if (typeof(simInvLocalStorage)=='undefined') {
       alert('simInv_localStorageStats error:  simInvLocalStorage global not defined ');
       return false;
   }

  let elocalStorage=$('#iLocalStorage');
  let elocalStorageButton=$('#iLocalStorageButton');
  if (simInvLocalStorage['enabled']===false) {
      elocalStorage.show();
      elocalStorage.css({'opacity':0.3,'text-decoration':'line-through','color':'red'});
      let lMess;
      let qLocal= simInvLocalStorage['enabled'] ;
      if (!qLocal)   {
           lMess='Local storage is NOT enabled   by this simInv installation ';
      } else {
            lMess='Local storage is  enabled by this simInv installation  ' ;
      }
      elocalStorage.attr('title',lMess);
      elocalStorageButton.attr('title',lMess);
      elocalStorageButton.prop('disabled',true);

  } else {
      navigator.storage.estimate().then((estimate) => {
        let localStorage_usage=estimate.usage;  // save some globals
        let localStorage_quota=estimate.quota;

        simInvLocalStorage['usage']=estimate.usage;
        simInvLocalStorage['quota']=estimate.quota;

        let  usedPct=((estimate.usage / estimate.quota) * 100).toFixed(2);
        elocalStorage.show();
        elocalStorage.attr('title','Local storage enabled. '+usedPct+'% used');
        elocalStorageButton.attr('title','Local storage enabled. '+usedPct+'% used');
        elocalStorageButton.prop('disabled',false);
     });
   }
   return 1;
}


//=================
// update, or read, local storage "lastUpdate" time stamp   -- for a username
// if  noargs, or 0 or false -- get lastUpdate (false if not set) . Returns null if a problem
// if 1 arg, set to iset value. If iset=true, use current time
// returns false if other problem

function simInv_localLastUpdate(iset) {
   if (typeof(simInvLocalStorage)=='undefined') {
       alert('simInv_localLastUpdate error:  simInvLocalStorage global not defined ');
       return null;
   }
   if (simInvLocalStorage['enabled']===false) return null ;       // no local storage, return false (but no alerts)

   if (arguments.length<1 || iset==0) iset=false;
   if (iset===false  )  {                // read lastUpdate (from localStorage or simInvLocalStorage)
      let aname='simInv_'+userName+'!lastUpdate';  // no liveVersion, so read lastUpdate from localStorage
      let aval2=localStorage.getItem(aname);   // not in local version -- read from localStorage
      if (aval2===null)  aval2=false ;        // local storage not initialized for this user of siminv (leave localVersion as false
      simInvLocalStorage['lastUpdate']=aval2 ;  // update live version
      return aval2 ;                // could be false, could be js datestamp
   }

// ... set last update (using time right now)
   let useTime= (iset===true) ? wsurvey.get_currentTime(0) : iset ;
   let aname='simInv_'+userName+'!lastUpdate';  // read lastUpdate from localStorage
   localStorage.setItem(aname,useTime);               // update lastUpdate for this user
   simInvLocalStorage['lastUpdate']=useTime ;  // update live version

   return true ;
}

//============
// button in index.html calls this
function simInv_viewLocalInfo(athis) {
  let bmess='';
   bmess+='<input type="button" value="x" onclick="wsurvey.wsShow.hide(this,200)" data-wsshow="#mainDiv3"> ';
   bmess+='<b>Local storage:</b> for user=<tt>'+userName+'</tt>   ';

   let qLocal= simInvLocalStorage['enabled'] ;
   if (!qLocal) {           // should never happen
      alert('<em>local storage not used for simInv data (online mode)</em>');
      return false ;
   }


   if (simInvLocalStorage['onLineLocalStorage']===false) {
        bmess+='<em>local storage used for simInv data (standAlone mode)</em>'
   } else {                 // either
        bmess+='<em>local storage used for simInv data (onLine/localStorage mode)</em>'
   }
   let lupdate= simInv_localLastUpdate();
   let oof1=setEntryDate(lupdate);

    bmess+= ':: last update on <tt>'+oof1.sayDate+'</tt> <br>';
    bmess+='<p>You can <input type="button" value="Remove this user ('+userName+')"    onClick="simInv_viewLocalInfoRemoveAll(0)" > (and clear all her data)' ;

    let userList1=localStorage.getItem('simInv_!users');
    let userList=JSON.parse(userList1);

    bmess+=' <ul class="linearMenu16Pct">';
    bmess+='<li style="background-color:lime;font-weigh:600">You can switch users ...';
    let nOnLine=0;
    for (auser in userList['list']) {
       let adate=userList['list'][auser];
       let isdis='  ';
       if (auser==userName) isdis=' disabled  title="(current user)" ';
       if (adate!==false) {
          bmess+='<li><button onClick="simInv_switchUser(this)" '+isdis+'  data-online="0"  data-user="'+auser+'">'+auser+'</button>';
       } else {
          nOnLine++;
          bmess+='<li><button onClick="simInv_switchUser(this)" data-online="1" '+isdis+' data-user="'+auser+'">'+auser+' </button> <em>onLine</em>';
       }
    }
    bmess+='</ul>';


  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv1');    // this is where the table is shown
  wsurvey.wsShow.hide('#mainDiv2');    // this is where the table is shown
  wsurvey.wsShow.show('#mainDiv3','show');
  $('#mainDiv3').html(bmess);

}

//================
// switch users
function simInv_switchUser(athis) {
   let ethis=wsurvey.argJquery(athis);
   let auser =ethis.attr('data-user');
   let isOnline=ethis.attr('data-online');
   if (isOnline==1) {
      let qq=confirm('Would you like to switch this user ('+auser+') to local mode? \nThe simInv data you stored onLine  will not be deleted, but it will not be readily accessible. \nYou might want to archive it first! ');
      if (qq) {
        let a1=simInv_removeOnline(auser) ;
      }
    }
    doLogoff(1,'',auser)
}

function simInv_viewLocalInfo_sort(a,b) {
   let a1=a[0].toLowerCase();
   let b1=b[0].toLowerCase();
   if (a1>b1) return 1 ;
   if (b1>a1) return -1 ;
   return 0;
}


//======================
// showDebug this localStorage var
function simInv_viewLocalInfoVar(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-name');
   let vv= simInv_readLocal(aname);
   if (vv===null) {
      amess='Not yet saved to localStorage:  '+aname ;
      alert(amess);
   } else {
       showDebug(vv,'localStorage of '+aname );
   }

   return 1;

}
//==============
// remove an chose-online record for a username. Does not remove data -- just element from simInv!users
function simInv_removeOnline(aname) {
// remove from userlist
   let u1=localStorage.getItem('simInv_!users');
   if (u1===null) {        // should never happen
      alert('simInv_viewLocalInfoRemoveAll: no userList (simInv_!users not in localStorage)');
      return false;
   }
   let u2=JSON.parse(u1);
   let userList=u2['list'];
   let nusers=u2['nusers'];
   if (!userList.hasOwnProperty(aname)) {
      alert('simInv local users does NOT have userName of: '+aname);
      return 0;
   }
   delete userList[aname];
    nusers=parseInt(nusers)-1;
   let z1={'nusers':nusers,'list':userList};
   let z2=JSON.stringify(z1);
   localStorage.setItem('simInv_!users',z2);     // remove user for userlist (in simInv_viewLocalInfoRemoveAll)
   return 1 ;
}

//==========
// clear all simInv_username... localStorage variables
function simInv_viewLocalInfoRemoveAll(iforce) {
  if (iforce==0) {
     let bmess='';
     bmess+='<div style="border:1px solid green;border-radius:3px;margin:3px 3em;padding:10px">';
     bmess+=' Clearing localStorage will remove ALL of your ('+userName+') simInv data! ';
     bmess+='</div>';
     bmess+='<ul class="boxList2">';
     bmess+='<li>Do you want to <input type="button" value="Archive the data" onClick="doExport_menu(3)">';
     bmess+='<li><button onClick="hideStatusMessage(100)"><b>No</b></button> ';
     bmess+='<li><button onClick="simInv_viewLocalInfoRemoveAll(1)"><b>Yes</b>, delete '+userName+' simInv data</button>';
     bmess+='</ul>';
     displayStatusMessage(bmess);
     showStatusMessage(1);
     toggleStatusDiv(0,0);
     return 1;
   }

// make list of vars to delete
   let anameCheck='simInv_'+userName+'@';
   let ilen=anameCheck.length;
   let dodels=[];
   for (let i = 0; i < localStorage.length; i++) {  // the various varnames saved for userName
      let anameSaved=localStorage.key(i) ;
      if (typeof(anameSaved)!='string') continue;
      let aname0=anameSaved.substr(0,ilen);
      if (aname0!==anameCheck)     continue ;
      dodels.push(anameSaved);
    }
   anameCheck='simInv_'+userName+'!';      // for now, just !lastUpdate
   ilen=anameCheck.length;
   for (let i = 0; i < localStorage.length; i++) {
      let anameSaved=localStorage.key(i) ;
      if (typeof(anameSaved)!='string') continue;
      let aname0=anameSaved.substr(0,ilen);
      if (aname0!==anameCheck)     continue ;
      dodels.push(anameSaved);
      localStorage.removeItem(anameSaved);
    }

    for (let ij=0;ij<dodels.length;ij++) {  // and remvoethem
       let aname=dodels[ij] ;
       localStorage.removeItem(aname);
    }

// remove from userlist
   let u1=localStorage.getItem('simInv_!users');
   if (u1===null) {        // should never happen
      alert('simInv_viewLocalInfoRemoveAll: no userList (simInv_!users not in localStorage)');
      return false;
   }
   let u2=JSON.parse(u1);
   let userList=u2['list'];
   let nusers=u2['nusers'];
   delete userList[userName];
     nusers=parseInt(nusers)-1;
   let z1={'nusers':nusers,'list':userList};
   let z2=JSON.stringify(z1);
   localStorage.setItem('simInv_!users',z2);     // remove user for userlist (in simInv_viewLocalInfoRemoveAll)

// check for # of simInv users. If not, remove simInv_!useLocal
   let userList2=localStorage.getItem('simInv_!users');

   displayResponseFromServer('User: '+userName+' has been removed. You can <button onClick="doLogoff(1)">logOff </button>  ',0,1);
}

//=================
// get list of all local variable of a user
// ivals=0, array of full variable names
// 1 :object whose properties are the "Short" names, with their values.  value=simInv_readLocal(short name)
function simInv_getAllLocalVars(ivals) {

// make list of vars to delete
   let anameCheck='simInv_'+userName+'@';
   let ilen=anameCheck.length;
   let dovars=[];
   for (let i = 0; i < localStorage.length; i++) {  // the various varnames saved for userName
      let anameSaved=localStorage.key(i) ;
      if (typeof(anameSaved)!='string') continue;
      let aname0=anameSaved.substr(0,ilen);
      if (aname0!==anameCheck)     continue ;
      dovars.push(anameSaved);
    }
   if (ivals==0) return dovars ;  // full local storage names

   let davals={};
   for (let ij=0; ij<dovars.length;ij++) {
       let avar=dovars[ij];
       let avarShort=avar.substr(ilen);
       davals[avarShort]=simInv_readLocal(avarShort);
   }
   return davals;     // object with accessible name, and   simInv_readLocal(avarShort)

}

// =============
// generic
//===============
//https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
// check if local storage is available
function simInv_storageAvailable(type) {
  let storage;
  try {
    storage = window[type];
    const x = "__storage_test__";
    storage.setItem(x, x);
    storage.removeItem(x);
    return true;
  } catch (e) {
    return (
      e instanceof DOMException &&
      // everything except Firefox
      (e.code === 22 ||
        // Firefox
        e.code === 1014 ||
        // test name field too, because code might not be present
        // everything except Firefox
        e.name === "QuotaExceededError" ||
        // Firefox
        e.name === "NS_ERROR_DOM_QUOTA_REACHED") &&
      // acknowledge QuotaExceededError only if there's something already stored
      storage &&
      storage.length !== 0
    );
  }
}


//=====
// return bytes used in local storage
// https://stackoverflow.com/posts/15720835/revisions
function  simInv_localBytesUsed(ifoo) {
var _lsTotal = 0,
    _xLen, _x;
for (_x in localStorage) {
    if (!localStorage.hasOwnProperty(_x)) {
        continue;
    }
    _xLen = ((localStorage[_x].length + _x.length) * 2);
    _lsTotal += _xLen;
};
return _lsTotal;
}
