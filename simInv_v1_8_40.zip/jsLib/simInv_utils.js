// utils for simInv


//========
// scroll to a div
function scrollToDiv(athis) {

   let ethis=wsurvey.argJquery(athis) ;
   let divid=ethis.attr('data-where');        // scroll to this div
   let isShow=ethis.attr('data-show');         // or hide it (if =1)
   if (typeof(isShow)=='undefined')  isShow=0;  // if not spcifiedd, assume not visible
   let aparent=ethis.attr('data-parent');    // if psecified, use this as parent. If not, use parent().

   let ediv=$('#'+divid);
   if  (isShow==1)     {  // visible, so hide
     ediv.hide();
     ethis.attr('data-show',0);
     return 1;
   }
   if (typeof(aparent)!=='undefined')  {
      pdiv=$('#'+aparent);
   } else {
      pdiv=ediv.parent();
   }

   ediv.show();
   let atop=parseInt(ediv.position().top);
   pdiv.animate({scrollTop: atop}, 700);

    ethis.attr('data-show',1);

   return 1;
}

// probably not useful enouh
// https://developer.mozilla.org/en-US/docs/Web/HTTP/Browser_detection_using_the_user_agent
 function operatingSytem() {
       let OSName = "Unknown OS";
       if (navigator.appVersion.indexOf("Win") != -1) OSName = "Windows";
       if (navigator.appVersion.indexOf("Mac") != -1) OSName = "MacOS";
       if (navigator.appVersion.indexOf("X11") != -1) OSName = "UNIX";
       if (navigator.appVersion.indexOf("Linux") != -1) OSName = "Linux";
   return   OSName ;
 }

 //====================
// return index of "closest entry" (in alist) to aDate -- the entry that is just less than this date.
//   Or -1 if adate is before earliest entry
//  Thus: 0 if aDate  aDate>=alist[0] and < alist[1]
// (after alist has been sorted)
// alist will be sorted and made numeric, as will aDate
//  If aDate before earlist entry alist, return -1 ;
// if non numeric dates, alert an error and return false
 

function find_closestDate(alist0,aDate0) {

   if (!jQuery.isNumeric(aDate0)) {
      alert('Error in  find_closestDate: date is not numeric ('+aDate0+')');
      return false;
   }
   let aDate=parseFloat(aDate0);

   let  alist=[];
   for (let ii=0;ii<alist0.length;ii++) {
      let k1=alist0[ii];
      if (!jQuery.isNumeric(k1)) {
        alert('Error in  find_closestDate: list['+ii+'] is not numeric ('+k1+')');
        return false;
      }
      alist[ii]=parseFloat(k1);
   }
   alist.sort(find_closestDate_sort);  // make sure its ascending sort

   if (aDate<alist[0]) return -1  ;

    for (ifoo=alist.length-1;ifoo>=0;ifoo--) {     // go backwards
        let t1=alist[ifoo];
        if (aDate>=t1)   return ifoo;
    }             // ifoo=0 will always work (given aDate<alist[0]) test above

    alert('Error in  find_closestDate: could not match ');     // should never happen
    return false;
}


function find_closestDate_sort(a1,b1) {     // assumes values are alreday numeric
   return a1 - b1;
}



//===============
// display a statusmessage
// amess===false: close displayStatuMessage
// iappend: if 1, append to current status message IF VISIBLE.  2: append always

function displayStatusMessage(amess,iappend,ifade) {
  if (amess===false) {                           // 3 dec 2023 .. or use   hideStatusMessage()
    if (arguments.length<3) ifade=100;
    ifade=parseInt(ifade);
     wsurvey.wsShow.hide('#statusDiv',ifade);
     return 1;
  }
  if (arguments.length<2) iappend=0;
  let emess=$('#statusMessage_message');
  if (iappend==0)   {
    emess.html(amess);
  } else {
    if (iappend==2) {
       emess.append(amess);
   } else {
      if (emess.is(':visible')) {
       emess.append(amess);
      }
   }

  }
  wsurvey.wsShow.show('#statusDiv','show');
}

//=======
// shortcut: close status message
function hideStatusMessage(ifade) {
   if (arguments.length<1) ifade=10;
     ifade=parseInt(ifade);
     wsurvey.wsShow.hide('#statusDiv',ifade);
     return 1;
}

//=======
// shortcut: show status message
// if ii==false, return true/false on whether statusDiv container is visible. Otherwise, ii is ignored
function showStatusMessage(ii) {
  if (ii===false) {
      let q1=$('#statusDiv').is(':visible');
      return q1;
  }
    wsurvey.wsShow.show('#statusDiv',2);
     return 1;
}

//==========
// toggle size of sattusDiv
// if one arg -- data-isbig has current size -- toggle it
// If 2 args, athis is ignored
// istatus:1 -- shrink
//         0  -- expand 

function toggleStatusMessage(athis,istatus) {   // a synonym
  if (arguments.length<2) {
   toggleStatusDiv(athis,0);
  } else {
   toggleStatusDiv(athis,istatus);
  }
   return 1;
}

// ---
// istatus is current status --- toggle away from this
// if two args, first is ignored. And 2nd can be:
//     0: normal, 1:small, 2:lower, 3: big , 4: lower small, 5 upper smallish,6= middle biggish

function toggleStatusDiv(athis,istatus) {
  let ediv=$('#statusDiv');
  let ethis;
  if (arguments.length<2)  {
     ethis=wsurvey.argJquery(athis);
     let s1=ethis.attr('data-isbig');    // the current status
     istatus=0;  // change to this
     if (s1==0) istatus=1;
     if (s1==1) istatus=2;
     if (s1==2) istatus=3;
  }  else {
     ethis=ediv.find('[name="toggleSizeButton"]');
     let s1=istatus ;
     istatus=0 ;    // the default is normal
     if (s1==1) istatus=1;
     if (s1==2) istatus=2;
     if (s1==3) istatus=3;
     if (s1==4) istatus=4;
     if (s1==5) istatus=5;
     if (s1==6) istatus=6;
  }

    ediv.removeClass('cStatusDivSmall cStatusDivLower cStatusDivBig cStatusDivSmallLower cStatusDivNearTop');

   if (istatus==1) {                 // small
      ediv.addClass('cStatusDivSmall');
   } else if (istatus==2) {               //     lower
      ediv.addClass('cStatusDivLower');
   } else if (istatus==3) {           // big
      ediv.addClass('cStatusDivBig');
   } else if (istatus==4) {           // , lower small
      ediv.addClass('cStatusDivSmallLower');
   } else if (istatus==5) {           // ,
      ediv.addClass('cStatusDivNearTop');
   } else if (istatus==6) {           // ,
      ediv.addClass('cStatusDivBig2');

   }  // else, normal
  ethis.attr('data-isbig',istatus);   // set the current status
  return 1;
}

//===============
// toggleStatus -- with "selec which size"
function toggleStatusDiv2(athis,istatus) {
  let ebb=$('#statusDivOpts');

  if (arguments.length<2 || istatus===false) {
     ethis=wsurvey.argJquery(athis);
     let lastClick=ethis.attr('data-click');
     let nowTime=wsurvey.get_currentTime(0)
     ethis.attr('data-click',nowTime);
     let dd=nowTime-lastClick;
     if (dd<1000) {  // double click -- toggle
           toggleStatusDiv(athis) ;
           ebb.hide();
     }   else {
       ebb.show();
     }
    return 1;
  }
// else, show options bar
  toggleStatusDiv(athis,istatus) ; // 2 args -- do nothing here


}

// handler for  toggleStatusDiv2 actions
function toggleStatusDiv2a(ido) {
  let ebb=$('#statusDivOpts');
  if (ido==-1) {
     ebb.hide();
     return 0;  // just hide
  }

  toggleStatusDiv2(0,ido);
}


//=================
// resize status. single click to enlarge, double to shrink
// isize: 0- regular full size. nn : add nn%, -nn: subtract nn%
//  if isize not specified, add 10 to nn in data-size (minimum of 50px or window size
//    14 july 2023 ... not working right, don't use
function resizeStatusDiv(athis) {
     let ediv=$('#statusDiv');
     ediv.removeClass('cStatusDivSmall');

     let ethis=wsurvey.argJquery(athis);
     let isize=parseInt(ethis.attr('data-size'));
     let lastClick=ethis.attr('data-click');
     let origHeight=parseInt(ethis.attr('data-origheight'));
     let origWidth=parseInt(ethis.attr('data-origwidth'));
     let nowTime=wsurvey.get_currentTime(0)
     ethis.attr('data-click',nowTime);

     let nowWidth=ediv.width();
     let nowHeight=ediv.height();

     if (origHeight==0) {
        ethis.attr('data-origheight',nowHeight); // set to initial value
        origHeight=nowHeight;
     }
     if (origWidth==0) {
        ethis.attr('data-orighwidth',nowWidth);
        origWidth=nowWidth;
     }

     let dd=nowTime-lastClick;

     if (dd<1000) {
          isize=isize-20;  // have to subtracdt the add from the first click
       } else {
          isize=isize+10 ;
     }
     ethis.attr('data-size',isize);
     let asize=(100+isize)/100;
     let newHeight=parseInt(origHeight*asize);
     let newWidth=parseInt(origWidth*asize);

    ediv.width(newWidth+'px');
    ediv.height(newHeight+'px');
    ediv.css({'height':newHeight+'px','width':newWidth+'px'});


}


//=============
// replace all " , ' characters  with ' '
// nospaces: 1=remove all internal spaces (and breaks), 2=multiple spaces replace with 1 space, otherwise no space messing with
function fixString(astring,nospaces) {
   let bstring=jQuery.trim(astring);
   bstring=bstring.replace(/"|'|,/g," ");
   if (nospaces==1) bstring= bstring.replace(/\s+/g,"");
   if (nospaces==2) bstring= bstring.replace(/\s+/g," ");

   return jQuery.trim(bstring);
}

// remove | ! $ ~ #, " , ', : make lower case
function fixStringRemoves(astring) {
   let bstring= astring.replace(/\s+/g,"");  // get rid of spaces
   bstring=bstring.replace(/"|'|`|#|\\|\/|\%|!|\+|\&|~|\*|\$|\||\<|\>/g,'');   // unallowed characters
   return bstring.toLowerCase();
}



//==============
// validate a date, and find some more info
// returns false (if bad date), or object with fields : year month day month3 dayOfWee value sayDate and sayDateMore
// 3 argument mode: year month day (year: 4 digits, month : 1-12, day 1-31)
//  one argument mode: a js datestamp. or true: use current date
// 2 argument: same as 1, but domonth should be seperator used to create sayDate and sayDateMore
// returns:
//        year:  number: 2023
//        month:  number: 12
//        day:  number: 3
//        dayOfWeek:  string(3): "Sun"
//        value:  number: 1701579600000
//        month3:  string(3): "Dec"
//        sayDate:  string(10): "2023-Dec-3"
//        sayDateMore:  string(14): "Sun 2023-Dec-3"
//        dayCount:  number: 19694
//        orig:  string(0): ""
// if an error in the arguments, returns false
//  if an impossible date, returns false 
// if quiet=0 (the default), an error causes an alert to be displayed.



function setEntryDate(doyear,domonth,doday,quiet) {
 let foo='';
  let dasep='-';
  let td1;
  let origarg='';
  if (arguments.length<4) quiet=0;

  let isDayCount=0,firstTry=0,useGmt=0,origDayCount=0;        // set if  doyear is a daycount (i.e.' 16436  for 2014 jan 1

  let nmillis=(60*60*24*1000);       // 86,400,000  millisecs per day
  if (arguments.length==1 && doyear!==true )    origarg=doyear+' . .  ';
  if (arguments.length==2)  origarg=doyear+', '+domonth + ' .   ';
  if (arguments.length==3)    origarg=doyear+', '+domonth + ', '+doday ;

  if (arguments.length<3)   {  // a datestamp
    if (arguments.length>1) dasep=jQuery.trim(domonth);
    let dd;
    if (doyear===true) {
       td1=-1;
        dd=new Date();
    } else {
      if (parseInt(doyear)<nmillis)   {
        origDayCount=parseInt(doyear);
        td1=origDayCount*nmillis   ;   ; // do year is "day count" -- in local time
        let dog=new Date();
        let agmt=dog.getTimezoneOffset();      // number of minutes to utc
        useGmt= agmt*60*1000 ;
        td1+=useGmt;
        isDayCount=1;                 // dayCount input
        firstTry=td1 ;                 // adjust this if bad match (see below)
        dd=new Date(td1);
      } else {
        td1=doyear;
        dd=new Date(parseInt(doyear));
      }
    }
    domonth=dd.getMonth()+1;
    doyear=dd.getFullYear();
    doday=dd.getDate();
    foo=dd.valueOf();
  }

// use all date fields... get their values
   doday=jQuery.trim(doday);
   if (doday==='') doday=1;
   if (!jQuery.isNumeric(doday) || doday<1) {
       if (quiet==1) return false ;
       alert('Invalid day: '+doday+' (using '+origarg+')')  ;
        if (simInvGlobals['debugMode']==1)   a=errorHack-12;  // force an error
       return false ;
    }
    doday=parseInt(doday);

   domonth=jQuery.trim(domonth);
   if (domonth==='') domonth=1;
   if (!jQuery.isNumeric(domonth)) {   // check for month name
      let xdate=new Date('1 '+domonth+' 1999');
      let newmonth=xdate.getMonth();
      if (!jQuery.isNumeric(newmonth)) {
         if (quiet==1) return false ;
         alert('Invalid month: '+domonth+' (using '+origarg+')')  ;
         if (simInvGlobals['debugMode']==1)   a=errorHack-12;  // force an error
         return false;
       }
      domonth=newmonth+1;       // convert jan=0 to jan=1
   }
   domonth=parseInt(domonth);
// https://stackoverflow.com/questions/13178069/getting-the-month-number-from-a-given-month-name


   doyear=jQuery.trim(doyear) ;
   if (doyear==='') doyear=2023;
   if (!jQuery.isNumeric(doyear) ) {
       if (quiet==1) return false ;
       alert('Invalid  year: '+doyear+' (using '+origarg+')')
       if (simInvGlobals['debugMode']==1)   a=errorHack-12;  // force an error
       return false;
    }
   doyear=parseInt(doyear);

   if (doyear<simInvGlobals['theMinYear'] || doyear > simInvGlobals['theMaxYear']) {        // global variables (simInv_params.js)
       let q=confirm('Are you sure the year ('+doyear+') is correct? ');
      if (!q) return false ;
  }

  let d1=wsurvey.validateDate(doyear,domonth,doday); // month from 1 to 12

  let d1Year=wsurvey.validateDate(doyear,1,1); // month from 1 to 12
  let d1Diff=d1.value-d1Year.value ;
  let dayOfYear=1+(d1Diff/(1000 * 60 * 60 * 24));

   if (d1===false)  {
        if (quiet==1) return false ;
         alert('Improper date (please re-enter): Y:' +doyear +'/ M: '+domonth+'/ D:'+doday );
         return false;
  }


  let dsay3=d1['year']+dasep+d1['month3']+dasep+d1['day'] ;
  d1['sayDate']=dsay3;
  let dsay4=d1['dayOfWeek']+' '+dsay3 ;
  d1['dayOfYear']=dayOfYear;
  d1['sayDateMore']=dsay4;
  d1['dayCount']=parseInt(d1['value']/nmillis) ;
  d1['orig']=origarg ;

// isDayCount=0,firstTry=0,useGmt=0,origDayCount=0;
  if (isDayCount==1)  {    // daycount input -- make sure the returned daycount matches (utc issues can make this not ture
    for (let mfoo=0;mfoo<24;mfoo++)  {    // shouldn't need this many!
      let d2;
      if (d1['dayCount']<origDayCount) {  // add some time and try again
        let td2=firstTry+useGmt;
          d2=setEntryDate(td2);           // since full time string, will not get into recursioh hell
      } else if (d1['dayCount']>origDayCount) {
          let td2=firstTry+useGmt;
            d2=setEntryDate(td2);
      } else {
          break ; // equal!
      }
      if (d2['dayCount']==origDayCount)  {
           d1=d2;
           break;
      }       // success
    }   // mfoo
  }       // isdaycount check

  return d1 ;  // value month3  day year

}


//=============
// display div in new window
function displayInWindow(athis) {
  let ethis=wsurvey.argJquery(athis);
  let aid=ethis.attr('data-id');
  let eid=$('#'+aid);
  let arf=eid.html();
  let hmess='<html><head><title>simInv: help and tips </title> ';
   hmess+='<script type="text/javascript" src="lib/jquery-3.6.0.min.js"></script>';
   hmess+='<link rel="stylesheet" type="text/css" href="cssLib/simInv.css" />  ';
   hmess+='<script type="text/javascript" src="lib/wsurvey.utils1.js">  </script>';

   hmess+='<script type="text/javascript" src="simInv_utils.js">  </script>';
   hmess+='</head><body>';
   hmess+=arf;
   hmess+='</body></html>';

  wsurvey.displayInNewWindow(0,{'content':hmess});
}

//===========
// convert a nearby input field with a xxxK number -- to xxx*1000
function convertKto1000(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-namefind');
   let espan=ethis.closest('span');
   if (espan.length!=1) return false 
   let einput=espan.find('[name="'+aname+'"]');
   if (einput.length!=1) return false
   let aval=parseFloat(einput.val());
   let aval2=aval*1000;
   let aval3=wsurvey.addComma(parseInt(aval2));
   einput.val(aval3);
}


// ==========
// fatal or other kind of message. Could be "please relogon" message
// in any case :this is the only thing that will be visible (other than help button)
// if includeLogon=1, add a "relogon" button to start omessage


function simInv_errorMessage(bmess,includeLogon,againMessage) {
   if (arguments.length<2) includeLogon=0;
   if (arguments.length<3) againMessage='Please logon again';
   if (bmess==false) {
              $('#failMessage').html(bmess).hide();
              return 1;
   }
    if (includeLogon==1) bmess+='<br><button class="cdoButton"  onClick="doLogoff(1)">'+againMessage+'</button>';

      $('#failMessage').html(bmess).show();
      $('#logonDiv').hide();
      $('#headerLine').hide();
  return 1;
}

//==============
// sort a list using each rows 'date' property
function simInvData_sortDate(a,b) {
   let a1=parseFloat(a['date']);
   let b1=parseFloat(b['date']);
   let dd=a1-b1;
   return dd;
}


//=========
// (this is NOT called when local storage is used)
// selectively JSON.parse (unstringify) simInv data  received from   server
// AND ... decrypt if akey!=''.
// note that akey=false, or '', means "do not try to decrypt"
// anything else ... decryption is attempted

function simInvData_unstringify(aobject,akey) {
   let aobject1={};
   let simInvUpdateTimes={} ;

   let doList={'cpiuSeries':{},'settings':{},'viewDates':{},
      'assets':[],'assetHistory':{},
      'portfolios':[],'portfolioInit':{},'portfolioModifications':{},'scenario':{},
    } ;   // default values if nothing speciifed

   let encList= {'assets':1,'assetHistory':1,'portfolios':1,'portfolioInit':1,'portfolioModifications':1,'scenario':1};

   for (let ado in aobject){
      if (!doList.hasOwnProperty(ado)) { // not subject to processing... so leave as is
          aobject1[ado]=aobject[ado];
          continue;
      }
      if (aobject[ado]===false) {     // uninitialized
          aobject1[ado]=false ;   // signal its empty
          simInvUpdateTimes[ado]=false;
          continue;
      }

      let arf=null ;
      if (akey!=false  && jQuery.trim(akey)!=='' && encList.hasOwnProperty(ado)) {                             // encrypted ... so decrypt (if on enclist)
         arf =simInvDecrypt(aobject[ado]['dinfo'],akey,'decrypting '+ado) ;  // decrypt (and unstringify)
         if (arf ===null) return null;   // should never get here (simInDecrypt will throw a fatal error
      } else {
         arf=JSON.parse(aobject[ado]['dinfo']);   // unstringify!
      }
      aobject1[ado]= arf ;
      simInvUpdateTimes[ado]=aobject[ado]['time'];
   }

   return [simInvUpdateTimes,aobject1] ;
}

//=====
// the type of data that an simInv database uses
// for example: assets uses an [], while assetHistory uses ans  {}
function assetData_empty(ado) {
    let doList={'cpiuSeries':{},'settings':{}, 'viewDates':{},
      'assets':[],'assetHistory':{},
     'portfolios':[],'portfolioInit':{},'portfolioModifications':{},'scenario':{}
    } ;   // default values if nothing speciifed
     if (!doList.hasOwnProperty(ado)) {
          alert('assetData_empty: unknown data: '+ado);
          let thisError=assetDataEmtpyFunc/3;
     }
     let zz=JSON.parse(JSON.stringify(doList[ado]));
     return zz;
}



//================     (
// siminv encryptione   -- returns object
// if akey=false, or 0 or '' : do NOT encrypt. Just return stringified adata as is

function simInvEncrypt(adata,encryptionKeyDo) {

   if (encryptionKeyDo===false || jQuery(encryptionKeyDo)==='' || encryptionKeyDo==0)  {
      let adata1=JSON.stringify(adata);             // stringify object
      return adata1;
   }

   let adata1=JSON.stringify(adata);             // stringify object
   let encObj=CryptoJS.AES.encrypt(adata1,encryptionKeyDo);          // encrypt the stringified
   let  encString=encObj.toString();                                // extract the text that contains the encrypted/stringified object
   let amd5=simInv_makeEncMd5(encryptionKeyDo) ;
   stuff={'dataEnc':encString,'encrypt':amd5};          // a non-'' encrypt signals that data is stringifyied/encrypted  -- using akey whose md5 is amd5

   return stuff;
}

//================
// simInv decrytprion
// return decrypted value of info stored in stuff
// if stuff does not an object with just a dataEnc and encrypt fields, decryption is not attempted --  stuff is
// returned as is
// Note that when "returned as is" -- stuff may need to be destringified
//   25 dec 2023 : however, as currently used simInvDecrypt is ONLY called it decryption is expected to be needed
// if it does have these fields (dataEnd and encrypt), but akey is false or '', fatal error occurs
// if it has these fields, but md5(akey) does not match encrypt, bad key error is returned
// if it has these and they match, the decrypted (and unstringified) contents of stuff['dataEnc'] is returned
// akey is  encryption key
// amess is extra messed use if error

function simInvDecrypt(stuff,akey,amess) {
   if (arguments.length<3) amess=false;

   if (akey===false) return stuff ;                       //  return  as is

   if (!jQuery.isPlainObject(stuff))  return stuff;

   for (let afield in stuff) {
       if (afield!=='dataEnc' && afield!=='encrypt')  return stuff ;  // has a field other than the only two allowed. Return as is
   }

   if (!stuff.hasOwnProperty('encrypt') || !stuff.hasOwnProperty('dataEnc')) {    // has  both encryption fields?
       showDebug(stuff,'simInvDecrypt: data has empty encryption information ',1);
       return null ;
   }

   if (akey===0 || jQuery(akey)=='')  {     // stuff is a valid "simInv encrypted" object -- so check if a key is provided
       showDebug(stuff,'simInvDecrypt: encrypted data, but no key provided',1);
       return null;
   }

   let storedMd5=stuff['encrypt'];

   let check1Md5=simInv_makeEncMd5(akey) ;  // check for validity of key before decyrptiong

   if (check1Md5!==storedMd5) {   // user entred key doesn't the stored key (the md5 of the key used for encryption)
        if (amess!==false) alert(amess+' : provided keyMd5  ',check1Md5 + ' does not match stored keyMd5= '+storedMd5 ) ;
        return null ;
  }

  let decryptedBytes = CryptoJS.AES.decrypt(stuff['dataEnc'], akey);
  try {              // could be an error....
    plaintext = decryptedBytes.toString(CryptoJS.enc.Utf8);
    let data1=JSON.parse(plaintext);
    return data1 ;
  } catch(err) {    // should not happen, but who knows
    return null ;
  }

}



//===============
// converrt xxK and xxM to xx000  or xx000000
function fixNumberValue(aval) {
      aval=jQuery.trim(aval).toLowerCase();
      aval= aval.replace(/,/g,'');
      let achar=aval.slice(-1).toLowerCase()  ;
      let bval=false;
      if (achar=='k') {
         bval=aval.substr(0,aval.length-1);
         if (!jQuery.isNumeric(bval)) return false ;
         bval=parseFloat(aval)*1000;
      } else if (achar=='m') {
         bval=aval.substr(0,aval.length-1);
         if (!jQuery.isNumeric(bval)) return false ;
         bval=parseFloat(bval)*1000000;
      }  else {
        if (!jQuery.isNumeric(aval)) return false;
        bval=parseFloat(aval);
      }
      return bval;
}


// return sort list of numbers, duplicates removed
// all non-number values are at beginning of list, sorted lexigrapically.
// The sort of these non-numbers may not be fully as expected

function sortNoDuplicates(alist0) {
  let alist=[];
  if (alist0.length==0) return alist ;
  for (let ii=0;ii<alist0.length;ii++) alist[ii]=alist0[ii];  // clone

  alist.sort(mySortNumeric);   // numeric sort. Non numbers appear before numbrs
  let oof2=[];
  iwas=alist[0];
  oof2[0]=iwas;
   for (let jj=1;jj<alist.length;jj++) {  // get rid of duplicates
         let adate=alist[jj];
         if (adate!==iwas) {
             oof2.push(adate);
             iwas=adate;
         }
    }
    return oof2;
}

// === ================
// sort by number value.
// if an element is NOT a number, it is "before" a number
// if both are not numbers, sort lexigraphically

function mySortNumeric(a,b) {
   if (!jQuery.isNumeric(a) || !jQuery.isNumeric(b)) {  // one or both not numbers
       if (jQuery.isNumeric(a)) return 1 ;     // just b is nonnumeric, so b should  be before a
       if (jQuery.isNumeric(b)) return -1 ;   // just a is nonnumeric, so a should  be before b
       if (a>b) return  1;
       if (a==b) return 0;
       return -1 ;
   }
   let a1=parseFloat(a);  // both are numbers
   let b1=parseFloat(b);
   return a1 - b1;
}

// ------------
// can use this as an alternative to jQuery.isNumeric (march 2024: jQuery.isNumeric depreated for jquery 3.3)

var isNumeric2 = function(obj){
  return !Array.isArray( obj ) && (obj - parseFloat( obj ) + 1) >= 0;
}


//===================
// convert an object to a array, with each array a csv string
//    myData : the object to convert. Required
//    levels: array of "row headers". Must be an array with at least one element
//        levels is also used to divide the object into "rows" in the csv array.
//        It can have up to 4 elements
//    headerSep: a seperator string, used in column names. If not specified , ':' is used
//    arraySep :  aseperator string used in arrays. If not specified, a ',' used
//    defVal : default value used if a property is not defined. Default is nothing (which is different from "")
//    quoteRep :  a string to use to replace " characters. If not specified,  or false, quote characters are removed.
//     skips: object with properties that values of "level1" that should be skipped. Default is false (none)
//
//   For example:
//      levels=['userName','date'], defVal="" , arraySep=',';
//          mydata['joe']['19781']={'pet':'cat,'car':'jeep'}
//          mydata['joe']['20924']= {'pet':'dog','car':'cadillac'}
//          mydata['jill']['20124']= {'car':'toyota'} ;
//          mydata['jill']['20924']=  {'pet':'rabbit','car':''} ;
//          mydata['sam']['23511']=  {'pet':'snake','car':'['nissan','ford']} ;
//    yields lines like
//       "username","date","pet","car"
//       "joe",19781,"cat","jeep"
//       "joe",20924,"dog","cadillac"
//       "jill",20124,"","toyota"
//       "jill",20924,"rabbit",""
//       "sam",23511,"snake","nissan,ford"
//
// Notes:
//  *  "" is used in the "pet" column for  the "jill,"20124" row:  since 'pet' is not a property of mydata['jill']['20124']
//  * if a value can be interpreted as a number if it NOT quoted. Otherwise it is.
//  * If a value of a property is an array, it is concatenated using the arraySe and saved as a string. That is: seperate columns are NOT
//     created for each index of the array.
//  * If a property after the "levels" is an object, each of its properties is saved to its own column; using the headerSep
//     For example, if headerSep is ' : '
//      myData.harry.18901.animals has properties 'name','age','weight'
//        seperate columns are created with top row "column names" of
//            "animals : name"
//            "animals : age"
//            "animals : weight"

function objectToCsv(myData,alevels,headerSep,arraySep,defval,quoteRep,skip1) {

 if (arguments.length<2) {
    alert('objectToCsv requires a data and options arguments ');
    return false;
 }
 if (!jQuery.isPlainObject(myData)) {
    alert('objectToCsv data arg must be an object');
    return false;
 }
 if (!Array.isArray(alevels) || alevels.length<1  )  {
    alert('objectToCsv levels (the identifier properties)g must be an array with at least one element : '+typeof(alevels)+'  and length='+alevels.length);
    return false;
 }
 if (alevels.length>4  )  {
    alert('objectToCsv: there can not be more than 4 identifier properties (in the levels argument)');
    return false;
 }

 if (arguments.length<3) headerSep='|';
 if (arguments.length<4) arraySep=',';
 if (arguments.length<5) defval=' ';
 if (arguments.length<6) quoteRep=false;
 if (arguments.length<7) skip1=false;
 let skip2={} ;        // 21 march 2024 not yet impemented

// if (jQuery.trim(defval)==='') defval=' ';  // at least one charcater long

 let scalarTypes={'string':1,'number':1,'boolean':1,'bigInt':1};  // use in internal functions

 if (skip1!==false) {
     if (!jQuery.isPlainObject(skip1)) {
        alert('objectToCsv skip1 is specified, but is not an object ');
        return false;
     }
 }

 let bigCsv=[];   // this will be filled, one row per levels combo

// find the "levels" -- the "identifier propertiess"

 let dlevels=[]  ;    // each will be an  object will ALL properties that appear in this level
  dlevels[0]={};     // the main properties -- first col in csv
  dlevels[1]={};     // secondary properties (which may or may not be in all the main properties)  -- 2nd col in csv
  dlevels[2]={};     // tertiary properties
  dlevels[3]={};      // quarternary properties
  let metaData={} ;   // primary properties that are NOT objects
// fill in dlevels -- the "primary,...,quarternay"  identfier-propertries that appear anywhere in myData
// Each row of the CSV is identified by a unique combination  of "identifier properties"  (there can be up to 4)

  for (let ac1 in myData) {    // Look at all the "main" properties of the myData object

     if (!jQuery.isPlainObject(myData[ac1])) {      // 21 march 2024 .. save, but not yet used
         metaData[ac1]=1;
         continue ;          // this primary property is NOT an object -- it is metadata
     }

     if (skip1!==false) {          // skip this "primary property" ?
         if (skip1.hasOwnProperty(ac1)) continue;
     }
     dlevels[0][ac1]=1 ;          // myData[ac1] could be scalar (or array), but could be another object
     if (jQuery.isPlainObject(myData[ac1]) && alevels.length>1) {          // search more levels
         for (ac2 in myData[ac1]) {
            if (skip2.hasOwnProperty(ac2)) continue;      // skip this seconeary proerty
            if (!jQuery.isPlainObject(myData[ac1][ac2])) continue ;  // skip this secondary property is not an object
            if (!dlevels[1].hasOwnProperty(ac2)) dlevels[1][ac2]=0 ;     // ve this "object" as a secondary level
            dlevels[1][ac2]++ ;                                           // count of number of times this secondary property appears (in a primery property)
            if (jQuery.isPlainObject(myData[ac1][ac2]) && alevels.length>2) {
              for (ac3 in myData[ac1][ac2]) {
                  if (!jQuery.isPlainObject(myData[ac1][ac2][ac3])) continue ;  // skip if  this tertiary property if not an object
                  if (!dlevels[2].hasOwnProperty(ac3)) dlevels[2][ac3]=0 ;       // save this "object" as a tertiary level
                  dlevels[2][ac3]++;
                  if (jQuery.isPlainObject(myData[ac1][ac2][ac3]) &&  alevels.length>3) {
                     for (ac4 in myData[ac1][ac2][ac3] ) {
                       if (!jQuery.isPlainObject(myData[ac1][ac2][ac3][ac4])) continue ;  // skip if if  this quaternay property not an object
                       if (!dlevels[3].hasOwnProperty(ac4)) dlevels[3][ac4]=0 ;       // save this "object" as a quatenary level
                       dlevels[3][ac4]++ ;
                      }   //ac4
                  }  //  levels >3
              }  // ac3
            } // length >2
         }   // ac2
      }  // 1
   } //ac1

// list of all "id properties"
// Each combo of "identifier properties" is a unique row in the csv
// ONLY objects that have one of EACH idendifier level are considered.
// Thus: if 3 levels are specified, scalars in level 2 are ignored

  let levelsUse=[];

  let a0,a1,a2,a3;
  for  (a0 in dlevels[0]) {
      if (jQuery.isEmptyObject(dlevels[1])) {   // just one level
           let zz=[a0]
           levelsUse.push(zz);
           continue;
      }
      for (a1 in dlevels[1]) {
         if (jQuery.isEmptyObject(dlevels[2])) {      // just 2 levels
              let zz=[a0,a1]
              levelsUse.push(zz);
              continue;
         }
         for (a2 in dlevels[2]) {
             if (jQuery.isEmptyObject(dlevels[3])) {      // just 3 levels
                 let zz=[a0,a1,a2]
                 levelsUse.push(zz);
                 continue;
             }
             for (let a3 in dlevels[3]) {      // 4 levels
                 let zz=[a0,a1,a2,a3]
                 levelsUse.push(zz);
             }   // ic3
         }  //ic2
      }  // ic1
  }  // ic0

// find all unique "data value" property names -- under the primary,...,quaternay "identifier" properties var1.var2... property names
// Note that data values CAN be objects. If so -- "expanced" column names are used (to recursively write data to the csv)

  let saves={};
  for (let ir=0;ir<levelsUse.length;ir++)  {   // for primary,..., quaternary properties of myData
      let useMe=myData;                        // look in myData for primary properties
      let qok=true;
      for (let ir2=0;ir2<levelsUse[ir].length;ir2++)  {      // for each of up to 4 id properties (secondary nested in primary, etc)
          let aa=levelsUse[ir][ir2];                      // all specified Levels must have
          if (!useMe.hasOwnProperty(aa)) {
              qok=false;
              continue;
          }
          useMe=useMe[aa];                         // recursive drill down into a "nested" object  -- and
      }
      if (qok) {                      // got an object at the required "level" -- so recursively look for data value properties
        let nowVars0=[];
        objectToCsv_get(useMe,saves,nowVars0,headerSep,ir);   // saves is modified in place ('call by reference'), and used below 
      }
  }


  let saves_a=[],dataProperties=[];
  for (let zz in saves) {
     let woof=saves[zz];
     let atop=woof.join(headerSep);
     dataProperties.push(woof)
     let ug1={'colname':atop,'list':woof}
     saves_a.push(ug1);   // create array to  be sure order is the same (when outputting to csv)
  }
// saves_a ist a list of all 'data value" properties. Many of them may NOT be specfied for a given property-id combo -- in which case defval is used

  let hdr1='"'+alevels.join('","')+'"';
  let h1=[];
  for (ij1=0;ij1<saves_a.length;ij1++) h1.push(saves_a[ij1]['colname']);
  let hdr2='"'+h1.join('","')+'"';
  let hdr=hdr1+','+hdr2;
  bigCsv.push(hdr);

// build csv row for ech levelsUse

  for (let ir=0;ir<levelsUse.length;ir++)  {    // for each possible combo of identifier properties
      let crow=[];
      let useMe=myData;
      let qNoUse=false;
      for (let ir2=0;ir2<levelsUse[ir].length;ir2++)  {      // all of the "levels" must exist (as objects). If not, skip
          let aa=levelsUse[ir][ir2];
          if (!useMe.hasOwnProperty(aa)){
              qNoUse=true;
              break  ;           // missing an id property (that is an object) -- so skip (no row with this combo of id properties is written to csv)
          }
          crow.push(aa);
          useMe=useMe[aa];     // recurse!
      }
      
      if (qNoUse) continue ;

      if (!jQuery.isPlainObject(useMe)) {        // this should never happen
         wsurvey.dumpObj(crow,1,' objectToCsv: level '+ir2+'  is not a plain object ');
         continue  ;; // ignore "levels" if they are not an object
      }

// look for all the saves_a  dataValue properies (in the useMe ID property combo)
     for (let iss=0;iss<saves_a.length;iss++) {
         let ss1=saves_a[iss];
         let ss1V=ss1['list'];

         let useMe2=useMe,qmiss=false;
         for (iss2=0;iss2<ss1V.length;iss2++) {     // drill down...
              let ss2=ss1V[iss2];
              if (!useMe2.hasOwnProperty(ss2)) {     // does not have this property (could be a property of an uspecified nested object)
                  crow.push(defval);
                  qmiss=true;
                  break;
              }
              if (typeof(useMe2)=='undefined') alert(ir+' objectToCsv: useMe bad at '+ss1+', '+crow.join(' | '),1);
              useMe2=useMe2[ss2];
         }
         if (qmiss) continue ;         // doesn't have this property, so defval was used
         let vSay=objectToCsv_var(useMe2,ss1);      // quote strings, expand arrays, etc ...
         crow.push(vSay);
     }      // iss  (a dataValue property

     bigCsv.push(crow)
   }  // ir      (a ID properties combo

   return bigCsv ;


// ------------------------------
//  internal function: eturn "displayable" value of this property.  Eg; quote a value, recode " chars in strings, use defval if undefined or non-scalar, ...
   function objectToCsv_var(aa,aname ) {

      ttype=typeof(aa);

// simple cases
      if (ttype=='number' || ttype=='bigint')  return aa ; // simple case
      if (ttype==='boolean') {
         if (aa) return 'true'  ; // NOT " quoted
         return 'false';
      }

// strings (that need " quoting)?
      if (ttype=='string') {
         if (aa.indexOf('"')<0) return '"'+aa+'"';    // no embedded "
         if (quoteRep===false) {
           let aa2=aa.replace(/["]+/g,'') ;    // remove "
           return '"'+aa2+'"';
         }
         let aa2=aa.replace(/["]+/g,quoteRep) ; // replace with quoteRep  (which might be '')
         return '"'+aa2+'"';
      }

//  wierd stuff, or undefined for this "row" ..  use defval ...
      if (ttype!=='object'  ) return defval  ;    // function, undefined, etc

// if here, an object (could be null, or an array)
     if (aa===null) return 'null' ;   // similar to true and false
     if (!Array.isArray(aa)) return defval   // this should never happen  ... but   just in case..

// an array... if an array  of "scalars" -- than concatenate
     for (let ia1=0;ia1<aa.length;ia1++) {
       let ttype1=typeof(aa[ia1]);
       if (!scalarTypes.hasOwnProperty(ttype1))  return aname+' ' +aa.length+' mixed types' ;  // on non-scalar is enough
     }  
     
// if here then array just has  scalars: so concatenate  and return as "string"

     let aa1=aa.join(arraySep)   // will be checked for " below
     if (aa1.indexOf('"')<0) return '"'+aa1+'"';    // no embedded "
     let aa2;
     if (quoteRep===false) {
        aa2=aa1.replace(/["]+/g,'') ;    // remove "
     } else {
        aa2=aa1.replace(/["]+/g,quoteRep) ; // replace with quoteRep  (which might be '')
     }
     return '"'+aa2+'"' ;

 }  // .... objectToCsv_var internal

}     // objectToCsv
//
//=============
// recursive function to extract all property names from data
// ir is index to levelsUse (for info purposes)
// gotVars is "returned" (pass by reference)

function objectToCsv_get(data1,gotVars,nowVars,asep,ith ) {
   let nowHdr='';
   let nowVarsX=JSON.parse(JSON.stringify(nowVars)) ;
   if (nowVarsX.length>0) nowHdr='('+nowVarsX.join(')(')+')';      // first part of column names for all properties of data1 -- could be ''
   let iput=nowVars.length;
   for (let avar in data1)  {                    // all the 'data value' properties of data1 -- which could be objects that have datavalue proprties
       if (!jQuery.isPlainObject(data1[avar]))  {            //not an object, so is a "data value " property --- record it!
          let vnuse= (nowHdr!=='') ? nowHdr+'('+avar+')' : '('+avar+')' ;
          if (gotVars.hasOwnProperty(vnuse)) continue ;    // already found, so skip
          gotVars[vnuse]=JSON.parse(JSON.stringify(nowVars));
          gotVars[vnuse].push(avar);
          continue;
      }                       // if here, an object.. recurse!
      let ause=data1[avar];      // this is a  "sub object)
      if (jQuery.isEmptyObject(ause)) continue  ;         // empty object -- skip
      nowVarsX[iput]=avar;                 // add to end of    nowVarsX ( sequence of property names that yield data1)
      objectToCsv_get(ause,gotVars,nowVarsX,asep,ith )
   }           // get next avar in data1
   return true;

}


//=======================
// record miscellaneous tech and other notes
function simInv_notes(anote) {
   if (arguments.length<2) {
    let nowTime=wsurvey.get_currentTime(0);
    let zmess={'time':nowTime,'message':anote};
    simInvGlobals['notes'].push(zmess);
    return 1;
   }

//else, a view notes
  showDebug( simInvGlobals['notes'],'simInv technical notes! ',11);

}

//=============
// store "display results" to local storage (zip of the html)
// assume 5m local storage available
function simInv_cacheResults_save(amess,gname1) {
  if (simInvGlobals['cacheStuff']['cacheDisplayResults']===false) return false ;   // no caching!
   let nbuffer=500000   ;  // must be at least this amount free after storing in cache
   let nmax=5000000;       // assume 5m of local storage


  let ascen=simInvParams['scenarioUse'];
  if (ascen=='') ascen='0' ;
  let gname2='$'+ascen+'$'+gname1;
  let amessZip=LZString.compressToUTF16(amess);
  let nused=simInv_localBytesUsed(1) ;
  let nfree=nmax-(nused+nbuffer);
  if (nfree< (nbuffer+amessZip.length)) {
     let naval=nmax-(nused+nbuffer);
      simInv_notes('Unable to save to cache ('+amessZip.length+'  for '+gname2+') :  used+buffer= '+wsurvey.addComma(nused+nbuffer)+', &rarr; free=' +wsurvey.addComma(nfree));
      $('#iWarningsButton').show();
       $('#iWarningsButton').attr('data-what','fullStorage');
       $('#iWarningsButton').attr('data-info',naval);

      return false ;
  }   else {
     let aa= simInv_writeLocal(gname2,amessZip) ;
     simInv_notes('caching. zipLength='+amessZip.length +' (original='+amess.length+'), using '+aa[1]+' ... for '+gname2+' (current size of simInv user localStorage + buffer= '+wsurvey.addComma(nused+nbuffer)+', free=' +wsurvey.addComma(nfree)+')');
  }
  return true ;
}

//============
// read, if available, "dislay results" from cache
function simInv_cacheResults_read(gname1) {
   let isnull;
  if (simInvGlobals['cacheStuff']['cacheDisplayResults']===false) return false ;   // no caching!
  if (simInvGlobals['cacheStuff']['cacheDisplayResults']==='write') return false ;   // no reading of cache!
  let ascen=simInvParams['scenarioUse'];
  if (ascen=='') ascen='0' ;
  let gname2='$'+ascen+'$'+gname1;
  let astuff= simInv_readLocal(gname2,false) ;
  if (astuff===isnull || astuff===false ) return false;

  let astuff2=LZString.decompressFromUTF16(astuff);

  return astuff2 ;                             // false if no suc hvar
}

//================
// view quick dsiplay info
function  simInv_cacheResults_show(ifoo) {
  let bmess=' <input class="csettingsButton" type="button" value="&lArr;" onclick="viewDiagnostics(1)"> ';
  if (simInvGlobals['cacheStuff']['cacheDisplayResults']===false) {
      bmess+='quickDisplay not enabled. You can use  <button class="csettingsButton">&#9965;</button> to enable quickDisplay ';
      displayStatusMessage(bmess);
      toggleStatusMessage(0,1);
      return 1;
  }

  let nmax=5000000;       // assume 5m of local storage
  let nused=simInv_localBytesUsed(1) ;
  let nfree=nmax-nused;
   bmess+='Bytes used= '+wsurvey.addComma(nused)+', free=' +wsurvey.addComma(nfree) ;
   bmess+='&nbsp;&nbsp;&nbsp;<button class="csettingsButton"  title="Remove the  quickDisplay information for the checked entries..." onClick="simInv_cacheResults_remove(this)" >&#9003;remove &check;</button> ';
  let zz=simInv_getAllLocalVars(1) ;
  bmess+='<table id="isimInv_cacheResults_show" border="1" xrules="rows" cellpadding="5"> ';
  let aall='<button class="csettingsButton"  onClick="simInv_cacheResults_checkAll(this)" title="check all (for removal)"> &#9003; &check;</button> ';
  bmess+='<tr><th>'+aall+'Scenario</th><th>portfolio</th><th>Inflation adjusted?</th><th>Interpolated</th><th>Size</th></tr>';
  for (let aa in zz) {
      let aas=aa.split('$');
      let ascen=aas[1];
      if (ascen=='0') ascen='<span title="Scenario not chosen">...</span>';
      let bbs=aas[2].split('_');
      let aport=bbs[0];
      if (aport=='main') aport='all';
      let isInf=(aa.indexOf('_inf')>-1) ? 'Yes' : 'No';
      let isInterp=(aa.indexOf('_interp')>-1) ? 'Yes' : 'No';
      let arem='<input name="remove_checkBox" type="checkbox" value="x" data-what="'+aa+'" title="Remove this from local storage"> ';
      bmess+='<tr><td><label>'+arem+' '+ascen+'</label></td><td>'+aport+'</td><td>'+isInf+'</td><td>'+isInterp+'</td><td>'+zz[aa].length+'</td></tr>';
  }
  bmess+='</table>';

  displayStatusMessage(bmess);
  toggleStatusMessage(0,5);

}
//=============
// check all for removal
function simInv_cacheResults_checkAll(athis) {
  let e1=$('#isimInv_cacheResults_show');
  let e2=e1.find('[name="remove_checkBox"]');
 
  e2.prop('checked',true);
  return 1;
}

//=============
// remove  checked
function simInv_cacheResults_remove(athis) {
  let e1=$('#isimInv_cacheResults_show');
  let e2=e1.find('[name="remove_checkBox"]');

  let e3=e2.filter(':checked');
  for (let i3=0;i3<e3.length;i3++) {
     let awhat=$(e3[i3]).attr('data-what');
     simInv_removeLocal(awhat)

  }
  simInv_cacheResults_show(1) ; // refresh

  return 1;
}

//=============
// remove  all
function simInv_cacheResults_removeAll(athis) {

  let zz=simInv_getAllLocalVars(1) ;
  let nn=0;
  for (let aa in zz) {
     simInv_removeLocal(aa) ;
     nn++;
  }

  simInv_notes('Remove '+nn+' from localStorage ');
  return 1;
}

//-===============
function simInv_fastQuickDisplayReCalc(i1) {

    window.setTimeout(function() { //  give dom a moment to settle

// replicate "afterLogon"
     simInvGlobals['cacheStuff']['cacheDisplayResults']='write';
     let response2=simInvDsets['allCurrentData2']  ;   // saved by afterLogon_build()
     let entryComments2=setupPortfolios(response2) ; // basic setup for globals portfolioInit and portfolioModifications

      simInvDsets['qStatusList']['setupPortfolioInit']= makePortfolioInitValues(1)  ;    // changes global portfolioInit -- adds current values!
      simInv_notes(portfolioList.length+ ' portfolio Init entries processed (fast quickDisplay) ');

     if (simInvDsets['qStatusList']['setupPortfolioInit']!==false) {            // portfolioInit okay (no asset errors found)
        portfolioLookup=makePortfolioLookup(entryComments2 );  // portfolioLookup global    -- is used by  makePortfolioModifyValue
        simInvDsets['qStatusList']['setupPortfolioMod']=makePortfolioModifyValue(1)  ;    // modifies global portfolioModifications
        simInvDsets['qStatusList']['setupPortfolioLookup']= true;
        let nInits= makePortfolioLookupFix(1)  ; // update totnets in portfolioLookup using recalcualted portfolioModifications  (and get # of mod entries)
        simInv_notes(nInits + ' portfolio Modification entries processed  (fast quickDisplay) ');
        makeViewDatesAll(1) ;          // augment the siminvDsets['viewDates'] (this used portfolioLookup global

     }
     showAllPortfolioValuesStart(i1);

    },100);
}
