// ========
// update asset info
// useDate : date to find values for -- all attributes of all assets as of this date (a 5 digit datestamp)
//
// This updates values of asset-specific attributes -- attributes that do NOT depend on the portfolio
//  What is calculated depends on the asset type
//    a) attributes that can change (based on asset history entries).
//       These can be calculated using linear interpolation between entries.
//          price dividend rent interest  expense income growthFrac  -- depending on asset type
//    b) Are set when asset is defined:
//       These are included as a convenience (they can also be read from assetLookup)
//          taxFreeFrac
//
//    Several "portfolio dependent" asset attributes are NOT set here.
//    These attributes depend on detalis specified when an asset is added to a portfolio
//      Tax deferred bonds:  RMD distributions (uses age and date when distributions start,and version)
//      Properties: loanOwed, principal paid, interest paid (given when loan starts, and loan attributes)
//      Annuities: annuity income (given date annuity begins)
//
// 30 Jen 2024 : aName used to be a 2nd argument -- it is deprecated
//
// returns : true (if entries for usedate exist, ndid (# of items added to assetValuesCache)

function doUpdateAssets(useDate) {

  if (simInvDsets['assetValuesCache']['list'].hasOwnProperty(useDate) ) {
       return true;           // cache exists, so done  (no need to create a cache entry)
  }

// no cache entry for useDate ... create it
  simInvDsets['assetValuesCache']['list'][useDate]={};

   let ndid=0,useIs={};

   for (let anAsset in assetHistory ) {

     let len1= assetHistory[anAsset]['entries'].length ;

     if (len1==0) continue;                  // not initialized

     let firstDate=assetHistory[anAsset]['entries'][0]['date'] ;
     if (firstDate>useDate) continue ;      // asset not specifed as of this date, so not available

     if (firstDate==useDate) {        // exact match to "initialization"
        useIs[anAsset]=[0,0,'exact'];
        continue ;
    }

     if (len1==1) {
        useIs[anAsset]=[0,0,'one'];
        continue;
    }

     let lastDate=assetHistory[anAsset]['entries'][len1-1]['date']  ;
     if (useDate>=lastDate) {        // after or at last, so use last
        useIs[anAsset]=[len1-1,len1-1,'after'];
        continue ;
     }

       let klen=assetHistory[anAsset]['entries'].length

//   after first, before last... perhaps exact, perhaps interpolate
     for (let ij=klen-1;ij>=0;ij--) {
         let adate=assetHistory[anAsset]['entries'][ij]['date'];
         if (adate==useDate) {
             useIs[anAsset]=[ij,ij,'exact' ];
             break;
         }
         if (adate<useDate)  {  // this is lower end
             useIs[anAsset]=[ij,ij+1,'interpolate' ];   // ij never > = length (given check above)
             break;
         }

      }
   }    // useIs

//  using bounds in useIs  -- interpolation done if not an exact match to an assetHistory entry

     for (let anAsset in useIs) {
       let i0=useIs[anAsset][0];
       let i1=useIs[anAsset][1];

       ndid++;
       let atype=assetLookup[anAsset]['assetType'];

       let avals={};
       avals['comment']=assetHistory[anAsset]['entries'][i0]['comment'];
       avals['type']=atype ;

       let day1=assetHistory[anAsset]['entries'][i0]['date'];
       let day2=assetHistory[anAsset]['entries'][i1]['date'];
       avals['match']=[day1,day2];
       let dlen=day2-day1;

       if (atype==0)  {                // stock
         let aprice,adividend ;
         if (dlen==0  ) {                // exact match
           aprice=parseFloat(assetHistory[anAsset]['entries'][i0]['assetPrice']);
           adividend=parseFloat(assetHistory[anAsset]['entries'][i0]['assetDividend']);
         } else {
             let dfact=(useDate-day1)/dlen;
             let a1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetPrice']);
             let a2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetPrice']);
            aprice=a1+ ((a2-a1)*dfact);
             let d1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetDividend']);
             let d2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetDividend']);
            adividend=d1+ ((d2-d1)*dfact);
         }
         avals['price']=aprice;
         avals['dividend']=adividend;
       }

       if (atype==1 || atype==2)  {                // bond (regular or tax deferred)
         let ainterest ;
         if (dlen==0  ) {                // exact match
           ainterest=parseFloat(assetHistory[anAsset]['entries'][i0]['assetInterest']);
         } else {
             let dfact=(useDate-day1)/dlen;
             let a1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetInterest']);
             let a2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetInterest']);
             ainterest=a1+ ((a2-a1)*dfact);
         }
         avals['interest']=ainterest;
         if (atype==1) avals['taxFreeFrac']=assetLookup[anAsset]['taxFreeFrac'];
       }

       if (atype==3)  {              // property
//       showDebug(assetHistory,'assethistory xx ',1);
         let aprice,arent,aoffset,saleCost ;
         if (dlen==0  ) {                // exact match
             aprice=parseFloat(assetHistory[anAsset]['entries'][i0]['assetSalePrice']);
             arent=parseFloat(assetHistory[anAsset]['entries'][i0]['assetNetRent']);
             saleCost=parseFloat(assetHistory[anAsset]['entries'][i0]['assetSaleCost']);
             if (!jQuery.isNumeric(saleCost)) saleCost=0;
         } else {        // interpolate ...
             let dfact=(useDate-day1)/dlen;

             let a1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetSalePrice']);
             let a2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetSalePrice']);
            aprice=a1+ ((a2-a1)*dfact);

             let d1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetNetRent']);
             let d2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetNetRent']);
            arent=d1+ ((d2-d1)*dfact);

            saleCost=0;
            if (assetHistory[anAsset]['entries'][i0].hasOwnProperty('assetSaleCost') &&
               assetHistory[anAsset]['entries'][i1].hasOwnProperty('assetSaleCost') ) {   // 16 jan 2024 .. deal with older specs that did not have saleCost
                 let sc1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetSaleCost']);
                 if (!jQuery.isNumeric(sc1)) sc1=0;
                 let sc2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetSaleCost']);
                 if (!jQuery.isNumeric(sc2)) sc2=0;
                 saleCost=sc1+ ((sc2-sc1)*dfact);

            }

         }
         avals['price']=aprice;
         avals['rent']=arent;
         avals['saleCost']=saleCost;
         avals['taxFreeFrac']=assetLookup[anAsset]['taxFreeFrac'];

       }

       if (atype==4) {     // incomeStream
         let aincome ;
         if (dlen==0)   {                // exact match
           aincome=parseFloat(assetHistory[anAsset]['entries'][i0]['assetIncome']);
         } else {
             let dfact=(useDate-day1)/dlen;
             let a1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetIncome']);
             let a2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetIncome']);
            aincome=a1+ ((a2-a1)*dfact);
         }
         avals['income']=aincome;
         avals['taxFreeFrac']=assetLookup[anAsset]['taxFreeFrac'];
       }

       if (atype==7) {     // expenseStream
         let aexpense ;
         if (dlen==0)   {                // exact match
           aexpense=parseFloat(assetHistory[anAsset]['entries'][i0]['assetExpense']);
         } else {
             let dfact=(useDate-day1)/dlen;
             let a1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetExpense']);
             let a2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetExpense']);
            aexpense=a1+ ((a2-a1)*dfact);
         }
         avals['expense']=aexpense;
         avals['taxFreeFrac']=assetLookup[anAsset]['taxFreeFrac'];
       }

       if (atype==5) {     // annuity
         let aincome,agrowth ;
         if (dlen==0  ) {                // exact match
           aincome=parseFloat(assetHistory[anAsset]['entries'][i0]['assetIncome']);
           agrowth=parseFloat(assetHistory[anAsset]['entries'][i0]['assetIncomeGrowth']);
         } else {
             let dfact=(useDate-day1)/dlen;
             let a1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetIncome']);
             let a2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetIncome']);
            aincome=a1+ ((a2-a1)*dfact);
             let d1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetIncomeGrowth']);
             let d2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetIncomeGrowth']);
            agrowth=d1+ ((d2-d1)*dfact);
         }
         avals['income']=aincome;
         avals['growthFrac']=agrowth;                        // calcAnnuityValues uses income and growthfrac to determine actual annuity income (given an acqusition date)
         avals['taxFreeFrac']=assetLookup[anAsset]['taxFreeFrac'];

       }        // annuity

       if (atype==6) {     // oneOff
         let assetReceipt ;
         if (dlen==0)   {                // exact match
           assetReceipt=parseFloat(assetHistory[anAsset]['entries'][i0]['assetOneOff']);
         } else {
             let dfact=(useDate-day1)/dlen;
             let a1=parseFloat(assetHistory[anAsset]['entries'][i0]['assetOneOff']);
             let a2=parseFloat(assetHistory[anAsset]['entries'][i1]['assetOneOff']);
             assetReceipt=a1+ ((a2-a1)*dfact);
         }
         avals['receipt']=assetReceipt;
         avals['taxFreeFrac']=assetLookup[anAsset]['taxFreeFrac'];
       }

       simInvDsets['assetValuesCache']['list'][useDate][anAsset]=avals;  // save to global


   }     // if aName specified, jumps here if anAsset != aName

   return ndid ;

}

//===============
// return caclculated asset attribute, given a date  and  assetname
// adate: date to calculate for,
// aName:asset to calculate,
// att1: attribute of this asset,  or '*' for attributes. If false (the default) return all info (attibures, and type/comment/match info
// sayError: if 1, then alert a message (otherwise just return false
//
// suggest useage (a bit expensive since it might make entries for porfolios that nver use them)
//  doUpdateAssets(adate);   // does nothing if adate already done
//  aval=getAssetValue(adate,aName,...);

function getAssetValue(adate,aName,att1,sayError) {

   if (arguments.length<5) nocreate=0;
   if (arguments.length<4) sayError=0;
   if (arguments.length<3) att1=false ;           // no attribute: return the object with all attributes

   let a1=doUpdateAssets(adate);  // create  assetValuesCache if one does not already exist
   if (a1===false ) {   // should not happen
        if (sayError==1) alert('getAssetValue: no asset values for '+adate );
        return false;
   }
   if (!simInvDsets['assetValuesCache']['list'][adate].hasOwnProperty(aName))  {
        if (sayError==1)   alert('getAssetValue: no asset values for '+adate+'/'+aName);      //should not happen
        return false;
   }

   let v1=JSON.parse(JSON.stringify(simInvDsets['assetValuesCache']['list'][adate][aName]));   // clone from   global

   if (v1===false) return false ;                   // should not happen

// apply scenariomultipliers
   if (simInvParams['scenarioUse']!='') {

       let ascenario= simInvParams['scenarioUse'] ;

       if (simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(ascenario)) {       // this scenario exists -- find matching date
          let imatch=false;
          for (let im=0;im<simInvDsets['scenarioList'][ascenario].length;im++)  {   // stop when adate >= scenarioList date
              let jdate=simInvDsets['scenarioList'][ascenario][im];
              if (jdate>adate) break;
              imatch=jdate;
          }
          if (imatch!==false)  {  // got a match (a scenario entry date just < adate)
            let daMults=simInvDsets['scenarioSpecs']['entries'][ascenario][imatch]['multipliers'];
             let atype=v1['type'];
             let use1=atype;
             if (daMults.hasOwnProperty(aname)) use1=aname;   // use asset specific multiplier if specified. Otherwise, use generic "asset type" multiplier
             v1['multipliers']={};
             v1['preMult']={};
             for (let aav in daMults[use1]) {
               if (aav=='type' || aav=='sayname') continue ; //skip these metadata
               if (v1.hasOwnProperty(aav)) {
                   v1['preMult'][aav]= v1[aav] ;        // save for info purposes
                   v1[aav]=v1[aav]*daMults[use1][aav];  // the scenario adjusment (For this asset attirbut on this date, for this scenario)
                   v1['multipliers'][aav]=daMults[use1][aav] ;    // save for info purposes
               }

             }
          }

       }
   }

   if (att1===false) return v1 ;                    // return all attributes  and  comment/type/match

   if (att1=='*')  {           // return attributes (remove comment/type/match
     for (let zatt in v1) {
       if (zatt=='comment' || zatt=='type' || zatt=='match') {
          delete v1[zatt];;              // v1 is a clone, so this is safe
       } else {
          let vvxx=v1[zatt];
          if (jQuery.isNumeric(vvxx)) vvxx=parseFloat(vvxx);
          v1[zatt]=vvxx;
       }
     }     // zatt
     return v1;
   }         // att1 = *

//  if here, return just one attribute
   if (!v1.hasOwnProperty(att1)) {
         if (sayError==1) {
            alert('getAssetValue: no asset attribute ('+att1+') for '+adate+'/'+aName) ;
         } else {
          return false;
         }
    }   // if here, attribute exists  for this asset ...
    let vvX=v1[att1];
    if (jQuery.isNumeric(vvX)) vvX=parseFloat(vvX);
    return vvX ;             // return this attribute for this data and aset

}

//=========== match
// return list of dates with entries in  assetValuesCache, or list of assets that have been calculated for a datea
// if asobject specified and is 1, return as object. Otherwise, return as array
function getAssetValueInfo(useDate,asObject) {

   if (arguments.length<2) asObject=0;

   if (useDate!==false) {
     let a1=doUpdateAssets(useDate);  // create  assetValuesCache for usedate if one does not already exist
     if (a1===false) return false  ;       // should never happen
   }

   if (useDate===false) {         // get list of dates that currently have asset attributes calculated
      let dlist=[];
      for (let zdate in  simInvDsets['assetValuesCache']['list']) dlist.push(zdate);
      if (asObject==1) {
          let dobj={};
          for (let idd=0;idd<dlist.length;idd++) dobj[dlist[idd]]=1;
          return dobj;
      } else {
          return dlist;
      }
   }

// else, get list of assets of all assets available on  useDate

   if (!simInvDsets['assetValuesCache']['list'].hasOwnProperty(useDate)) return []  ;  // nothing avail for this date
   let vlist=[];
   for (let zasset in simInvDsets['assetValuesCache']['list'][useDate]) vlist.push(zasset);
   if (asObject==1) {
       let dobj={};
       for (let idd=0;idd<vlist.length;idd++) dobj[vlist[idd]]=1;
       return dobj;
   } else {
       return vlist;
   }

   return vlist;
}

