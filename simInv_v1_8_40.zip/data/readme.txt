14 April 2024 

This directory contains username specific subdirectories.
Each subdirectory contains data files specifiying assets, and portfolios, for a single user.

To create a "simInv" account for a new user, just create a subdirectory with the username.

For example: for a new user with a logon name of 'joeb', create a data/joeb directory 

You don't need to do anything else (the directory should be empty when you create it). 
When a user first logins, simInv will initialize his directory.

Note that simInv is distributed with a "test" subdirectory -- to support the "test" username.
You can use this for testing!

Notes: 

 * publicAssets/ (under the main simInv directory) contains asset information for publically available assets.
   See its readme.txt for information on how to add public assets.

 * in standalone mode, a user specific subdirectory is NOT used

 * in online mode with local storage, a user specific subdirectory is NOT used 



