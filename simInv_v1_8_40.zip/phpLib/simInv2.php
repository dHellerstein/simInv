<?php

// ============
// php for simInv

session_start() ;
ob_start();

// :::  save / retreive simInv data. This does very little processing -- is just chooses a directory and a file     :::::::::::::::::::::

// some global variables
$allowAutoArchive=1;    // 0: no, 1:yes, 2: no auto, but manual archive allowed

// add some php functions

$curDir1=getcwd();             // will be xxx/yyy/simInv/phpLib ... strip out /phpLib
$len1=strlen($curDir1);
$len2=$len1-7;
$curDir=substr($curDir1,0,$len2);

$todo=$_REQUEST['todo'];

if ($todo=='echoFile') {            // echo file back (used to download to afile
 $fname=$_REQUEST['fname'];
 $content=$_REQUEST['content'];
 header('Content-type: text/plain');
 header("Content-Length: " . strlen($content));
 header('Expires: 0');
 $filename=trim($fname);
 header('Content-Disposition: attachment; filename='. urlencode($fname));
 echo $content;
 exit;
}

// checkUserExists is one of the few requests that does not require an encMd5 ( even a '' one)
// 0: ready, 1:no username speciifed, 2: no such user,3: no settings
if ($todo=='checkUserExists')  { // special case (no encrytption);
    ob_end_clean();   // remove prints and other crap

    if (!array_key_exists('username',$_REQUEST) || trim($_REQUEST['username'])=='' )  {
       $retme=[1,"No username specified"] ;
        $vsuggests=json_encode($retme, JSON_UNESCAPED_UNICODE);  // encode for web transmission
        print $vsuggests;
        exit;
    }

   $auser=$_REQUEST['username'];
   $retme=[0,"Ready: $auser"] ;        // assume it worked
   $daDir=$curDir.'/data/'.$auser;

   $qexist=true;
   if (!is_dir($daDir)) {
          $qexist=false;
          $retme=[2,"No such user (admin must create) :: $auser"] ;
   } else {
        $aget=$daDir.'/*.json';
        $ff=glob($aget);
        if (count($ff)==0) {
           $retme=[3,"Uninitialized user :: $auser"] ;
           $qexist=false;
       }
   }
   if ($qexist===false) {
        $vsuggests=json_encode($retme, JSON_UNESCAPED_UNICODE);  // encode for web transmission
        print $vsuggests;
        exit;
   }

   $tryS=$daDir.'/settings.json';
   $gotSettings=file_exists($tryS);
   if (!$gotSettings) {
         $retme=[4,"Settings not specified for: $auser"] ;  // need to initialize this user (perhaps select encryption keyy)
   } else {
      $tryEnc=$daDir.'/encMd5.json';
      $gotEnc=file_exists($tryEnc);
      if (!$gotEnc) {
         $retme=[4,"Encryption not specified for: $auser"] ;  // need to initialize this user (perhaps select encryption keyy)
       }
    }

   $vsuggests=json_encode($retme, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;
   exit;


}     // checkuserexists

// --- not checkUserExists

if (!array_key_exists('username',$_REQUEST))  doReturnError("No username specified");   // exits directoly
$auser=$_REQUEST['username'];  // must exist
$daDir=$curDir.'/data/'.$auser;
if (!is_dir($daDir)) {
   doReturnError("No such user: $auser");   // exits directoly
}


// for all requests, .... encMd5 is checked

if (!array_key_exists('encMd5',$_REQUEST))  doReturnError('No encryption key specified (not even an empty one)','encKey',1);   // exits directoly

$myEncMd5=$_REQUEST['encMd5'] ;  // could be  blank

$savedMd5='';$ahint=0;  // used if no encryption key file
$xxx=readEncKey($auser,$curDir);
if ($xxx!== false) {
  $savedMd5=$xxx['encMd5'];
}

//print "oof saved: $savedMd5, provided=$myEncMd5 ";
//exit;

if ($savedMd5!= $myEncMd5) {   // both are blank is aslso allowed
    if ($savedMd5==='') {
       doReturnError('You do not need an encryption key  ')  ;
    } else {

       $ahint=false;
       $tryHint=$daDir.'/hint.json';  // see if hint available
       $gotHint=file_exists($tryHint);
       if ($gotHint) {               // if no hint file, hint is   ''
          $aa=file_get_contents($tryHint);
          if ($aa!==false) {
             $va=unserialize($aa);
             if (array_key_exists('dinfo',$va)) $ahint =$va['dinfo'] ;
          }
       }
       $amess="You did not specify the correct encryption key ($awhich) ... ";
       if ($ahint!='') $amess.='<br>Hint: <tt>'.$ahint.'</tt>';
       doReturnError($amess)  ;
    }
}   // encmd5 do not match

// "logon" ok (username exists, encryption key matches

if ($todo=='setupArchiveDirs')  {
  $amess=setupArchiveDirs($auser) ;
  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission   -- {main,removed,manual,auto] datestamps
  print_r($vsuggests);
  exit;
}

if ($todo=='getAutoArchiveBasics')  {
  ob_end_clean();   // remove prints and other crap
  $amess=getAutoArchiveBasics($auser,$allowAutoArchive);
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission   -- {main,removed,manual,auto] datestamps
  print_r($vsuggests);
  exit;
}

if ($todo=='makeManualArchive')  {
  ob_end_clean();   // remove prints and other crap
  $amess=makeManualArchive($auser,$allowAutoArchive);
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission   -- {main,removed,manual,auto] datestamps
  print_r($vsuggests);
  exit;
}

if ($todo=='makeAutoArchive')  {
  ob_end_clean();   // remove prints and other crap
  $amess=makeAutoArchive($auser,$allowAutoArchive);
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission   -- {main,removed,manual,auto] datestamps
  print_r($vsuggests);
  exit;
}

if ($todo=='recoverAutoArchive')  {
  ob_end_clean();   // remove prints and other crap
  $amess=recoverAutoArchive($auser,$allowAutoArchive);
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission   -- {main,removed,manual,auto] datestamps
  print_r($vsuggests);
  exit;
}

if ($todo=='recoverManualArchive')  {
  ob_end_clean();   // remove prints and other crap
  $amess=recoverManualArchive($auser,$allowAutoArchive);
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission   -- {main,removed,manual,auto] datestamps
  print_r($vsuggests);
  exit;
}

// .... return this users simInv data
if ($todo=='getData')  {
  getUserData($auser,$savedMd5);
  exit;
}



doReturnError("An unknown action: $todo ");
exit;



//===============
// retrieve this user's siminv data
// these may be encrypted -- decrypted on javascript side
// note that encMd5 check done before calling getUserData


function getUserData($auser,$savedMd5) {

 global $curDir ;

// the defaults: note use of data=false if no such xxx.json file

 $rets=['error'=>false,'errorMessage'=>'','messages'=>[],
     'encMd5'=>$savedMd5,          // for info puurposes
     'updateDate'=>false,
      'settings'=>false,
      'cpiuSeries'=>false,
      'assets'=>false,
      'assetHistory'=>false,
       'portfolios'=>false,
      'portfolioInit'=>false,
      'portfolioModifications'=>false,
      'scenario'=>false,
      'viewDates'=>false ]  ;

   $messages=[];

   $daDir=$curDir.'/data/'.$auser;

   if (!is_dir($daDir)) {
     doReturnError("No such user directory: $dadir");   // exits directoly
  }

  $try=$daDir.'/assets.json';
  $gotAssets=file_exists($try);
  if ($gotAssets) {
      $aa=file_get_contents($try);
      if ($aa===false) {
         doReturnError("Unable to retrieve assets file: $try ");
      } else {
        $va=unserialize($aa);
        if ($va===false) {
           doReturnError("Problem decoding assets file: $try ")  ;
        } else {

          $dd=date ("F d Y H:i:s.", filemtime($try));
          $rets['messages'][]='Using assets file updated on '.$dd ;
          $rets['assets']=$va;
        }
     }
  } else {
       $rets['messages'][]='No assets file available ';
  }     // gotassets

  // look for assets history file
  $tryH=$daDir.'/assetHistory.json';
  $gotAssetsH=file_exists($tryH);
  if ($gotAssetsH) {
      $aah=file_get_contents($tryH);
      if ($aah===false) {
         doReturnError("Unable to retrieve assets history file: $tryH ");
      } else {
        $vah=unserialize($aah);

        if ($vah===false) {
           doReturnError("Problem decoding assets history : $tryH ")  ;
        } else {
          $dd=date ("F d Y H:i:s.", filemtime($tryH));
          $rets['messages'][]='Using assets history file updated on '.$dd ;
          $rets['assetHistory']=$vah;
        }
     }
  } else {
          $rets['messages'][]='No assets history file available ';
  }     // assets history file

// look for portfolios file
  $try3=$daDir.'/portfolios.json';
  $gotportfolios=file_exists($try3);
  if ($gotportfolios) {
      $aa3=file_get_contents($try3);
      if ($aa3===false) {
         doReturnError("Unable to retrieve portfolios file: $try3 ");
      } else {
        $va3=unserialize($aa3);
        if ($va3===false) {
           doReturnError("Problem with portfolios file: $try3 ");
        } else {
          $dd=date ("F d Y H:i:s.", filemtime($try3));
          $rets['messages'][]='Using portfolios file updated on '.$dd ;
          $rets['portfolios']=$va3;
        }
     }
  } else {
     $rets['messages'][]='No portfolios file available ';
  } // portfolios file



// look for portfolio init file
  $try4a=$daDir.'/portfolioInit.json';
  $gotportfolioInit=file_exists($try4a);
  if ($gotportfolioInit) {
      $aa4a=file_get_contents($try4a);
      if ($aa4a===false) {
         doReturnError("Unable to retrieve portfolio initialization (original assets) file: $try4a ");
      } else {
        $va4a=unserialize($aa4a);
        if ($va4a===false) {
           doReturnError("Problem with portfolio initialization  file: $try4a ");
        } else {


          $dd=date ("F d Y H:i:s.", filemtime($try4a));

          $rets['messages'][]="Using portfolio initialization file. Updated on $dd "   ;
          $rets['portfolioInit']=$va4a;
        }
     }
  } else {
     $rets['messages'][]='No portfolios initialization  file available ';
  } // portfolio initialiation file


  // look for portfolio modifications file
  $try4b=$daDir.'/portfolioModifications.json';
  $gotportfolioModifications=file_exists($try4b);
  if ($gotportfolioModifications) {
      $aa4b=file_get_contents($try4b);
      if ($aa4b===false) {
         doReturnError("Unable to retrieve portfolio modifications : $try4b ");
      } else {
        $va4b=unserialize($aa4b);
        if ($va4b===false) {
           doReturnError("Problem with portfolio modifications  file: $try4b ");
        } else {
          $dd=date ("F d Y H:i:s.", filemtime($try4b));

          $rets['messages'][]="Using portfolio modifications file, updated on $dd "   ;
          $rets['portfolioModifications']=$va4b;
        }
     }
  } else {
     $rets['messages'][]='No portfolios modification file available ';

  } // portfolio modifications file


// look for scnearios file
  $try8=$daDir.'/scenario.json';
  $gotScenario=file_exists($try8);
  if ($gotScenario) {
      $aa=file_get_contents($try8);
      if ($aa===false) {
         doReturnError("Unable to retrieve scenario file: $try8");
      } else {
        $va=unserialize($aa);
        if ($va===false) {
           doReturnError("Problem decoding scenario file: $try8 ")  ;
        } else {
          $dd=date ("F d Y H:i:s.", filemtime($try8));
          $rets['messages'][]='Using scenario file updated on '.$dd ;
          $rets['scenario']=$va;
        }
     }
  } else {
     $rets['messages'][]='No scenario file available ';
  }     // scenario




// look for valuation dates file
  $try5=$daDir.'/viewDates.json';
  $gotValueDates=file_exists($try5);
  if ($gotValueDates) {
      $aa=file_get_contents($try5);
      if ($aa===false) {
         doReturnError("Unable to viewDates file: $try5");
      } else {
        $va=unserialize($aa);
        if ($va===false) {
           doReturnError("Problem decoding viewDates file: $try5 ")  ;
        } else {
          $dd=date ("F d Y H:i:s.", filemtime($try5));
          $rets['messages'][]='Using viewDates   file updated on '.$dd ;
          $rets['viewDates']=$va;
        }
     }
  } else {
     $rets['messages'][]='No viewDates  file available ';
  }     // valueDates


// personal settings

  $try6=$daDir.'/settings.json';
  $gotSettings=file_exists($try6);
  if ($gotSettings) {

      $aa=file_get_contents($try6);

      if ($aa===false) {
         doReturnError("Unable to use settings file: $try6");
      } else {
        $va=unserialize($aa);
        if ($va===false) {
           doReturnError("Problem decoding settings file: $try6 ")  ;
        } else {
          $dd=date ("F d Y H:i:s.", filemtime($try6));
          $rets['messages'][]='Using settings file updated on '.$dd ;
          $rets['settings']=$va;
         }
     }   // aa

  }   else {  // no settings file (should never happen)
     $rets['messages'][]='No settings file available: using defaults  ';


  } // settings


// cpiuSeries

  $try7=$daDir.'/cpiuSeries.json';
  $gotCpiu=file_exists($try7);
  if ($gotCpiu) {

      $aa=file_get_contents($try7);

      if ($aa===false) {
         doReturnError("Unable to use settings file: $try7");
      } else {
        $va=unserialize($aa);

        if ($va===false) {
           doReturnError("Problem decoding settings file: $try7 ")  ;
        } else {
          $dd=date ("F d Y H:i:s.", filemtime($try7));
          $rets['messages'][]='Using cpiuSeries saved on '.$dd ;
          $rets['cpiuSeries']=$va ;
         }
     }   // aa

  }   else {  // no cpiuSeries file (should never happen)
     $rets['messages'][]='No cpiuSeries file available: using defaults  ';
  } // cpiusedries


  $rets['updateDate']=makeAutoArchive_readTimestamp($auser,'') ;


  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;
}

//=-----------------------
// generic save a simInv   dataset  (might be encrsyped)
function saveDataset($auser,$daencMd5) {
   global $curDir ;

//  $curDir=getcwd();

  $awhich=$_REQUEST['which'];
  $acontent=$_REQUEST['data'];
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/'.$awhich.'.json';
  $aa=['time'=>time(),'content'=>$acontent ];
  $da2=serialize($aa);

  $nn=file_put_contents($try,$da2);
  if ($nn===false)  {
    doReturnError("Could not save: $awhich : in: $try ");
  }

// set timestamp file in main
  $tstamp= simInv_updateTimestamp($auser,'') ;
  $dateTime='Could not create datestamp';
  if ($tstamp!==false)  $dateTime = date('Y-m-d H:i:s', $tstamp);

  ob_end_clean();   // remove prints and other crap
  $amess="Saved: $awhich (on $dateTime)" ;
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit;
}


// ===========
// save current users "first used" encryption key
function saveEncMd5($auser,$daencMd5) {

 global $curDir ;
//  $curDir=getcwd();

  $dahint=''; // saved in settings
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/encMd5.json';
  $aa=['time'=>time(),'encMd5'=>$daencMd5,'hint'=>$dahint];

  $da2=serialize($aa);

  $nn=file_put_contents($try,$da2);
  if ($nn===false)  {
    doReturnError("Could not save md5 of encryption key in: $try ");
  }

  return 1;

}


// ===========
// return current users "first used" encryption key
function readEncKey($auser,$curDir) {

  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/encMd5.json';
  $gotEncKey=file_exists($try);
  if ($gotEncKey) {
      $aa=file_get_contents($try);
      if ($aa===false) {
         doReturnError("Unable to retrieve encryption key MD5 file: $try ");
      } else {
        $va=unserialize($aa);
        if ($va===false) {
           doReturnError("Problem reading encryption key MD5 file: $try ")  ;
        } else {
           return $va ;
        }
     }
  }

  return  false ;     // if no encMd5 ever saved, use a value of ''
}

//======================
// save personal settings for a suer
function  doSaveSettings($auser,$noexit=0)  {

  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/settings.json';

  $da2=serialize($_REQUEST['data']);   // 14 dec 2023 ... no need to tweak
  $nn=file_put_contents($try,$da2);
  if ($nn===false) {
     doReturnError("Error: could not save settings file: $try ") ;
     exit;
  }
  if ($noexit==1) return $da1 ;  // initializting call?

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($da1, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit;

}

//==========
//create    for auto, manual, and removed  subdirs (For auto archiving) -- if $makeAuto allows
function setupArchiveDirs($auser) {

// 26 dec 2023 -- assume this is called only if auto archive dir creation is desired
//  if ($makeAuto==0) return 'On this simInv instllation: auto-archiving is disabled.' ;       // not allowed, so dirs not created

  global $curDir;
  $amess='';

  $daDir=$curDir.'/data/'.$auser;

//  $removeDir=$daDir.'/removed';
//  if (!is_dir($removeDir)) {
//     $okay1=mkdir($removeDir);
//     if ($okay1) $amess.='remove/ subdir created!'   ;
//  }

  $manualDir=$daDir.'/manual';
  if (!is_dir($manualDir)) {
     $okay2=mkdir($manualDir);
     if ($okay2) $amess.='<br>manual/ subdir created!'   ;
  }


  $autoDir=$daDir.'/auto';
  if (!is_dir($autoDir)) {
       $okay3=mkdir($autoDir);
       if ($okay3) $amess.='<br>auto/ subdir created!'   ;
  }

   return $amess;
}




//===============
// save display dates for user
function  doSaveViewDates($auser)  {
  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/viewDates.json';
  $vdList=$_REQUEST['data']['list'];

  $da1=[];
  $da1['time']=time();
  $da1['list']= $vdList  ;
  sort($da1['list'],SORT_NUMERIC);

  $da2=serialize($da1);
  $nn=file_put_contents($try,$da2);
  if ($nn===false) {
     print_r("Error: could not save $try ");
     exit;
  }

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($da1, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;
}


//============================
// save a portfolio asset mix (initial)
function  doSavePortfolioInit($auser ) {

  $pname=$_REQUEST['portfolio']  ;

  $alls=$_REQUEST['alls'];

  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/portfolioInit.json';

  $portfolioInit=[];
  $pArray=[];

  if (file_exists($try)) {
    $aa=file_get_contents($try);
    if ($aa===false)  doReturnError("Unable to retrieve portfolio initialization file: $try ");
    $portfolioInit=unserialize($aa);
  }

  if (!array_key_exists($pname,$portfolioInit)) {    // doesn't exist, so initializse
     $portfolioInit[$pname]=[];  // this portfolio
     $portfolioInit[$pname]['alls']=$alls;  // this portfolio asset mix, totals, etc
   }
   $portfolioInit[$pname]['alls']=$alls;

  $da2=serialize($portfolioInit);
  $nn=file_put_contents($try,$da2);
  if ($nn===false) {
     print_r("Error: could not save initial portfolio to: $try ");
     exit;
  }

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode("saved $nn to $try", JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

}

//=============
// remove a portfolio modification
function   doRemovePortfolioModification($auser)  {
  $pname=$_REQUEST['portfolio']  ;
  $amod=$_REQUEST['modification'];

  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/portfolioModifications.json';

  $portfolioModifications=[];

  if (file_exists($try)) {
    $aa=file_get_contents($try);
    if ($aa===false)  doReturnError("Unable to retrieve portfolio modifications file: $try ");
    $portfolioModifications=unserialize($aa);
  }

  if (!array_key_exists($pname,$portfolioModifications)) {
       doReturnError("No such portfolio ($pname), so can not remove modification ($amod) ");
  }

   if (!array_key_exists($amod,$portfolioModifications[$pname]['alls'])) {
       doReturnError("In  portfolio $pname, no such modification ($amod) xx2 <pre>$result</pre>");
  }
  unset($portfolioModifications[$pname]['alls'][$amod])  ;
  $goo1=$portfolioModifications[$pname]['pArray']   ;
  $gooNew=[];
  foreach ($goo1 as $ii=>$idate) {
     if ($idate==$amod) continue;
     $gooNew[]=intval($idate);
  }
  $portfolioModifications[$pname]['pArray'] =$gooNew;

  $portfolioModifications2= serialize($portfolioModifications);
  $nn=file_put_contents($try,$portfolioModifications2);
  if ($nn===false) {
     print_r("Error: could not save portfolio modifications to: $try ");
     exit;
  }
  $amess="Modification $amod removed from portfolio $pname ";
  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;


}


//=============  ::::::::::::::::::::::::  =======================
// error return
function doReturnError($amess,$acondition='',$avalue='') {
     $rets=[];
     $rets['error']=true;
     $rets['errorMessage']=$amess;
     if ($acondition!='') $rets[$acondition]=$avalue;

    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
}


//=========
// from https://www.php.net/openssl_encrypt
// encrypts plain text $amessText) using $akey.
// returns base64 encoded version of the encrypted text, with 'wEncryt. $message:' prepended
// Thus: wDecrypt looks for 'wEncrypt. xxx :', and removes it. If this is not found (and xxx can be anything, including ""
//       an error is returned
function wEncrypt($amessText,$key,$message=" ") {
  $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
  $iv = openssl_random_pseudo_bytes($ivlen);
  $ciphertext_raw = openssl_encrypt($amessText, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
  $hmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
  $ciphertext = base64_encode( $iv.$hmac.$ciphertext_raw );

  $amessage1=str_replace(':',' ; ',$message);
  return "wEncrypt. $amessage1:". $ciphertext;
}

//--------------
// decrypte text that was encrypted using wEncrypt
// amessEncrypt : message encrypted (and base64'ed) with wEncrypt
// $akey  : key used to encrypt
// return the uncentryped text  or false if an erro
// if verbose is specified and equal 1, then
//   return [true,unencryptedText] if okay
//          [false,errorMessages] if an error  -- errorMessages is an array of erro messages
function wDecrypt($amessEncrypt0,$key,$verbose=0) {

  while(openssl_error_string() !== false);   // clear error s
  $ahead1=substr($amessEncrypt0,0,9);
  if ($ahead1!='wEncrypt.') {
     if ($verbose!=1) return false ;
     return [false,['Not an wEncrypted string (does not start with wEncrypt)']];
  }
  $jpos=strpos($amessEncrypt0,':');
  $amessEncrypt=substr($amessEncrypt0,$jpos);
  $c = base64_decode($amessEncrypt);
  $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
  $iv = substr($c, 0, $ivlen);
  $hmac = substr($c, $ivlen, $sha2len=32);
  $ciphertext_raw = substr($c, $ivlen+$sha2len);
  $original_plaintext = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
  $calcmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
  if (hash_equals($hmac, $calcmac)) { // timing attack safe comparison
       if ($verbose!=1)return $original_plaintext ;
       return [true,$original_plaintext];
   }
  if ($verbose!=1) return false ;

  $errs=[];
   while ($msg = openssl_error_string()) $errs[]= $msg ;

   return [false,$errs];

}


//==========================
// export data to a json file
function doExportData($auser) {
  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $aget=$daDir.'/*.json';
  $ff=glob($aget);
  $bnames=[];
  $rets=[];
  $messages=[];
  foreach ($ff as $ith=>$fullName) {
     $bname=basename($fullName,'.json');
     $aah=file_get_contents($fullName);
      if ($aah===false) {
         $messages[]="Export error: Unable to retrieve $bah: $aah ";
      } else {
        $vah=unserialize($aah);
        if ($vah===false) {
           $messages[]="Problem decoding $bah: $aah "  ;
        } else {
          $rets[$bname]=$vah;
          $messages[]="Retrieved: $bname ";
       }
     }   //aah=false
   }  // file
  $stuff=['info'=>$rets,'messages'=>$messages];

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests ;
  exit ;
}

// ===========
// echo export data
 // export data a json file
function doExportData2($auser) {
  $stuff=$_REQUEST['stuff'];
  print $stuff;
  exit;
}

// ================================= ===============
// auto archiving functions ....

//=============================
// auto and manual restore
// -1: dir does not exist, 0: no or bad timestamp, otherwise an integer timestamp
function getAutoArchiveBasics($auser,$makeAuto) {

  $amess=['current'=>0,'auto'=>-1,'manual'=>-1,'removed'=>-1,'user'=>$auser,'makeAuto'=>$makeAuto];
  $amess['current']=makeAutoArchive_readTimestamp($auser)  ;

  if ($makeAuto>0)  {
    $amess['removed']=makeAutoArchive_readTimestamp($auser,'removed') ;   // check for removed DIr timestamp
    $amess['manual']=makeAutoArchive_readTimestamp($auser,'manual') ;   // check for removed DIr timestamp
  }
  if ($makeAuto==1)  $amess['auto']=makeAutoArchive_readTimestamp($auser,'auto')  ;
  return $amess;
}

//===========
// restore data -- from auto  archive
function recoverAutoArchive($auser,$makeAuto) {
   global $curDir;
   $daDir=$curDir.'/data/'.$auser;
   $bmess=[];

   if ($makeAuto==0)  {
       $bmess[]='Archiving not enabled ';
       return $bmess;
   }
   $autoDir=$daDir.'/auto';
   if (!is_dir($autoDir)) {
      $bmess[]="Auto archiving is not enabled for $auser" ;
      return $bmess;
   }

//   $removeDir=$daDir.'/removed';
//   if (!is_dir($removeDir)) {
//      $bmess[]='No removed/ dir -- can not backup current files ';
//      $bmess[]=makeAutoArchive_clear($auser,'')  ;  // delete  current files
//   } else {
//       $bmess[]=makeAutoArchive_clear($auser,'removed')  ;  // move current files to removed... so first clear removed
//       $bmess[]=makeAutoArchive_move($auser,'','removed');
//   }

   $bmess[]=makeAutoArchive_copy($auser,'auto','')  ;  // copy (not rename) fromr auto to main
   
   return $bmess;
}

//===========
// restore data -- from manual archive
function recoverManualArchive($auser,$makeAuto) {
    global $curDir;
   $daDir=$curDir.'/data/'.$auser;
   $bmess=[];

   if ($makeAuto==0)  {
       $bmess[]='Archiving not enabled ';
       return $bmess;
   }
   $manualDir=$daDir.'/manual';
   if (!is_dir($manualDir)) {
      $bmess[]="Manual archiving is not enabled for $auser" ;
      return $bmess;
   }

//   $removeDir=$daDir.'/removed';
//   if (!is_dir($removeDir)) {
//      $bmess[]='No removed/ dir -- can not backup current files ';
//      $bmess[]=makeAutoArchive_clear($auser,'')  ;  // delete  current files
//   } else {
//       $bmess[]=makeAutoArchive_clear($auser,'removed')  ;  // move current files to removed... so first clear removed
//       $bmess[]=makeAutoArchive_move($auser,'','removed');
//   }

   $bmess[]=makeAutoArchive_copy($auser,'manual','')  ;  // copy (not rename) fromr manual to main
   return $bmess;
}

// 9 dec 2023 ... should  implement a 'recoverRemovedArchive ... ??

//=====================
// save a manual archive for auser

function makeManualArchive($auser,$makeAuto) {
   global $curDir;
   $daDir=$curDir.'/data/'.$auser;
   $bmess=[];

   if ($makeAuto==0)  {
       $bmess[]='Manual archiving not enabled ';
       return $bmess;
   }
   $manualDir=$daDir.'/manual';
   if (!is_dir($manualDir)) {
      $bmess[]="Manual archiving is not enabled for $auser" ;
      return $bmess;
   }
  $bmess[]=makeAutoArchive_clear($auser,'manual'); // clear manual
  $bmess[]=makeAutoArchive_copy($auser,'','manual');    // copy from current tomanual

  return $bmess ;

}

//=====================
// make an auto archive for auser

function makeAutoArchive($auser,$makeAuto) {
   global $curDir;
   $daDir=$curDir.'/data/'.$auser;
   $bmess=[];

   if ($makeAuto!==1)  {
       $bmess[]='Auto archiving not enabled ';
       return $bmess;
   }
   $manualDir=$daDir.'/auto';
   if (!is_dir($manualDir)) {
      $bmess[]="Auto archiving is not enabled for $auser" ;
      return $bmess;
   }
   $bmess[]=makeAutoArchive_clear($auser,'auto'); // clear auto
   $bmess[]=makeAutoArchive_copy($auser,'','auto');    // copy from current auto

   $adate=simInv_updateTimestamp($auser,'auto')  ;
   $dd=date('Y-m-d H:i',$adate);
   $bmess[]='Date of autoArchive: '.$dd;

   return $bmess ;

}



// =========   makeAutoArchive_ utilties ======

//========
// copy all files from one directory to another
//    makeAutoArchive_clearDir($auser,$toDir) SHOULD be called before calling this!
// Note: this will copy the lastUpdate.dat file from current -- hence, do NOT create  lastUpdate.dat in $ato

function makeAutoArchive_copy($auser,$afrom,$ato) {
    global $curDir;

   $daDir=$curDir.'/data/'.$auser;
   if (!is_dir($daDir)) return "(copy) Missing main directory for $auser " ;      // should never happen

   if (trim($afrom)!='') {
      $fromDir=$daDir.'/'.$afrom ;
      if (!is_dir($fromDir)) return "(copy) Missing from ($afrom) directory for $auser " ;      // should never happen
   } else {
       $fromDir=$daDir ;
   }

   if (trim($ato)!='') {
      $toDir=$daDir.'/'.$ato ;
      if (!is_dir($toDir)) return "(copy) Missing to ($ato) directory for $auser " ;      // should never happen
   } else {
       $toDir=$daDir ;
   }

   if ($toDir==$fromDir)    return "(copy) From ($afrom) and to ($ato) directories are the same ($auser) "  ;

   $aget2=$fromDir.'/*';
   $ff2=glob($aget2);
   $copies=[];
   foreach ($ff2 as $ith=>$fullName) {
          if (is_dir($fullName)) continue ;
          $abase=basename($fullName);
          $tofile=$toDir.'/'.$abase;
          $qq=copy($fullName,$tofile);
          if ($qq) $copies[]=$tofile;
   }

  $sayFrom= (trim($afrom)=='') ? '(main)' : $afrom ;
  $sayTo=  (trim($ato)=='') ? '(main)' : $ato ;

  $bmess='(copy) ' .count($ff2)." files &amp; dirs in $sayFrom/ ... ".count($copies). "  files were copied to $sayTo/  " ;
  return $bmess;

}

//========
// move all files from one directory to another
//    makeAutoArchive_clearDir($auser,$toDir) SHOULD be called before calling this!
// Note: this will move the lastUpdate.dat file from current -- hence, do NOT create  lastUpdate.dat in $ato

function makeAutoArchive_move($auser,$afrom,$ato) {
    global $curDir;

   $daDir=$curDir.'/data/'.$auser;
   if (!is_dir($daDir)) return "(move) Missing main directory for $auser " ;      // should never happen

   if (trim($afrom)!='') {
      $fromDir=$daDir.'/'.$afrom ;
      if (!is_dir($fromDir)) return "(move) Missing from ($afrom) directory for $auser " ;      // should never happen
   } else {
       $fromDir=$daDir ;
   }

   if (trim($ato)!='') {
      $toDir=$daDir.'/'.$ato ;
      if (!is_dir($toDir)) return "(move) Missing to ($ato) directory for $auser " ;      // should never happen
   } else {
       $toDir=$daDir ;
   }

   if ($toDir==$fromDir)    return "(move) From ($afrom) and to ($ato) directories are the same ($auser) "  ;
   
   $aget2=$fromDir.'/*';
   $ff2=glob($aget2);
   $renames=[];
   foreach ($ff2 as $ith=>$fullName) {
          if (is_dir($fullName)) continue ;
          $abase=basename($fullName);
          $tofile=$toDir.'/'.$abase;
          $qq=rename($fullName,$tofile);
          if ($qq) $renames[]=$tofile;
   }
   
  $sayFrom=(trim($afrom)=='') ?  '(main)' : $afrom ;
  $sayTo= (trim($ato)=='') ?  '(main)' : $ato ;

  $bmess='(move) '. count($ff2)   ;
  $bmess.="  files &amp; dirs in $sayFrom/ ... ";
  $bmess.=count($renames). " files were moved to $sayTo/: " ;
  return $bmess;

}


//======
// delete all files from a dir (typicallly auto, removed, or manual -- but if '', clear   main dir of auser)
function makeAutoArchive_clear($auser,$adir) {
    global $curDir;
   $daDir=$curDir.'/data/'.$auser;
   if (!is_dir($daDir)) return "(clearDir) Missing main directory for $auser " ;      // should never happen

   if (trim($adir)=='') {
       $usedir=$daDir ;        // this clears the main directory!
       $sayDir='(main)' ;
   } else {
     $usedir=$daDir.'/'.$adir ;
     if (!is_dir($usedir)) return "(clearDir) No $adir archive directory for $auser "  ;     // slight possiblity of happening
     $sayDir=$adir;
   }
   $aget=$usedir.'/*';
   $ff=glob($aget);
   if (count($ff)==0 ) {
      return "(clearDir) No files in $adir/";
   }

   $remfiles=[];
   foreach ($ff as $ith=>$fullName) {
      if (is_dir($fullName)) continue ;
      $qq=unlink($fullName);
      if ($qq) $remfiles[]=$fullName;
   }

   $bmess='(clearDir) Found '.count($ff)." files &amp; dirs in $sayDir/ ...  deleted ".count($remfiles).' files '; // Deleted files: '.implode(', ',$remfiles);
   return $bmess;

}

//=============
// create a timeSTamp file for user in a subdirectory  -- such as 'auto' or 'maual' .. .if asub=='', in main dir for this user

function  simInv_updateTimestamp($auser,$asub='') {

  global $curDir;
  $daDir=$curDir.'/data/'.$auser;
  if (!is_dir($daDir)) return false ;      // should never happen

  if (trim($asub)=='') {
     $usedir=$daDir ;
  } else {
     $usedir=$daDir.'/'.$asub;
     if (!is_dir($usedir)) return false ;      // should never happen
  }

  $afile=$usedir.'/lastUpdate.dat';
  $atime=time();
  $nbytes=file_put_contents($afile,$atime);
  return $atime ;
}


//==============
// read timestamp from a user's data dir (or subdir)
function makeAutoArchive_readTimestamp($auser,$asub='') {

  global $curDir;
  $daDir=$curDir.'/data/'.$auser;
  if (!is_dir($daDir)) return false ;      // should never happen

  if (trim($asub)=='') {
     $usedir=$daDir ;
  } else {
     $usedir=$daDir.'/'.$asub;
     if (!is_dir($usedir)) return false ;      // should never happen
  }

  $daFile=$usedir.'/lastUpdate.dat';
  if (!is_file($daFile))  return 0;

  $aa=file_get_contents($daFile);
  if ($aa==false || !is_numeric($aa)) return 0 ;  // no such file or bad contents are   treated the same
 $aa=intval($aa);
  return $aa ;



}


?>