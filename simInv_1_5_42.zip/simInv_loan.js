
//=======================
//  this is called from the asset specification menu (to preview what a loan, given a specified asset price, would look like
function specifyLoanSchedule(athis) {
   let ethis=wsurvey.argJquery(athis);
   let etr=ethis.closest('.assetHistoryRow');
   let aname=ethis.attr('data-aname');
   let eprice=etr.find('[name="assetSalePrice"]');
     let aprice0=(eprice.val());
     let aprice=fixNumberValue(aprice0);
   if (aprice===false  ) {
       alert('Please enter a numeric value for the price of '+aname+' ('+aprice0+') ');
       return 0;
   }

   let amess='<div class="loanSpecsBox">';
   amess+='<b> Loan worksheet.</b> When you add a <u>property</u> asset to a portfolio, you can specify a loan to pay for it.';
   amess+='This worksheet previews what a mortgage may look like.. ';
   amess+='<br>For <u>'+aname+'</u> with a purchase price=<tt>'+wsurvey.addComma(aprice)+'</tt>'  ;
   amess+='<ul>';
   amess+=' <li>Amount: <input type="text" value="'+aprice+'" title="Amount of loan (dollars). " name="loanAmt" size="8"><br>';
   amess+='   <li>Term: <input type="text" value="30" title="Length of loan (years)" name="loanTerm" size="8"><br>';
   amess+='<li>Interest rate: <input type="text" value="4.0" title="Yearly interest rate as percent. Example: 3.0 for 3% interest rate" name="loanRate" size="8"><br>';
   amess+='<li>Appreciation rate: <input type="text" value="1.0" title="Yearly apprecation rate in property price rate as percent. Example: 3.0 for 3% interest rate" name="apprecationRate" size="8"><br>';
   amess+='<li><input type="button" value="Show payment schedule" onClick="specifyLoanSchedule2(this)" data-aname="'+aname+'"  ';
   amess+=  ' data-price="'+aprice+'"  > ';
   amess+='</ul>';
   amess+='<b>Notes:</b>';
   amess+='<menu class="tighterMenu">';
   amess+='<li> If this is a refinance, or you are paying less than market value: the loan can be less than the <tt>price</tt>. Or you may pay part of the price with a downpayment.' ;
   amess+='<li>The <tt>apprecation rate</tt> should be a percent -- say, 3.1 for 3.1% ... and it can be less than 0).<br> It is used to display the trend in the yearly price of the property. ';
   amess+='</menu>';
   amess+='</div>';

   displayStatusMessage(amess);
   toggleStatusDiv(0,2);       // makt it big


}
//================
// calc a loan
function specifyLoanSchedule2(athis) {
   let ethis=wsurvey.argJquery(athis);
   let etr=ethis.closest('.loanSpecsBox');
   let aname=ethis.attr('data-aname');
   let aprice=ethis.attr('data-price');

   let eamount=etr.find('[name="loanAmt"]');
     let amount0=  eamount.val() ;
     let amount=fixNumberValue(amount0);

   let eterm=etr.find('[name="loanTerm"]');
     let aterm0=  eterm.val() ;
     let aterm=fixNumberValue(aterm0);

   let erate=etr.find('[name="loanRate"]');
     let arate0=  erate.val() ;
     let arate=fixNumberValue(arate0);

   let eappr=etr.find('[name="apprecationRate"]');
     let appr0=  eappr.val() ;
     let appr=fixNumberValue(appr0);

   if (aterm===false || arate===false ||   amount===false || appr===false)  {
       alert('Please enter a numeric value for the loan amount ('+amount0+'), term ('+aterm0+'), interest rate ('+arate0+'), and appreciaton rate ('+appr0+') ');
       return 0;
   }

  let amess='For <u>'+aname+'</u>: price='+wsurvey.addComma(aprice)+'   : loan size='+wsurvey.addComma(amount);
  amess+='<br>Loan amount='+wsurvey.addComma(amount)+' :  <tt>'+aterm+'</tt> years @ <tt>'+arate.toFixed(2)+' %</tt>';

  let oof=figLoanSchedule(amount,aterm,arate);
  let monthPay=oof[0];
  let yearPay=monthPay*12;
  let schedule=oof[1];

  let len1= oof[1].length-1 ;

  let oof2=[];
  let cumPrincipal=0,cumInterest=0,wasCum;

  let apprUse=1+(appr/100);
  let price1=aprice;
  for (let iyear=1;iyear<1000000;iyear++) {
    let istart=(iyear-1)*12;
    if (istart>=schedule.length) break;
    for (let ii=0;ii<12;ii++) {
       let iuse=istart+ii;
       cumPrincipal+=schedule[iuse][1];
       cumInterest+=schedule[iuse][2];
    }
    let owed=amount-cumPrincipal ;
     price1=price1*apprUse ;
    let netSale=price1-owed;
    let oink={'cumInterest':cumInterest,'cumPrincipal':cumPrincipal,'owed':owed,'price':price1,'netSale':netSale  };
    oof2[iyear]=oink;

  }                           // [i][endOfYear#,princPaidMonth,interestPaindM

    amess+='<br><em>Yearly status of loan (end of year cumulative amounts)</em> ';
  let mtable='<table cellpadding="3">';
  mtable+='<tr bgcolor="#cfefde"><td>Year</td><th>Owned</th><th>Remaining<br>debt</th><th>interest<br>payments</th><th>appreciated<br>Price</th><th>netSale</th></tr>';
  for (let ioof=1;ioof<oof2.length;ioof++) {
     let aoof=oof2[ioof];
     let aprinc=wsurvey.makeNumberK(parseInt(aoof['cumPrincipal']),20000);
     let aowed=wsurvey.makeNumberK(parseInt(aoof['owed']),20000);
     if (aowed<0.1) aowed=0

     let bprice=wsurvey.makeNumberK(parseInt(aoof['price']),20000);
     let bnetSale=wsurvey.makeNumberK(parseInt(aoof['netSale']),20000);

     let aint=wsurvey.makeNumberK(parseInt(aoof['cumInterest']),20000);
     mtable+='<tr><td>'+ioof+'</td><td>'+aprinc+'</td><td>'+aowed +'</td><td>'+aint +' </td><td>'+bprice+'</td><td>'+bnetSale+'</td></tr>';
  }
  mtable+='</table>';
  amess+=mtable;

 
  displayStatusMessage(amess);
}



//=========================
// compute [monthly payment,  schedule]
// schedule is a matrix, each row being [month#,principalPaidThisMonth,interestPaidThisMonth,cumulativePrincipalPaid]
// (assuming payment occurs at end of month)

function figLoanSchedule(loanAmt,termYears,intrYear )  {

  var bpayment=0,nmonths,pwas,cumPrinc,pPaid,pInt,sline,schedule=[];

  bpayment=montlyLoanAmount(loanAmt,termYears,intrYear) ;
  nmonths=termYears*12 ;
  pwas=0 ;

  for (im=1;im<=nmonths;im++) {
     cumPrinc=principalPaid(loanAmt,bpayment,intrYear,im) ;
     pPaid=cumPrinc-pwas ;
     pInt=bpayment-pPaid ;
     pwas=cumPrinc;

     sline=[im,pPaid,pInt,cumPrinc];
     schedule.push(sline);
  }

  return [bpayment,schedule] ;
}



//=========================
// loan calc functions
///============================
// monthly loan amount calculator
// princ: original loan amount (i.e. 100000 for 100k loan
// termYears : # of years of loan (i.e.; 15 if a 15 year loan with monthly payments)
// intrYear: interest rate as a percent.  (i.e.; 3.1 means 3.1%
//=========================
//http://www.wikihow.com/Calculate-Loan-Payments
function montlyLoanAmount(princ,termYears,intrYear) {

var term=termYears * 12;

// special case: 0 % interset
if (intrYear == 0) {
    intr=0;
    avalue=princ/(termYears*12) ;  // monntly payment
    return avalue;
}
// non 0 % loan

var intr=intrYear/1200 ;   // divide by 100 to convert pct to decimal value (and divide by 12 to convert yearly to monthly rate)

var avalue = princ * intr / (1 - (Math.pow(1/(1 + intr), term)));
return avalue;

}

//===============
// http://www.financeformulas.net/Remaining_Balance_Formula.html
// princiapl paid on loan, after n months (given original amount, interest rate, and monthly payment
// you can use monthlyLoanAmount to compute monthly payment (given origional principal, term (# months of loan), and yearly interst rate
function principalPaid(originalAmt,payment,intrYear,nmonths) {

  var m1,m2,m3,v1,v2,v2a ;
  var intr=intrYear/1200 ;   // divide by 100 to convert pct to decimal value (and divide by 12 to convert yearly to monthly rate)

// special case: 0% interest
  if (intrYear==0) {
    return nmonths*payment;
  }

  m1=Math.pow(1+intr,nmonths);
  v1=originalAmt*m1;

  v2a=(m1-1)/intr;
  v2=payment*v2a ;

  v3=v1-v2 ;
  return  originalAmt-v3;
}

//=======================
// view loan specs (call from specifying a property input cell on the  portfolio init page)

function specifyLoanScheduleB(athis) {
  let ethis=wsurvey.argJquery(athis);
  let ebox=ethis.closest('[name="loanSpecs"]');

  let ename=ebox.find('[name="portfolioLoanName"]');
  let aname=ename.val();

  let etable=$('#portfolioHistory1');

//  let assetValuesCurrent=etable.data('assetValuesCurrent');  // 14 july 2023: assetValuesCurrent is now a global
  let use1=assetValuesCurrent[aname];

  let aprice= use1[4]['salePrice'] ;  // hidden will be a number

  let amount ;
  let eamount=ebox.find('[name="portfolioLoanAmount"]');
  let amount0= eamount.val() ;
  if (amount0.substr(amount0.length-1,1)=='%') {
        amount=amount0.substr(0,amount0.length-1);
        amount=fixNumberValue(amount);
        if (amount!==false) amount=(amount/100)*aprice;
     } else {
        amount=fixNumberValue(amount0);
     }

  let erate=ebox.find('[name="portfolioLoanRate"]');
     let arate0=  erate.val() ;
     let arate=fixNumberValue(arate0);

  let eterm=ebox.find('[name="portfolioLoanTerm"]');
     let aterm0=  eterm.val() ;
     let aterm=fixNumberValue(aterm0);

   if (aterm===false || arate===false ||   amount===false  )  {
       alert('Please enter a numeric value for the loan amount ('+amount0+'), term ('+aterm0+'), and interest rate ('+arate0+')  ');
       return 0;
   }

   let ededuct=ebox.find('[name="portfolioLoanTaxDeductInt"]');
   let aDeduct= (ededuct.prop('checked')) ? 1  : 0 ;

  let amess='For... loan amount='+wsurvey.addComma(amount)+' :  <tt>'+aterm+'</tt> years @ <tt>'+arate.toFixed(2)+' %</tt>';

  let oof=figLoanSchedule(amount,aterm,arate);
  let aLoanSchedule1=figLoanSchedule_cum(oof,amount) ;
  let aLoanSchedule=figLoanSchedule_cumAT(aLoanSchedule1,aDeduct,taxRate)  ; // taxRate is global

  let monthPay=aLoanSchedule['monthPay'];
  let yearPay=aLoanSchedule['yearPay'];
  amess+=' :: Monthly payment='+monthPay.toFixed(2)+' , yearly='+yearPay.toFixed(0) ;

  amess+='<br><em>Yearly status of loan (end of year cumulative amounts)</em> ';
  let mtable='<table cellpadding="3">';
  mtable+='<tr bgcolor="#cfefde"><td>Year</td><th>Owned</th><th>Remaining<br>debt</th><th>interest payments</th><th> ...interest<br>payments<br>after tax deduction</tr>';
  for (let ioof=1;ioof<aLoanSchedule['cumYear'].length;ioof++) {
     let aoof=aLoanSchedule['cumYear'][ioof];
     let aprinc=wsurvey.makeNumberK(parseInt(aoof['cumPrincipal']),20000);
     let aowed=wsurvey.makeNumberK(parseInt(aoof['owed']),20000);
     if (aowed<0.1) aowed=0
     let aint=wsurvey.makeNumberK(parseInt(aoof['cumInterest']),20000);
     let aintAT=wsurvey.makeNumberK(parseInt(aoof['cumInterestAT']),20000);

     mtable+='<tr><td>'+ioof+'</td><td>'+aprinc+'</td><td>'+aowed +'</td><td>'+aint +' </td><td>'+aintAT +' </td></tr>';

  }
  mtable+='</table>';
  amess+=mtable;


  displayStatusMessage(amess);
}

//==================
// running sums from a a loan schedule generated by   figLoanSchedule
function figLoanSchedule_cum(aschedule,loanAmount,startDateStamp) {

  if (arguments.length<3) startDateStamp=false;
  let useStartDate=startDateStamp,month1_dateStamp=0 ;
  let cumMonth,cumYear=[];
  if (useStartDate!==false) {
       let oof2=setEntryDate(useStartDate)  ;
       let ayear=oof2['year'];
       let amonth=oof2['month'];
       let aday=oof2['day'];
       let oof3=setEntryDate(ayear,amonth,24);    // pay near end of month, could be  before acquistion date... wth, it's just one payment
       useStartDate=oof3['dayCount'];
       month1_dateStamp= useStartDate ;
       cumMonth={};
  } else {
     cumMonth=[];
  }

  let monthPay=aschedule[0];
  let yearPay=monthPay*12;

  let schedule0=aschedule[1];
  let len1= schedule0.length-1 ;

  let cumPrincipal=0,cumInterest=0   ;
  let oink;
  for (let iyear=0;iyear<1000000;iyear++) {
   let istart=(iyear)*12;
    if (istart>=schedule0.length) break;  // no more to do
    for (let ii=0;ii<12;ii++) {
       let iuse=istart+ii;
       cumPrincipal+=schedule0[iuse][1];   // principal payment this month
       cumInterest+=schedule0[iuse][2];     // interest payment this mont
       let owed=loanAmount-cumPrincipal ;
       oink={'cumInterest':cumInterest,'cumPrincipal':cumPrincipal,'owed':owed    };
       if (startDateStamp===false) {
            cumMonth[iuse]=oink;               // payment at end of month i (i=0 is first month)
       } else {
            let oof2=setEntryDate(useStartDate)  ;
            oink['sayDate']=oof2['sayDate'];
            oink['nMonth']=iuse;
            cumMonth[useStartDate]=oink;
            let useStartDate3=useStartDate+31 ;  // pay in "next month"
            let oof3=setEntryDate(useStartDate3)  ;
            ayear=oof3['year'];
            amonth=oof3['month'];
            aday=oof3['day'];
            let oof4=setEntryDate(ayear,amonth,1);
             useStartDate=oof4['dayCount'];       // the date of next payment

         }
    }
    cumYear[iyear]=oink;                 // payment at end of year i (i=0 is first year)

  }
  
  amonthPay_int=cumMonth[month1_dateStamp]['cumInterest'];
  amonthPay_intAT= amonthPay_int ;
  amonthPay_prin=cumMonth[month1_dateStamp]['cumPrincipal'];


  return {'monthPay':monthPay,'yearPay':yearPay,'cumYear':cumYear,'cumMonth':cumMonth,
       'month1_dateStamp':month1_dateStamp,'month1_intAT':amonthPay_intAT,'month1_int':amonthPay_int,'month1_prin':amonthPay_prin} ;

}

//=================
// add "tax deductible mortgate" to output of figLoanSchedule_cum
function figLoanSchedule_cumAT(aLoanSchedule0,isTaxDeduct,taxRate)  {
// add in "after tax deduction" cumInterest
  for (let ii in  aLoanSchedule0['cumYear'] ) {
     let aint=aLoanSchedule0['cumYear'][ii]['cumInterest'];
     if (isTaxDeduct==0) {
        aLoanSchedule0['cumYear'][ii]['cumInterestAT']= aint;
        continue;
     }
     let aintAT=aint*(1-taxRate);
     aLoanSchedule0['cumYear'][ii]['cumInterestAT']= aintAT ;
  }
  let i0=0;
  for (let ii  in  aLoanSchedule0['cumMonth']) {
     i0++ ;
     let aint=aLoanSchedule0['cumMonth'][ii]['cumInterest'];
     if (isTaxDeduct==0) {
        aLoanSchedule0['cumMonth'][ii]['cumInterestAT']= aint ;
        continue;
     }
     let aintAT=aint*(1-taxRate);
     aLoanSchedule0['cumMonth'][ii]['cumInterestAT']= aintAT ;
     if (i0==1)  aLoanSchedule0['month1_intAT']= aintAT;
  }

  return  aLoanSchedule0 ;
}

//============
// compute loan stats -- between two datees. Return false if no loan for this portfolio/date/asset
function computeLoanStanding(pname,dateStampEntry,zasset,date0,date1) {
  
    if (!portfolioLoans.hasOwnProperty(pname)) return false;
    if (!portfolioLoans[pname].hasOwnProperty(dateStampEntry)) return false;
    if (!portfolioLoans[pname][dateStampEntry].hasOwnProperty(zasset)) return false;
    if (date1<date0) return false ;

    let dates=portfolioLoans[pname][dateStampEntry][zasset]['loanPaymentsDates'];
    let payments=portfolioLoans[pname][dateStampEntry][zasset]['loanPayments'];
    let loanAmount=portfolioLoans[pname][dateStampEntry][zasset]['loanSchedule']['amount']

    if (date1<dates[0]) return false ;    // before start of loan for this portfolio/entry/asset

    let  gIntpay0,gPrinpay0,gIntpay0AT,loanOwed0,gIntpay1,gPrinpay1,gIntpay1AT,loanOwed1 ;
    let loanPaidTotalAt,loanPaidTotal;

// cum info for date0
    let ause;
    for (let jj=dates.length-1;jj>=0;jj--) {
          let adate=dates[jj];
          ause=false;
          if (date0>adate) {        // this is the entry just before ... so use it
                ause=payments[adate] ;
                gIntpay0=ause['cumInterest'];
                gPrinpay0=ause['cumPrincipal'];
                gIntpay0AT=ause['cumInterestAT'];
                loanOwed0=ause['owed'];         // use this as is (no need to adjust using ba
                break;
          }      date0   > adate
    }   // for
    if (ause===false) {        // nothing paid yet
           let jdate=dates[0];
           let ause1=payments[jdate] ;
           gIntpay0=0;
           gPrinpay0=0;
           gIntpay0AT=0;
           loanOwed0=loanAmount;         // use this as is (no need to adjust using ba
    }

    for (let jj=dates.length-1;jj>=0;jj--) {
           let adate=dates[jj];
           if (date1>adate) {        // this is the entry just before ... so use it
              let ause=payments[adate] ; ;
              gIntpay1=ause['cumInterest'];
              gPrinpay1=ause['cumPrincipal'];
              loanPaidTotal=gIntpay1+gPrinpay1;
              gIntpay1AT=ause['cumInterestAT'];
              loanPaidTotalAT=gIntpay1AT+gPrinpay1;
              loanOwed1=ause['owed'];         // use this as is (no need to adjust using ba
              break;
         }     //> adate
    }            // for


    let interestPaidPeriod=gIntpay1-gIntpay0;
    let interestPaidPeriodAT= gIntpay1AT - gIntpay0AT ;

    let principalPaidPeriod= gPrinpay1-gPrinpay0 ;

    let loanPaidPeriod= principalPaidPeriod+interestPaidPeriod ;
    let loanPaidPeriodAT= principalPaidPeriod+interestPaidPeriodAT ;

    let loanTaxDeductValue=interestPaidPeriod-interestPaidPeriodAT ;
    return {'interestPaidPeriod':interestPaidPeriod,'interestPaidPeriodAT':interestPaidPeriodAT,'principalPaidPeriod':principalPaidPeriod,
                 'loanPaidPeriod':loanPaidPeriod,'loanPaidPeriodAT':loanPaidPeriodAT,'loanTaxDeductValue':loanTaxDeductValue,
                 'loanOwedStart':loanOwed0,'loanOwedEnd':loanOwed1,
                 'loanPaidTotal':loanPaidTotal, 'loanPaidTotalAT':loanPaidTotalAT,
                 'loanAmount':loanAmount,'date0':date0,'date1':date1};

}

//=======================
// view loan specs (click handler for Loan button on a portoflio menu

function specifyLoanScheduleC(athis,loanMess) {
  if (arguments.length<2) loanMess=false;

  let ethis=wsurvey.argJquery(athis);
   let amess='';
 let noYes=['No','Yes'];
  let loanAmount=parseFloat(ethis.attr('data-amount'));
  let loanTerm=parseInt(ethis.attr('data-term'));
  let loanRate=parseFloat(ethis.attr('data-rate'));
  let isTaxDed=parseInt(ethis.attr('data-taxDed'));
  let startDate=ethis.attr('data-start');

  let oofD=setEntryDate(startDate);
  let startDateSay=oofD['sayDate'];

  let zasset=ethis.attr('data-asset') ;

  let oof=figLoanSchedule(loanAmount,loanTerm,loanRate);    // month#,principalPaidThisMonth,interestPaidThisMonth,cumulativePrincipalPaid
  let aLoanSchedule1=figLoanSchedule_cum(oof,loanAmount) ;
  let aLoanSchedule=figLoanSchedule_cumAT(aLoanSchedule1,isTaxDed,taxRate)  ; // taxRate is global

  let sayAmount= wsurvey.makeNumberK(loanAmount,10000000,2) ;
    amess+='<br><b>'+zasset+'</b> loan status (start date: '+startDateSay+'). ';
    let monthPay=parseInt(aLoanSchedule['monthPay']), yearPay=parseInt(aLoanSchedule['yearPay']);
    amess+='<span title="yearly payment: '+yearPay+'">Monthly payment: '+wsurvey.addComma(monthPay)+' </span> ';
    if (loanMess!==false) amess+='<span style="font-style:oblique;margin:3px 1em 3px 1em">'+loanMess+'</span>';


    amess+='<br>Starting amount=<tt>'+sayAmount+'</tt></em> ';
    amess+='| Rate='+loanRate.toFixed(1)+' | Term='+loanTerm + '| tax deductible interest='+noYes[isTaxDed];

   amess+='<div style="border-top:1px solid green;font-style:oblique">end of year cumulative amounts</div>'
  let mtable='<table cellpadding="3">';
  mtable+='<tr bgcolor="#cfefde"><td>Year</td><th>Owned</th><th>Remaining<br>debt</th><th>interest payments</th><th> ...interest<br>payments<br>after tax deduction</tr>';
  for (let ioof=0;ioof<aLoanSchedule['cumYear'].length;ioof++) {
     let aoof=aLoanSchedule['cumYear'][ioof];
     let aprinc=wsurvey.makeNumberK(parseInt(aoof['cumPrincipal']),20000);
     let aowed=wsurvey.makeNumberK(parseInt(aoof['owed']),20000);
     if (aowed<0.1) aowed=0
     let aint=wsurvey.makeNumberK(parseInt(aoof['cumInterest']),20000);
     let aintAT=wsurvey.makeNumberK(parseInt(aoof['cumInterestAT']),20000);
      let ioof2=ioof+1;
     mtable+='<tr><td>'+ioof2+'</td><td>'+aprinc+'</td><td>'+aowed +'</td><td>'+aint +' </td><td>'+aintAT +' </td></tr>';

  }
  mtable+='</table>';
  amess+=mtable;


  displayStatusMessage(amess);
}

//==============
// refinance a loan
function portfolio_loanRefinance(athis) {

  let ethis=wsurvey.argJquery(athis);
  let amess='';
   let noYes=['No','Yes'];
  let loanAmount=parseFloat(ethis.attr('data-amount'));
  let loanOwed=parseFloat(ethis.attr('data-owed'));

  let loanTerm=parseInt(ethis.attr('data-term'));
  let loanRate=parseFloat(ethis.attr('data-rate'));
  let isTaxDed=parseInt(ethis.attr('data-taxDed'));

  let zasset=ethis.attr('data-asset');


  amess+=' <button title="Tips" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueRefinance">&#10068;</button>';

  amess+='<b>'+zasset+'</b>: current balance: <tt>'+wsurvey.addComma(parseInt(loanOwed))+ '</tt> (original amount=<tt>'+wsurvey.addComma(loanAmount)+'</tt>)';
  amess+='<br>Current: Rate='+loanRate.toFixed(1)+' |  Term='+loanTerm+' | taxDeductible interest payments: '+noYes[isTaxDed];
  amess+='<div name="newLoanMenu">';
  amess+='<ul class="tightMenu">';
  amess+='<li>Costs: <input type="text" size="6" name="newCosts" value="0" >';
  amess+='<input type="hidden" value="'+zasset+'" name="assetName" >';
  amess+=' | New amount: <input type="text" size="6" name="newAmount" value="'+loanOwed.toFixed(0)+'" > ';
  amess+='<li>';
  amess+=' New term: <input type="text" size="6" name="newTerm" value="'+loanTerm+'" >';
  amess+= ' &nbsp;| &nbsp; ';
  amess+='   &nbsp; |&nbsp;  New rate: <input type="text" size="6" name="newRate" value="'+loanRate.toFixed(1)+'" >';
  amess+='<label>';
  if (isTaxDed==1) {
    amess+='&nbsp; |&nbsp;  Tax Deductible? <input type="checkbox"checked  name="newTaxDed" value="1" >';
  } else {
    amess+='&nbsp; |&nbsp;<label> Tax Deductible?: <input type="checkbox"   name="newTaxDed" value="0" > ';
  }
  amess+='</label>';

  amess+='<li><input type="button" onClick="portfolio_loanRefinance2(this)" value="Step 2 of 3: Preview this loan " >';
  amess+='</ul>';
  amess+='</div>';

  displayStatusMessage(amess);

}

//=============
// new loan specs submitted
function portfolio_loanRefinance2(athis) {
  
  let ethis=wsurvey.argJquery(athis);
  let ediv=ethis.closest('[name="newLoanMenu"]');
     let noYes=['No','Yes'];
   let amess='';

   let ename=ediv.find('[name="assetName"]');
   let aname=ename.val();

   let e0=ediv.find('[name="newCosts"]');
   let newCosts0=e0.val();
   let newCosts=portfolioCalcValueMenu_readVal(newCosts0,false,1,'newCosts');
   if (newCosts===false || isNaN(newCosts)) return 0;

   let e1=ediv.find('[name="newAmount"]');
   let newAmount0=e1.val();
   let newAmount=portfolioCalcValueMenu_readVal(newAmount0,false,1,'newAmount');
   if (newAmount===false || isNaN(newAmount) ) return 0;

   let e2=ediv.find('[name="newRate"]');
   let newRate0=e2.val();
   let newRate=portfolioCalcValueMenu_readVal(newRate0,false,1,'newRate');
   if (newRate===false || isNaN(newRate) ) return 0;

   let e3=ediv.find('[name="newTerm"]');
   let newTerm0=e3.val();
   let newTerm=portfolioCalcValueMenu_readVal(newTerm0,false,1,'newTerm');
   if (newTerm===false  || isNaN(newTerm)  ) return 0;

   let  e4=ediv.find('[name="newTaxDed"]');
   let newTaxDed= (e4.prop('checked')) ? 1 : 0 ;


  let oof=figLoanSchedule(newAmount,newTerm,newRate);
  let aLoanSchedule1=figLoanSchedule_cum(oof,newAmount) ;
  let aLoanSchedule=figLoanSchedule_cumAT(aLoanSchedule1,newTaxDed,taxRate)  ; // taxRate is global

  let sayAmount= wsurvey.makeNumberK(newAmount,10000000,0) ;
    amess+='<input type="button" value="Step 3 of 3: Use this loan!" onClick="portfolio_loanRefinance3(this)"  data-asset="'+aname+'"  ' ;
    amess+='  data-amount="'+newAmount+'" data-term="'+newTerm+'" data-rate="'+newRate+'"  data-taxDed="'+newTaxDed+'" data-cost="'+newCosts+'"> ';
    amess+='<b>'+aname+'</b>: new loan amount=<tt>'+sayAmount+'</tt></em>&nbsp; ';
    let monthPay=parseInt(aLoanSchedule['monthPay']), yearPay=parseInt(aLoanSchedule['yearPay']);
    amess+='<span title="yearly payment: '+yearPay+'">Monthly payment: '+wsurvey.addComma(monthPay)+' </span> ';

    amess+='<br> &nbsp; Cost= '+newCosts.toFixed(0) ;
    amess+='&nbsp;| &nbsp; Rate= '+newRate.toFixed(1)+' &nbsp;| &nbsp; Term= '+newTerm + '&nbsp; | &nbsp; tax deductible interest='+noYes[newTaxDed];

  let mtable='<table cellpadding="3">';
  mtable+='<tr bgcolor="#cfefde"><td>Year</td><th>Owned</th><th>Remaining<br>debt</th><th>interest payments</th><th> ...interest<br>payments<br>after tax deduction</tr>';
  for (let ioof=0;ioof<aLoanSchedule['cumYear'].length;ioof++) {
     let aoof=aLoanSchedule['cumYear'][ioof];
     let aprinc=wsurvey.makeNumberK(parseInt(aoof['cumPrincipal']),20000);
     let aowed=wsurvey.makeNumberK(parseInt(aoof['owed']),20000);
     if (aowed<0.1) aowed=0
     let aint=wsurvey.makeNumberK(parseInt(aoof['cumInterest']),20000);
     let aintAT=wsurvey.makeNumberK(parseInt(aoof['cumInterestAT']),20000);
     let ioof2=ioof+1;
     mtable+='<tr><td>'+ioof2+'</td><td>'+aprinc+'</td><td>'+aowed +'</td><td>'+aint +' </td><td>'+aintAT +' </td></tr>';

  }
  mtable+='</table>';
  amess+=mtable;


  displayStatusMessage(amess);


}
// final step in saving new loan
function portfolio_loanRefinance3(athis) {
     let ethis=wsurvey.argJquery(athis);
  let aname=ethis.attr('data-asset');
  let cost=parseFloat(ethis.attr('data-cost'));
  let loanAmount=parseFloat(ethis.attr('data-amount'));
  let loanTerm=parseInt(ethis.attr('data-term'));
  let loanRate=parseFloat(ethis.attr('data-rate'));
  let isTaxDed=parseInt(ethis.attr('data-taxDed'));
  
  let etable=$('#portfolioHistory1');
  let eassets=etable.find('[name="portfolioAsset"]');
  let e1=eassets.filter('[data-orig="'+aname+'"]');

  let etr=e1.closest('.portfolioHistoryRow');
  let eDiv=etr.find('[name="loanInfoDiv"]');


  let eamount=eDiv.find('[name="portfolioLoanAmount"]');
  eamount.val(loanAmount);
  eamount.attr('type','text');

  let eterm=eDiv.find('[name="portfolioLoanTerm"]');
  eterm.val(loanTerm);
  eterm.attr('type','text');

  let erate=eDiv.find('[name="portfolioLoanRate"]');
  erate.val(loanRate.toFixed(1));
  erate.attr('type','text');

  let etax=eDiv.find('[name="portfolioTaxDeduct"]');
  etax.val(isTaxDed);

  let eLcost=eDiv.find('[name="portfolioRefiCost"]');
  eLcost.val(cost);
  eLcost.attr('type','text');

  let erefi=eDiv.find('[name="portfolioLoanRefinance"]');
  erefi.val(1);


  let evu=eDiv.find('[name="portfolioLoan_currentSpecs"]')
//  evu.css({'opacity':0.5,'font-size':'70%'});
  evu.addClass('cLoanSpecsRefi');
  evu.attr('title','These will be replaced by the refinance terms ');

  displayStatusMessage(false);

}