// grow porfolios, etc

//===============================
// Called by      showModifyPortfolio_step2 -- "grow" a "existing asset mix"" -- given a new date.
//  Which "existing asset mix" to used is set by the ithUse parameter ...
// ithUsed is calculated via a  backward search in in portfolioModifications
//    If 0, use the portfolioInit entry.
// returns modEntry -- that contans the "grown" version of the "existing asset mix"

// called from makeViewPortfolio: growPortfolio(pname,ithUse,closestStamp,aviewDate,1);

function growPortfolio(pname,ithUse,priorStamp,modStamp,noDel)  {

   let baseEntry;
   let growDays=parseInt(modStamp)-parseInt(priorStamp);
   if (growDays<=0)  {
       alert('Error in growPortofolio: growDays ('+growDays+') must be >0 ');
       return false ;           // should never happen   -- note that "changing" an existing modification will first grow the prior one -- so growdays will be > 0
   }

  if (typeof(ithUse)=='object') {    // used by makePortfolioModify
      baseEntry=ithUse ;
  } else {
     if (ithUse==0)   {  // the initializaton
       baseEntry=portfolioInit[pname];
     } else {
       baseEntry=portfolioModifications[pname]['list'][priorStamp];     // use the dateStamp, not ithUse, as the index
     }
  }

  let modEntry= JSON.parse(JSON.stringify(baseEntry));  // start with close of base, and then change...
   modEntry['growDays']=growDays;

   let baseStartDate=baseEntry['dateStamp'];

   if (baseStartDate!=priorStamp) {               // should NEVER happen
      alert('growPortfolio error: startDate from prior entry ('+baseStartDate+') not as expected ('+priorStamp+')');
      return false;
   }

   let baseStartDateSay=baseEntry['dateStampSay'];
   let  baseTotNetValue=baseEntry['totNetValue'];

//     alert('growPortfolio. in '+pname+' base for '+modStamp+' is: '+baseStartDate+','+baseStartDateSay+', '+baseTotNetValue );

   if (noDel==0) {              //  noDel=0 if "modifiatcion". 1 if "viewing portofolio"
     delete modEntry['changesModify'];     // this is rebuilt later
     delete modEntry['summary'];     // this is rebuilt later
     delete modEntry['changesGrow'];     // this is rebuilt later
     delete modEntry['totalsG'];     // this is rebuilt later
   }
   let cashAsset=parseFloat(baseEntry['cashAsset']) ;

   let cashAssetPrior=cashAsset ;
   let changeCashAsset=0;

   let baseList=baseEntry['assetList'];

   let modList= JSON.parse(JSON.stringify(baseList));  // clone this ;

  let growthStuff=portfolioAssetsGrow(baseEntry,modStamp);          // grow the assets  (in baseEntry, to modStamp date)

   for (let ij=0;ij<modList.length;ij++) {          // make the "list of assets" (suitable for use as input to portfolioCalcValue
           let abase=modList[ij];

           let zasset=abase['name'];

           let  gstuff1=growthStuff['growths'][zasset];

           let aType=abase['assetType'];
           let nshares0=abase['nShares'];
           if (aType==0) {
              modList[ij]['nShares']=parseFloat(gstuff1['modQ']);
              modList[ij]['basis']=parseFloat(modList[ij]['basis'])+parseFloat(gstuff1['earningsAT']);

           }  else  if ( aType==1 || aType==2)  {
              modList[ij]['nShares']=parseFloat(gstuff1['modQ']);
              if (additionsFromCash==1)   changeCashAsset-=gstuff1['additionCost'] ;

           }  else  if ( aType==3)  {
               modList[ij]['loanOwed']=parseFloat(gstuff1['loanOwed']);  // remaining balance
//               modList[ij]['makeLoan']=0 ;            //  NOT a new loan (after growth)
               changeCashAsset+=(parseFloat(gstuff1['earningsAT'])-parseFloat(gstuff1['loanPaidPeriodAT']));    // earningsAT=rent after tax

           }  else  if ( aType==4)  {
               changeCashAsset+=parseFloat(gstuff1['earningsAT']) ;   // income streams
           }
           modList[ij]['loanPayYearly']=baseEntry['assets'][zasset]['loanPayYearly'];     // yearliy loan papyments do not change during growth
           modList[ij]['incomeStart']=baseEntry['assets'][zasset]['incomeStart'];     // year income stream was acquired   does not change during growth

   }

//  modEntryTmp will contains asset values (including income streams)as of modStamp

   let modEntryTmp= portfolioCalcValue(modList,modStamp,pname,1);

 let totCostAfterGrow=0;
 let totNetOwed=0;
 let totLoanPaidPreTax=0;
 let totLoanPaidAT=0;
 let totLoanPayPeriodPreTax=0;
 let totLoanPayPeriodAT=0;
 let totInterestPayPeriodAT=0;

 let totTaxEarnings=0;
 let totTaxCashEarnings=0;

  let totEarningsPreTax=0;
  let totEarningsAT=0;
//  let totRevenuePreTax=0;
  let totRevenueAT=0;

  totRentAT=0;
  totIncomeStreamAT=0;

  let totCostGrowth=0;
  let totAdditions=0;

  let totTaxOnEarnings=0;

  let totLosses_taxImpact=0;
  let totLossForTaxCredit=0;

  let thisGrow={};
  let priorEntryVals={};

// update modEntry with stuff from growth and from modEntryTmp ;

   for (let jj=0;jj<modList.length;jj++) {
      let aModList=modList[jj];                // list of assets used to create tmp1
      let basset=aModList['name'] ;
      let mod1=modEntry['assets'][basset];      // update this
      let gchange1=growthStuff['growths'][basset];      // growth stuff
      let tmp1=modEntryTmp['assets'][basset ];           // portfolioCalc stuff

        thisGrow[basset]={'dq':0,'earningsAT':0,'taxEarnings':0,'loanPaidPeriodAT':0,'additions':0};

        let bb1=baseEntry['assets'][basset];                // saved as "prior values"
        priorEntryVals[basset]={'q':parseFloat(bb1['q']),'value':parseFloat(bb1['value']),
                         'netValue':parseFloat(bb1['netValue']),'cost':parseFloat(bb1['cost']),
                         'price':parseFloat(bb1['price']),'loadOwed':parseFloat(bb1['loanOwed'])};

      let atype=mod1['assetType'];

      if (atype==0) {

         mod1['basis']=aModList['basis'] ;            // calculated above

         mod1['value']=tmp1['value'] ;
         mod1['netValue']=tmp1['netValue'] ;
         mod1['capGains']=tmp1['capGains'] ;                 // calcualted by       portfolioCalcValue
         mod1['price']=tmp1['price'] ;                // calcualted by       portfolioCalcValue
         mod1['taxOnSale']=tmp1['taxOnSale'] ;       // calcualted by       portfolioCalcValue

         let nucost=parseFloat(gchange1['earningsAT']);
         mod1['cost']=parseFloat(mod1['cost'])+nucost;    // original cost + added
         totCostGrowth+=nucost;

         mod1['q']=gchange1['modQ'] ;
         mod1['lossForTaxCredit']=gchange1['lossForTaxCredit'] ;
         mod1['earningsAT']=gchange1['earningsAT'];
         mod1['taxOnEarnings']=gchange1['taxOnEarnings'];

         totEarningsPreTax+=gchange1['earningsPreTax'];
         totEarningsAT+=gchange1['earningsAT'];
         totTaxEarnings+=gchange1['taxOnEarnings'];

         totLossForTaxCredit+= gchange1['lossForTaxCredit'] ; ;

         totCostAfterGrow+= parseFloat(mod1['cost']) ;     // use "prior" cost

         thisGrow[basset]['dq']=gchange1['modQ']-gchange1['baseQ'];
         thisGrow[basset]['earningsAT']=gchange1['earningsAT'] ;
         thisGrow[basset]['taxEarnings']=gchange1['taxOnEarnings'];
         


     } else if (atype==1) {
         mod1['value']=tmp1['value'] ;
         mod1['netValue']=tmp1['netValue'] ;

         let nucost=+parseFloat(gchange1['earningsAT']);
         nucost+=gchange1['additionCost'] ;

         mod1['cost']=parseFloat(mod1['cost'])+nucost;    // original cost + added

         totCostGrowth+=nucost;

         mod1['q']=gchange1['modQ'] ;
         mod1['lossForTaxCredit']=gchange1['lossForTaxCredit'] ;
         mod1['earningsAT']=gchange1['earningsAT'];
         mod1['taxOnEarnings']=gchange1['taxOnEarnings'];

         mod1['addition']=gchange1['additionPeriod'] ;

         totEarningsPreTax+=gchange1['earningsPreTax'];
         totEarningsAT+=gchange1['earningsAT'];
         totTaxEarnings+=gchange1['taxOnEarnings'];
         totLossForTaxCredit+= gchange1['lossForTaxCredit'] ; ;

         totCostAfterGrow+= parseFloat(mod1['cost']) ;     // use "prior" cost
         totAdditions+=gchange1['additionPeriod'] ;

         thisGrow[basset]['dq']=gchange1['modQ']-gchange1['baseQ'];
         thisGrow[basset]['earningsAT']=gchange1['earningsAT'] ;
         thisGrow[basset]['taxEarnings']=gchange1['taxOnEarnings'];
         thisGrow[basset]['additions']=gchange1['additionPeriod'];


     } else if (atype==2) {
         mod1['value']=tmp1['value'] ;
         mod1['netValue']=tmp1['netValue'] ;
         mod1['taxOnSale']=tmp1['taxOnSale'] ;
         mod1['addition']=gchange1['additionPeriod'] ;

         let nucost=+parseFloat(gchange1['earningsAT']);
         nucost+=gchange1['additionCost'] ;

         mod1['cost']=parseFloat(mod1['cost'])+nucost;    // original cost + added
         totCostGrowth+=nucost;

         mod1['q']=gchange1['modQ'] ;
         mod1['lossForTaxCredit']=gchange1['lossForTaxCredit'] ;
         mod1['earningsAT']=gchange1['earningsAT'];
         mod1['taxOnEarnings']=gchange1['taxOnEarnings'];

         totEarningsPreTax+=gchange1['earningsPreTax'];
         totEarningsAT+=gchange1['earningsAT'];
         totTaxEarnings+=gchange1['taxOnEarnings'];    // no tax on earnings.. but wth

         totLossForTaxCredit+= gchange1['lossForTaxCredit'] ; ;

         totCostAfterGrow+= parseFloat(mod1['cost']) ;           // use "prior" cost

         totAdditions+=gchange1['additionPeriod'] ;

         thisGrow[basset]['dq']=gchange1['modQ']-gchange1['baseQ'];
         thisGrow[basset]['earningsAT']=gchange1['earningsAT'] ;
         thisGrow[basset]['taxEarnings']=gchange1['taxOnEarnings'];
         thisGrow[basset]['additions']=gchange1['additionPeriod'];



     } else if (atype==3) {
         mod1['value']=tmp1['value'] ;
         mod1['netValue']=tmp1['netValue'] ;
         mod1['capGains']=tmp1['capGains'] ;                 // calcualted by       portfolioCalcValue
         mod1['price']=tmp1['price'] ;                // calcualted by       portfolioCalcValue
         mod1['taxOnSale']=tmp1['taxOnSale'] ;
         
         mod1['yearlyNetRent']=tmp1['yearlyNetRent'];
         mod1['yearlyRevenue']=tmp1['yearlyNetRent'];

         mod1['basis']=aModList['basis'] ;

         mod1['earningsAT']=gchange1['earningsAT'];
         mod1['earningsPreTax']=gchange1['earningsPreTax'];
         mod1['taxOnEarnings']= mod1['earningsPreTax'] - mod1['earningsPreTax'] ;

         mod1['loanOwed']=gchange1['loanOwed'] ;
         mod1['loanPaid']=gchange1['loanPaidTotal'] ;
         mod1['loanPaidAT']=gchange1['loanPaidTotalAT'] ;
         mod1['loanTaxDeductValue']=gchange1['loanTaxDeductValue'] ;
         mod1['lossForTaxCredit']=gchange1['lossForTaxCredit'] ;

         totNetOwed+=gchange1['loanOwed'] ;
         totLoanPaidPreTax +=gchange1['loanPaidTotal'] ;
         totLoanPaidAT += gchange1['loanPaidTotalAT'] ;

         totEarningsPreTax+=gchange1['earningsPreTax'];
         totEarningsAT+=gchange1['earningsAT'];

         totTaxEarnings+=mod1['taxOnEarnings'];

         totLossForTaxCredit+= gchange1['lossForTaxCredit'] ; ;

         totRevenueAT+=gchange1['changeRevenueAT'];

         totLoanPayPeriodPreTax+= gchange1['loanPaidPeriod'] ;          // loan payments this period
         totLoanPayPeriodAT+= gchange1['loanPaidPeriodAT'] ;
         totInterestPayPeriodAT+= gchange1['loanInterestPeriodAT'] ;

         totCostAfterGrow+= parseFloat(mod1['cost']) ;             // use "prior" cost

         thisGrow[basset]['loanPaidPeriodAT']=gchange1['loanPaidPeriodAT'] ;
         thisGrow[basset]['loanInterestPaidPeriodAT']=gchange1['loanInterestPeriodAT'] ;
         thisGrow[basset]['earningsAT']=gchange1['earningsAT'] ;
         thisGrow[basset]['taxEarnings']=gchange1['taxOnEarnings'];



     } else if (atype==4) {

        mod1['yearlyIncome']=tmp1['yearlyIncome'];
        mod1['yearlyRevenue']=tmp1['yearlyIncome'];

         mod1['taxOnEarnings']=gchange1['taxOnEarnings'] ;
         mod1['lossForTaxCredit']=gchange1['lossForTaxCredit'] ;
         mod1['earningsAT']=gchange1['earningsAT'];

         mod1['yearlyIncome_notAdjusted']= mod1['yearlyIncome']  ;
         if (gchange1['yearlyIncome_adjusted']!==false) mod1['yearlyIncome']=gchange1['yearlyIncome_adjusted'];   //change yearlyIncome if this is a fixed income (with growth)

         totTaxEarnings+=gchange1['taxOnEarnings'];
         totTaxCashEarnings+=gchange1['taxOnEarnings'];

         totEarningsPreTax+=gchange1['earningsPreTax'];
         totEarningsAT+=gchange1['earningsAT'];

         totRevenueAT+=gchange1['changeRevenueAT'];
         totLossForTaxCredit+= gchange1['lossForTaxCredit'] ; ;

         totCostAfterGrow+= parseFloat(mod1['cost']) ;      // use "prior" cost

         thisGrow[basset]['earningsAT']=gchange1['earningsAT'] ;
         thisGrow[basset]['taxEarnings']=gchange1['taxOnEarnings'];

      }
      mod1=modEntry['assets'][basset]=mod1;         // may not be necessary (not a clone)
   }

   modEntry['totals']=modEntryTmp['totals'] ;       // mostly correctl

   modEntry['totals']['totCost']=totCostAfterGrow ;

   modEntry['totals']['totLoanOwed']=totNetOwed ;
   modEntry['totals']['totLoanPaidPreTax']=totLoanPaidPreTax ;
   modEntry['totals']['totLoanPaidAT']=totLoanPaidAT ;

   modEntry['changesGrow']={} ;

   modEntry['changesGrow']['growDays']=growDays ;
   modEntry['changesGrow']['priorStateDate']=baseStartDate ;
   modEntry['changesGrow']['priorStateDateSay']=baseStartDateSay ;

   modEntry['changesGrow']['priorTotNetValue']=baseTotNetValue;  // rewritten below
   modEntry['changesGrow']['totNetValueAfterGrowth']=0;         // rewritten below
 
   modEntry['changesGrow']['totCostGrowth']=totCostGrowth ;

   modEntry['changesGrow']['totAdditions']=totAdditions ;

   modEntry['changesGrow']['totLoanPayPreTax']=totLoanPayPeriodPreTax ;
   modEntry['changesGrow']['totLoanPayAT']=totLoanPayPeriodAT ;
   modEntry['changesGrow']['totLoanInterestPayAT']= totInterestPayPeriodAT ;

   modEntry['changesGrow']['totTaxOnEarnings']=totTaxEarnings ;
   modEntry['changesGrow']['totTaxOnRevenue']=totTaxCashEarnings ;

   modEntry['changesGrow']['totLossForTaxCredit']=totLossForTaxCredit ;


   modEntry['changesGrow']['totEarningsPreTax']=totEarningsPreTax ;      // raw (no interest growth)
   modEntry['changesGrow']['totEarningsAT']=totEarningsAT ;      // raw (no interest growth)

   modEntry['changesGrow']['totRevenueAT']=totRevenueAT ;      // raw (no interest growth)

   modEntry['changesGrow']['list']=thisGrow;      // by asset
   modEntry['changesGrow']['priorEntryVals']=priorEntryVals;      // by asset


// the initial cashAsset (cashAssetPrior) has has changeCashAsset added (or subtracted from it).
// As an approcimation, assume these additions occurred on a "daily" basis, at a constant rate.
// For example: if 10,000 was added over 100 days, then $100 was added
// These additions will grow (become more positive or more negative) as a function of the `Cash` interest rates (>0 and <0 rates)
// Thus: the new cashAsset is a function of the growth of original (at creation date, or existing modification date) and the addtions

//   afterGrowthCashAsset  = priorCashAsset + (bond addtions+ (rentsAT-loanAT) + IncomeAt
//   and an interest is added  using an interpolation between priorCashAsset and afterGrowthCashAsset

  let rawCash=cashAssetPrior+changeCashAsset ;

  let cashAssetGrown=assetGrowth_cash(cashAssetPrior,rawCash,growDays,cashInterest,cashPenalty) ;
  modEntry['cashAssetPrior']=cashAssetPrior;        // includes estimate of interest growth while income, taxes, etc were deposited/withdrawn from Cash

   modEntry['changesGrow']['cashAsset']=cashAssetGrown;
   modEntry['changesGrow']['cashAssetPrior']= cashAssetPrior;
   modEntry['changesGrow']['cashAssetChangeGrow']=changeCashAsset ;      // raw (no interest growth) change in "cash" over this period: cost of bond additions + (rentsAT-loansAT) + incomeStreams
   modEntry['changesGrow']['cashAssetInterestAmount']=cashAssetGrown-rawCash;

   modEntry['assetList']=modList;
   modEntry['comment']='modification: growth to '+modStamp;

   modEntry['dateStamp']=modEntryTmp['dateStamp'];
   modEntry['dateStampSay']=modEntryTmp['dateStampSay'];

   modEntry['totals']=modEntryTmp['totals'] ;
   modEntry['totNetAllEst']=modEntryTmp['totals']['totNetAssetEst']+cashAssetGrown ;   // estimated -- calc_netValues produces a better measure

    modEntry['changesGrow']['totNetValueAfterGrowth']= modEntry['totNetAllEst']  ;

   modEntry['growDays']=growDays ;

   modEntry['cashAsset']=cashAssetGrown ;

  return modEntry ;


}


//=======================
// grow a portfolio, from its starting date to a future date.
function  portfolioAssetsGrow(baseEntry,modStamp) {

    modStamp=parseInt(modStamp);

    let assetsListBase=baseEntry['assetList'];
 
    let baseDateStamp=parseInt(baseEntry['dateStamp']);

    let pname=baseEntry['name'];
    let growDays=modStamp-baseDateStamp ;

    if (growDays==0) return  false    ;         // same day -- so no growth

    let cgrowths={};

    for (let ith=0;ith<assetsListBase.length;ith++)  {

// initialize (not really necessary)
      let agrowth1={'baseQ':0,'modQ':0,
            'changeRevenueAT':0,'taxOnEarnings':0,'lossForTaxCredit':0,
            'netCumRentAT':0,'netCumIncomeAT':0,
            'loanOwed':0,'loanTaxDeductValue':0,'loanInterestPeriodAT':0,
            'loanPaidPeriodAT':0,'loanPayYearly':0,'additionPeriod':0,'additionCost':0
        }

        let aentry=assetsListBase[ith];
        let aname=aentry['name'];
        let incomeStart=(aentry.hasOwnProperty('incomeStart')) ? aentry['incomeStart'] : false ;

        let atype=aentry['assetType'];
        let agrowth ;

// the per share 'growth' , and additions (price, etc not used here)

        let grateBase0=calcAssetValues_2(aname,baseDateStamp,1,incomeStart);
        let grateBase=grateBase0[4];

        let grateMod0=calcAssetValues_2(aname,modStamp,1,incomeStart);
        let grateMod=grateMod0[4];

        let cunk=modStamp-  baseDateStamp

// growth in #shares (or $ dollars) for bonds, taxdeferred bonds, and stocks -- using post tax growth
        let baseQ=parseFloat(assetsListBase[ith]['nShares']);

// actual earnings & tax paid on earnings
        if (atype==0) {
            agrowth=portfolioAssetsGrow_0(aname,baseDateStamp,modStamp,grateBase,grateMod,baseQ)   ;
            agrowth['changeRevenueAT']=0;         // all revenue reinvested

        } else  if (atype==1   ) {

            agrowth=portfolioAssetsGrow_12(aname,baseDateStamp,modStamp,grateBase,grateMod,baseQ,atype)    ;

            agrowth['changeRevenueAT']=0;         // all revenue reinvested

        } else  if (atype==2   ) {
            agrowth=portfolioAssetsGrow_12(aname,baseDateStamp,modStamp,grateBase,grateMod,baseQ,atype)    ;
            agrowth['changeRevenueAT']=0;         // all revenue reinvested

        } else if (atype==3) {

            modQ=1; baseQ=1 ;

            agrowth=portfolioAssetsGrow_34(aname,baseDateStamp,modStamp,grateBase,grateMod,baseQ)  ;

            agrowth['changeRevenueAT']=agrowth['earningsAT'] ;       // earnings from netRent (lower bound of 0)
            
            aLoanStart=baseEntry['assets'][aname]['loanSchedule']['startDate'];
           let loanInfo=computeLoanStanding(pname,aLoanStart,aname,baseDateStamp,modStamp);

           if (loanInfo!==false) {
              agrowth['loanOwed']=loanInfo['loanOwedEnd'];
              agrowth['loanPrincipalPeriod'] =loanInfo['principalPaidPeriod'];
              agrowth['loanInterestPeriod']=loanInfo['interestPaidPeriod'];
              agrowth['loanInterestPeriodAT']=loanInfo['interestPaidPeriodAT'];
              agrowth['loanPaidPeriod']=loanInfo['loanPaidPeriod'];
              agrowth['loanPaidPeriodAT']=loanInfo['loanPaidPeriodAT'];
              agrowth['loanPaidTotal'] = loanInfo['loanPaidTotal'];
              agrowth['loanPaidTotalAT'] = loanInfo['loanPaidTotalAT'];
              agrowth['loanTaxDeductValue'] =loanInfo['loanTaxDeductValue'];  ;
           }

       } else if (atype==4) {
            let startIncome=(baseEntry['assets'][aname].hasOwnProperty('incomeStart')) ?  baseEntry['assets'][aname]['incomeStart'] : false;
            if (startIncome=='false') startIncome=false;
            agrowth=portfolioAssetsGrow_34(aname,baseDateStamp,modStamp,grateBase,grateMod,baseQ)  ;
            if (startIncome!==false) {
               agrowth['yearlyIncome_adjusted']=grateMod['income'];   // will be "inflation adjusted" if fixedIncome
           } else {
               agrowth['yearlyIncome_adjusted']=false ;   // will be "inflation adjusted" if fixedIncome
           }
            agrowth['changeRevenueAT']=agrowth['earningsAT'] ;       // income recieved
       }

       for (let zza in agrowth) agrowth1[zza]=agrowth[zza];     // copy changes to agrowth1w
       
       cgrowths[aname]=agrowth1 ;


    }  // assetsListBase.length

   return {'growths':cgrowths,'dayGap':growDays,'baseDateStamp':baseDateStamp,'modDateStamp':modStamp }   ;

}


// ==================================================     agrowth
// compute earnings and growth changes
// stock version
function portfolioAssetsGrow_0(aname,baseDateStamp,modStamp,grateBase,grateMod,baseQ) {

//growth
  let gcumBasePreTax=grateBase['growthCum'];             // pre tax earnings and growth
  let gcumModPreTax=grateMod['growthCum'];
  let gperiodRatePreTax=gcumModPreTax/gcumBasePreTax ;     // growth from baseEntry date is retained
  let modQPreTax  = baseQ*gperiodRatePreTax;
  let dSharesPreTax=modQPreTax-baseQ   ;

  let gcumBaseAT=grateBase['growthCumAT'];            // after tax growth
  let gcumModAT=grateMod['growthCumAT'];
  let gperiodRateAT=gcumModAT/gcumBaseAT ;            //  "after tax" values   retained
  let modQAT = baseQ*gperiodRateAT;
  let dSharesAT=modQAT-baseQ   ;

// earnings ... since dividend growth is absolute and drives stock share growth, an approximation is required
// in contrast, for bonds one can use the period growth rate

  let gEarnBasePreTax=grateBase['earningsCum'];     // per share cum earnings
  let gEarnModPreTax=grateMod['earningsCum'];
  let earnPerSharePreTax=gEarnModPreTax-gEarnBasePreTax ;           // earnings per share (starting from base date)
  let earningsPreTax=((dSharesPreTax/2) + baseQ ) *  earnPerSharePreTax;      // 13 June... an approximation --   is best when time gap betweeen base entries is small

  let gEarnBaseAT=grateBase['earningsCumAT'];      // after tax earnings
  let gEarnModAT=grateMod['earningsCumAT'];
  let earnPerShareAT=gEarnModAT-gEarnBaseAT ;      // earnings per share (starting from base date)
  let earningsAT=((dSharesAT/2) + baseQ ) *  earnPerShareAT;      // 13 June... an approximation --   is best when time gap betweeen base entries is small

  let taxOnEarnings=earningsPreTax-earningsAT;

  let taxOffset=0;
  if (earningsPreTax<0) {     // this should nevenr happen (- dividends not allowed)
     if (doAssetLookup(aname,'lossesOffsetIncome')==1) taxOffset=earningsPreTax ;         // can you use losses in one asset to offset other income?
      taxOnEarnings=0;
   }

  let  stuff={'baseQ':baseQ, 'modQ':modQAT,'modQPreTax':modQPreTax,
       'gperiodRateAT':gperiodRateAT,'gperiodRatePreTax':gperiodRatePreTax,
       'earningsAT':earningsAT, 'earningsPreTax':earningsPreTax,
       'taxOnEarnings':taxOnEarnings,'lossForTaxCredit':taxOffset,
       'earnPerShareAT':earnPerShareAT,'earnPerSharePreTax':earnPerSharePreTax
     } ;


  return stuff;
}


// ==================================================
// bond version

function portfolioAssetsGrow_12(aname,baseDateStamp,modStamp,grateBase,grateMod,baseQ,atype) {

  let gcumBasePreTax=grateBase['growthCum'];             // pre tax earnings and growth
  let gcumModPreTax=grateMod['growthCum'];
  let gperiodRatePreTax=gcumModPreTax/gcumBasePreTax ;     // growth from baseEntry date is retained
  let modQPreTax  = baseQ*gperiodRatePreTax;
  let dSharesPreTax=modQPreTax-baseQ   ;
  let earningsPreTax=dSharesPreTax ;

  let gcumBaseAT=grateBase['growthCumAT'];                     // after tax earnings and growth
  let gcumModAT=grateMod['growthCumAT'];
  let gperiodRateAT=gcumModAT/gcumBaseAT ;                   //  "after tax" values   retained
  let modQAT = baseQ*gperiodRateAT;
  let dSharesAT=modQAT-baseQ   ;
  let earningsAT=dSharesAT ;

  let taxOnEarnings=earningsPreTax-earningsAT;

  let taxOffset=0;
  if (earningsPreTax<0) {
     if (doAssetLookup(aname,'lossesOffsetIncome')==1) taxOffset=earningsPreTax ;         // can you use losses in one asset to offset other income?
      taxOnEarnings=0;
   }
   let gAdditionBase=grateBase['additionCum'];     // total additions (not per share)
  let gAdditionMore=grateMod['additionCum'];

  let additionPeriod=gAdditionMore- gAdditionBase ;
  if (modQPreTax+additionPeriod <=0)    {
      additionPeriod=-modQPreTax ;
      modQPreTax=0;
      modQAT=0;
  } else {
      modQPreTax+=additionPeriod ;
      modQAT+=additionPeriod;
      modQPreTax=Math.max(0,modQPreTax);// these are unnecessary, but keep just in case (14 July 2023)
      modQAT=Math.max(0,modQAT);    // - additions can not drive to lt 0
  }

  let additionCost=0;
  if (additionPeriod>0) {
    if (atype==1) {
         additionCost=additionPeriod ;
    } else {
       let ataxRate=calcAsset_taxRate(2,0)  ;
       additionCost=additionPeriod*(1-ataxRate);      // assume pre tax income added (so immediate cost shoudl be net of taxes not paid
    }
  }


  let  stuff={'baseQ':baseQ, 'modQ':modQAT,'modQPreTax':modQPreTax,
       'gperiodRateAT':gperiodRateAT,'gperiodRatePreTax':gperiodRatePreTax,
       'earningsAT':earningsAT, 'earningsPreTax':earningsPreTax,
       'additionPeriod':additionPeriod,'additionCost':additionCost,
       'taxOnEarnings':taxOnEarnings,'lossForTaxCredit':taxOffset
     } ;


  return stuff;
}

//====================       earnings   aname
//  property and incomeSTream version

function portfolioAssetsGrow_34(aname,baseDateStamp,modStamp,grateBase,grateMod,baseQ) {

  let gEarnBasePre=grateBase['earningsCum'];     // per share cum earnings
  let gEarnModPre=grateMod['earningsCum'];
  let earnPre=gEarnModPre-gEarnBasePre ;           // earnings (starting from base date)

  let gEarnBaseAT=grateBase['earningsCumAT'];
  let gEarnModAT=grateMod['earningsCumAT'];
  let earnAT=gEarnModAT-gEarnBaseAT ;           // earnings per share (starting from base date)

  let gTaxBase=grateBase['earningsTaxCum'];
  let gTaxMod=grateMod['earningsTaxCum'];
  let taxOnEarnings=gTaxMod-gTaxBase;
  let taxOffset=0;
  if (earnPre<0) {
     if (doAssetLookup(aname,'lossesOffsetIncome')==1) taxOffset=earnPre ;         // can you use losses in one asset to offset other income?
      taxOnEarnings=0;
   }

  let  stuff={'earningsPreTax':earnPre,'earningsAT':earnAT,
              'taxOnEarnings':taxOnEarnings,'lossForTaxCredit':taxOffset
        } ;
  return stuff;
}


//==================    baseDateStamp     modStamp
// calculate correct net values and taxes
// read earnings from changesGrow
function   calc_netValues(checkEntry ) {

 let totals2={} ;

  let totNetSale=0;
  let totCapGain=0;
  let totTaxDeferredSale=0;
  let totRegularSale=0;
  let totStockSale=0;
  let totPropertyProfit=0;
  let totPropertySale=0;
  let totLosses_taxImpact=0 ;
  let totLossForTaxCredit=0;
  let totEarningsAT_est=0;
  let totTaxOnEarnings=0;



//  Note : earnings occur during growth, sales & purchses happen during modifications

// note: reductions in taxes from losses use an asset specific tax rate ... since increases in taxes (from + earnings) use the same asset specifici tax rate
  for (let zasset in checkEntry['assets']) {

      let aStuff=checkEntry['assets'][zasset];
      atype=aStuff['assetType'];

      let gotGrow=0;
      if (checkEntry.hasOwnProperty('changesGrow')) gotGrow=1

      if (gotGrow==1)   {    // rebuilding (on logon) inits will NOT have changesGrow ..

         if (checkEntry['changesGrow']['list'].hasOwnProperty(zasset)) {     // might of been removed?
            let aTaxOnEarn=  parseFloat(checkEntry['changesGrow']['list'][zasset]['taxEarnings'])  ;    // can not be < 0 (though losses can apper in  totLossForTaxCredit
            let earningsAT = parseFloat(checkEntry['changesGrow']['list'][zasset]['earningsAT'] );

            totEarningsAT_est+=checkEntry['changesGrow']['list'][zasset]['earningsAT'];
            totTaxOnEarnings+= aTaxOnEarn ;

            if (checkEntry['changesGrow']['list'][zasset].hasOwnProperty('lossForTaxCredit')) {
              lossForTaxCredit=Math.abs(checkEntry['changesGrow']['list'][zasset]['lossForTaxCredit']);
              totLossForTaxCredit+= lossForTaxCredit;
              if (lossForTaxCredit!=0)                        {  // will be <0 if a loss occurred  -- so use abs()
                 let ttrate=calcAsset_taxRate(zasset,0) ;
                 totLosses_taxImpact+=lossForTaxCredit*ttrate ;       // reduection in other income taxes paid
              }       // lossfortax credit !=
            }           // has lossForTaxCredit
         }         // has zasset
      }             // got gotGrow

// capgains and other taxes on sale

      if (atype==0)  {               // cap gains
          let aValue=aStuff['value'];
          let abasis=aStuff['basis'];
          totStockSale+=aValue;
          let capGain=calcAsset_capGainsAmount(zasset,aValue,abasis);
          totCapGain+=capGain;

      }
      if (atype==1)  {               // no cap gains, no taxes on liquidation
          let aValue=aStuff['value'];
          totRegularSale+=aValue;
       }
      if (atype==2)  {               // no cap gains,  taxes on liquidation figured on ALL the tax-deferred assets
          let aValue=aStuff['value'];
          totTaxDeferredSale+=aValue;

       }
      if (atype==3)  {               //  cap gains
 
          let aValue=aStuff['value'];

          let abasis=aStuff['basis'];
          let loanOwed=aStuff['loanOwed'];

          let acapGain=calcAsset_capGainsAmount(zasset,aValue,abasis) ;    // cap losses are also effected by "% of gains subject to capital gains"
          let aprofit=aValue-loanOwed;
          totPropertySale+= aValue ;      // used for info purposes
          totPropertyProfit+=aprofit;

          totCapGain+=acapGain;
       }

       if (atype==4) {
 // no changes !
       }

// lossForTaxCredit from any source can reduce taxes (including regular bonds, whose earnings are recycled into more bonds)

  }

  let totAssetSale=totStockSale+totRegularSale+ totTaxDeferredSale+ totPropertyProfit ;    // use property profit, not property sale

  totTaxOnEarnings=totTaxOnEarnings- totLosses_taxImpact;           // totLosses_taxImpact  will be  absoluted

  let cashAsset0=checkEntry['cashAsset'];

  let cashAsset2=cashAsset0+totLosses_taxImpact ;        //  totLosses_taxImpact is abs

  let totCapGainTax=calcAsset_taxAmount('*capgains',totCapGain,1) ;           // sum of all cap gains (all stocks, all properties)
  totCapGainTax=Math.max(0,totCapGainTax);
  let totTaxDeferredTax=calcAsset_taxAmount('*taxdeferred',totTaxDeferredSale,1) ;           // sum of all tax deferred (
  totTaxDeferredTax=Math.max(0,totTaxDeferredTax);
   totalTaxOnSale=totCapGainTax+ totTaxDeferredTax ;

  let totNetAsset= totAssetSale-totalTaxOnSale ;
  totNetValue=totNetAsset+cashAsset2  ;            // actual value: (totAssetSale+cashAsset2)-totalTaxOnSale ; -= taxes computed on cap gains summed across all assets (including negative)
    totals2['totAssetSale']=totAssetSale;
    totals2['totNetValue']=totNetValue;                // not estimated means: calcualtes taxes across all assets, not  one at a time

    totals2['cashAsset']=cashAsset2 ;
    totals2['totNetAsset']=totNetAsset;
    totals2['totTaxSellAll']=totalTaxOnSale;
    totals2['totCapGainTaxSellAll']=totCapGainTax;
    totals2['totTaxDeferredSellAll']=totTaxDeferredTax;     // totTaxDeferredTaxSellAll =totTaxSellAll- totCapGainTaxSellAll
    totals2['totPropertySale']=totPropertySale;
    totals2['totLossForTaxCredit']=totLossForTaxCredit;
    totals2['totLosses_taxImpact']=totLosses_taxImpact;


   return totals2 ;

}        //

