

//=================
// update some sortuse data  in the asset mix menu
// tt is the return from portfolioCalcValueMenu
function  portfolioCalcValueMenu_sortUpdate(tt) {
   let totvalPortfolio=tt['totNetValue'];
   let usevals=tt['assets'];

   let etable=$('#portfolioHistory1AssetRows');
   let etrs=etable.find('.portfolioHistoryRowNew')  ;
   for (let ie=0;ie<etrs.length;ie++) {
       let aetr=$(etrs[ie]);
       let  ename=aetr.find('[name="portfolioAsset"]');
       let aname=ename.val();
       if (!usevals.hasOwnProperty(aname)) continue ; // should never happen
       let a1=usevals[aname];

       let  val=a1['value'];
       let e1=aetr.find('[name="cell_value"]');
       e1.attr('data-_sortuse',val);

       let netVal=a1['netValue'] ;
       let e2=aetr.find('[name="cell_netValue"]');
       e2.attr('data-_sortuse',netVal);

       let apct=val/totvalPortfolio;
       let e3=aetr.find('[name="cell_pct"]');
       e3.attr('data-_sortuse',apct);
   }           // etrs
   return 1;
}


// init portfolio values (blank for all input fields)

function buildPortfolioMenu_reset(athis) {
   let etable=$('#portfolioHistory1');
   let etrs=etable.find('.portfolioHistoryRow');
   for (let ii=0;ii<etrs.length;ii++) {
       let etr=$(etrs[ii]);
       let ec1=etr.find('[name="cell_value"]');
       let einputs=ec1.find('[data-orig]');
       for (let ii2=0;ii2<einputs.length;ii2++) {
          let einput=$(einputs[ii2]);
          let oval=einput.attr('data-orig');
          einput.val(oval);
       }
   }
   return 1;
}


//======================
// show buttons for the view  and modifications, of a portfolio.
// clicking the button displayes an asset mix
// iwhich: 1= show the list, 3: show the list, and open the "modify" menu, 4: view this portfolio button on display viewDates column header


function showPortfolioViewModify(athis,iwhich  ) {

   let ethis=wsurvey.argJquery(athis);
   let pname=ethis.attr('data-name');

   if (!portfolioInit.hasOwnProperty(pname) ) {
      alert('You must initialize the '+pname+' portfolio ');  // should never happen
      return false;
   }

   if (iwhich==4) {
//      wsurvey.wsShow.hide('#mainDiv2');
      iwhich=1;
   }

   let zz=portfolioLookup['list'][pname];
//   wsurvey.dumpObj(portfolioLookup,1,'portfolioLookupin showPortfolioViewModify');

   let nHistory=zz['nHistory'] ;

   let iz=zz['ith'];
   let adesc=portfolioList[iz]['desc'];

   let origBudget=portfolioInit[pname]['original']['budget'];
   let origBudgetSay=numberString=wsurvey.makeNumberK(origBudget,90000,0) ;

   let daNassets=parseInt(portfolioInit[pname]['totals']['nAsset']);
   let daNincome=parseInt(portfolioInit[pname]['totals']['nIncome']);
   let daBoth=daNassets+' &amp; '+daNincome ;
   let totAssetSale=portfolioInit[pname]['totals']['totAssetSale'];
   let totNetAssetEst=portfolioInit[pname]['totals']['totNetAssetEst'];   // estiamted not actula (totals vs totalsG

   let daCreation=portfolioInit[pname]['dateStamp'];
   let daCreationSay=portfolioInit[pname]['dateStampSay'];

   let amess='';
   amess+=' <button   title="Return to list of portfolios" onClick="showPortfolioTable(this)">&#8617;&#65039;</button>  ';
   amess+='<input type="button" value="&neArr;" title="View in a new window"  data-id="mainDiv3" onClick="displayInWindow(this)"> ';
   amess+='<input type="button" value="&#10068;" onClick="displayHelpMessage(this)" data-div="#portfolioAssetMix1"> ';  // help button

   amess+='<button  data-name="'+pname+'" class="cViewSummaryButton" title="Toggle the list of  transactions (sales & purchases in all the modifications)" ';
   amess+='   onClick="showPortfolioViewModify_listMods(this)" data-mode="'+showTransactions+'" data-name="'+pname+'" > ';  //   showTransactions is a global setting
   amess+=' &#129534; </button> ';

   amess+=' <button class="cdoButtonRegular" style="font-size:95%;color:blue" id="valuePortfolioButton2"  ';
   amess+=' title="Display this portfolio`s values using selectedViewDates dates" ';
   amess+='   onclick="showAllPortfolioValuesStart(this,\''+pname+'\')">&#128176; &#11190;</button> ';


// open modify menu button
   amess+=' <button id="idoButtonModify"  class="cdoButtonModify"  onClick="showModifyPortfolio_step1(this)"  ';
   amess+='     title="Create a modification of  this portfolio`s asset mix (as of a future date that you specify)" ';
   amess+='    data-name="'+pname+'" >Modify <u>'+pname+'</u>&#10068;</button> ';

   amess+='<span class="cPortfolioName_t1"  ><em>Portfolio </em> <u>'+pname+'</u></span> <span style="font-size:90%;font-style:oblique" title="Short description">'+adesc+'</span>'

   amess+='<ul id="portfolioModificationsList" class="linearMenu18Pct">';
   amess+='<li style="width:8em"><div style="font-size:90%">Initial budget=<tt>'+origBudgetSay+'</tt>';
   let mdList0=portfolioLookup['list'][pname] ;

   let amodDate0=mdList0['modDates'][0];
   let daNetValue0=mdList0['totNets'][amodDate0];
   daNetValue0Say=wsurvey.makeNumberK(daNetValue0,100000,0);

   let p1say='<button title="The initialization entry ... " onClick="showPortfolioMix(this)" name="whichPortfolio" ';
   p1say+='   data-date="'+daCreation+'" data-nth="0"  data-name="'+pname+'"  >';
   
   p1say+=daCreationSay+'</button>';
   p1say+='<span name="portfolioButton_summary" title="#assets & # incomes"> <em>  '+daBoth+' </span>    | '+daNetValue0Say+' </em> ' ;
   amess+='<li class="notHighlightThisLi">'+p1say;

   for (let jj=1;jj<portfolioLookup['list'][pname]['modDates'].length;jj++) {
      let mdList=portfolioLookup['list'][pname];

      let amodDate=mdList['modDates'][jj];             // totNets [0..]

      let amodDateSay=mdList['modDatesSay'][amodDate];
      let daNetValue=mdList['totNets'][amodDate];
      let acomment=mdList['comments'][amodDate];

      let nAssets=mdList['nAssets'][amodDate];
      let nIncomes=mdList['nIncomes'][amodDate];
      let nboth=nAssets+nIncomes;
      let daNetValueSay=wsurvey.makeNumberK(daNetValue,100000,0);
      let modThis='<input type="button" value="&#119585;" title="Change this modification"  onClick="showModifyPortfolio_step1b(this)" data-name="'+pname+'" data-ith="'+jj+'"> ';
      let p1say='<button title="A modification: '+acomment+'" onClick="showPortfolioMix(this)" name="whichPortfolio"  data-date="'+amodDate+'"  ';
      p1say+='    data-nth="'+jj+'"  data-name="'+pname+'"  >';
      p1say+=amodDateSay+'</button>';
      p1say+='<span  name="portfolioButton_summary" style="font-style:oblique" title="#assets '+nAssets+'+ # incomes'+nIncomes+' |  netValue"> <em>('+nboth+ ' | '+daNetValueSay+')</em> ' ;
      amess+='<li class="notHighlightThisLi">'+modThis+' '+p1say;
   }

    amess+='</ul>'; // end of list of modifications for this portfolio

   amess+='<div id="viewPortfolioMods_input" class="cviewPortfolioMods_input">';  // popup box to get a modification date, and then display mod menu
   amess+='Modify portfolio <span style="font-size:110%;background-color:lime">'+pname+'</span>  ' ;
   amess+='<ul class="boxList2">';
   amess+='<li>Enter a date after <tt>'+daCreationSay+' </tt>  &#8620; ';

// these value fields filled with lastEntryDate values (by
   amess+='  <span style="border:1px solid gray;padding:5px">  Y:<input type="text"  name="portfolioYear" size="4" title="year " value=""> </span> ';
   amess+=' <span style="border:1px solid gray;padding:5px">    M:<input type="text"  name="portfolioMonth" size="4" title="Month: 1 ... 12, or Jan ... Dec" value="" >  </span> ';
   amess+='  <span style="border:1px solid gray;padding:5px">   D:<input type="text"  name="portfolioDay" size="4" title="Day of month"  value="" > </span>';
   amess+='<li><button  name="modButton1" data-name=""  data-creationDate=""  class="cdoButtonRegular"  data-daycount="" onClick="showModifyPortfolio_step2(this)">';
   amess+='Specify the modifications </button> <em>for the above date!</em>';
   amess+='</ul>';
   amess+='</div>';

   amess+='<div id="mainDiv3b"></div>';



   wsurvey.wsShow.show('#mainDiv','show');
   wsurvey.wsShow.show('#mainDiv3','show');
   $('#mainDiv3').html(amess);


   if (iwhich==3) $('#idoButtonModify').trigger('click') ;

   if (iwhich==1) {        // view creation entry   (nb: iwhich=4 is converted to iwhich=1)
      let e1=$('#portfolioModificationsList');
      let e2=e1.find('[data-nth="0"]');
      e2.trigger('click') ;
   }

   return 1;
}

//=============================== pname  click
// display a list of the modifications to this portfolio
// if pname arg specified it is always show. Otherwise its a button click -- so toggle
// modes:
//  0: small buttons 
//  1 : large buttons
// 2:  large buttons and summary table
// 3:  small buttons and summary table
// 4 :  summary table
function showPortfolioViewModify_listMods(athis,pname,aMode) {
  
  if (arguments.length<3) {
     let ethis=wsurvey.argJquery(athis);
     aMode=ethis.attr('data-mode');
     pname=ethis.attr('data-name');
     aMode++;
     if (aMode>4 || aMode<0)  aMode=0;
     ethis.attr('data-mode',aMode);
  } else {
      if (aMode>4 || aMode<0)  aMode=0;
  }

   let eList=$('#portfolioModificationsList');
  let eListSummary=eList.find('[name="portfolioButton_summary"]');
  let esummary=$('#iPortfolioTransactions');

  if (aMode==0)  { // just small buttons
    eList.show();
    esummary.hide();
    eListSummary.hide();
    eList.removeClass('linearMenu18Pct');
    eList.addClass('linearMenu10Pct');

  } else if (aMode==1) {   // large buttons (buttons + #assets/netValue
    eList.show();
   esummary.hide();
    eListSummary.show();
    eList.addClass('linearMenu18Pct');
    eList.removeClass('linearMenu10Pct');


  } else if (aMode==2) {   // large buttons (buttons + #assets/netValue) and summary table
    eList.show();
    esummary.show();
    eListSummary.show();
    eList.addClass('linearMenu18Pct');
    eList.removeClass('linearMenu10Pct');

  } else if (aMode==3) {   // small buttons (buttons  ) and summary table
    eList.show();
    esummary.show();
    eListSummary.hide();
    eList.removeClass('linearMenu18Pct');
    eList.addClass('linearMenu10Pct');

  } else if (aMode==4) {   //    summary table
    eList.hide();       // no need to hide summaries in eListSummary
    esummary.show();
  }

  showTransactions=aMode ;  // this is now the "default" (used by showPortfolioMix

 let asummMade=esummary.attr('data-made');
 if (asummMade==1) return 1;

//  create and display for this portfolio the table of summaries (for init and each mod)

  let oof,oofComments;
  if (!portfolioModifications.hasOwnProperty(pname)) {
     oof=false;
  } else  {
      oof=portfolioModifications[pname]['list'];
  }

// note:   afterGrowthCashAsset  = priorCashAsset + (-bond addtions+ (rentsAT-loanAT) + IncomeAt
//   and an interest is added  using an interpolation between priorCashAsset and afterGrowthCashAsset
//  afterModifiedCashAsset = afterGrowthCashAsset + netProceeds - refinanceCosts

   let amods={},agrows={};
   let ntrans=0;
   if (oof!==false) {
     for (let adate in oof) {

        ntrans++ ;
        amods[adate]=oof[adate]['changesModify'];
        agrows[adate]=oof[adate]['changesGrow'];
     }
   }

   let amess='';
   amess+='<tt>'+ntrans+'</tt> modifications for <b>'+pname+'</b><br>';
   amess+='<table cellpadding="3" rules="rows" xborder="1" >';
   amess+='<tr><th>Date</th>';
   amess+='<th  style="border-left:3px solid black" colspan="2">Current</th>'
   amess+='<th  style="border-left:3px solid black" colspan="4">Changes in <u>Cash</u> due to modifications</th>'
   amess+='<th  style="border-left:3px dotted black" colspan="4">... assets that were modified</th>'
   amess+='<th style="border-left:3px solid black" colspan="4">Changes in `Cash` due to Growth</th>'
   amess+='<th style="border-left:3px dotted black" colspan="2">After Growth</th>'
   amess+='<th style="border-left:3px solid black" colspan="3">Prior entry</th>'
   amess+='</tr>';
   amess+='<tr><th> </th>';
   amess+='<th  style="border-left:3px solid black" ><u>Cash</u></th><th>netValue</th> ';
   amess+='   <th  style="border-left:3px solid black"> Proceeds</th>  <th>Sales</th>  <th>Purchases</th> <th>reFinance</th>';
   amess+=' <th  style="border-left:3px dotted black">Sold  </th>  <th>Purchased  </th>  <th>Changed  </th>  <th>reFinanced  </th> ';
   amess+='<th style="border-left:3px solid black"> Revenue <th>loans</th><th>additions</th><th>cashInterest</th> ';
   amess+='<th style="border-left:3px dotted black" ><u>Cash</u></th> <td>netValue</td>  ';
   amess+='<th style="border-left:3px solid black"><u>Cash</u></th><th>netValue</th><th>days</th>';
   amess+='</tr>';

// first data row is  just cash and netValue for initialzation entry

   let initStartDateSay=portfolioInit[pname]['dateStampSay'];
   let initStartDate=portfolioInit[pname]['dateStamp'];
   let initCashAsset=portfolioInit[pname]['cashAsset'];
   let initCashAssetSay=wsurvey.makeNumberK(initCashAsset,100000,0)  ;
   let initTotNetValue=portfolioInit[pname]['totNetValue'];
   let initTotNetValueSay=wsurvey.makeNumberK(initTotNetValue,100000,0)  ;

   let totRevenue=portfolioInit[pname]['totals']['totYearlyRevenue'];
   let totRevenueSay= wsurvey.makeNumberK(totRevenue,100000,0)  ;

   let totLoans=portfolioInit[pname]['totals']['totLoanPayYear'];
   let totLoansSay= wsurvey.makeNumberK(totLoans,100000,0)  ;

   let totAdditions=portfolioInit[pname]['totals']['additionsPerYear'];     // added by makePortfolioInit (since its an asset attribute)
   let totAdditionsSay= wsurvey.makeNumberK(totAdditions,100000,0)  ;

// initialzation
  let initStartDateButton='<input type="button" value="'+initStartDateSay+'" data-date="'+initStartDate+'" onClick="clickWhichPortofolio(this)" > ';
   amess+='<tr  bgcolor="#dfdfda"><td>'+initStartDateButton+'</td> ';
   amess+='<td style="border-left:3px solid black">'+initCashAssetSay+'</td>';
   amess+='<td >'+initTotNetValueSay+'</td>';
   amess+='<td  style="border-left:3px solid black; text-align: right;margin-right:1em " colspan="8 align="middle"><em>the initial entry (initial yearly values) ... </em></td> '
   amess+='<td style="border-left:3px dotted black">'+totRevenueSay+'</td>';
   amess+='<td>'+totLoansSay+'</td>';
   amess+='<td>'+totAdditionsSay+'</td>';
   amess+='<td colspan="6"> ... </td>';
   amess+='</tr>';


// now the modifications ...
   if (oof!==false) {

   for (adate in amods) {
      let amods1=amods[adate];

      let adateSay=setEntryDate(adate).sayDate ;
      let adateSayButton='<input type="button" value="'+adateSay+'" data-date="'+adate+'" onClick="clickWhichPortofolio(this)" > ';

       let aTotNetValue=oof[adate]['totNetValue'];
       let aCashAsset=oof[adate]['cashAsset'];
       aTotNetValueSay= wsurvey.makeNumberK(aTotNetValue,100000,0)  ;
       aCashAssetSay= wsurvey.makeNumberK(aCashAsset,100000,0)  ;

        let netProceeds=amods1['netProceeds'];
        let refiCost=amods1['totRefiCost']  ;

      let proceedsSay=wsurvey.makeNumberK(amods1['netProceeds'],100000,0);
      let refiSay=wsurvey.makeNumberK(amods1['totRefiCost'],10000,0);
        let salesSay=wsurvey.makeNumberK(amods1['totSales'],100000,0)  ;
        let netSalesSay=wsurvey.makeNumberK(amods1['netSales'],100000,0)  ;
        let purchasesSay=wsurvey.makeNumberK(amods1['totCosts'],100000,0);       // indluces reficosts
        let sellList=[],purchList=[],changeList=[],refiList=[] ;
        for (let aa in amods1['removeList']) sellList.push(aa);
        for (let aa in amods1['newList']) purchList.push(aa);
        for (let aa in amods1['changeList']) changeList.push(aa);
        for (let aa in amods1['refiList']) refiList.push(aa);

      amess+='<tr><td>'+adateSayButton+'</td> ';

// current colspan
      amess+='<td style="border-left:3px solid black">'+aCashAssetSay+'</td> ';
      amess+='<td ><div title="Net value (including `Cash`">'+aTotNetValueSay+'</div></td> ';

// $changes due to modifciations
      amess+='<td style="border-left:3px solid black">';
      amess+='    <div >'+proceedsSay+'</div></td> ';
      amess+='<td><div    title="Pre tax value='+salesSay+'">'+netSalesSay+'</div></td> ';
      amess+='<td><div  title="Cost of acquiring new assets">'+purchasesSay+'</div></td> ';
      amess+='<td><div    title="Cost of refinancing loans">'+refiSay+'</div></td> ';

// which assets were changed/sold/etc
      amess+='<td style="border-left:3px dotted black">';
      amess+='  <div style="border:1px dotted brown">'+sellList.join(' ')+'</div></td> ';
      amess+='<td><div style="border:1px dotted brown">'+purchList.join(' ')+'</div></td> ';
      amess+='<td><div style="border:1px dotted brown">'+changeList.join(' ')+'</div></td> ';
      amess+='<td><div style="border:1px dotted brown">'+refiList.join(' ')+'</div></td> ';

// changes due t ogrwoth
      let cashAssetChangeGrowSay=wsurvey.makeNumberK(agrows[adate]['cashAssetChangeGrow'],100000,0)  ;
      let revenueSay=wsurvey.makeNumberK(agrows[adate]['totRevenueAT'],100000,0)  ;

      let loanPayment =agrows[adate]['totLoanPayAT']  ;
      let loanPaymentSay=wsurvey.makeNumberK(loanPayment  ,100000,0)  ;

      let addition=agrows[adate]['totAdditions']  ;
      let additionSay=wsurvey.makeNumberK(addition ,100000,0)  ;

      let cashInterest=agrows[adate]['cashAssetInterestAmount']  ;
      let cashInterestSay=wsurvey.makeNumberK(cashInterest ,10000,0)  ;

      let cashAssetAfterGrowth=agrows[adate]['cashAsset'] ;
      let cashAssetAfterGrowthSay=wsurvey.makeNumberK(cashAssetAfterGrowth,100000,0);

      let netValueAfterGrowth=agrows[adate]['totNetValueAfterGrowth'] ;
      let netValueAfterGrowthSay=wsurvey.makeNumberK(netValueAfterGrowth,100000,0);

      amess+='<td style="border-left:3px solid black" ><div  title="rents+ incomes   ">'+revenueSay+'</div></td>';
      amess+='<td><span title="loan payments     ">-'+loanPaymentSay+'</span></td>';
      amess+='<td><span title=" addition to bonds    ">-'+additionSay+'</span></td>';
      amess+='<td><span title=" interest on `Cash`"    ">'+cashInterestSay+'</span></td>';

// values after growht
      amess+='<td style="border-left:3px dotted black"><div    title="`Cash` asset (after growth, before modifications). ">'+cashAssetAfterGrowthSay+'</div></td>';
      amess+='<td><span title="approximate netValue, including `Cash` (after growth, before modifications). ">'+netValueAfterGrowthSay+'</span></td>';

      netValueAfterGrowthSay
      let cashAssetPrior=agrows[adate]['cashAssetPrior'];
      let cashAssetPriorSay=wsurvey.makeNumberK(cashAssetPrior,100000,0);
      let netValuePrior=agrows[adate]['priorTotNetValue'] ;
      let netValuePriorSay=wsurvey.makeNumberK(netValuePrior,100000,0);

// prior entry
      amess+='<td style="border-left:3px solid black" ><div   title="`Cash` asset (before growth)">'+cashAssetPriorSay+'</div></td>';
      amess+='<td><span title="netValue, including `Cash` (before growth)">'+netValuePriorSay+'</span></td>';
      amess+='<td><span title="Days between priorEntry and this modification">'+agrows[adate]['growDays']+'</span></td>';

      amess+='</tr>';
   }
   amess+='</table>';
   }  // oof!== false 

   esummary.html(amess);
   esummary.attr('data-made',1);
//   esummary.show();
   return amess;
}

///==================
// click a whichPortfolio button (to display its asset mix.
// event handler for date col in transactions table
function clickWhichPortofolio(athis) {
   let ethis=wsurvey.argJquery(athis);
   let adate=ethis.attr('data-date');
  let eList=$('#portfolioModificationsList');
  let eListSummary=eList.find('[name="whichPortfolio"]');
  let e1=eListSummary.filter('[data-date="'+adate+'"]');
  if (e1.length!=1) {
     alert('Unable to find button for: '+adate);
  } else {
     e1.trigger('click');
  }
  return 1;
}

//===========================    agrows
// modify a portofolio: first step --  open a menu that asks for a date
// this is called from the "Modify" button

function showModifyPortfolio_step1(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-name');
   let sayDate=ethis.attr('data-creationDate');
   let daycount=ethis.attr('data-daycount');
   let e1= $('#viewPortfolioMods_input');                // this is hard coded, so show it...
   e1.show();
   let oof1=$(document).data('lastEntryDate');         // and set some defualt values for year/month/day
   let eyear=e1.find('[name="portfolioYear"]')
   eyear.val(oof1['year']);
   let emonth=e1.find('[name="portfolioMonth"]');
   emonth.val(oof1['month']);
   let eday=e1.find('[name="portfolioDay"]');
   eday.val(oof1['day']);

   let ebutton=e1.find('[name="modButton1"]')
   ebutton.attr('data-name',aname);
   ebutton.attr('data-creationDate',sayDate);
   ebutton.attr('data-daycount',daycount);              // note that a submit button,which  calls   showModifyPortfolio_step2, is hard coded

}

//=================
// modify an existing modificiaton entry (click handler)
function  showModifyPortfolio_step1b(athis) {
  let ethis=wsurvey.argJquery(athis);
  let pname=ethis.attr('data-name');
  let ith=ethis.attr('data-ith');                 // the position (in list of entries) of the "Modification entry" to be changed. Must be > 0
  let mdList=portfolioLookup['list'][pname];
  let amodDate=mdList['modDates'][ith];
  let oof=setEntryDate(amodDate);
  let ayear=oof['year'];
  let amonth=oof['month'];
  let aday=oof['day'];

  showModifyPortfolio_step2(0,pname,ayear,amonth,aday,ith)  ;  // showModifyPortfolio_step1b:  ith identifies the "mod entry to change"
  //                                                           (the prior entry, to be grown, is ith-1 (0=initialization entry)


}

//===========
// make the modifications .. step 2
// called by "specify the modifications" button in   showModifyPortfolio_step1, or by showModifyPortfolio_step1b ---
//   step1  -- the user specifies a date, and then clicks the button.
//   step1b -- use the date of an existing modification (so as to change the modification)
// The  main action is to "grow" the "nearest existing asset-mix" -- perhaps the initializtion, or perhaps an existing modification
//      growPortfolio()    does this growing
//      growPortfolio returns an entry (an object) with the results of this growing
//   buildPortfolioMenu is then called, with this entry, to display the entry values (the "grown" values) on screen
//   the user can "modify" these values, and then submit the modifications (submit calls portfolioCalcValueMenu_modify)
//   athis ignored if step1b, only athis is used if step1
//  isChange: signals that this is a "change to an existing modificatoin".
//           growPortoflio is applied to the 'prior' (possibly initialization) entry, and then the assets (and their quantities) are used
//            by buildPortfolioMenu (rather than the normal case where the assets in the prior entry are used by buildPortoflioMenu)

function showModifyPortfolio_step2(athis,pname,ayear,amonth,aday,isChange) {

   if (arguments.length<2)  {   // button
     let ethis=wsurvey.argJquery(athis);
       pname=ethis.attr('data-name');
   }

   if (arguments.length<6) isChange=false;    // false not same as 0
   if (isChange===0) {                                            // should NEVER happen
      alert('Error in showModifyPortfolio_step2: isChange=0 ');
      return false;
   }

   aLookup=portfolioLookup['list'][pname];
   let origDate=aLookup['creationDate'] ;
   let origDateSay=aLookup['creationDateSay'] ;
   if (!portfolioInit.hasOwnProperty(pname)) {   // should never happen
        alert('This portfolio ('+pname+') has not been initialized ');
        return false;
   }
 
   let nMods= aLookup['nHistory'];
   let modDates=aLookup['modDates'];

   if (arguments.length<2)  {   // button handler ... read date info from menu (user input)

      let e1=$('#viewPortfolioMods_input');
      let eyear=e1.find('[name="portfolioYear"]');
        ayear=parseInt(eyear.val());
      let emonth=e1.find('[name="portfolioMonth"]');
        amonth= (emonth.val());    // might be a jan, feb, etc.. so don't automatically parseint
      if (jQuery.isNumeric(amonth)) amonth=parseInt(amonth);
      let eday=e1.find('[name="portfolioDay"]');
        aday=parseInt(eday.val());
   }       // else, provided by 1b in arguments above

   let oof=setEntryDate(ayear,amonth,aday);
   if (oof===false)  {
      alert("Bad date entry in showModifyPortfolio_step2");
      return 0;
   }
   let theModDate=oof['dayCount'];
   let theModDateSay=oof['sayDate'];

    if (theModDate<=origDate) {
       alert('The modification date ('+theModDateSay+') must be after the creation (the starting date) of  portfolio '+pname+'  ('+origDateSay+')');
       return 0;
    }

    $(document).data('lastEntryDate',oof);  // use this as defaualt  in enter-a-date fields
    let lastModeDate1=11111111111111111 ;
    if (aLookup['modDates'].length>0)  lastModDate1=aLookup['modDates'][aLookup['modDates'].length-1];
    let iug=jQuery.inArray(theModDate,modDates);

    if (iug>-1) {
      if (isChange===false) {
          let aamess='There already is a modification on this date ('+theModDateSay+')';
          aamess+='\n To change an existing modification: use its \uD834\uDF21  button > ';
          alert(aamess);
          return false;
      }         // if isChange=1, this is the asset mix shown in the menu, but the prior entry asset mix is "grown"
    } else {
       if (theModDate<lastModDate1 && warningLevel==0) {      // don't show this caution if warningLevel>0
         let oof0=setEntryDate(lastModDate1);
         let aamess='Caution: the modification date ('+theModDateSay+') is between the creation date and the last existing modification  ('+oof0['sayDate']+').';
         aamess+='\n This can cause unexpected changes in the values of existing modifications (that occur after '+theModDateSay+').';
         aamess+='\nAre you sure you want to make this modification? ';
         let qq=confirm(aamess);
         if (!qq) return false;
      }
    }

    wsurvey.wsShow.hide('#statusDiv');

// which modification is the "base" (occurs on or before desired modification date
    let ithBase ;
    if (isChange===false) {
       ithBase=find_closestDate(modDates,theModDate);
       if (ithBase===false) return false ;            // false not the same as 0 !    -- should never happen
    } else {
        ithBase=isChange-1 ;       // grow the prior entry (before the modEntry to be changed). isChange is ALWAYS > 0 !
    }

    let closestStamp=modDates[ithBase];        // could be the initialization

// ::: This grows   the "prior" entry at closestStamp(up to theModDate) !   ...

//   "grow" the "ithBase" entry  (which has  closestStamp as its dateStamp)
   let grownEntry=growPortfolio(pname,ithBase,closestStamp,theModDate,0);       // showModifyPortfolio_step2 -- create a modification by growing ithBase..

    if (grownEntry===false) {
       alert('Problem with '+pname+' using entry '+ithBase+' with datestamp '+closestStamp+' for '+theModDate);
       return 1;
    }

    let atg=calc_netValues(grownEntry) ;          // in showModifyPortfolio_step2   calculate correct net values and taxes
    grownEntry['totalsG']=atg;
    grownEntry['totalsG']['statusMessage']='after growth, before modification (on '+theModDate+' growing entry ' +ithBase+' on '+closestStamp+')';
    grownEntry['totNetValue']=grownEntry['totalsG']['totNetValue'] ;

    grownEntry['baseEntry']={'ith':ithBase,'dateStamp':closestStamp};

// build a summary
   let summA;
     if (grownEntry['growDays']>0) {
      summA=portfolio_totalSummary(grownEntry,'<span title="after growth, before modification"><em>after growth</em></span>',1);
   } else {     // if 0, MUST be a "change existing modification" (given iug check above)
      summA=portfolio_totalSummary(grownEntry,'<em>change an existing modification</em>',1);
   }


// ....... ANd this DISPLAYS the user modifiable menu (with the grown asset values) ...
// reminder: grownEntry starts with a clone of baseEntry.

    buildPortfolioMenu(1,grownEntry,theModDate,isChange);     // showModifyPortfolio_step2: display the assets in the "grown" entry,  OR display the "mod entry to change"   assets

   $('#assetHistory_currentSummary').html(summA).show();   // will happen on button push (for initialziation of a portfolio)

//    let tnet=grownEntry['totNetAll'];       // should be actual
    let tnet=grownEntry['totNetValue'];       // should be actual
   let cashAssetNow=grownEntry['cashAsset'];
    portfolioCalcValueMenuWarn(cashAssetNow,1,tnet) ;  // write warning messages?

    entryWorking=grownEntry ;                 //  entryWorking is a global that used used when a "modified" entry is submitted

    return 1 ;          // entryWOrking is global

}



//================
// reset portfolio values on a "modified entry" menu

function growPortfolio_reset(athis) {
   let etable=$('#portfolioHistory1');
   let efields=etable.find('.portfolioAssetNameNew');

   for (let i1=0;i1<efields.length;i1++) {     // un remove
     let eb=$(efields[i1]);
      let erow=eb.closest('tr');
      erow.attr('data-remove',0);
      erow.css({'opacity':1.0,'font-size':'100%'});
   }

   let einputs=etable.find('.modReset');           // all input fields that can be "reset" when "modifying a portoflio"
   for (let i1=0;i1<einputs.length;i1++) {       // reset to "original"
       let  e1=$(einputs[i1]) ;
       let v1=e1.attr('data-orig');
         v1=jQuery.trim(v1);
       let v1say=''
       if (v1!=='')   {
           v1=parseFloat(v1);
           v1say=v1.toFixed(2);
        }
        e1.val(v1say);
   }


   let einputs2=etable.find('.modResetHide');           // the loan fields that might be non-hidden due to refiance -- hide them!
   for (let i1=0;i1<einputs2.length;i1++) {
       let  e1=$(einputs2[i1]) ;
       e1.attr('type','hidden');
   }


   let ep1=etable.find('[name="portfolioLoan_currentSpecs"]'); 
   if (ep1.length==1) {
      ep1.removeClass('cLoanSpecsRefi'); 
      ep1.attr('title','Current loan specs');
   }

   return 1;
}


//====================
// review the modifications to the portfolio
function reviewPortfolioMod(athis) {
 let ethis=wsurvey.argJquery(athis);

 let pname=ethis.attr('data-name');

 let newvals=portfolioCalcValueMenu_modify(athis);          // in reviewPortfolioMod
 if (newvals===false) return false ;

  newvals['comment']='modification and review (of grown entry): '+newvals['dateStampSay'];

 bmess="<b>Summary of modification</b>";
 bmess+='<menu class="boxList">';
 bmess+=' <li>Enter a comment:<input type="text" value="" id="modComment" title="Optional comment about this modification" size="60">';
 bmess+=' <li><em>and then ... </em> ';
 bmess+='<button class="cdoButton" onClick="saveModifiedPortolio(this)" data-name="'+pname+'">Save this modified portfolio</button> ';
 bmess+='</menu>';

 bmess+='<ul class="tightMenu">';
// let tnetAll= parseInt(newvals['totNetAll']);              // should be actual
 let totNetValue= parseInt(newvals['totNetValue']);              // should be actual
 bmess+='<li>netValue (all assets and <u>Cash</u>): <tt>'+wsurvey.addComma(totNetValue)+'</tt> ';

 bmess+='<li>Number of assets: <tt>'+newvals['totals']['nAsset']+'</tt> ';

 bmess+=' &nbsp;&nbsp;(#removed= <tt>'+newvals['changesModify']['nremove']+'</tt>, #added= <tt>'+newvals['changesModify']['nnew']+'</tt>, ';
 bmess+='<tt>#changed= '+newvals['changesModify']['nchange']+'</tt> ).';
 bmess+='<menu class="tighterMenu">';
 bmess+='<li> <tt>'+newvals['totals']['nStock']+'</tt> stock assets:  ~netValue: <tt>'+wsurvey.addComma(parseInt(newvals['totals']['totNetStock']))+'</tt> ';
 bmess+='<li> <tt>'+newvals['totals']['nRegular']+'</tt> regular bond assets: ~netValue: <tt>'+wsurvey.addComma(parseInt(newvals['totals']['totNetRegular']))  + '</tt>';
 bmess+='<li> <tt>'+newvals['totals']['nTaxDefer']+'</tt>  taxDeferred bond assets:  ~netValue: <tt>'+wsurvey.addComma(parseInt(newvals['totals']['totNetTaxDeferred']))+'</tt> ';
 bmess+='<li> <tt>'+newvals['totals']['nProperty']+'</tt> properties: ~netValue: <tt>'+wsurvey.addComma(parseInt(newvals['totals']['totNetProperty']))+'</tt> ';
 bmess+=' (~netRent=<tt>'+wsurvey.addComma(parseInt(newvals['totals']['totYearlyNetRent']))  +'</tt>)';
 let nloans=newvals['totals']['nLoan'];
 if (nloans>0) {
    bmess+=' &hellip;<tt>'+nloans+'</tt> loans: <em>owed</em>: <tt>'+wsurvey.addComma(parseInt(newvals['totals']['totLoanOwed'])) +'</tt>, ' ;
    bmess+=' yearly loan payments (pre tax): <tt>'+wsurvey.addComma(parseInt(newvals['totals']['totLoanPayYear']))+'</tt> ';

 }
 bmess+='<li> <tt>'+newvals['totals']['nIncome']+'</tt> incomeStreams: ~ yearly netIncome: <tt>'+wsurvey.addComma(parseInt(newvals['totals']['totNetIncomeStream'])) +'</tt> ';
 bmess+='</menu>';
 
 bmess+='<li><em>Modifications:</em> ';
 
 let achange=parseInt(newvals['changesModify']['netProceeds']) -parseInt(newvals['changesModify']['totRefiCost']) ;
 let achangeSay=wsurvey.addComma(achange);
 bmess+='netTransactions: '+ achangeSay;
 bmess+=' &#129008; ';
 bmess+='   <tt> '+ wsurvey.addComma(parseInt(newvals['changesModify']['netSales']))+'</tt>   ' ;
 bmess+='&#8722;  ';
 bmess+='  <tt>('+ wsurvey.addComma(parseInt(newvals['changesModify']['totCosts']))+'</tt>   ' ;
 bmess+= ' + <tt>'+ wsurvey.addComma(parseInt(newvals['changesModify']['totRefiCost']))+')</tt>    ' ;
 bmess+=' <tt>&hellip;  assetSales -  (acquisitionCosts + refinanceCosts) </tt>  ';


 if (newvals['changesModify']['totPropertyNetSales']>0) {
   bmess+=' &hellip;  <em> (assetSales include <tt> '+ wsurvey.addComma(parseInt(newvals['changesModify']['totPropertyNetSales']))+'</tt> property sales) </em> ' ;
 }

 bmess+='<menu class="tightMenu">';
 bmess+='<li>Change in (income + rents): <tt> '+ wsurvey.addComma(parseInt(newvals['changesModify']['totModRevenueChangeYearly']))+'</tt>   ' ;

 bmess+='<li> ';

 let rmSay=propertiesToString(newvals['changesModify']['removeList'],' | ');

 bmess+='<span class="cListOfChangeAssets" >Removed:<tt> '+ propertiesToString(newvals['changesModify']['removeList'],' | ')+'</tt></span> ';
 bmess+='<span class="cListOfChangeAssets">New:<tt> '+ propertiesToString(newvals['changesModify']['newList'],' | ')+'</tt></span> ';
 bmess+='<span class="cListOfChangeAssets">Changed:<tt> '+ propertiesToString(newvals['changesModify']['changeList'],' | ')+'</tt></span> ';
 bmess+='<span class="cListOfChangeAssets">reFinance:<tt> '+ propertiesToString(newvals['changesModify']['refiList'],' | ')+'</tt></span> ';

 bmess+='</menu>';

 bmess+='<li>Net value assets: <tt>'+wsurvey.addComma(parseInt(newvals['totalsG']['totNetAsset'])) +'</tt> ';
  let taxOnSales=newvals['totalsG']['totTaxSellAll'];
  let taxOnSalesSay=wsurvey.makeNumberK(parseInt(taxOnSales),20000);
  sayTax2='  <span title="Taxes (capital gains, and tax-deferred) if all assets converted to cash" style="margin-left:0.1em;border:2px dotted tan">';
  sayTax2+=' (includes CapGains &amp; Deferred tax: <tt>'+taxOnSalesSay+'</tt>)</span> ';
  bmess+=sayTax2;

  let tcash =parseInt(newvals['cashAsset']);
  let alimit=totNetValue*budgetRemainPct ;         // budgetRemainPct is global
  if (Math.abs(tcash)>alimit ) {       // big enought  worry about (ie > 0.5% of budget?)
    if (tcash<0) {
        sayCash='<span title="Negative cash balances are subject to a '+cashPenalty+' interest rate penalty" style="font-size:110%;border:2px dotted red">'+wsurvey.addComma(tcash)+'<span>';
    } else {
        sayCash='<span title="Positive  cash balances increase at  a '+cashInterest+' interest rate " style="border:2px dotted green">'+wsurvey.addComma(tcash)+'<span>';
    }
  } else {
        sayCash=wsurvey.addComma(tcash);
  }
 bmess+='    &amp; <u>Cash:</u> <tt>'+sayCash +'</tt>';



 bmess+='<li>Total value (pre-tax, pre loan payoff): <tt>'+wsurvey.addComma(parseInt(newvals['totalsG']['totAssetSale'])) +'</tt> ' ;
 bmess+=' (pre-loan payout: <tt>'+wsurvey.addComma(parseInt(newvals['totals']['totAssetSale'])) +')</tt> ' ;


 bmess+='</ul>';
 displayStatusMessage(bmess);
 toggleStatusDiv(0,0)     ;


}

function propertiesToString(alist,ajoin) {
  if (arguments.length<2) ajoin=', ';
   let plist=[];
   for (let aa in alist) plist.push(aa) ;
   let psay=plist.join(ajoin);
   return psay;
}

//=======================
// save modified portfolio to server
function saveModifiedPortolio(athis) {

  let ethis=wsurvey.argJquery(athis);
  let pname=ethis.attr('data-name');

  let e1=$('#modComment');
  let acomment_mod=jQuery.trim(e1.val());

  let newvals=portfolioCalcValueMenu_modify(athis);   //  in saveModifiedPortolio

  if (newvals===false) return false ;
  newvals['name']=pname;

  for (let ij=0;ij<newvals['assetList'].length;ij++) {
       a0=newvals['assetList'][ij];
       let aname=a0['name'];
       let acomment=newvals['assets'][aname]['comment'];
       newvals['assetList'][ij]['comment']=acomment;
  }

  let dayCount=newvals['dateStamp']   ;
  let sayDate=newvals['dateStampSay']; ;
  newvals['comment']='Modified portfolio on '+sayDate;
  let totNetValue=newvals['totNetValue'];        // actual

//  newvals['totNetAll']=totNetValue;
  newvals['totNetValue']=totNetValue;
  newvals['isCreation']=0 ;

  let davals0={};
  davals0['name']=pname;
  davals0['specifiedDate']=wsurvey.get_currentTime(31,1);
  davals0['userName']=newvals['userName'];
  davals0['dateStamp']=newvals['dateStamp'];
  davals0['dateStampSay']=sayDate;
  davals0['userName']=userName;
  davals0['totNetValue']= newvals['totalsG']['totNetValue'];
  davals0['cashAsset']=newvals['cashAsset'];
  davals0['assetList']= newvals['assetList'];
  davals0['original']=newvals['original'];;
  davals0['comment']=acomment_mod ;
  davals0['baseEntry']=newvals['baseEntry'];            // 0 signals "initial entry"

  let ddata={};
  ddata['username']=userName;    // global
  ddata['todo']='savePortfolioModify';
  ddata['createDate']=dayCount;
  ddata['portfolio']=pname;
  ddata['encMd5']=encryptionKey_md5;

  let alls={};

 // alls['list']=newvals;
  alls['list']=davals0;
  alls['modComment']=acomment_mod ;
//  let allE=simInvEncrypt(alls,encryptionKey);
  ddata['list']=alls ;

   saveSimInvData(ddata);

}



//=============
// add a  empty (no values assigned) row to the portfolio assetMix menu -- using asset name assigned to athis (button push)
// addARowPortfolioAssetMix to specify values

function portfolioAddAssetNew(athis ) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.val();
   let assetType=ethis.attr('data-type');
   let ison=ethis.attr('data-chosen');
   let etable=$('#portfolioHistory1AssetRows');

   if (ison==1) {             // already selected, so scroll it into view

     let egots=etable.find('[name="portfolioAsset"]');
     let egot1=egots.filter('[data-orig="'+aname+'"]');
     if (egot1.length==0) return 0  ;     // should not happen
     let etr=egot1.closest('.portfolioHistoryRow');
     wsurvey.centerInParent(etr,{'duration':300});

     let erems=etable.find('[name="removeThisRowButton"]');
     erems.removeClass('chighlightAssetButton');

     let erem=etr.find('[name="removeThisRowButton"]');
     erem.addClass('chighlightAssetButton');

     return 1;
   }


// check if asset from same family already in protfolio -- also test for asset already added, which should not happen (give disabling of buttons)
   let omess=portfolio_checkAssetAdded(aname);    // portfolioAddAssetNew: asset exists? Not alredy in portfolio?  Not in same family (if sameFamily not permitted)
   if (omess!==false) {
        alert(omess);
        return 0;
   }

   ethis.attr('data-chosen',1);
   ethis.addClass('chighlightAssetButton');
   let eli=ethis.closest('li');
   let aprice='';
   let egoo=eli.find('[name="assetValue_now"]');

// empty (except for name and type) pre-population data
   useTheseEmpty={'name':aname,'nShares':'','comment':'','basis':'','assetType':assetType,'comment':'','cost':'','price':'',
            'loanAmount':'','loanTerm':'','loanRate':'','incomeStart':'','modState':0,'acqCost':0,'purchaseCost':0};

 // add the row
   let etr=addARowPortfolioAssetMix(0,useTheseEmpty,0) ;    // portfolioAddAssetNew: add new (no specs) row to portoflio menu   ... etr is used for highlighting

   wsurvey.centerInParent(etr,{'duration':300});      // scroll to this row in the portoflio menu

   let erems=etable.find('[name="removeThisRowButton"]');
   erems.removeClass('chighlightAssetButton');
   let erem=etr.find('[name="removeThisRowButton"]');
   erem.addClass('chighlightAssetButton');


  return 2;


}

//============================
// check if an asset is already added, or if one of its family has been added
// return false if okay (no match, and no family match)
// otherwise a string error message
// anamex : full name of asset to check 
// haveLIst : ojbect of asset, as created by portfolioMenu_assetFamily. If not specified, portfolioMenu_assetFamily is called
function  portfolio_checkAssetAdded(anameX,haveList) {

   let aname=jQuery.trim(anameX).toLowerCase();

   if (!assetLookup.hasOwnProperty(aname)) return 'Missing asset ('+aname+')' ;

   if (arguments.length<2)   haveList=portfolioMenu_assetFamily(2);    // get list of currently specified (and non removed) assets, and their family
   let anameFamily=aname.split('.',1)[0] ;

    for (let zname in haveList ) {           // look at all the assets currently added to the portfolio's menu ...

        if (zname=='') continue ;                 // will never happen
        if (zname==aname) return 'Asset already added ';

        if (sameAssetFamilyOk==1) continue ;    // else check for members of current family
        if (haveList[zname]==anameFamily)     return 'There already is a `'+anameFamily+'` asset ('+zname+'). To add '+aname+', you must remove '+zname ;

     }

    return false ;  // false means no problem
}


//=============
// retrieve list of assetnames added to portfolio table
function portfolioMenu_assetFamily(ifoo) {
     haveList={} ;
     let etable=$('#portfolioHistory1AssetRows');
     let eaa=etable.find('[name="portfolioAsset"]');
     for (let ii=0;ii<eaa.length; ii++) {           // look at all the assets currently added to the portfolio's menu ...
        let ea1=$(eaa[ii]);
        let etr=ea1.closest('.portfolioHistoryRow');
        if (etr.attr('data-remove')==1) continue ;
        let zname=jQuery.trim(ea1.val()).toLowerCase();
        if (zname=='') continue ;

        let znameFamily=zname.split('.',1)[0].toLowerCase();
        haveList[zname]=znameFamily;
   }
   return haveList;
}

// ================
// changes between "base, with growth"  (entry0) and "modified" (entry1) entries.
// entry1 contains the  current modifications -- but it may have totals, etc that aren't right (portfolioCalValue does too much).
// returns a new entry (that properly combines entry0 and entry1, and some descirptive info

function  portfolioCalcValueMenu_difference(entry0,entry1) {

  let pname=entry0['name'];

  let entryNew= JSON.parse(JSON.stringify(entry1));  // clone this ;
  let allCosts={};
  let allSales={} ;
  let allCapGains={} ;
  let allTaxDeferred={} ;
  let totPropertyNetSales=0;
  let totModRevenueChange=0;
  let totRefiCost=entry1['totals']['totRefiCost'];

  let nremove=0,nnew=0,nchange=0;
  let changeList={},newList={},removeList={},refiList={} ;

// check all assets that are retained
// yearlyrevneu is sum of rents and incomeStreams for an asset. 5 July: only one of these is non-zero for a single asset... rents incorporate recurring expenses, and can be negative

   for  (let asset1 in entry1['assets']) {      // look at assets in the modification (look for removals below ...)

     let a1=entry1['assets'][asset1];

     let atype=a1['assetType'];

     if  (!entry0['assets'].hasOwnProperty(asset1)) {          // a new asset? Just track its cost
             allCosts[asset1]=parseFloat(a1['cost']);     // all the  entry1 variables are okay

             if (atype==3 || atype==4)  totModRevenueChange+=a1['yearlyRevenue'];
             nnew++ ;
             newList[asset1]={'change':parseFloat(a1['q']),'acqCost':parseFloat(a1['cost']),'saleValue':0} ;
             continue;;
     }         //  else a change  ...


// correct possible inappopriate changes (to cost, loan, etc) made when entry1 was created by portfolioCalcValue
// (stuff that was updated by growth (basis, price), or does not change (loan info)
// Note: ONLY if this a "retained" asset!
// assetType is the same in both (no need to correct)

     let a0=entry0['assets'][asset1];

     entryNew['assets'][asset1]['cost']=parseFloat(a0['cost'] );
     entryNew['assets'][asset1]['basis']=parseFloat(a0['basis']) ;
     entryNew['assets'][asset1]['price']=parseFloat(a0['price']) ;
     if (a1['loanSchedule']===false) {                     //not a refi
         entryNew['assets'][asset1]['loanSchedule']=  a0['loanSchedule']  ;      // use prior one
         entryNew['assets'][asset1]['loanOwed']=parseFloat(a0['loanOwed']) ;
        entryNew['assets'][asset1]['loanPayYearly']= (jQuery.isNumeric(a0['loanPayYearly'])) ? parseFloat(a0['loanPayYearly']) : a0['loanPayYearly']  ;  // might be false
     } else {
         entryNew['assets'][asset1]['loanOwed']=parseFloat(a1['loanOwed']) ;
         entryNew['assets'][asset1]['loanPayYearly']= (jQuery.isNumeric(a1['loanPayYearly'])) ? parseFloat(a1['loanPayYearly']) : a1['loanPayYearly']  ;  // might be false
     }

// q, value, netValue, capGains, taxOnSale, comment CAN change!

     let cost0=parseFloat(a0['cost'])     ;
     let nshares1=parseFloat(a1['q']);
     let nshares0=parseFloat(a0['q']);

     let dShares=nshares1-nshares0;
     if (atype==0 || atype==1 || atype==2 ) {
        if (Math.abs(dShares)<1) continue ;  // no change ...   // allow for rounding
     }
     if (atype==3)  {
        if (a1['loanSchedule']==false) continue;   // not a refi
      }
    if (atype==4) continue ;                     // incomeStreams can not be modfied

// a modification has occured... 

     if (atype==0) {

        nchange++;
        changeList[asset1]={'change':dShares,'acqCost':0,'saleValue':0};

        let aprice=parseFloat(a0['price']) ;
        let abasis=parseFloat(a0['basis']) ;
        if (dShares>0)  {           // shares added
               let costx=dShares*aprice;
               changeList[asset1]['acqCost']=costx ;
               allCosts[asset1]=costx;       // cost of addition
               entryNew['assets'][asset1]['cost']=cost0+costx ;
               entryNew['assets'][asset1]['basis']=abasis+costx ;
        } else if (dShares<0)  {           // shares sold
               let ddShares=Math.abs(dShares);
               let salex=ddShares*aprice;
               changeList[asset1]['saleValue']=salex ;
               allSales[asset1]=salex  ;         // subject to capital gains ...

               let cfrac=ddShares/nshares0;        // fraction of existing shares sold
               let daBasis=abasis*cfrac;
               allCapGains[asset1]=calcAsset_capGainsAmount(asset1,salex,daBasis) ;
               entryNew['assets'][asset1]['cost']=cost0*(1-cfrac) ;    // proportional reduction
               entryNew['assets'][asset1]['basis']=abasis-daBasis ;
        }                     // change in asset shares
        continue;
     }       // type=0

     if (atype==1) {

        nchange++;

        changeList[asset1]={'change':dShares,'acqCost':0,'saleValue':0};

        if (dShares>0)  {           // shares added
               allCosts[asset1]=dShares;       // cost of addition
               changeList[asset1]['acqCost']=dShares ;
               entryNew['assets'][asset1]['cost']=cost0+dShares  ;  // add to "base"  cost
        } else if (dShares<0)  {           // shares sold
              let ddShares=Math.abs(dShares);
              changeList[asset1]['saleValue']=ddShares ;

              allSales[asset1]=ddShares ;
              let cfrac=ddShares/nshares0;
              entryNew['assets'][asset1]['cost']=cost0*(1-cfrac);       // proportional reduction
        }                     // change in asset shares
         continue;
     }       // type=1

     if (atype==2) {            // similar to regular bonds, but cost and value differ (due to pre-tax income being used)

        nchange++;

        changeList[asset1]={'change':dShares,'acqCost':0,'saleValue':0};

        if (dShares>0)  {           // shares added
            let taxRate= calcAsset_taxRate(asset1,1);
            let costX=dShares*(1-taxRate);    // assume pre-tax income is used to acquire tax deerred bonds, so actual cost is net of reduced income tax
            changeList[asset1]['acqCost']=costX ;
            allCosts[asset1]=costX;       // cost of addition
            entryNew['assets'][asset1]['cost']=cost0+costX ;
            allTaxDeferred[asset1]= (-dShares);          // allow addtions to taxDeferred to be a transfer from a sold tax deferred

        } else  {           // shares sold
            let ddShares=Math.abs(dShares);
            changeList[asset1]['saleValue']=ddShares ;        // tax on tax deferred figured on all modifications (a transfer between tax deferred is NOT taxed)
            allSales[asset1]=ddShares   ;         //// subject to tax deferred s ...
            allTaxDeferred[asset1]=ddShares;
            let cfrac=ddShares/nshares0;        // proportional reduction
            entryNew['assets'][asset1]['cost']=cost0*(1-cfrac) ;
         }                     // change in asset shares
         continue;
     }       // type=2


     if (atype==3)  {     // check if a refinance occured  ?
          let a1Loan=a1['loanSchedule'];
          let loanDate=(a1Loan.hasOwnProperty('startDate')) ? parseInt(a1Loan['startDate']) :  false ;
          let entry_date=parseInt(entry1['dateStamp']);
 
          if (loanDate!==false && loanDate==entry_date) {  // a new loan
             refiCostX=parseFloat(a1Loan['refiCost']) ;
             allCosts[asset1]=refiCostX;       // cost of refinance
             refiList[asset1]={'loanAmount':a1Loan['amount'],'yearPay':a1Loan['yearPay'],'refiCost':refiCostX } ;
             continue ;
         }
     }

// retained incomeStreams do not change (they can be sold, or new ones bought ... but no marginal changes).

   }           // entry1 assets


// ... removed assets  ...........
   for  (let asset0 in entry0['assets']) {      // look at assets in the modification (look for removals below ...)

      if (entry1['assets'].hasOwnProperty(asset0)) continue ; // NOT a removed asset
      nremove++;
      
       removeList[asset0]={'change':1,'acqCost':0,'saleValue':0} ;


      let a0=entry0['assets'][asset0];
      let atype=a0['assetType'];
      if (atype==0) {
         let nshares0=parseFloat(a0['q']);
         let aprice=a0['price'];             // since entry0 and entry1 are on the same date, can use entry0 attributes
         let abasis=a0['basis'];
         let salex=nshares0*aprice;
         removeList[asset0]['saleValue']=salex;
         allSales[asset0]=salex  ;         // subject to capital gains ...
         allCapGains[asset0]=calcAsset_capGainsAmount(asset0,salex,abasis) ;
         continue;
      }       // type=0

     if (atype==1) {                            // no taxes, so simple
         let nshares0=parseFloat(a0['q']);
         allSales[asset0]=nshares0 ;
         removeList[asset0]['saleValue']=nshares0;

         continue ;
     }       // type=1

     if (atype==2) {            // track all tax deferred sales
         let nshares0=parseFloat(a0['q']);
         allSales[asset0]=nshares0 ;
         removeList[asset0]['saleValue']=nshares0;
         allTaxDeferred[asset0]=nshares0;
         continue;
     }       // type=2

     if (atype==3) {
         let loanOwed=a0['loanOwed'];
         let aprice=a0['price'] ;
         let abasis=a0['basis'] ;
         let asale=aprice-loanOwed;
         removeList[asset0]['saleValue']=asale;

         allSales[asset0]=asale;          // subject to capital gains tax....
         allCapGains[asset0]=calcAsset_capGainsAmount(asset0,aprice,abasis) ;
         totPropertyNetSales+=asale ;

         totModRevenueChange-=a0['yearlyRevenue'];

         continue;
     }       // type=3

     if (atype==4 ) {      // if 4 (incomeSTream) removed, just change  totModRevenueChange
       totModRevenueChange-=a0['yearlyRevenue'];
       continue ;
     }


   }             // end of removes

// totals ..
   let totSales=0;             // pre tax income
   for (let aa in allSales) {
      totSales+=allSales[aa];
   }
   let totCosts=0;             // pre tax costs
   for (let aa in allCosts) {
      totCosts+=allCosts[aa];
   }
   let totCapGainsTaxable=0;             // total taxable capital gains

   for (let aa in allCapGains) {
      totCapGainsTaxable+=allCapGains[aa];
   }

   let capGainsTax=calcAsset_taxAmount(0,totCapGainsTaxable,1);

   capGainsTax=Math.max(0,capGainsTax);

   let totTaxDeferred=0;             // total taxable capital gains
   for (let aa in allTaxDeferred) {
      totTaxDeferred+=allTaxDeferred[aa];
   }
   let deferredTax=calcAsset_taxAmount(2,totTaxDeferred,1);
   deferredTax=Math.max(0,deferredTax);

   let netSales =totSales-(capGainsTax+deferredTax);

   let netProceeds=netSales-totCosts;

   let cc1={'totRefiCost':totRefiCost,'netProceeds':netProceeds,
            'totCosts':totCosts,'totSales':totSales,'netSales':netSales,'capGainsTax':capGainsTax,'deferredTax':deferredTax,
            'totPropertyNetSales':totPropertyNetSales, 'totModRevenueChangeYearly':totModRevenueChange,
            'nremove':nremove,'nnew':nnew,'nchange':nchange,
            'removeList':removeList,'newList':newList,'changeList':changeList,'refiList':refiList
            };

   entryNew['changesModify']=cc1;

   return entryNew;

}

