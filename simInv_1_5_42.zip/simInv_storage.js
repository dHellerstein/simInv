//===================
// get, or write, data from or to server-- or from/to local file system
// `stuff` depends on action (often it is not specified)

function getSimInvData(ddata,action,stuff) {

  let qstandAlone=simInvLocalStorage['useLocalStorage']==1 ;

  let nowTime=wsurvey.get_currentTime(0);

  if (action=='afterLogon')    {       // :::::::::::::::::::::: afterLogon  ::::::::::

    let response={};
    if (!qstandAlone)  {               // ........... onLine mode?
         ddata['action']=action;
         getSimInvData_sendServer(ddata);
         return 1;   // callback deals with return
    }


//  ... IF here, Local mode ..........

//  fix settings ?
  let tsettings=simInv_localVar('settings');
  if (!tsettings.hasOwnProperty('list')) {   // 27 july 2023: fix up older version
    let tsettings2={'date':nowTime,'list':{}};
    for (let avar in tsettings)  {
       tsettings2['list'][avar]= tsettings[avar];
    }
    simInv_localVar('settings',tsettings2);  // fix it
    tsettings=tsettings2;
  }  // fixing setigns

   response['settings']=tsettings ;
    response['assets']=simInv_localVar('assets');
    response['assetHistory']=simInv_localVar('assetHistory');
    response['portfolios']=simInv_localVar('portfolios');
    response['portfolioInit']=simInv_localVar('portfolioInit');
    response['portfolioModifications']=simInv_localVar('portfolioModifications');
    response['viewDates']=simInv_localVar('viewDates');

    afterLogon(response);
    return 1;

  }

  wsurvey.dumpObj(ddata,1,'unsupported in local: '+action);

}

//==============      alert
// sort a list using each rows 'date' property
function  getSimInvData_sortDate(a,b) {
   let a1=parseFloat(a['date']);
   let b1=parseFloat(b['date']);
   let dd=a1-b1;
   return dd;
}

//====================
// send/get info to server
function getSimInvData_sendServer(ddata)  {

   let action=ddata['action'];
   let stuff=0;                // stuff might be used (depdending on action)

   $.ajax({                                // getSimInvData !
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {
     alert('oy '+action);
      getSimInvData_serverResponse(action,response,stuff);
   });

   return 1; ;
}


//====================
// call back : server response
function   getSimInvData_serverResponse(action,response,stuff)  {
// callback action dpends on "action"

  if (action=='afterLogon')    {       // afterLogon will read data from response and save to globals
       wsurvey.wsShow.hide('#statusDiv');
       return 1;


  } else if (action=='saveEncKey') {
       if (response['error']===true)  {           // should never happen
            alert('Problem: '+response['message']);
            return 0;
       }
       let amess='<tt>'+response['message']+'</tt>';
       amess+'<p> You <u>must</u> use it in all simInv logons! ';
       amess+='<p>Please  <input type="button" value="logon again "   ';
       amess+='             onClick="doLogoff(1)" data-reload="0" > (using this <em>encryption key</em>) ';
       displayStatusMessage(amess);
       toggleStatusDiv(0,0);
       return 1;

  }

  wsurvey.dumpObj(response,1,'getSimInvData: Response from server, unknown  action '+action)
  return false;


}

// ================================================
// save a simInv data set ... to local storage or server

function saveSimInvData(ddata,nosave) {
  if (arguments.length<2) nosave=0;
  let qLocal=simInvLocalStorage['useLocalStorage']==1 ;
  let action=ddata['todo'];
  let nowTime=wsurvey.get_currentTime(0);

// save public asset
  if (action=='saveAssetsPublic') {            // :::::::::::::::::::::: assets public ::::::::::::

   let dAsset=ddata['assetName'];
   let aList0=JSON.parse(JSON.stringify(allCurrentData['assets']));
   let aList=aList0['list'];
   let nassets=aList.length ;   // before adding puclic asset

   aList.push(ddata['assetSpecs']['list'][0]);  // now add the specs for the public asset

   let aListH=JSON.parse(JSON.stringify(allCurrentData['assetHistory']));
   delete aListH['date'];  // don't need this

    aListH['list'][dAsset]=ddata['assetHistory']['list'];
    aListH['autoAddEntries'][dAsset]=0;            // make the user add entries as they happen
    aListH['nremove'] =0;            // make the user add entries as they happen
    aListH['nretain'] =nassets;            // make the user add entries as they happen

   let vvMake={'date':nowTime};
    vvMake['list']=aList ;
    vvMake['listH']=aListH ;
      vvMake['nremove']=0 ;
      vvMake['nadd']=1 ;
     vvMake['nretain']=nassets  ;
     vvMake['removes']=[] ;
     vvMake['nassets']=nassets+1 ;
     vvMake['publicAdd']=dAsset ;

     if (qLocal) {
        saveSimInvLocal_assets(vvMake,1) ;
        let bmess='After adding publicAsset '+dAsset+': # assets= '+vvMake['nassets']  +' assets (local storage) ';
          bmess+= '<br> After reloading -- you can use  <button> &#128065; assets</button> to add, or modify, its history-entries.';
          bmess+='<br>For example: you can enable <tt>autoAdd entries after final</tt>';
         displayResponseFromServer(bmess,'assetsTableButton');    // nremove
     } else {
         saveSimInvOnline_assets(vvMake,1) ;   // saveAssets
     }

     return 1;


  }

  if (action=='saveAssets') {            // :::::::::::::::::::::: assets ::::::::::::

     let vv= saveSimInv_assets(ddata,0);             // saveAssets
     if (qLocal) {
        saveSimInvLocal_assets(vv,0) ;
        let bmess=vv['nassets']  +' assets:  after '+vv['nretain']+' retained, '+vv['nremove']+' removed, '+vv['nadd']+' added (local storage) ';
        if (vv['nadd']>0) bmess+= '<br> After reloading -- use  <button> &#128065; assets</button> to add history-entries for the newly added assets ';
        displayResponseFromServer(bmess,'assetsTableButton');    // nremove
     } else {
        saveSimInvOnline_assets(vv,0) ;   // saveAssets
     }

     return 1;
  }

  if (action=='saveSettings') {            // :::::::::::::::::::::: assets ::::::::::::
   let vvL={};
     let x1= JSON.parse(JSON.stringify(ddata['list']));  // clone this ;
     vvL['date']=nowTime;
     vvL['list']=x1;             // don't bother encrypting

     if (qLocal) {
        simInv_localVar('settings',vvL);        // save to localStorage
        let  bmess ='New personal settings recorded (local). ';
        displayResponseFromServer(bmess,'isettingsButton');
       return 1;
     }

// save to server
     ddata={'todo':'saveSettings','which':'settings','data':vvL,'username':userName,'encMd5':encryptionKey_md5} ;

     $.ajax({                                // getSimInvData !
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
     }).always(function (response) {
        let  bmess ='New personal settings recorded (onLine). ';
        displayResponseFromServer(bmess,'isettingsButton');
           return 1;
     });

     return 1;
  }

  if (action=='saveViewDates') {                    // :::::::::::::::::::::: viewdates  ::::::::::::

     let vvL={};
     let x1= JSON.parse(JSON.stringify(ddata['list']));  // clone this ;
     vvL['date']=nowTime;
     vvL['list']=x1;             // don't bother encrypting


     if (qLocal) {
     
        simInv_localVar('viewDates',vvL);        // save to localStorage
        let  bmess ='New display dates recorded (local). ';
        displayResponseFromServer(bmess,'valueDatesButton');
       return 1;
     }

     let ddata2={'todo':'saveViewDates','data':vvL,'username':userName,'encMd5':encryptionKey_md5} ;

     $.ajax({                                // getSimInvData !
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata2
     }).always(function (response) {
        let  bmess ='New viewDates recorded (onLine). ';
        displayResponseFromServer(bmess,'valueDatesButton');
           return 1;
     });

  }


   if (action=='saveAssetHistory') {            // :::::::::::::::::::::: assets ::::::::::::
       let vv= saveSimInv_assetHistory(ddata);   // saveAssetHistory
        vv['bothLists']={};           // this is what is saved
        vv['bothLists']['list']=vv['list']['list'];
        vv['bothLists']['autoAddEntries']=vv['list']['autoAddEntries'];

      if (qLocal) {
        saveSimInvLocal_assetHistory(vv ) ;
     } else {
        saveSimInvOnline_assetHistory(vv ) ;   // saveAssetHistory
     }

     return 1;
  }

  if (action=='saveAllPortfolios') {            // :::::::::::::::::::::: assets ::::::::::::

     let vv= saveSimInv_portfolios(ddata);
      if (qLocal) {
        saveSimInvLocal_portfolios(vv) ;
     } else {
        saveSimInvOnline_portfolios(vv) ;   // callback used
     }

     return 1;
  }

  if (action=='savePortfolioInit') {            // :::::::::::::::::::::: assets ::::::::::::

     let vv= saveSimInv_portfolioInit(ddata);
     if (qLocal) {
        saveSimInvLocal_portfolioInit(vv) ;
     } else {
        saveSimInvOnline_portfolioInit(vv) ;   // callback used
     }

     return 1;
  }


  if (action=='savePortfolioModify') {            // :::::::::::::::::::::: assets ::::::::::::

     let vv= saveSimInv_portfolioModification(ddata);

     if (qLocal) {
        saveSimInvLocal_portfolioModification(vv) ;
     } else {
        saveSimInvOnline_portfolioModification(vv) ;   // callback used
     }
     return 1;
  }


  if (action=='removePortfolioModification') {          /// ============ remove a portfolio modification

      let v0=allCurrentData['portfolioModifications'];

      let pname=ddata['portfolio'];           // note that overwriting of same date
      let cdate=ddata['modification']  ;

      if (!v0['list'].hasOwnProperty(pname)) {
          alert('No such portfolio ('+pname+') -- can not remove a modification!' );
          return 0;
      }
      let  vlist=v0['list'][pname]['modList']  ;
      if (!v0['list'][pname]['modList'].hasOwnProperty(cdate)) {
          alert('Portfolio ('+pname+') -- does not have a modification on '+cdate);
          return 0;
      }

      delete v0['list'][pname]['modList'][cdate];   // remove this modification
      let nmods=0;
      for (let arf in v0['list'][pname]['modList']) nmods++ ;

      let vvL={};

      if (qLocal) {        // local storage
          let vvL2={};
          vvL2['date']=nowTime;
          vvL2['content']={};
          vvL2['content']['date']=nowTime;
          vvL2['content']['list']= simInvEncrypt(v0['list'],encryptionKey);

          simInv_localVar('portfolioModifications',vvL2);        // save to localStorage (and update lastChange)
          let bmess= 'Portfolio <tt>'+pname+'</tt>: modification removed ('+cdate+'). There are now: '+nmods+' modifications (local storage).';
          displayResponseFromServer(bmess,'portfoliosTableButton');
      }

// on line

      vvL['date']=nowTime;
      vvL['list']=simInvEncrypt(v0['list'],encryptionKey);
      ddata={'todo':'save','which':'portfolioModifications','data':vvL,'username':userName,'encMd5':encryptionKey_md5} ;

      $.ajax({                                // getSimInvData !
         url: 'simInv2.php',
         type: 'POST',
         dataType: 'json',
         data: ddata
      }).always(function (response) {
          let bmess= 'Portfolio <tt>'+pname+'</tt>: modification removed ('+cdate+'). There are now: '+nmods+' modifications (onLine storage).';
          displayResponseFromServer(bmess,'portfoliosTableButton');
      });


   }    // remove portoflio mod

}      // saveSimInvData

// =============================================
//  .....................................
// save assets  ...............

function  saveSimInv_assets(ddata,ispublic) {
  if (arguments.length<2) ipublic=0;
   let nowTime=wsurvey.get_currentTime(0);
   let v0=allCurrentData['assets'];
   let vlist=v0['list'];
   let listH0=false;

   let rlist={};     // removals?
   for (let id=0;id<ddata['removes'].length;id++) {
           let a1=ddata['removes'][id];
           rlist[a1]=1;                     // assets to remove
   }

   let vlistUse=[];
   let nremove=0,nadd=0,nretain=0;
   let nassets=vlist.length;

   for (let iv=0;iv<vlist.length;iv++) {
           let avv=vlist[iv];
           let avname=avv['name'];
           if (rlist.hasOwnProperty(avname))  {
              nremove++;
              continue;  // this entry in vlist is to be removed
           }
           vlistUse.push(avv);
           nretain++ ;
   }

// new assets (could be after removing prior version)
   for (let mm=0;mm<ddata['list'].length;mm++)  {
         let zz=ddata['list'][mm];
         vlistUse.push(zz);
         nadd++ ;
    }

   if (nremove>0) {                // if removals, need to remove stuff from assetHistroy
      listH0=saveSimInvLocal_assetHistory_removes(ddata['removes']);
   }
   nassets=nadd+nretain ;
   let vv={'date':nowTime,'list':vlistUse,'listH':listH0,'nremove':nremove,'nretain':nretain,'nadd':nadd,'removes':rlist,'nassets':nassets  };
   return vv;
}

//===========
// save the formatted assets.. local

function  saveSimInvLocal_assets(vv,ispublic) {
  if (arguments.length<2) ispublic=0;
    let vvL={};
     let nowTime=wsurvey.get_currentTime(0);

    vvL['date']=nowTime;
    vvL['content']={};
    vvL['content']['date']=nowTime;
    vvL['content']['list']=simInvEncrypt(vv['list'],encryptionKey);
    simInv_localVar('assets',vvL);        // save to localStorage (and update lastChange)
    if (vv['listH']!==false) {          // assethistory removals, or public asset addition
        let vvH={};
        vvH['date']=nowTime;
        vvH['content']={};
        vvH['content']['list']=simInvEncrypt(vv['listH'],encryptionKey);
        simInv_localVar('assetHistory',vvH);        // save to localStorage (and update lastChange)
    }

  return 1 ;
}

//===========
// save the formatted assets.. local

function  saveSimInvOnline_assets(vv,ispublic) {
  if (arguments.length<2) ispublic=0;
    let vvL={};
    let nowTime=wsurvey.get_currentTime(0);
    vvL['date']=nowTime;
    vvL['list']=simInvEncrypt(vv['list'],encryptionKey);
    ddata={'todo':'save','which':'assets','data':vvL,'username':userName,'encMd5':encryptionKey_md5} ;
   $.ajax({
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {          // now deal withy removals
      saveSimInvOnline_assetsRemove1(vv,ispublic);
   });
   return 1;
}

// ===========
// step 2 in adding/remove assets -- removals from assetHistory
// uses vv['listH']
function saveSimInvOnline_assetsRemove1(vv,ispublic) {
  if (arguments.length<2) ispublic=0;

  let nowTime=wsurvey.get_currentTime(0);

  if (vv['listH']===false  ) {       // no need to adjust assetHistory
     let bmess=vv['nassets']  +' assets:  after '+vv['nretain']+' retained, none removed, '+vv['nadd']+' added ';
     if (vv['nadd']>0) bmess+= '<br> After reloading -- use  <button> &#128065; assets</button> to add history-entries for the newly added assets ';
      displayResponseFromServer(bmess,'assetsTableButton');
      return 0;
  }

  let nentries=0 ;
  for (let za in vv['list']) nentries++ ;

  let vvH={};
  vvH['date']=nowTime;
  vvH['bothLists']={};
  vvH['bothLists']['list']=vv['listH']['list'];
  vvH['bothLists']['autoAddEntries']=vv['listH']['autoAddEntries'];

  vvH['nretain']=vv['nretain'];
  vvH['nremove']=vv['nremove'];
  vvH['nadd']=vv['nadd'];
  vvH['nentries']=nentries;
  vvH['assetName']= (vv.hasOwnProperty('publicAdd'))  ? vv['publicAdd'] : 'assets removed' ;
  saveSimInvOnline_assetHistory(vvH,ispublic);             // saveSimInvOnline_assetsRemove1

}

// =============================================
//  .....................................
// save assetHistory changes (for asset aname)
function  saveSimInv_assetHistory(ddata ) {

   let nowTime=wsurvey.get_currentTime(0);
   let dAsset=ddata['asset'];
   let v0=allCurrentData['assetHistory'];

   let vlist= v0['list'];
   if (!jQuery.isPlainObject(vlist)) vlist={} ; // deal with [] init.. otherwise conains prior entries (if not removed, that are not changed)
   let vlistA= (vlist.hasOwnProperty(dAsset)) ?   vlist[dAsset] : [] ; // this assets history entries

   let gotDates={} ;   // existing dates in this assets history
   let vlistUse=[],nremove=0,nretain=0,nadd=0;

   if (!ddata.hasOwnProperty('vlistH')) {
      let rlist={};     // removals of some entries from this assets history
      for (let id=0;id<ddata['removes'].length;id++) {
           let a1=ddata['removes'][id];
           rlist[a1]=1;                     // assets to remove
      }

      for (let iv=0;iv<vlistA.length;iv++) {
         let avv=vlistA[iv];
         let avname=avv['date'];     // properties in remove list are the dates
         if (rlist.hasOwnProperty(avname)) {
               nremove++; ;
               continue;  // this entry in vlist is removed
         }
         vlistUse.push(avv);
         nretain++;
      }
   }  else {      //
      alert('Error in saveSimInv_assetHistory.');
   }

   let gotdates={};
   for (let iu=0;iu<vlistUse.length;iu++) {
            let adate=vlistUse[iu]['date'];
            gotdates[adate]=1;
    }


// new assethistory entries (could be after removing prior version)
     let errs=[];
     for (let mm=0;mm<ddata['list'].length;mm++)  {
         let zz=ddata['list'][mm];
         let bdate=zz['date'];
         if (gotdates.hasOwnProperty(bdate)) {
             errs.push(bdate )
             continue;
         }
         vlistUse.push(zz);

         nadd++ ;
      }

      if (errs.length>0)  {        // conflicting dates
        let bmess='';
         bmess+='<div style="border:3px solid yellow;padding:5px"><b>Warning</b>: entries <b>not saved</b>.<br> ';
         bmess+='The following dates already have entries (for asset <tt>'+dAsset+'</tt>) -- you must remove entries on these dates, and then you can respecify! ';
         bmess+='<ul><li>'+errs.join('<li>')+'</ul> ';
         displayStatusMessage(bmess);
         toggleStatusMessage(0);
         return 0;
      }

      vlistUse.sort(getSimInvData_sortDate);  // in ascending order
      vlist[dAsset]=vlistUse ;                // replaced this asset's entries

      v0['list']=vlist ;

      if (!jQuery.isPlainObject(v0['autoAddEntries']))  v0['autoAddEntries']={};
      v0['autoAddEntries'][dAsset]=parseInt(ddata['autoAddEntries']);

      return {'list':v0,'nretain':nretain,'nremove':nremove,'nadd':nadd,'nentries':vlistUse.length,'assetName':dAsset} ;
}

//===============   gotdates    
// return assetHistory with removals of assetnames (all entries of an asset)
function   saveSimInvLocal_assetHistory_removes(removes) {
   let vHH=allCurrentData['assetHistory'];

   let rlist={};     // removals?
   for (let jid=0;jid<removes.length;jid++) {
           let a1=removes[jid];
           rlist[a1]=1;                     // assets to remove
   }

   let vlistUse={},vAutoAddEntriesUse={},nremove=0,nretain=0 ;

    for (aa1 in  vHH['list']) {
         if (rlist.hasOwnProperty(aa1)) {
               nremove++; ;
               continue;  // this entry in vlist is removed
         }
         vlistUse[aa1]=vHH['list'][aa1];
         vAutoAddEntriesUse[aa1]=vHH['autoAddEntries'][aa1];
         nretain++;
   }
   return {'list':vlistUse,'autoAddEntries':vAutoAddEntriesUse,'nremove':nremove,'nretain':nretain};

}

//===========
// save the formatted assetHistory .. local

function  saveSimInvLocal_assetHistory(vv) {

    let vvL={};
    let nowTime=wsurvey.get_currentTime(0);
    vvL['date']=nowTime;
    vvL['content']={};
    vvL['content']['date']=nowTime;
    vvL['content']['list']=simInvEncrypt(vv['list'],encryptionKey);

    simInv_localVar('assetHistory',vvL);        // save to localStorage (and update lastChange)
    let bmess=vv['nentries']  +' entries for '+vv['assetName']+'  :  after '+vv['nretain']+' retained, '+vv['nremove']+' removed, '+vv['nadd']+' added (local storage) ';
    displayResponseFromServer(bmess,'assetsTableButton');

  return 1 ;
}

//===========
// save the formatted assetHistory .. online

function  saveSimInvOnline_assetHistory(vv,ispublic) {
  if (arguments.length<2) ispublic=0;
  // showDebug(vv,'vvv in aaaa');
    let vvL={};
    let nowTime=wsurvey.get_currentTime(0);

    vvL['date']=nowTime ;
    vvL['list']=simInvEncrypt(vv['bothLists'],encryptionKey);
    ddata={'todo':'save','which':'assetHistory','data':vvL,'username':userName,'encMd5':encryptionKey_md5} ;

   $.ajax({                                // getSimInvData !
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {
     let bmess;
      if (ispublic==0) {
         let bmess=vv['nentries']  +'   entries for '+vv['assetName']+'  :  after '+vv['nretain']+' retained, '+vv['nremove']+' removed, '+vv['nadd']+' added ';
      } else {
         let nn=0;
         for (let xx in  vv['bothLists']['list']) nn++;
         let newname =vv['assetName'];

         let nentries=vv['bothLists']['list'][newname].length;
           bmess=nentries+' entries added for publicAsset <tt> '+vv['assetName']+' </tt>  : there are now '+nn+' assets ';
      }
       displayResponseFromServer(bmess,'assetsTableButton');

   });
   return 1;
}


// =============================================
//  .....................................
// save portofliol ist

function  saveSimInv_portfolios(ddata) {

   let nowTime=wsurvey.get_currentTime(0);

   let v0=allCurrentData['portfolios'];

   let vlist0=v0['list'];
   let nremove=0,nretain=0,nadd=0;
   let rlist={};     // removals?
   for (let id=0;id<ddata['removes'].length;id++) {
          let a1=ddata['removes'][id];
          rlist[a1]=1;                     // portfolios to remove
  }

   let vlistUse=[];

   for (let iv=0;iv<vlist0.length;iv++) {
       let avv=vlist0[iv];
       let avname=avv['name'];
       if (rlist.hasOwnProperty(avname)) {
           nremove++;
           continue;  // this entry in vlist is removed
       }
       vlistUse.push(avv);
       nretain++;
   }
   for (let mm=0;mm<ddata['list'].length;mm++)  {
      let zz=ddata['list'][mm];
      vlistUse.push(zz);
      nadd++;
   }
   let z1={'date':nowTime,'list':vlistUse,'nretain':nretain,'nremove':nremove,'nadd':nadd,'nportfolios':vlistUse.length,
       'pInitsNew':false,'pModsNew':false};

   if (nremove>0) {              // also these !
       let pInits=allCurrentData['portfolioInit'];
       let pMods=allCurrentData['portfolioModifications'];
      for (pp1 in rlist) {
           if (pInits['list'].hasOwnProperty(pp1)) delete pInits['list'][pp1];
           if (pMods.hasOwnProperty('list') ) {            // modifications are odd if there are none
             if  (typeof(pMods['list'])=='object') {
               if (pMods['list'].hasOwnProperty(pp1) ) delete pMods['list'][pp1];
             }
          }
      }
      z1['pInitsNew']=pInits;
      z1['pModsNew']=pMods;
   }

   return z1 ;
}

//===========
// save the formatted portoflios .. local

function  saveSimInvLocal_portfolios(vv) {

   let nowTime=wsurvey.get_currentTime(0);

    let vvL={};
    vvL['date']=nowTime;
    vvL['content']={};
    vvL['content']['date']=nowTime;
    vvL['content']['list']=simInvEncrypt(vv['list'],encryptionKey);
    simInv_localVar('portfolios',vvL);        // save to localStorage (and update lastChange)

// removals? update portfolioInit and portfolioModifications
   if (vv['pInitsNew']!==false) {
       let vvL2={}
       vvL2['date']=nowTime;
       vvL2['content']={};
       vvL2['content']['date']=nowTime;
       let pinits= vv['pInitsNew'] ;
       vvL2['content']['list']= simInvEncrypt(pinits['list'],encryptionKey);
       simInv_localVar('portfolioInit',vvL2);        // save to localStorage
   }
   if (vv['pModsNew']!==false) {
       let vvL2={}
       vvL2['date']=nowTime;
       vvL2['content']={};
       vvL2['content']['date']=nowTime;
       let pmods= vv['pModsNew'] ;
       vvL2['content']['list']= simInvEncrypt(pmods['list'],encryptionKey);
       simInv_localVar('portfolioModifications',vvL2);        // save to localStorage
   }

   let bmess=vv['nportfolios']  +' portfolios :  after '+vv['nretain']+' retained, '+vv['nremove']+' removed, '+vv['nadd']+' added (local storage) ';
   if (vv['nadd']>0) bmess+= '<br> After reloading -- you can  <button>&#128065; portfolios</button> to specify the asset mix of the newly added portfolios ';
    displayResponseFromServer(bmess,'portfoliosTableButton');

   return 1;
}

//===========
// save the formatted portoflios .. online
function  saveSimInvOnline_portfolios(vv) {

    let vvL={};
   let nowTime=wsurvey.get_currentTime(0);

    vvL['date']=nowTime;
    vvL['list']=simInvEncrypt(vv['list'],encryptionKey);
    ddata={'todo':'save','which':'portfolios','data':vvL,'username':userName,'encMd5':encryptionKey_md5} ;

   $.ajax({                                // getSimInvData !
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {
       saveSimInvOnline_portfolios2(response,vv);

   });
   return 1;
}

function saveSimInvOnline_portfolios2(response,vv) {   // clear "removed" from portfolioInit?

 let nowTime=wsurvey.get_currentTime(0);
 if (vv['nremove']==0) {           // nothing else to do?
    let bmess=vv['nportfolios']  +' portfolios :  after '+vv['nretain']+' retained, '+vv['nremove']+' removed, '+vv['nadd']+' added   (to local) ';
    if (vv['nadd']>0) bmess+= '<br> After reloading -- you can  <button>&#128065; portfolios</button> to specify the asset mix of the newly added portfolios ';
    displayResponseFromServer(bmess,'portfoliosTableButton');
     return 1;
  }

// remove portfolios from portfolioInit
    let vvL={};
    let vInit1=vv['pInitsNew'];
    vInit1['date']=nowTime;
    vInit1['list']=simInvEncrypt(vInit1['list'],encryptionKey);
    ddata={'todo':'save','which':'portfolioInit','data':vInit1,'username':userName,'encMd5':encryptionKey_md5} ;

    $.ajax({                                // getSimInvData !
           url: 'simInv2.php',
           type: 'POST',
            dataType: 'json',
           data: ddata
    }).always(function (response) {
      saveSimInvOnline_portfolios3(response,vv);
    });
 return 1;
}

function saveSimInvOnline_portfolios3(response,vv) {   // clear "removed" from portfolioModifications?
     let nowTime=wsurvey.get_currentTime(0);
    let vvL={};
    let vInit1=vv['pModsNew'];
    vInit1['date']=nowTime;
    vInit1['list']=simInvEncrypt(vInit1['list'],encryptionKey);
    ddata={'todo':'save','which':'portfolioModifications','data':vInit1,'username':userName,'encMd5':encryptionKey_md5} ;

    $.ajax({                                // getSimInvData !
           url: 'simInv2.php',
           type: 'POST',
            dataType: 'json',
           data: ddata
    }).always(function (response) {

       let bmess=vv['nportfolios']  +' portfolios :  after '+vv['nretain']+' retained, '+vv['nremove']+' removed, '+vv['nadd']+' added (to local) ';
       if (vv['nadd']>0) bmess+= '<br> After reloading -- you can  <button>&#128065;fsortfolios</button> to specify the asset mix of the newly added portfolios ';
       displayResponseFromServer(bmess,'portfoliosTableButton');
       return 1;

    });
 return 1;
}



//=========================================
// save a portoflioinit
// ..............
function saveSimInv_portfolioInit(ddata) {

   let v0=allCurrentData['portfolioInit'];

   let vlist0=v0['list'];
   if (!jQuery.isPlainObject(vlist0)) {
      v0['list']={} ; // deal with [] init
      vlist0={} ;
   }

   let pname=ddata['list']['name'];

   if (vlist0.hasOwnProperty(pname)) {
     bmess+='<div style="border:3px solid yellow;padding:5px"><b>Warning</b>: entries <b>not saved</b>.<br> ';
     bmess+='The <tt>'+pname+'</tt> portfolio has already been initialized. You can remove it, and then intialize it again ';
     displayStatusMessage(bmess);
     toggleStatusMessage(0);
     return 0;
   }
   v0['list'][pname]=ddata['list'];

   return {'list':v0,'portfolioName':pname} ;

}

//=========================================
// save a portoflioinit : local

function saveSimInvLocal_portfolioInit(ddata) {

   let nowTime=wsurvey.get_currentTime(0);
   let vvL={}
    vvL['date']=nowTime;
    vvL['content']={};
    vvL['content']['date']=nowTime;
    let pinits=  simInvEncrypt(ddata['list']['list'],encryptionKey); ;
    vvL['content']['list']= pinits;
    simInv_localVar('portfolioInit',vvL);        // save to localStorage

    let pname=ddata['portfolioName']
    let bmess=pname +' portfolio initialized with  '+ddata['list']['list'][pname]['assetList'].length+' assets ';
    displayResponseFromServer(bmess,'portfoliosTableButton');

}

//=========================================
// save a portoflioinit  : online

function saveSimInvOnline_portfolioInit(vv) {
   let nowTime=wsurvey.get_currentTime(0);
   let vvL={};
   vvL['date']=nowTime
   vvL['list']=simInvEncrypt(vv['list']['list'],encryptionKey);

    ddata={'todo':'save','which':'portfolioInit','data':vvL,'username':userName,'encMd5':encryptionKey_md5} ;

   $.ajax({                                // getSimInvData !
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {

       let pname=vv['portfolioName']
       let bmess=pname +' portfolio initialized with  '+vv['list']['list'][pname]['assetList'].length+' assets ';

       displayResponseFromServer(bmess,'portfoliosTableButton');

   });
   return 1;
}


//=========================================
// save a portfolioModifications
// ..............
function saveSimInv_portfolioModification(ddata) {
   let v0=allCurrentData['portfolioModifications'];

   let pname=ddata['portfolio'];

   if (!jQuery.isPlainObject(v0['list']))   v0['list']={} ; // deal with [] init
   if (!v0['list'].hasOwnProperty(pname)) v0['list'][pname]={'modList':{}} ; // 1 aug 2023: dates no longer used ,'dates':[]};

   let cdate=ddata['createDate']  ;
   let dateSay=ddata['list']['list']['dateStampSay'];

   v0['list'][pname]['modList'][cdate]=ddata['list']['list']   ;

// 1 aug 2023 -- no longer used (recreated each logon on js side)
//   v0['list'][pname]['modComments'][cdate]=ddata['list']['modComment'];
//   v0['list'][pname]['dates'].push(cdate) ;
//   v0['list'][pname]['dates'].sort(sortNoDuplicates);   // remove duplicates, sort ascenting

   return {'list':v0,'portfolio':pname,'date':cdate,'dateSay':dateSay};

}

//=========================================
// save a portoflioinit : local

function saveSimInvLocal_portfolioModification(ddata) {

   let nowTime=wsurvey.get_currentTime(0);
   let vvL={}
    vvL['date']=nowTime;
    vvL['dog']='spot' ;
    vvL['content']={};
    vvL['content']['date']=nowTime;
    let pinits=  simInvEncrypt(ddata['list']['list'],encryptionKey); ;
    vvL['content']['list']= pinits;
    
    simInv_localVar('portfolioModifications',vvL);        // save to localStorage

  let pname=ddata['portfolio'];
  let bmess=pname +' portfolio modification added (for date: '+ddata['dateSay']+')' ;

  displayResponseFromServer(bmess,'portfoliosTableButton');

}

//=========================================
// save a portoflioinit  : online

function saveSimInvOnline_portfolioModification(vv) {
   let nowTime=wsurvey.get_currentTime(0);
   let vvL={};
   vvL['date']=nowTime
   vvL['list']=simInvEncrypt(vv['list']['list'],encryptionKey);

   ddata={'todo':'save','which':'portfolioModifications','data':vvL,'username':userName,'encMd5':encryptionKey_md5} ;
   $.ajax({                                // getSimInvData !
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {

     let pname=vv['portfolio'];
     let bmess=pname +' portfolio modification added (for date: '+vv['dateSay']+')' ;

     displayResponseFromServer(bmess,'portfoliosTableButton');

   });
   return 1;
}

