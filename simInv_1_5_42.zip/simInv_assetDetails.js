// functions for calculating the attributes of an asset on a given date (using assetHistory)
// called as   makeAssetDetails( assetHistory);  (sort of silly using globals as arguments)
// 8 july 2023 -- add "autoAddEntries"

function makeAssetDetails(aHistory) {
 // assetInterest and assetIncomeGrowth are rates, hence are NOT subject to inflation -- though they could be (if specified as real, rather than nomimal, rates)
//      wsurvey.dumpObj(aHistory,1,' in  makeAssetDetails');
    assetDetails={'assets':{}};           // clear it!
 
  for (let aname in aHistory) {                  // all assets that have some history info
      assetDetails['assets'][aname]={};        // initialize an entry in assetDetails

      assetDetails['assets'][aname]['nHistory']=0;
      let assetType=getAssetType(aname);  // 0:stock, 1: bond, 2:taxdeferred bond, 3: property, 4:incomd    (this is rep

      assetDetails['assets'][aname]['type']=assetType;
      assetDetails['assets'][aname]['dates']=[] ;
      assetDetails['assets'][aname]['datesSay']=[] ;
      assetDetails['assets'][aname]['entries']={}

      let lastDate;
      let a1Use ;
      a1Use=  aHistory[aname] ;  //   add entries to it

// auto add entries? (1 per after the year of the last entry, until end of yearRange?

     for (let ih=0;ih<a1Use.length;ih++) {         // a history entry for this asset -- including "imputed" entries (inflation based predictions)
         let hdate=parseInt(a1Use[ih]['date']);
         lastDate=hdate;
         assetDetails['assets'][aname]['dates'].push(hdate) ;
         let oof1=setEntryDate(hdate);
         assetDetails['assets'][aname]['datesSay'].push(oof1['sayDate']) ;
//          alert('details_1 for '+aname+' / '+ih);
         assetDetails['assets'][aname]['entries'][hdate] =makeAssetDetails_1(aname,ih,assetType );
         assetDetails['assets'][aname]['nHistory']++;  // if one of the  above failed (not currently used)
     }   // ih

// add a far future date. This is useful   when there are  dates after the year range.
     let lastEntry=a1Use[a1Use.length-1];
     lastDate=parseInt(lastEntry['date']) ;  // date of last entry
     let lastDateYear=setEntryDate(lastDate).year;

     let oofFarFuture=setEntryDate(assetDetails_farFuture,12,31) ;
     let hdateF=oofFarFuture['dayCount'];
     assetDetails['assets'][aname]['dates'].push(hdateF) ;
     assetDetails['assets'][aname]['datesSay'].push(oofFarFuture['sayDate']) ;

     assetDetails['assets'][aname]['entries'][hdateF] =makeAssetDetails_1(aname,a1Use.length-1,assetType ); // replicate "last" entry in the far futute
     assetDetails['assets'][aname]['nHistory']++;  // add 1 because of far

// sort by date
       assetDetails['assets'][aname]['dates'].sort(mySortNumeric);

// compute cumulative growth

       makeAssetDetails_histCum(aname,assetType);             // changes assetDetails global -- calculates cumulative vars

  }    // aname

  return  1 ;       // results save in global assetDetails    aHistory
}


function makeAssetDetails_1(a1,hdate,assetType) {
  let stuff={};

  hist1=assetHistory[a1][hdate];
  let isorig=hist1['original'];
  stuff['daysGap']=false ;                // days since prior history entry (will be filled in later, but for first in time will remain 'false'

  if (assetType==0)   {   // stock) ;
      stuff['price']=parseFloat(hist1['assetPrice'])  ;
      stuff['dividend']=parseFloat(hist1['assetDividend'])  ;

      stuff['dividendDaily']=stuff['dividend']/365;

      stuff['growthCum']=false;                 // cumulative (per share) growth (as a multiplier)
      stuff['growthCumAT']=false;                 // after tax cumulative (per share) growth (as a multiplier)

      stuff['earningsCum']=false;               // cumulative (per share) dividend earnings (as a number)
      stuff['earningsCumAT']=false;               // cumulative (per share) dividend earnings (as a number)
      stuff['earningsTaxCum']=false;            //  cumulative taxRate *  dividendDaily
      stuff['earningsLossesCum']=false;            //  cumulative taxRate *  dividendDaily
      stuff['earningsTaxRate']=calcAsset_taxRate(a1,0);  // should be 0

       stuff['addition']=0 ;  //  additions per year (total dollars)
       stuff['additionDaily']=0  ;  //  per day


  } else if (assetType==1 || assetType==2)   {                // bond (regular or tax deferred)
       stuff['interest']=parseFloat(hist1['assetInterest']/100.0 ) ;  // convert from % to a fractional rate (0.04= 4% growth per year)

       let t2=Math.log(1+stuff['interest'])/365;              // not use of log to ensujre that cmulative daily interest is same as yearly
       stuff['interestDaily']=Math.exp(t2);                    // 18 june ... just used for info purposes

       let daAdd= (hist1.hasOwnProperty('assetAddition')) ? parseFloat(hist1['assetAddition']) : 0 ;
       stuff['addition']=daAdd ;  //  addition per year (total dollars)
       stuff['additionDaily']=daAdd/365  ;  //  per day
       stuff['additionCum']=0;               // cumulative (overall) additions

       stuff['growthCum']=false;               // cumulative (per share) interest earnings (as a multiplier)
       stuff['growthCumAT']=false;               // cumulative (per share) interest earnings (as a multiplier)

       stuff['earningsCum']=false;                 // cumulative (per share) growth (as a number)   -- will be growthCum-1  --
       stuff['earningsCumAT']=false;               // cumulative (per share) dividend earnings (as a number)
       stuff['earningsTaxCum']=false;            //   cumulative taxRate *  dividendDaily
       stuff['earningsLossesCum']=false;            //  cumulative taxRate *  dividendDaily

       stuff['earningsTaxRate']=calcAsset_taxRate(a1,0);  // should be 0

  } else if (assetType==3) {              // property
              stuff['salePrice']=parseFloat(hist1['assetSalePrice'])  ;         // the "profit" if sold today (sale price - remaining debt)
              stuff['netRent']=parseFloat(hist1['assetNetRent'])  ;    // costs (or earnings) from owning.. can incluce mortgage interest payments
              stuff['netRentDaily']=stuff['netRent']/365;             // per day

              stuff['earningsCum']=false;                 //  sum of positive netRentDaily.. could be negative
              stuff['earningsCumAT']=false;                 //  after tax sum of positive netRentDaily.. could be negative
              stuff['earningsTaxCum']=false;            //  tax on earnings -- min of 0
              stuff['earningsLossesCum']=false;            //  cumulative taxRate *  dividendDaily
              stuff['earningsTaxRate']=calcAsset_taxRate(a1,0);

            stuff['addition']=0 ;  //  additions per year (total dollars)
            stuff['additionDaily']=0  ;  //  per day

   } else if (assetType==4) {              // income

// if constantIncome, don't grow it again!
        stuff['income']=parseFloat(hist1['assetIncome'])  ;         // the "profit" if sold today (sale price - remaining debt)
        stuff['incomeDaily']= stuff['income']/365  ;         // the "profit" if sold today (sale price - remaining debt)

       stuff['growthRate']=parseFloat(hist1['assetIncomeGrowth'] ) ;  // use fraction as is

//       stuff['growthRate']=parseFloat(hist1['assetIncomeGrowth']/100.0 ) ;  // 14 july deprecated ... convert from % to a fractional rate (0.04= 4% growth per year)

//       let t2=Math.log(1+stuff['growthRate'])/365;              // not use of log to ensujre that cmulative daily interest is same as yearly
//       stuff['growthRateDaily']=Math.exp(t2);                    // 18 june ... just used for info purposes. 14 july -- depreacated (use fraction of inflation)

        stuff['earningsCum']=false;                 //  sum of positive netRentDaily.. could be negative
        stuff['earningsCumAT']=false;                 // after tax sum of   netRentDaily.. could be negative
        stuff['earningsTaxCum']=false ;            //  tax on earnings -- min of 0
        stuff['earningsLossesCum']=false;            //  cumulative taxRate *  dividendDaily
        stuff['earningsTaxRate']=calcAsset_taxRate(a1,0);

       stuff['addition']=0 ;  //  additions per year (total dollars)
       stuff['additionDaily']=0  ;  //  per day


   } else {                             // should never happen
         alert('unknown asset type ('+assetType+') in  makeAssetDetails_1 for '+a1);
         stuff=false;
   }
   stuff['originalValue']=isorig ;
    return stuff ;
}

//=================
// calculate cumulative values using global  assetDetails -- the history entries
// calls  calcAssetGrowth using information stored in  assetDetails, and updates assetDetails

function makeAssetDetails_histCum(a1,assetType) {
   let dates=assetDetails['assets'][a1]['dates'];
   let nHistory=assetDetails['assets'][a1]['nHistory'];

   let date1=dates[0];

   let priorStuff=calcAssetGrowth(false,a1,0,false,false,'init asset history');
   for (let kvar in priorStuff) assetDetails['assets'][a1]['entries'][date1][kvar]=priorStuff[kvar];  // initialize the first entry in an asset's history


// step through the asset's history  -- accumulating on top of the prior entry
   let date2;
   let dovars=['price','dividend','interest','netRentDaily','incomeDaily','addition','additionDaily'];

   for  (let ii=1;ii<nHistory;ii++) {
      date2=dates[ii];
      let daysGap=date2-date1;
      let att1={},att2={};
      for (let jj=0;jj<dovars.length;jj++) {
          let dvar=dovars[jj ];
          att1[dvar]= (assetDetails['assets'][a1]['entries'][date1].hasOwnProperty(dvar)) ?  assetDetails['assets'][a1]['entries'][date1][dvar] : 0 ;
          att2[dvar]= (assetDetails['assets'][a1]['entries'][date2].hasOwnProperty(dvar)) ?  assetDetails['assets'][a1]['entries'][date2][dvar] : 0 ;
      }
      let stuff=calcAssetGrowth(priorStuff,a1,daysGap,att1,att2,'make asset history '+ii)   ;

      for (let kvar in stuff) assetDetails['assets'][a1]['entries'][date2][kvar]=stuff[kvar];

      priorStuff=stuff ;
      date1=date2;
  }   // nhistory

  return 1;
}
// =========== end of assetdetails for history entries.


//==================
// update asset histories using information on "constantIncome=1" assets
// create aname.$baseDate entries in assetHistory  ... starting on astart (with interpolated values)
//  and then every year using growth applied to astart
// Note this 'every year' is a growth calculation suitable for use in linear interpolation.
//  That is: calcAssetValue will NOT attempt to do  a growth calculation for each .
// Note that for normal assets, the final price (or income) holds for all future dates.
// For an assset with constant growth, that's a bad assumption!  
//  3 July: may want to cap the constant growth after T years 
//  11 july: updates assetLookup global

function updateAssetHistory_income(doThese) {
   let doThese2={};
   for (let vasset in doThese) {
      for (let istart in doThese[vasset]) {
       let makeIt=vasset+'.$'+istart;
       let cvals=calcAssetValues_simple(vasset,istart) ;   
       if (cvals[0]!=1) {
           alert('error: see console.log ');
           return false;
       }
       doThese2[makeIt]=cvals[1];
       doThese2[makeIt]['startDate']=istart;
       doThese2[makeIt]['baseName']=vasset;
     }
   }

   let oofL=setEntryDate(lastYearUse,12,31);
   let lastYearDayCount=oofL['dayCount'];
   let nDays=365 ;         // every year. Exact dates don't matter
   for (let zasset in doThese2) {                  // add info to doThese2
      doThese2[zasset]['values']={} ;
      let startDate=parseInt(doThese2[zasset]['startDate']);
      let startAmount=parseFloat(doThese2[zasset]['income']);
      let infFraction=parseFloat(doThese2[zasset]['growthRate']);

      let dateUse=startDate ;
      do {
          let gfactor=calcInflation(startDate,dateUse);
          let gdiff=gfactor-1;
          let gdiff2=infFraction*gdiff;
          gfactor=gdiff2+1 ;
          let income2=startAmount*gfactor ;
          doThese2[zasset]['values'][dateUse]=[gfactor,income2];
          dateUse=dateUse + nDays ;
      }        // yearly dates
      while (dateUse<=lastYearDayCount) ;

// add one way  in the far future (accuracy won't be good, but better than frozan at last value
      let oof4=setEntryDate(theMaxYear,1,1);
      let dateUse2=oof4['dayCount'];

      let gfactor2=calcInflation(startDate,dateUse2);
          let gdiff=gfactor2-1;
          let gdiff2=infFraction*gdiff;
          gfactor2=gdiff2+1 ;
      let income22=startAmount*gfactor2  ;

       doThese2[zasset]['values'][dateUse2]=[gfactor2,income22];
   }         // zasset  -- expanding doThese2

   for (let zasset in doThese2) {     // add to assetHistory -- the .$xxx "shortcut" assets

       let origAsset=doThese2[zasset]['baseName'];
       assetLookup[origAsset]['contantIncomeVariants'].push(zasset);      // initalized in makeAssetLookup

      let addme=[];
      assetHistory[zasset]=[];
      let startDate=doThese2[zasset]['startDate'];
      let startIncome=doThese2[zasset]['income'];
      let grateYear=doThese2[zasset]['growthRate'];
      let baseName=doThese2[zasset]['baseName']

      for (let idate in doThese2[zasset]['values']) {
         let dsay=setEntryDate(idate).sayDate;
         let acomment=baseName+': '+startIncome.toFixed(0) +' on '+startDate+ ' @ '+grateYear.toFixed(4)+' : for '+dsay ;
         let grate=doThese2[zasset]['values'][idate][0];
         let aincome=doThese2[zasset]['values'][idate][1];
         let addme={'date':idate,
                   'comment':acomment,
                   'assetPrice':0,'assetDividend':0,'assetInterest':0,'assetSalePrice':0,'assetNetRent':0,
                   'assetIncome':aincome,'assetIncomeGrowth':grate }
         assetHistory[zasset].push(addme)  ; // no need to sort (since created in ascencing order
     }       // idate
   }       // zsset

// saves stuff to global (assetHistory)
   return 1; 

 }

 

// ===================================================
// functions to calculate asset values on a gven date, using an asset's history
// ===================================================

// =====================================
// compute asset values for the display dates , and for every nth year between firstYearUse and lastYearUse
// nthYear1 not used (could be frequency of entries). 5 July: every year

// uses dates in viewDates  -- buitl from user specific explicit dates, 
//  and  (from user specific settings) "n times a year" dates  between  'firstYearUse' and 'lastYearUse'
//   and  entry dates from the assetHistory

function   makeAssetValues_viewdates(nthYear1) {

  let dodates={'details':{},'list':[]};

  allList=[];
// the display dates
  for (let jj=0;jj<viewDates['list'].length;jj++) {
    allList.push(parseInt(viewDates['list'][jj]));
  }

// dates of assset history entries
  for (let ana in assetDetails['assets'] ) {
      for (let idd=0;idd<assetDetails['assets'][ana]['dates'].length;idd++) {
         allList.push(parseInt(assetDetails['assets'][ana]['dates'][idd]));
      }
      let nhist=assetDetails['assets'][ana]['nHistory'];
   }

// first and last year of range
    let oofX=setEntryDate(firstYearUse,1,1);
    let dcountX=parseInt(oofX['dayCount']);
    allList.push(parseInt(dcountX));

    let oofY=setEntryDate(lastYearUse,1,1);
    let dcountY=oofY['dayCount'];
    allList.push(parseInt(dcountY)) ;

// periodic betwween first and last year of range  ?
    for (jj=firstYearUse;jj<=lastYearUse;jj++) {
        let oof2=setEntryDate(jj,1,1);
        let dcount=oof2['dayCount'];
        allList.push(parseInt(dcountY));
   }

   allList.sort(mySortNumeric);

  let allList2=[];
  let iwas=false;
  for (let ij=0;ij<allList.length;ij++) {    // remove duplicates
     jdate=allList[ij];
     if (jdate!==iwas) {
        iwas=jdate;
        allList2.push(iwas);
     }
  }

  return allList2;

}

//===================
// calcAssetValues, with check for "constantIncome" asset
// if constantINcome asset, change the name to reflectd the incomeStart date 
// if no incomeStart date -- fatal error
// anENtry is from assetList, or from assets... for this asset ... must have'incomeStart' and 'assetType' property

function calcAssetValues_2(anAsset0,aDate,isMod,startDate)   {

  if (arguments.length<3) isMod=0;
  if (arguments.length<4) startDate=false ;
  let anAsset=anAsset0;
  atype=getAssetType(anAsset0);
  if (startDate!==false && startDate!=='false') {
    let suffix=jQuery.trim(startDate);
    anAsset=anAsset0+'.$'+suffix;
  }
  let dval1= calcAssetValues(anAsset,aDate) ;       // calcAssetValues_2: not constantIncome

  return dval1;

}

// =====================================
/// calc asset values for an asset on a date (using asset history info in assetDetails
//  aDate can be any date, not necessarilyi one created by  makeAssetDetails (using explicit entries in assetHistory)
// This is accomplisehed by using linear intrerpolation between existing entries (in assetDetails), and interpolating between them
// Thus: if aDate is before   the first entry in an asset's history: an error occurs.
//       NOte that the first entry is always the "initialization" entry -- which can NOT be replaced.
//       if after, an error occurs. That's why a jan/1/2100 o  entry is always added to each asest's history (by makeAssetDetails)
// Uses  calcAssetValues_simple for intepolated prices, and then calcAssetGrowth for "cumulative growth"
//
//  return [anAsset,aDate,date0,date1,arfNew,assetType]
// calcValues is object with price, etc attribues,  and cumulative info fields

function calcAssetValues(anAsset,aDate) {

// STEP 1: interpolate values
  let errors=[];
  let cvals=calcAssetValues_simple(anAsset,aDate,1) ;   // returns  [status,interpolatedAttributes,assetType,date0,date1,ahist]


  if (cvals===false) {
     displayStatusMessage('Error: no assetType for '+anAsset,2);
     return false;       // bad assetytpe... should never happen
  }
  if (cvals[0]!=1) {
     displayStatusMessage('<br>calcAsset problem: '+cvals[3],2);

     return false;
  }

// now do asset growth (from prior to "interpolated" current value)
// the variables to "grow" -- some of the will be ignored (depending on asset type)
  let arfNew=cvals[1];
  let assetType=cvals[2];
  let date0=cvals[3],date1=cvals[4];
  let ahist=cvals[5];

  let arfWas=ahist['entries'][date0];    // prior

   let dovars=['price','dividend','interest','netRentDaily','netRent','income','incomeDaily','salePrice','addition','additionDaily'];
   let att1={},att2={};
   for (let jj=0;jj<dovars.length;jj++) {
          let dvar=dovars[jj];
          att1[dvar]= (arfWas.hasOwnProperty(dvar)) ? arfWas[dvar] : 0 ;  // arfWas also has prior cum values
          att2[dvar]= (arfNew.hasOwnProperty(dvar)) ?  arfNew[dvar] : 0 ;
    }
   let daysGap1=arfNew['daysToPrior'];

//Step 2: compute cumulative values caculate cumulative grow stuff, given the attributes on the "base" and "current" dates

    let stuff=calcAssetGrowth(arfWas,anAsset,daysGap1,att1,att2,'calcAssetValues:  for '+aDate)   ;

    let cumvars=[];
    for (let aa in stuff) {
        cumvars.push(aa);
        arfNew[aa]=stuff[aa];  // copy the "cumulative" stuff
    }
    arfNew['_cumVars']=cumvars;        // for debugging

   return [anAsset,aDate,date0,date1,arfNew,assetType];

}

//======================
// calculate asset values, just prices etc (no cumulative stats)
// returns on succes
//   [1,interpolatedAttribes,assetType,date0,date1,ahist] == date0 and date1 bracket adate
// error returns:
//    false: bad assettype or other wierd error
//    [errStat,false,assetType]
//        errStats: 2=no history for this asset, 3: before first history entry, 4: after last (last is usually autoadded using theMaxYear

function calcAssetValues_simple(anAsset,aDate,idebug) {
  if (arguments.length<3) idebug=0;
  assetType=getAssetType(anAsset);
  if (assetType===false) return false ;

// note that first step in "contantIncome" is to get the "interpolated" inome/growth for the incomeStream on a given date
// the next step is to grow this

   if (!assetDetails['assets'].hasOwnProperty(anAsset)) {
     anAsset=getAssetFamily(anAsset);
   }

   if (!assetDetails['assets'].hasOwnProperty(anAsset)) {
       alert('calcAssetValues_simple: can not find '+anAsset);
       return false;
   }

   let ahistList=assetDetails['assets'][anAsset] ;   // the history of "explicit" entries (specifying an asset's attribute)

  let nHistory=ahistList['nHistory'];             // # of entries in thish istory

  if (nHistory==0) {
     return [2,false,assetType,'No entries for asset: '+anAsset ];
  }

// some info available
  let last1=ahistList['dates'][nHistory-1];  // the last history entry (in far future)

   if (aDate<ahistList['dates'][0])  {
      let nowDate=setEntryDate(aDate).sayDate;
      let dateFirst=setEntryDate(ahistList['dates'][0]).sayDate;

      return [3,false,assetType,'Date '+nowDate+' before first entry for asset <tt>'+anAsset+'</tt> (on '+dateFirst+')'];
   }
   if (aDate>=last1){
      let nowDate=setEntryDate(aDate).sayDate;
      let dateLast=setEntryDate(last1).sayDate;
      return [4,false,assetType,'Date  '+nowDate+' is after last date for '+anAsset+': '+dateLast];                // too late
   }

//given a far future entry (add by simIn, for 2100) there '4' should not happen. If it does, update theMaxYear

// if here, got info and a legit date

// find assetHistory entries that bracked aDate (the test above guarantee this will work)

  let ientry=false,postEntry=false;  ;
  for (jj=nHistory-1;jj>=0;jj--) {                      
       let trydate=ahistList['dates'][jj];
      if (trydate<=aDate) {                    // use this date!
         ientry=jj   ;
         break;
      }
      postEntry=jj ;
  }

  let date0=ahistList['dates'][ientry];
  let date1=ahistList['dates'][postEntry];

  let doInterp=0;

// This does the work  ..........

  let oog=calcAssetValues_interpolate(anAsset,aDate,date0,date1,assetType );  // interpolated  asset values (price, dividend, intrest, ...

  let arfNew=oog[0];      // the "current" prices, etc (after interpolation)
//  let arfBase=oog[1];     // base  price, etc (not currently used)


  if (arfNew['daysToPrior']==0) {
     arfNew['doInterp']=0 ;        // 0: no interplocation needed
  } else {
     arfNew['doInterp']=1 ;         // interpolation needed
  }

  return [1,arfNew,assetType,date0,date1,ahistList] ;

}

///========   ahist
// conpute values of an asset variable, using interpoloation if neceeary
// uses assetValues_varlistA for list of variables that might be in  an asset
function calcAssetValues_interpolate(anAsset,aDate,date0,date1,assetType ) {
  let daVals={};
  if (aDate==date0  )  {  // got an  actual asset history entry -- no need to interpolate
     for (let avar in assetDetails['assets'][anAsset]['entries'][aDate]) {
         daVals[avar]=assetDetails['assets'][anAsset]['entries'][aDate][avar];
     }
     let d0=daVals;
     daVals['daysToPrior']=0;
     return [daVals,d0] ;
  }

// inteproloate!  Note that for some of the "growth" vars, a recalc using interpolated rates would be more acccurate (30 june hence the suggestion for not infrequent calculations

  let myGap=aDate-date0 ;       // days after "just before" history entry
  let daysGap=assetDetails['assets'][anAsset]['entries'][date1]['daysGap'];  // days between "just before" and "just after" history entries
  let dmult=myGap/daysGap ;

  for (let jj=0;jj<assetValues_varlistA.length;jj++) {
      let avar=assetValues_varlistA[jj];

      if (!assetDetails['assets'][anAsset]['entries'][date1].hasOwnProperty(avar)) continue ;  // not used  for this asset

      if (!assetDetails['assets'][anAsset]['entries'].hasOwnProperty(date0) ) {
         let zmess='Error in calcAssetValues_interpolate for: '+ anAsset+' ('+assetType+') on '+aDate+' ::  from '+date0+ ' to '+ date1  ;
         showDebug(assetDetails['assets'][anAsset]['entries'],zmess,1);         // calcAssetValues_interpolate error
      }

      let aval1=assetDetails['assets'][anAsset]['entries'][date0][avar] ;
      let aval2=assetDetails['assets'][anAsset]['entries'][date1][avar] ;
      let dval=aval2-aval1;
      let avalUse=aval1+ (dval*dmult);
      daVals[avar]=avalUse;
  }

  if ( assetType==1 || assetType==2 ) {
       let z1=daVals['interest'];
       let z1a=Math.log(1+z1);
       let z2=z1a/365;
       daVals['interestDaily']=Math.exp(z2);       // 19 june interestDaily not used (
  }


  daVals['daysToPrior']=myGap;

  return [daVals,assetDetails['assets'][anAsset]['entries'][date0]] ;


}

//===========================
// calculate   asset grwoth between two dates. Typically the first is an existing (with an an entry in assetDetails
// returns object with properties:
//  growthCum growthCumAT  earningsCum  earningsCumAT earningsTaxCum  earningsLossesCum   earningsTaxRate  earningsThisGap
//    priorStuff : results from prior call to calcAssetGrowth
//    aName:  the assetName
//    daysGap : difference between two dates
//    att1 : attributes on the first date
//    att2  : attributes on the second date
// Special case: if priorStuff==false, return an "initialization" (values of the properties are one or 0). All other args (except aName) are ignored
//     This is useful to do first, for use as the priorStuff argument in a next call
//
// att1 and att2 depend on the asset (its assetType)
//    0 : price and dividend
//    1:   interest rate and additions
//    2 : interest rate  and additions
//    3:   netRentDaily
//    4:  incomeDaily

// Note that  asset specific earningsTaxRate is used (based on the asset)  -- it should be in priorStuff; and is calculuated
// when priorStuff=false
// example:  let priorStuff=calcAssetGrowth(false,assetName,0,false,false,'init asset history');

function calcAssetGrowth(priorStuff,aName,daysGap,att1,att2,cmt) {
   let stuff={};

//  for (let zzz in priorStuff) stuff[zzz+'_base']=priorStuff[zzz];  // initializse

   if (priorStuff===false) {
      stuff['growthCum']=1.0 ;
      stuff['growthCumAT']=1.0 ;
      stuff['additionCum']=0;
      stuff['earningsCum']=0.0 ;
      stuff['earningsCumAT']=0.0 ;
      stuff['earningsTaxCum']=0.0 ;
      stuff['earningsLossesCum']=0.0 ;
      stuff['earningsThisGap']=false;
      stuff['daysGap']=false;
      stuff['comment']=cmt;
      stuff['netCumIncomeAT']=0 ;
      stuff['netCumRentAT']= 0
      stuff['earningsTaxRate']=calcAsset_taxRate(aName,0);  // asset specific (but not date dependent)
      return stuff;
   }

  stuff['daysGap']=daysGap;
  stuff['comment']=cmt;

  let earningsTaxRate =calcAsset_taxRate(aName,0);  // asset specific (but not date dependent)

  let taxf=1- earningsTaxRate ;

  let assetType=getAssetType(aName);

   if (assetType==0) {                              // stock   -- note that dividends can NOT be negative. So losses are not possible

        let D_1=parseFloat(att1['dividend']) ;
        let D_2=parseFloat(att2['dividend']) ;
        let P_1=parseFloat(att1['price']) ;
        let P_2=parseFloat(att2['price']) ;

        let agrowth=assetGrowth_dividend(D_1,D_2,P_1,P_2,daysGap) ;         // Growth between dates  ....
        stuff['growthCum']=priorStuff['growthCum']*agrowth;                  // cumulativive is growth * prior cumulative

        let D_1b=D_1*taxf ;                    // now for after tax...
        let D_2b=D_2*taxf ;

        let agrowth2=assetGrowth_dividend(D_1b,D_2b,P_1,P_2,daysGap) ;   // after tax growth rate  (note that prices used are not affected by tax)
        stuff['growthCumAT']=priorStuff['growthCumAT']*agrowth2;

        let D_1_daily= D_1/365;              // now do dividends
        let D_2_daily= D_2/365;

        let s1= assetGrowth_sum(daysGap,D_1_daily,D_2_daily) ;
        stuff['earningsCum']=priorStuff['earningsCum']+s1;

        stuff['earningsThisGap']=s1;

        let D_1_dailyAT=D_1_daily*taxf  ;
        let D_2_dailyAT=D_2_daily*taxf ;

        let s2= assetGrowth_sum(daysGap,D_1_dailyAT,D_2_dailyAT) ;
        stuff['earningsCumAT']=priorStuff['earningsCumAT']+s2;

        stuff['earningsTaxCum']=stuff['earningsCum'] - stuff['earningsCumAT'] ;

        stuff['earningsLossesCum']=0 ;     // non-neg dividends means losses not possible

       stuff['netCumIncomeAT']=0 ;
       stuff['netCumRentAT']= 0;

        return stuff;
   }

    if (assetType==1  ) {                 // regular bond -- interest can be < 1.0, so losses permitted

        let I_1=att1['interest'] ;
        let I_2=att2['interest'] ;
        let agrowth=assetGrowth_interest(I_1,I_2,daysGap) ;

        stuff['growthCum']=priorStuff['growthCum']*agrowth;
        stuff['earningsCum']=stuff['growthCum']-1;
          stuff['earningsThisGap']=stuff['earningsCum']-priorStuff['earningsCum'];

//          stuff['earningsPrior']=priorStuff['earningsCum']


        if (agrowth>=1.0 ) {        // growth, so taxable...
          let I_1b=I_1*taxf ;
          let I_2b=I_2*taxf ;
          let agrowth2=assetGrowth_interest(I_1b,I_2b,daysGap) ;
          stuff['growthCumAT']=priorStuff['growthCumAT']*agrowth2;
          stuff['earningsCumAT']=stuff['growthCumAT']-1;

          stuff['earningsTaxCum']= stuff['earningsCum']-  stuff['earningsCumAT']  ;
          stuff['earningsLossesCum']=0 ;

        } else {           // shrinkage  -- so no taxes
           stuff['growthCumAT']=stuff['growthCum'];
           stuff['earningsCumAT']=stuff['earningsCum'] ;
           stuff['earningsTaxCum']=priorStuff['earningsTaxCum'] ;     // no tax paid  this period
           stuff['earningsLossesCum']=priorStuff['earningsLossesCum']+(agrowth-1) ;  // this period's loss
        }

        let A_1=parseFloat(att1['additionDaily']) ;
        let A_2=parseFloat(att2['additionDaily']) ;
        let adds= assetGrowth_sum(daysGap,A_1,A_2)
        stuff['additionCum']=priorStuff['additionCum']+adds;                  // cumulativive is growth * prior cumulative

        stuff['netCumIncomeAT']=0 ;
        stuff['netCumRentAT']= 0;

        return stuff ;

     }

     if (assetType==2) {                 //  taxdeferred bond    -- no tax on earnings

        let I_1=att1['interest'] ;
        let I_2=att2['interest'] ;
        let agrowth=assetGrowth_interest(I_1,I_2,daysGap) ;

        stuff['growthCum']=priorStuff['growthCum']*agrowth;
        stuff['growthCumAT']=stuff['growthCum'];

        stuff['earningsCum']=stuff['growthCum']-1;
        stuff['earningsCumAT']=stuff['earningsCum'] ;

          stuff['earningsThisGap']=stuff['earningsCum']-priorStuff['earningsCum'];

        stuff['earningsTaxCum']=0 ;     // no tax EVER paid
        stuff['earningsLossesCum']=0 ;     // and NEVER losses (since its all reinvested

        let A_1=parseFloat(att1['additionDaily']) ;
        let A_2=parseFloat(att2['additionDaily']) ;
        let adds= assetGrowth_sum(daysGap,A_1,A_2)
        stuff['additionCum']=priorStuff['additionCum']+adds;                  // cumulativive is growth * prior cumulative

       stuff['netCumIncomeAT']=0 ;
       stuff['netCumRentAT']= 0;
        return stuff;
     }

   if (assetType==3) {                 // property (no growth rate calculations)
        let N_1=att1['netRentDaily'] ;
        let N_2=att2['netRentDaily'] ;
        let ss2= assetGrowth_sum(daysGap,N_1,N_2) ;
        stuff['earningsCum']=priorStuff['earningsCum']+ss2;
        stuff['earningsThisGap']=ss2;

        if (ss2>=0)  {          // gains, so taxes
           let N_1b=N_1*taxf ;
           let N_2b=N_2*taxf;
           let ss2AT=assetGrowth_sum(daysGap,N_1b,N_2b) ;
           stuff['earningsCumAT']=priorStuff['earningsCumAT']+ss2AT;
           stuff['earningsTaxCum']= stuff['earningsCum']-  stuff['earningsCumAT']  ;
           stuff['earningsLossesCum']=priorStuff['earningsLossesCum'] ;
       } else {                  // lossses, so  no taxes
           stuff['earningsCumAT']=stuff['earningsCum'] ;
           stuff['earningsTaxCum']=priorStuff['earningsTaxCum'];
           stuff['earningsLossesCum']= priorStuff['earningsLossesCum']+ss2 ;

       }
       stuff['netCumRentAT']= stuff['earningsCumAT'] ;
       stuff['netCumIncomeAT']= 0;

        return stuff;

     }

      if (assetType==4) {                 // income (-income is possible)

        let N_1=att1['incomeDaily'] ;
        let N_2=att2['incomeDaily'] ;
        let ss2= assetGrowth_sum(daysGap,N_1,N_2) ;
        stuff['earningsCum']=priorStuff['earningsCum']+ss2;
        stuff['earningsThisGap']=ss2;

        if (ss2>=0)  {          // gains, so taxes
           let N_1b=N_1*taxf;
           let N_2b=N_2*taxf ;
           let ss2AT=assetGrowth_sum(daysGap,N_1b,N_2b) ;
           stuff['earningsCumAT']= priorStuff['earningsCumAT']+ss2AT;
           stuff['earningsTaxCum']=stuff['earningsCum']-  stuff['earningsCumAT']  ;
           stuff['earningsLossesCum']=priorStuff['earningsLossesCum'] ;


       } else {                  // lossses, so  no taxes
           stuff['earningsCumAT']=stuff['earningsCum'] ;
           stuff['earningsTaxCum']=priorStuff['earningsTaxCum'];
           stuff['earningsLossesCum']= priorStuff['earningsLossesCum']+ss2 ;
       }
       stuff['netCumIncomeAT']= stuff['earningsCumAT'] ;
       stuff['netCumRentAT']= 0;

        return stuff;
  }
  alert('Error in calcAssetGrowth: no such assetType ('+assetType+') for '+aName);
  return false;
}



//==========

// compute cumulative growth in stock; dividend changes from d0a to d1a, prices from p0a to p1a, over tspan # days
// Dividends and prices are in $
// Note that dividends are "yearly" (they will be converted to daily). PRices are as of a given date
// uses integral of divFrac:  ln( 1 +   ((D_0 + g_d*x   ) / (P_0+g_p*x )  )
// uses  https://www.integral-calculator.com/

//
function assetGrowth_dividend(D0a,D1a,P0a,P1a,tspan )  {         // by day

  if (tspan==0) return  1.0 ;

   let D_0=D0a/365;
   let D_1=D1a/365;
   let P_0=P0a;
   let P_1=P1a;
   if (P_0==P_1) P_1+=0.000001 ; // hack to deal with failure of integral

  let  g_d=(D_1-D_0)/(tspan);
  let  g_p=(P_1-P_0)/(tspan);

  let x=tspan-1 ;
  let vv1=((P_0+D_0)*Math.log(Math.abs((g_p+g_d)*x+P_0+D_0)))/(g_p+g_d)-(P_0*Math.log(Math.abs(g_p*x+P_0)))/g_p+x*Math.log((g_d*x+D_0)/(g_p*x+P_0)+1);

  x=0;
  let vv0=((P_0+D_0)*Math.log(Math.abs((g_p+g_d)*x+P_0+D_0)))/(g_p+g_d)-(P_0*Math.log(Math.abs(g_p*x+P_0)))/g_p+x*Math.log((g_d*x+D_0)/(g_p*x+P_0)+1);

  return Math.exp(vv1-vv0);
}

//==========
// uses integrals produced by https://www.integral-calculator.com/
// uses integral of :  ln(  exp(  ln(I_0 + x*g_i)/365)  )
// assume trend is linear in yearly rates, each day the rate is converted to daily
// I_0 and I_1 should be 0.xx ... so 4% growth would be 0.04

function assetGrowth_interest(I_0a,I_1a,tspan) {

  if (tspan==0) return  1.0 ;

 if (I_1a===I_0a) I_1a+=0.0000000001 ;   // integral fails if equal
 let g_i=(I_1a-I_0a)/(tspan);
 let I_0=I_0a+1.0;
 let x=tspan-1;
 let vv1=((g_i*x+I_0)*Math.log(g_i*x+I_0)-g_i*x)/ (365*g_i)  ;

   x=0 ;
 let vv0=((g_i*x+I_0)*Math.log(g_i*x+I_0)-g_i*x)/ (365*g_i)  ;

  return Math.exp(vv1-vv0);

}

//=======================
// change in "cash" asset, given a "starting cash" CA and ending Cash CB ... where both of these are simple accumulations
//  this will convert this total accumulation into a per period addition; and grow the start (CA) and all the additions
//  -- so early additions  grow more (since they have a longer time to grow)
// note that tspan imples: growth starts beginning of a day, cash recieved at end.
// to tspan=1 means initial value grows at rate over the first day, and then the difference is added at the end of tye day
//  CA  : starting value
//  CB  : endiing value
//  tspan : number of days between start and end
//  yRate : yearly interest rate. yRate should be 0.xx (so 0.04 = 4%)
//          It will be converte to a daily rate
// https://www.varsitytutors.com/hotmath/hotmath_help/topics/geometric-series
// based on
//  [ a1 * (1-r^n) ]  /  (1-r)
// a1= first term'
//  r st a2=a1*r, a3=a2*r
//  n # of values to sum
//  example:    a=30, t=4, r= 1.05  =  30*(1-1.05^4) / (1-1.05) ==  30*(1-1.2155)/(1-1.05) =  -6.465 / -0.05   = 129.303
//   = 30 + 30*1.05 + 30*1.05^2 + 30*1.05^3
//===============
//===============
function assetGrowth_cash(CA,CB,tspan,yRateU,yRateD) {

   if (tspan==0) return 0 ;         // no time span so no growth ;

   if (CA==0 & CB==0) return 0 ;      // degenerate case
   if (tspan<1) return CB ;        // immediate change, no growth

   CA=parseFloat(CA);
   CB=parseFloat(CB);
   tspan=parseInt(tspan);
   yRateU=parseFloat(yRateU);
   yRateD=parseFloat(yRateD);

// if both are greater, or lesser, than  0,.... simple  segment > 0
   if ( (CA>=0 && CB>=0 ) || (CA<=0 && CB<=0 ) ) {         // simple case, both on same side of 0

      let rtmp= (CA>=0 && CB>=0) ? 1+yRateU : 1+yRateD;        // convert 0.xx to 1.xx  (growth rate) -- the above 0 rate
      if (rtmp==1.0) return CB ;                             // no growth
      let y1=Math.log(rtmp)/365;
      let irate1=Math.exp(y1);
      let yy=assetGrowth_cash2(CA,CB,tspan,irate1) ;
      return yy ;
   }

// else do in 2 segments
    let dabs=Math.abs(CA-CB);

    let rtmp0=1+yRateD ;        // convert 0.xx to 1.xx  (growth rate) -- the above 0 rate
    let y0=Math.log(rtmp0)/365;
    let irate0=Math.exp(y0);

    let rtmp1=1+yRateU ;        // convert 0.xx to 1.xx  (growth rate) -- the above 0 rate
    let y1=Math.log(rtmp1)/365;
    let irate1=Math.exp(y1);

    let df1=Math.abs(CA)+Math.abs(CB);
    let tt1=Math.abs(CA)/df1 ;
    let yrt=parseInt(tt1*tspan) ;
    let yr1=Math.max(1,yrt);
    if (yr1==tspan) yr1=tspan-1 ;
    let yr2=tspan-yr1;

     let t1,t2;
     if (CA>0)   {    // first part is yrateU, second yrateD
      t1= assetGrowth_cash2(CA,0,yr1,irate1) ;
      t2= assetGrowth_cash2(0,CB,yr2,irate0) ;
    } else {        // first part is yrateD, 2nd yrate U
      t1= assetGrowth_cash2(CA,0,yr1,irate0) ;
      t2= assetGrowth_cash2(0,CB,yr2,irate1) ;
    }
      let yy=t1+t2;
      return yy;
}

function assetGrowth_cash2(CA,CB,tspan,irate1) {

  if (tspan==0) return  0 ;

  if (irate1==1.0) return CB ;   // no growth, so just return where you end

    let dC=CB-CA;
    let dCt=dC/tspan;

    let t1=CA*(irate1**(tspan));

    let a1=irate1;
    let nb=irate1**(tspan-1);

    let na=1-nb;
    let num=irate1*na ;
    let denom=1-irate1;
    let t2a=num/denom ;

    let t2=dCt*t2a ;
    let aval=t1+t2+dCt;       // reciept of dc at beginnng of last period --- so last dc does NOT grow
    return aval ;
}



//================
// compute sum, of nPeriods, of earnings that start at v0 and end at v1  (each period has earnings v, v ranging between v0 and v1)

function assetGrowth_sum(nPeriods,v0,v1) {
    if (nPeriods==0) return  0 ;

   let vv1=nPeriods*v0;
   let vv2=nPeriods*((v1-v0)/2) ;
   let vv=vv1+vv2;
   return vv;
}

///=============================
// display a few asset details   -- html
// No portfolio info used!
// output not used anywhere else

// =====================================
/// calc asset valus for all assets on all dates in useDates
function calcAssetValues_all(useDates) {
 
  let goos={};
  let assetList={};
  let dateListSay={};
  let dateListNVals={};
 
  let earliestUsed=assetsUsed['someDates']['earliestEntryBoth'];

  let oof4=setEntryDate(theMaxYear,1,1);
   let theMaxDate=oof4['dayCount'];

  for (let anAsset in assetDetails['assets']) {
    let tt0=anAsset.split('.$');
    if (tt0.length>1) continue ;       // don't do startDate versions
    let ifoo=0;
    if (assetDetails['assets'][anAsset]['nHistory']==0) continue;
    for (let mm=0;mm<useDates.length;mm++) {
       let idate=useDates[mm];
       if (idate>theMaxDate)  idate=theMaxDate ;
       if (idate<earliestUsed) continue ; // don't bother if before any entries (portfolio or asset)
       if (!goos.hasOwnProperty(idate)) {
           goos[idate]={};
           oofA=setEntryDate(idate);
           dateListSay[idate]=oofA['sayDate'];
           dateListNVals[idate]=0
       }
       goo=calcAssetValues(anAsset,idate);       // [anAsset,aDate,date0,date1,arfNew,assetType];
       if (goo!==false) {
          goos[idate][anAsset]=goo[4];
          dateListNVals[idate]++;
          assetList[anAsset]=1;
          ifoo=1;
       } else { 

          goos[idate][anAsset]=false;
       }
     }

  }
  assetValues_byDate={'vals':goos,'dateListSay':dateListSay,'assetList':assetList,'dateListNVals':dateListNVals,'created':1} ;

  return 1;


}

//======================    calcAssetValues
// make and display html table of  asset Details  -- by day. Yearly interest for bonds, current price and yearly dividend for  tocks
// &#127480; S blue  ,  &#127463; B blue,  &#127299;  T box      &#9332; (1)   &#9450; circle 0
function showAllAssetDetailsHtml(ifoo) {

  if (!assetValues_byDate.hasOwnProperty('created')) {    // not yet created ...
displayStatusMessage('Building table of trends in asset values ...');
    calcAssetValues_all(assetLookupDates );   // populate the assetValues_byDate global
displayStatusMessage('<br>... completed! ',1);
  }

  let ahtml='<div style="background-color:cyan">';
  ahtml+='<a name="showDetailsTop">&nbsp;</a> ';
  ahtml+='<a href="#showDetailsDesc" title="View some descriptive notes">&#127901;</a> ';
  ahtml+='Asset summary for <u>'+userName+'</u> @ '+wsurvey.get_currentTime(31,1)+'</div>';

  ahtml+='<table cellpadding="3" border="1"> ';
  ahtml+='<tr><th>date</th>';
  ahtml+='<th>&#205;nflation</th>';
  let atr2='<tr bgcolor="#dfdfdf"><td colspan="2"> </td>';
  for (let aName in  assetValues_byDate['assetList']) {              // showAllAssetDetailsHtml
 
     let assetType=getAssetType(aName),aextra='';
      if (assetType==4) {
          if (doAssetLookup(aName,'constantIncome') ==1) aextra='<span title="Value fixed on acquisition, with a growth rate" style="font-style:oblique;font-size:85%">fixed</span>';
      }
     let aIcon=getAssetType(assetType,'icon');

     ahtml+='<th>'+aIcon+' '+aName+' '+aextra+'</th>';

     let dd='';
     if (assetType==0) {
         dd+=' <span title="Price per share"  style="border:1px solid gray;font-family:monospace">Price</span>';
         dd+=' <span title="Yearly dividend rate per share "  style="border:1px solid gray;font-family:monospace">Dividend</span>';
         dd+=' <span title="Cumulative after-tax growth (per share multiplier). Pre-tax: ..." style="border:1px solid gray;font-family:monospace">cumGrowth</span>';
     } else if (assetType==1 || assetType==2 ) {
         dd+=' <span title="Yearly interest rate per share "  style="border:1px solid gray;font-family:monospace">Interest</span>';
         dd+=' <span title="Cumulative after-tax growth (per share multiplier). Pre-tax: ..." style="border:1px solid gray;font-family:monospace">cumGrowth</span>';
     } else if (assetType==3) {
            dd+=' <span title="Sale price"  style="border:1px solid gray;font-family:monospace">salePrice</span>';
            dd+=' <span title="Yearly netRent: earnings-costs. Costs include mortgate interest payments"  style="border:1px solid gray;font-family:monospace">netRent</span>';
            dd+=' <span title="Cumulative after tax earnings (can be negative). Pre-tax: .." style="border:1px solid gray;font-family:monospace">cumEarn</span>';
     } else if (assetType==4) {
            dd+=' <span title="Yearly income (pre tax)"  style="border:1px solid gray;font-family:monospace">Income</span>';
            dd+=' <span title="Cumulative after tax earnings (can be negative). Pre-tax ..." style="border:1px solid gray;font-family:monospace">cumEarn</span>';
     }
     atr2+='<td>'+dd+'</td>';

  }
  ahtml+='</tr>';
 

  ahtml+=atr2+'</tr>'

 let firstDate=false;
 for (let aDate in assetValues_byDate['dateListNVals']) {      // showAllAssetDetailsHtml
     if (assetValues_byDate['dateListNVals'][aDate]<=0) continue ;      // no assets with history... soskip
     if (firstDate===false) firstDate=aDate;

     let adaySay=assetValues_byDate['dateListSay'][aDate];       // showAllAssetDetailsHtml
     let atr='<tr><td><span title="'+aDate+'"> '+adaySay+'</span></td>';

     let gfactor=calcInflation(firstDate,aDate);
     atr+='<td>'+parseFloat(gfactor).toFixed(3)+'</td>';

     let aclass=' class="cAssetTableHtml " ';
     for (let aName in assetValues_byDate['assetList']) {

        let ahist=assetValues_byDate['vals'][aDate][aName];

        if (ahist===false) {            // no values as of this date
              let dd='<td><div title="Asset: '+aName+' @ '+adaySay+': before first history entry "  style="border:1px solid gray">&hellip;</div></td>';
              atr+=dd;
              continue;
         }

       let aclass=' class="cAssetTableHtmlSpan " ';
       if (ahist['doInterp']==0) aclass=' class="cAssetTableHtmlSpanHist " ';  // matches a history entry (so no intepolration)

         let assetType=getAssetType(aName); 
         let dd='<td><div  title="Asset: '+aName+' @ '+adaySay+'" style="border:1px solid tan">';

         if (assetType==0 ) {   // bond (regular or tax deferred)
            dd+=' <span title="Price per share" '+aclass+' >';
              dd+=ahist['price'].toFixed(1) ;
            dd+='</span>';
            dd+=' <span title="Yearly dividend rate per share " '+aclass+'>';
              dd+=ahist['dividend'].toFixed(2) ;
            dd+='</span>';
            dd+=' <span title="Cumulative after-tax growth (per share multiplier). Pre-tax: '+ahist['growthCum'].toFixed(6)  +'"'+aclass+'>';
               let v1=ahist['growthCumAT'],v1use;
               if (Math.abs(v1-1.0)<0.001) {
                   v1use="~1.0";
               } else {
                  v1use=v1.toFixed(3) ;
               }
               dd+=v1use;
             dd+='</span>';


         } else if (assetType==1 || assetType==2) {   // bond (regular or tax deferred)
            dd+=' <span title="Yearly interest rate" '+aclass+'>';
              dd+=ahist['interest'].toFixed(3) ;
            dd+='</span>';
            dd+=' <span title="Cumulative after-tax growth (per share multiplier). Pre-tax: '+ahist['growthCum'].toFixed(6)  +'"'+aclass+'>';
               let v1=ahist['growthCumAT'],v1use;
               if (Math.abs(v1-1.0)<0.001) {
                   v1use="~1.0";
               } else {
                  v1use=v1.toFixed(3) ;
               }
               dd+=v1use;
             dd+='</span>';

         } else if (assetType==3 ) {

            dd+=' <span title="Sale price"  '+aclass+'>';
               dd+=wsurvey.makeNumberK(parseInt(ahist['salePrice']),50000);
            dd+='</span>';
            dd+=' <span title="Yearly netRent: earnings-costs. Costs include mortgage interest payments"'+aclass+'>';
              dd+=wsurvey.addComma(parseInt(ahist['netRent']));
            dd+='</span>';
            dd+=' <span title="Cumulative after tax earnings (can be negative). Pre-tax: '+ahist['earningsCum'].toFixed(1)  +'" '+aclass+'>';
               let v1use=wsurvey.makeNumberK(parseInt(ahist['earningsCumAT']),50000);
               dd+=v1use;
             dd+='</span>';


         } else if (assetType==4 ) {
            dd+=' <span title="Yearly income (pre tax)"  '+aclass+'>';
              dd+=wsurvey.addComma(parseInt(ahist['income'])) ;
            dd+='</span>';
            dd+=' <span title="Cumulative after tax earnings (can be negative). Pre-tax: '+ahist['earningsCum'].toFixed(1)  +'" '+aclass+'>';
               let v1use=wsurvey.makeNumberK(parseInt(ahist['earningsCumAT']),50000);
               dd+=v1use;
             dd+='</span>';

         }         // assettype

         atr+=dd+'</div></td>';

     }    // this aName


     atr+='</tr>';
     ahtml+=atr;
  }      // this daate

  ahtml+='</table>'    ;


  ahtml+='<div style="margin:1em;background-color:cyan"><a href="#showDetailsTop">&uarr;</a> <a name="showDetailsDesc">Key</a></div>';
  ahtml+='<ul class="boxList">';
  ahtml+='<li><span>Dates have an assetHistory entry (for at least one asset) </span>.';
  ahtml+='<span class="cAssetTableHtmlSpanHist ">Creation or modification entry</span> used (interpolation not needed) ';
  ahtml+='<br><span >&#127470;ncome entries do not account for growth (of <em>fixed value incomes</em>) ';
  ahtml+='<li><em>Asset Types</em>: ';
  ahtml+=getAssetType(0,1)+' | ';
  ahtml+=getAssetType(1,1)+' | ';
  ahtml+=getAssetType(2,1)+' | ';
  ahtml+=getAssetType(3,1)+' | ';
  ahtml+=getAssetType(4,1)+' ';

  ahtml+='<li> <em>Descriptions:</em>';
  ahtml+='<menu xclass="tightMenu">';
 
  for (let aName in  assetValues_byDate['assetList']) {              // showAllAssetDetailsHtml

     let atype=doAssetLookup(aName,'assetType',2);
     let taxFreeFrac=doAssetLookup(aName,'taxFreeFrac',1);
     taxFracSay='n.a.';
     if (taxFreeFrac!=='false') {
           taxFracSay=parseFloat(taxFreeFrac).toFixed(2);
     }
     let aextras='';

     if (doAssetLookup(aName,'autoAddEntries','i')==1) {
           let nImputed=doAssetLookup(aName,'nImputed','i')   ;
           aextras+=nImputed+ ' entries added (using imputed inflation) after last explicit entry.<br>';
     }

     if (atype==0) {
        aextras+='';
     } else if (atype==1 ) {
         let tt0=parseFloat(taxFreeFrac)*100;
         let tt=tt0.toFixed(1)+'%';
         aextras+='Percent of interest earnings <u>not</u> taxed: '+tt;
     } else if (atype==2 ) {
        aextras+='';
     } else if (atype==3 ) {
         let tt0=parseFloat(taxFreeFrac)*100;
         let tt=tt0.toFixed(1)+'%';
         aextras+='Percent of capital gains <u>not</u> taxed: '+tt;
         let sayLossesOffset=(doAssetLookup(aName,'lossesOffsetIncome')==1) ? 'Yes' : 'No' ;
         aextras+=' | losses (when sold) offset income: <tt>'+sayLossesOffset+'</tt>';

     } else if (atype==4 ) {

         if (doAssetLookup(aName,'constantIncome')==1) {
            aextras+='Income determined by acquisition date ';
            let cclist=doAssetLookup(aName,'contantIncomeVariants');
            aextras+= '(# of variants = '+cclist.length+').<br>';
         }


         let tt0=parseFloat(taxFreeFrac)*100;
         let tt=tt0.toFixed(1)+'%';
         aextras+='Percent of income <u>not</u> taxed: '+tt;
         let sayLossesOffset=(doAssetLookup(aName,'lossesOffsetIncome')==1) ? 'Yes' : 'No' ;
         aextras+=' | losses offset income: <tt>'+sayLossesOffset+'</tt>';
     }

      let sayLossesOffset=(doAssetLookup(aName,'lossesOffsetIncome')==1) ? 'Yes' : 'No' ;
     let aIcon=getAssetType(atype,'icon');
      let adesc=doAssetLookup(aName,'desc');
      let nhistory=doAssetLookup(aName,'nHistory','i');
      ahtml+='<li>'+aIcon+' <b>'+aName+'</b> <span title="# of asset history entries" class="cHistoryAssetDescs"># entries:' +nhistory+'</span>  <tt>'+adesc+'</tt>';
      ahtml+='<br> '+aextras;
  }
  ahtml+='</menu>';


    wsurvey.displayInNewWindow(0,{'content':ahtml,'cssFiles':'simInv.css','name':'assetDetails','title':'Asset details (by various dates'});

  return 1;

}

//=======================
// create assetHistory from assetHistoryOrig -- by adding "inflation imputed" entries
// also tweaks assetLookup global (since this is called after makeAssetLookup

function updateAssetHistory_inflation(hOrig,assetAutoAdds,lastYearToUse) {

  let dovars=['assetPrice','assetDividend','assetSalePrice','assetNetRent','assetIncome','assetAddition'] ;
  let noDovars=['assetInterest','assetIncomeGrowth'];
  assetHistory={} ;        // global

// copy assetHistoryOrig global (provided as argument)
  for (let aname in hOrig) {                  // all assets that have some history info
    assetHistory[aname] =JSON.parse(JSON.stringify(hOrig[aname])) ;
    for (iu=0; iu<assetHistory[aname].length;iu++) {
       assetHistory[aname][iu]['original']=1;
    }
 }

// add "imputed" (inflation calculated) entries?
  for (let aname in assetHistory) {                  // all assets that have some history info

    if (!assetAutoAdds.hasOwnProperty(aname) ||  assetAutoAdds[aname]==0) continue;        // do NOT auto add "inflation" adjusted entries

    let a1Use=assetHistory[aname];

// auto add entries? (1 per after the year of the last entry, until end of yearRange?
     let lastEntry=a1Use[a1Use.length-1];
     lastDate=parseInt(lastEntry['date']) ;  // date of last entry
     let lastDateYear=setEntryDate(lastDate).year;
     for (kyear=lastDateYear+1;kyear<=lastYearToUse;kyear++) {
             let addme={};
             let kyearDayCount=setEntryDate(kyear,1,1).dayCount;  // date of this "to be imputed" entry
             addme['date']=kyearDayCount ;
             let infRate=calcInflation(lastDate,kyearDayCount);
             addme['comment']='imputed values from '+lastDateYear+' to '+kyear+' @ '+infRate.toFixed(3);

            for (ij=0;ij<dovars.length;ij++) {
                a1=dovars[ij];
                addme[a1]=  (lastEntry.hasOwnProperty(a1)) ? (infRate*parseFloat(lastEntry[a1]) ) : 0 ;
            }
            for (ik=0;ik<noDovars.length;ik++){
                a2=noDovars[ik];
                addme[a2]=  (lastEntry.hasOwnProperty(a2)) ? parseFloat(lastEntry[a2]) : 0 ;
            }
            addme['original']=0;

            assetHistory[aname].push(addme);
            assetLookup[aname]['nImputed']++ ;        // initialized to 0 by makeAssetLookup

     }           // kyear
  }           // aname

  return 1 ; // modifies global history assetHistory

}
