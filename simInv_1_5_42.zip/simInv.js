// simInv js functions

///=============
// show something in new sidnwo
function showDebug(a1,asay,isay) {
  let xx=a1;
  if (arguments.length<2) asay=' showing ' ;
  if (arguments.length<3) isay=0 ;
  if (typeof(a1)=='string') {
    if (arguments.length<2) asay=a1 ;
     xx=window[a1]  ;
   }
   let xx2=wsurvey.dumpObj(xx ,'var','var: '+asay);          // showDebug!
   if (isay==1) {
       qq=confirm('showDebug? for '+asay);
       if (!qq) return 0;
   }
   wsurvey.displayInNewWindow('',{'content':'<pre>'+xx2+'</pre>'});
   if (isay==1) alert('Showing: '+asay);
}

//==================
// logon -- check for existence of data/username directory (under simInv)
function doLogon(athis) {

   if (simInvLocalStorage['enabled']===false && simInvLocalStorage['useLocalStorage']==1 ) return 0;  // give up if failure (no local storage in a standalone mode)

   let e1= $('#iUserName');
   let aval=jQuery.trim(e1.val());
   if (aval.indexOf('@')>-1 || aval.indexOf('!')>-1 || aval.indexOf(' ')>-1) {
      alert(' Invalid user name (it can not contain @, !, or spaces) ');
      return 0;
   }
   if (aval=='') {
      alert(' You must enter a user name ');
      return 0;
   }
   aval2=fixString(aval,1);
   if (aval2!=aval) {
      alert('Please enter a single word');
      return 0;
   }
  userName=aval2.toLowerCase();         // global

  let eKey=$('#iEncryptionKey');
  encryptionKey=eKey.val();          // global
  encryptionKey=fixString(encryptionKey,1).toLowerCase();
  encryptionKey_md5= (encryptionKey!='') ? md5('simInv_'+encryptionKey) : '' ;  // global

// online mode?   ...................

  if (simInvLocalStorage['useLocalStorage']==0) { // online mode  -- check if user exists, update settings if first logon
     checkUserExistsOnline(userName);        // this calls afterLogon()
     return 1;
  }

// standALone mode  ......... ..........

  let qstat=simInv_localEnable()      ;         // update simInvLocalStorage (now that we have a userName!) ;
  if (qstat===false) return 0;  // fatal error (there was an alert). Quit
  if (qstat==2)     {          // intiailzation (for this user, in standalone mode) required
     init_localUser(1);
     doLogoff(1);
  }

// local storage uesable for this userName (or not neeed)
  simInv_localStorageStats(1) ;       // enable local storage button


// the simInv data
  let response={};

    response['settings']=simInv_localVar('settings');
    response['assets']=simInv_localVar('assets');
    response['assetHistory']=simInv_localVar('assetHistory');
    response['portfolios']=simInv_localVar('portfolios');
    response['portfolioInit']=simInv_localVar('portfolioInit');
    response['portfolioModifications']=simInv_localVar('portfolioModifications');
    response['viewDates']=simInv_localVar('viewDates');

    afterLogon(response,0);

 }


//==============================
// check that user exists (online mode).
// if no username -- error messages
// if username, but no settings --save global settings (and encMd5) and relogon
// if global settings -- afterLogon (read all data)

function   checkUserExistsOnline(ifoo) {

    let ddata={'todo':'checkUserExists','username':userName};
    $.ajax({
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {
     checkUserExistsOnline2(response);
   });
}

//===========
// callback from checkUserExistsOnline (online mode)
// 0: ready, 1:no username speciifed, 2: no such user,3: no settings
function checkUserExistsOnline2(response,asay) {
   if (arguments.length<2){
      astat=response[0];
      asay=response[1] ;
   } else {
      astat=response;
   }
 
   if (astat==1)  { // no user name -- should never happen
       let amess="Please specify a username ";
       displayStatusMessage(amess,2);
       toggleStatusMessage(0,0);
       return 0 ;
   } else if (astat==2) {   // no such user

       displayStatusMessage(asay,2);
       toggleStatusMessage(0,0);
       return 0;
   }


// first time logon? create settings file (usijng default settings)
   if (astat==3) {
     let amess='';
     amess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#firstLogonInit">&#10068;</button> ';
     amess+='Hello <tt>'+userName+'</tt>. This is your first logon -- some initialization is required! ';
     amess+='<br><label title="Check to encrypt your simInv data">';
     amess+=' <input id="iwantToEncrypt" onClick="checkUserExistsOnline2_click(this)" type="checkbox" value="1">Do you want to <u>encrypt your data?</u></label> ';
     amess+='<div id="iEncryptionKey_initOuter" style="display:none"> ... please enter your <tt>personal encryption key</tt>: ';
     amess+='<input type="text" size="20" id="iEncryptionKey_init"> ';
     amess+='<br><em>Optional:</em> enter a hint (to help you remember your encryption key) <input type="text" size="40" id="iEncryptionKey_init_hint"> ';
     amess+='</div>';
     amess+='<p><input type="button" value="Initialize your account!" onClick="checkUserExistsOnline2_init(this)">';
     displayStatusMessage(amess);
     toggleStatusMessage(0,0);
     return 1;
   }

// if here, ready!
// check for incorrect md5

    let ddata={'todo':'getData','username':userName,'encMd5':encryptionKey_md5};

    $.ajax({
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {
 
      afterLogon(response,0);
   });


   return 1; ;
}      // checkUserExistsOnline2

// =========== initialze a uaser
function  checkUserExistsOnline2_init(athis) {

  let  uencrypt= encryptionKey_md5;
  let e1=$('#iwantToEncrypt');
  let qencrypt=e1.prop('checked');

// check out personal encryption text
   let e2=$('#iEncryptionKey_init');
   let encryptionKeyX=e2.val();          // global
   encryptionKeyX=fixString(encryptionKeyX,1).toLowerCase();
   encryptionKeyX_md5= (encryptionKeyX!='') ? md5('simInv_'+encryptionKeyX) : '' ;  // global
   let myhint='';

   if (qencrypt) {
      if (encryptionKeyX_md5=='') {
         alert('You chose to encrypt your data, but did NOT provide an encryption key! \nPlease try again ');
        return 0;
      }
      let e2h=$('#iEncryptionKey_init_hint');
      myhint=e2h.val();
      myhint=wsurvey.removeAllTags(myhint);

   } else {
     if (encryptionKeyX_md5!=='') {
        alert('You chose NOT to encrypt your data, but DID provide an encryption key!   \nPlease try again ');
        return 0;
     }
   }
    let ddata={};;          // save the default user settings
    defaultUserSettings['encryptionKeyHint']=myhint;  // the hint!
    ddata['todo']='saveDefaultSettings';   
    ddata['data']={};
    ddata['data']['list']= defaultUserSettings  ;
    ddata['encMd5']=encryptionKeyX_md5  ;       // saved for later validation
    ddata['username']=userName;
 
    $.ajax({
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function (response) {
        let cmess='Default settings saved for <tt>'+userName+'</tt> (you can change these at any time).' ;
        if (encryptionKeyX_md5!='')  {
            cmess+='<br>You specified an encryption key! Don`t forget it, you will need it everytime you logon.';
            cmess+='<br>Hint: you can change your <em>hint</em> at any time, using <button>&#9965;</button>settings. ';
        }
        displayResponseFromServer(cmess,1) ;
        return 1;
    });

}

//============
function checkUserExistsOnline2_click(athis) {
   ethis=wsurvey.argJquery(athis);
   if (ethis.prop('checked')) {
     $('#iEncryptionKey_initOuter').show();
   } else {
     $('#iEncryptionKey_initOuter').hide();
     $('#iEncryptionKey_init').val('');
   }
}


//========================
// localStoarge only (standAlone mode) -- but no such user. Do some initialziation
//   assets
//   assetHistory
//+   portfolios
//   portfolioInit
//   portfolioModifications
//   viewDates
//   settings

function init_localUser(ifoo) {

   let u1=localStorage.getItem('simInv_!users');
   if (u1===null) {        // should never happen
      alert('init_localUser: no userList (simInv_!users not in localStorage)');
      return false;
   }
   let u2=JSON.parse(u1);
   let userList=u2['list'];
   let qq=confirm('Would you like to initialize username=`'+userName+'` ? \n * local storage data will be used \n * Default user settings will be used (you can change them at any time)   ');
   if (!qq) return false;

   let nowTime=wsurvey.get_currentTime(0)
   userList[userName]=nowTime;
   let nusers=parseInt(u2['nusers'])+1;
   let z1={'nusers':nusers,'list':userList};
   let z2=JSON.stringify(z1);
   localStorage.setItem('simInv_!users',z2);

// save default settings
   let dsettings={'date':nowTime,'list':{}};
   for (let aa1 in defaultUserSettings) dsettings['list'][aa1]=defaultUserSettings[aa1];
   let q2=simInv_localVar('settings',dsettings);

    let arf=localStorage.getItem('simInv_!users');


// save empty assets
   let zassets={'date':'','list':[] };
     q2=simInv_localVar('assets',zassets);

// save empty assets
   let zassetHistory={'date':'','list':{},'autoAddEntries':{}};
     q2=simInv_localVar('assetHistory',zassetHistory);

// save empty portfolios
   let zportfolios={'date':'','list':[]};
     q2=simInv_localVar('portfolios',zportfolios);

// save empty portfolioInit
     let zportfolioInit={'date':'','list':[]};
     q2=simInv_localVar('portfolioInit',zportfolioInit);

// save empty portfolioModifications

     let zportfolioMod={'date':'','list':[]};
     q2=simInv_localVar('portfolioModifications',zportfolioMod);

// save empty portfolios
   let zviewDates={'date':'','list':[]};
     q2=simInv_localVar('viewDates',zviewDates);

// after localStorage init, must logon again

}

//==============
// return from logon check
// responseFromServer may be encrypted  -- and it may be from local storage :(

function afterLogon(responseFromServer,do1 ) {

// logon error?
  if (responseFromServer.hasOwnProperty('error') && responseFromServer['error']===true)  {
     displayStatusMessage(responseFromServer['errorMessage']);
     return 0;
  }

 if (arguments.length<2) do1=0;
 let qLocal=simInvLocalStorage['useLocalStorage']==1 ;

// show a please wait message  -- it is removed when the processing of server data is done.
// the wait is just to avoid some dom timing issues
  if (do1==0) {
    displayStatusMessage('Hello <tt>'+userName+'</tt>. Please wait while simInv initializes  .... ');
    window.setTimeout(function() {  // and recall this... to process the response
         afterLogon(responseFromServer,1)
    },50);
    return 1;
 }


// Process response from sever -- biggest task is to decrypt

let response ;
if (qLocal==0) {
  response=afterLogon_fromServer(responseFromServer);
} else {
  response=afterLogon_fromLocal(responseFromServer);
}


if (doDebug==1) {
  if (qLocal) {
   showDebug(response,'For '+userName+' (local storage)');   // enable this (set doDebug at top of file) to view response --- which might be a php error message
  } else {
   showDebug(response,'For '+userName+' (online storage)');   // enable this (set doDebug at top of file) to view response --- which might be a php error message
  }
}

allCurrentData=response ;  // global (used to save changes, and for archiving)

if (!qLocal) {
  delete allCurrentData['error'];
  delete allCurrentData['errorMessage'];
  delete allCurrentData['messages'];
  delete allCurrentData['firstKeyMd5'];
}

   shortcut.add("esc",wsurvey.wsShow.hideRecent,{
	'type':'keydown',
 	'propagate':true,
	'disable_in_input':true,
	'target':document
   });


   $('#header_floatRight').show()  ; // display the settings, etc in the header

// user specific settings: defaults are in  index.php ....

  cashInterest=(response['settings']['list'].hasOwnProperty('cashInterest') ) ? response['settings']['list']['cashInterest'] : cashInterest ;
  cashPenalty=(response['settings']['list'].hasOwnProperty('cashPenalty') ) ? response['settings']['list']['cashPenalty'] : cashPenalty ;
  taxRate=(response['settings']['list'].hasOwnProperty('taxRate')  ) ? response['settings']['list']['taxRate'] :  taxRate;
  capGainsRate=(response['settings']['list'].hasOwnProperty('capGainsRate') ) ? response['settings']['list']['capGainsRate'] : capGainsRate ;
  firstYearUse=( response['settings']['list'].hasOwnProperty('firstYearUse') ) ? response['settings']['list']['firstYearUse'] : firstYearUse;
  lastYearUse=(response['settings']['list'].hasOwnProperty('lastYearUse') ) ? response['settings']['list']['lastYearUse'] : lastYearUse;
  encryptionKeyHint=(response['settings']['list'].hasOwnProperty('encryptionKeyHint')  ) ? response['settings']['list']['encryptionKeyHint'] : encryptionKeyHint;  // only shown in settings button
  warningLevel=(response['settings']['list'].hasOwnProperty('warningLevel')  ) ? response['settings']['list']['warningLevel'] : warningLevel;
  showTransactions=(response['settings']['list'].hasOwnProperty('showTransactions')  ) ? response['settings']['list']['showTransactions'] : showTransactions;
  addEntryDates=(response['settings']['list'].hasOwnProperty('addEntryDates')  ) ? response['settings']['list']['addEntryDates'] : addEntryDates;
  addEntryDates_yearly=(response['settings']['list'].hasOwnProperty('addEntryDates_yearly')  ) ? response['settings']['list']['addEntryDates_yearly'] : addEntryDates_yearly;
  budgetRemainPct=(response['settings']['list'].hasOwnProperty('budgetRemainPct')  ) ? response['settings']['list']['budgetRemainPct'] : budgetRemainPct;
  inflationAverageTimespan=(response['settings']['list'].hasOwnProperty('inflationAverageTimespan')  ) ? response['settings']['list']['inflationAverageTimespan'] : inflationAverageTimespan;
  sameAssetFamilyOk=(response['settings']['list'].hasOwnProperty('sameAssetFamilyOk')  ) ? response['settings']['list']['sameAssetFamilyOk'] : sameAssetFamilyOk;
  additionsFromCash=(response['settings']['list'].hasOwnProperty('additionsFromCash')  ) ? response['settings']['list']['additionsFromCash'] : additionsFromCash;
  cpiuSeries=(response['settings']['list'].hasOwnProperty('cpiuSeries')  ) ? response['settings']['list']['cpiuSeries'] : cpiuSeries;

  allSettings=response['settings']['list']; // can be exported

  for (let iyear in cpiuSeries) cpiuSeries[iyear]=parseFloat(cpiuSeries[iyear]) ;   // inflation series used in several places
  cpiuSeriesUse=fixCpiuSeries(cpiuSeries,inflationAverageTimespan,lastYearUse);

// pull some datasets from server,  as is
  viewDates=response['viewDates'] ;

  assetList=response['assets']['list'];

  let assetAutoAdds=(response['assetHistory'].hasOwnProperty('autoAddEntries')) ? response['assetHistory']['autoAddEntries']: {}  ;

  assetHistoryOrig=response['assetHistory']['list'];

  portfolioList=response['portfolios']['list'];       // a global -- not encrypted

// create   portfolioInit and  portfolioModifications globals (decrypt and cleanup)

  let portfolioInit_orig= JSON.parse(JSON.stringify(response['portfolioInit']));  // clone this ;

  let portfolioModifications_orig= JSON.parse(JSON.stringify(response['portfolioModifications']));  // clone this ;

  setupPortfolios(portfolioInit_orig,portfolioModifications_orig) ; // sets globals,  could  thendelete  portfolioInit_orig and  portfolioModifications_orig


// create assetLookup global from the assetlist and history

  assetLookup=makeAssetLookup(assetList,assetHistoryOrig,assetAutoAdds);

 // check if any assets in a porfolio (init or mod) that are NOT in assetLookup  --  use portfolioInit and portfolioModifications from above
  makeAssetsUsed1(assetLookup);      // create   assetsUsed

  let nerr= assetsUsed['nErrs'];
  if (nerr>0 ) {
      showAssetProblems(1) ;
  }

// make some loan shedules (global var) (SKIP this if asset errors
  if (nerr==0 ) {
     let loanStuff=getCurrentLoans(portfolioInit,portfolioModifications) ; // reads portoflioInit and portfolioModifications
     portfolioLoans=makePortfolioLoans(loanStuff);

// update assethistory global (add imputed values using inflation?)
     updateAssetHistory_inflation(assetHistoryOrig,assetAutoAdds,lastYearUse) ;

// 1st call: history of asset attributes (for modification, and perhaps other, dates)
     makeAssetDetails(assetHistory);         // assetDetails (for each asset's history entries) -- will change  assetDetails global "in place"

// add some "shortcuts" to the assetHistory     global
     let constantVars=getConstantIncomes(portfolioInit,portfolioModifications) ; // extracts 'from server' versions of portfolioInit and portfolioModifications
     updateAssetHistory_income(constantVars) ;        // add  .$incomeStart entries to assetHistory -- resolves the "constantIncome & growth rate" shortcut


// call makeAssetDetails again, with "constantIncome" assets now included in assetHistory.
// 8 july: probably should tweak this to just update the stuff added by updateAssetHistory_income

     makeAssetDetails(assetHistory);    // compute assetDetails (for each asset's history entries) -- note change global "in place"

// asset details are ready for use  ..... so create the porftolio datases from the asset-mixed retrieved from server
// note that since asset characteristics may be changed, the recreated portfolio (its netValue etc) CAN be different than
// the values when first specified.
// Hence: simInv recreates each time it loads, rather than save & retrieve the "working" portfolio datasests on the server
//
//  6 July 2023: should implement a caching scheme to skip these steps (ONLY if no changes to assets or porfolios have occurred
//  since the cached version was saved)

    let qok= makePortfolioInit(1)  ;    // changes global portfolioInit
    if (qok!==false) {            // no asset errors (ie; first asset histyor after date of inclusin in a portfoplio
       makePortfolioModify(1)  ;    // modifies global portfolioModifications

       portfolioLookup=makePortfolioLookup(portfolioList,portfolioModifications);  // a global  {'ith'  ,'isInit' ,'budget' ,'creationDate'. creationDateSay ]
     } else {
        nerr=1;
     }
  }       // no asset errors

// now display stuff ...

  $('#mainDivHeader').show();

  $('#logonDiv').hide();
  let amm='<ul class="boxList">';


  let eaB=$('#assetsTableButton');
   let asseNeedInit=0;
   for (let baa in assetLookup) {
      if (assetLookup[baa][1]==0) {
          asseNeedInit=1;
          break;
      }
   }
  eaB.html('&#128065; '+assetList.length+' assets ');
  if (asseNeedInit==1) {                           // at least one asset needs initialization
      eaB.addClass('cdoButton')   ;
  } else {
      eaB.removeClass('cdoButton')
  }

//  do any portofliols need "initialzation" (specification of the intial asset mix)
 let portfolioNeedInit=0;
 for (let pfoo in portfolioLookup['list']) {
     if (portfolioLookup['list'][pfoo]['isInit']==0) {
        portfolioNeedInit=1;
        break;
    }
  }

  let ebB=$('#portfoliosTableButton');
  ebB.html('&#128065; '+portfolioList.length+' portfolios ');
  if (portfolioNeedInit==1) {
       ebB.addClass('cdoButton')   ;        // highlight in lime (signal a portfolio needs initialziation)
  } else {
      ebB.removeClass('cdoButton')
  }

// what assets are used in which portfolios. And which assets are in at least one portfolio but are NOT specified
// Note these are AFTER portfolio re-creation, since they can (or might) use portfolio info

  assetLookupDates= makeAssetValues_viewdates(1) ;  /// a list of "dates to comptue asset values for"  (every year & assetEntry dates)--     assetLookupDates is a global

// show some personal settings
// less importatnt setting   not displayed (but are shown when settings menu is opened

// show these basic settings
  $('#headerBarRight').show();

//  $('#settingsHeader1').show();
//  $('#isetInflation').show();

  $('#iCashInterest').html(cashInterest);
  $('#iCashPenalty').html(cashPenalty);

  $('#itaxRateValue').html(taxRate);
  $('#icapitalGainsValue').html(capGainsRate);
  $('#ifirstYearUse').html(firstYearUse);
  $('#ilastYearUse').html(lastYearUse);

 $('#simInvIntro_ver').html(versionNumber);  // versionNumber is global (set in index.php)

 if (encryptionKey!='')  {
     let eenc=$('#encryptOn') ;
     eenc.show();
  } else {
     let eenc=$('#encryptOff') ;
     eenc.show();
 }


 displayStatusMessage(false);      // hide this unless ....

 // loadCompleted is a sglobal used by autologon -- if true, autologon can occur.
 // If not true (when autologon call wakesup, no attempt to auto logon

 loadCompleted=true ;

 let tmess='';
   tmess+='<div style="margin:2em 2em;padding:1em">';
   tmess+='Hello <b>'+userName+'</b>! simInv is ready to use! Using the buttons in the <span style="padding:5px;margin:3px" class="cmainDivHeader">header bar</span> you can ... <p>';

//  <button >&#128176; Display</button>  results: --net values, etc. for all portofolios (on selected dates)
 tmess+='<ul class="boxList2">';

 tmess+='<li><span class="cdoButtonRegularFooOuter">';
 tmess+=' <button  class="cdoButtonRegularFoo"> &#128176; Display</button> ';
 tmess+='</span>';
 tmess+=' : display trends in portfolio results  -- the netValue, etc. for currently specified portofolios  ';

 tmess+='<br> <em>and</em> &hellip;  ';
 tmess+='<br> <span class="cdoButtonRegularFooOuter">'
 tmess+='<button   class="cdoButtonRegularFoo">&#128197;displayDates</button>';
 tmess+='</span>';
 tmess+=' : change what dates to use  (when displaying trends in portfolio results)';

 tmess+='<li><span class="cdoButtonRegularFooOuter">';
 tmess+='<button  class="cdoButtonRegularFoo"> &#128065; assets</button>';
 tmess+='</span>';
 tmess+=' : view, or modify '+assetList.length+' assets .. or add a new one ';

  tmess+='<br><em>or ...</em><br>';
  tmess+='<span class="cdoButtonRegularFooOuter">';
  tmess+='<button  class="cdoButtonRegularFoo"   title="Add a history entry for an asset " >&#128476; vu</button> ';
  tmess+='</span>';
  tmess+=' : compressed view ';

 tmess+='<li><span class="cdoButtonRegularFooOuter">' ;
 tmess+='  <button  class="csettingsBcdoButtonRegularFoouttonFoo"   title="View/Create public asset" >&#127760;Public</button> ';
 tmess+='</span>';
 tmess+=' : view (and add to available assets)  simInv`s <em>public assets</em>.';

 tmess+='<li><span class="cdoButtonRegularFooOuter">';
 tmess+='<button >&#128463;Info</button> ';
 tmess+='</span>';
 tmess+=' : view trend information on the assets (the history of their price, interest, etc.)  ';

 tmess+='<li><span class="cdoButtonRegularFooOuter">';
 tmess+='<button  class="cdoButtonRegularFoo">  &#128065;   portfolios </button> ';
 tmess+='</span>';
 tmess+=' : view, or modify  '+portfolioList.length+' portfolios .. or add a new one! ' ;

 tmess+='<li><span class="cdoButtonRegularFooOuter">';
 tmess+='<button class="cdoButtonRegularFoo">&#9965;</button> ';
 tmess+='</span>';
 tmess+=' : change personal settings ';

 tmess+='<li><span class="cdoButtonRegularFooOuter">';
  tmess+='<button >&#11192; &#206;nflation</button> ';
 tmess+='</span>';
  tmess+=' : view and modify  (CPI) schedule';

 tmess+='<li><span class="cdoButtonRegularFooOuter">';
 tmess+=' <button class="cdoButtonRegularFoo">&#128194;</button> ';
 tmess+='</span>';
 tmess+=' : export results and data ';

 tmess+='<li> or &hellip; <input class="csettingsButton" type="button" value="&#10068;Intro" " onclick="wsurvey.wsShow.show(this)" data-wsshow="#simInvHelp"> <em>to view an introdution ... and other online help!</em>';

 tmess+='</ul>';
 tmess+='</div>';

 welcomeMessage=tmess ;  // save for later display

 $('#mainDiv3').html(welcomeMessage);
 wsurvey.wsShow.show('#mainDiv','show');  // make sure its on top
 wsurvey.wsShow.show('#mainDiv3','show');  // make sure its on top

 displayStatusMessage(false);


// populate  publicAssetsList
 if (typeof(publicAssets_current)=='undefined') {
    alert('Note: publicAssets have not been initialized. See readme.txt for details ');
    publicAssetsList=false;
 } else {
   let palist=publicAssets_current(1);
   if (palist==false) {
      alert('Note: publicAssets are missing, or have not been initialized. See readme.txt for details ');
   } else {
      publicAssetsList=JSON.parse(palist);
   }
 }

// show the welcome sceen for new users?
   if (warningLevel==0) {
       if (assetList.length==0) {   // no assets (hence no portfolios -- a new user!
          displayHelpMessage('#simWelcome',false,1) ;
       }
   }

// and show errors (do this last since errors can occur in a few actions)
  if (nerr>0 || logonAlerts>0 ) {
    wsurvey.wsShow.show('#statusDiv','show');  // make sure its on top
    window.setTimeout(function() {
       wsurvey.wsShow.show('#statusDiv','show');  // make sure its on top
       wsurvey.wsShow.inFront('#statusDiv');
     $('#portfoliosTableButton').prop('disabled',true); // don't allow portfolio mods (need to fix assets first)
    },500);
    return 0;
  }

  displayStatusMessage('simInv initialization completed ')  ;
  displayStatusMessage(false,0,1500);

// change header line
 $('#userNameInHeader').html(userName);
 $('#descNoteInHeader').hide();
 displayStatusMessage(false);
}


//================
//  process sresponse from server -- possiblyie decrypt
function afterLogon_fromServer(responseZ) {
  let md5KeyServer=jQuery.trim(responseZ['keyMd5']);

  let response0={};      // temporary
  let daGetVars=['settings','assets','assetHistory','portfolios','portfolioInit','portfolioModifications','viewDates'] ;   // variables to extract from responseFromServer

  for (let iz=0;iz<daGetVars.length;iz++) {

   let zvar=daGetVars[iz];

   let useMd5=false,useStuff=false,useStuff0, useStuff1;

   if (responseZ[zvar].hasOwnProperty('content')) {     // encrypted

      if (!responseZ[zvar]['content'].hasOwnProperty('list')) {
          alert('Problem reading response from server: '+zvar+' has `content` but no `list` ');
          return 1;
      }
       useMd5=(responseZ[zvar]['content']['list'].hasOwnProperty('keyMd5')) ? responseZ[zvar]['content']['list']['keyMd5'] : '' ;
       if (jQuery.trim(useMd5)=='') useMd5=false;
       useStuff0=(responseZ[zvar]['content']['list'].hasOwnProperty('data')) ? responseZ[zvar]['content']['list']['data'] : false ;

   } else {      // no content, so no chance of encryption
       useStuff0=(responseZ[zvar].hasOwnProperty('list')) ? responseZ[zvar]['list'] : '' ;
    }
   if (useMd5===false || useStuff0===false) {
       useStuff1={'list':useStuff0};

   } else   {
      let darg={'data':useStuff0,'keyMd5':useMd5};
      useStuff1a= simInvDecrypt(darg,encryptionKey,' problem: ') ;
      useStuff1={'list':useStuff1a};
    }
    response0[zvar]={};
    response0[zvar]['list']= useStuff1['list']   ;
    if (zvar=='assetHistory') {                // assetHistory has some extra info
      response0[zvar]['list']= useStuff1['list']['list']   ;
      response0[zvar]['autoAddEntries']= useStuff1['list']['autoAddEntries']  ;
    }
    if (zvar=='portfolioModifications') {
       if (!response0[zvar].hasOwnProperty('list') ||response0[zvar]['list']===false) response0[zvar]['list']={} ;
    }
  }
  response=JSON.parse(JSON.stringify(response0));  // permanent ... clone to avoid issues
  return response ;
}


//================
//  process sresponse from local
// 6 August.. no decription of local... but would be easy to implement it here  (check list for keyMd5 and data fields)
function afterLogon_fromLocal(responseZ) {
  let response0={};      // temporary
  let daGetVars=['settings','assets','assetHistory','portfolios','portfolioInit','portfolioModifications','viewDates'] ;   // variables to extract from responseFromServer

  for (let iz=0;iz<daGetVars.length;iz++) {

   let zvar=daGetVars[iz];
   if (zvar=='settings') {
     let alist=afterLogon_fromLocal_b(zvar,responseZ);
     response0[zvar]={'list':alist};
   }

   if (zvar=='assets') {
     let alist=afterLogon_fromLocal_b(zvar,responseZ);
     response0[zvar]={'list':alist};
   }

   if (zvar=='assetHistory') {

     let alist={'list':{},'autoAddEntries':{} } ;
     let alistx=afterLogon_fromLocal_b(zvar,responseZ);

     alist['list']=(alistx.hasOwnProperty('list')) ? alistx['list'] : {} ;
     alist['autoAddEntries']=(alistx.hasOwnProperty('autoAddEntries')) ? alistx['autoAddEntries'] : {} ;
     response0[zvar]={};
     response0[zvar]['list']=alist['list'];
     response0[zvar]['autoAddEntries']=alist['autoAddEntries'];

   }

   if (zvar=='portfolios') {
     let alist=afterLogon_fromLocal_b(zvar,responseZ);
     response0[zvar]= {'list':alist} ;
   }

  if (zvar=='portfolioModifications') {
     let alist=afterLogon_fromLocal_b(zvar,responseZ);
     response0[zvar]={'list':alist};
   }

  if (zvar=='portfolioInit') {
     let alist=afterLogon_fromLocal_b(zvar,responseZ);
     response0[zvar]={'list':alist};
   }

   if (zvar=='settings') {
     let alist=afterLogon_fromLocal_b(zvar,responseZ);
     response0[zvar]={'list':alist};
   }

   if (zvar=='viewDates') {
     let alist=afterLogon_fromLocal_b(zvar,responseZ);
     response0[zvar]={'list':alist};
   }

  }  // dogetvars

  return response0;

}

//=-==================
// pull from local storage response
function  afterLogon_fromLocal_b(zvar,responseZ,sayList) {
 sayList='list';
   let alist={};

   if (!responseZ.hasOwnProperty(zvar)) return {} ;  // should not happen

   if (responseZ[zvar].hasOwnProperty('content')) {         // encryption occured (even if no actual encryption)
       if (responseZ[zvar]['content'].hasOwnProperty(sayList)) {
          if (responseZ[zvar]['content'][sayList].hasOwnProperty('data')) {
               alist=responseZ[zvar]['content'][sayList]['data'] ;
               let keyMd5=(responseZ[zvar]['content'][sayList].hasOwnProperty('keyMd5')) ? responseZ[zvar]['content'][sayList]['keyMd5'] : '' ;
                if (keyMd5!=='') {
                      alist=simInvDecrypt(responseZ[zvar]['contents'][sayList],encryptionKey,' problem: ');
                }
          }    // 'data' exists
       }    // 'list' exists
    }   else {  // 'content'  does not exist
           if (zvar=='assetHistory') {
               let alist1={},alist2={};
                if (responseZ[zvar].hasOwnProperty(sayList)) alist1=responseZ[zvar][sayList] ;
                if (responseZ[zvar].hasOwnProperty('autoAddEntries')) alist2=responseZ[zvar]['autoAddEntries'] ;
                alist={'list':alist1,'autoAddEntries':alist2};
           } else {
               if (responseZ[zvar].hasOwnProperty(sayList)) alist=responseZ[zvar][sayList] ;
           }
      }       // zvar exists
      return alist ;
}

//==============
// display "wlecome" messages
function reShowWelcome(ifoo) {

 $('#mainDiv3').html(welcomeMessage);
 wsurvey.wsShow.show('#mainDiv','show');  // make sure its on top
 wsurvey.wsShow.show('#mainDiv3','show');  // make sure its on top
 displayStatusMessage(false);

}

//===================
// are there any assets (in a porfoli) that are NOT av available

function makeAssetsUsed1(assetLookup) {
  let assetAll={};
  let earliestAssetEntry=11111111111111111 ;
  let earliestPortfolioEntry=11111111111111111 ;

  let lastAssetEntry=-11111111111111111 ;
  let lastPortfolioEntry=-11111111111111111 ;

 for (let aport in portfolioInit) {
    let dstamp=parseInt(portfolioInit[aport]['dateStamp']);
    earliestPortfolioEntry=Math.min(earliestPortfolioEntry,dstamp);
    lastPortfolioEntry=Math.max(earliestPortfolioEntry,dstamp);

    for (let ij=0;ij<portfolioInit[aport]['assetList'].length ;ij++) {
       let assetI=portfolioInit[aport]['assetList'][ij]['name'] ;
       let assetT=portfolioInit[aport]['assetList'][ij]['assetType'] ;
        if (!assetAll.hasOwnProperty(assetI)) assetAll[assetI]={'exist':-1,'portfolios':{},'entries':0,'type':false };
        if (!assetAll[assetI]['portfolios'].hasOwnProperty(aport))  {
            assetAll[assetI]['type']=assetT ;
            assetAll[assetI]['portfolios'][aport]=[];
            assetAll[assetI]['entries']++ ;
        }
        assetAll[assetI]['portfolios'][aport].push(assetT)   ;      // 0 values are assettype
    }
 }

  for (let aport in portfolioModifications) {
    for (let adate in portfolioModifications[aport]['list'] ) {
       let dstamp=parseInt(adate);
       earliestPortfolioEntry=Math.min(earliestPortfolioEntry,dstamp);
       lastPortfolioEntry=Math.max(earliestPortfolioEntry,dstamp);

       for (let ij=0;ij<portfolioModifications[aport]['list'][adate]['assetList'].length;ij++ ) {
          let assetI=portfolioModifications[aport]['list'][adate]['assetList'][ij]['name']  ;
          if (!assetAll.hasOwnProperty(assetI)) assetAll[assetI]={'exist':-1,'portfolios':{},'type':false };
          if (!assetAll[assetI]['portfolios'].hasOwnProperty(aport)) {
              assetAll[assetI]['type']=portfolioModifications[aport]['list'][adate]['assetList'][ij]['assetType']  ;
              assetAll[assetI]['portfolios'][aport]=[];
              assetAll[assetI]['entries']++ ;
          }
          assetAll[assetI]['portfolios'][aport].push(adate)   ;    // non-0 values are mod dates
       }
    }

 }


let nMissing=0,nNoHistory=0,nOkay=0;
 for (let zasset in assetAll) {
     if (!assetLookup.hasOwnProperty(zasset)) {
          nMissing++;
         continue ;   // exist stays at -1
     }
     let jh=assetLookup[zasset]['nHistory'];
     assetAll[zasset]['exist']=jh ;
     if (jh==0) {
         nNoHistory++;
     } else {
         nOkay++;
         let aearly=assetLookup[zasset]['earliestEntry'];
         let alate=assetLookup[zasset]['latestEntry'];
         earliestAssetEntry=Math.min(earliestAssetEntry,aearly);
         lastAssetEntry=Math.max(lastAssetEntry,alate);
     }
 }

 let someDates={};
  someDates['earliestPortfolioEntry']=earliestPortfolioEntry;
  someDates['lastPortfolioEntry']=lastPortfolioEntry;

  someDates['earliestAssetEntry']=earliestAssetEntry;
  someDates['lastAssetEntry']=lastAssetEntry;

  someDates['earliestEntryBoth']=Math.min(earliestAssetEntry,earliestPortfolioEntry);
  someDates['lastEntryBoth']=Math.max(lastAssetEntry,lastPortfolioEntry);

 let nerrs=nMissing+nNoHistory;
 assetsUsed={'nErrs':nerrs,'nMissing':nMissing,'nNoHistory':nNoHistory,'nOkay':nOkay,'list':assetAll,'someDates':someDates}  ; // get the global

 return 1;

}

//================    responseFromServer
// calculate inflation multipler between two dates
//  infMult * priceDate1 = priceDate2
// infmult is the ratio of cpiDate2/cpiDate1
// cpiDaten is   interpolated (if necessary) from values in cpiuSeriesUse (grow at daily rate from cpi of series entry just before daten

function calcInflation(date1,date2) {
 
   if (date1==date2) return 1.0;
  date1=parseInt(date1);
  date2=parseInt(date2);
  let csLen=cpiuSeriesUse.length-1;
  let firstEntryDate=cpiuSeriesUse[0][0];
  let lastEntryDate=cpiuSeriesUse[csLen][0];
  if (date1>lastEntryDate || date2>lastEntryDate) return false ; // too late!
  if (date1<firstEntryDate || date2<firstEntryDate) return false ; // too soon!


  let cpi1,cpi2;
  for (let jj=csLen;jj>=0;jj--) {      // start at the end ...
      let ac1=cpiuSeriesUse[jj];
      if (ac1[0]<=date1)  {      // this entry is before date1 (never after last entry -- given chedk above)
          if (ac1[0]==date1)  {  // exact match
               cpi1=ac1[2];
          } else {            // need to interpolate
            date1A=ac1[0];
            dayRateB=cpiuSeriesUse[jj+1][3] ;       // the daily inflation of the "next" entry (its what was used to go from prior entry to this one
            let dgapFind=date1-date1A;
            let ratex=dayRateB**dgapFind ;
            cpi1=ratex*ac1[2];
          }
     }
   }

  for (let jj=csLen;jj>=0;jj--) {
      let ac2=cpiuSeriesUse[jj];
      if (ac2[0]<=date2)  {      // this entry is before date1 (never after last entry -- given chedk above)
          if (ac2[0]==date2)  {
               cpi2=ac2[2];
          } else {            // need to interpolate
            date2A=ac2[0];
            dayRateB=cpiuSeriesUse[jj+1][3] ;       // the daily inflation of the "next" entry (its what was used to go from prior entry to this one
            let dgapFind=date2-date2A;
            let ratex=dayRateB**dgapFind ;
            cpi2=ratex*ac2[2];
          }
     }
   }

   let rateUse=cpi2/cpi1 ;
   return rateUse;

}

//============
// fix cpiuSeries, and extend to lastYearDo
function fixCpiuSeries(cpiuSeries0,inflationAverageTimespan,lastYearDo) {
  let dlist=[];

  let cpiuSeries1= JSON.parse(JSON.stringify(cpiuSeries0));  // clone this ;

  for (let adate in cpiuSeries1)   dlist.push(parseFloat(adate));
  dlist.sort(mySortNumeric);

  let lastgotDate=dlist[dlist.length-1];

  let oof=setEntryDate(lastgotDate);
  lastGotYear=oof.year;

  let t2=cpiuSeries1[lastgotDate];

  lastGotDayCount=oof.dayCount ;
  let lookyear=lastGotYear-inflationAverageTimespan;

// go back and find entry before lookyear
  let useDate=dlist[0] ; // if can't find entry far enough back
  for (let ii=dlist.length-1;ii>=0;ii--) {
     let t1=dlist[ii];
     let tyear=setEntryDate(t1).year ;
     if (tyear<lookyear) {
          useDate=t1;
          break;
     }
  }
  let t1=cpiuSeries1[useDate];
  let useDateYear=setEntryDate(useDate).year ;

// computed "average" inflation rate over this timespan
  dgap=lastgotDate-useDate;
  let aratio=t2/t1;
   let v1=Math.log(aratio);
   let v1b=v1/dgap;
  let dayRateFuture=Math.exp(v1b);
  let inflationRateFuture=dayRateFuture** 365;

  let dlistNew=[];
  for (let jyear=lastGotYear+1;jyear<=lastYearDo;jyear++) {
   let do1a=setEntryDate(jyear,1,1)
   let do1=do1a.dayCount   ;
   dlistNew.push(do1 );
  }

 let cuse=[];
 for (jj=1;jj<dlist.length;jj++) {     // drop the first year of the specified series (typically the built in cpi-u series)
     let j0=dlist[jj-1];
        let arate0=cpiuSeries1[j0];
     let j1=dlist[jj];
        let arate1=cpiuSeries1[j1];
        let j1year=setEntryDate(j1).year;

     let dgap1=j1-j0;
     let aratio1=arate1/arate0;
     let v1=Math.log(aratio1);
     let v1b=v1/dgap1;
     let dayRate1=Math.exp(v1b);
     let inf1=dayRate1**365  ;  // impted yearly length inflation rate (assuming
     aa=[j1,j1year,arate1,dayRate1,inf1,0] ;
     cuse.push(aa);
 }  // specfied entries

 let kk=cuse.length-1;
 let arateA=cuse[kk][2];       // first of pair starts with last specified entry
 let jA=cuse[kk][0];

 for (jj=0;jj<dlistNew.length;jj++) {     // drop the first year of the specified series (typically the built in cpi-u series)
     let jB=dlistNew[jj];
     let jByear=setEntryDate(jB).year;

     let dgap1=jB-jA;
     let amult=dayRateFuture**dgap1;
     let arateB=amult*arateA;

     aa=[jB,jByear,arateB,dayRateFuture,inflationRateFuture,1] ;
     cuse.push(aa);

     jA=jB;
     arateA=arateB ;  // do next year...
 }

// and to avoid nans, a far fuiture date. Since linear interpolation is used, this is not going to provide accurate
// results for years after the end of the year range
  jByear=assetDetails_farFuture ;
  let jB=setEntryDate(jByear,1,1).dayCount;
  let dgap1=jB-jA;
  let amult=dayRateFuture**dgap1;
  let arateB=amult*arateA;

  aa=[jB,jByear,arateB,dayRateFuture,inflationRateFuture,1] ;
  aa=[jB,jByear,arateB,dayRateFuture,inflationRateFuture,1] ;
  cuse.push(aa);

// each row of cuse is a cpi index.
// [dayCount,year,cpi,dailyInflationRate,yearlyInflationRate,flag
// where the dailyInflationRate and yearlyInflationRate are calculated using this entry and the prior entry  (they are backwards looking)
// flag is 0 for actual entries, 1 if imputed
   return cuse ;


}

//===================
// missing assets -- show a warning screen
function showAssetProblems(ifoo) {
  let bmess='';
  bmess+='<b>Asset definition errors</b><br>';
  bmess+='There are one (or more) assets specified in one (or more) portfolios that are <u>not</u> defined!<br>';
  bmess+='You <u>must</u> specify these assets. <br>';
  bmess+='<table border=1" xrules="rows" cellpadding="4" width="90%">';
  bmess+='<tr><th width="15%">Asset</th><th width="15%">Status</th><th>Type </th><th width="55%">Appears in portfolios ...</th></tr>';

  for (let zasset in assetsUsed['list']){

     let gg=assetsUsed['list'][zasset];
     if (gg['exist'] <1) {
         bmess+='<tr><td>'+zasset+'</td>';
         if (gg['exist']<0) {
            bmess+='<td>Not specified</td>';
         } else {
            bmess+='<td>Specifed, but no history entries</td>';
         }
         
         let aicon=getAssetType(+gg['type'],'say')   ;
         bmess+='<td>'+aicon+'</td>';
         let aa=[];
         for (let pp1 in gg['portfolios']) {
             aa.push(pp1);
         }
         bmess+='<td>'+aa.join(' | ')+'</td>';
         bmess+='</tr>';
     }
   }
     bmess+='</table>';

   displayStatusMessage(bmess);
   toggleStatusMessage(0);

}

//=============
// display div in new window
function displayInWindow(athis) {
  let ethis=wsurvey.argJquery(athis);
  let aid=ethis.attr('data-id');
  let eid=$('#'+aid);
  let arf=eid.html();
  let hmess='<html><head><title>simInv: help and tips </title> ';
   hmess+='<link rel="stylesheet" type="text/css" href="simInv.css" />  ';
   hmess+='</head><body>';
   hmess+=arf;
   hmess+='</body></html>';

  wsurvey.displayInNewWindow(0,{'content':hmess});
}

//===============
// expand window to fill screen
// 2 arguments  for dirdct call  -- to remove expand class
function fillTheWindow(athis,athis2) {
  let isfull=false,aid,aid2,ethis;
  if (arguments.length==2) {
      aid=athis;
      aid2=athis2;
  } else {
       ethis=wsurvey.argJquery(athis);
     aid=ethis.attr('data-id');
     aid2=ethis.attr('data-id2');
     isfull=ethis.attr('data-full');
  }
  let eid=$('#'+aid);
  let eid2=$('#'+aid2);

  if (isfull!==false) {
     isfull=1-isfull;
     ethis.attr('data-full',isfull);
  }
  if (isfull==1) {
     eid.addClass('cmakeWindowFull');
     if (eid2.length>0)  eid2.addClass('cmakeWindowFull2');
     ethis.css({'background-color':'lime'});
     ethis.attr('title','Click to unExpand ');
  } else {
     if (isfull!==false) {
        ethis.css({'background-color':''});
        ethis.attr('title','Click to expand (to fill window) ');
     }
     eid.removeClass('cmakeWindowFull');
     if (eid2.length>0)  eid2.removeClass('cmakeWindowFull2');

  }
  return 1;
 }

//================
// changep ersonal settings
function personalSettings(athis) {
  let bmess='';
  bmess+='<div id="ipersonalSetting">';
  bmess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#settingsHelp1">&#10068;</button>';
//  bmess+='<input type="button" value="?" title="Notes" onClick="$(\'#settingsHelp1\').toggle()"> ';
  bmess+='You can personalize the following settings ';
  bmess+=' ... and then  ';
  bmess+='<button class="csaveButton"  id="ipersonalSettingSaveButton" onClick="personalSettingsSave(this)"> ';
  bmess+='Save them </button> ';
  bmess+='<span style="margin-left:3em"><em>Use <button> &#11192; &#206;nflation</button> to view &amp; change the inflation series ....</em></span>';

  bmess+='<ul class="boxList">';

  bmess+='<li>Cash interest rates: ';
  bmess+='<br>   <u>Cash</u> &gt; 0.0 : <input size="6" type="text" name="cashInterest" value="'+cashInterest+'">   ';
  bmess+='&#8286; &#8286; <u>Cash</u> &lt; 0.0 : <input size="6" type="text" name="cashPenalty" value="'+cashPenalty+'">';

  bmess+='<li>Tax rates: ';
  bmess+='<span style="display:inline-block;white-space:nowrap"> ';
  bmess+='Income tax rate: <input size="6" type="text" name="taxRate" value="'+taxRate+'">';
  bmess+='  &#8286; &vellip; Capital gains tax rate: <input  size="6" type="text" name="capGainsRate" value="'+capGainsRate+'">';
  bmess+='</span>';

  bmess+='<li>Reporting range: ';
  bmess+='<span style="display:inline-block;white-space:nowrap"> ';
  bmess+=' first year <input type="text"  size="6" name="firstYearUse" value="'+firstYearUse+'">';
  bmess+=' to  last year <input type="text"  size="6" name="lastYearUse" value="'+lastYearUse+'">';
  bmess+='</span>';

  bmess+='<li>Encryption key hint:<input type="text"  size="45" name="encryptionKeyHint" value="'+encryptionKeyHint+'">';
  bmess+='<em> optional: you can use this to help you remember your personal encryption key</em>';

  bmess+='<li>Warnings: 0=show all, 1=show fewer ';
  bmess+='<input type="text"  size="2" name="warningLevel" value="'+warningLevel+'">';

  bmess+='<li>How to first display a portfolio`s initialization and modfification entries?: ';
  bmess+=' 0=small buttons, 1=larger buttons, 2=larger buttons and summary table, 3=small buttons and summary table, 4= summary table  ';
  bmess+='<input type="text"  size="2" name="showTransactions" value="'+showTransactions+'">';

  bmess+='<li>Automatically add entry dates to the list of displayDates : 0=do not, 1=add creation dates, 2=add creation and modification dates ';
  bmess+='<input type="text"  size="2" name="addEntryDates" value="'+addEntryDates+'">';

  bmess+='<li>Automatically add calendars dates to the list of displayDates : 0=do not, 1=Jan 1, 2: Jan1 &amp; July1, 4: quarterly, 12:monthly, 52:weekly';
  bmess+='<input type="text"  size="2" name="addEntryDates_yearly" value="'+addEntryDates_yearly+'">';

  bmess+='<li>If remaining Abs(cash) is gt than this fraction of the budget (or netValue), issue various warning (such as a  <tt>confirm?</tt> when saving)  ';
  bmess+='<input type="text"  size="2" name="budgetRemainPct" value="'+budgetRemainPct+'">';

  bmess+='<li>Number of years to use when estmating <em>future inflation rates</em>. Must be at least 1  ';
  bmess+='<input type="text"  size="2" name="inflationAverageTimespan" value="'+inflationAverageTimespan+'">';

  bmess+='<li>Allow more than one asset from the same <u>family</u> to be in a portfolio. ';
  bmess+='Example: <tt>funStock.1</tt> and <tt>funstock.2</tt> are in the <u>family</u>.';
  bmess+='<br>0=do <u>not</u> allow, 1=allow <input type="text"  size="2" name="sameAssetFamilyOk" value="'+sameAssetFamilyOk+'">';

//  bmess+='<li>Additions (to   bonds) are drawn from <u>Cash</u>: ';
//  bmess+='<span style="display:inline-block;white-space:nowrap"> ';
//  bmess+='0=do <u>not</u> draw from <u>Cash</u>, 1=draw from <u>Cash</u> <input type="text"  size="2" name="additionsFromCash" value="'+additionsFromCash+'">';
//  bmess+='</span>';

  bmess+='</ul>';
  bmess+='</div>';     ///  ipersonalSetting


  displayStatusMessage(bmess);
  toggleStatusDiv(0,0);       // makt it big

  if (athis===2) {   // auto save -- this is used when cpiuSeries is updated
     $('#ipersonalSettingSaveButton').trigger('click');
  }
}

// ============== save personal settings
function personalSettingsSave(athis) {
   let e1=$('#ipersonalSetting');

   let eint1=e1.find('[name="cashInterest"]');
   let ainterest=jQuery.trim(eint1.val());
   if (!jQuery.isNumeric(ainterest)) {
      alert("Cash interest rate is not a number: "+ainterest);
      return 0;
   }

   let eint2=e1.find('[name="cashPenalty"]');
   let apenalty=jQuery.trim(eint2.val());
   if (!jQuery.isNumeric(apenalty)) {
      alert("Cash penalty rate (interest on -Cash)   is not a number: "+apenalty);
      return 0;
   }


   let erate=e1.find('[name="taxRate"]');
   let arate=jQuery.trim(erate.val());
   if (!jQuery.isNumeric(arate)) {
      alert("Income tax rate is not a number: "+arate);
      return 0;
   }
   if (arate<0  || arate>1.0) {
      alert("Income tax rate should be between 0.0 and 1.0: "+arate);
      return 0;
   }

   let ecapgains=e1.find('[name="capGainsRate"]');
   let acapgains=jQuery.trim(ecapgains.val());
   if (!jQuery.isNumeric(acapgains)) {
      alert("Capital gains tax rate is not a number: "+acapgains);
      return 0;
   }
   if (acapgains<0  || acapgains>1.0) {
      alert("Capital gains tax rate should be between 0.0 and 1.0: "+acapgains);
      return 0;
   }

   let efirstYear=e1.find('[name="firstYearUse"]');
   let afirstYear=jQuery.trim(efirstYear.val());
   let elastYear=e1.find('[name="lastYearUse"]');
   let alastYear=jQuery.trim(elastYear.val());

   if (!jQuery.isNumeric(afirstYear)) {
      alert("First year is not a number: "+afirstYear);
      return 0;
   }
   if (!jQuery.isNumeric(alastYear)) {
      alert("Last year is not a number: "+alastYear);
      return 0;
   }
   if (afirstYear>alastYear) {
      alert('First year ('+afirstYear+')  is greater than last year ('+alastYear+')');
      return 0;
   }
   if (alastYear>theMaxYear || afirstYear<theMinYear) {
      let qq=confirm('Your first and last years ('+afirstYear+' to '+alastYear+') are unusual. Are you sure you want to use them?');
      if (!qq) return 0;
   }

   let ehint=e1.find('[name="encryptionKeyHint"]');   // this is used as is
   let ahint=jQuery.trim(ehint.val());

   let ewarningLevel=e1.find('[name="warningLevel"]');
   let warningLevel=jQuery.trim(ewarningLevel.val());
   if (warningLevel!='1') warningLevel=0;

   let eshowTranscations=e1.find('[name="showTransactions"]');
   let showTransactions=jQuery.trim(eshowTranscations.val());
   if (!jQuery.isNumeric(showTransactions) || showTransactions<0 || showTransactions>4) showTransactions=0;
   showTransactions=parseInt(showTransactions);
    //alert('using '+showTransactions);

   let eaddEntryDates=e1.find('[name="addEntryDates"]');
   let addEntryDates=jQuery.trim(eaddEntryDates.val());
   if (!jQuery.isNumeric(addEntryDates)) addEntryDates=0;
   addEntryDates=parseInt(addEntryDates);
   if (addEntryDates<0 || addEntryDates>2) addEntryDates=0;

   let eaddEntryDatesDaily=e1.find('[name="addEntryDates_yearly"]');
   let addEntryDates_yearly=jQuery.trim(eaddEntryDatesDaily.val());
   if (!jQuery.isNumeric(addEntryDates_yearly)) addEntryDates_yearly=1;
   addEntryDates_yearly=parseInt(addEntryDates_yearly);
   if (addEntryDates_yearly<0) addEntryDates_yearly=0;
   if (addEntryDates_yearly>52) addEntryDates_yearly=52 ;

   let ebudgetRemainPct=e1.find('[name="budgetRemainPct"]');
   let budgetRemainPct=jQuery.trim(ebudgetRemainPct.val());
   if (!jQuery.isNumeric(budgetRemainPct)) budgetRemainPct=0.005;
   budgetRemainPct=parseFloat(budgetRemainPct);
   if (budgetRemainPct<0 || budgetRemainPct>1.0) budgetRemainPct=0.005;

   let einflationAverageTimespan=e1.find('[name="inflationAverageTimespan"]');
   let inflationAverageTimespan=jQuery.trim(einflationAverageTimespan.val());
   if (!jQuery.isNumeric(inflationAverageTimespan)) inflationAverageTimespan=5 ;
   inflationAverageTimespan=parseInt(inflationAverageTimespan);
   if (inflationAverageTimespan<1  ) inflationAverageTimespan=1;

   let esameAssetFamilyOk=e1.find('[name="sameAssetFamilyOk"]');
   let sameAssetFamilyOk=jQuery.trim(esameAssetFamilyOk.val());
   if (sameAssetFamilyOk!='1') sameAssetFamilyOk=0;

//   let eadditionsFromCash=e1.find('[name="additionsFromCash"]');
//   let additionsFromCash=jQuery.trim(eadditionsFromCash.val());
//   if (additionsFromCash!='1') additionsFromCash=0;

  let ddata={};
  ddata['todo']='saveSettings';
  ddata['username']=userName;
  ddata['encMd5']=encryptionKey_md5;
   ddata['list']={};
  ddata['list']['firstYearUse']=afirstYear ;  // defaults
  ddata['list']['lastYearUse']=alastYear ;
  ddata['list']['taxRate'] =arate ;  // defaults
  ddata['list']['capGainsRate']=acapgains ;
  ddata['list']['cashInterest']=ainterest;
  ddata['list']['cashPenalty']=apenalty;
  ddata['list']['warningLevel']=warningLevel;
  ddata['list']['encryptionKeyHint']=ahint;
  ddata['list']['showTransactions']=showTransactions;
  ddata['list']['addEntryDates']=addEntryDates;
  ddata['list']['addEntryDates_yearly']=addEntryDates_yearly;
  ddata['list']['budgetRemainPct']=budgetRemainPct;
  ddata['list']['inflationAverageTimespan']=inflationAverageTimespan;
  ddata['list']['sameAssetFamilyOk']=sameAssetFamilyOk;
//  ddata['list']['additionsFromCash']=additionsFromCash;
  ddata['list']['cpiuSeries']=cpiuSeries;
  ddata['list']['hint']=ahint ;

  saveSimInvData(ddata);


 }

//================
// create display dates table ..........
function createViewDates(ifoo) {

  let vmess=' <hr>';
  vmess+='<input type="button" value="x" title="close this" onClick="wSurvey.wsShow.hide(this,100)" data-wsshow="-2"> ';
  vmess+='<button title="Click to add a new display date" onClick="addARowViewDate(this)">Add</button>';
  vmess+=' <b>display dates</b>';
  vmess+='<span style="margin-left:3em;padding;3px">';
  vmess+='<button onClick="saveViewDates(this)" class="csaveButton"> Save these display dates</button> ';
  vmess+='(they will be sorted, with duplicates removed)</span>' ;
  vmess+='<br> &vellip; ';

  if (addEntryDates==1) {
      vmess+='<em>The creation dates (for all portfolios) will be automatically added.</em> ';
  } else if (addEntryDates==2){
      vmess+='<em>The creation &amp; modifications dates (for all portfolios) will be automatically added.</em> ';
  }
  if (addEntryDates_yearly>=26) {
      vmess+=' <em>Display dates will be automatically added  for every week. </em> ';
  } else if (addEntryDates_yearly>10) {
      vmess+=' <em>Display dates will be automatically added  for every month. </em> ';
  } else if (addEntryDates_yearly>3) {
      vmess+=' <em>Display dates will be automatically added  for every quarter year. </em>';
  } else  if (addEntryDates_yearly>1) {
      vmess+=' <em>Display dateswill be automatically added  for Jan 1 and July of every year. </em>';
  } else  if (addEntryDates_yearly>0) {
      vmess+=' <emDisplay dates will be automatically added  for Jan 1  of every year. </em>';
  }
   vmess+='&nbsp;&nbsp; &vellip; ';

  vmess+='<table style="margin:3px 2em;border:1px solid gray" id="viewDatesTable" rules="cols">';
  vmess+='<tr><td style="width:7em">...</td> <td style="width:7em">Year</td> <td style="width:7em">Month</td> <td style="width:7em">Day</td> </tr>';

  let arf0=setEntryDate(firstYearUse,1,1)

 
  vmess+='<tr class="viewDateRow0">';
      vmess+='<td><span " title="Earliest portfolio creation date (or start of reporting range)"  ><em>first</em></span></td>';
      vmess+='<td><input name="viewYear" type="hidden" value="'+arf0['year']+'"> '+arf0['year']+'</td>';
      vmess+='<td><input name="viewMonth" type="hidden" value="'+arf0['month']+'">  '+arf0['month']+'</td> ';
      vmess+='<td><input name="viewDay" type="hidden" value="'+arf0['day']+'"> '+arf0['day']+'</td>';
      vmess+='</tr>';

  for (let ii=0;ii<viewDates['list'].length;ii++) {
      let arf=setEntryDate(viewDates['list'][ii]) ;
      vmess+='<tr class="viewDateRow">';
      vmess+='<td><input type="button" value="Remove" title="Remove this display date" onClick="removeViewDateRow(this)"></td>';
      vmess+='<td><input name="viewYear" type="hidden" value="'+arf['year']+'"> '+arf['year']+'</td>';
      vmess+='<td><input name="viewMonth" type="hidden" value="'+arf['month']+'">  '+arf['month']+'</td> ';
      vmess+='<td><input name="viewDay" type="hidden" value="'+arf['day']+'"> '+arf['day']+'</td>';
      vmess+='</tr>';
  }

  let arf1=setEntryDate(lastYearUse,12,31)
      vmess+='<tr class="viewDateRow0">';
      vmess+='<td><span " title="End of reporting range "  ><em>last</em></span></td>';
      vmess+='<td><input name="viewYear" type="hidden" value="'+arf1['year']+'"> '+arf1['year']+'</td>';
      vmess+='<td><input name="viewMonth" type="hidden" value="'+arf1['month']+'">  '+arf1['month']+'</td> ';
      vmess+='<td><input name="viewDay" type="hidden" value="'+arf1['day']+'"> '+arf1['day']+'</td>';
      vmess+='</tr>';

  vmess+='</table>';

  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.show('#mainDiv2','show');
  wsurvey.wsShow.hide('#mainDiv3',122);
  $('#mainDiv2').html(vmess) ;
  return 1;
}

// ===========
// add row to display dates table
function addARowViewDate(athis) {
      let arf=setEntryDate(true);
      let vmess='';
      vmess+='<tr class="viewDateRow">';
      vmess+='<td><input type="button" value="Remove" title="Remove this display date ..." onClick="removeViewDateRow(this)"></td>';
      vmess+='<td><input name="viewYear" type="text" size="5" value="'+arf['year']+'" title="year"></td>';
      vmess+='<td><input name="viewMonth"  type="text" size="5" value="'+arf['month']+'" title="month"></td>';
      vmess+='<td><input name="viewDay"  type="text" size="5" value="'+arf['day']+'" title="day"></td>';
      vmess+='</tr>';
      $('#viewDatesTable').append(vmess);

}

//==================
// remove row from display date table
function removeViewDateRow(athis) {
   let ethis=wsurvey.argJquery(athis);
   let etr=ethis.closest('.viewDateRow');
   etr.remove();
}

//=================
// save display dates
function saveViewDates(athis) {
   let etable=$('#viewDatesTable');
   let etrs=etable.find('.viewDateRow');

   let stuff=[];
   for (let ie1=0;ie1<etrs.length;ie1++) {
       let erow=$(etrs[ie1]);
       let eyear=erow.find('[name="viewYear"]');
       let ayear=jQuery.trim(eyear.val());

       let emonth=erow.find('[name="viewMonth"]');
       let amonth=jQuery.trim(emonth.val());

       let eday=erow.find('[name="viewDay"]');
       let aday=jQuery.trim(eday.val());

       let vd1=setEntryDate(ayear,amonth,aday);
       if (vd1===false) return 0;  // alert happens if bad year/month/ or day
       let dayCount=vd1['dayCount'];

       let arf0=setEntryDate(firstYearUse,1,1)
       if (dayCount<=arf0['dayCount']) {
           alert('Chosen date ('+vd1['sayDate']+') is before the Reporting Range, or before the first portfolio\'s creation date.\n You can change the Reporting Range in \u26ED settings');
           return 1;
       }

       let arf1=setEntryDate(lastYearUse,12,31)
       if (dayCount>=arf1['dayCount']) {
           alert('Chosen date  ('+vd1['sayDate']+') is after the Reporting Range. \nYou can change the Reporting Range in \u26ED  settings)');
           return 1;
       }
       stuff.push(dayCount);
   }

  stuff.sort(sortNoDuplicates);   // remove duplicates, sort ascenting
  let ddata={};
  ddata['todo']='saveViewDates';
  ddata['list']=stuff;
  ddata['username']=userName ;
  ddata['encMd5']=encryptionKey_md5;
  saveSimInvData(ddata );

}

//===============
// display a statusmessage
// amess===false: close displayStatuMessage
// iappend: if 1, append to current status message IF VISIBLE.  2: append always

function displayStatusMessage(amess,iappend,ifade) {
  if (amess===false) {
    if (arguments.length<3) ifade=100;
    ifade=parseInt(ifade);
     wsurvey.wsShow.hide('#statusDiv',ifade);
     return 1;
  }
  if (arguments.length<2) iappend=0;
  let emess=$('#statusMessage_message');
  if (iappend==0)   {
    emess.html(amess);
  } else {
    if (iappend==2) {
       emess.append(amess);
   } else {
      if (emess.is(':visible')) {
       emess.append(amess);
      }
   }

  }
  wsurvey.wsShow.show('#statusDiv','show');
}

//==========
// toggle size of sattusDiv 
// if one arg -- data-isbig has current size -- toggle it
// If 2 args, athis is ignored
// istatus:1 -- shrink
//         0  -- expand 

function toggleStatusMessage(athis,istatus) {   // a synonym
  if (arguments.length<2) {
   toggleStatusDiv(athis,istatus);
  } else {
   toggleStatusDiv(athis,istatus);
  }
   return 1;
}

// ---
// istatus is current status --- toggle away from this
// 0: normal, 1:small, 2:lower, 3: big

function toggleStatusDiv(athis,istatus) {
  let ediv=$('#statusDiv');
  let ethis;
  if (arguments.length<2)  {
     ethis=wsurvey.argJquery(athis);
     let s1=ethis.attr('data-isbig');    // the current status
     istatus=0;  // change to this
     if (s1==0) istatus=1;
     if (s1==1) istatus=2;
     if (s1==2) istatus=3;
  }  else {
     ethis=ediv.find('[name="toggleSizeButton"]');
     let s1=istatus ;
     istatus=0 ;    // the default is normal
     if (s1==1) istatus=1;
     if (s1==2) istatus=2;
     if (s1==3) istatus=3;
  }

    ediv.removeClass('cStatusDivSmall cStatusDivLower cStatusDivBig');

   if (istatus==2) {    //    make lower
      ediv.addClass('cStatusDivLower');
  } else if (istatus==3) {           // lower, make small
      ediv.addClass('cStatusDivBig');
  } else if (istatus==1) {           // lower, make small
      ediv.addClass('cStatusDivSmall');
  }  // else, normal
  ethis.attr('data-isbig',istatus);   // set the current status
  return 1;
}

//===============
// toggleStatus -- with "selec which size"
function toggleStatusDiv2(athis,istatus) {
  let ebb=$('#statusDivOpts');

  if (arguments.length<2 || istatus===false) {
     ethis=wsurvey.argJquery(athis);
     let lastClick=ethis.attr('data-click');
     let nowTime=wsurvey.get_currentTime(0)
     ethis.attr('data-click',nowTime);
     let dd=nowTime-lastClick;
     if (dd<1000) {  // double click -- toggle
           toggleStatusDiv(athis) ;
           ebb.hide();
     }   else {
       ebb.show();
     }
    return 1;
  }
// else, show options bar
  toggleStatusDiv(athis,istatus) ; // 2 args -- do nothing here


}

// handler for  toggleStatusDiv2 actions
function toggleStatusDiv2a(ido) {
  let ebb=$('#statusDivOpts');
  if (ido==-1) {
     ebb.hide();
     return 0;  // just hide
  }
  toggleStatusDiv2(0,ido);
}


//=================
// resize status. single click to enlarge, double to shrink
// isize: 0- regular full size. nn : add nn%, -nn: subtract nn%
//  if isize not specified, add 10 to nn in data-size (minimum of 50px or window size
//    14 july 2023 ... not working right, don't use
function resizeStatusDiv(athis) {
     let ediv=$('#statusDiv');
     ediv.removeClass('cStatusDivSmall');

     let ethis=wsurvey.argJquery(athis);
     let isize=parseInt(ethis.attr('data-size'));
     let lastClick=ethis.attr('data-click');
     let origHeight=parseInt(ethis.attr('data-origheight'));
     let origWidth=parseInt(ethis.attr('data-origwidth'));
     let nowTime=wsurvey.get_currentTime(0)
     ethis.attr('data-click',nowTime);

     let nowWidth=ediv.width();
     let nowHeight=ediv.height();

     if (origHeight==0) {
        ethis.attr('data-origheight',nowHeight); // set to initial value
        origHeight=nowHeight;
     }
     if (origWidth==0) {
        ethis.attr('data-orighwidth',nowWidth);
        origWidth=nowWidth;
     }

     let dd=nowTime-lastClick;

     if (dd<1000) {
          isize=isize-20;  // have to subtracdt the add from the first click
       } else {
          isize=isize+10 ;
     }
     ethis.attr('data-size',isize);
     let asize=(100+isize)/100;
     let newHeight=parseInt(origHeight*asize);
     let newWidth=parseInt(origWidth*asize);

    ediv.width(newWidth+'px');
    ediv.height(newHeight+'px');
    ediv.css({'height':newHeight+'px','width':newWidth+'px'});


}

//===============
// display help
function displayHelpMessage(athis,amess,iforce) {
  if (arguments.length<3)  iforce=0;
  let other=false;
  let fromDiv;
  if (arguments.length<2 || amess===false)  {
    if (typeof(athis)=='string') {
         fromDiv=athis;
    } else {
        let ethis=wsurvey.argJquery(athis);
        fromDiv=ethis.attr('data-div');
    }
    if (fromDiv=='#encryptionKeyHelp1') other='encryptionHelp'


    let efrom=$(fromDiv);
    if (efrom.length==0) {
      alert('bad fromDiv  (help) ('+fromDiv+')');
      return 0;
    }
     amess=efrom.html();
  }
  $('#helpDiv_message').html(amess);

  let ehd=$('#helpDiv');
  ehd.removeClass('cHelpDivSmaller cHelpDivSmall');
  let ebb=ehd.find('[name="toggleSizeButton"]');
  ebb.attr('data-nowsize',1);
  if (iforce==0) {
    wsurvey.wsShow.show('#helpDiv','toggle');
  } else {
    wsurvey.wsShow.show('#helpDiv','show');
  }

  if (other===false) return 1;
  
// do some customizations
 if (other=='encryptionHelp') {
   let cmess;
   if (encryptionKey!='')  {
      cmess='<div style="border:1px dotted green;padding:3px;margin:1em 4em">Hello <tt>'+userName+'</tt>  -- you have <b>enabled</b> encryption!</div>';
   } else {

     cmess='<div style="border:1px dotted green;padding:3px;margin:1em 4em">Hello <tt>'+userName+'</tt>  -- you have <b>not enabled</b> encryption! Note that encryption can only be enabled when you initialize (on your first logon)</div>';
   }

    $('#encryptionHelp_custom').html(cmess).show();
 }

}

//==========
//toggle size of hgelpt
//1 = normal size (60% of screen), 2= small (30%) = 3=smaller (15%)
function toggleHelpDiv(athis) {
  let ediv=$('#helpDiv');

  let ethis=wsurvey.argJquery(athis);
  let istatus=ethis.attr('data-nowsize');

  ediv.removeClass('cHelpDivSmaller cHelpDivSmall');

  if (istatus==1) {    //  is big, so srhink
      ediv.addClass('cHelpDivSmall');
      ethis.attr('data-nowsize',2);
  } else if (istatus==2) {    //  is smallg, so srhink some more
      ediv.addClass('cHelpDivSmaller');
      ethis.attr('data-nowsize',3);

  } else {                     // reset to big

      ethis.attr('data-nowsize',1);
  }
  return 1;
}

//==========================
// display a response from the server
// if noReload=1, do NOT show a "reload button" (defualt is to show )
// autologon: if noReload=0, trigger this button on reload ( in addition to auto logging on)
function displayResponseFromServer(amess,autologon,noReload) {
  if (arguments.length<2) autologon=0;
  if (arguments.length<3) noReload=0;

  $('#statusDivServerResponse_message').html(amess);

  wsurvey.wsShow.show('#statusDivServerResponse','show');

  if (noReload!=1) {
     $('#statusDivServerResponse_reload').show();
     $('#statusDivServerResponse_logoff').attr('data-reload',autologon)

  } else {
     $('#statusDivServerResponse_reload').hide();
  }

  return 1;
}




//===============
// create portfolio lookup "hash"   -- use portfolioHistory  and portfolioInit globals

function  makePortfolioLookup(aplist,modlist) {

  plookup={'list':{},'info':{}};

  let date1=111111111111111111111 ;
  let date2=-11111111111111111111 ;
  let nEntries=0;
  let allDates=[];

   for (let i1=0;i1<aplist.length;i1++) {       // list of portfolios
     let anyDateAsset={} ;
     let modDates=[];
     let totNets={},nAssets={},nIncomes={},modDatesSay={},comments={},assetsList={};;

     let didInit=0;
     let nHistory=0;
     let abudget=0,creationDate=0,creationDateSay=0;
     let dname=aplist[i1]['name'];

     if (aplist[i1]['exists']==0)  {  // no init -- so it needs initialization (and nothing else to do)!
       plookup['list'][dname]={'ith':i1,'isInit':0,'nHistory':0,'creationDate':false,'creationDateSay':'','modDates':[]};
       continue ;
    }

//   init entry (for this portfolio) exists

     didInit=1;
     nHistory=1;

     let oink0=portfolioInit[dname];

     abudget=parseInt(oink0['original']['budget']);
      creationDate=parseInt(oink0['dateStamp']) ;
      creationDateSay=oink0['dateStampSay'] ;

     let assetsListNow={};
     for (let aa1 in oink0['assets']) {
         assetsListNow[aa1]=1;
         if (!anyDateAsset.hasOwnProperty(aa1)) anyDateAsset[aa1]=0;
         anyDateAsset[aa1]++ ;
     }
     assetsList[creationDate]=assetsListNow ;

     allDates.push(parseInt(creationDate));

     date1=Math.min(date1,creationDate);
     date2=Math.max(date2,creationDate);
     nEntries++;

// modDates is sorted (by date) array... that contains dateStamps used in the totNets, etc data objects

     modDates[0]=parseInt(creationDate) ;              // first entry in  modDates is always the initialization date
      totNets[creationDate]=parseFloat(oink0['totNetValue']);
      nAssets[creationDate]=parseFloat(oink0['totals']['nAsset']);
      nIncomes[creationDate]=parseFloat(oink0['totals']['nIncome']);
      modDatesSay[creationDate]=oink0['dateStampSay'] ;
      comments[creationDate]=oink0['comment'] ;

// now for the modifications ...
     if (modlist.hasOwnProperty(dname))  {
           for (let aa1 in  modlist[dname]['list']) {   // aa1 is the mod date
              allDates.push(parseInt(aa1));

              modDates.push(parseInt(aa1)) ;
              let oink=modlist[dname]['list'][aa1];

             let assetsListNow={};
             for (let aa1 in oink['assets']) {
               assetsListNow[aa1]=1;
               if (!anyDateAsset.hasOwnProperty(aa1)) anyDateAsset[aa1]=0;
               anyDateAsset[aa1]++ ;
             }
             assetsList[aa1]=assetsListNow ;

              totNets[aa1]=parseFloat(oink['totNetValue']);

              nAssets[aa1]=parseInt(oink['totals']['nAsset']);
              nIncomes[aa1]=parseInt(oink['totals']['nIncome']);
              modDatesSay[aa1]=oink['dateStampSay'] ;
              comments[aa1]=modlist[dname]['modComments'][aa1];
              nHistory++;
           }
     }        // modifications


     let oof=sortNoDuplicates(modDates);

      plookup['list'][dname]={'ith':i1,'isInit':didInit,'budget':abudget,'nHistory':nHistory,
           'creationDate':creationDate,'creationDateSay':creationDateSay,'modDates':oof,
           'assetsList':assetsList,
           'totNets':totNets,'nAssets':nAssets,'nIncomes':nIncomes,'modDatesSay':modDatesSay,'comments':comments
        }
        let nAnyDateAsset=0;
        for (let foo in anyDateAsset) nAnyDateAsset++;
        plookup['list'][dname]['anyDateAsset']=anyDateAsset  ;
        plookup['list'][dname]['nAnyDateAsset']=nAnyDateAsset  ;

  }           // dname

// got all inits and mods....

  let oof2=sortNoDuplicates(allDates);

  plookup['info']['allDates']=oof2;
  plookup['info']['firstDateInit']=date1;
  plookup['info']['lastDateInit']=date2;
  plookup['info']['nEntries']=nEntries;

  return plookup;


}


//==============
// return sort list of numbers, duplicates removed
// all non-number values are at beginning of list, sorted lexigrapically. 
// The sort of these non-numbers may not be fully as expected

function sortNoDuplicates(alist0) {
  let alist=[];
  if (alist0.length==0) return alist ;
  for (let ii=0;ii<alist0.length;ii++) alist[ii]=alist0[ii];  // clone

  alist.sort(mySortNumeric);   // numeric sort. Non numbers appear before numbrs
  let oof2=[];
  iwas=alist[0];
  oof2[0]=iwas;
   for (let jj=1;jj<alist.length;jj++) {  // get rid of duplicates
         let adate=alist[jj];
         if (adate!==iwas) {
             oof2.push(adate);
             iwas=adate;
         }
    }
    return oof2;
}

// === ================
// sort by number value.
// if an element is NOT a number, it is "before" a number
// if both are not numbers, sort lexigraphically

function mySortNumeric(a,b) {
   if (!jQuery.isNumeric(a) || !jQuery.isNumeric(b)) {  // one or both not numbers
       if (jQuery.isNumeric(a)) return 1 ;     // just b is nonnumeric, so b should  be before a
       if (jQuery.isNumeric(b)) return -1 ;   // just a is nonnumeric, so a should  be before b
       if (a>b) return  1;
       if (a==b) return 0;
       return -1 ;
   }
   let a1=parseFloat(a);  // both are numbers
   let b1=parseFloat(b);
   return a1 - b1;
}


// ==============
/// create loan schdedules ==  portfolio / date / asset / ...
// careful: order of properties in plookups a bit differnt tha in aportfolioLoans
function   makePortfolioLoans(plookups){
  let aportfolioLoans={} ;        // is returned
  for (let pname in plookups  ) {
     if (!aportfolioLoans.hasOwnProperty(pname)) aportfolioLoans[pname]={} ;
     for (let aname in plookups[pname])  {
       for (let dStamp in plookups[pname][aname]) {
         if (!aportfolioLoans[pname].hasOwnProperty(dStamp)) aportfolioLoans[pname][dStamp]={} ;

         let vv=plookups[pname][aname][dStamp];
         let loanAmount=vv[0],loanTerm=vv[1],loanRate=vv[2],loanTaxDeduct=vv[3];

         let daLoan0=figLoanSchedule(loanAmount,loanTerm,loanRate);
         let daLoan1=figLoanSchedule_cum(daLoan0,loanAmount,dStamp);  // makePortfolioLoans
         daLoan=figLoanSchedule_cumAT(daLoan1,loanTaxDeduct,taxRate)  ; // taxRate is global
         daLoan['startDate']=dStamp ;
         daLoan['amount']=loanAmount ;
         daLoan['term']=loanTerm;
         daLoan['rate']=loanRate;
         daLoan['taxDeduct']=loanTaxDeduct;

         let cumMonth=daLoan['cumMonth'];
         let loanArray=[];
         for (let idate in cumMonth) loanArray.push(parseInt(idate));

         delete daLoan['cumMonth'];

         aportfolioLoans[pname][dStamp][aname] ={'loanSchedule':daLoan,'loanPaymentsDates':loanArray,'loanPayments':cumMonth};

       }           // dStamp
     }   //aname
  }   // pname


  return aportfolioLoans ;

}

//=============
// create the assetLookup Hash Table

function makeAssetLookup(alist,ahist,assetAutoAdds) {
  let ahash={};

//  wsurvey.dumpObj(alist,1,'alist in makesetlookup ');
//  wsurvey.dumpObj(ahist,1,'ahst in makesetlookup ');
//   wsurvey.dumpObj(assetAutoAdds,1,'assetAutoAdds in makesetlookup ');

  if (typeof(alist)=='undefined' || ahist===false) alist=[] ;
  if (typeof(ahist)=='undefined' || ahist===false) ahist={} ;
  if (typeof(assetAutoAdds)=='undefined' || assetAutoAdds===false) assetAutoAdds={} ;

  for (let i1=0;i1<alist.length;i1++) {

    if (typeof(alist[i1])=='undefined') continue ;
     let dname=alist[i1]['name'];
     ahash[dname]={};
     for (let agoo in alist[i1]) {
        if (agoo!='name')   ahash[dname][agoo]=alist[i1][agoo];
     }

     if (!ahash[dname].hasOwnProperty('lossesOffsetIncome')) ahash[dname]['lossesOffsetIncome']=1;
     if (!ahash[dname].hasOwnProperty('constantIncome')) ahash[dname]['constantIncome']=0;

     ahash[dname]['nHistory']=0;
     ahash[dname]['firstHistoryDate']=false;

     let nHistory=0,firstEntryDate=false ;
     let d0=0;
     let earliestEntry=false;
     let latestEntry=false ;

     if (ahist.hasOwnProperty(dname)) {
        nHistory= ahist[dname].length   ;
        if (nHistory>0) {
            d0=ahist[dname][0]['date'];
            let oof=setEntryDate(d0);
            firstEntryDate=oof['sayDate'];
            earliestEntry=111111111111;
            latestEntry=-1111111111111 ;
            for (let ik=0;ik<nHistory;ik++) {
               let arf=ahist[dname][ik];
               let kdate=parseInt(arf['date']);
               earliestEntry=Math.min(kdate,earliestEntry);
               latestEntry=Math.max(kdate,latestEntry);
           }
        }     // nhistory
     }        // hist has dname
     ahash[dname]['nHistory']=0;
     ahash[dname]['date']=d0;
     ahash[dname]['firstEntryDateSay']=firstEntryDate;
      ahash[dname]['earliestEntry']=earliestEntry;
      ahash[dname]['latestEntry']=latestEntry;

     let  autoAdd=(assetAutoAdds.hasOwnProperty(dname)) ? assetAutoAdds[dname] : 0 ;  // default is DO NOT autoadd

     ahash[dname]['autoAddEntries']=autoAdd ;
     ahash[dname]['nImputed']=0;                         // updated by    updateAssetHistory_inflation
     ahash[dname]['contantIncomeVariants']=[];            // updated by  updateAssetHistory_income

     if (ahist.hasOwnProperty(dname)) {
         ahash[dname]['nHistory']=ahist[dname].length;
         ahash[dname]['firstHistoryDate']=ahist[dname][0]['date'];
     }

  }

  return ahash;
}

//============
// get a array of asset/dates that are need the constantIncome shortcut
// this works with rawer versions of portofolioInit and portfolioModifications

function getConstantIncomes(initList,modList) {
  let cList=[] ;
  for (let apname in initList) {
    let v1=initList[apname]['assetList'];
    for (let iv=0;iv<v1.length;iv++) {
        let aname=v1[iv]['name'];
        let isConstant=doAssetLookup(aname,'constantIncome');
        if (isConstant==0) continue ;
        let incomeStart=v1[iv]['incomeStart'];
        let a1=[aname,incomeStart,apname,0];
        cList.push(a1)
    }
  }

  for (let apname in modList) {
    let v1=modList[apname]['list'];
    for (let adate in v1)   {
       for (let ith=0;ith<v1[adate]['assetList'].length;ith++) {
          let aname=v1[adate]['assetList'][ith]['name'];
          let isConstant=doAssetLookup(aname,'constantIncome');
          if (isConstant==0) continue ;
          let incomeStart=v1[adate]['assetList'][ith]['incomeStart'];
          let a1=[aname,incomeStart,apname,1];
          cList.push(a1)  ;
       }
    }
  }

  let cList2={};
  for (let jj=0;jj<cList.length;jj++) {
      let dd=cList[jj];
      let aname=dd[0];
      let sdate=dd[1];
      if (!cList2.hasOwnProperty(aname)) cList2[aname]={};
      if (!cList2[aname].hasOwnProperty(sdate)) cList2[aname][sdate]=0;
      cList2[aname][sdate]++;
  }
  return cList2 ;
}

//==========
// cureent outstanding loans

function  getCurrentLoans(initList,modList) {
 
  let cList={} ;
  for (let apname in initList) {
    let v1=initList[apname]['assetList'];
    for (let iv=0;iv<v1.length;iv++) {

        let aname=v1[iv]['name'];
        let loanAmount=v1[iv]['loanAmount'];
        if (loanAmount===false || loanAmount=='false' || loanAmount==0) continue

        let astart=v1[iv]['loanStart'];
        let aterm=v1[iv]['loanTerm'];
        let arate=v1[iv]['loanRate'];
        let adeduct=v1[iv]['loanTaxDeduct'];

        if (!cList.hasOwnProperty(apname)) cList[apname]={};
        if (!cList[apname].hasOwnProperty(aname)) cList[apname][aname]={};

        let a1=[loanAmount,aterm,arate,adeduct];

        cList[apname][aname][astart]=a1   ;

    }      // ith   (asset)
  }        // apname

    for (let apname in modList) {
      let v1=modList[apname]['list'];
      for (let adate in v1)   {
        for (let ith=0;ith<v1[adate]['assetList'].length;ith++) {

          let aname=v1[adate]['assetList'][ith]['name'];
          let loanAmount=v1[adate]['assetList'][ith]['loanAmount'];
          if (loanAmount===false || loanAmount=='false' || loanAmount==0) continue


          let astart=v1[adate]['assetList'][ith]['loanStart'];
          let aterm=v1[adate]['assetList'][ith]['loanTerm'];
          let arate=v1[adate]['assetList'][ith]['loanRate'];
          let adeduct=v1[adate]['assetList'][ith]['loanTaxDeduct'];

          if (!cList.hasOwnProperty(apname)) cList[apname]={};
          if (!cList[apname].hasOwnProperty(aname)) cList[apname][aname]={};

          let a1=[loanAmount,aterm,arate,adeduct];

          cList[apname][aname][astart]=a1  ;

       }  // ith    (asset)
    }  // adate
  }  //  apname

  return cList;

}

///===============
// setup portfolioInit and portfolioModifications
function setupPortfolios(dainit,damods) {      // arguments are clones of resposne from server

 let  errs=[];

 portfolioInit={};      //globals
 portfolioModifications={ };

 for (let pname in dainit['list']) {
    let alls0= dainit['list'][pname] ;
    portfolioInit[pname]=alls0 ;
 }

 if (!damods.hasOwnProperty('list')) damods['list']={} ;

// 1 august 2023: don't bother using the 'dates' in stored modifications
  for (let pname in damods['list']  ) {
    portfolioModifications[pname]={};
    portfolioModifications[pname]={'list':{}, 'modComments':{},'dateArray':[] };
    let darray=[];
    for (let dstamp in damods['list'][pname]['modList']) {   // make a sortable list
       darray.push(dstamp);
    }
    darray.sort(mySortNumeric);

//  start with earliest frist
    for (let idd=0;idd<darray.length;idd++) {
      let dstamp=darray[idd] ;
      let v1= damods['list'][pname]['modList'][dstamp] ;

      portfolioModifications[pname]['list'][dstamp]=v1 ;

      portfolioModifications[pname]['modComments'][dstamp]=damods['list'][pname]['modList'][dstamp]['comment'];
      portfolioModifications[pname]['dateArray'].push(dstamp);
    }
  }  // damods

   if (errs.length>1) {
        let bmess='<b>Decryption errors. Some of your portfolios will not be accessible ';
        bmess+='<ul><li>'+errs.join('<li>')+'</ul>';
        displayStatusMessage(bmess);
   }
   return 1;
}


//====================
// read, decrypt  the  portfolioinit  (that was returned from server) , and make a lookup list
function  makePortfolioInit(dainit,quiet)  {

   let errlist=[];
 
// re create full portfolioInit from what was saved on server -- using currently specified prices, etc
 for (let pjname in portfolioInit) {
    let alist1=portfolioInit[pjname];
    let cashAsset=parseFloat(alist1['cashAsset']);
    let adateStamp=alist1['dateStamp'];

  //  alert('makePortfolioInit portfolioCalcValue for '+pjname);
    let daval0= portfolioCalcValue(alist1['assetList'], adateStamp,pjname,0) ;
    if (daval0===false)  return false ;         // an asset error... there will be a message in the displayStatus box
    let totNetAssetEst=parseFloat(daval0['totals']['totNetAssetEst']);
    let totNetValue=totNetAssetEst +  cashAsset   ;
    portfolioInit[pjname]['cashAsset']=cashAsset;
    portfolioInit[pjname]['totNetValue']=totNetValue;

    portfolioInit[pjname]['totals']=daval0['totals'];
    portfolioInit[pjname]['assets']=daval0['assets'];
    portfolioInit[pjname]['totals']=daval0['totals'];

    let totalsG=calc_netValues(portfolioInit[pjname]) ;

    portfolioInit[pjname]['totalsG']=totalsG;
    let totAdds=0;
    for (let im=0;im<alist1['assetList'].length;im++) {
        let aname=alist1['assetList'][im]['name'];

        let qexists=doAssetLookup(aname,'*');  // does this asset exist?
        if (qexists===false)  {
           errlist.push('Asset `'+aname+'` in portfolio `'+pjname+'` does not exist');
        } else {

          if (qexists['nHistory']==0) {
             errlist.push('Asset `'+aname+'` in portfolio `'+pjname+'` has no entries');
          } else {
             let acomment=alist1['assetList'][im]['comment'];
             portfolioInit[pjname]['assets'][aname]['comment']=acomment;
             let v1=calcAssetValues(aname,adateStamp)  ;
             if (!v1.hasOwnProperty(4)) {
                errlist.push('Asset `'+aname+'` in portfolio `'+pjname+'` has errors in its entries (perhaps its first entry is too late)');
             } else {
                let add1=(v1[4].hasOwnProperty('addition')) ? v1[4]['addition'] : 0 ;
                totAdds+=add1;
             }      // v1[4]
          }  // nhistory
        }
    }
    portfolioInit[pjname]['totals']['additionsPerYear']= totAdds ;
 }

// update portfolioList global  (set exist flag to 1 for portfolios with an initialization entry... 'exists' should be 'isInit'
  for (let iz=0;iz<portfolioList.length;iz++ ) {         // update exists in portfolioList
    let zname=portfolioList[iz]['name'];
    if (portfolioInit.hasOwnProperty(zname)) {
       portfolioList[iz]['exists']=1;
    }
  }

  if (errlist.length>0) {
     let arf='Errors were found in the asset definitions. Please add these assets, or remove portfolios with these assets !';
     for  (iarf=0;iarf<errlist.length;iarf++) arf+='\n * '+errlist[iarf];
     alert(arf);
//     displayStatusMessage(arf,1);
//     toggleStatusMessage(0);
//     alert('Errors were found!'+oy);
  }

 return 1 ;          // portfolioInit is global

}

// ==============================
// recreate portfolios from asset-mixes saved on server

function makePortfolioModify(ifoo) {

 let errs=[];
 let new1={};
 let ith=0;

 for (let pname in portfolioModifications  ) {

    let p0Vals=portfolioInit[pname];     // start with initialization (grow it, and apply the saved "modified" asset-mix

// make sure to start with earliest first  (since later portofolios use growth/etc of the prior portfolio
    let ith=0;
    for (let idd=0;idd<portfolioModifications[pname]['dateArray'].length;idd++) {
      ith++ ;
      let dstamp=portfolioModifications[pname]['dateArray'][idd] ;
      let  priorStamp=p0Vals['dateStamp']   ;

      let  grownEntry0=growPortfolio(pname,p0Vals,priorStamp,dstamp,0)   ; // makePortfolioModify -- recreate modification step 1 (grow prior)

      let alist= portfolioModifications[pname]['list'][dstamp]['assetList'] ;  // the asset-mix from this modification

// difference between grown and selected asset-mix
      let modEntry0=portfolioCalcValue(alist,dstamp,pname,1) ;   // the values of the "grown prior" entry (that is then modified)

      let modifiedEntry=portfolioCalcValueMenu_difference(grownEntry0,modEntry0) ;

// add some stuff  (From the "grown  prior entry"
    modifiedEntry['assetList']=alist;       // note that this IS the asset mix (cashAsset and netValue depend on grown prior, but NOT quantitie in the asset ix)

// make sure 'assets' has comments made during the modification
     for (let ij=0;ij<modifiedEntry['assetList'].length;ij++) {
       a0=modifiedEntry['assetList'][ij];
       let aname=a0['name'];
       let acomment=a0['comment'];
       modifiedEntry['assets'][aname]['comment']=acomment ;
  }

    modifiedEntry['original']=grownEntry0['original'];       // initialization asset mix. 5 july -- not really used, so maybe don't bother
    modifiedEntry['changesGrow']=grownEntry0['changesGrow'];

    let cashAssetGrownPrior=grownEntry0['cashAsset'];      // prior (base) Entry cashAsset +  cashAssetChangeGrow

// update the "after modification" cashAsset using the prior cashAsset, and net expenses (cost-sales) due to modifications
    let cashAssetChangeModification=modifiedEntry['changesModify']['netProceeds']-modifiedEntry['changesModify']['totRefiCost'] ;
    modifiedEntry['cashAsset']=cashAssetGrownPrior+cashAssetChangeModification ;

    modifiedEntry['cashAssetPreModification']= cashAssetGrownPrior ;
    modifiedEntry['cashAssetChangeModification']= cashAssetChangeModification ;


   modifiedEntry['totalsG']= calc_netValues(modifiedEntry ,entryWorking)  ; // fix netValues ,etc.

   modifiedEntry['totNetValue']=modifiedEntry['totalsG']['totNetValue']  ;     // actual

// and save it
   portfolioModifications[pname]['list'][dstamp]=modifiedEntry;

   p0Vals=modifiedEntry;  // the next mod uses this mod as the "baseEntry"

   }           // dstamp


 }  // pname



 return 1 ;    // portfolioModifications is global  p0Vals

}

//================    comment
// siminv encryptione
function simInvEncrypt(adata,encryptionKey) {

   if (encryptionKey=='') {
     let stuff={'data':adata,'keyMd5':''};    // key='' flags data is the original (ccould be array, object, wheateer
     return stuff;
   }
   let adata1=JSON.stringify(adata);             // stringify object
   let encObj=CryptoJS.AES.encrypt(adata1, encryptionKey);          // encrypt the stringified
   let  encString=encObj.toString();                                // extract the text that contains the encrypted/stringified object
   let amd5=md5('simInv_'+encryptionKey)
   stuff={'data':encString,'keyMd5':amd5};          // a non-'' key signals that data is stringifyied/encrypted

   return stuff;
}

//================
// simInv decrytprion
function simInvDecrypt(stuff,akey,amess) {
    if (arguments.length<3) amess=false;
   let aflag=stuff['keyMd5']  ;  // make sure key is correct
   if (aflag===0 || aflag==='')  {          // unenctyrped, so returne as is
      return stuff['data'] ;
   }
   let check1='simInv_'+encryptionKey ;         // check for validity of key before decyrptiong
   let check1Md5=md5(check1);
   if (check1Md5!==aflag) {   // user entred key doesn't match key  used to encrypt
      if (amess!==false) alert(amess+' : expected pwdMd5  ',check1Md5 + 'not match stored pwdMd5= '+aflag ) ;
         return false;
  }

  let decryptedBytes = CryptoJS.AES.decrypt(stuff['data'], akey);
  try {              // could be an error....
    plaintext = decryptedBytes.toString(CryptoJS.enc.Utf8);
    let data1=JSON.parse(plaintext);
    return data1 ;
  } catch(err) {    // should not happen, but who knows
    return false ;
  }

}

//=======  amess
// logoff
// iAuto=1 : do an auto logon. Otherwise, just show username in username field (user than clicks logon button)
// doAuto: if exists and not 0, do an auto logon  AND trigger button with this id (i.e.'portfoliosTableButton'
//          if doAuto==1, just auto logon
// userMe : optional -- user name to logon as (otherwise, use the current userName)

function doLogoff(iAuto,athis,userMe) {
  let doAuto='0';                     // no autologon (just fill in username )
  if (arguments.length>1 && iAuto==2) {
     let ethis=wsurvey.argJquery(athis);
     doAuto=ethis.attr('data-reload');
     doAuto=jQuery.trim(doAuto);
     if (doAuto==='') doAuto='1';  // the id of a button to trigger. '1' means "just logon, don't trigger a button"
  }
  if (arguments.length<3) userMe=userName;
  let oof;
  if (iAuto==2) {      // auto logon usin username, and trigger an action button (using its id)
    oof=window.location.protocol + "//" + window.location.host + window.location.pathname+'?username='+userMe+'&autoLogon='+doAuto ;
  } else {
    oof=window.location.protocol + "//" + window.location.host + window.location.pathname+'?username='+userMe ;
 }
  window.location.href = oof;
}

//=============
// replace all " , ' characters  with ' '
// nospaces: 1=remove all internal spaces (and breaks), 2=multiple spaces replace with 1 space, otherwise no space messing with
function fixString(astring,nospaces) {
   let bstring=jQuery.trim(astring);
   bstring=bstring.replace(/"|'|,/g," ");
   if (nospaces==1) bstring= bstring.replace(/\s+/g,"");
   if (nospaces==2) bstring= bstring.replace(/\s+/g," ");

   return jQuery.trim(bstring);
}

// remove | ! $ ~ #, " , ', make lower case
function fixStringRemoves(astring) {
   let bstring= astring.replace(/\s+/g,"");  // get rid of spaces
   bstring=bstring.replace(/"|'|`|#|\\|\/|\%|!|\+|\&|~|\*|\$|\||\<|\>/g,'');   // unallowed characters
   return bstring.toLowerCase();
}



//==============
// validate a date, and find some more info
// returns false (if bad date), or object with fields : year month day month3 dayOfWee value sayDate and sayDateMore
// 3 argument mode: year month day (year: 4 digits, month : 1-12, day 1-31)
//  one argument mode: a js datestamp. or true: use current date
// 2 argument: same as 1, but domonth should be seperator used to create sayDate and sayDateMore
function setEntryDate(doyear,domonth,doday,quiet) {
 let foo='';
  let dasep='-';
  let td1;
  let origarg='';
  if (arguments.length<4) quiet=0;

  let isDayCount=0,firstTry=0,useGmt=0,origDayCount=0;        // set if  doyear is a daycount (i.e.' 16436  for 2014 jan 1

  let nmillis=(60*60*24*1000);       // 86,400,000  millisecs per day
  if (arguments.length==1 && doyear!==true )    origarg=doyear+' . .  ';
  if (arguments.length==2)  origarg=doyear+', '+domonth + ' .   ';
  if (arguments.length==3)    origarg=doyear+', '+domonth + ', '+doday ;

  if (arguments.length<3)   {  // a datestamp
    if (arguments.length>1) dasep=jQuery.trim(domonth);
    let dd;
    if (doyear===true) {
       td1=-1;
        dd=new Date();
    } else {
      if (parseInt(doyear)<nmillis)   {
        origDayCount=parseInt(doyear);
        td1=origDayCount*nmillis   ;   ; // do year is "day count" -- in local time
        let dog=new Date();
        let agmt=dog.getTimezoneOffset();      // number of minutes to utc
        useGmt= agmt*60*1000 ;
        td1+=useGmt;
        isDayCount=1;                 // dayCount input
        firstTry=td1 ;                 // adjust this if bad match (see below)
        dd=new Date(td1);
      } else {
        td1=doyear;
        dd=new Date(parseInt(doyear));
      }
    }
    domonth=dd.getMonth()+1;
    doyear=dd.getFullYear();
    doday=dd.getDate();
    foo=dd.valueOf();
  }

// use all date fields... get their values
   doday=jQuery.trim(doday);
   if (doday==='') doday=1;
   if (!jQuery.isNumeric(doday) || doday<1) {
       if (quiet==1) return false ;
       alert('Invalid day: '+doday+' (using '+origarg+')')  ;
        if (debugMode==1)   a=errorHack-12;  // force an error
       return false ;
    }
    doday=parseInt(doday);

   domonth=jQuery.trim(domonth);
   if (domonth==='') domonth=1;
   if (!jQuery.isNumeric(domonth)) {   // check for month name
      let xdate=new Date('1 '+domonth+' 1999');
      let newmonth=xdate.getMonth();
      if (!jQuery.isNumeric(newmonth)) {
         if (quiet==1) return false ;
         alert('Invalid month: '+domonth+' (using '+origarg+')')  ;
         if (debugMode==1)   a=errorHack-12;  // force an error
         return false;
       }
      domonth=newmonth+1;       // convert jan=0 to jan=1
   }
   domonth=parseInt(domonth);
// https://stackoverflow.com/questions/13178069/getting-the-month-number-from-a-given-month-name


   doyear=jQuery.trim(doyear) ;
   if (doyear==='') doyear=2023;
   if (!jQuery.isNumeric(doyear) ) {
       if (quiet==1) return false ;
       alert('Invalid  year: '+doyear+' (using '+origarg+')')
       if (debugMode==1)   a=errorHack-12;  // force an error
       return false;
    }
   doyear=parseInt(doyear);

   if (doyear<theMinYear || doyear > theMaxYear) {        // global variables (index.php)
       let q=confirm('Are you sure the year ('+doyear+') is correct? ');
      if (!q) return false ;
  }

  let d1=wsurvey.validateDate(doyear,domonth,doday); // month from 1 to 12

   if (d1===false)  {
        if (quiet==1) return false ;
         alert('Improper date (please re-enter): Y:' +doyear +'/ M: '+domonth+'/ D:'+doday );
         return false;
  }


  let dsay3=d1['year']+dasep+d1['month3']+dasep+d1['day'] ;
  d1['sayDate']=dsay3;
  let dsay4=d1['dayOfWeek']+' '+dsay3 ;
  d1['sayDateMore']=dsay4;
  d1['dayCount']=parseInt(d1['value']/nmillis) ;
  d1['orig']=origarg ;

// isDayCount=0,firstTry=0,useGmt=0,origDayCount=0;
  if (isDayCount==1)  {    // daycount input -- make sure the returned daycount matches (utc issues can make this not ture
    for (let mfoo=0;mfoo<24;mfoo++)  {    // shouldn't need this many!
      let d2;
      if (d1['dayCount']<origDayCount) {  // add some time and try again
        let td2=firstTry+useGmt;
          d2=setEntryDate(td2);           // since full time string, will not get into recursioh hell
      } else if (d1['dayCount']>origDayCount) {
          let td2=firstTry+useGmt;
            d2=setEntryDate(td2);
      } else {
          break ; // equal!
      }
      if (d2['dayCount']==origDayCount)  {
           d1=d2;
           break;
      }       // success
    }   // mfoo
  }       // isdaycount check

  return d1 ;  // value month3  day year

}


//==========
// a front end to setEntryDate
// read and process the "creation date -- year month day" (on the asset mix menu)
 function getCreationDate(ifoo) {
   let etable=$('#portfolioHistory1');
   let e1=etable.find('[name="portfolioDateYear"]');
   let ayear=e1.val();
   e1=etable.find('[name="portfolioDateMonth"]');
   let amonth=e1.val();
   e1=etable.find('[name="portfolioDateDay"]');
   let aday=e1.val();

   let d1=setEntryDate(ayear,amonth,aday); // month from 1 to 12
   return d1;
 }

//==============
// view all help topics (in a new window)
function viewAllHelp(athis) {
   let ehelps=$('.helpBox')
   let stuffJumps=[];

   let amess='';
   let topJump='<a href="#allHelpTop">&#8682;</a> ';
   for (let ie=0;ie<ehelps.length;ie++) {
      let ehelp=$(ehelps[ie]);
      let astuff=ehelp.html();
      let adesc=ehelp.attr('data-desc');
      let ajump='allHelp_'+ie ;
      let tt=[ajump,adesc];
        stuffJumps.push(tt) ;

      let bstuff='<div ';
      bstuff+='    style="font-weight:600;background-color:#eaf3ef;padding:3px 5px 3px 5px;margin:8px 5px 5px 2px;border-top:3px groove black">';
      bstuff+='<a name="'+ajump+'">'+topJump+adesc+'</a>';
      bstuff+='</div>';
      bstuff+='<div style="margin:2px 1em 2px 2em;border-left:1px dotted blue;padding-left;5px"> '+astuff+'</div>';
      amess+=bstuff;
   }

   let jumps='<div style="backgrond-color:#e0f9fc;margin:3px 3em;padding:5px;min-height;2em;max-height:10%;overflow:auto">';
   jumps+='<ul class="linearMenu22Pct">';
   for (let ij=0;ij<stuffJumps.length;ij++) {
       let s1=stuffJumps[ij];
        let a1='<a href="#'+s1[0]+'">'+s1[1]+'</a> ';
        jumps+='<li style="overflow:auto">'+a1;
   }
   jumps+='</ul></div>';
   let bmess='<div style="background-color:cyan;padding:5px;margin:1em 3px"><a name="allHelpTop">simInv:</a> help and tips </div>';
   bmess+=jumps;
   bmess+=amess ;
   bmess+='<div style="border-top:2px dashed black;margin-top:1em;font-style:oblique;font-size:90">end of help and tips ...  </div>';

   displayHelpMessage(0,bmess,1);
}



//===============
// converrt xxK and xxM to xx000  or xx000000
function fixNumberValue(aval) {
      aval=jQuery.trim(aval).toLowerCase();
      aval= aval.replace(/,/g,'');
      let achar=aval.slice(-1).toLowerCase()  ;
      let bval=false;
      if (achar=='k') {
         bval=aval.substr(0,aval.length-1);
         if (!jQuery.isNumeric(bval)) return false ;
         bval=parseFloat(aval)*1000;
      } else if (achar=='m') {
         bval=aval.substr(0,aval.length-1);
         if (!jQuery.isNumeric(bval)) return false ;
         bval=parseFloat(bval)*1000000;
      }  else {
        if (!jQuery.isNumeric(aval)) return false;
        bval=parseFloat(aval);
      }
      return bval;
}

//============
// calcluate tax on earnings of an asset
// anasset: asset name
// forSale: 0 or 1 (dcefault is 0). 0 if this a "earnings" (nterest, etc) tax rate, 1 if a "sales" (cap gains or withdraw from tax deferred)

function calcAsset_taxRate(anAsset,forSale)  {
   if (arguments.length<2) forSale=0;
  let assetType=getAssetType(anAsset);
  if (assetType===false) return false ;
  let ataxRate=parseFloat(taxRate);
  let aCapGainsRate=parseFloat(capGainsRate);

  if (assetType==0) {
      if (forSale==0) return ataxRate;     // tax on dividends
      return aCapGainsRate ;             // tax on cap gains (sale  - basis)
  }
  if (assetType==1) {          // rgular bonds
      if (forSale==0){
         let taxFreeFrac=doAssetLookup(anAsset,'taxFreeFrac',1);
         return ((1-taxFreeFrac)*taxRate ) ;
      }
      return 0 ;          // no tax on cashing out regular bonds
  }

  if (assetType==2) {       // tax ceferred bonds
      if (forSale==0) return 0 ;         // no tax on interest earnings (at time of occurence0
      return ataxRate ;                        //   tax on  full value when cashing out tax-deffered  bonds
  }

  if (assetType==3)  {                   // property
      if (forSale==1) {
         let taxFreeFrac=doAssetLookup(anAsset,'taxFreeFrac',1);
         return ((1-taxFreeFrac)*aCapGainsRate ) ;
      }
      return ataxRate ;       // netRevenue
  }

  if (assetType==4)  {                   // income
      if (forSale==0){
         let taxFreeFrac=doAssetLookup(anAsset,'taxFreeFrac',1);
         return ((1-taxFreeFrac)*ataxRate ) ;
      }
      return 0 ;                        //   income streams can not be sold, so this should never happen
  }
}


//============
// calcluate tax on earnings (or sale) of an asset
function calcAsset_taxAmount(anAsset,aValue,forSale) {
  if (arguments.length<3) forSale=0;
  let daRate ;
  if (anAsset=='*capgains') {              // do NOT apply "tax free fraction" (that is done by calcAsset_capGainsAmount
      daRate=parseFloat(capGainsRate);
  } else if (anAsset=='*taxdeferred') {
      daRate=parseFloat(taxRate);
  } else {
     daRate=calcAsset_taxRate(anAsset,forSale);     // can apply  "tax free freaction"
  }
   let daVal=daRate*parseFloat(aValue);
   return daVal
}

//============
// calcluate the "Taxable capital gains" for  an asset -- using its sale price and it basis
// for bonds (Rgulear and tax deferred)-- this is always 0. Also 0 for income streams

function calcAsset_capGainsAmount(anAsset,aValue,abasis) {
  let assetType=getAssetType(anAsset);
  if (assetType===false) return false ;
  if (assetType==1 || assetType==2 || assetType==4) return 0 ;        // these are NOT subject to capital gains. Note that "2" is subject to regular tax
  let capGains0=parseFloat(aValue)-parseFloat(abasis);
  let att =doAssetLookup(anAsset,'taxFreeFrac',1);
  let taxFreeFrac=(att===false || att==='false') ? 0 :  parseFloat(att);
  let daAmount=(1-taxFreeFrac)* capGains0    ;
  return daAmount ;
}

//=================
// confirm a close of a box (used by displayResponseFromServer
// note use of athis -- it is used gby wsShow.hide
function closeConfirm(athis,iwait) {
   let ethis=wsurvey.argJquery(athis);
   let amess=ethis.attr('data-message');
   let q=confirm(amess);
   if (!q) return 0;         // don't hice box
  let aid1=ethis.attr('data-wsshow');

   wsurvey.wsShow.hide(aid1,iwait);
}


//==================
// create and save an encypriont ke
function saveEncryptionKey(ifoo) {
  let ep1=$('#iEncryptionKey');
  let key0=fixString(ep1.val(),1);

   let amess='<div style="border:2px solid black">Create and save an encryption key</div>';
   amess+='<div style="border:1px solid gray;margin:5px 3em"><b>Caution:</b> Once you specify an encryption key you ';
   amess+='<b>must</b> enter it every time you use simInv.</div>';
   amess+='<ul class="boxList">';
   amess+='<li>Your encryption key: <input type="text" value="'+key0+'" size="20" title="Spaces will be removed, and text converted to lowercase" id="iEncKeyValue">';
   amess+='<em> &hellip; your encryption key should be a single (case-insensitive) word -- the longer the better! </em>';
   amess+='<li>Optional: a <em>hint</em> to help you remember your encryption key: <input type="text" size="50" title="A hint to helpy you remeber" id="iEncKeyHint">';
   amess+='<li><input type="button" value="Save your encryption key" onClick="saveEncryptionKey2(this)" >';
   amess+='</ul>';
   amess+='<div style="border:1px solid gray;margin:5px 3em"><b>Caution:</b> The encryption key used as logon password, ';
   amess+=' and to encrypt your data. It is <b>not</b> saved by simInv - you <b>must</b> remember it (the hint can help)!<br>';
   amess+='And, since it encrypts your data-- it can <b>not</b> be changed! If you forget your encryption key, you will have to ';
   amess+='re-enter all your assets and portfolios (and the admin will have to reset your account)</div>';

   displayStatusMessage(amess);
   toggleStatusDiv(0,0) ;
}

function saveEncryptionKey2(ifoo) {
   let e1=$('#iEncKeyValue');
   let aenc=jQuery.trim(fixString(e1.val(),1).toLowerCase());
   if (aenc=='') {
       alert('You did not specify an encryption key.  You can exit, or you can specify one and resubmit!');
       return 0;
   }
   let e2=$('#iEncKeyHint');
   let ahint=wsurvey.removeAllTags(e2.val());
   let q=confirm('Are you sure you want to save this encryption key ('+aenc+')? If you do, you MUST use if in all future logons to simInv ');
   if (!q) return 0;

  let ddata={};

  let aencMd5=md5('simInv_'+aenc);
  ddata['todo']='saveEncKey';
  ddata['username']=userName;
  ddata['key']=aencMd5;
  ddata['hint']=ahint;
  ddata['encMd5']='';  // special case: there is no kay, and you are saving one -- so this will match (and allow you to save the newly specifie key

  getSimInvData(ddata,'saveEncKey');


 }


//============
// view and set inflation (CPI) info
function doSetInflation(athis) {

  let amess='';
    amess+='<div style="border-bottom:1px solid blue;margin:5px 5px 1em 5px;padding:3px 5px 5px 5px">';
    amess+=' <button title="Tips" onClick="displayHelpMessage(this)" data-div="#inflationSeriesHelp1">&#10068;</button>';
    amess+=' <b>Inflation series (by default, CPI-U)</b>. ';
    amess+='You can  <button>Replace</button> or  <input class="cdoButtonRegular" type="button" value="add" onClick="doSetInflation2(this)"> values ... ';
    amess+=' and then <input class="cdoButtonRegular" type="button" value="save the changes" onClick="doSetInflation3(this)" > ';
   amess+=' <span style="float:right;margin-right:2em"> <em> or ... </em>  ';
    amess+='<button class="cdoButtonRegular" onClick="doViewInflation1(this)"> View the working series</button> (with imputed values) ';
    amess+='</span>';
   amess+='</div>';

  displayStatusMessage('....');
  toggleStatusMessage(0,0);
  let mheight=$('#statusDiv').height();
  let mheight2=parseInt(0.84*mheight);

  amess+='<div id="iInflationTableDiv" style="border:5px solid blue;height:'+mheight2+'px;overflow:auto">';
  amess+='<table id="iInflationTable" rules="rows" cellpadding="6">';
  amess+='<tr id="iInflationTableHeader"><td>...</td><td>Date</th><th>CPI value</th></tr>';
  for (let iday in cpiuSeries) {
     amess+='<tr class="inflationRow"> ';
      let oof=setEntryDate(iday);
      let sayDate=oof['sayDate'];
      amess+='<td><input type="button" value="Replace" title="replace this date`s value" onClick="doSetInflation_replace(this)"></td>';
      amess+='<td><span name="theDate" data-value="'+iday+'"  title="dayCount: '+iday+'">'+sayDate+'</span></td>'
      amess+='<td><span name="theValue" data-value="'+cpiuSeries[iday]+'">'+cpiuSeries[iday].toFixed(1)+'</span></td>';
      amess+='<tr>';
  }
  amess+='</table>';
  amess+='</div>';
  displayStatusMessage(amess);
  toggleStatusMessage(0,0);
}

function doSetInflation2(athis) {
   let a1='<tr class="cpiRow">';
   a1+='<td>Date: <tt>Year Month</tt> <input name="newCpiDate" type="text" title="year, month. Example: `2024, 6` for June 2024" size="8"></td>';
   a1+='<td>Amount: <input name="newCpiAmount" type="text" title="CPI (1984=100)" size="8"></td>';
   a1+='</tr>';
   let etable=$('#iInflationTable');
   etable.append(a1);
   
   let ediv=$('#iInflationTableDiv');
   let ath=ediv.prop("scrollHeight");
 
   ediv.animate({ scrollTop: ath}, 700);
  return 1;
}

//=======
// save changes to cpiuSeries
function  doSetInflation3(athis) {
   let etable=$('#iInflationTable');
   let enews=etable.find('[name="newCpiDate"]');

   if (enews.length==0) {
      alert('You did not specify any new changes');
      return 0;
   }
   let changes=[];
   for (let inn=0;inn<enews.length;inn++) {
       let eb=$(enews[inn]);
       let bval=jQuery.trim(eb.val());
       if (bval=='') continue ;
       let goo=wsurvey.getWord(bval,0, /[\,\s]+/);
       if (goo.length<2) goo[1]=1;  // assume jan
       let oof=setEntryDate(goo[0],goo[1],1);
       if (oof===false) return 0;
       let dayCount=oof['dayCount'];
       let sayDate=oof['sayDate'];
       let etr=eb.closest('.cpiRow,.inflationRow') ;
       let eamount=etr.find('[name="newCpiAmount"]');
       let amount=jQuery.trim(eamount.val());
 

       if (amount=='') continue ;

       if (!jQuery.isNumeric(amount)) {
          alert('Non-numeric value for CPI ');
          continue;
       }
       let aa=[sayDate,dayCount,amount];
       changes.push(aa);
   }
   if (changes.length==0) {
      alert('No changes were made');
      return 0;
   }


   for (let ii=0;ii<changes.length;ii++) {
        let idate=changes[ii][1];
        let aval=changes[ii][2];
        cpiuSeries[idate]=parseFloat(aval);    // might overwrite existing
   }
   let a1=[];                 // make sure in asceding order and no dups
   for (let idate in cpiuSeries) a1.push(idate);
   let oof=sortNoDuplicates(a1);
   
   let cpiuTmp={};
   for (let ii=0;ii<oof.length;ii++) {
      let idate=oof[ii];
      cpiuTmp[idate]=cpiuSeries[idate];
   }
   
   cpiuSeries=cpiuTmp;
    let last1=oof[oof.length-1];
    let oofD=setEntryDate(last1);
   let vmess='You added (or changed) '+changes.length+'  entries, and there are now '+oof.length+' entries, in the CPI series (the last entry is on '+oofD.sayDate+')';
   vmess+='<p>You can <input type="button" value="Save them!" onClick="personalSettings(2)">';
   displayStatusMessage(vmess);


}

//==========
// replace a value
function  doSetInflation_replace(athis) {
    let ethis=wsurvey.argJquery(athis) ;
    let erow=ethis.closest('.inflationRow');
    let edate=erow.find('[name="theDate"]');
    let adate=edate.attr('data-value');
    let evalue=erow.find('[name="theValue"]');
    let avalue=evalue.attr('data-value');

    let oof=setEntryDate(adate);
    let ayear=oof.year,amonth=oof.month;
   a1=' <br> <input name="newCpiDate" value="'+ayear+' '+amonth+'" type="text" title="year, month " size="8"></td>';
   edate.after(a1);
   a2=' <br> <input name="newCpiAmount" type="text" title="CPI (1984=100)" value="'+avalue+'" size="8"></td>';
   evalue.after(a2);


    
}

//===================
// view the cpiuSeriesUse series
function doViewInflation1(athis) {

   let bmess='';
   bmess+='<input title="Return to setInflation menu" type="button" value="&lArr;" onClick="doSetInflation(this)">';
   bmess+=' hese inflation values are used by simInv -- they may include imputed values (for years after the last explicit inflation entry)';
   bmess+='<table rules="rows" cellpadding="5">';
   bmess+='<tr><th>Date</th><th>CPI (cumulative)</th><th>Yearly inflation rate</th><th>Imputed?</th>';
   for (let ii=0; ii<cpiuSeriesUse.length;ii++) {
       acc=cpiuSeriesUse[ii];
       let idate=acc[0];
       let sayDate=setEntryDate(idate).sayDate ;
       let acpi=acc[2].toFixed(1);
       infPct=(acc[4]-1)*100;
       let sayInf=infPct.toFixed(1);
       let isImputed=(acc[5]==0) ? 'Explicit' : 'Imputed ';
       bmess+='<tr><td>'+sayDate+'</td><td>'+acpi+'</td><td>'+sayInf+'</td><td>'+isImputed+'</td></tr>';
   }
   displayStatusMessage(bmess);

}


//======================
// return asset type info by asset name
//  aname: name of asset.
//          Or "0","*sto",  "1","*bon", "2","*tax" , "3","*pro", "4","*inc"
//          If not 0,1,2,3,4, the first 4 characters (case insensitive) are used  -- if the first is not a '*', then this must be the name
//          of an existing asset
// return depends on ahow
//   ahow:  'type' : a 0,1,2,3,4 depending on type of asset. This is the default (if ahow is not specified)
//   ahow : 'say' (or 1) :  a &xxx;aaa string of the type of this asset. Actually, anything but 'say' or '1' is interpeted as 'type'
//   ahow : 'saysimple'  :  a  aaa string of the type of this asset (eg; 'bond' or 'stock').
//    ahow: sayslong   : a longer string naming this asset (could be more than one word)
//   ahow : 'icon'  : a &xxx; string (icon of the asset type)
//   ahow : 'iconSpan'  : a &xxx; string (icon of the asset type), surrouned by <span title="asset type'> ...</span>
// returns false if an error (such as a non existing asset, or a *xxx with xxx not one of sto bon tax pro inc.

function getAssetType(aname,ahow) {

    if (arguments.length<2) ahow='type';
    ahow=jQuery.trim(ahow).toLowerCase();

    let asays=['&#127480;tock','&#127463;ond','&#127299;axDefer','&#127477;roperty','&#127470;ncome'];
    let aicons=['&#127480;','&#127463;','&#127299;','&#127477;','&#127470;'];
    let alooks={'sto':0,'bon':1,'tax':2,'pro':3,'inc':4 } ;
    let asaysSimple=['Stock','Bond','TaxDefer','Property','Income'];
    let asaysLong=['Stock','Bond (regular)','Bond (tax deferred)','Property','Income stream'];

    aname=jQuery.trim(aname);
    let iuse=false;
    let a1=aname.substr(0,1);

    if (a1=='*') {      // *xxx pnemonic for assetType ?
        let a2=a1.substr(1,3).toLowerCase();
        if (!alooks.hasOwnProperty(a2)) {
           alert('getAssetType error: unrecognized asset type: '+a1);
           return false  ;
        }
        iuse=alooks[a2];
    } else if (jQuery.isNumeric(a1)) {    // number for generic asset type
        iuse=parseInt(a1);
        if (iuse<0 || iuse>4) {
           alert('getAssetType error: assetType must be 0,1,2,3, or 4');
           return false ;
       }
    }
    if (iuse!==false) {  // a generic type
        if (ahow=='icon') return aicons[iuse];
        if (ahow=='iconspan') {
          let ticon=aicons[iuse];
          let t2='<span title="'+asaysLong[iuse]+'">'+ticon+'</span>';
          return t2;
        }
        if (ahow=='saysimple') return asaysSimple[iuse];
        if (ahow=='sayslong') return asaysLong[iuse];
        if (ahow=='say') return asays[iuse];
        return iuse ;
    }

// a named asset: get the asset family (regardless of scenario or incomeFixedVariant)
   let aname0=aname;
   let aname1=getAssetFamily(aname0,1);
     aname=aname1['family'];
   if (aname1['scenario']!='') aname+='.'+aname1['scenario'];

    if (!assetLookup.hasOwnProperty(aname)) return false;
    iuse=doAssetLookup(aname,'assetType','i');
    if (iuse===false) {
        alert('getAssetType error: unknown asset: '+aname0);
        return false ;
    }
    if (ahow=='icon') return aicons[iuse];
    if (ahow=='iconspan') {
 
          let ticon=aicons[iuse];
          let t2='<span title="'+asaysLong[iuse]+'">'+ticon+'</span>';
          return t2;
     }

    if (ahow=='saysimple') return asaysSimple[iuse];
    if (ahow=='sayslong') return asaysLong[iuse];
    if (ahow=='say') return asays[iuse];
    return iuse;

}

//====================
// return the "asset family" of an asest
//  family.sceanario.$incomeVariant   (family is required, incomeVariant always preceded by a $ and only appears if fixedIncomeStream asset
// if iall=1 return {'family':,'scenario','variant'}  scenario and variant often '';
//   otherwise just return family as a string

function getAssetFamily(anAsset,iall) {

   if (arguments.length<2) iall=0;

    let tt1=anAsset.split('.');
    if (tt1.length>3) {
       alert('getAssetFamilyError: improper assetName (too many .): '+anAsset);
       return false;
    }

    let afamily=jQuery.trim(tt1[0]);
    if (iall!=1)  return afamily;         // just the fmaily

// return family, scenario, & variant
    let vv={'family':afamily,'scenario':'','variant':''};

    if (tt1.length==1) return vv;

   if (tt1.length==2) {
      if (tt1[1].substr(0,1)=='$')  {       // no scenario, but a variant
         vv['variant']=tt1[1].substr(1);
         return vv;
      }
      vv['scenario']=tt1[1];
      return vv;
   }

// if 3,  variant is last
   vv['scenario']=tt1[1];
   vv['variant']=tt1[2].substr(1);
   return vv;

}


//============

//====================
// return indeex "closest entry" (in aliset) to aDate
//  Thus: 0 if aDate  aDate>=alist[0] and < alist[1]
// (after alist has been sorted)
// alist will be sorted and make numeric, as will aDate
//  If aDate before earlist entry alist, return -1 ;
// if non numeric dates, alert an error and return false
// 0: creation
//  1: modification 1, 2: mod 2 ...
// false: an error ( aDate < creationDat

function find_closestDate(alist0,aDate0) {

   if (!jQuery.isNumeric(aDate0)) {
      alert('Error in  find_closestDate: date is not numeric ('+aDate0+')');
      return false;
   }
   let aDate=parseFloat(aDate0);

   let  alist=[];
   for (let ii=0;ii<alist0.length;ii++) {
      let k1=alist0[ii];
      if (!jQuery.isNumeric(k1)) {
        alert('Error in  find_closestDate: list['+ii+'] is not numeric ('+k1+')');
        return false;
      }
      alist[ii]=parseFloat(k1);
   }
   alist.sort(find_closestDate_sort);  // make sure its ascending sort

   if (aDate<alist[0]) return -1  ;

    for (ifoo=alist.length-1;ifoo>=0;ifoo--) {     // go backwards
        let t1=alist[ifoo];
        if (aDate>=t1)   return ifoo;
    }             // ifoo=0 will always work (given aDate<alist[0]) test above
    return false;
}


function find_closestDate_sort(a1,b1) {     // assumes values are alreday numeric
   return a1 - b1;
}


//================
// retrieve assetLookup variable == by family
// avar=* return the object, otherwise return variable name in object
// toNumber=1 or f : parsefloat result. or 2 or  'i' for parseInt
function doAssetLookup(anAsset,aVar,toNumber0,quiet) {
  if (arguments.length<3) toNumber0=0;
  if (arguments.length<4) quiet=0;
  let tt0=getAssetFamily(anAsset,1);
  aname=tt0['family'];
  if (tt0['scenario']!='') aname=aname+'.'+tt0['scenario'];

  if (aVar=='*') {
     if (!assetLookup.hasOwnProperty(aname)) return false ;
     return   assetLookup[aname] ;
  }

  if (!assetLookup.hasOwnProperty(aname)) {
     if (quiet!=1) alert('doAssetLookup: no such assetname= '+anAsset+' ... family= '+aname);
     let zz=zz3/3;  // force error
     return false;
  }

 let aval= assetLookup[aname][aVar] ;
 if (!jQuery.isNumeric(aval)) return aval;   // not numeric, dont try parsefloat or parseint
 let toNumber=jQuery.trim(toNumber0).toLowerCase() ;
 if (toNumber=='1' || toNumber=='f') aval=parseFloat(aval);
 if (toNumber=='2' || toNumber=='i') aval=parseInt(aval);
 return aval;
}


// probably not useful enouh
// https://developer.mozilla.org/en-US/docs/Web/HTTP/Browser_detection_using_the_user_agent
 function operatingSytem() {
       let OSName = "Unknown OS";
       if (navigator.appVersion.indexOf("Win") != -1) OSName = "Windows";
       if (navigator.appVersion.indexOf("Mac") != -1) OSName = "MacOS";
       if (navigator.appVersion.indexOf("X11") != -1) OSName = "UNIX";
       if (navigator.appVersion.indexOf("Linux") != -1) OSName = "Linux";
   return   OSName ;
 }