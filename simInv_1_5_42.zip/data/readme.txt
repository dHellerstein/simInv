5 August 2023

This directory contains username specific subdirectories.
Each subdirectroy contains data files specifiying investment simulations for a single user.

To give access to a new user, create a  subdirectory with the username.

For example: if the new user logon with 'joeb', then create a joeb directory.

You don't need to do anything else (the directory should be empty when you create it). 
When a user first logins, simInv will initialize his directory.

Note that simInv is distributed with a "test"  subdirectory -- to support the "test" username.
You can use this for testing!

Hint: 

 * publicAssets/ (under the main simInv directory) contains asset information for  publically available assets.
    See its readme.txt for information on how to add public assets.



