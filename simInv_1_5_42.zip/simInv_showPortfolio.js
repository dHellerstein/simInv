// === show all values: inflation adjusted?

function showAllPortfolioValuesStart(useInfAdjust,aportfolio) {
   if (arguments.length<2 || aportfolio===false) aportfolio=false;
   displayStatusMessage('Please wait while simInv calculates your portfolios ... ');
   toggleStatusMessage(0,1);
   window.setTimeout(function() {
       showAllPortfolioValues(useInfAdjust,aportfolio);
       displayStatusMessage(' ... done! ',1);
       displayStatusMessage(false,0,400);
       fillTheWindow('mainDiv','portfolioValuesTableDiv')  ; // helpful if esc was used previously

   },100);
   return 1;
   }

function showAllPortfolioValues_infAdj(ii,aportfolio) {
   if (arguments.length<2 || aportfolio===false) aportfolio=false;

  let e1=$('#showInflationAdjustedCheck');
  doAdjust= (e1.prop('checked')) ? 0 : 1 ;  // toggle
  
   displayStatusMessage('Please wait while simInv re-calculates your portfolios ... ');
   toggleStatusMessage(0,1);
   window.setTimeout(function() {
       showAllPortfolioValues(doAdjust,aportfolio);
   },20);

}

//==================
// this does the work!
// show all the portfolio values in a table
// isAdj=1 to "inflation adjust", 0 to not
function showAllPortfolioValues(useInfAdjust,aportfolio) {
   let bmess='';

   if (arguments.length<2 || aportfolio===false) aportfolio=false;

   oof1=setEntryDate(true);
   let nowDayCount=oof1['dayCount'];

  let firstColWidth=160;   // in px
  let minCellWidth=225 ;

  let doViewDates=showAllPortfolioValues_makeViewDates(1);
  doViewDatesUse=doViewDates  ;           // global used by showAllPortfolioValues_viewAssetsOverTime

  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.show('#mainDiv2','show');    // this is where the table is shown

  let emainDiv2=$('#mainDiv2');
  let mainDiv2Width=emainDiv2.width();
  bmess+='<div style="background-color:#dced1a;padding:3px">';
  bmess+='<input type="button" value="x" onClick="wsurvey.wsShow.hide(this,200)" data-wsshow="#mainDiv2" > ';
  bmess+='<input type="button" value="&neArr;" title="View in a new window"  data-id="mainDiv" onClick="displayInWindow(this)"> ';
  bmess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#portfolioValuesHelp1">&#10068;</button>';

  bmess+='<b>Portfolio values </b>';

  if (useInfAdjust==0) {
     bmess+='<span style="background-color:#eaf8fb;margin-left:2em;padding:1px 5px">  ';
  } else {
     bmess+='<span style="background-color:#eaf8fb;margin-left:2em;padding:1px 5px"> <em>inflation adjusted</em>: ';
  }

  bmess+=' <b>netValue</b>';
  bmess+='   <span title="#assets / #incomes " style="margin-right:1em;border:1px dotted gray;font-size:90%">#assets / # incomeStreams.</span>';
  bmess+='<span style="color:#1e5b06;margin-right:1em;" title="Yearly cash flow= (income +  Rent) - loanPayments"><tt>cashFlowYearly </tt></span>';

  bmess+=' &Verbar;     &#9872;  view a few  details';
  bmess+=' &Verbar;    &#128270; &hellip; more  ';
  bmess+=' &Verbar;  &#128366;  &hellip; even more   ';
  bmess+='</span>';

  bmess+='<span style="float:right;margin-right:1.0em">';

  bmess+='<span>';
  bmess+='  <button class="cdoButtonRegular" display" title="Choose which portfolios to display" onClick="showAllPortfolioValues_pick(this)">&#9935;</button>';
  bmess+=' </span>';

  let sayReal= (useInfAdjust==1) ? ' checked ' : '  ' ;
  bmess+='<span style="margin:2px 5px;border:1px solid gray" > <input readonly '+sayReal+' type="checkbox" value="1"  id="showInflationAdjustedCheck"> ';
    bmess+='<button class="cdoButtonRegular" id="infAdjustCheckbox"    title="Display using real (inflation adjusted" values" onClick="showAllPortfolioValues_infAdj(1)">&real;eal values</button>';
  bmess+='</span>';

  bmess+='</span>';  <!-- float right --> 

  bmess+='</div>';

  bmess+='<div style="margin:3px 23px 2em 3px;border:1px dotted blue;padding:2px;width:92vw;overflow:auto;max-height:79vh" id="portfolioValuesTableDiv">';

// header row has portfolio names (and "show details" button)
// first column has viewDates (and "show details" button)

// # active porfolios ..
  let nPortfoliosActive=0;

  doPorts=[];
  for (ith=0;ith<portfolioList.length;ith++) {
     let iexists=portfolioList[ith]['exists'];
     if (iexists==0) continue ; // not initialized
     nPortfoliosActive++ ;
     let pname=portfolioList[ith]['name'];
     doPorts.push(pname);
  }

// hard code widths. 26 June ... maybe switch to floated <divs> to allow for resizing?

//  let nTests=18;

  let mainDiv2WidthUse= mainDiv2Width-(1.7*firstColWidth);
  let tryCellWidth=parseInt(mainDiv2WidthUse/nPortfoliosActive);
  let useCellWidth=Math.max(tryCellWidth,minCellWidth);
   let tableWidth=parseInt((nPortfoliosActive*useCellWidth)+firstColWidth+30);     // add 10 just because

  bmess+='<table border="1" id="portfolioValuesTable" width="'+tableWidth+'" class="cportfolioValuesTable">';


  bmess+='<colgroup>';
  bmess+='<col style="color:blue" title="Date">';
  for (let ijj=0;ijj<doPorts.length;ijj++) {
    let ij2=ijj+1;
    bmess+='<col data-nth="'+ij2+'" data-origwidth="'+useCellWidth+'" title="Portfolio: '+doPorts[ijj]+'" style="color:green;font-size:200%;visibility:visible">';
  }
  bmess+='</colgroup>';

// top row: portfolio names

  bmess+='<tr >';

  bmess+='<th   bgcolor="#fdf6c3"  width="'+firstColWidth+'"><div  style="overflow:auto">';
  bmess+='<button  title="Expand to fill window"  data-id="mainDiv" data-id2="portfolioValuesTableDiv" data-full="0" onClick="fillTheWindow(this)"  ';
  bmess+=' style="color:blue;padding:3px;font-weight:600;margin:1px 3px 1px 3px"> ';
  bmess+='&#128468;</button>';

    bmess+='<input type="button" value="&#8998;" title="toggle view of empty rows" onClick="showAllPortfolioValues_toggleEmpty(this)" data-on="0" >';
  bmess+='<input type="button" value="Export!" title="export results to json file" onClick="doExportImport_viewResults(this)" >';
  bmess+='&nbsp;&nbsp;  <span title="You can add ,or remove, dates using `viewDates`">date</span></div></th>';

 // doPorts=[];
  for (ith=0;ith<portfolioList.length;ith++) {
     let iexists=portfolioList[ith]['exists'];
     if (iexists==0) continue ; // not initialized
     let pname=portfolioList[ith]['name'];

     let adesc=portfolioList[ith]['desc'];
     let pstuff=portfolioLookup['list'][pname];
     let nhistory=pstuff['nHistory'];
     let nAnyDateAsset=pstuff['nAnyDateAsset'];
     let seeD1='';
 
     seeD1+='<input value="&#128366; ('+nAnyDateAsset+')" type="button" title="View all '+nAnyDateAsset+' assets in this portfolio, for all dates "  ';
     seeD1+= '   onClick="showAllPortfolioValues_viewAssetsOverTime(this)" data-name="'+pname+'"  class="viewAssetsOverTimeButtons" >';
     seeD1+='<input value="&#128301;" type="button" title="View this portfolio`s entries ('+nhistory+' entries)" onClick="showAllPortfolioValues_viewEntry(this)" data-ith="0" data-name="'+pname+'" >';

     seeD1+='<input type="button" value="&#128270;"  data-on="0" data-entry="'+pname+'" title="view details: for this portfolio" onClick="showAllPortfolioValues_DetailsPortfolio(this)" >';
     let desc2=' <span style="padding:2px 6px;max-width:10em;overflow:none;font-size:80%">'+adesc+'</span>';

     bmess+='<th width="'+useCellWidth+'"  data-origwidth="'+useCellWidth+'"><div  style="width:12em">'+seeD1+'<span title="'+adesc+'"> '+pname ;
     bmess+=desc2 ;
     bmess+='</div></th>';
  }

  bmess+='</tr>';   // end of portfolio name/desc header row

// row 2 ---   some creation info  on the porfolios

  bmess+='<tr style="white-space:nowrap">';
  bmess+='<td   bgcolor="#f0ecd1"  width="30"><div style="overflow:auto">';
    bmess+='<input type="button" value="&forall; &#128270;"   data-show="0" data-entry="*" title="view details: for ALL dates"  ';
    bmess+='     onClick="showAllPortfolioValues_DetailsDate(this)" >';

    bmess+='<input type="button" value="&forall;&#9872;"   data-show="0"  title="view extra details: for ALL dates"  ';
    bmess+='     onClick="showAllPortfolioValues_allExtraDetails(this)" >';

    bmess+='<span style="overflow:auto;margin-right:1em"><em>created or modified:</em></span>';
  bmess+='</div></td>';

  for (let ip=0;ip<doPorts.length;ip++) {
      let pname=doPorts[ip];
      let alook=portfolioLookup['list'][pname];
      let creationDateSay=alook['creationDateSay'];
      let origBudget=alook['budget'];;
      if (origBudget<200000) {
           origBudget=wsurvey.addComma(parseInt(alook['budget']));
      } else {
        origBudget= wsurvey.makeNumberK(parseInt(alook['budget']),100000,0) ;
      }
      bmess+='<td>  <div style="overflow:auto;scrollbar-width: thin;"  ><tt>'+creationDateSay+' / $'+origBudget+'</tt></div></td>';
  }
  bmess+='</tr>';

  let id0=1;
  let rowClass=['cportfolioValuesTableEven','cportfolioValuesTableOdd'];

// 2 rows for each viewDate : row 1 is the basics, row 2 is the "details"   .... each has same background color (that's why rowClass is used, rather than a simple css

  let dataStore={};

  for (let jthDate=0;jthDate<doViewDates.length;jthDate++) {
    let aviewDate=doViewDates[jthDate];
    let got1=0;
    dataStore[aviewDate]={};
    id0=1-id0;
    let useClass=rowClass[id0];

    let oofX2=setEntryDate(aviewDate);
    let sayDate=oofX2['sayDate'];
    bbasic='<td title="for day# '+aviewDate+'"> '

    let seeD1='<input type="button" value="&#128270;"  data-show="0"  data-entry="'+aviewDate+'" title="view details: for this date" onClick="showAllPortfolioValues_DetailsDate(this)" >';
    bbasic+=seeD1;
    bbasic+=sayDate;
    bbasic+='</td>';                 // first col of row 1 (basics) for this er date

    if (useInfAdjust==1) {
      bDetails='<td width="20" ><em>details  <br>(netValues, &hellip;)<br><u>Not</u> inflation adjusted</em></td> ';     // details row (2 of 2) per date
    } else {
      bDetails='<td width="20" ><em>details  <br>(netValues, &hellip;)</em></td> ';     // details row (2 of 2) per date
    }

  let dplen=doPorts.length;

  for (let ip=0;ip<dplen;ip++) {       // list of active portfolios
      let pname=doPorts[ip];
      dataStore[aviewDate][pname]={};
      dataStore[aviewDate][pname]['dateSay']= sayDate ;

      let plook1=portfolioLookup['list'][pname];
      let cdate=plook1['creationDate'];
      let modDates=plook1['modDates'];
      let modDatesSay=plook1['modDatesSay'];
      let ithUse=find_closestDate(modDates,aviewDate);            // what existing entry (creation or modification) is "just before" (or at) this viewdate
      if (ithUse<0)    { // this date is before creation of thiis portoflioa
         bbasic+='<td><span title="Before this portfolio`s initialization"> &vellip; </span> </td>';
         bDetails+='<td>&vellip;    </td>';
         continue;
      }

      got1++ ;
      let closestStamp=modDates[ithUse];
      let closestStampSay=modDatesSay[closestStamp];
      dataStore[aviewDate][pname]['closestStamp']=closestStamp;

// THIS DOES THE WORK
      let  useEntry=makeViewPortfolio(pname,aviewDate,ithUse,closestStamp,useInfAdjust,nowDayCount);       // "grow" the "ithUse" entry  (which as closestStamp as its dateStamp)  -- or use exact match as is

      let modDaysUse= useEntry['modDaysUse']  ;
      let tdclass='', tdtitle='',growDays=0; ;
      if (modDaysUse!==false )  {
         tdclass=' class="cEntryClass" ' ;
         if (modDaysUse==0) {
             tdclass=' class="cEntryClass0" ' ;
              tdtitle=' title="This is the initialization (creation) entry" ';
          }  else {
             tdclass=' class="cEntryClass" ' ;
              tdtitle=' title="This is the modification # '+ithUse+' entry"';
          }
      }  else {
         growDays=useEntry['changesGrow']['growDays'] ;
      }

      dataStore[aviewDate][pname]['growDays']=growDays;

      let aNetValue=parseFloat(useEntry['totalsG']['totNetValue']);
      let nAssets=parseFloat(useEntry['totals']['nAsset']);
      let nIncomes=parseFloat(useEntry['totals']['nIncome']);
      let netRevenueYear=parseFloat(useEntry['totals']['totYearlyRevenue']);
      let loanPayYear=parseFloat(useEntry['totals']['totLoanPayYear']);
      let netCashFlow=netRevenueYear-loanPayYear;

      dataStore[aviewDate][pname]['netValue']=aNetValue;
      dataStore[aviewDate][pname]['nAssets']=nAssets;
      dataStore[aviewDate][pname]['nIncomes']=nIncomes;
      dataStore[aviewDate][pname]['netRevenueYear']=netRevenueYear;
      dataStore[aviewDate][pname]['loanPayYear']=loanPayYear;
      dataStore[aviewDate][pname]['netCashFlow']=netCashFlow;

      let sayTotalNet,amult=1.0;;
       if (useInfAdjust==1) amult=calcInflation(aviewDate,nowDayCount) ; // deflate to current date

       if (useInfAdjust==1)   {
          aNetValue=amult*aNetValue;
          sayTotalNet='<span style="font-style:oblique" title="Inflation adjusted using '+amult+'">'+wsurvey.makeNumberK(aNetValue,100000,0)+'</span>'; ;
       } else {
          sayTotalNet=wsurvey.makeNumberK(aNetValue,100000,0) ;
       }
      bbasic+='<td class="viewPortfolioCell_td" title="Days since creation_or_modification entry: '+growDays+'">';

      bbasic+='<div  '+tdclass+' '+tdtitle+'> ';

//      alert([pname,aNetValue,nowDayCount,aviewDate]);
        bbasic+='<span title="netValue (after taxes, after loan payouts"><b>'+sayTotalNet+'</b></span> ';
        bbasic+='<span title="#assets / #incomes " style="border:1px dotted gray;font-size:90%">'+nAssets+' / '+nIncomes+'</span> ';


       let netCashFlowSay ; // =wsurvey.makeNumberK(netCashFlow,30000,0);
       if (useInfAdjust==1)  {
          netCashFlow=amult*netCashFlow;
          netCashFlowSay='<span style="font-style:oblique" >'+wsurvey.makeNumberK(netCashFlow,100000,0)+'</span>'; ;
       } else {
         netCashFlowSay=wsurvey.makeNumberK(netCashFlow,100000,0) ;
       }

      if (netCashFlow<0) {
         bbasic+='<span style="color:#b10a28;" title="cash flow is negative! (income + Rent) - loanPayments"><tt>'+netCashFlowSay+'</span>';
      } else {
         bbasic+='<span style="color:#1e5b06;" title=" (income + Rent) - loanPayments"><tt>'+netCashFlowSay+'</span>';
      }
      let cashAsset=parseFloat(useEntry['totalsG']['cashAsset']);
      let cFrac=cashAsset/aNetValue;

      dataStore[aviewDate][pname]['cashAsset']=cashAsset;
      dataStore[aviewDate][pname]['cFrac']=cFrac;


      let aflag=' <span title="The `Cash` balance is equal, or close, to 0.00">&#8773;</span> ';
      let cashAssetSay=wsurvey.addComma(parseInt(cashAsset));
      if (cFrac>budgetRemainPct) {
          if (cFrac<0.1) {
             aflag=' <span title="You have a positive amount in `Cash`: '+cashAssetSay+'" style="color:green">&#9872;</span> ';
          } else {
             aflag=' <span title="You have a large positive amount in `Cash`: '+cashAssetSay+'" style="background-color:lime;color:darkgreen">&#9872;</span> ';
          }
      } else if (cFrac<-budgetRemainPct) {
          if (cFrac<-0.1) {
            aflag=' <span title="You have a large negative  amount in `Cash`: '+cashAssetSay+'" style="background-color:yellow;color:red">&#9872;</span> ';
        } else {
           aflag=' <span title="You have a negative  amount in `Cash`: '+cashAssetSay+'" style="color:red">&#9872;</span> ';
        }
      }
      bbasic+=' <button title="click for a short summary" onClick="showAllPortfolioValues_summary(this)">'+aflag+'</button>' ;

      bbasic+='<div name="viewPortfolioCell_summary" style="display:none">'+useEntry['summary']+'</div> ';

      bbasic+='</div></td>';

      let dfoo=showAllPortfolioValues_moreDetails(useEntry,pname,closestStamp,closestStampSay); // By ASSET !!!

      dd1=dfoo[0];
      for (let aa1 in dfoo[1]) dataStore[aviewDate][pname][aa1]=dfoo[1][aa1]

      let dd2='<div name="portfolioDetailsCell_'+pname+'" class="cportfolioDetailsCell" >'+dd1+'<div>';

//             alert("add to bdetails "+ip+' : ' +pname+'/'+aviewDate+'\n'+dd2);
      bDetails+='<td class="viewPortfolioDetailsCell" >'+dd2+'</td>'  ;

    } // do ports

    let empty1= (got1==0) ? ' emptyViewRow  ' : '  ' ;
    bmess+='<tr class="viewPortfolioRow '+useClass+' '+empty1+'"  data-row="'+jthDate+'" class="'+useClass+'">'+bbasic+'</tr>';  // row 1
    bmess+='<tr class="viewPortfolioRow2 '+useClass+' '+empty1+' "   data-row="'+jthDate+'" data-row2="'+jthDate+'" class="'+useClass+' cportfolioValuesTableDetails" ';
    bmess+='  style="display:none">'+bDetails+'</tr>' ;  // 2nd row

    if (got1===0) delete  dataStore[aviewDate] ; // don't store empty rows
  }    // tr jthDate

  bmess+='</table>';
  bmess+='</div>';

   $('#mainDiv2').html(bmess);

   showAllPortfolioValues_toggleEmpty(0) ;  // hide "empty rows"

  viewDates_dataStore=dataStore   ;  // store in global

// show details (assets by viewDate) for a portfolio
  if (aportfolio!==false) {
     let ex1=$('#portfolioValuesTableDiv');
     let ebutton0=ex1.find('.viewAssetsOverTimeButtons');
      let ebutton1=ebutton0.filter('[data-name="'+aportfolio+'"]');
     if (ebutton1.length==1) ebutton1.trigger('click');
   }

  wsurvey.wsShow.hide('#mainDiv3',222)   ;

}

//================
// create, or read from local storage,  
// uses firstYearUse,addEntryDates and viewDates globals
function showAllPortfolioValues_makeViewDates(ifoo) {
//   let doViewDatesTry=simInv_localVar('doViewDates');
//  if (typeof(doViewDatesTry)!='undefined') {
//
//    return  doViewDatesTry ;
//  }


// not stored locally, create it...
   let doViewDates0=[] ;

   let oofX=setEntryDate(firstYearUse,1,1);
   doViewDates0[0]=oofX['dayCount'];               // the "first date in the range"

   for (let im=0;im<viewDates['list'].length;im++) doViewDates0.push(parseInt(viewDates['list'][im]));    // user specified display dates (stored on server)

// auto add entry dtes?
  if (addEntryDates>0)     {          // 0- do not
    for (let app in portfolioLookup['list']) {
       let mdList=portfolioLookup['list'][app]['modDates'];
       if (mdList.length>0) {
         let nadd= (addEntryDates==1) ? 1 : mdList.length;
         for (let ii=0;ii<nadd;ii++) {
            doViewDates0.push(parseInt(mdList[ii]));
         }         // this list (for this portfolil)
       }
    }
   }              // addEntryDates

   if (addEntryDates_yearly>0)     {          // 0- do not
     for (let kyear=firstYearUse;kyear<=lastYearUse;kyear++) {
        if (addEntryDates_yearly>0)   {    // jan 1
           let oof3=setEntryDate(kyear,1,1);
           doViewDates0.push(oof3['dayCount']) ;
        }
        if (addEntryDates_yearly>1)   {    //  & july 1
           let oof3=setEntryDate(kyear,7,1);
           doViewDates0.push(oof3['dayCount']) ;
        }
        if (addEntryDates_yearly>2)   {    //  & april 1 and oct 1
           let oof3=setEntryDate(kyear,4,1);
           doViewDates0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,10,1);
           doViewDates0.push(oof3['dayCount']) ;
        }
        if (addEntryDates_yearly>=10)   {    //  & feb1, mar 1,  & may 1 and sep 1, nov 15
           let oof3=setEntryDate(kyear,2,1);
           doViewDates0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,3,1);
           doViewDates0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,5,1);
           doViewDates0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,6,1);
           doViewDates0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,8,1);
           doViewDates0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,9,1);
           doViewDates0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,11,1);
           doViewDates0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,12,1);
           doViewDates0.push(oof3['dayCount']) ;
        }
        if (addEntryDates_yearly>=50)   {    //  & feb1, mar 1,  & may 1 and sep 1, nov 15
          let oof3;
          for (let kmonth=1; kmonth<=12; kmonth++ ) {
             oof3=setEntryDate(kyear,kmonth,7);
             doViewDates0.push(oof3['dayCount']) ;
             oof3=setEntryDate(kyear,kmonth,14);
             doViewDates0.push(oof3['dayCount']) ;
             oof3=setEntryDate(kyear,kmonth,21);
             doViewDates0.push(oof3['dayCount']) ;
          }     // kmonth
        }    // addEntryDates_yearly
     }            // kyear
   }  //    addEntryDates_yearly

   let oof2=setEntryDate(lastYearUse,12,31);      // end of "end of range" year
   doViewDates0.push(oof2['dayCount'])   ;      // the "last date in the range"

   doViewDates0.sort(mySortNumeric);         // sort

   let doViewDates=[];
// remove duplicates (after sort)
  let wasDate=false;
  for (let mm=0;mm<doViewDates0.length;mm++) {
      if (doViewDates0[mm]!==wasDate) {
         wasDate=doViewDates0[mm];
         doViewDates.push(wasDate );
      }
  }

//  wsurvey.dumpObj(doViewDates,1,'saving to local storage');
//  simInv_localVar('doViewDates',doViewDates);  // copy to localStorage (if enabled)
//  let oof=simInv_localLastUpdate(0,1);

  return doViewDates ;
}


//============         portfolioList
// display a short summary in a cell of "row 1";
function showAllPortfolioValues_summary(athis) {
   let ethis=wsurvey.argJquery(athis);
    let etd=ethis.closest('.viewPortfolioCell_td');
   let esumm=etd.find('[name="viewPortfolioCell_summary"]');
   esumm.toggle();

    return 1 ;
}

//==============
// pick which columns (portfolios) to display
function showAllPortfolioValues_pick(athis,) {
  doPorts=[];
  let bmess='';

    bmess+='<input type="button" value="&#8704;" title="Select all portfolios" onClick="showAllPortfolioValues_pick2(0,1)" >  ';
    bmess+='<input type="button" value="&#10672;" title="De-Select all portfolios" onClick="showAllPortfolioValues_pick2(0,0)" >   ';

    bmess+='<em>Select portfolio (columns),</em> and ';
  bmess+=' then <input type="button" value="display them" onClick="showAllPortfolioValues_pick2(this)"> ';
  bmess+='<ul id="ishowAllPortfolios_pick" class="linearMenu16Pct">';
  for (ith=0;ith<portfolioList.length;ith++) {
     let iexists=portfolioList[ith]['exists'];
     if (iexists==0) continue ; // not initialized
     let pname=portfolioList[ith]['name'];
     let adesc=portfolioList[ith]['desc'];
     let pstuff=portfolioLookup['list'][pname];
     bmess+='<li><label title="Display this portfolio" ><input type="checkbox"  checked name="chooseThis" data-name="'+pname+'" >'+pname+'</label>';
     bmess+='<span title="Description..." class="cdescNoteBuildPortfolio">'+adesc+'</span>';
  }
  bmess+='</ul>';
  displayStatusMessage(bmess);
}

//==========
// display chosen columns
function showAllPortfolioValues_pick2(athis,ido) {
  if (arguments.length<2) ido=false ;
   let showThese={};

   let e1=$('#ishowAllPortfolios_pick');
   let e2=e1.find('[name="chooseThis" ]');
   let nshow=0;
   for (let ie=0;ie<e2.length;ie++) {
       let ae=$(e2[ie]);
       if (ido===false) {  // find the checked
         if (ae.prop('checked')) {
           let aname=ae.attr('data-name');
           showThese[ie+1]=1 ;       // col # (skip header col)
           nshow++;
         }
       } else {  // select or deselect all checkboxes
          if (ido==1) {
             ae.prop('checked',true);
          } else {
            ae.prop('checked',false);
          }
       }
   }
   if (ido!==false) return 0;

   let ediv=$('#portfolioValuesTableDiv');
   let etable=$('#portfolioValuesTable');
   let ecs=etable.find('colgroup');         // view or collapse a <col>
   let ecs2=ecs.find('col');
   let awidth0=ediv.width();

   let awidth1=awidth0-250; // a bit of a buffer (includes widht of date column)
   let tryWidth=parseInt(awidth1/nshow);

   for (let ie1=1;ie1<ecs2.length;ie1++) {
      let acol=$(ecs2[ie1]);
      let nth=acol.attr('data-nth');
      if (showThese.hasOwnProperty(nth)) {
             acol.css({'visibility':'visible'});
             let nowWidth=parseInt(acol.attr('data-origwidth'));
             let useWidth=Math.max(nowWidth,tryWidth);
             acol.attr('width',useWidth+'px');
             nshow++;
      } else {
             acol.css({'visibility':'collapse  '});
      }
    }


}

//===========================
// view table of all assets in a portfolio, for all the viewdates.
function showAllPortfolioValues_viewAssetsOverTime(athis,doInfAdjust,aportfolio) {

   if (arguments.length<2) doInfAdjust=0;

   if (arguments.length<3) {
     let ethis=wsurvey.argJquery(athis);
     aportfolio=ethis.attr('data-name');
   }

   oof1=setEntryDate(true);
   let nowDayCount=oof1['dayCount'];
   let nowDayCountSay=oof1['sayDate'];


   let id0=1;
   let rowClass=['cportfolioValuesTableEven','cportfolioValuesTableOdd'];
   let bmess='<div style="font-size:110%;background-color:lime;">Trend in asset values, for portfolio <b> '+aportfolio+'</b>';
   bmess+='&nbsp;&nbsp;<input type="button" value="Export" title="Export expanded version of this " data-name="'+aportfolio+'" onClick="showAllPortfolioValues_exportAssetOverTime(this)" >&nbsp;'
   if (doInfAdjust==0) {
     bmess+='<br><em>The inflation multipler is provided for informational purposes -- it is <u>not</u> applied to these value</em>';
   } else {
     bmess+='<br><em>Displaying inflation adjusted values (using the inflation multipler)</em>';
   }
   bmess+='<span style="border:1px solid cyan;float:right;margin-right:2em">';
   if (doInfAdjust==0) {
      bmess+='<label><input name="viewAssetsUsingInf" data-name="'+aportfolio+'" type="checkbox" onClick="showAllPortfolioValues_viewAssetsOverTime_real(this)">&real; values?</label>';
   } else {
      bmess+='<label><input name="viewAssetsUsingInf"  data-name="'+aportfolio+'" checked type="checkbox" onClick="showAllPortfolioValues_viewAssetsOverTime_real(this)">&real; values?</label>';
   }
   bmess+='</span>';

   bmess+='</div>';
   bmess+='<table cellpadding="3" border="1">';

   let creationDate=portfolioLookup['list'][aportfolio]['creationDate'];
   let allAssets=portfolioLookup['list'][aportfolio]['anyDateAsset'];

   bmess+='<tr><th>Date</th><td><em>total netValue</em></td><td><em>inflationMultiplier</em></td>';
   bmess+='<td> <u>Cash</u> </td> ';
   for (let a1 in allAssets) {
      let aicon=getAssetType(a1,'icon');
       bmess+='<th>'+aicon+'&nbsp;'+a1+'</th>';
   }
   bmess+='</tr>';

   bmess+='<tr><td>...</td><td><tt>includes <u>Cash</u></td><td><tt>'+nowDayCountSay+'=1.0</tt></td>';
   bmess+='<td>...</td>';

   for (let a1 in allAssets) {
     let atype=getAssetType(a1);
     if (atype==0) {
       bmess+='<td><em>netValue</em></td>';
     } else if (atype==1) {
       bmess+='<td><em>netValue </em>';
       bmess+='<span title="cumulative additions (ignoring asset value)"  class="cviewAssetsOverTime_addition">cumAdd</span>';
       bmess+='</td>';
     } else if (atype==2) {
       bmess+='<td><em>netValue </em>';
       bmess+='<span title="cumulative additions (ignoring asset value)"  class="cviewAssetsOverTime_addition">cumAdd</span>';
       bmess+='</td>';
     } else if (atype==3) {
       bmess+='<td><span class="cviewAssetsOverTime_saleprice">netValue </span>   <span class="cviewAssetsOverTime_loanowed"> loanOwed </span>  ';
       bmess+=' <span title="Yearly rent, before taxes. Can be negative" class="cviewAssetsOverTime_yearlyrent"> yearRentPT</span> ';
       bmess+=' <span title="Loan payments, before tax deductions" class="cviewAssetsOverTime_yearlyloanpayments"> yearLoan</span></td>';
     } else if (atype==4) {
       bmess+='<td><em>yearlyIncome (preTax)</em></td>';
     }    // atype
   }     // a1
   bmess+='</tr>';


   viewDates_portfolioAssetTrend={'portfolio':aportfolio,'content':{}};                 // a global used by showAllPortfolioValues_exportAssetOverTime

   for (let jd=0;jd< doViewDatesUse.length;jd++) {
      let aviewDate=doViewDatesUse[jd];

      let amult=calcInflation(aviewDate,nowDayCount) ; // deflate to current date
      let amultSay;
      if (amult===false) {
         amultSay='n.a.';
      } else {
         amultSay=parseFloat(amult).toFixed(3);
      }

      if (aviewDate<creationDate) continue ;  // don't bother if before creation date of this portfolio
      let adateSay=setEntryDate(aviewDate).sayDate ;

// details on each asset
      let plook1=portfolioLookup['list'][aportfolio];
      let modDates=plook1['modDates'];
      let modDatesSay=plook1['modDatesSay'];
      let assetsHere=plook1['assetsList'];

      let ithUse=find_closestDate(modDates,aviewDate);            // what existing entry (creation or modification) is "just before" (or at) this viewdate

       if (ithUse<0)    {                                        // sho8uld never happen (caught above)
        alert('showAllPortfolioValues_viewAssetsOverTime error: ithUse lt 0 ');
        return false;
       }

      let closestStamp=modDates[ithUse];
      let closestStampSay=modDatesSay[closestStamp];
      let assetsHere1=assetsHere[closestStamp];


// THIS DOES THE WORK!
      let  useEntry=makeViewPortfolio(aportfolio,aviewDate,ithUse,closestStamp,0,nowDayCount);       // "grow" the "ithUse" entry  (which as closestStamp as its dateStamp)  -- or use exact match as is

      let initDate=useEntry['original']['date'];

// .. just used for cumulative additions
      let  useEntryFromOrig=makeViewPortfolio(aportfolio,aviewDate,0,initDate,0,nowDayCount);       // "grow" the "ithUse" entry  from initialziat date

      let changesGrowInit= (useEntryFromOrig.hasOwnProperty('changesGrow')) ? useEntryFromOrig['changesGrow']['list'] : false ;

      let xsave=JSON.parse(JSON.stringify(useEntry));  // clone this ;
      delete xsave['original'];
      delete xsave['assetList'];
      delete xsave['summary'];
      xsave['infMult']= amult ;
      xsave['infMultBase']= nowDayCountSay ;
      viewDates_portfolioAssetTrend['content'][aviewDate]=xsave;

      let totalsG=useEntry['totalsG'];

      let changesGrow= (useEntry.hasOwnProperty('changesGrow')) ? useEntry['changesGrow']['list'] : false ;

      let saleValue=totalsG['totAssetSale'];
      let saleValue_inf=amult*saleValue ;
      let saleValueSay1= (doInfAdjust==0) ? wsurvey.addComma(parseInt(saleValue)) :  wsurvey.addComma(parseInt(saleValue_inf)) ;

      let netVal=totalsG['totNetValue'];
      let netVal_inf=amult*netVal ;
      let netValSay1= (doInfAdjust==0) ? wsurvey.addComma(parseInt(netVal)) :  wsurvey.addComma(parseInt(netVal_inf)) ;

      let cashAsset=totalsG['cashAsset'];
      cashAssetSay=wsurvey.addComma(parseInt(cashAsset));
      let cashAsset_inf=amult*cashAsset ;
      cashAsset_infSay=wsurvey.addComma(parseInt(cashAsset_inf));
      let cashAssetSay1= (doInfAdjust==0) ? cashAssetSay :  cashAsset_infSay ;

      let cmess='<span title="Total net value\n Sale value (pre tax, pre loan payout)='+saleValueSay1+'">'+netValSay1+'</span>';

      bmess+='<tr><td>';
      if (aviewDate==creationDate) {
        bmess+=' <span style="background-color:#cbf8f6" title="'+aviewDate+' (creation date)">'+adateSay+'</span> ';
      } else {
 
        if  (portfolioLookup['list'][aportfolio]['modDatesSay'].hasOwnProperty(aviewDate)) {
           bmess+=' <span style="border:3px solid #0bd2c9"  title="'+aviewDate+' (a modification date)">'+adateSay+'</span> ';
        } else {
           bmess+=' <span title="'+aviewDate+'">'+adateSay+'</span> ';
        }
      }
      bmess+='</td>'
      bmess+='<td>'+cmess+'</td>';

      let cmess2='<span style="margin:3px 5px;border:1px solid lime" title="Inflation multiplier">'+amultSay+'</span>' ;
      bmess+='<td>'+cmess2+'</td>';

      let cmess3 ;
      if (Math.abs(cashAsset)>5)  {
        if (cashAsset<5) {
           cmess3='<span style="margin:3px 5px;border:1px solid red" title="`Cash` ">'+cashAssetSay1+'</span>' ;
        } else {
           cmess3='<span style="margin:3px 5px;border:1px solid green" title="`Cash` ">'+cashAssetSay1+'</span>' ;
        }
      } else {
           cmess3='<span style="margin:3px 5px;border:1px solid gray" title="`Cash` ">'+cashAssetSay1+'</span>' ;
      }
      bmess+='<td>'+cmess3+'</td>';

      for (let a1 in allAssets) {
         if (!assetsHere1.hasOwnProperty(a1)) {        // not in this entry
            bmess+='<td>&vellip;</td>';
            continue;
         }
         let assetVals=useEntry['assets'][a1];

         let atype=assetVals['assetType'];
         bmess+='<td><span title="for '+a1+' on '+adateSay+'">';
         let cmess='' ;

         let totVal=assetVals['value'];
         let totValSay= wsurvey.addComma(parseInt(totVal)) ;
         let totVal_inf=amult*totVal ;
         let totVal_infSay= wsurvey.addComma(parseInt(totVal_inf)) ;
         let totValSay1=(doInfAdjust==0) ? totValSay :  totVal_infSay ;

         let netVal=assetVals['netValue'];
         let netValSay= wsurvey.addComma(parseInt(netVal)) ;
         let netVal_inf=amult*netVal;
         let netVal_infSay= wsurvey.addComma(parseInt(netVal_inf)) ;
         let netValSay1= (doInfAdjust==0) ? netValSay :  netVal_infSay ;

          let  add1=0 ;

         if (changesGrowInit!==false && changesGrowInit.hasOwnProperty(a1))   add1=changesGrowInit[a1]['additions'];
         add1_inf=add1*amult;
         let add1Say= wsurvey.addComma(parseInt(add1)) ;
         let add1_infSay= wsurvey.addComma(parseInt(add1_inf)) ;
         let add1Say1= (doInfAdjust==0) ? add1Say :  add1_infSay ;

         let nshares=assetVals['q'];
         if (atype==0)  {
              cmess+='<span title="# shares="'+nshares.toFixed(0)+'\npre-tax value: '+totValSay1+'">'+netValSay1+'</span>   ';
         } else if (atype==1) {
              cmess+='<span title=" ">'+netValSay1+'</span> ';
              cmess+='<span title="additions"  class="cviewAssetsOverTime_addition">'+add1Say+'</span>';
         } else if (atype==2) {
              cmess+='<span title="pre-tax value: '+totValSay1+'">'+netValSay1+'</span>   ';
              cmess+='<span title="additions" class="cviewAssetsOverTime_addition">'+add1Say1+'</span>';
         } else if (atype==3) {

              let salePriceSay=wsurvey.addComma(parseInt(assetVals['price']));
              let salePriceSay_inf=wsurvey.addComma(parseInt(amult*assetVals['price']));
              let salePriceSay1=(doInfAdjust==0) ? salePriceSay :  salePriceSay_inf ;

              let loanOwedSay=wsurvey.addComma(parseInt(assetVals['loanOwed']));
              let loanOwed_infSay=wsurvey.addComma(parseInt(amult*assetVals['loanOwed'])) ;
              let loanOwedSay1=(doInfAdjust==0) ? loanOwedSay :  loanOwed_infSay ;

              let yearlyRentSay=wsurvey.addComma(parseInt(assetVals['yearlyNetRent']));
              let yearlyRent_infSay=wsurvey.addComma(parseInt(amult*assetVals['yearlyNetRent']));
              let yearlyRentSay1=(doInfAdjust==0) ? yearlyRentSay :  yearlyRent_infSay ;

              let yearlyLoanPay1='n.a.';
              if (assetVals.hasOwnProperty('loanSchedule')) {
                let yearlyLoanPay=parseFloat(assetVals['loanSchedule']['yearPay']);
                yearlyLoanPaySay=wsurvey.addComma(parseInt(yearlyLoanPay));
                yearlyLoanPay_infSay=wsurvey.addComma(parseInt(amult*yearlyLoanPay));
                yearlyLoanPay1=(doInfAdjust==0) ? yearlyLoanPaySay :  yearlyLoanPay_infSay ;
              }
              cmess+='<span class="cviewAssetsOverTime_saleprice" title="Net value: after taxes and loan payout. Sale price= '+salePriceSay1+'">'+netValSay1+'</span> ';
              cmess+='<span class="cviewAssetsOverTime_loanowed" title="Loan owed ">'+loanOwedSay1+'</span>  ';
              cmess+='<span class="cviewAssetsOverTime_yearlyrent" title="Yearly Rent (pre taxes)">'+yearlyRentSay1+'</span> ';
              cmess+='<span class="cviewAssetsOverTime_yearlyloanpayments" title="Yearly loan payments (not including tax deductions)" >'+yearlyLoanPay1+'</span> ';
         } else if (atype==4) {

              let yearlyIncome=assetVals['yearlyIncome'];
              let yearlyIncomeSay=wsurvey.addComma(parseInt(yearlyIncome));
              let yearlyIncome_inf=amult*yearlyIncome ;
              let yearlyIncome_infSay=wsurvey.addComma(parseInt(yearlyIncome_inf));
              let yearlyIncomeSay1=(doInfAdjust==0) ? yearlyIncomeSay :  yearlyIncome_infSay ;

              cmess+='<span title="Yearly (after tax) income">'+yearlyIncomeSay1+'</span>';

         }

         bmess+=cmess;
         bmess+='</td>';

      }
      bmess+='</tr>';
   }
   bmess+='</table>';
   displayStatusMessage(bmess );
   toggleStatusMessage(0,2);

}

//====================
// real/nominal view checkboxk 
function showAllPortfolioValues_viewAssetsOverTime_real(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aportfolio=ethis.attr('data-name');
   let icheck= (ethis.prop('checked')) ? 1 : 0  ;
   showAllPortfolioValues_viewAssetsOverTime(0,icheck,aportfolio);
}


//=================
// export the "values of assets over time" data for a portfolio
function showAllPortfolioValues_exportAssetOverTime(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aportfolio=ethis.attr('data-name')

// makea  flatter file
   let dstuff={}
   for (let adate in viewDates_portfolioAssetTrend['content']) {
     let vv=viewDates_portfolioAssetTrend['content'][adate];
     dstuff[adate]={};
     dstuff[adate]['portfolio']=aportfolio;
     dstuff[adate]['sayDate']=vv['dateStampSay'];
     dstuff[adate]['comment']=vv['comment'];
     dstuff[adate]['infMult']=vv['infMult'];
     dstuff[adate]['infBaseDate']=vv['infMultBase'];
     for (let tvar in vv['totalsG']) {
        dstuff[adate][tvar]=vv['totalsG'][tvar];
     }

     for (let tvar in vv['totals']) {
        dstuff[adate][tvar+'_est']=vv['totals'][tvar];
     }
     for (let aname in vv['assets']) {
         for (let avar in vv['assets'][aname]) {
          if (avar=='loanSchedule') {                   // loanSchedule is an object
             let aname2;
             let xloan=vv['assets'][aname]['loanSchedule'];

             aname2=aname+'~loanAmount' ;
             if (xloan===false) {
                dstuff[adate][aname2] =0
             } else {                        // also fix goofy loanOwed  value (if 0)   -- 13 July 2023 fix this hack !
                let lamount= xloan['amount'];
                dstuff[adate][aname2] =lamount;
                if (lamount>0  && dstuff[adate][aname+'~loanOwed']==0) dstuff[adate][aname+'~loanOwed']=lamount ;
             }

             aname2=aname+'~loanStart' ;
                dstuff[adate][aname2] = (xloan===false) ? 0 : xloan['startDate'];
             aname2=aname+'~loanMonthPay' ;
                dstuff[adate][aname2] = (xloan===false) ? 0 : xloan['monthPay'];
             aname2=aname+'~loanMonthYear' ;
                dstuff[adate][aname2] = (xloan===false) ? 0 : xloan['yearPay'];
             aname2=aname+'~loanFirstMonthPrincipal' ;
                dstuff[adate][aname2] = (xloan===false) ? 0 : xloan['month1_prin'];


         } else if (avar=='addition') {
            let aval=vv['assets'][aname][avar];
            let vname=aname+'~additionCum';
            dstuff[adate][vname]=aval;

         } else {
            let aval=vv['assets'][aname][avar];
            let vname=aname+'~'+avar;
            dstuff[adate][vname]=aval;
         }    // loanschedule
       }      // a variable
     }  // an asset
   }          // adate
//   let jstuff=

  let b1=JSON.stringify(dstuff);

  let bmess='Export asset values (<u>not</u> inflation adjusted) --  all viewDates for '+aportfolio+') will be displayed in a new window.<br>';
   bmess+='<ul class="boxList">';
        bmess+='<li>You can save it to a file on your computer (as a .JSON file).';

        bmess+='<li><button class="csettingsButton" onClick="doExportImport2(this)">View its contents </button>  ';
        bmess+='<div  style="width:20em;height:4em;overflow:auto;background-color:#bfbdff" id="showAllPortfolioValues_results_1">'+b1+'</div>' ;
        bmess+='<p>';
        bmess+='<li><button onClick="doExportImport2Mark(1)">copy to the clipboard</button> ';
        bmess+='<span style="color:green;display:hidden" id="showAllPortfolioValues_results_1_copied"><span>';
        bmess+='</ul>';

       bmess+='<li><em>Hint:</em> JSON files can be converted into spreadsheet files (such as XLSX, or ODS) using online tools. However, since this JSON file is deeply nested, some of the less sophisticated tools will fail! '

    displayStatusMessage(bmess);
    toggleStatusDiv(0,2);


}

//  ========
// show init entry (in status box) for a portfolio
function showAllPortfolioValues_viewEntry(athis,ith) {

  if (arguments.length<2) ith=0;
   let ethis=wsurvey.argJquery(athis);
   let aportfolio=ethis.attr('data-name');
   if (!portfolioInit.hasOwnProperty(aportfolio)) {               // should never happen
      alert('error in  showAllPortfolioValues_viewEntry: no such portfolio= '+aportfolio);
      return false;
   }
   let startDate ;
  let modList=(portfolioModifications.hasOwnProperty(aportfolio)) ? portfolioModifications[aportfolio]['dateArray'] : [] ;
   if (ith==0) {
      startDate=portfolioInit[aportfolio]['startDate'];
   } else {
       if (modList.length<ith) {      // should not happen
          alert('showAllPortfolioValues_viewEntry: no such modification ('+ith+') for '+aportfolio);
          return false;
       }
       startDate=modList[ith-1];  // array starts at index 0
   }

    let goo=showPortfolioMix(false,aportfolio,ith,startDate,1);

   let goo2='<div style="background-color:tan"><b>'+aportfolio+'</b>: ';
   if (ith>0) {
     let ith1=ith-1;
     goo2+=' <input type="button" value="&#8612" title="view prior modification" onClick="showAllPortfolioValues_viewEntry(this,'+ith1+')" data-name="'+aportfolio+'"   >';
   }

   if (ith==0) {
      goo2+=' initialization entry ';
      goo2+=' <span style="margin-left:3em;font-size:85">'+modList.length+' modifications</span>';
   } else {
      goo2+=' modification #'+ith+' of '+modList.length ;
   }

   if (ith<modList.length) {
     let ith1=ith+1;
     goo2+=' <input type="button" value="&#8614" title="view next modification" onClick="showAllPortfolioValues_viewEntry(this,'+ith1+')" data-name="'+aportfolio+'"   >';
   }
   goo2+='</div>';
   goo2+=goo;
   displayStatusMessage(goo2);
   toggleStatusMessage(0,2);
//   toggleStatusMessage(1,1);


}

// ====================================
// toggle view of empty rows
function showAllPortfolioValues_toggleEmpty(athis) {
    let ion ;
    if (athis===1 || athis===0) {
        ion=athis;
    } else {
       let ethis=wsurvey.argJquery(athis);
       ion=ethis.attr('data-on');
       ion=1-ion;
        ethis.attr('data-on',ion);
    }
   let etable=$('#portfolioValuesTable');
   let erows=etable.find('.emptyViewRow');
   if (ion==0) {
//     alert('hide '+erows.length);
      erows.hide();
   } else {
//     alert('show '+erows.length);
      erows.show();
   }

}

//============
// display a short summary in a cell of "row 1";
function showAllPortfolioValues_allExtraDetails(athis) {
   let ethis=wsurvey.argJquery(athis);
   let isvu=ethis.attr('data-show');
   isvu=1-isvu;
   ethis.attr('data-show',isvu);
   let etable=$('#portfolioValuesTable');
   let esumms=etable.find('[name="viewPortfolioCell_summary"]');
   let etrans=etable.find('[name="viewPortfolioCell_netTransactions"]');
   if (isvu==1) {
      esumms.show();
      etrans.show();
   } else {
     esumms.hide();
     etrans.hide();
   }
}

//================
// details on a portfolio on a given date
// 8 july: not supported :     totNetValue    totLoanPayYear    periodEarningsTax   periodRevenueTax totEarning  totCashEarnings

function  showAllPortfolioValues_moreDetails(useEntry,pname,closestStamp,closestStampSay) {
     let dstuff={};
      let nAssets=parseFloat(useEntry['totals']['nAsset']);
      let nIncomes=parseFloat(useEntry['totals']['nIncome']);
      dstuff['nAssets']=nAssets ;
      dstuff['nIncomes']=nIncomes ;

      let dateSay=useEntry['dateStampSay'];
      let growDays=useEntry['growDays'];
      let changesGrow= (useEntry.hasOwnProperty('changesGrow')) ? useEntry['changesGrow']: false ;

      if (nAssets+nIncomes ==0) return '&hellip;';
      let totals=useEntry['totals'];
      let totalsG=useEntry['totalsG'];

      let assets=useEntry['assets'];

      let assetList=[];
      let incomeList=[];
      for (let zasset in assets) {
         let atype=assets[zasset]['assetType'];
         if (atype==4) {
             incomeList.push(zasset);
         } else {
            assetList.push(zasset);
         }
      }

      let totValue=parseInt(totalsG['totAssetSale']);   // after paying loan bbalances (before cap gains and tax deferred taxes)
      dstuff['totAssetSale']=totValue ;

      let totNetValue=parseInt(totalsG['totNetValue']);
      dstuff['totNetValue']=totNetValue ;

      let totNetAsset=parseInt(totalsG['totNetAsset']);
      dstuff['totNetAsset']=totNetAsset ;

      let cashAsset=parseInt(totalsG['cashAsset']);
      dstuff['cashAsset']=cashAsset ;

      let totPropertySale=(totalsG.hasOwnProperty('totPropertySale')) ? parseInt(totalsG['totPropertySale']) : -0 ;
      dstuff['totPropertySale']=totPropertySale ;

      let totNetStock=parseInt(totals['totNetStock']);
      dstuff['totNetStock']=totNetStock ;

      let totPropertyProfit=parseInt(totals['totNetProperty']);
      dstuff['totPropertyProfit']=totPropertyProfit ;

      let totLoanOwed=totals['totLoanOwed'] ;
      if (totLoanOwed=='false') totLoanOwed=0;
      totLoanOwed=parseInt(totLoanOwed);
      dstuff['totLoanOwed']=totLoanOwed ;

      let totLoanOriginal=totals['totLoanOriginal'] ;
      if (totLoanOriginal=='false') totLoanOriginal=0;
      totLoanOriginal=parseInt(totLoanOriginal);
      dstuff['totLoanOriginal']=totLoanOriginal ;

      let totBasis=parseInt(totals['totBasis']);
      dstuff['totBasis']=totBasis ;

      let totOwed=parseInt(totals['totLoanOwed']);
      dstuff['totBasis']=totOwed ;

      let totNetRegular=parseInt(totals['totNetRegular']);
      dstuff['totNetRegular']=totNetRegular ;

      let totNetTaxDeferred=parseInt(totals['totNetTaxDeferred']);
      dstuff['totNetTaxDeferred']=totNetTaxDeferred ;

      let totNetBond=totNetRegular+totNetTaxDeferred ;
      dstuff['totNetBond']=totNetBond ;

      let totNetIncomeStream=parseFloat(totals['totNetIncomeStream']);
      dstuff['totNetIncomeStream']=totNetIncomeStream ;

      let totYearlyNetRent=parseFloat(totals['totYearlyNetRent']);
      dstuff['totYearlyNetRent']=totYearlyNetRent ;

      let totLoanPayYear=parseFloat(totals['totLoanPayYear']);
//      dstuff['totLoanPayYear']=totLoanPayYear ;

// in changesGrow
        let  totTaxOnEarnings='n.a.',  totTaxOnRevenue='n.a.',   totEarningsPreTax='n.a.',  totCashEarnings='n.a.' ;
        if (changesGrow!==false) {
            totTaxOnEarnings=changesGrow['totTaxOnEarnings'];
            totTaxOnRevenue=changesGrow['totTaxOnRevenue'] ;
            totEarningsPreTax=changesGrow['totEarningsPreTax'];
            totCashEarnings= changesGrow['totCashEarnings'] ;
        }
        dstuff['totTaxOnEarnings']=totTaxOnEarnings ;
        dstuff['totTaxOnRevenue']=totTaxOnRevenue ;
        dstuff['totEarningsPreTax']=totEarningsPreTax ;
        dstuff['totCashEarnings']=totCashEarnings ;

//      let periodEarningsTax=parseFloat(totalsG['totTaxEarnings']);
//      dstuff['periodEarningsTax']=periodEarningsTax ;
//      let periodRevenueTax=parseFloat(totalsG['totTaxCashEarnings']);
//      dstuff['periodRevenueTax']=periodRevenueTax ;
//      let totEarnings=parseFloat(totalsG['totEarnings']);
//      dstuff['totEarnings']=totEarnings ;
//      let totCashEarnings=parseFloat(totalsG['totCashEarnings']);
//      dstuff['totCashEarnings']=totCashEarnings ;

//      bmess+='<td>'+sayTotalNet+' <span title="before capital gains, and tax deferred, taxes" class="cportfolioValueGross">('+sayTotal+')</span> </td>';

      let assetListSay=assetList.join(', ');
      dstuff['assetList']=assetListSay ;

      let incomeListSay=incomeList.join(', ');
      dstuff['incomeList']=incomeListSay ;

      let oof='<div  title="assets in '+pname+' on ' +dateSay+' "  class="cportfolioValuesTableDetails_assetnames">';
      oof+=' # assets= <tt>'+nAssets+': </tt>   ';
      oof+=' <em>'+assetListSay+'</em> ';
      oof+=' |  # incomes= <tt>'+nIncomes+': </tt>   ';
      oof+=' <em>'+incomeListSay+'</em> ';

      oof+='</div>';
      oof+='<menu class="tighterMenu" title="for portfolio '+pname+' on '+dateSay+'">';

      let sayTotalNet=wsurvey.makeNumberK(totNetValue,100000,0) ;
      let sayTotal=wsurvey.makeNumberK(totValue,100000,0) ;
      let cashSay=wsurvey.makeNumberK(cashAsset,100000,0) ;
      let netAssetSay=wsurvey.makeNumberK(totNetAsset,100000,0) ;
      let totNetStockSay=wsurvey.makeNumberK(totNetStock,100000,0) ;
      let totPropertyProfitSay=wsurvey.makeNumberK(totPropertyProfit,100000,0) ;
      let totBasisSay=wsurvey.makeNumberK(totBasis,100000,0) ;
      let totLoanOwedSay=wsurvey.makeNumberK(totOwed,100000,0) ;

      let totNetRegularSay=wsurvey.makeNumberK(totNetRegular,100000,0) ;
      let totNetTaxDeferredSay=wsurvey.makeNumberK(totNetTaxDeferred,100000,0) ;
      let totNetBondSay=wsurvey.makeNumberK(totNetBond,100000,0) ;

      let totPropertySaleSay=wsurvey.makeNumberK(totPropertySale,100000,0) ;

      let totNetIncomeStreamSay=wsurvey.makeNumberK(totNetIncomeStream,100000,0) ;
      let totYearlyNetRentSay=wsurvey.makeNumberK(totYearlyNetRent,100000,0) ;
      let totLoanPayYearSay=wsurvey.makeNumberK(totLoanPayYear,100000,0) ;

// 24 june ... not accurate, so don't use for nwo
//      let totEarningsSay=wsurvey.makeNumberK(totEarnings,150000,0) ;
//      let totCashEarningsSay=wsurvey.makeNumberK(totCashEarnings,150000,0) ;
//      let periodEarningsTaxSay=wsurvey.makeNumberK(periodEarningsTax,150000,0) ;
//      let periodRevenueTaxSay=wsurvey.makeNumberK(periodRevenueTax,150000,0) ;

      oof+='<li><u>netValue</u>: <b>'+sayTotalNet+'</b>' ;
      oof+=' <span title="gross value (before capital gains, and tax-deferred, taxes)" class="cportfolioValueGross">(<tt>'+sayTotal +'</tt>)</span>';
      oof+='<li>';
      oof+='<span title="netAsset (after tax payments, after loan payouts)"><u>netAsset</u>: <tt> '+netAssetSay+'</tt>'  ;
      oof+='  ... <span title="Amount in `Cash` (residual, or deficit)"><u>Cash</u>: <tt> '+cashSay+'</tt>'  ;

      oof+='<li><span title="approximate net value of all stocks (after capital gains tax)"><u>&#127480;tockValue</u>: <tt> '+totNetStockSay+'</tt>' ;

      oof+='<li><u>&#127463;ondValue</u>: <tt> '+totNetBondSay+'</tt>'
      oof+='<br>&nbsp;&nbsp;&nbsp;<span title="~net value of regular bonds"><u>regular</u>: <tt> '+totNetRegularSay+'</tt></span>' ;
      oof+=',&nbsp;&nbsp;<span title="~net value of tax-deferred bonds (after taxes paid)"><u>tax deferred</u>: <tt> '+totNetTaxDeferredSay+'</tt>'

      oof+='<br><span title="approximate net value of all properties (after capital gains tax)"><u>&#127477;ropertyNetValue</u>: <tt> '+totPropertyProfitSay+'</tt>' ;
      oof+=' ...&nbsp; <span style="font-size:85%" title="gross value of all properties (before paying off loans, before capital gains tax)"><u>propertySell</u>: <tt> '+totPropertySaleSay+'</tt>' ;
      oof+=' ...&nbsp; <span style="font-size:85%" title="amount of unpaid loans"><u>loanOwed</u>: <tt> '+totLoanOwedSay+'</tt></span> ' ;
      oof+='<li><span title="Total basis (for all stocks and properties)\nUsed to compute capital gains taxes)"><u>Basis</u>: <tt> '+totBasisSay+'</tt>' ;

//      oof+='<li><em>Earnings since '+closestStampSay+' ('+growDays+' days)</em>'
      oof+='<li><span title="Yearly income, and yearly net rents">&#127470;ncome/year</u> <tt>'+totNetIncomeStreamSay+'</tt>, <u>netRents</u>=<tt>'+totYearlyNetRentSay +'</tt></span>'
      oof+='<div title="Yearly loan payments (before tax)"><u>loanPayments</u> <tt>'+totLoanPayYearSay +'</tt></div>';

//      oof+='<tt>'+totEarningsSay+'</tt> | netRent&amp;income: <tt>'+totCashEarningsSay+'</tt> ';
//      let atitle='Tax on all earnings in this period (between date and last modification or creation): interest (regular bonds), dividends, netRent and incomeStreams) ';
//       oof+='<br><span title="'+atitle+'"><u>earnings tax</u> <tt>'+periodEarningsTaxSay+'</tt></span> ';
//       oof+='&nbsp;&nbsp; (<span title="Portion of earningsTax from netRents and incomeStreams"><u>revenueTax</u> <tt>'+periodRevenueTaxSay+'</tt>)</span> ';
//      oof+='</menu>';

      return [oof,dstuff] ;
}


// ==================================================
// create a "view results" entry
// similar to showModifyPortfolio_step2, but no display and no read of user input
function makeViewPortfolio(pname,aviewDate,ithUse,closestStamp,useInfRate,nowDayCount)  {

   if (!portfolioInit.hasOwnProperty(pname)) {   // should never happen
      alert('This portfolio ('+pname+') has not been initialized ');
      return false;
   }

   let exactMatch=(closestStamp==aviewDate) ? 1 :  0 ;

   let grownEntry ;
   if (exactMatch==1)       {   // matches an init or mod entry -- so use it (no need to grow from it)
      if (ithUse==0) {
            grownEntry=portfolioInit[pname];
      } else {
             grownEntry=portfolioModifications[pname]['list'][aviewDate];
      }
   } else {

     grownEntry=growPortfolio(pname,ithUse,closestStamp,aviewDate,1);       // makeViewPortfolio: a viewDate by "grow" the "ithUse" entry  (which has closestStamp as its dateStamp)
   }

   let atg=calc_netValues(grownEntry) ;          // in makeViewPortfolio
   grownEntry['totalsG']=atg;

// note: don't bother with changesGrow
   let matchType=ithUse;
   if (aviewDate!=closestStamp  )  {                          // this is a "growth from a prior" entry
        matchType=-1;
        let atg=calc_netValues(grownEntry) ;          // impute some valuess for the growth to this point (
        grownEntry['totalsG']=atg;
        grownEntry['modDaysUse']=false;
        delete grownEntry['changesModify'] ;          // not quite relevant (its leftover from the most recent modENtry)
        delete grownEntry['modifySummary'] ;          // not quite relevant (its leftover from the most recent modENtry)

   } else {                                    // an explict entry
       if (ithUse==0) {                        // the creation entry
          grownEntry['modDaysUse']=0;
       } else {                                   // a modification entry
          grownEntry['modDaysUse']=grownEntry['changesGrow']['growDays'];       // value>0 means "check changesModify for the modifications"
       }
   }
  if (useInfRate==1)    {
     let amult=calcInflation(aviewDate,nowDayCount) ; // deflate to current date
     if (amult===false)  {
        let oof1=setEntryDate(aviewDate);
        grownEntry['summary']=oof1['sayDate']+' is after last year in range ';
     } else {
        let amultSay= amult.toFixed(3);
        grownEntry['summary']=portfolio_totalSummary(grownEntry,' (inflation adjustment: '+amultSay+')',0,amult);   // readdf
     }
  } else {
     grownEntry['summary']=portfolio_totalSummary(grownEntry,' ',0,1.0);   // readdf
  }

   return grownEntry ;

}
//============
// a "portfoliol changes summary"
function makeViewPortfolio_mod(grownEntry) {
   let gg=grownEntry['changesModify'];

   let pp1=parseFloat(gg['netProceeds']);
   let ns1=parseFloat(gg['netSales']);
   let cc1=parseFloat(gg['totCosts'] );

   let amess='';
    let aProceeds=wsurvey.makeNumberK(pp1,100000,0);
    let aSales= wsurvey.makeNumberK(ns1,100000,0);
    let aCosts= wsurvey.makeNumberK(cc1,100000,0);
    amess='<div name="viewPortfolioCell_netTransactions" style="border-top:1px dotted gray"><ul class="tighterMenu">';
    amess+='<li>netProceeds='+aProceeds+'= '+aSales+' - '+aCosts ;
    amess+='<li>#removed='+gg['nremove']+' | #added='+gg['nnew']+' | #changed='+gg['nchange'];
   amess+='</ul></div>';
   return amess;
}


//===============
// display details on a viewDate entry for all portfolios
// just show existing "details" rows (for this date)
function  showAllPortfolioValues_DetailsDate(athis){
  let ethis=wsurvey.argJquery(athis);
  let ashow=ethis.attr('data-show');
  let nowshow=1-ashow;
   ethis.attr('data-show',nowshow);

  let aentry=ethis.attr('data-entry');
  let etable=$('#portfolioValuesTable');
   if (aentry=='*') {        // show all
    let erows2=etable.find('.viewPortfolioRow2');
    for (let ie=0;ie<erows2.length;ie++) {
       let erow1=$(erows2[ie]);
       let ecells=erow1.find('.cportfolioDetailsCell');
       if (nowshow==1) {
          erow1.show();
          ecells.show();
       } else {
          ecells.hide();
          erow1.hide();
       }
    }
    ashow=1-ashow;
    return 1;
  }

// just this row
    let etr1=ethis.closest('.viewPortfolioRow');
    let arow=etr1.attr('data-row');
    let etr2=etable.find('[data-row2="'+arow+'"]');
    let ecells=etr2.find('.cportfolioDetailsCell');
    if (nowshow==1) {
          etr2.show();
          ecells.show();
    } else {
          ecells.hide();
          etr2.hide();
    }


    return 1;
}

//===============
// display details on a all viewDate  entries for one porfolio (all 2nd rows in a column)

function  showAllPortfolioValues_DetailsPortfolio(athis){
  let ethis=wsurvey.argJquery(athis);
  let pname=ethis.attr('data-entry');
  let ison=ethis.attr('data-on');

  let nowon=1-ison ;         // set to this status (0=hide,1=show)
  ethis.attr('data-on',nowon);

  let etable=$('#portfolioValuesTable');

  let ecells1=etable.find('[name="portfolioDetailsCell_'+pname+'"]');  // div inside of td
  let nlen=ecells1.length;

   for (let ii1=0;ii1<nlen;ii1++) {
     let ecellA=$(ecells1[ii1]);
     let etr=ecellA.closest('.viewPortfolioRow2');             // the tr
     let ediv=ecellA.closest('.cportfolioDetailsCell');    // the td
     let ecells2=etr.find('.cportfolioDetailsCell');
      if (nowon==0)      {      // hide this -- but not necessarily other cols in this row
           ediv.hide();
      } else {
         ecells2.hide();
         etr.show();
         ediv.show();
      }
  }
  return 1;



}

