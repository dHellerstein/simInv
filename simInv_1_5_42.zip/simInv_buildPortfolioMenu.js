//============
// Display a menu to specify a portfolio -- starting empty (init), or populated with details of an existing asset mix
// 3 variants:  create an initialization entry, add a modification entry, change an existing modification entry
//
// ismod: 0 - initialize, 1 - existing asset mix (modification)
//     if isMod=0, all other arguments are ignored
//  grownEntry   -- "after growth" portfolio values, and   "list of assets" to pre-populate menu with
//         the "list of assets" array  is typically from  portfolioInit or portfolioModification  -
//  newDate : date of the modificationEntry to create... ignored if ismod=0
//   isChange : if a number >0, the "existing entry to be changed". Its assetList, and assets, are used to pre-populate the menu
//              if not specified or false, then the  grownEntry assets are used to prepopluate
//              However: the portofliol values (cashAsset, totNetValue) are computed using the "grownEntry"
//
// Since    buildPortfolioMenu main purpose is to create an onscreen menu, it does NOT return anything. Nor does is set or change globals
//
// Called by showModifyPortfolio_step2 (isMod will be 1,  and grownEntry and ithUse will be specified. useAssetList non-false only if changing an existing modifcation
//   or    as an event handler by the "Initialize this portfolio " (on the create a portfolio page) -- add non-pre-populated rows
//           isMod will be 0, useEntry= this; this and is used to find portfolio name saved in data-name attribute of the button . ithUse and useAssetList not specified

function buildPortfolioMenu(isMod,grownEntry,newDate,isChange) {

   if (arguments.length<4) isChange=false;       // not a "change existing mod entry"

// 7 july 2023 -- do the modifications in   buildPortfolioMenu_mod
  if (isMod==0)  {
     displayStatusMessage(' initializing a portfolio ...<br>');
      buildPortfolioMenu_init(grownEntry);      // grownentry will be 'this' -- (to give access data-name)
      displayStatusMessage(false,0,1000);
      return 1;
   }

// it is a modification
     displayStatusMessage(' modifying a portfolio ...');

   if (grownEntry['baseEntry']==0) {
          alert('buildPortfolioMenu: baseEntry in grownEntry is 0 ');
          return false;
   }

  if (isChange==false)  {
     buildPortfolioMenu_modAdd(grownEntry,newDate );
        displayStatusMessage(false,0,1000); 
     return 1;
  }

   buildPortfolioMenu_modChange(grownEntry,newDate,isChange );
        displayStatusMessage(false,0,1000);
   return 1;

 }


//==============
// build a "portfolio specification" menu -- for initialziation entries.
// this is similar (and uses common functions) to   buildPortfolioMenu

function buildPortfolioMenu_init(athis) {

   let ethis=wsurvey.argJquery(athis);
   let pname=ethis.attr('data-name');

   let useScenario;
// a "scenario" version of a portfolio? If so, exclude assets that have a different scenario
   let pnameF=getAssetFamily(pname,1);

   if (pnameF['scenario']=='') {
      useScenario=false;
   } else {
    useScenario=pnameF['scenario'];
   }

   let ithBase=false,growThisDate=false,growThisDateSay=false,makeThisDate,makeThisDateSay;
   let  grownEntry={};

   let jyear,jday,jmonth ;

   let zz=portfolioLookup['list'][pname];
   let nHistory=zz['nHistory'];
   let adesc=portfolioList[iz]['desc'];


    ithBase=false;
    let oof=setEntryDate(true);      // returns most recenlty saved, or current date if no save in this session
    jyear=oof['year'],jday=oof['day'],jmonth=oof['month'];
    makeThisDate=oof['dayCount'];
    makeThisDateSay=oof['sayDate'];

   let amess='';

// three divs are created and displayed :     portfolioHistory1   portfolioHistory_bar1  portfolioHistory_footer

//  1) portfolioHistory1:  the main container --  portfolioHistory1Head ,    portfolioHistory1AssetHeaderDiv ,portfolioHistory1AssetRows_div

   amess+='<div style="border:1px solid gray" id="portfolioHistory1"     >';

// top table: info cells, Initialize, etc cells,
   amess+='<table  border="1" id="portfolioHistory1Head" width="98%"   class="cportfolioTable">';

   amess+='<tr class="headerRowInit">';  // just 1 row in this table

// navigation, submit, and help button cell
    amess+='<td width="15%" >';

      amess+='<button title="Return to portfolio list ... " data-name="'+pname+'" onClick="showPortfolioTable(this)">&#8617;&#65039;</button>  ';
      amess+='<input type="button" value="&neArr;" title="View in a new window"  data-id="mainDiv" onClick="displayInWindow(this)"> ';
      amess+=' <button class="csaveButton" title="Initialize this portfolio " data-name="'+pname+'" onClick="savePortfolioInit(this)">Initalize!</button>';
      amess+=' <button title="Tips" onClick="displayHelpMessage(this)" data-div="#portfolioHistoryHelp1">&#10068;</button>';
    amess+='</td>';

// portfolio name and short descirpiton cell

    amess+='<td width="14%"> '
    amess+='<span class="portfolioNameSay"><em>portfolio: '+pname+'</em></span> ';
    amess+='<span title="Short description"   class="cdescNoteBuildPortfolio"> '+adesc+'</span> ';
    amess+='</td>';

// budget cell    . defaultBudget is global setting

    amess+='<td width="22%"   > '
    amess+='<span style="font-size:110%;font-weight:600">';
    amess+='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioProposedBudgetHelp1">?</button>  ';
    amess+='Proposed budget</span>:';
      amess+='   <input type="text" name="portfolioBudget"  style="font-size:110%" size="7" title="Dollars to allocate to various assets"  ';
      amess+= '    data-budget="'+defaultBudget+'" data-orig="'+defaultBudget+'" value="'+defaultBudget+'">';
     amess+='</td>';

// dates (initialization, modificatoin, priorentry..) cell

   amess+='<td width="45%"   style="border-right:0px dotted blue;text-align:right"> ' ;
     amess+='<span style="color:green;display:none" id="updatedCreationDate">Initialization date changed ...  prices were updated ... </span> ';
     amess+='<span style="color:#a69b29;margin-right:1em">Initialization date ... </span> ';
     amess+='    Y:<input type="text"   onChange="buildPortfolioMenu_date(this)"  name="portfolioDateYear" size="3" title="year" value="'+jyear+'" > &nbsp;&nbsp; ';
     amess+='    M:<input type="text"   onChange="buildPortfolioMenu_date(this)"   name="portfolioDateMonth" size="3" title="Month: 1 ... 12, or Jan ... Dec" value="'+jmonth+'" > &nbsp;&nbsp;  ';
     amess+='    D:<input type="text"   onChange="buildPortfolioMenu_date(this)"   name="portfolioDateDay" size="4" title="Day of month"  value="'+jday+'" >';
   amess+='</td>';

  amess+='</tr>';
  amess+='</table>';

// list of  buttons .. for all existing assets... with highlighting of assets currently in the portfolio's asset-mix

  amess+='<div id="portfolioHistory1AssetHeaderDiv" style="max-height:7em;overflow:auto;">';
  amess+='<table  border="1" id="portfolioHistory1AssetHeader" width="98%"   class="cportfolioTable">';

  amess+='<tr bgcolor="#edf6f6" id="portfolioHistoryAssetList"   >';

// button cell (copy protoflio, sort buttons..)
  amess+='<td width="15%" ><span style="background-color:#daf7f9;padding;3px">&hellip;add an asset &hellip; ';
  amess+='<button style="color:blue" onclick="buildPortfolioMenu_sortAsset(this)" title="sort the asset list -- order of creation, alphabetical, by type " data-how="0"> &#10143;</button>';
  amess+='</span>';
  amess+='<br><em>or </em> <input type="button" data-name="'+pname+'" value="Copy a portfolio... " title="Copy the asset mix of an existing portfolio" onClick="copyPortfolio(this)">';
  amess+=' </td>';

// list of buttons: add asset to asset-mix menu
  amess+='<td width="83%" >';
  amess+='<ul class="linearMenu18Pct" name="portfolioTable_assetButtons" title="Available assets ... ">   ';
  amess+='<li data-type="-1" data-name="Cash" data-orig="0"  data-init="1">  ';       // -1:cash

  amess+='<span  title="The remaining cash (or, if negative, additional required cash) after allocation of the budget to selected assets">Cash &#65284;</span>';

// the "add this asset to the mix" buttons     -- all available assets
  let ifoo=0;
  for (let casset in assetLookup) {
      let assetType=doAssetLookup(casset,'assetType',2);;
      let assetSay=getAssetType(assetType,'say');
      let nHistory=doAssetLookup(casset,'nHistory',2)  ;

// don't show this asset?
      if (skipNoHistoryAsset==1) {
        if (nHistory==0) continue ;    // not initialized
        if (useScenario!==false)   { // check if  this asset is in a different scenario. If so, skip
          let cFamily=getAssetFamily(casset,1);
          if (cFamily['scenario']!='')   {        // non-scenario assets avaialable to all portoflios
             if (cFamily['scenario']!=useScenario) continue ; // in a different scenario .. don't show
           }  // this asset has a scenario
         }    // this portfolio has  a scenario
      }                // skipNoHistoryAsset (or if different scenario
      ifoo++;
      amess+='<li data-type="'+assetType+'" data-name="'+casset+'" data-orig="'+ifoo+'" data-nhistory="'+nHistory+'" >';
      if (nHistory==0)  {  // no history entries -- hence not price, et c
         amess+='<span style="opacity:0.5" title="This asset has not  been initialized (there is no price, etc.)"> ';
         amess+=casset+'</span>';
      } else {
         let adesc=doAssetLookup(casset,'desc');
         amess+='<label  title="Description: '+adesc+'"> ';

         let notAvail=' ',titleA='Click to add this asset',fdate=assetLookup[casset]['firstHistoryDate'];
        if (fdate>makeThisDate)  {
           notAvail=' disabled ';
            titleA='This asset is not available (it is not defined for the target date)' ;
        }
         let firstEntryDate
         amess+='<button '+notAvail+' value="'+casset+'" data-type="'+assetType+'"  data-firstdate="'+fdate+'" data-chosen="0"   title="'+titleA+'" ';
         amess+='   data-name="'+casset+'" name="portfolioTable_assetButtons_1"  onClick="portfolioAddAssetNew(this)" > '; //  buildPortfolioMenu_init
         amess+= casset+'</button>';
         amess+='<span  >'+assetSay+'</span> </label>';

// these infoettes (next to the add this asset button) are populated by calls to buildPortfolioMenu_priceUpdate (below)
         if (assetType==0 ) {
            amess+='<span name="assetValue_now" data-type="0" data-name="'+casset+'" data-value="" title="Per share price: as of '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==3 ) {
            amess+='<span name="assetValue_now"  data-type="3"  data-value=""   data-name="'+casset+'" title="Property price:  as of  '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==4 ) {
            amess+='<span name="assetValue_now"  data-type="4"  data-value=""   data-name="'+casset+'" title="Yearly income:  as of  '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }

         amess+='</span>';
      }
  }          // add asset buttons

  amess+='</ul>';
  amess+='</td> ';
  amess+='</tr>';        // clickable list of assets
  amess+='</table>';     //portfolioHistory1AssetHeader

  amess+='</div>';      // portfolioHistory1AssetHeaderDiv

// column names

  amess+='<div id=portfolioHistory1AssetRows_div" class="cportfolioHistory1AssetRowsDiv">';

  amess+='<table  border="1" id="portfolioHistory1AssetRows" width="99%"   class="cportfolioTable">';

   amess+='<tr class="headerRow">';
   amess+='<td  width="1%"  ><input type="button" style="font-family:oblique" value="Reset" title="reset values " onClick="buildPortfolioMenu_reset(this)"> ';

   amess+='<input type="hidden" name="baseEntry_ith" value="0">';
   amess+='<input type="hidden" name="baseEntry_closestDate" value="0">';

  amess+='</td>';
  amess+='<th  width="14%" ><span  title="Name of an existing asset">';
  amess+='<button style="margin-bottom:5px" title="Tips on adding assets" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueAddAsset">&#10068;</button>';

  amess+='<b>Name</b></span>';
  amess+='</th>';
  amess+='<th width="36%"> <span title="Allocation to this asset --. As #shares, $ amount, or % of budget">Allocations (# shares or $, etc.)</span></th>';
  amess+='<td  width="35%">  ';

// these fields are filled by addARowPortfolioAssetMix_assetSummary
  amess+='<div name="allocationHeader_allocation" class="cAllocationHeader" style="display:none"> ';
    amess+='<u>Current</u>: <span  title="Cost (to obtain asset), and pct of total cost" class="cmyCost_span">Cost</span>';
    amess+=' <span  title="Gross (pre-tax, pre loan payback) value, and pct of total value " class="cmyValue_span">Value</span>';
    amess+=' <span  title="Net (after-tax, after loan payback) value, and pct of total net value " class="cmyNetValue_span">netValue</span>';
    amess+=' <span  title="Net revenue (such as rents - mortgagePayments). Can be negative " class="cmyNetRevenue_span">netRevenue</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_info" style="overflow-wrap: break-word;overflow:auto;white-space:normal;" class="cAllocationHeader"  style="display:none"> ';
    amess+='<span title="Information for each asset, as of the current modification (or creation) date" class="cmyValue_span">Info (yearly):  dividends, interest rate, income, &hellip;</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_base"  class="cAllocationHeader"  style="display:none"> ';
    amess+='<u>preGrowth</u>: ';
    amess+='<span  title="Cost (to obtain asset), and pct of total cost" class="cmyCost_span">Cost</span>';
    amess+=' <span  title="Gross (pre-tax, pre loan payback) value, and pct of total value " class="cmyValue_span">Value</span>';
    amess+=' <span  title="Net (after-tax, after loan payback) value, and pct of total net value " class="cmyNetValue_span">netValue</span>';
    amess+=' <span  title="Share price, or loan amount owed" class="cmyNetRevenue_span">Price or loan</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_changes"  class="cAllocationHeader"  style="display:none"> ';
// filled by buildPortfolioMenu_showChanges
  amess+='</div>'

  amess+='</td>';
  amess+='<th  width="10%"> <span title="Comment">Comment</span></th>';
  amess+='</tr>';

//end of header and help rows

// the cash row

   amess+='<tr class="portfolioHistoryRowCash"  >';
   amess+='<td title="sort by: asset type">&hellip;</td>';

   amess+='<td title="sort by: asset name"><u>Cash</u> </td>';
   amess+='<td title="sort by: gross (pre-tax) value" >';
   amess+=' <input readonly style="opacity:0.6;color:blue" type="text" name="portfolioCashRemain" size="9" value="" data-value=""   ';
   amess+=' title="Remaining cash; if negative, additional cash required  to obtain asset mix\nThis is automatically calculated "  size="4"     >';
   amess+=' <button  data-name="'+pname+'" title="Allocate remaining cash to first empty asset" onClick="allocateCashToEmpty(this,0)">&#1769;</button> ';
   amess+='</td>';

   amess+='<td title="sort by: net (after tax) value">';
   amess+='<span class="cgrossValue"  ><tt>  &hellip;</tt></span>  ';
   amess+='<input type="button"  id="iUpdatePricesButton" value="&#11118; &#128712;" title="Display prices, etc. ... as of the creation date" onClick="buildPortfolioMenu_priceUpdate(0)" >'; // update using currently specified creation date
   amess+='</td>';

   amess+='<td  title="sort by: fraction of portfolio in this asset"><input type="hidden" name="portfolioComment" value="Cash remaining (or required) ">';
   amess+='<input type="text" disabled size="35"  value="remaining, or (if negative) required, cash"></td>';
   amess+='</tr>'

  amess+='</table>'; //portfolioHistory1AssetRows
  amess+='</div> ' ;   //portfolioHistory1AssetRows_div

  amess+='</div>';  // end of portoflioHistory1

// calcluate portfolio value results, display resuilts

// just a seperator  ........
  amess+='<div id="portfolioHistory_bar1" style="background-color:brown;margin:3px 30% 3px 30%;height:0.1em">&nbsp;</div>' ;

// submit buttons and summary boxes   ...........
  amess+='<div id="portfolioHistory_footer" style="border:2px solid gold" width="99%">';

  amess+='<div name="portfolioHistory_comment" title="optional comment" style="display:none;background-color:#d7f8fb;margin:3px 10% 3px 10%;padding:1px 3px 1px 18px" >'  ;
  amess+='Comment (optional): <input type="text" size="80" name="portfolioHistory_commentInput"> ';
  amess+='</div> '  ; //portfolioHistory_comment

  amess+='<table style="border:2px solid gold" width="99%">';

  amess+='<tr>';

// calculate the portoflio value cell
  amess+='<td valign="top" width="10%">';
    amess+='<button id="icalcPortfolioValue_init"  style="margin-bottom:5px" title="Tips" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueHelpInit1">&#10068;</button>';
    amess+='<button id="icalcPortfolioValue_mod"  style="display:none;margin-bottom:5px" title="Tips" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueHelp1">&#10068;</button>';
    amess+='<br>';
    amess+='<button id="calcPValueButton"  class="calcButton" title="Calculate values of this proposed asset-mix ... as of the specified creation date"   ';
    amess+=' onClick="portfolioCalcValueMenu_init(this)" data-name="'+pname+'">Calculate portfolio value</button>'; // in buildPortfolioMenu -- suppress summary
  amess+='</td>';

// summary of current portofliol (where current value is written)
  amess+='<td valign="top" width="20%">';
    amess+='<div id="assetHistory_currentSummary" title="Summary of current portfolio "  ';
    amess+='     class="cassetHistory_currentSummary"  >';
    amess+='</div>';
  amess+='</td>';

// after modiffications -- NOT USED when creating initial entry!
  amess+='<td valign="top" width="25%">';
// this is filled by portfolioCalcValueMenu_modify
  amess+='<div id="assetHistory_modifiedSummary"  class="cassetHistory_modifiedSummary"  ';
  amess+='   title="Summary of proposed modifications ">';
  amess+=' </div>';
  amess+='</td>';

// warning notes
  amess+='<td valign="top" width="40%">';
  amess+='<div id="assetHistory_currentSummaryNote" class="cassetHistory_currentSummaryNote"  > ';
  amess+='</div>';
  amess+='</td>';

  amess+='</tr>';
  amess+='</table>';

  $('#mainDiv3').html(amess);
  amess+='</div>';

  wsurvey.wsShow.show('#mainDiv3','show');
 
  $('#icalcPortfolioValue_init').show();
  $('#icalcPortfolioValue_mod').hide();

   buildPortfolioMenu_priceUpdate(0)  ; // calculate all current asset values, and display prices etc on buttons

    return 1   ;          // nothing to pre-popoulate with
 }


//==============    family
// build a "portfolio specification" menu -- for adding a new modification entry.
// this is similar (and uses common functions) to   buildPortfolioMenu

function buildPortfolioMenu_modAdd(grownEntry,newDate) {
//alert('in  buildPortfolioMenu_modAdd: new date '+newDate);
   let pname,gotUse;

   pname=grownEntry['name'];
   let zz=portfolioLookup['list'][pname];

   let nHistory=zz['nHistory'];
   let adesc=portfolioList[iz]['desc'];

   let ithBase,growThisDate,growThisDateSay,makeThisDate,makeThisDateSay;

   let jyear,jday,jmonth ;

   ithBase=grownEntry['baseEntry']['ith'];
   grownDate=grownEntry['baseEntry']['dateStamp'];
   let oof3=setEntryDate(grownDate);
   grownDateSay=oof3['sayDate'];

   makeThisDate=newDate;
   let oof4=setEntryDate(makeThisDate);
   let jYear=oof4['year'],jMonth=oof4['month'],jDay=oof4['day'];
//   alert([jYear,jMonth,jDay]);
   makeThisDateSay=oof4['sayDate'] ;

   let amess='';

// three divs are created and displayed :     portfolioHistory1   portfolioHistory_bar1  portfolioHistory_footer

//  1) portfolioHistory1:  the main container --  portfolioHistory1Head ,    portfolioHistory1AssetHeaderDiv ,portfolioHistory1AssetRows_div

   amess+='<div style="border:1px solid gray" id="portfolioHistory1"     >';

   amess+='<table  border="1" id="portfolioHistory1Head" width="98%"   class="cportfolioTable">';

// top row (with add save ? buttons... and creation date )
   amess+='<tr class="headerRowInit">';

// navigation, submit, and help button cell

    amess+='<td width="15%" >';
    amess+='<button title="Return to modificationDate specification" data-name="'+pname+'" onClick="showPortfolioViewModify(this,1)">&#8656;</button>  ';
    amess+='<input type="button" value="&neArr;" title="View in a new window"  data-id="mainDiv" onClick="displayInWindow(this)"> ';
    amess+=' <button class="csaveButton"  id="idoModifyPortfolioReview" data-name="'+pname+'" title="Review the modifications to the portfolios history (changes to its asset mix)" data-name="'+pname+'" onClick="reviewPortfolioMod(this)">Review</button>';
    amess+=' <button title="Tips" onClick="displayHelpMessage(this)" data-div="#portfolioHistoryHelp1">&#10068;</button>';
    amess+='</td>';

// portfolio name and short descirpiton cell

    amess+='<td width="14%"> '
    amess+='<span     class="portfolioNameSay"><em>portfolio: '+pname+'</em></span> ';
    amess+='<span title="Short description"   class="cdescNoteBuildPortfolio"> '+adesc+'</span> ';
    amess+='</td>';

// budget cell

    amess+='<td width="22%"   > '

    let totNet0=grownEntry['totNetValue'];
    amess+='<span style="font-size:110%;font-weight:600" data-value="'+totNet0+'" name="totNet_value"  ';
    amess+='  title="Before modifications: the after tax, and after loan payoffs, value of the asset-mix (including `Cash`)">Portfolio netValue: ';
    let sayNetValue=wsurvey.addComma(parseInt(totNet0));
    amess+=sayNetValue;
    amess+='<span class="cdescNoteLittle" name="portfolioTotValue_note1" title="gross value (pre-tax,pre loan payoffs)">';
    let sayGrossValue=wsurvey.makeNumberK(grownEntry['totals']['totAssetSale'],5000) ;
    amess+=' &nbsp; ['+sayGrossValue+'] ';
    amess+='</span>';
    amess+='</span>';

     let origBudget=portfolioInit[pname]['original']['budget'];
     let origBudgetSay=wsurvey.addComma(parseInt(origBudget) ) ;
     amess+='<span class="cdescNoteLittle" style="float:right;margin-right:0.5em" data-budget="'+origBudget+'" name="original_budget" title="original budget (specified when portfolio was created)">'+origBudgetSay+'</span>';
     amess+='</td>';

// dates (initialization, modificatoin, priorentry..) cell

    amess+='<td width="45%"   style="border-right:0px dotted blue;text-align:right"> ' ;
    amess+='<span style="color:#a66529;margin-right:1em">Add a modification for: <tt>'+makeThisDateSay+'</tt></span>  ';

    amess+='<input type="hidden"    name="portfolioDateYear" size="3"  value="'+jYear+'" >   ';
    amess+='<input type="hidden"      name="portfolioDateMonth" size="3"   value="'+jMonth+'" > ';
    amess+='<input type="hidden"       name="portfolioDateDay" size="4" t   value="'+jDay+'" >';

   if (ithBase==0) {             // growing the initial entry
       amess+=' <span  title="dayCount: '+grownDate+'" class="cdescNoteLittle" style="float:right;margin-right:2em"> Growing the <u>initial</u> asset mix (<tt>'+grownDateSay+'</tt>)</span> ';
   } else {                     // growing a modification entry
       amess+=' <span title="dayCount: '+grownDate+'" class="cdescNoteLittle" style="float:right;margin-right:2em"> Growing the <u>modification</u> asset mix (<tt>'+grownDateSay+'</tt>)</span> ';
   }
   amess+='</td>';
  amess+='</tr>';
  amess+='</table>';


// list of  buttons .. for all existing assets... with highlighting of assets currently in the portfolio's asset-mix

  amess+='<div id="portfolioHistory1AssetHeaderDiv" style="max-height:7em;overflow:auto;">';
  amess+='<table  border="1" id="portfolioHistory1AssetHeader" width="98%"   class="cportfolioTable">';

  amess+='<tr bgcolor="#edf6f6" id="portfolioHistoryAssetList"   >';
  amess+='<td width="15%" ><span style="background-color:#daf7f9;padding;3px">&hellip;add an asset &hellip; ';
  amess+='<button style="color:blue" onclick="buildPortfolioMenu_sortAsset(this)" title="sort the asset list -- order of creation, alphabetical, by type " data-how="0"> &#10143;</button>';
  amess+='</span>';

  amess+=' </td>';
  amess+='<td width="83%" >';
  amess+='<ul class="linearMenu18Pct" name="portfolioTable_assetButtons" title="Available assets ...   ">   ';
  amess+='<li data-type="-1" data-name="Cash" data-orig="0"  data-init="1">  ';       // -1:cash

  amess+='<span  title="The remaining cash (or, if negative, additional required cash) after allocation of the budget to selected assets">Cash &#65284;</span>';

// the "add this asset to the mix" buttons
  let ifoo=0;
  for (let casset in assetLookup) {
      let assetType=doAssetLookup(casset,'assetType',2);;
      let assetSay=getAssetType(assetType,'say');
      let nHistory=doAssetLookup(casset,'nHistory',2)  ;
      ifoo++;
      amess+='<li data-type="'+assetType+'" data-name="'+casset+'" data-orig="'+ifoo+'" data-nhistory="'+nHistory+'" >';
      if (nHistory==0)  {  // no history entries -- hence not price, et c
         amess+='<span style="opacity:0.5" title="This asset has not  been initialized (there is no price, etc.)"> ';
         amess+=casset+'</span>';
      } else {

         let adesc=doAssetLookup(casset,'desc');
         amess+='<label  title="Description: '+adesc+'"> ';

         amess+='<button value="'+casset+'" data-type="'+assetType+'"  data-chosen="0"   title="click to add this asset"   ';
         amess+='   data-name="'+casset+'" name="portfolioTable_assetButtons_1"  onClick="portfolioAddAssetNew(this)" > ';   // buildPortfolioMenu_modAdd
         amess+= casset+'</button>';
         amess+='<span  >'+assetSay+'</span> </label>';

// these infoettes (next to the add this asset button) are populated by calls to buildPortfolioMenu_priceUpdate (below)
         if (assetType==0 ) {
            amess+='<span name="assetValue_now" data-type="0" data-name="'+casset+'" data-value="" title="Per share price: as of '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==3 ) {
            amess+='<span name="assetValue_now"  data-type="3"  data-value=""   data-name="'+casset+'" title="Property price:  as of  '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==4 ) {
            amess+='<span name="assetValue_now"  data-type="4"  data-value=""   data-name="'+casset+'" title="Yearly income:  as of  '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }

         amess+='</span>';
      }
  }          // add asset buttons

  amess+='</ul>';
  amess+='</td> ';
  amess+='</tr>';        // clickable list of assets
  amess+='</table>';     //portfolioHistory1AssetHeader
  amess+='</div>';      // portfolioHistory1AssetHeaderDiv

// column names

  amess+='<div id=portfolioHistory1AssetRows_div" class="cportfolioHistory1AssetRowsDiv">';
  amess+='<table  border="1" id="portfolioHistory1AssetRows" width="99%"   class="cportfolioTable">';

   amess+='<tr class="headerRow">';
   amess+='<td  width="1%"  ><input type="button" style="font-family:oblique" value="Reset" title="reset values " onClick="growPortfolio_reset(this)">';

   amess+='<input type="hidden" name="baseEntry_ith" value="'+grownEntry['baseEntry']['ith']+'">';
   amess+='<input type="hidden" name="baseEntry_closestDate" value="'+ grownEntry['baseEntry']['dateStamp']+'">';

  amess+='</td>';
  amess+='<th  width="14%" ><span  title="Name of an existing asset">';
  amess+='<button style="margin-bottom:5px" title="Tips on adding assets" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueAddAsset">&#10068;</button>';

  amess+='<b>Name</b></span>';
  amess+='</th>';
  amess+='<th width="36%"> <span title="Allocation to this asset --. As #shares, $ amount, or % of budget">Allocations (# shares or $, etc.)</span></th>';
  amess+='<td  width="35%">  ';

// these fields are filled by addARowPortfolioAssetMix_assetSummary
  amess+='<div name="allocationHeader_allocation" class="cAllocationHeader" style="display:none"> ';
    amess+='<u>Current</u>: <span  title="Cost (to obtain asset), and pct of total cost" class="cmyCost_span">Cost</span>';
    amess+=' <span  title="Gross (pre-tax, pre loan payback) value, and pct of total value " class="cmyValue_span">Value</span>';
    amess+=' <span  title="Net (after-tax, after loan payback) value, and pct of total net value " class="cmyNetValue_span">netValue</span>';
    amess+=' <span  title="Net revenue (such as rents - mortgagePayments). Can be negative " class="cmyNetRevenue_span">netRevenue</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_info" style="overflow-wrap: break-word;overflow:auto;white-space:normal;" class="cAllocationHeader"  style="display:none"> ';
    amess+='<span title="Information for each asset, as of the current modification (or creation) date" class="cmyValue_span">Info (yearly):  dividends, interest rate, income, &hellip;</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_base"  class="cAllocationHeader"  style="display:none"> ';
    amess+='<u>preGrowth</u>: ';
    amess+='<span  title="Cost (to obtain asset), and pct of total cost" class="cmyCost_span">Cost</span>';
    amess+=' <span  title="Gross (pre-tax, pre loan payback) value, and pct of total value " class="cmyValue_span">Value</span>';
    amess+=' <span  title="Net (after-tax, after loan payback) value, and pct of total net value " class="cmyNetValue_span">netValue</span>';
    amess+=' <span  title="Share price, or loan amount owed" class="cmyNetRevenue_span">Price or loan</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_changes"  class="cAllocationHeader"  style="display:none"> ';
// filled by buildPortfolioMenu_showChanges
  amess+='</div>'
  amess+='</td>';

  amess+='<th  width="10%"> <span title="Comment">Comment</span></th>';
  amess+='</tr>';

//end of header and help rows

// the cash row

   amess+='<tr class="portfolioHistoryRowCash"  >';
   amess+='<td title="sort by: asset type">&hellip;</td>';
   amess+='<td title="sort by: asset name"><u>Cash</u> </td>';
   amess+='<td title="sort by: gross (pre-tax) value" >';
   let cbalance=grownEntry['cashAsset'];
   let cbalanceSay=  wsurvey.addComma(parseInt(cbalance)) ;
   amess+=' <input readonly style="opacity:0.6;color:blue" type="text" name="portfolioCashRemain" size="9" value="'+cbalanceSay+'" data-value="'+cbalance+'"  ';
   amess+=' title="`Cash` -- remaining cash. If negative, additional cash required  to obtain asset mix\n  ';
   amess+=        ' Includes `Cash`from initial (or modification) portfolio... plus accumulated taxes, revenues, and payments ... and interest growth on this `Cash`!\n You can not manually specify this value!"  size="4"     >';
   amess+=' <button  data-name="'+pname+'" title="Allocate remaining cash to first empty asset" onClick="allocateCashToEmpty(this,1)">&#1769;</button> ';
   amess+='<span style="padding:1px 3px;color:green;background-color:#e9e8c8" title="Accumulated `Cash` (since portfolio creation, or last modifcation) -- NOT adjusted for interest growth ">';

  let cashAcc=grownEntry['changesGrow']['cashAssetChangeGrow'];
  let cc1=wsurvey.addComma(parseInt(cashAcc));
  amess+='&#120491;<u>Cash</u>= <tt>'+cc1+'<tt>' ;
   amess+='</span>'
   amess+='</td>';

   amess+='<td title="sort by: net (after tax) value">';
   amess+='<span class="cgrossValue"  ><tt>  &hellip;</tt></span>  ';
   amess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#buildPortfolioMenu_others1">&#10068;</button>';
     amess+='<input type="button" value="&#128712;" title="Display prices, etc. ... as of the modification date" onClick="buildPortfolioMenu_priceUpdate(-1)" >';  // use most recently computed prices
     amess+='<input type="button" value="&#9918;" title="Show current asset allocation  (before modification)  " onClick="buildPortfolioMenu_showBase(this)" >';
  amess+='<input type="button" value="&#8710;" title="Show changes due to growth (before modification) asset allocation " onClick="buildPortfolioMenu_showChanges(this)" >';
   amess+='</td>';

   amess+='<td  title="sort by: fraction of portfolio in this asset"><input type="hidden" name="portfolioComment" value="Cash remaining (or required) ">';
   amess+='<input type="text" disabled size="35"  value="remaining, or (if negative) required, cash"></td>';
   amess+='</tr>'

  amess+='</table>'; //portfolioHistory1AssetRows
  amess+='</div> ' ;   //portfolioHistory1AssetRows_div

// calcluate portfolio value results, display resuilts
  amess+='</div>';

  amess+='<div id="portfolioHistory_bar1" style="background-color:brown;margin:3px 30% 3px 30%;height:0.1em">&nbsp;</div>' ;

  amess+='<div id="portfolioHistory_footer" style="border:2px solid gold" width="99%">';

  amess+='<div name="portfolioHistory_comment" title="optional comment" style="display:none;background-color:#d7f8fb;margin:3px 10% 3px 10%;padding:1px 3px 1px 18px" >'  ;
  amess+='Comment (optional): <input type="text" size="80" name="portfolioHistory_commentInput"> ';
  amess+='</div> '  ; //portfolioHistory_comment

  amess+='<table style="border:2px solid gold" width="99%">';
  amess+='<tr>';
  amess+='<td valign="top" width="10%">';
  amess+='<button id="icalcPortfolioValue_init"  style="margin-bottom:5px" title="Tips" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueHelpInit1">&#10068;</button>';
  amess+='<button id="icalcPortfolioValue_mod"  style="display:none;margin-bottom:5px" title="Tips" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueHelp1">&#10068;</button>';
  amess+='<br>';

  amess+='<br>';
  amess+='<button id="calcPValueModifyButton"  class="calcButton" title="What are the values of this modified asset mix\n... as of the specified modification date" data-name="'+pname+'" onClick="portfolioCalcValueMenu_modify(this)">Calculate modified value</button> ';  // in buildPortfolio

  amess+='</td>';
  amess+='<td valign="top" width="20%">';
  amess+='<div id="assetHistory_currentSummary" title="Summary of current portfolio "  class="cassetHistory_currentSummary"  > </span>';
  amess+='</td>';
  amess+='<td valign="top" width="25%">';

// this is filled by portfolioCalcValueMenu_modify

  amess+='<div id="assetHistory_modifiedSummary"  class="cassetHistory_modifiedSummary"  ';
  amess+='   title="Summary of proposed modifications "> </div>';
  amess+='</td>';
  amess+='<td valign="top" width="40%">';
  amess+='<div id="assetHistory_currentSummaryNote" class="cassetHistory_currentSummaryNote"  > </div>';
  amess+='</td>';
  amess+='</tr>';
  amess+='</table>';
  
  amess+='</div>';

  $('#mainDiv3').html(amess);

 wsurvey.wsShow.show('#mainDiv3','show');

  $('#icalcPortfolioValue_init').hide();
   let oink1=$('#icalcPortfolioValue_mod')
   oink1.show();

// pre populate with existing shares ,etc  .. first do price updating

   let useThisEntry1=grownEntry;
   let useThisList=useThisEntry1['assetList'];

  buildPortfolioMenu_priceUpdate(2,useThisEntry1['assets'],makeThisDate)  ; // calculate all current asset values, with info from "entry to be grown"

   for (let i1=0;i1<useThisList.length;i1++) {         // prepopulate ... perhaps with "to be changed modEntry" assets
      let astuff=useThisList[i1];
      let aname=astuff['name'];

      let omess=portfolio_checkAssetAdded(aname);    // buildPortfolioMenu: asset exists? Not alredy in portfolio?  Not in same family (if sameFamily not permitted)
      if (omess!==false) continue ;    // shouldn't happen, but might if okFamily has changed

      let loanOwed=useThisEntry1['assets'][aname]['loanOwed'];
      astuff['loanOwed']=loanOwed ;

      addARowPortfolioAssetMix(1,astuff,1,makeThisDate) ;   //  buildPortfolioMenu: pre populating (wll also highlight the appropriate asset-button

   }

   buildPortfolioMenu_priceUpdate(1,useThisEntry1['assets'],makeThisDate)  ; // update asset prices with info from "entry being changed" --

//   portfolioCalcValueMenu also sets fields on menu
   portfolioCalcValueMenu_sortUpdate(useThisEntry1);   // update sorting fields
   wsurvey.sortTable.init('portfolioHistory1AssetRows',{'startRow':2,'headerRow':1}); // enable sorting

   return 1 ;
}



//==============
// build a "portfolio specification" menu -- chagne an existing modification entry.
// newdate matches an existing modification 

function buildPortfolioMenu_modChange(grownEntry,newDate ) {

   let pname,gotUse;

   pname=grownEntry['name'];
   let zz=portfolioLookup['list'][pname];

   let nHistory=zz['nHistory'];
   let adesc=portfolioList[iz]['desc'];

   let ithBase,growThisDate,growThisDateSay,makeThisDate,makeThisDateSay;

   let jyear,jday,jmonth ;

   ithBase=grownEntry['baseEntry']['ith'];
   grownDate=grownEntry['baseEntry']['dateStamp'];
   let oof3=setEntryDate(grownDate);
   grownDateSay=oof3['sayDate'];

   makeThisDate=newDate;
   let oof4=setEntryDate(makeThisDate);
   let jYear=oof4['year'],jMonth=oof4['month'],jDay=oof4['day'];
//   alert([jYear,jMonth,jDay]);
   makeThisDateSay=oof4['sayDate'] ;

   let amess='';

// three divs are created and displayed :     portfolioHistory1   portfolioHistory_bar1  portfolioHistory_footer

//  1) portfolioHistory1:  the main container --  portfolioHistory1Head ,    portfolioHistory1AssetHeaderDiv ,portfolioHistory1AssetRows_div

   amess+='<div style="border:1px solid gray" id="portfolioHistory1"     >';

   amess+='<table  border="1" id="portfolioHistory1Head" width="98%"   class="cportfolioTable">';

// top row (with add save ? buttons... and creation date )
   amess+='<tr class="headerRowInit">';

// navigation, submit, and help button cell

    amess+='<td width="15%" >';
    amess+='<button title="Return to modificationDate specification" data-name="'+pname+'" onClick="showPortfolioViewModify(this,1)">&#8656;</button>  ';
    amess+='<input type="button" value="&neArr;" title="View in a new window"  data-id="mainDiv" onClick="displayInWindow(this)"> ';
    amess+=' <button class="csaveButton"  id="idoModifyPortfolioReview" data-name="'+pname+'" title="Review the modifications to the portfolios history (changes to its asset mix)" data-name="'+pname+'" onClick="reviewPortfolioMod(this)">Review</button>';
    amess+=' <button title="Tips" onClick="displayHelpMessage(this)" data-div="#portfolioHistoryHelp1">&#10068;</button>';
    amess+='</td>';

// portfolio name and short descirpiton cell

    amess+='<td width="14%"> '
    amess+='<span     class="portfolioNameSay"><em>portfolio: '+pname+'</em></span> ';
    amess+='<span title="Short description"   class="cdescNoteBuildPortfolio"> '+adesc+'</span> ';
    amess+='</td>';

// budget cell

    amess+='<td width="22%"   > '

    let totNet0=grownEntry['totNetValue'];
    amess+='<span style="font-size:110%;font-weight:600" data-value="'+totNet0+'" name="totNet_value"  ';
    amess+='  title="Before modifications: the after tax, and after loan payoffs, value of the asset-mix (including `Cash`)">Portfolio netValue: ';
    let sayNetValue=wsurvey.addComma(parseInt(totNet0));
    amess+=sayNetValue;
    amess+='<span class="cdescNoteLittle" name="portfolioTotValue_note1" title="gross value (pre-tax,pre loan payoffs)">';
    let sayGrossValue=wsurvey.makeNumberK(grownEntry['totals']['totAssetSale'],5000) ;
    amess+=' &nbsp; ['+sayGrossValue+'] ';
    amess+='</span>';
    amess+='</span>';

     let origBudget=portfolioInit[pname]['original']['budget'];
     let origBudgetSay=wsurvey.addComma(parseInt(origBudget) ) ;
     amess+='<span class="cdescNoteLittle" style="float:right;margin-right:0.5em" data-budget="'+origBudget+'" name="original_budget" title="original budget (specified when portfolio was created)">'+origBudgetSay+'</span>';
     amess+='</td>';

// dates (initialization, modificatoin, priorentry..) cell

    amess+='<td width="45%"   style="border-right:0px dotted blue;text-align:right"> ' ;
    amess+='<span style="color:#a66529;margin-right:1em">Changing a modification on: <tt>'+makeThisDateSay+'</tt></span>  ';

    amess+='<input type="hidden"    name="portfolioDateYear" size="3"  value="'+jYear+'" >   ';
    amess+='<input type="hidden"      name="portfolioDateMonth" size="3"   value="'+jMonth+'" > ';
    amess+='<input type="hidden"       name="portfolioDateDay" size="4" t   value="'+jDay+'" >';

   if (ithBase==0) {             // growing the initial entry
       amess+=' <span  title="dayCount: '+grownDate+'" class="cdescNoteLittle" style="float:right;margin-right:2em"> Changing a modification (after growing the <u>initial</u> asset mix (<tt>'+grownDateSay+'</tt>)</span> ';
   } else {                     // growing a modification entry
       amess+=' <span title="dayCount: '+grownDate+'" class="cdescNoteLittle" style="float:right;margin-right:2em"> Changing a <u>modification</u> asset mix (after growing <tt>'+grownDateSay+'</tt>)</span> ';
   }
   amess+='</td>';
  amess+='</tr>';
  amess+='</table>';


// list of  buttons .. for all existing assets... with highlighting of assets currently in the portfolio's asset-mix

  amess+='<div id="portfolioHistory1AssetHeaderDiv" style="max-height:7em;overflow:auto;">';
  amess+='<table  border="1" id="portfolioHistory1AssetHeader" width="98%"   class="cportfolioTable">';

  amess+='<tr bgcolor="#edf6f6" id="portfolioHistoryAssetList"   >';
  amess+='<td width="15%" ><span style="background-color:#daf7f9;padding;3px">&hellip;add an asset &hellip; ';
  amess+='<button style="color:blue" onclick="buildPortfolioMenu_sortAsset(this)" title="sort the asset list -- order of creation, alphabetical, by type " data-how="0"> &#10143;</button>';
  amess+='</span>';

  amess+=' </td>';
  amess+='<td width="83%" >';
  amess+='<ul class="linearMenu18Pct" name="portfolioTable_assetButtons" title="Available assets ...   ">   ';
  amess+='<li data-type="-1" data-name="Cash" data-orig="0"  data-init="1">  ';       // -1:cash

  amess+='<span  title="The remaining cash (or, if negative, additional required cash) after allocation of the budget to selected assets">Cash &#65284;</span>';

// the "add this asset to the mix" buttons
  let ifoo=0;
  for (let casset in assetLookup) {
      let assetType=doAssetLookup(casset,'assetType',2);;
      let assetSay=getAssetType(assetType,'say');
      let nHistory=doAssetLookup(casset,'nHistory',2)  ;
      ifoo++;
      amess+='<li data-type="'+assetType+'" data-name="'+casset+'" data-orig="'+ifoo+'" data-nhistory="'+nHistory+'" >';
      if (nHistory==0)  {  // no history entries -- hence not price, et c
         amess+='<span style="opacity:0.5" title="This asset has not  been initialized (there is no price, etc.)"> ';
         amess+=casset+'</span>';
      } else {

         let adesc=doAssetLookup(casset,'desc');
         amess+='<label  title="Description: '+adesc+'"> ';

         amess+='<button value="'+casset+'" data-type="'+assetType+'"  data-chosen="0"   title="click to add this asset"   ';
         amess+='   data-name="'+casset+'" name="portfolioTable_assetButtons_1"  onClick="portfolioAddAssetNew(this)" > ';   // buildPortfolioMenu_modAdd
         amess+= casset+'</button>';
         amess+='<span  >'+assetSay+'</span> </label>';

// these infoettes (next to the add this asset button) are populated by calls to buildPortfolioMenu_priceUpdate (below)
         if (assetType==0 ) {
            amess+='<span name="assetValue_now" data-type="0" data-name="'+casset+'" data-value="" title="Per share price: as of '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==3 ) {
            amess+='<span name="assetValue_now"  data-type="3"  data-value=""   data-name="'+casset+'" title="Property price:  as of  '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==4 ) {
            amess+='<span name="assetValue_now"  data-type="4"  data-value=""   data-name="'+casset+'" title="Yearly income:  as of  '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }

         amess+='</span>';
      }
  }          // add asset buttons

  amess+='</ul>';
  amess+='</td> ';
  amess+='</tr>';        // clickable list of assets
  amess+='</table>';     //portfolioHistory1AssetHeader
  amess+='</div>';      // portfolioHistory1AssetHeaderDiv

// column names

  amess+='<div id=portfolioHistory1AssetRows_div" class="cportfolioHistory1AssetRowsDiv">';
  amess+='<table  border="1" id="portfolioHistory1AssetRows" width="99%"   class="cportfolioTable">';

   amess+='<tr class="headerRow">';
   amess+='<td  width="1%"  ><input type="button" style="font-family:oblique" value="Reset" title="reset values " onClick="growPortfolio_reset(this)">';

   amess+='<input type="hidden" name="baseEntry_ith" value="'+grownEntry['baseEntry']['ith']+'">';
   amess+='<input type="hidden" name="baseEntry_closestDate" value="'+ grownEntry['baseEntry']['dateStamp']+'">';

  amess+='</td>';
  amess+='<th  width="14%" ><span  title="Name of an existing asset">';
  amess+='<button style="margin-bottom:5px" title="Tips on adding assets" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueAddAsset">&#10068;</button>';

  amess+='<b>Name</b></span>';
  amess+='</th>';
  amess+='<th width="36%"> <span title="Allocation to this asset --. As #shares, $ amount, or % of budget">Allocations (# shares or $, etc.)</span></th>';
  amess+='<td  width="35%">  ';

// these fields are filled by addARowPortfolioAssetMix_assetSummary
  amess+='<div name="allocationHeader_allocation" class="cAllocationHeader" style="display:none"> ';
    amess+='<u>Current</u>: <span  title="Cost (to obtain asset), and pct of total cost" class="cmyCost_span">Cost</span>';
    amess+=' <span  title="Gross (pre-tax, pre loan payback) value, and pct of total value " class="cmyValue_span">Value</span>';
    amess+=' <span  title="Net (after-tax, after loan payback) value, and pct of total net value " class="cmyNetValue_span">netValue</span>';
    amess+=' <span  title="Net revenue (such as rents - mortgagePayments). Can be negative " class="cmyNetRevenue_span">netRevenue</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_info" style="overflow-wrap: break-word;overflow:auto;white-space:normal;" class="cAllocationHeader"  style="display:none"> ';
    amess+='<span title="Information for each asset, as of the current modification (or creation) date" class="cmyValue_span">Info (yearly):  dividends, interest rate, income, &hellip;</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_base"  class="cAllocationHeader"  style="display:none"> ';
    amess+='<u>preGrowth</u>: ';
    amess+='<span  title="Cost (to obtain asset), and pct of total cost" class="cmyCost_span">Cost</span>';
    amess+=' <span  title="Gross (pre-tax, pre loan payback) value, and pct of total value " class="cmyValue_span">Value</span>';
    amess+=' <span  title="Net (after-tax, after loan payback) value, and pct of total net value " class="cmyNetValue_span">netValue</span>';
    amess+=' <span  title="Share price, or loan amount owed" class="cmyNetRevenue_span">Price or loan</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_changes"  class="cAllocationHeader"  style="display:none"> ';
// filled by buildPortfolioMenu_showChanges
  amess+='</div>'
  amess+='</td>';

  amess+='<th  width="10%"> <span title="Comment">Comment</span></th>';
  amess+='</tr>';

//end of header and help rows

// the cash row

   amess+='<tr class="portfolioHistoryRowCash"  >';
   amess+='<td title="sort by: asset type">&hellip;</td>';
   amess+='<td title="sort by: asset name"><u>Cash</u> </td>';
   amess+='<td title="sort by: gross (pre-tax) value" >';
   let cbalance=grownEntry['cashAsset'];
   let cbalanceSay=  wsurvey.addComma(parseInt(cbalance)) ;
   amess+=' <input readonly style="opacity:0.6;color:blue" type="text" name="portfolioCashRemain" size="9" value="'+cbalanceSay+'" data-value="'+cbalance+'"  ';
   amess+=' title="`Cash` -- remaining cash. If negative, additional cash required  to obtain asset mix\n  ';
   amess+=        ' Includes `Cash`from initial (or modification) portfolio... plus accumulated taxes, revenues, and payments ... and interest growth on this `Cash`!\n You can not manually specify this value!"  size="4"     >';
   amess+=' <button  data-name="'+pname+'" title="Allocate remaining cash to first empty asset" onClick="allocateCashToEmpty(this,1)">&#1769;</button> ';
   amess+='<span style="padding:1px 3px;color:green;background-color:#e9e8c8" title="Accumulated `Cash` (since portfolio creation, or last modifcation) -- NOT adjusted for interest growth ">';

  let cashAcc=grownEntry['changesGrow']['cashAssetChangeGrow'];
  let cc1=wsurvey.addComma(parseInt(cashAcc));
  amess+='&#120491;<u>Cash</u>= <tt>'+cc1+'<tt>' ;
   amess+='</span>'
   amess+='</td>';

   amess+='<td title="sort by: net (after tax) value">';
   amess+='<span class="cgrossValue"  ><tt>  &hellip;</tt></span>  ';
   amess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#buildPortfolioMenu_others1">&#10068;</button>';
     amess+='<input type="button" value="&#128712;" title="Display prices, etc. ... as of the modification date" onClick="buildPortfolioMenu_priceUpdate(-1)" >';  // use most recently computed prices
     amess+='<input type="button" value="&#9918;" title="Show current asset allocation  (before modification)  " onClick="buildPortfolioMenu_showBase(this)" >';
  amess+='<input type="button" value="&#8710;" title="Show changes due to growth (before modification) asset allocation " onClick="buildPortfolioMenu_showChanges(this)" >';
   amess+='</td>';

   amess+='<td  title="sort by: fraction of portfolio in this asset"><input type="hidden" name="portfolioComment" value="Cash remaining (or required) ">';
   amess+='<input type="text" disabled size="35"  value="remaining, or (if negative) required, cash"></td>';
   amess+='</tr>'

  amess+='</table>'; //portfolioHistory1AssetRows
  amess+='</div> ' ;   //portfolioHistory1AssetRows_div

// calcluate portfolio value results, display resuilts
  amess+='</div>';

  amess+='<div id="portfolioHistory_bar1" style="background-color:brown;margin:3px 30% 3px 30%;height:0.1em">&nbsp;</div>' ;

  amess+='<div id="portfolioHistory_footer" style="border:2px solid gold" width="99%">';

  amess+='<div name="portfolioHistory_comment" title="optional comment" style="display:none;background-color:#d7f8fb;margin:3px 10% 3px 10%;padding:1px 3px 1px 18px" >'  ;
  amess+='Comment (optional): <input type="text" size="80" name="portfolioHistory_commentInput"> ';
  amess+='</div> '  ; //portfolioHistory_comment

  amess+='<table style="border:2px solid gold" width="99%">';
  amess+='<tr>';
  amess+='<td valign="top" width="10%">';
  amess+='<button id="icalcPortfolioValue_init"  style="margin-bottom:5px" title="Tips" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueHelpInit1">&#10068;</button>';
  amess+='<button id="icalcPortfolioValue_mod"  style="display:none;margin-bottom:5px" title="Tips" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueHelp1">&#10068;</button>';
  amess+='<br>';

  amess+='<br>';
  amess+='<button id="calcPValueModifyButton"  class="calcButton" title="What are the values of this modified asset mix\n... as of the specified modification date" data-name="'+pname+'" onClick="portfolioCalcValueMenu_modify(this)">Calculate modified value</button> ';  // in buildPortfolio

  amess+='</td>';
  amess+='<td valign="top" width="20%">';
  amess+='<div id="assetHistory_currentSummary" title="Summary of current portfolio "  class="cassetHistory_currentSummary"  > </span>';
  amess+='</td>';
  amess+='<td valign="top" width="25%">';

// this is filled by portfolioCalcValueMenu_modify

  amess+='<div id="assetHistory_modifiedSummary"  class="cassetHistory_modifiedSummary"  ';
  amess+='   title="Summary of proposed modifications "> </div>';
  amess+='</td>';
  amess+='<td valign="top" width="40%">';
  amess+='<div id="assetHistory_currentSummaryNote" class="cassetHistory_currentSummaryNote"  > </div>';
  amess+='</td>';
  amess+='</tr>';
  amess+='</table>';

  amess+='</div>';

  $('#mainDiv3').html(amess);

 wsurvey.wsShow.show('#mainDiv3','show');

  $('#icalcPortfolioValue_init').hide();
   let oink1=$('#icalcPortfolioValue_mod')
   oink1.show();

// pre populate with existing shares ,etc  .. first do price updating
   if (!portfolioModifications[pname]['list'].hasOwnProperty(makeThisDate)) {
       alert('Error in buildPortfolioMenu_modChange: no modification with date of '+makeThisDate);
       return false;
   }

   useThisEntry1=portfolioModifications[pname]['list'][makeThisDate]   ;      // use the asset list specified in the modification on this date
   let useThisList=useThisEntry1['assetList'];

  buildPortfolioMenu_priceUpdate(2,useThisEntry1['assets'],makeThisDate)  ; // calculate all current asset values, with info from "entry to be mmodified"

   for (let i1=0;i1<useThisList.length;i1++) {         // prepopulate ... perhaps with "to be changed modEntry" assets
      let astuff=useThisList[i1];
      let aname=astuff['name'];

      let omess=portfolio_checkAssetAdded(aname);    // buildPortfolioMenu: asset exists? Not alredy in portfolio?  Not in same family (if sameFamily not permitted)
      if (omess!==false) continue ;    // shouldn't happen, but might if okFamily has changed

      let loanOwed=useThisEntry1['assets'][aname]['loanOwed'];
      astuff['loanOwed']=loanOwed ;

      addARowPortfolioAssetMix(1,astuff,1,makeThisDate) ;   //  buildPortfolioMenu: pre populating (wll also highlight the appropriate asset-button

   }

  buildPortfolioMenu_priceUpdate(1,useThisEntry1['assets'],makeThisDate)  ; // if new assets added, need to call this again

//   portfolioCalcValueMenu also sets fields on menu
   portfolioCalcValueMenu_sortUpdate(useThisEntry1);   // update sorting fields
   wsurvey.sortTable.init('portfolioHistory1AssetRows',{'startRow':2,'headerRow':1}); // enable sorting

   return 1 ;
}



//=========================        abudget  useEntry
// date was changed (on portfolio init)
// athis not  used
function buildPortfolioMenu_date(athis) {
  buildPortfolioMenu_priceUpdate(0)  ;
  let eu=$('#updatedCreationDate');
  eu.show();
  window.setTimeout(function() {
     eu.fadeOut(1500);
  },200);
}

//===========================
// update prices etc display -- next to "select this asset" buttons
// and in the 4th col of "specify portofolio assets" table (available for init  and mod)
// useExist:
//  -1 use most recently computed values of assetValuesCurrent
// 0  : use date specifeid in date field
// 1  : use jdateSTemp as date
// useEntrY
// not specified if useExist=0 or -1
//   otherwise: the entry containing info on income startDates (in the 'assets') -- so xx['assets']['zname'] assetType and incomeStart must exit
// jdateStamp: the date to update to (onluy uised if useExist = 1

function buildPortfolioMenu_priceUpdate(useExist,useEntry,jDateStamp) {

  let noFixed=0;
   if (arguments.length<2)   noFixed=1;     // incomes treated as variable if no useENtry (useEntry contains incomeStart info)

 let etable=$('#portfolioHistory1');
  let assetValuesCurrentUse;
 if (arguments.length<3) {
    let arf=getCreationDate(1);
    jDateStamp=arf['dayCount'];
 }

  if (useExist===-1) {      // special case: don't create (use existing value).... used on button click in modification menu
     assetValuesCurrentUse=assetValuesCurrent  ; // use current clogal
 

 } else {                // for all available assets (those with an "add this asset" button in the portoflioTable header..)
      let egots=etable.find('[name="portfolioTable_assetButtons_1"]');
      assetValuesCurrentUse={};

// calcluate   asset values (given jDateStampe as date) -- NOT necessariy accounting for fixed growth (since these are not necessarily in the portfolio)

      for (zname in assetLookup) {
        if (assetLookup[zname]['nHistory']==0) continue ; // not initialized
        if (assetLookup[zname]['firstHistoryDate']>jDateStamp) {
            let oof1=setEntryDate(assetLookup[zname]['firstHistoryDate']);
            let oof2=setEntryDate(jDateStamp);
            displayStatusMessage('<tt>'+zname+'</tt> : first entry ('+oof1.sayDate+') is after a target date: '+oof2.sayDate,2);
            continue ; // not yet specified (in time)
        }

        if (noFixed==1) {

           let yuba= calcAssetValues_2(zname,jDateStamp) ;   // doesn't use starTdate
           if (yuba===false) return false ;  // some kind of error
           assetValuesCurrentUse[zname]=yuba;
        } else {
           if (useEntry.hasOwnProperty(zname)) {
               let daEntry=useEntry[zname]
               let incomeStart=(daEntry.hasOwnProperty('incomeStart')) ? daEntry['incomeStart'] : false;

               assetValuesCurrentUse[zname]= calcAssetValues_2(zname,jDateStamp,1,incomeStart) ;
               let loanPayYear=  useEntry[zname]['loanPayYearly']   ;
               assetValuesCurrentUse[zname][4]['loanPayYearly']=useEntry[zname]['loanPayYearly'];
               assetValuesCurrentUse[zname][4]['loanAmount']= (useEntry[zname]['loanSchedule']) ? useEntry[zname]['loanSchedule']['amount'] : 0  ;
           } else {
               assetValuesCurrentUse[zname]= calcAssetValues_2(zname,jDateStamp,1,false) ;   // daentry should containt 'assetType' and 'incomeStart' properties
           }
        }
    }
    assetValuesCurrent=assetValuesCurrentUse ;          // set the global

  }  // useExist


// write info to price field next to buttons

  let edo=etable.find('[name="assetValue_now"]');


  for (let ie=0;ie<edo.length;ie++) {
     ado=$(edo[ie]);
     let aname=ado.attr('data-name');
     let atype=ado.attr('data-type');
     let dval=assetValuesCurrent[aname] ;


     let vval,vvalsay;
     if (atype=='0') {
         vval=dval[4]['price'];
         vvalsay=vval.toFixed(1) ;
     }
     if (atype=='3') {
        vval=dval[4]['salePrice']  ;
        vvalsay=wsurvey.makeNumberK(vval,10000)  ;
     }
     if (atype=='4'){          // note that this the "starting" fixed income

         vval=dval[4]['income']  ;
         vvalsay=wsurvey.makeNumberK(vval,10000)  ;
     }

     ado.html(vvalsay);
     ado.attr('data-value',vval);

  }

// update info fields (last colum) for each asset row

  let eins=etable.find('[name="portfolioAsset"]');

  for (let ii=0;ii<eins.length;ii++) {
     let ein=$(eins[ii]);
     let aname=ein.attr('data-orig');
     let etr=ein.closest('.portfolioHistoryRow');
     let esummary=etr.find('.cportfolioTable1_summaryCell');
     let  tbdSay=portfolioAssets_currentInfo(aname);
     esummary.html(tbdSay);
  }

// show the appropriate header
  let daheaders=etable.find('.cAllocationHeader');
  daheaders.hide();
  let da1=etable.find('[name="allocationHeader_info"]');
  da1.show();

}

//=================================     useEntr    athis
// display asset specific "changes" (after a change)
function buildPortfolioMenu_showChanges(athis) {

  let achanges= entryWorking['changesGrow']['list'] ;

  let etable=$('#portfolioHistory1');
  let eins=etable.find('[name="portfolioAsset"]');
  let growDays=entryWorking['growDays'];

  for (let ii=0;ii<eins.length;ii++) {
     let ein=$(eins[ii]);
     let aname=ein.attr('data-orig');
     let atype=getAssetType(aname);
     let achange1=(achanges.hasOwnProperty(aname)) ? achanges[aname] : {} ;

     let amess='';
     if (atype==0 ) {
          amess+='<span class="cshowChanges" title="Change in # shares">';
          if (achange1.hasOwnProperty('dq')) amess+=   ' dQ=<tt>'+achange1['dq'].toFixed(1)+'</tt>' ;
          amess+='</span>';
          amess+='<span class="cshowChanges" title="After tax earnings -- it is used to buy additional shares">';
          if (achange1.hasOwnProperty('earningsAT')) amess+=   '&nbsp;&nbsp; using earnings= <tt>'+achange1['earningsAT'].toFixed(1)+'</tt> ';
          if (achange1.hasOwnProperty('taxEarnings')) amess+='  (<span style="font-size:85%" title="Tax paid">tax:<tt> '+achange1['taxEarnings'].toFixed(0)+'</tt></span>) ';
          amess+='</span> ';

     } else if (atype==1) {
          amess+='<span class="cshowChanges" title="Change in after-tax earnings  -- it is reinvested ">';
          if (achange1.hasOwnProperty('earningsAT')) amess+=   ' Earnings= <tt>'+achange1['earningsAT'].toFixed(0)+'</tt> ';
          if (achange1.hasOwnProperty('taxEarnings')) amess+='  (<span style="font-size:85%" title="Tax paid">tax: <tt>'+achange1['taxEarnings'].toFixed(0)+'</tt>  </span>) ';
          if (achange1.hasOwnProperty('additions')) amess+='  (<span style="font-size:85%" title="Additions">additions: <tt>'+achange1['additions'].toFixed(0)+'</tt>  </span>) ';
          amess+='</span> ';
     } else if (atype==2) {
          amess+='<span class="cshowChanges" title="Change in after-tax earnings -- it is reinvested">';
          if (achange1.hasOwnProperty('earningsAT')) amess+=   ' Earnings= <tt>'+achange1['earningsAT'].toFixed(0)+'</tt> ';
          if (achange1.hasOwnProperty('additions')) amess+='  (<span style="font-size:85%" title="Additions">additions: <tt>'+achange1['additions'].toFixed(0)+'</tt>  </span>) ';
          amess+='</span> ';

     } else if (atype==3) {

          amess+='<span class="cshowChanges" title="Change in after-tax earnings   -- it is added to `Cash` ">';
          if (achange1.hasOwnProperty('earningsAT'))  amess+=   ' Earnings= <tt>'+achange1['earningsAT'].toFixed(1)+'</tt> ';
          if (achange1.hasOwnProperty('taxEarnings'))  amess+='  (<span style="font-size:85%" title="Tax paid">tax: <tt>'+achange1['taxEarnings'].toFixed(0)+'</tt>  </span>) ';
          amess+='</span> ';
           amess+='&nbsp;&nbsp;&nbsp; [<span class="cshowChanges" title="Loan payments (after tax)">';
          if (achange1.hasOwnProperty('loanPaidPeriodAT')) amess+=   ' loanPaid= <tt>'+achange1['loanPaidPeriodAT'].toFixed(0)+'</tt>' ;
          amess+='</span>]';


     } else if (atype==4) {
          amess+='<span class="cshowChanges" title="Income received (after tax) -- it is added to `Cash` ">';
          if (achange1.hasOwnProperty('earningsAT'))  amess+=   ' Earnings= <tt>'+achange1['earningsAT'].toFixed(0)+'</tt> ';
          if (achange1.hasOwnProperty('taxEarnings'))  amess+='  (<span style="font-size:85%" title="Tax paid">tax: <tt>'+achange1['taxEarnings'].toFixed(0)+'</tt>  </span>) ';
          amess+='</span> ';

     }
     let etr=ein.closest('.portfolioHistoryRow');
     let esummary=etr.find('.cportfolioTable1_summaryCell');
     esummary.html(amess);
  }

// show the appropriate header
  let daheaders=etable.find('.cAllocationHeader');
  daheaders.hide();
  let amess2='';
   amess2+='Earnings, and loan payments, in last '+growDays+' day ';

  let da1=etable.find('[name="allocationHeader_changes"]');
  da1.html(amess2);
  da1.show();
  return 1;

}

//=======================
// info on "base" (pre growth) of a modification
function buildPortfolioMenu_showBase(athis) {

  let etable=$('#portfolioHistory1');
  let eins=etable.find('[name="portfolioAsset"]');
  let growDays=entryWorking['growDays'];
 
  for (let ii=0;ii<eins.length;ii++) {
     let ein=$(eins[ii]);
     let aname=ein.attr('data-orig');
     let atype=getAssetType(aname);
     let avals= (entryWorking['changesGrow']['priorEntryVals'].hasOwnProperty(aname)) ? entryWorking['changesGrow']['priorEntryVals'][aname]  : false  ;

     let amess='';
     if (avals!==false) {
       amess+='<span  title="Estimated cost (to obtain asset) " class="cmyCost_span">'+avals['cost'].toFixed(0) +'</span>';
       amess+=' <span  title="Gross (pre-tax, pre loan payback) value  " class="cmyValue_span">'+avals['value'].toFixed(0) +'</span>';
       amess+=' <span  title="Net (after-tax, after loan payback) value " class="cmyNetValue_span">'+avals['netValue'].toFixed(0) +'</span>';
       if (atype==3) amess+=' <span  title="Loan amount owed   " class="cmyNetRevenue_span">loanOwed: '+avals['loadOwed'].toFixed(0)   +'</span>';
       if (atype==0) amess+=' <span  title="Share price " class="cmyNetRevenue_span">price: '+avals['price'].toFixed(2)   +'</span>';
     }
     let etr=ein.closest('.portfolioHistoryRow');
     let esummary=etr.find('.cportfolioTable1_summaryCell');
     esummary.html(amess);

  }

// show the appropriate header
  let daheaders=etable.find('.cAllocationHeader');
  daheaders.hide();

  let da1=etable.find('[name="allocationHeader_base"]');
  da1.show();
  return 1;

}


//====================
// sort the list of assets buttons (above the asset-mix table)
// ihow: 0=order of appearanc, 1=name, 2=type/name
function buildPortfolioMenu_sortAsset(athis) {
  let ethis=wsurvey.argJquery(athis) ;
  let isort=ethis.attr('data-how');
   let doSort=parseInt(isort)+1;
   if (doSort>2) doSort=0;
    ethis.attr('data-how',doSort);

  let etable=$('#portfolioHistory1');
  let elist=etable.find('[name="portfolioTable_assetButtons"]');
  let elis=elist.find("li");

  let alist=[];
  let newlist=[];
  newlist[0]=0   ; // Cash is always first
  let notUseList=[];
  for (let jli=0;jli<elis.length;jli++) {
      let eliA=$(elis[jli]);
      let isInit=eliA.attr('data-init');
      if (isInit==0   ) {   // not initialzd,
         notUseList.push(jli);
         continue ;
      }
      let atype=parseFloat(eliA.attr('data-type'));
      if (atype<0) continue         // cash ;
      let aorig=parseInt(eliA.attr('data-orig'));
      let aname=eliA.attr('data-name');
      let foo;
      if (doSort==1) {     // by name
         foo=[aname,0,jli];
      } else if (doSort==2) {   // type/name
         foo=[atype,aname,jli];
      } else {
         foo=[aorig,0,jli];
      }
      alist.push(foo)
  }
  alist.sort(buildPortfolioMenu_sortAsset_sort);

  for (let ia=0;ia<alist.length;ia++)  newlist.push(alist[ia][2]);
  for (let ib=0;ib<notUseList.length;ib++)  newlist.push(notUseList[ib] ) ;

  for (let ic=0;ic<newlist.length;ic++) {
      let jj=newlist[ic];
      elist.append(elis[jj]);
  }


}

//=====
// sort an array of arrays (using first array elment, and 2nd if firsts match)
// do NOT assume numeric (lexigraphic sort)
function buildPortfolioMenu_sortAsset_sort(a,b) {
 let a1=a[0]; let b1=b[0];
 if (a1==b1) {         // use secondary sort
    let a2=a[1], b2=b[1];
    if (a2==b2) return 0;
    if (a2>b2) return 1 ;
    return -1;
 }
 if (a1>b1) return  1 ;
 return -1;
}
