6 August 2023. simInv 1.5 -- creating simInv publicAssets

Introduction 

    simInv's "publicAssets" are assets (stocks, bonds, and tax deferred bonds) that are "public" -- they are available on the market.
    simInv users can add one, or many, public assets to the mix of assets available. Where "available" means "can be added to a portfolio".

    publicAssets are specified by .txt files in the publicAssets/inputData directory of simInv. They have a fairly simple format.

    simInv comes with a number  of these .txt files, as well as the simInv accesssible version (in publicAssets/assetsUse.js).
   And it is not hard to add more !
  
Adding public assets

        As of  ver 1.5, public assets can only be added when running in onLine mode. 
        AND -- you must have access to the server simInv is installed on.

  Assuming the above ...

  
     i)  add one (or more) properly formatted .txt files to publicAssets/inputData  -- see below for the details!

    2)  delete  publicAssets/assetsUse.js

    3)  load simInv. For eample: load http://path.to.simInv/index.html
  
    4)  An error message is dislayed: "Note: publicAssets have not been initialized. See readme.txt for details "
         
    5)  Click the "Public" icon

    6)  Click the "intialized the publcAssets list" button

   7)  Click the 'Save' button
  
   8)  Reload simInv

   That's it! The newly added publicAssets will be available (a new versuib of publicAssets/assetsUse.js is created).

   Note that if there are specification errors in any of the publicAssets .txt files, an error message is displayed -- and 
  publicAssets/assetsUse.js will not be created.


Format of publicAsset .txt files

    headerVar: headerValue
    headerVar: headerValue

    dataLine_csv
    dataLine_csv

Note the empty line between the headerVar:headerValue section  and dataLine_csv section!

Permissible 'header' values (case insensitive), and permissible 'headerValue' values:

  name:  (required). The  name of the asset.
       headerValue MUST BE ONE WORD. No embedded spaces,and no odd characters.
 type: (required).  The type of the asset 
       headerValue must be one of : 0 ,1, or 2. Where 0=stock, 1=bond, and 2=tax deferred bond 
 freq (required). Frequency of specification
      headerValue must be one of: year, month, day.  See below for how this is used
  desc:  (optional) short description of the asset.
        Html will be removed.
  desclong: (optional)  longer description of the asset
        Html will be removed. 
   
DataLines are csv (comma seperated values). Each dataLine specifies the asset at a given date.
Each line starts with "date" values, and ends with "attribute" values

How you specify the date depends on the 'freq' header.
     year: specify a year the first value in the csv).
	Example: 2021 means "Jan 1, 2021"
     month: specify a year and month (first, and secondd values in the csv)
                Example: 2019,9  means "August 1, 2019"
     day : specify a year, a month, and a day (first, second, and third values in the csv)
                Example: 2022,12,7  means "December 7, 2022"
 
The attributes depend on the "type".

   0 (stocks):  price, and "yearly dividend rate". 
           Price is the first value after the date value(s), and dividend is second.
	   Dividend should be written as a percent. Example: 3.2 means "3.2%"
	   The price is the sale (or purchase) price on that date.
	   The dividend should be a yearly rate. Typically a "average of the preceding 12 months"   is used.

   1 (bonds) or 2 (tax-deferred bonds):   interest rate.
           Interest should be written as a percent. Example: 2.42 means "2.24%"
	   The interest should be a yearly rate. Typically a "average of the preceding 12 months"   is used.

Notes:
  * entries can be in any date order simInvl will sort them)
  * how many dates you specify is flexible -- simInv uses interpolation to compute values between
    specified dates.
    Thus: the "freq" header only specifies how the date values are specified!
 * simInv  will note if the date, or attributes, specifications have errors


Example  of a stock .txt file (mote that extraneous spaces are removed)

  name: Apple
  type: 0
  freq: year
  desc: Apple stock

   2013 , 14.42, 0.24
   2014 , 16.18 ,0.38
   2015 , 27.02, 0.42
   2016 , 22.15, 0.47
   2017 , 31.02  , 0.53
   2018 , 37.22 , 0.60
   2019 , 41.17 ,0.70
   2020 , 78.34 ,0.75
   2021 , 134.95, 0.82
   2022 , 171.12 , 0.87
   2023 , 172.56, 0.93

Example of a stock file (with monthly freq)

   name: SPY
   desc: SPDR S&P 500 ETF Trust
   desclong: note use of biannual values
   type: 0
   freq: month

   2023,	6,	443.02,	6.552
   2022,	12,	385.18,	7.12
   2022,	6,	365.51,	6.28
   2021,	12,	461.55,	6.52
   2021,	6,	417.09,	5.48
   2020,	12,	370.97,	6.32
   2020,	6,	314.17,	5.44
   2019,	12,	320.46,	6.24
   2019,	6,	294.13,	5.72
   2018,	12,	246.74,	5.72
   2018,	6,	276.6,	4.96
   2017,	12,	265.45,	5.4
   2017,	6,	242.77,	4.72
   2016,	12,	226.01,	5.28
   2016,	6,	207.17,	4.28
   2015,	12,	202.77,	4.84
   2015,	6,	211.46,	4.12
   2014,	12,	206.43,	4.52
   2014,	6,	196.03,	3.72
   2013,	12,	180.67,	3.92



Example of a tax deferred bond .txt file

   name: tsp_g
   type: 2
   freq: year
   desc: TSP G fund

   2023, 3.76
   2022, 2.98
   2021, 1.38
   2020, 0.97
   2019, 2.24
   2018, 2.91
   2017, 2.33
   2016, 1.82
   2015, 2.04
   2014, 2.31
   2013, 1.89


