<?php

// ============
// php for simInv

session_start() ;
ob_start();

// :::  save / retreive simInv data. This does very little processing -- is just chooses a directory and a file     :::::::::::::::::::::

// add some php functions
$curDir=getcwd();

$todo=$_REQUEST['todo'];

if ($todo=='echoFile') {            // echo file back (used to download to afile
 $fname=$_REQUEST['fname'];
 $content=$_REQUEST['content'];
 header('Content-type: text/plain');
 header("Content-Length: " . strlen($content));
 header('Expires: 0');
 $filename=trim($fname);
 header('Content-Disposition: attachment; filename='. urlencode($fname));
 echo $content;
 exit;
}

// checkUserExists is one of the few requests that does not require an encMd5 ( even a '' one)
// 0: ready, 1:no username speciifed, 2: no such user,3: no settings
if ($todo=='checkUserExists')  { // special case (no encrytption);
    ob_end_clean();   // remove prints and other crap

    if (!array_key_exists('username',$_REQUEST) || trim($_REQUEST['username'])=='' )  {
       $retme=[1,"No username specified"] ;
    } else {
       $auser=$_REQUEST['username'];
       $retme=[0,"Ready: $auser"] ;        // assume it worked
       $daDir=$curDir.'/data/'.$auser;
       if (!is_dir($daDir)) {
          $retme=[2,"No such user (admin must create) :: $auser"] ;
       } else {
          $tryS=$daDir.'/settings.json';
          $gotSettings=file_exists($tryS);
          if (!$gotSettings)  $retme=[3,"Settings not specified for: $auser"] ;
       }
    }
   $vsuggests=json_encode($retme, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;
   exit;
}     // checkuserexists

// --- not checkUserExists

if (!array_key_exists('username',$_REQUEST))  doReturnError("No username specified");   // exits directoly
$auser=$_REQUEST['username'];  // must exist
$daDir=$curDir.'/data/'.$auser;
if (!is_dir($daDir)) {
   doReturnError("No such user: $auser");   // exits directoly
}

//    does not require encryption
if ($todo=='saveDefaultSettings')  {    // initializee user with the default settings (no encryption needed)

   $da1=doSaveSettings($auser,1);      // exits if error
   $keyMd5=$_REQUEST['encMd5'];
   saveEncKey($auser,$keyMd5)  ;      // save md5 of encryption key, for later validation
  ob_end_clean();   // remove prints and other crap
  $amess="Settings saved ";
  if ($keyMd5!='') $amess.=', and md5 of encryption key';
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit ;
}

// for all requests, ....

 if (!array_key_exists('encMd5',$_REQUEST))  doReturnError('No encryption key specified (not even an empty one)','encKey',1);   // exits directoly

$myEncMd5=$_REQUEST['encMd5'] ;  // could be  blank

$savedMd5='';$ahint=0;  // used if no encryption key file
$xxx=readEncKey($auser,$curDir);
if ($xxx!== false) {
  $savedMd5=$xxx['encKeyMd5'];
  $ahint=$xxx['hint'];     // 27july 2023, not used (hint is saved in settings)
}
if ($savedMd5!= $myEncMd5) {   // both are blank is aslso allowed
    if ($savedMd5==='') {
       doReturnError('You do not need an encryption key  ')  ;
    } else {
       $ahint=false;
       $try6=$daDir.'/settings.json';  // see if hint available
       $gotSettings=file_exists($try6);
       if ($gotSettings) {
          $aa=file_get_contents($try6);
          if ($aa!==false) {
             $va=unserialize($aa);
             if (array_key_exists('encryptionKeyHint',$va['list'])) $ahint =$va['list']['encryptionKeyHint'] ;
          }
       }
       $amess='You did not specify the correct encryption key';
       if ($ahint!='') $amess.='<br>Hint: <tt>'.$ahint.'</tt>';
       doReturnError($amess)  ;
    }
}

// "logon" ok (username exists, encryption key matches

// restore everything
if ($todo=='restoreAll')  {

  ob_end_clean();   // remove prints and other crap

  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $saves=[];
  foreach ($_REQUEST['data']['content'] as $avar=>$aval) {
     if ($avar=='keyMd5') continue;
     $awhich=$avar;
     $acontent=$aval;
     $try=$daDir.'/'.$awhich.'.json';
     $aa=['date'=>time(),'content'=>$acontent ];
     $da2=serialize($aa);
      $nn=file_put_contents($try,$da2);
      if ($nn===false)  {
         doReturnError("Could not save: $awhich in: $try ");
     }
     $saves[]=$awhich;
  }
  ob_end_clean();   // remove prints and other crap
  $amess='Restored: '.implode(',',$saves);
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit;
}




// .... return this users simInv data
if ($todo=='getData')  {
  getUserData($auser,$savedMd5);  // getUSErDat exist
  exit;
}

if ($todo=='save') {
    saveDataset($auser,$savedMd5);
    exit;
}


if ($todo=='saveSettings') {
   $auser=$_REQUEST['username'];
   doSaveSettings($auser)  ;
   exit;
}

if ($todo=='saveViewDates') {
  $auser=$_REQUEST['username'];
   doSaveViewDates($auser)  ;
   exit;
}



if ($todo=='exportData') {
  $auser=$_REQUEST['username'];
   doExportData($auser);
   exit;
}

if ($todo=='exportData2') {
  $auser=$_REQUEST['username'];
   doExportData2($auser);
   exit;
}


doReturnError("An unknown action: $todo ");
exit;



//===============
// retrieve this user's siminv data
// these may be encrypted -- decrypted on javascript side
// note that encMd5 check done before calling getUserData

function getUserData($auser,$savedMd5) {
 $rets=['error'=>false,'errorMessage'=>'','messages'=>[],
     'keyMd5'=>$savedMd5,
      'settings'=>['date'=>'','list'=>[]]  ,
      'assets'=>['date'=>'','list'=>[]]  ,
      'assetHistory'=>['date'=>'','list'=>[],'autoAddEntries'=>[] ]  ,
       'portfolios'=>['date'=>'','list'=>[]],
      'portfolioInit'=>['date'=>'','list'=>[]],
      'portfolioModifications'=>['date'=>'','list'=>[]],
      'viewDates'=>['date'=>'','list'=>[]]
      ];

   $messages=[];

   $curDir=getcwd();
   $daDir=$curDir.'/data/'.$auser;

   if (!is_dir($daDir)) {
     doReturnError("No such user directory: $dadir");   // exits directoly
  }

  $try=$daDir.'/assets.json';
  $gotAssets=file_exists($try);
  if ($gotAssets) {
      $aa=file_get_contents($try);
      if ($aa===false) {
         doReturnError("Unable to retrieve assets file: $try ");
      } else {
        $va=unserialize($aa);
        if ($va===false) {
           doReturnError("Problem decoding assets file: $try ")  ;
        } else {
          $dd=date('Y-m-d H:i',$va['date']);
          $rets['messages'][]='Using assets file updated on '.$dd ;
          $rets['assets']=$va;
        }
     }
  } else {
       $rets['messages'][]='No assets file available ';
  }     // gotassets

  // look for assets history file
  $tryH=$daDir.'/assetHistory.json';
  $gotAssetsH=file_exists($tryH);
  if ($gotAssetsH) {
      $aah=file_get_contents($tryH);
      if ($aah===false) {
         doReturnError("Unable to retrieve assets history file: $tryH ");
      } else {
        $vah=unserialize($aah);
        if ($vah===false) {
           doReturnError("Problem decoding assets history : $tryH ")  ;
        } else {
          $dd=date('Y-m-d H:i',$vah['date']);
          $rets['messages'][]='Using assets history file updated on '.$dd ;
          $rets['assetHistory']=$vah;
        }
     }
  } else {
          $rets['messages'][]='No assets history file available ';
  }     // assets history file

// look for portfolios file
  $try3=$daDir.'/portfolios.json';
  $gotportfolios=file_exists($try3);
  if ($gotportfolios) {
      $aa3=file_get_contents($try3);
      if ($aa3===false) {
         doReturnError("Unable to retrieve portfolios file: $try3 ");
      } else {
        $va3=unserialize($aa3);
        if ($va3===false) {
           doReturnError("Problem with portfolios file: $try3 ");
        } else {
          $dd=date('Y-m-d H:i',$va3['date']);
          $rets['messages'][]='Using portfolios file updated on '.$dd ;
          $rets['portfolios']=$va3;
          if (is_null($rets['portfolios']['list'])) $rets['portfolios']['list']=[];

        }
     }
  } else {
     $rets['messages'][]='No portfolios   file available ';
  } // portfolios file



// look for portfolio init file
  $try4a=$daDir.'/portfolioInit.json';
  $gotportfolioInit=file_exists($try4a);
  if ($gotportfolioInit) {
      $aa4a=file_get_contents($try4a);
      if ($aa4a===false) {
         doReturnError("Unable to retrieve portfolio initialization (original assets) file: $try4a ");
      } else {
        $va4a=unserialize($aa4a);
        if ($va4a===false) {
           doReturnError("Problem with portfolio initialization  file: $try4a ");
        } else {
          $rets['messages'][]='Using portfolio initialization file '   ;
          $rets['portfolioInit']=$va4a;
        }
     }
  } else {
     $rets['messages'][]='No portfolios initialization  file available ';
  } // portfolio initialiation file


  // look for portfolio modifications file
  $try4b=$daDir.'/portfolioModifications.json';
  $gotportfolioModifications=file_exists($try4b);
  if ($gotportfolioModifications) {
      $aa4b=file_get_contents($try4b);
      if ($aa4b===false) {
         doReturnError("Unable to retrieve portfolio modifications : $try4b ");
      } else {
        $va4b=unserialize($aa4b);
        if ($va4b===false) {
           doReturnError("Problem with portfolio modifications  file: $try4b ");
        } else {
          $rets['messages'][]='Using portfolio modifications file '   ;
          $rets['portfolioModifications']=$va4b;
        }
     }
  } else {
     $rets['messages'][]='No portfolios modification file available ';

  } // portfolio initialiation file


// look for valuation dates file
  $try5=$daDir.'/viewDates.json';
  $gotValueDates=file_exists($try5);
  if ($gotValueDates) {
      $aa=file_get_contents($try5);
      if ($aa===false) {
         doReturnError("Unable to viewDates file: $try5");
      } else {
        $va=unserialize($aa);
        if ($va===false) {
           doReturnError("Problem decoding viewDates file: $try5 ")  ;
        } else {
          $dd=date('Y-m-d H:i',$va['date']);
          $rets['messages'][]='Using viewDates   file updated on '.$dd ;
          $rets['viewDates']=$va;
        }
     }
  } else {
     $rets['messages'][]='No viewDates  file available ';
  }     // valueDates


// personal settings

  $try6=$daDir.'/settings.json';
  $gotSettings=file_exists($try6);
  if ($gotSettings) {
      $aa=file_get_contents($try6);
      if ($aa===false) {
         doReturnError("Unable to use settings file: $try6");
      } else {
        $va=unserialize($aa);


        if ($va===false) {
           doReturnError("Problem decoding settings file: $try6 ")  ;
        } else {
          $dd=date('Y-m-d H:i',$va['date']);
          $rets['messages'][]='Using settings file updated on '.$dd ;
          foreach ($va['list']  as $avar=>$aval) {
            $rets['settings']['list'][$avar]=$aval;
          }
         
        }
     }   // aa

  }   else {  // no settings file (should never happen)
     $rets['settings']['list']=[];
     $rets['messages'][]='No settings file available: using defaults  ';


  } // settings


  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;
}

//=-----------------------
// generic save a simInv   dataset  (might be encrsyped)
function saveDataset($auser,$dakeyMd5) {
  $curDir=getcwd();
  $awhich=$_REQUEST['which'];
  $acontent=$_REQUEST['data'];
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/'.$awhich.'.json';
  $aa=['date'=>time(),'content'=>$acontent ];
  $da2=serialize($aa);

  $nn=file_put_contents($try,$da2);
  if ($nn===false)  {
    doReturnError("Could not save: $awhich : in: $try ");
  }

  ob_end_clean();   // remove prints and other crap
  $amess='Saved: '.$awhich;
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit;
}


// ===========
// save current users "first used" encryption key
function saveEncKey($auser,$dakeyMd5) {

  $curDir=getcwd();

  $dahint=''; // saved in settings
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/encKeyMd5.json';
  $aa=['date'=>time(),'encKeyMd5'=>$dakeyMd5,'hint'=>$dahint];

  $da2=serialize($aa);

  $nn=file_put_contents($try,$da2);
  if ($nn===false)  {
    doReturnError("Could not save md5 of encryption key in: $try ");
  }

  return 1;

}


// ===========
// return current users "first used" encryption key
function readEncKey($auser,$curDir) {

  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/encKeyMd5.json';
  $gotEncKey=file_exists($try);
  if ($gotEncKey) {
      $aa=file_get_contents($try);
      if ($aa===false) {
         doReturnError("Unable to retrieve encryption key MD5 file: $try ");
      } else {
        $va=unserialize($aa);
        if ($va===false) {
           doReturnError("Problem reading encryption key MD5 file: $try ")  ;
        } else {
          return $va ;
        }
     }
  }

  return  false ;     // if no encKeyMd5 ever saved, use a value of ''
}

//======================
// save personal settings for a suer
function  doSaveSettings($auser,$noexit=0)  {
  $da1=[];
  $da1['date']=time();
  $da1['list']=[];
  $alist=$_REQUEST['data']['list'];
  foreach ($alist as $avar=>$aval) {
      $da1['list'][$avar]=$aval;
  }


  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/settings.json';

  $da2=serialize($da1);
  $nn=file_put_contents($try,$da2);
  if ($nn===false) {
     doReturnError("Error: could not save settings file: $try ") ;
     exit;
  }
  if ($noexit==1) return $da1 ;  // initializting call?

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($da1, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit;

}

//===============
// save display dates for user
function  doSaveViewDates($auser)  {
  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/viewDates.json';
  $vdList=$_REQUEST['data']['list'];

  $da1=[];
  $da1['date']=time();
  $da1['list']= $vdList  ;
  sort($da1['list'],SORT_NUMERIC);

  $da2=serialize($da1);
  $nn=file_put_contents($try,$da2);
  if ($nn===false) {
     print_r("Error: could not save $try ");
     exit;
  }

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($da1, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;
}





//============================
// save a portfolio asset mix (initial)
function  doSavePortfolioInit($auser ) {

  $pname=$_REQUEST['portfolio']  ;

  $alls=$_REQUEST['alls'];

  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/portfolioInit.json';

  $portfolioInit=[];
  $pArray=[];

  if (file_exists($try)) {
    $aa=file_get_contents($try);
    if ($aa===false)  doReturnError("Unable to retrieve portfolio initialization file: $try ");
    $portfolioInit=unserialize($aa);
  }

  if (!array_key_exists($pname,$portfolioInit)) {    // doesn't exist, so initializse
     $portfolioInit[$pname]=[];  // this portfolio
     $portfolioInit[$pname]['alls']=$alls;  // this portfolio asset mix, totals, etc
   }
   $portfolioInit[$pname]['alls']=$alls;

  $da2=serialize($portfolioInit);
  $nn=file_put_contents($try,$da2);
  if ($nn===false) {
     print_r("Error: could not save initial portfolio to: $try ");
     exit;
  }

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode("saved $nn to $try", JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

}

//=============
// remove a portfolio modification
function   doRemovePortfolioModification($auser)  {
  $pname=$_REQUEST['portfolio']  ;
  $amod=$_REQUEST['modification'];

  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/portfolioModifications.json';

  $portfolioModifications=[];

  if (file_exists($try)) {
    $aa=file_get_contents($try);
    if ($aa===false)  doReturnError("Unable to retrieve portfolio modifications file: $try ");
    $portfolioModifications=unserialize($aa);
  }

  if (!array_key_exists($pname,$portfolioModifications)) {
       doReturnError("No such portfolio ($pname), so can not remove modification ($amod) ");
  }

   if (!array_key_exists($amod,$portfolioModifications[$pname]['alls'])) {
//     $goo=['oink'=>1,'poo'=>'foo'];
//            ob_start();
//      var_dump($portfolioModifications);
//      $result = ob_get_clean();

       doReturnError("In  portfolio $pname, no such modification ($amod) xx2 <pre>$result</pre>");
  }
  unset($portfolioModifications[$pname]['alls'][$amod])  ;
  $goo1=$portfolioModifications[$pname]['pArray']   ;
  $gooNew=[];
  foreach ($goo1 as $ii=>$idate) {
     if ($idate==$amod) continue;
     $gooNew[]=intval($idate);
  }
  $portfolioModifications[$pname]['pArray'] =$gooNew;

  $portfolioModifications2= serialize($portfolioModifications);
  $nn=file_put_contents($try,$portfolioModifications2);
  if ($nn===false) {
     print_r("Error: could not save portfolio modifications to: $try ");
     exit;
  }
  $amess="Modification $amod removed from portfolio $pname ";
  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;


}


//=============  ::::::::::::::::::::::::  =======================
// error return
function doReturnError($amess,$acondition='',$avalue='') {
     $rets=[];
     $rets['error']=true;
     $rets['errorMessage']=$amess;
     if ($acondition!='') $rets[$acondition]=$avalue;

    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
}


//=========
// from https://www.php.net/openssl_encrypt
// encrypts plain text $amessText) using $akey.
// returns base64 encoded version of the encrypted text, with 'wEncryt. $message:' prepended
// Thus: wDecrypt looks for 'wEncrypt. xxx :', and removes it. If this is not found (and xxx can be anything, including ""
//       an error is returned
function wEncrypt($amessText,$key,$message=" ") {
  $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
  $iv = openssl_random_pseudo_bytes($ivlen);
  $ciphertext_raw = openssl_encrypt($amessText, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
  $hmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
  $ciphertext = base64_encode( $iv.$hmac.$ciphertext_raw );

  $amessage1=str_replace(':',' ; ',$message);
  return "wEncrypt. $amessage1:". $ciphertext;
}

//--------------
// decrypte text that was encrypted using wEncrypt
// amessEncrypt : message encrypted (and base64'ed) with wEncrypt
// $akey  : key used to encrypt
// return the uncentryped text  or false if an erro
// if verbose is specified and equal 1, then
//   return [true,unencryptedText] if okay
//          [false,errorMessages] if an error  -- errorMessages is an array of erro messages
function wDecrypt($amessEncrypt0,$key,$verbose=0) {

  while(openssl_error_string() !== false);   // clear error s
  $ahead1=substr($amessEncrypt0,0,9);
  if ($ahead1!='wEncrypt.') {
     if ($verbose!=1) return false ;
     return [false,['Not an wEncrypted string (does not start with wEncrypt)']];
  }
  $jpos=strpos($amessEncrypt0,':');
  $amessEncrypt=substr($amessEncrypt0,$jpos);
  $c = base64_decode($amessEncrypt);
  $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
  $iv = substr($c, 0, $ivlen);
  $hmac = substr($c, $ivlen, $sha2len=32);
  $ciphertext_raw = substr($c, $ivlen+$sha2len);
  $original_plaintext = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
  $calcmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
  if (hash_equals($hmac, $calcmac)) { // timing attack safe comparison
       if ($verbose!=1)return $original_plaintext ;
       return [true,$original_plaintext];
   }
  if ($verbose!=1) return false ;

  $errs=[];
   while ($msg = openssl_error_string()) $errs[]= $msg ;

   return [false,$errs];

}


//==========================
// export data a json file
function doExportData($auser) {
  $curDir=getcwd();
  $daDir=$curDir.'/data/'.$auser;
  $aget=$daDir.'/*.json';
  $ff=glob($aget);
  $bnames=[];
  $rets=[];
  $messages=[];
  foreach ($ff as $ith=>$fullName) {
     $bname=basename($fullName,'.json');
     $aah=file_get_contents($fullName);
      if ($aah===false) {
         $messages[]="Export error: Unable to retrieve $bah: $aah ";
      } else {
        $vah=unserialize($aah);
        if ($vah===false) {
           $messages[]="Problem decoding $bah: $aah "  ;
        } else {
          $rets[$bname]=$vah;
          $messages[]="Retrieved: $bname ";
       }
     }   //aah=false
   }  // file
  $stuff=['info'=>$rets,'messages'=>$messages];

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests ;
  exit ;
}

// ===========
// echo export data
 // export data a json file
function doExportData2($auser) {
  $stuff=$_REQUEST['stuff'];
  print $stuff;
  exit;
}

?>
