//=============== ==========================    ========================== ==========================
// auto/manual archive functions

// quick front ends
function autoArchiveRecover(k1) {
    archiveRecover('auto');
    return ;
}
function manualArchiveRecover(k1) {
    archiveRecover('manual');
    return ;
}

function autoArchiveMake(k1) {
   archiveMake('auto');
}

function manualArchiveMake(k1) {
   archiveMake('manual');
}

//=========
// Display menu of archive info; with choices
// used by onLine and local stroage
// astats properties are type of archive ('auto' or 'manual'
// archiving permitted (true/false), archive exists (true/false), php timestamp of archive, date of archive (string)
// this is caleld by autoArchive (or autoArchive_local)

function autoArchiveMenu(aStats) {
  bmess='';

   bmess+='<button class="csettingsButton" title="Back to: export and import menu" onclick="doExport_menu(this)" >&uArr;</button> ';
  if (aStats['current'][1]) {         // current data available
     let sayDate=wsurvey.get_currentTime(31,1,simInvGlobals['lastUpdateDate']);
     bmess+='<em>Your data was updated on '+sayDate+'</em><br>';
  }
  bmess+= '<button title="Tips" onClick="displayHelpMessage(this,0,1,\'exportArchiveRestoreHelp1_autoArchive\')"  data-div="#exportArchiveRestoreHelp1">&#10068;</button>';
 bmess+='You can ...   ';
 bmess+='<ul id="autoArchive2_boxlist" class="boxList">';

 if (aStats['auto'][0]==true) {
    if (aStats['auto'][1]==true) {
        bmess+='<li> <button onClick="autoArchiveRecover(1)"><b>Restore</b> automatically saved archive</button>  ';
        bmess+= ' <em> data from '+aStats['auto'][3]+'</em>';
     }  else {
        bmess+='<li>No automatically created archive currently available ';
     }
 } else {
    bmess+='<li>auto archiving not enabled ';
 }    // auto

 if (aStats['manual'][0]==true) {
     if (aStats['manual'][1]==true) {
        bmess+='<li> <button onClick="manualArchiveRecover(1)"><b>Restore</b> manually saved archive</button> ';
        bmess+= ' <em>data from '+aStats['manual'][3]+'</em>';
     }  else {
        bmess+='<li>No manually created archive currently available ';
     }

     bmess+='<li> <button onClick="manualArchiveMake(1)"><u>Create</u> manually saved archive</button> (will overwrite any pre-existing manually saved archive) ';

 } else {       // no manual archiving
    bmess+='<li>manual archiving not enabled ';
 }     // manual

 bmess+='</ul>';

 bmess+='<div id="autoArchive2_res" style="background-color:#aaccaa;margin:5px 1em">auto-archive status: '+simInvGlobals['autoArchiveStatus']+'</div>';
  displayStatusMessage(bmess);
  toggleStatusDiv(0,0);
}

// --------------  -----------
// get current info on auto/manual archives

function autoArchive(ido) {
   let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
   if (qLocal) {
      autoArchive_getInfo_local(1);
      return 1;
    }

// .... if here, server storage ...

    let ddata={'todo':'getAutoArchiveBasics','username':userName,'encMd5':simInvGlobals['encryptionKey_md5']};
    $.ajax({
        url: 'phpLib/simInv2.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {
     autoArchive_getInfo2(response);
   });
}

// callback from autoArchive_getInfo
function autoArchive_getInfo2(response,asay) {

  if (response.hasOwnProperty('error') && response['error']==true) {
     alert('autoArchive error: '+ response['errorMessage']);
     return false;
  }

  let aStats={};            // archiving permitted, archive exists, php timestamp of archive, date of archive ]

  let arcTypes={'current':1,'auto':1,'manual':1,'removed':1}; // removed and current not currently used (27 dec 2023)
  for (let awhich in arcTypes) {
      if (!response.hasOwnProperty(awhich)) {     // should never happen
           aStats[awhich]=[false,false,false,false] ;  // this flavor of archiving not permitted
     } else if (response[awhich]===false) {
           aStats[awhich]=[false,false,false,false] ;  // this flavor of archiving not permitted
     } else {
        let aval=parseInt(response[awhich] );
        if (aval===false || aval<0) {
           aStats[awhich]=[false,false,false,false] ;  // this flavor of archiving not permitted
        } else if (aval==0) {       // no or bad datestamp -- assume no archive currently exists
            aStats[awhich]=[true,false,false,false] ;
        } else {
           let daDate=wsurvey.get_currentTime(31,1,aval*1000);
           aStats[awhich]=[true,true,aval,daDate];
        }
     }
  }
  autoArchiveMenu(aStats);
  return 1;
}

//======
// local version of get archive info
function autoArchive_getInfo_local(i1) {

  archiveInfo_indexDb(userName,autoArchive_getInfo_local2);

}
function autoArchive_getInfo_local2(astatus,ares) {
   if (astatus==0) {
      alert('Archiving error:' +ares);
      let oof=autoArchive_getInfo_local2/3;
      return ;
   }

  let a1s={'auto':1,'manual':1};
  let aStats={};            // archiving permitted, archive exists, php timestamp of archive, date of archive ]

  lastUpdate=false;
  aStats['current']=[true,true,lastUpdate,'n.a.'];
  for (aa in a1s) {

    if (!ares.hasOwnProperty(aa)) {
      let afalse=false;
      if (simInvGlobals['enableAutoArchive']==1 &&  (aa=='auto' || aa=='manual')) afalse=true;
      if (simInvGlobals['enableAutoArchive']==2 && aa=='manual') afalse=true;
      aStats[aa]=[afalse,false,false,false];

    } else {                       // this kind of archive is allwoed
      if (ares[aa]==false)  {      // nothing archived yet
           aStats[aa]=[true,false,false,false];
      } else {   // check for archiveDate
         if (!ares[aa].hasOwnProperty('archiveDate')) {
             aStats[aa]=[true,false,false,false];
         } else {                                // an achive exists!
           let aupdate=ares[aa]['archiveDate'];
           let foo=setEntryDate(aupdate);
           aStats[aa]=[true,true,aupdate,foo.sayDate];
         }
      }     // ares[aa]==false
    }     // ares.hasOwnPrOperty(aa))
  }       //   for (aa in a1s)

  autoArchiveMenu(aStats);
}


//====-----   =======================  ===============
//  restore  archive
function archiveRecover(awhich) {

    let qq=confirm('Are you sure you want restore your simInv data (from '+awhich+') -- all your existing simInv data will be overwritten! ');
    if (!qq) return false 


     let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
     if (qLocal) {
         archiveRecover_local(awhich) ;
         return 1;
     }

// if here ... server storage ...............
    let todo ;
    if (awhich=='manual') {
       todo='recoverManualArchive';
    } else {
       todo='recoverAutoArchive';
    }
    


    let ddata={'todo':todo,'username':userName,'encMd5':simInvGlobals['encryptionKey_md5']};
    $.ajax({
        url: 'phpLib/simInv2.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {
     archiveRecover2(awhich,response);
   });
}
function archiveRecover2(awhich,response ) {

  if (response.hasOwnProperty('error') && response['error']==true) {
     alert(awhich+'  error: '+ response['errorMessage']);
     return false;
  }
  let asay=response ;
  if (jQuery.isArray(response))     asay='<ul><li>'+response.join('<li>')+'</ul>';


  asay+='<br> You should  ... <button  class="cdoButtonRegular"   onClick="doLogoff(1)">re-logon</button> ';
  $('#autoArchive2_res').html('<b>Restoring '+awhich+'-archive:</b>'+asay);

}

//==============     ============
// recover archive:  local storage version
function archiveRecover_local(awhich) {
     restoreArchive_indexDb(userName,awhich,archiveRecover_local2)
    return ;
}
function archiveRecover_local2(istatus,astuff,awhich,archiveDate) {
   if (istatus==0) {
      alert(awhich+' recover  error:' +astuff);
      let oof=archiveRecover_local2_err/3;
      return ;
   }
   if (astuff[awhich]===false) {
      alert(awhich+' archive is not currently available '); // this should not happen (button active only if manual archive exist
      return 0
   }

   let sayDate='n.a.';
   if (jQuery.isNumeric(archiveDate)) {
       sayDate=wsurvey.get_currentTime(31,1,archiveDate)
   }

   let asay='<br> You should  ... <button  class="cdoButtonRegular"   onClick="doLogoff(1)">re-logon</button> ';
   $('#autoArchive2_res').html('<b>'+awhich+'-archive restored ('+sayDate+') </b>'+asay);
}

//====-----  -------------------   ============
// create an  archive
function archiveMake(awhich) {
// Note : 27 dec 2023 ... auto archive create should NOT be called if errors/warnings decteced
    if (simInvDsets['qStatusList']['assetsNeedFixing']===true) {
        let q1=confirm('There are '+simInvDsets['qStatusList']['setupAssetUsedErrors']+' problems with your assets.\nAre you sure you want to create a '+awhich+' archive with this damaged data? ');
        if (!q1) return  false;
    }

     let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
     if (qLocal) {
         archiveMakeLocal(awhich) ;
         return 1;
     }

 // ...... if here, server storage ......

  if (awhich=='manual') {
      todo= 'makeManualArchive' ;
  } else {
      todo= 'makeAutoArchive' ;
  }
    let ddata={'todo':todo,'username':userName,'encMd5':simInvGlobals['encryptionKey_md5']};
    $.ajax({
        url: 'phpLib/simInv2.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {
     archiveMake2(response,awhich);
   });
}
function archiveMake2(response,awhich ) {

  if (response.hasOwnProperty('error') && response['error']==true) {
     alert('archiveMake2 error: '+ response['errorMessage']);
     return false;
  }
  let asay=response ;
  if (jQuery.isArray(response))     asay='<ul><li>'+response.join('<li>')+'</ul>';

  if (awhich=='manual') {
    let asay='<br> <button onclick="autoArchive(0)">refresh...</button>';
    $('#autoArchive2_res').html('<b>'+awhich+' archive created</b>:' +asay);
  }   else {
      let nowTime=wsurvey.get_currentTime(31,1);
      simInvGlobals['autoArchiveStatus']='Auto archive created at logon (saved on server @ '+nowTime+')';      // a global that diagnostics can display
  }
}

//==============
//   make archive  ---  local storage version
// 27 dec ... assume manual archive exists (otherwise button would not be active)

function archiveMakeLocal(awhich) {

  makeArchive_indexDb(userName,awhich,archiveMakeLocal2)
  return ;
}

function archiveMakeLocal2(astatus,amess,awhich) {

   if (astatus==0) {
      alert(awhich+' archiving error:' +amess);
      return ;
   }

  if (awhich=='manual') {
    amess+='<br> <button onclick="autoArchive(0)">refresh this menu</button> ... or ';
    amess+='<input type="button" onClick="doLogoff(1)" value="re-logon"> ';
    $('#autoArchive2_res').html('<b>'+awhich+' archive restored  </b>'+amess);
  }  else {
      let nowTime=wsurvey.get_currentTime(31,1);
      simInvGlobals['autoArchiveStatus']='Auto archive created on logon (saved to local storage @ '+nowTime+')';      // a global that diagnostics can display
  }

  return  ;
}



