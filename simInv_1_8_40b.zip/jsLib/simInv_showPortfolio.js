// === show all values: inflation adjusted?

function showAllPortfolioValuesStart(useInfAdjust,aportfolio,doFull) {

   redisplayHeaderLine(1);

   if (doFull==2 &&   simInvGlobals['cacheStuff']['cacheDisplayResults']=='fast')  { // special case
       let smessage,smessage2;
       smessage='<img src="spinner-icon-gif-1.jpg" height="30" width="30" alt="spinner"> Please wait while simInv initializes and re-calculates your portfolios (from quickDisplay to calculated) ... ';
        smessage2='Please wait while simInv initializes and re-calculates your portfolios (from quickDisplay to calculated) ... ';
        displayStatusMessage(smessage);
        toggleStatusMessage(0,1);
        $('#progressDiv_message').html(smessage2);
        simInv_fastQuickDisplayReCalc(useInfAdjust);
        return 1;
  }

// not fast quickdisplay

   if (arguments.length<2 || aportfolio===false || aportfolio==0) aportfolio=false;
   if (arguments.length<3 || doFull===false) doFull=0;

   if (doFull==2) {               // force non-quickDisplay (do not use localStorage of cached html Display Table)
      doFull=1;
      simInvGlobals['cacheStuff']['cacheDisplayResults']='write';
   }

   if (doFull!==1 && simInvSummaryResults['recentDisplay']!==false)  {                //   a redisplay of unchanged  already created showAllPortfoplioValues table -- then use it
       let ahow=showAllPortfolioValues(useInfAdjust,aportfolio);  // will do a redisplay, so async doesn't matter
       return 1;
  }

// not a redisplay
   let smessage2;
   if (doFull==1){
            smessage='<img src="spinner-icon-gif-1.jpg" height="30" width="30" alt="spinner"> Please wait while simInv   re-calculates your portfolios (from quickDisplay to calculated) ... ';
            smessage2='Please wait while simInv  re-calculates your portfolios (from quickDisplay to calculated) ... ';

   } else {
     if (useInfAdjust==1) {
         smessage='<img src="spinner-icon-gif-1.jpg" height="30" width="30" alt="spinner"> Please wait while simInv calculates your inflation adjusted portfolios ... ';
         smessage2='Please wait while simInv calculates your inflation adjusted portfolios ... ';
     } else {
            smessage='<img src="spinner-icon-gif-1.jpg" height="30" width="30" alt="spinner"> Please wait while simInv calculates your portfolios ... ... ';
            smessage2='Please wait while simInv calculates your portfolios ... ... ';
     }
   }
   displayStatusMessage(smessage);
   toggleStatusMessage(0,1);
   $('#progressDiv_message').html(smessage2);

   let time1=Date.now();
   simInvSummaryResults['wstatus']='' ;  // false means not being worked on , true means done, anything else is a status message
   simInvSummaryResults['wstatusStartTime']=time1 ;  // false means not being worked on , true means done, anything else is a status message
   simInvSummaryResults['finalMessage']=false ;  // false means not being worked on , true means done, anything else is a status message
   simInvSummaryResults['callFinal']=false ;

   showAllPortfolioValues_monitor(0,time1);

   window.setTimeout(function() {         // pause while dom settles
         let ahow=showAllPortfolioValues(useInfAdjust,aportfolio);  // this is not async, so timeout function immediately ends --
   },100);               // showAllPortfolioValues is async, so it use showAllPortfolioValues_monitor() to write progress bar, etc.

   return 1;
 }

/// front end to showAllPortfolioValues -- inflation adjustments   for ALL portfolios
// 30 march 2024 : aportoflio argument is never used (should remove it)
function showAllPortfolioValues_infAdj(ii,aportfolio) {
   if (arguments.length<2 || aportfolio===false) aportfolio=false;  // aportfolio will always be false (30 march 2024)

  let ival= simInvGlobals['display_infAdj']

  ival=1-ival ; // toggle (0 becomes 1,... 1 means "use inflation adjustment")
  simInvGlobals['display_infAdj']=ival;

  if (ival==1) {
     $('#infAdjustCheckbox_mark').show();
     $('#infAdjust_wait').show();
  } else {
     $('#infAdjustCheckbox_mark').hide();
  }
  window.setTimeout(function() {
     showAllPortfolioValuesStart(ival,aportfolio,true)   ;      // aportfolio will always be false
  },40);

}

//==================
//  monitor status of showAllPortfolioValues -- uses the myStatusVar global
function showAllPortfolioValues_monitor(ithCall,tstart) {

     let astatus= simInvSummaryResults['wstatus'] ;
     if (astatus===true) {   // all done
       let time2=Date.now();
       let epsTime=time2-tstart ;
       let epsTimeSay=(epsTime/1000).toFixed(2);
       if (simInvSummaryResults['finalMessage']===false ) {
          let t1=simInvGlobals['cacheStuff']['nCacheUseGlobal'],t2= simInvGlobals['cacheStuff']['nCacheNotUseGlobal']    ;
          let zmess='<br>Eps: '+epsTimeSay+ ' : cacheUsed='+t1+', cacheNotUsed='+t2 ;
          simInv_notes('Done calculating  Display values: '+zmess);

          $('#valuePortfolioButton').attr('data-eps_status',zmess);
          displayStatusMessage(' ... done!   '+zmess  ,1);
          let dd1=parseInt(simInvParams['showPortoflio_splashDelay']);
          displayStatusMessage(false,0,dd1);
       } else {
           displayStatusMessage('<br>'+simInvSummaryResults['finalMessage'],1 );
       }
       fixmyheight_maindiv(1) ;  // fit into  maindiv
       $('#progressDiv').hide() ;
       $('#infAdjust_wait').hide();       // might not be shown, but wth
       
       let epsAll=(time2-simInvSummaryResults['wstatusStartTime'])  ;
       if (epsAll>8000) {
          $('#iWarningsButton').show();
          $('#iWarningsButton').attr('data-what','slow');
          $('#iWarningsButton').attr('data-info',epsAll);
          let wlevel=parseInt(simInvParams['warningLevel'])
          let tz1=epsAll/1000;
             let oog='Calculating values for the displayDates took '+tz1.toFixed(1)+' seconds. ';
             oog+='\n You can use \`interpolation\`   (in the \u26ED settings) to speed this up -- at the cost of less accurate displayed results';
             $('#progressDivInner').html(oog);
             simInv_notes(oog) ;
          if (wlevel==0) alert(oog);
       }

//  simInvDsets['viewDates_dataStore']={};           // data shown by Display
//  simInvDsets['viewDates_dataStore_gname']=false;  // data shown by Display
//  simInvDsets['viewDates_dataStore_index']={};      // index to viewDates_dataSt
       if (simInvSummaryResults['callFinal']!==false)  {   // a callback!
         let zfunc=simInvSummaryResults['callFinal'][0];      // function name (as string)
         let zargs=simInvSummaryResults['callFinal'][1];      // argument to send to function (can be array, object, whatever)
         window[zfunc](zargs);
       }
       return 1;
  }
// else ... still running
  ithCall++;
  $('#progressDiv').show();
  if (ithCall==1 || astatus=='' ) {            // if astatus=='', nothing has happened yet, so keep waiting ...
     $('#progressDivInner').html('Start ...');
   } else {
     $('#progressDivInner').html('Completed: '+astatus.join(' of ')) ;
  }
  window.setTimeout(function(){
     showAllPortfolioValues_monitor(ithCall,tstart)},
     1100);
}

//==================
// called by   showAllPortfolioValues_infAdj and  showAllPortfolioValuesStart
// show all the portfolio values in a table
// useInfAdjust=1 to "inflation adjust", 0 to not
// This is async -- since it await calls sleepQ -- sleepQ does a timeout, which gives _monitor a chance to update the progress bar
// 30 march 2024 : aportfolio is non-false ONLY if this is called by showAllPortfolioValues_viewAssetsOverTime to fuly calculate an interpolated portfolio

async function showAllPortfolioValues(useInfAdjust,aportfolio) {

   let bmess='';

   if (arguments.length<2 || aportfolio===false) aportfolio=false;
   if (arguments.length<3  ) noCache=0;

   let gname=false,gnameBase=false ;                     // flase means "do not save this to a cache"
   if (aportfolio===false) {             // normal call, so save "gname"
     let ascenario=simInvParams['scenarioUse'];
     gname=ascenario;
     if (gname===false || gname=='') gname= '0';
     gnameBase=gname ;
     if (useInfAdjust==1) gname+=' infAdj';
   }


   let doViewDates,doCustomDates,showValuesInterp ;
   doViewDates=simInvDsets['viewDates']['all']  ;
   doCustomDates=JSON.parse(JSON.stringify(simInvDsets['viewDates']['customDates']))  ;

   let  doPorts=[],doPortsLookup={},nPortfoliosActive=0;        // create  list of portoflios to be "displayed"

   if (aportfolio!==false)  {   // special case: just one portofolio (called by viewDeatils)
       showValuesInterp=0 ;
   } else {         // first time -- so make the display results table (and save info for this scenario)
       showValuesInterp=parseInt(simInvParams['showValuesInterp']);
   }

   let gnameDCache= (useInfAdjust==1) ? 'main_inf' : 'main';
   if (showValuesInterp!=0) gnameDCache+='_interp';

// shortcut if one portfolio --   called if "full calculaton" of an interpolated portoflio is needed (for assetsOverTime view)
// this assumes that aportfolio is an existing & unhidden portfolio!
  if (aportfolio!==false) {
     nPortfoliosActive++ ;
     doPorts.push(aportfolio);           // don't use doPortsLookup in this shortcut (since no display)
     let vLength=doViewDates.length;
     for (let jthDate=0;jthDate<vLength;jthDate++) {         // one row for each date ..
       let aviewDate=doViewDates[jthDate];
       foo= await sleepQ(20);
       let goo1=showV_2(aviewDate,jthDate,vLength);   // THIS DOES THE WORK (step 1)
       dataStore[aviewDate]=goo1 ;
    }

    for (let ddate in dataStore) {              // save to 'viewDates_dataStore' cache  --
        if (!simInvDsets['viewDates_dataStore'].hasOwnProperty(ddate)) simInvDsets['viewDates_dataStore'][ddate]={};
        simInvDsets['viewDates_dataStore'][ddate][aportfolio]=dataStore[ddate][aportfolio];
    }
    showValues_dataStore_makeIndex(1)   ;
    simInvSummaryResults['wstatus']=true ;   // flag for monitor to exit --   finalMessage and callFinal was set by showAllPortfolioValues_viewAssetsOverTime()
    simInv_notes('Full calculation of '+aportfolio);

    return 1;
  }           // end of shortcut if one portfolio

// do all the portfolios ....


   for (ith=0;ith<portfolioList.length;ith++) {
     let iexists=portfolioList[ith]['exists'];
     if (iexists==0) continue ; // not initialized
     let isHidden=portfolioList[ith]['isHidden'];
     if (isHidden==1) continue;                   // skip hidden portfolios
     let pname=portfolioList[ith]['name'];
     if (aportfolio===false || aportfolio==pname) {
        nPortfoliosActive++ ;
        doPorts.push(pname);
        doPortsLookup[pname]=ith;
     }
   }

   let oofDate=setEntryDate(true);
   let nowDayCount=oofDate['dayCount'];  // used for CPI calculation

  wsurvey.wsShow.show('#mainDiv','show');

  wsurvey.wsShow.hide('#mainDiv1',122)   ;
  wsurvey.wsShow.hide('#mainDiv3',122)   ;

  wsurvey.wsShow.show('#mainDiv2','show');    // this is where the table is shown

  let emainDiv2=$('#mainDiv2');
  let mainDiv2Width=emainDiv2.width();

  simInvGlobals['cacheStuff']['usingCacheNow']=false ;    // assume computation (either full or interpolation)

// Nothing changed since last display (or switch between non-inflated and inflated, same scenario)? Then redisplay the HTML (no need to compute anything) !
  if (simInvSummaryResults['recentDisplay']!==false)  {                   //  already created showAllPortfoplioValues table -- then use it
     if (simInvSummaryResults['recentDisplay'].hasOwnProperty(useInfAdjust)) {

       let bmess2Raw=simInvSummaryResults['recentDisplay'][useInfAdjust]  ;    // retain non-inflated and inflated values
       let bmess2=LZString.decompressFromUTF16(bmess2Raw);
       $('#mainDiv2').html(bmess2);
       fixmyheight_maindiv(1) ;  // fit intoi maindif

       simInvSummaryResults['callFinal']=false ;
       simInvSummaryResults['wstatus']=true ;   // flag for monitor to exit --   finalMessage and callFinal was set by showAllPortfolioValues_viewAssetsOverTime()

       return 2;
     }                // seperate tables for inflated and non-inflated
  }

// maybe saved in diesplayCache? will not be if this is called due to "view assets over time" and quickDisplay was used
    let bmess2=simInv_cacheResults_read(gnameDCache);
    if (bmess2!==false) {
       simInv_notes('Using displayCache for '+gnameDCache);
       simInvGlobals['cacheStuff']['usingCacheNow']=true;     // computations not done!  Thus: details and export NOT supported
       $('#mainDiv2').html(bmess2);
       $('#iQuickDisplay').show();
       if (simInvGlobals['cacheStuff']['cacheDisplayResults']=='fast') {
          $('#iQuickDisplay2').html('<span title="Fast version of quickDisplay">fastDisplay</span>');
       } else {
          $('#iQuickDisplay2').html('<span title="quickDisplay">quickDisplay</span>');
       }
       fixmyheight_maindiv(1) ;  // fit intoi maindif
       simInvSummaryResults['callFinal']=false ;
       simInvSummaryResults['wstatus']=true ;   // flag for monitor to exit --   finalMessage and callFinal was set by showAllPortfolioValues_viewAssetsOverTime()
       return 3;
   }
   if (simInvGlobals['cacheStuff']['cacheDisplayResults']=='fast') {    // no localStorage, and fast means no init -- force call back without quickDisplay
      let acc=['simInv_fastQuickDisplayReCalc',useInfAdjust];              // function name (as string), argument to send to function
      simInvSummaryResults['callFinal']=acc;
      simInvSummaryResults['finalMessage']='fast quickDisplay chosen, but there are no results localStorage. <b>Please wait</b> while portfolio entries are processed ...';

      simInvSummaryResults['wstatus']=true ;   // flag for monitor to exit --   finalMessage and callFinal was set by showAllPortfolioValues_viewAssetsOverTime()
      simInv_notes('No Display -- fast quickDisplay but nothing saved. ');
     return 0;
    }

// if here, not in recentDisplay or in displayCache ... build a portfolioValues table  ...

// hard code widths. 26 June ... maybe switch to floated <divs> to allow for resizing?
  let firstColWidth=140;   // in px
  let minCellWidth=200 ;
  let mainDiv2WidthUse= mainDiv2Width-(1.7*firstColWidth);
  let tryCellWidth=parseInt(mainDiv2WidthUse/nPortfoliosActive);
  let useCellWidth=Math.max(tryCellWidth,minCellWidth);
  let tableWidth=parseInt((nPortfoliosActive*useCellWidth)+firstColWidth+30);     // add 10 just because

  bmess+=showV_1(useInfAdjust);       //header  above table, and first row of table

    dataStore={};

// showV_2: get entry info for all display dates for all portfolios... if creation date of a portfolio is after a display date, entry=false
// showV_2 will also update wstatus (used by showAllPortfolioValues_monitor() to update progress bar)

// if already done (say, this is an inflation adjusted call)?   NOte this is for the most recently "dipslayed" (only one scenario is stored in this cache)
  let qUseCache=false;
  if (noCache!==1 && simInvDsets['viewDates_dataStore_gname']!==false) {
     if (simInvDsets['viewDates_dataStore_gname']===gnameBase) {
         dataStore=simInvDsets['viewDates_dataStore'];
         qUseCache=true;
     }
  }

  if (qUseCache===false) {                            // NOT in viewDates_dataStore cache... so create

// first: do custom dates
     let vLengthC=doCustomDates.length;
     let lastYearStuff= setEntryDate(simInvParams['lastYearUse'],12,31)  ;
     if (vLengthC==0 || doCustomDates[vLengthC-1]<lastYearStuff.dayCount) doCustomDates.push(lastYearStuff.dayCount);   // should always be true
     vLengthC=doCustomDates.length;

     for (let jthCustom=0;jthCustom<vLengthC;jthCustom++) {         // one row for each date .. each col is a portfolio on that datee
       foo= await sleepQ(20);
       let aviewDateC=doCustomDates[jthCustom];
       let goo1=showV_2(aviewDateC,jthCustom,vLengthC);   // THIS DOES THE WORK (step 1) -- returns object each of the unhidden portfolio names as properties, data and sayDate as properties of each pname
     }           // vLengthC

// add last date of reporting rante

     simInv_notes('Calculate displayResults for '+vLengthC+' custom dates ');

// create lookup tables for  simInvDsets['showValues_summary1']
     showValues_summary1_makeIndex(1);            // saved  to  simInvDsets['showValues_summary1_index] -- this is used if interpolation is seleted

// now fill in gaps in  showValues_summary1 using interpolation  --
     if (showValuesInterp===1) {
       let nInterp=showV_2_interp(1)  ;
       simInvSummaryResults['wstatus']=true ;   // flag for monitor to exit
       simInv_notes('Interpolate displayResults for '+nInterp+' portfolio/dates ');
       simInvDsets['showValues_summary1_interp']=JSON.parse(JSON.stringify(simInvDsets['showValues_summary1']));  // used by viewDetails

     }


// if no interp, then fill in gaps using full computation, save to dataStore
     if (showValuesInterp===0) {
        let vLength=doViewDates.length;
        for (let jthDate=0;jthDate<vLength;jthDate++) {         // one row for each date .. each col is a portfolio on that datee
            let aviewDate=doViewDates[jthDate];
            if (dataStore.hasOwnProperty(aviewDate)) continue ;  // a custom date done above? No need to do it again
           foo= await sleepQ(20);

           let goo1=showV_2(aviewDate,jthDate,vLength);   // THIS DOES THE WORK (step 1) -- returns object each of the unhidden portfolio names as properties, data and sayDate as properties of each pname
           dataStore[aviewDate]=goo1 ;
        }           // vLength (doViewDates)
        simInv_notes('Calculated displayResults for '+vLength +' dates ');

// all portfolios have been fully calculated!

       simInvDsets['viewDates_dataStore']=dataStore ;         // save to global -- one 'row' for each of the "view dates", one 'column' for each portoflio
       simInvDsets['viewDates_dataStore_gname']=gname ;

       showValues_dataStore_makeIndex(1)   ;                 // lookup index (used by
     }                // showValuesInterp: interpolation of displayed values is suppressed
  }             // qUseCache: was not in cache (so was calcluated, possibly using interpolation, above)

///  Now write rows (to an HTML string) for each viewdate (each col is a portfolio)   ........................

  let rowClass=['cportfolioValuesTableEven','cportfolioValuesTableOdd'];

  let id0=1 ;
  let oof1D=setEntryDate(true);
  let nowDate=oof1D['dayCount'];  // used for CPI calculation

  let todayDate=setEntryDate(true).dayCount ;

  let bigSave={} ; // save as simInvSummaryResults['cache'][gname]

  for (let jthDate=0;jthDate<doViewDates.length;jthDate++) {    // one row per date (each col is a portfolio)
     let aviewDate=doViewDates[jthDate];
     let got1=0;
     id0=1-id0 ;
     let useClass=rowClass[id0];

     let gotData=(aviewDate>=simInvDsets['showValues_summary1_index']['$firstDate'] )  ? 1 : 0 ;

     for (let apname in dataStore[aviewDate]) {
         let a1= dataStore[aviewDate][apname] ;
          if (a1['data']['dateMatch']===false) continue ;
         gotData++;
     }

     if (gotData==0) {          // no portfolios defined as of this date (too soon!)
         let oofD=setEntryDate(aviewDate);
         let dateMatchSay=oofD.sayDate ;
         bmess+='<tr bgcolor="#dfefdf" class="emptyViewRow" style="display:none;font-size:70%;height:0.5em" title="No portfolios created before (or on) this date "> <td colspan="'+(1+doPorts.length)+'"> &nbsp; <tt>'+dateMatchSay+'</tt> ...</td></tr>';
         continue;
     }

// got at least one portfolio that exists after viewdate
     bmess+='<tr  class="viewPortfolioRow '+useClass+'">';        // start the row for this date (alternate backgrounsd colors)

     let oofX2=setEntryDate(aviewDate);
     let sayDate=oofX2['sayDate'];

// first col is date / startBudget column
     bbasic='<td  class="freezeCol1" title="day# '+aviewDate+'">';
     bbasic+='<button style="border-radius:3px" onClick="highlightThisRow(this)" data-mark="0" title="highlight this row">&#10082;</button> ';
     let seeD1='';
     bbasic+=seeD1;
     if (aviewDate==todayDate) {
        bbasic+='<span style="font-weight:700">'+sayDate+'</span>';
     } else {
        bbasic+=sayDate;
     }
     let acpi=1,amult=1 ;
     if (useInfAdjust==1) {
       acpi=calcInflation(nowDate,aviewDate) ; // cpi used to deflate to current date
       amult=1.0/ acpi  ; // deflate to current date (used in showV_4)
       bbasic+='<span style="float:right;margin-right:0.5em;font-size:90%;font-style:oblique;" title="CPI" name="viewPortfolioRow_cpi">'+acpi.toFixed(2)+'</span>';
     }

     bbasic+='</td>';                 // first col of row 1 (basics) for this er date
     bmess+=bbasic;

     let rdata2=showV_3_B(aviewDate,amult);         // using summary output of growPortfolioDo (can include interpolated cells)  -- or useing cached version of aviewDate

     let row1=showV_4(rdata2,1.0,nowDate,aviewDate) ;        // the remaining cols (one for each of the  portofliods)

     let acpiAbs=calcInflation(aviewDate,aviewDate,2) ;
     bigSave[aviewDate]={'infMult':amult,'CPI':acpiAbs,'data':rdata2} ;
     bmess+=row1;

     bmess+='</tr>';  // end of viewdate


  }        //dates

// display it!
   bmess+='</table>';
   bmess+='<div style="margin-top:2px;font-size:80%;opacity:0.66;color:#0057ff;padding-left:10em"> portfolio values by date ... </div>';

   bmess+='</div>';

  $('#mainDiv2').html(bmess);

  fixmyheight_maindiv(1) ;  // fit into  maindiv

// add to recentDisplay "internal cache"
  if (simInvSummaryResults['recentDisplay']===false) simInvSummaryResults['recentDisplay']={};
  let bmessZip=LZString.compressToUTF16(bmess);
  simInvSummaryResults['recentDisplay'][useInfAdjust]=bmessZip ;     // use this if redisplay of this scenario/infAdjust (in same session) -- seperate inflation and non-inflation versions

// store in html of Display results in "localStorage"
   simInv_cacheResults_save(bmess,gnameDCache);

   $('#valuePortfolioButton').removeClass('cdoButtonRegularBig_wow');   // remove the "new stuff" highlighting

// and save data for use by export
   if (!simInvSummaryResults['cache'].hasOwnProperty(gname))  simInvSummaryResults['ngot']++ ;
   simInvSummaryResults['cache'][gname]=JSON.parse(JSON.stringify(bigSave)) ;     // used by export

   if  (simInvSummaryResults['vars'].length==0) {      // used by export
      let vnames=[];
      let vobj=showV_3_B(1,1,1);       // just get variable list
      for (let aaname in  vobj) vnames.push(aaname);
      simInvSummaryResults['vars']=vnames;
   }

   simInvSummaryResults['wstatus']=true ;   // flag for monitor to exit

   let ec1=$('#iexportImport_button_ct');
   let dd1=parseInt(ec1.attr('data-ct'));
   dd1++;
   ec1.html(dd1);
   ec1.attr('data-ct',dd1);


   return 1;


// ::::::::::::::: internal functions  :::::::::::::::::::::::::::

// :::::;
// header  for display table
  function showV_1(useInfAdjust) {

     let  showValuesInterp=simInvParams['showValuesInterp'] ;

     let bmess='';
     bmess+='<div style="background-color:#dced1a;padding:3px"> ';
     bmess+='<input type="button" value="x" onClick="wsurvey.wsShow.hide(this,200)" data-wsshow="#mainDiv2" > ';
     bmess+='<input type="button" value="&#119136;" onClick="$(\'#portfolioTableNotes1\').toggle()" title="notes on table contents"> ';

     bmess+='<input type="button" value="&neArr;" title="View in a new window"  data-id="mainDiv2" onClick="displayInWindow(this)"> ';

     bmess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#portfolioValuesHelp1">&#10068;</button> ';
     bmess+='<button id="graphDivButton" class="cdoButtonRegular" title="Graphical view" onClick="showPortfolioValuesGraph(this)">&#128200;</button> ' ;

     bmess+='<b>Portfolio values </b>';

     if (simInvParams['scenarioUse']!='') bmess+='(&#127760;   using  <span title="using this scenario (future state-of-the-world)" style="text-decoration:underline">'+simInvParams['scenarioUse']+'</span>)';


     bmess+='<span  id="portfolioTableTopRow"> ';

// this is shown if quickDisplay (using html table of dislay results that was read from localStorage) is being used
      bmess+='<span  id="iQuickDisplay" title="quickDisplay being used to calculate values"  xclass="cQuickDisplay" style="display:none;border:1px dotted green;color:green">';
      bmess+='<button title="What is quick display?" onclick="displayHelpMessage(this)" data-div="#portfolioQuickDisplay">?</button>';
      bmess+='<span  id="iQuickDisplay2">quickDisplay!</span>';
      bmess+='&nbsp; <button title="Do a Full Calculation of portfolio values ...!!" onClick="showAllPortfolioValuesStart(0,0,2)"> &#128497;</button> ';
      bmess+='</span>  ';

// other info
     if (useInfAdjust!=0 || showValuesInterp!=0 ) {
         if (useInfAdjust!==0) bmess+='<span style="font-style:italic;background-color:#eaf8fb;margin:3px 2em;padding:1px 5px"> inflation adjusted</span>  ';
         if (showValuesInterp!=0) {
             bmess+='<span title="interpolation used to calculate values"  class="cInterploatedValue" style="border:1px dotted brown;color:brown">';
             bmess+='<button title="What is interpolation?" onclick="displayHelpMessage(this)" data-div="#portfolioValuesInterpolate1">?</button>';
            bmess+='interpolated values';
            bmess+='</span>  ';
         }
         bmess+='</span>';
     }   // useinf or interp

     bmess+='<span style="margin-top:-6px;float:right;margin-right:1.0em">';

     bmess+='<span>';
     bmess+='<button class="csettingsButton"  title="save results to CSV file" data-which="summary" onClick="doExportImport_viewResults_menu(this)" >';
     bmess+='&Sscr;ave</button>';

     bmess+='<input type="button" value="&#119137;"  title="View notes on what is displayed in each date/portfolio cell" onClick="showV_1_notes(1)"> '   ;

     bmess+='<input type="button" value="&forall;&#9872;"   data-show="0"  title="view several summary stats: for ALL dates"  ';
     bmess+='     onClick="showAllPortfolioValues_allExtraDetails(this)" >';
     bmess+='<input type="button" value="&forall;&#10721;"   data-show="0"  title="view growth & change stats: for ALL dates"  ';
     bmess+='     onClick="showAllPortfolioValues_allChangeDetails(this)" >';
     bmess+='  <button class="cdoButtonRegular" display" title="Choose which portfolios to display" onClick="showAllPortfolioValues_pick(this)">&#9935;</button>';
     bmess+=' </span>';

     let sayReal= (useInfAdjust==1) ? ' checked ' : '  ' ;
     bmess+='<span style="margin:2px 5px;border:1px solid gray" > ';

     bmess+='<input type="hidden" value="'+useInfAdjust+'"  id="showInflationAdjustedCheck"> ';
     let arf=Date.now();
     if (useInfAdjust==1) {
         bmess+='<span data-arf1="'+arf+'" id="infAdjustCheckbox_mark"  >&#9989;</span>';
      } else {
         bmess+='<span  data-arf0="'+arf+'"  id="infAdjustCheckbox_mark" style="display:none">&#9989;</span>';
      }
      bmess+='<input type="hidden" value="'+useInfAdjust+'" id="useInfAdjust_id">';
      bmess+='<button class="cdoButtonRegular" id="infAdjustCheckbox"  title="Display using real (inflation adjusted) values" onClick="showAllPortfolioValues_infAdj(1)">&real;eal values</button>';
      bmess+='</span>';
      bmess+='</span>';  // float right

     bmess+='</div>';

     bmess+='<div id="infAdjust_wait" class="cInfAdjWait" style="display:none">Please wait for inflation calculations .... </div>';

// ....... notes (displaye in popup) on what is displayed in eahc display table cell
     bmess+='<div id="ishow_v1_notes"  class="cShowV1Notes" style="display:none">';
     bmess+='<input type="button" value="x" onClick="$(\'#ishow_v1_notes\').hide()" >';
     bmess+='<input type="button" value="&neArr;"    data-id="ishow_v1_notes" onClick="displayInWindow(this)">';

     bmess+='<em>Description of Displayed values</em>';
     bmess+='<menu>';
     bmess+='<li> <b>xxx</b> : net portfolio value (rounded to nearest k$).  <u>Cash</u> + value of all assets. After taxes and loan repayments) ';
     bmess+='<li> <span class="cportfolioTable1_nassets">n</span> :  #assets (stocks, regular and tax-deferred bonds, properties, incomes, annuities, expenses, oneoffs)';
     bmess+='<li> <span style="color:#1e5b06;" title="Pre-tax yearly net cash flow (as of this date) --   property rents and loan payments, incomes and  annuities, and expenses "> '
     bmess+='xx.x</span> ';
     bmess+='<li><button>Cash</button> balance -- click for details on asset mix &amp; cashflow.';
     bmess+='  <span style="background-color:lime;color:darkgreen">large positive</span>  ';
     bmess+=' |  <span style="color:green">positive</span>';
     bmess+=' |  <span style="color:red">negative</span> ';
     bmess+=' |  <span style="background-color:yellow;color:red">large negative</span> ';

     bmess+='<li><button>&#10721;</button> : click to view details on growth and modifications  in this period';
     bmess+='</menu>';

     let iconSay=getAssetType('*iconsLong');

     bmess+='<em>details on asset mix &amp; cashflow</em>';
     bmess+='<menu>';
     bmess+='<li><span style="color:blue">Value: xxxx </span>  : net value of portfolio (to the dollar)';
     bmess+= '<br><span style="color:blue"> [xxxx] </span>: value of <u>Cash</u> (to the dollar). Uses the formatting described above. ';
     bmess+='<li><span style="color:blue">~netAssets: xxxx  </span> : net (after tax and loan paybacks) of assets (not including <u>Cash</u>)';
     bmess+='<br> <span style="color:blue">(xxx)  </span>  : gross (pre tax and loan paybacks)      ';
     bmess+='<li><span style="color:blue">Assets:</span>  : number of each kind of assets: ';
     for (let iarf=0;iarf<8;iarf++) {
         if (iarf==6) continue;
         bmess+='<span class="cAssetAllList">'+iconSay[iarf]+'</span> ' ;
      }
      bmess+='<span class="cAssetAllList">'+iconSay[6]+'</span>   ';

     bmess+='<li><span style="color:blue">cashFlow:</span> : yearly (as of this date) net change in <u>Cash</u> ';
     bmess+=' <br> &nbsp;&nbsp;&nbsp; <span style="color:green">in:</span> -- amount (and source) of additions to <u>Cash</u>';
     bmess+=' <br> &nbsp;&nbsp;&nbsp; <span style="color:green">out:</span> -- amount (and source) of deductions from <u>Cash</u>';
     bmess+='</menu>';


     bmess+='<em> details on growth and modifications </em> in this period';
     bmess+='<menu>';
     bmess+='<li><span style="border:1px solid gray;border-radius:3px">days since most recent modification (or initialization) entry</span> -- the timespan of this period! ';
     bmess+='<li> <u>&#916;Cash</u> : Change in <u>Cash</u> during this period<br>';
     bmess+='Sum of: bond additions &amp; RMDs, property rents and loan payments, income, annuities, oneOffs ... and within period interest growth on these ';
     bmess+='<li><b>Revenue</b> : <tt>net</tt> revenue from property rents, income, and annuities  ';
     bmess+='<br> <tt>(tax=xx)</tt> : tax paid (net is after this tax payment)  ';
     bmess+='<li>Loans: <span style="color:red">pay=xxx, balance=xxx</span> : Loan payments this period, and loan balance on this date ';
     bmess+='<li>oneOffsRecieved: <span style="color:green">oneOffsRecieved</span> Value of oneOffsReceeved during this period (on 2nd day of period) : <tt>aa bb </tt> list of these oneOffs (if any)';
     bmess+='</menu>';

     bmess+='<em> if this is a modification entry .... the changes </em> in this period. Changes are applied after within-period growth is calculated';
     bmess+='<menu>';
     bmess+='<li> <tt>&#916;Cash</tt> : Change in <u>Cash</u> due to modifications to the asset mix';
     bmess+='<br><tt>&#916;totSales </tt> : Additions to <u>Cash</u> due to sale of assets (after tax) ';
     bmess+='<br><tt>&#916;totPurchases </tt> : Subtractions from <u>Cash</u> due to purchase of assets (includes possible tax offsets)';
     bmess+='<li><tt>New</tt> : list of newly acquired (purchased) assets';
     bmess+='<li><tt>Changed</tt> : list of modified assets (partial sale, or an increase)';
     bmess+='<li><tt>Removed</tt> : list of removed  (sold) assets';
     bmess+='<li><span style="color:green">oneOffsPending</span> : value, and list of pending oneOffs  -- that will be received the next day';
      bmess+='</menu>';


     bmess+=' </div>';

     bmess+='<div id="portfolioTableNotes1" style="padding-left:2%;background-color:#dfefdf;display:none">';
     bmess+='<button onClick="$(\'#portfolioTableNotes1\').hide()"  title="Notes on values, and buttons, in portfolio values table " style="margin:right:4em;color:blue"> &#119136; </button> '
     bmess+='<b>netValue</b>';
     bmess+='   <span title="#assets / #incomes " style="margin-right:1em;border:1px dotted gray;font-size:90%">#assets / # incomeStreams.</span>';
     bmess+='<span style="color:#1e5b06;margin-right:1em;" title="Yearly cash flow= (income +  Rent) - loanPayments"><tt>netRevenueYearly </tt></span>';
     bmess+=' &Verbar;  <span  style="color:blue">View &hellip;</span> ';
     bmess+=' <button title="current summary">&#9872;</button> &amp; <button title="growth summary">&#10721;</button> summaries';
     bmess+=' &vellip;  <button>&#128366;</button> timeTrend of assets  ';
     bmess+=' &vellip;  <button>&#127553;</button>    portfolio assetMix ';

     bmess+='</div>';   // end of "header above table"

     bmess+='<div  class="cportfolioValuesTableDiv"  id="portfolioValuesTableDiv">';

// header row has portfolio names (and "show details" button)
// first column has viewDates (and "show details" button)

      bmess+='<table border="1" id="portfolioValuesTable" width="'+tableWidth+'" class="cportfolioValuesTable">';

// doPorts is "local global"   -- list of all unHidden portfolios, with their entry (init & mod) dates

      bmess+='<colgroup>';
      bmess+='<col style="color:blue" title="Date">';
         for (let ijj=0;ijj<doPorts.length;ijj++) {
         let ij2=ijj+1;
         bmess+='<col data-nth="'+ij2+'" data-origwidth="'+useCellWidth+'" title="Portfolio: '+doPorts[ijj]+'" style="color:green;font-size:200%;visibility:visible">';
     }
     bmess+='</colgroup>';

// top row: portfolio names

      bmess+='<tr >';

      bmess+='<th class="freezeRow1Col1_vt" style="height:32px"  bgcolor="#fdf6c3"  width="'+firstColWidth+'px">';
      bmess=='<div  style="overflow:auto">';
      bmess+='<button  title="Expand to fill window"  data-id="mainDiv" data-id2="portfolioValuesTableDiv" data-full="0" onClick="fillTheWindow(this)"  ';
      bmess+=' style="color:blue;padding:3px;font-weight:600;margin:1px 3px 1px 3px"> ';
      bmess+='&#128468;</button>';
      bmess+='<input type="button" value="&#8998;" title="toggle view of empty rows" onClick="showAllPortfolioValues_toggleEmpty(this)" data-on="0" >';
      bmess+='&nbsp;&nbsp;  <span title="You can add ,or remove, dates using viewDates">date</span>';
      bmess+='</div>';
      bmess+='</th>';    // leftmost "date" coluimn

      let oof1=setEntryDate(true);
      let nowDate=oof1['dayCount'];  // used for CPI calculation

      for (ip=0;ip<doPorts.length;ip++) {
         let pname =doPorts[ip];
         let ith=doPortsLookup[pname];

         let adesc=portfolioList[ith]['desc'];
         let pstuff=portfolioLookup['list'][pname];
         let nhistory=pstuff['nHistory'];
         let nmods=nhistory-1 ;  // portoflioInit is [0]
         let nAnyDateAsset=pstuff['nAnyDateAsset'];
         let seeD1='';

         seeD1+='<button ';
         if (showValuesInterp==1) {

            if (!simInvDsets['viewDates_dataStore_index'].hasOwnProperty(pname)) {
               seeD1+=' title="Calculate full (non-interpolated values), and display detailed info on '+nAnyDateAsset+' assets in this portfolio, for all dates "  ';
               seeD1+= '   onClick="showAllPortfolioValues_viewAssetsOverTime(this)" data-name="'+pname+'"  class="viewAssetsOverTimeButtons viewAssetsOverTimeButtons_hilite" >';
            } else {
               seeD1+=' title=" Re-display detailed info on '+nAnyDateAsset+' assets in this portfolio, for all dates "  ';
               seeD1+= '   onClick="showAllPortfolioValues_viewAssetsOverTime(this)" data-name="'+pname+'"  class="viewAssetsOverTimeButtons " >';
            }
         } else {
            seeD1+=' title=" Display detailed info on '+nAnyDateAsset+' assets in this portfolio, for all dates "  ';
            seeD1+= '   onClick="showAllPortfolioValues_viewAssetsOverTime(this)" data-name="'+pname+'"  class="viewAssetsOverTimeButtons " >';
         }
          seeD1+='&#128366; ('+nAnyDateAsset+')';
          seeD1+='</button>';
         seeD1+=' <input value="&#127553; '+nmods+' " type="button" title="View this portfolio\'s entries (init + '+nmods+' modifications)"  ';
         seeD1+='      onClick="showAllPortfolioValues_viewEntry(this)" data-ith="0" data-var="" data-name="'+pname+'" >';
         let desc2=' <span style="padding:2px 6px;max-width:10em;overflow:none;font-size:80%;font-weight:400;text-style:oblique"> '+adesc+'</span>';

         bmess+='<th  width="'+useCellWidth+'px" class="freezeRow1_vt" style="height:32px"  data-origwidth="'+useCellWidth+'px">';
         bmess+='<div  style="width:12em">  '+seeD1+'<span title="'+adesc+'"> '+pname ;
         bmess+=desc2 ;
         bmess+='</div>';
         bmess+='</th>';
      }      // this column (one col per portfolio)

      bmess+='</tr>';   // doports  ...  end of portfolio name/desc header row

// row 2 ---   some creation info  on the porfolios

     bmess+='<tr style="white-space:nowrap">';
     bmess+='<td class="freezeRow2Col1_vt"   style="top:41px"  bgcolor="#f0ecd1"  xwidth="30">';
     bmess+='<div style="overflow:auto">';
     bmess+='<span style="overflow:auto;margin-right:1em"><em>Date / startBudget</em></span>';
     bmess+='</div></td>';

     for (let ip=0;ip<doPorts.length;ip++) {
         let pname=doPorts[ip];
         let alook=portfolioLookup['list'][pname];
         let creationDateSay=alook['creationDateSay'];
         let origBudget=alook['origBudget'];;
         if (origBudget<200000) {
           origBudget=wsurvey.addComma(parseInt(origBudget));
         } else {
           origBudget= wsurvey.makeNumberK(parseInt(origBudget),100000,0) ;
         }
        bmess+='<td class="freezeRow2_vt" style="top:41px">  <div style="overflow:auto;scrollbar-width: thin;"  ><tt>'+creationDateSay+' / $'+origBudget+'</tt></div></td>';
     }   // column for this portfolio (date and origbudget)
     bmess+='</tr>';


     return bmess ;   // header above table,  portfolio name row,  initDate & budget row

 }    //   showV_1    intrnal function


//  ..........
// create the display data (for each portfolio/date)... returns in object
// doPorts is "global to funtion"
// jthDate aqn vLentth only used for progress bar updating
// note this uses "global to function" doPorts  -- values calculated for each portrolio in doPorts
  function showV_2(aviewDate,jthDate,vLength) {

       simInvSummaryResults['wstatus']=[jthDate,vLength];  // set global
       $('#showAllPortfolioValues_status1').html('Date # '+jthDate);

       let oofX2=setEntryDate(aviewDate);
       let sayDate=oofX2['sayDate'];

       dataStore1={};

       for (let ip=0;ip<doPorts.length;ip++) {       // list of active portfolios
          let pname=doPorts[ip];
          dataStore1[pname]={};
          dataStore1[pname]['dateSay']= sayDate ;

          let ztmp=showAllPortfolioValues_makeEntry(pname,aviewDate );  // THIS DOES THE WORK -- eventually calling growPortoflioDo  (step 2)  !!!!!!!!

          dataStore1[pname]['data']=ztmp;

        }                 // PORTFOLIOS

        return dataStore1 ;  // one 'row' (one date) with all portoflios in own columns
  }   //  showV_2   intrnal function


//====================
// fill in missing info in  simInvDsets['showValues_summary1'] using interpolation.
// uses  simInvDsets['showValues_summary1_index]
function showV_2_interp(ifoo) {

// variables that are  unchanged (they are inherited from the "base" init or mod entry
let keepVars={'nBond':true,'nStock':true,'nRegular':true,
          'nTaxDefer':true,'nProperty':true,'nIncomeStream':true,
          'nAnnuity':true,'nIncomeAnnuity':true,'nExpense':true,
          'nLoan':true,'nRentPos':true,'nRentNeg':true,
          'totOneOffsReceived':true,'oneOffListUsed':true,
          'totLoanOriginal':true,'totLoanPayYear':true,'totYearlyLoan':true,
          'dateMatch':true  };


// variables to interpolate  (:values are just fillers)
     let toDoVars={'totYearlyIncome':0,'totYearlyAnnuity':0,
          'totYearlyRentPos':0,'totYearlyRentNeg':0,
          'totYearlyRevenue':0,'totYearlyRevenueAT':0,'totYearlyExpense':0,'totYearlyExpenseAT':0,
          'totPortfolioValue':0,'cashAsset':0,'totAssetSale':0,'totAssetSaleNetAT':0,
          'cashChange':0,'totRevenuePeriod_AT':0,'totTaxOnRevenuePeriod':0,'totExpensePeriod_AT':0,
          'totLoanPayPeriod':0,'totLoanPayPeriod_AT':0,'totLoanOwed':0}  ;

// set to 0 (since this is NEVER a mod or an init
   let set0s={'oneOffListPending':[],'totOneOffPending':0,'nOneOffPending':0,
          'modCashChange':0,'totSales':0,'totPurchases':0,
          'qInitEntry':false,'qModEntry':false,'theModEntry':false,
          'mod_newList':[],'mod_removeList':[],'mod_changeList':[]};

   let vLength=doViewDates.length;
   let nInterp=0;
   let useBaseEntry=false;   // start with init entry (set below)
   let useBaseDate=false;
   let qNoChange=false;  // semi deprecated 10 april 2024
    let useBaseDates={},useBaseEntrys={};
    let anyQAfterLast=false,afterLastNotes=[]; ;

    for (let jthDate=0;jthDate<vLength;jthDate++) {         // one row for each date .. each col is a portfolio on that datee
       let aviewDate=doViewDates[jthDate];
       let qAfterLast=false ;
       for (let ip=0;ip<doPorts.length;ip++) {       // list of active portfolios

          let pname=doPorts[ip];

          let modDates=portfolioLookup['list'][pname]['modDates'];
          if (modDates.length==0 || aviewDate<modDates[0]  ) continue ;  // before first or after last, so no data

          if (simInvDsets['showValues_summary1'].hasOwnProperty(pname)) {          // an already calculated entry date (init, mod, or custom)
             if (simInvDsets['showValues_summary1'][pname].hasOwnProperty(aviewDate)) continue ;
          }                // else.... doesn't already exist

          let alist0=simInvDsets['showValues_summary1_index'][pname];
          let i1=find_closestDate(alist0,aviewDate) ;
          if (i1<0 ) {
            showDebug(alist0,qNoChange+' showV_2_interp error: '+aviewDate+' before first summary1 date for '+pname,1);
            continue;
          }
          if (i1>=alist0.length-1   ) {             // after last date, so just use  last date info
            qAfterLast=true;
            anyQAfterLast=true;
            let pp=pname+' on '+aviewDate+' &ge; '+alist0[alist0.length-1]
            afterLastNotes.push(pp);  // 'Portfolio '+pname+' / '+aviewDate+' after '+alist[alist0.length-1] ) ;

//             simInv_notes(oog) ;
//          showDebug(alist0,qNoChange+' showV_2_interp error: '+aviewDate+' after  last summary1 date for '+pname,1);
//            continue ;
          }

          let date1=alist0[i1];
          let date2=date1;
          if (!qAfterLast) date2=alist0[i1+1];

          if (!qAfterLast && !simInvDsets['showValues_summary1'][pname].hasOwnProperty(date1))  {
            alert('showV_2_interp error: '+aviewDate+' after '+date1+' but no entry for this date in summary1 (for '+pname);
            continue;
          }
          if (!qAfterLast && !simInvDsets['showValues_summary1'][pname].hasOwnProperty(date2))  {
            alert('showV_2_interp error: '+aviewDate+' after '+date2+' but no entry for this date in summary1 (for '+pname);
            continue;
          }

          let data1=simInvDsets['showValues_summary1'][pname][date1];
          if (data1['qInitEntry'])  {
              useBaseEntrys[pname]=0;
              useBaseDates[pname]=data1['dateGrownFrom'];
          } else if (data1['qModEntry']) {
              useBaseEntrys[pname]=data1['theModEntry'];
              useBaseDates[pname]=date1 ;
          }

          let data2=simInvDsets['showValues_summary1'][pname][date2];

          let newData=JSON.parse(JSON.stringify(data1));   // start with copy of earlier entry (the   unchanged variables are retained)
          for (let a0 in set0s) newData[a0]=set0s[a0];     // set some to zero or [] (i.e.; change attributes, since interpolated are NEVER init or mod entries

          let growDays1=aviewDate-date1 ;
          let cfrac=growDays1/(date2-date1) ;
          newData['growDays']=growDays1 ;

          for (let ado in toDoVars) {               // interpolate some variables
              let v1=data1[ado],v2=data2[ado];
              let vrange=v2-v1;
              let xx=vrange*cfrac;
              newData[ado]=v1+xx ;
          }

// special cases
    newData['qInitEntry']=false ;
    newData['qModEntry']=false ;
    newData['theModEntry']=false ;
    newData['theBaseEntry']=useBaseEntrys[pname] ;
    newData['theBaseDate']=useBaseDates[pname] ;

//  cashAsset
        let v1=data1['cashAsset'];
        let v2=data2['cashGrow']['endCash'];
        let vrange=v2-v1;
        let xx=vrange*cfrac;
        newData['cashAsset']=v1+xx ;

// growDays
        newData['growDaysStupid']=newData['growDays'];
        let growDaysB=aviewDate-  useBaseDates[pname] ;
        newData['growDays']=growDaysB ;

        newData['isInterp']=date1+' '+date2+' '+cfrac.toFixed(4);
        newData['interpValues']=true;
        simInvDsets['showValues_summary1'][pname][aviewDate]=newData;  // save interpoloated values to cache
        nInterp++ ;

      }     //  portfolio
   }     // date

   if (anyQAfterLast) {
          $('#iWarningsButton').show();
          $('#iWarningsButton').attr('data-what','lastDateIssue');
          let oof3=afterLastNotes.join(',');
          $('#iWarningsButton').attr('data-info',oof3);

   }

  return nInterp ;

}          //useBaseDate


// ------------------------      growdays
// create object with variables to display, for use by v_4
function showV_3_B(aviewDate,amult,justvars)  {
  if (arguments.length<2) justvars=0;

// false: not subject to inflation correttion, true is subject
   let useVarsRef={'theBaseEntry':false, 'theModEntry':false,
          'qInitEntry':false,  'qModEntry':false,
          'isInterp':false,
          'dateMatch':false,
          'growDays':false,
          'totPortfolioValue':true,         'cashAsset':true,
          'nBond':false,'nStock':false,          'nRegular':false,          'nTaxDefer':false,
          'nProperty':false,          'nIncomeStream':false,          'nAnnuity':false,
          'nIncomeAnnuity':false,          'nExpense':false,          'nLoan':false,
          'nRentPos':false,          'nRentNeg':false,
          'totOneOffsReceived':true,          'oneOffListUsed':false,          'oneOffListPending':false,
          'totReceiptPeriod':true,
          'totOneOffPending':true,          'nOneOffPending':false,
          'totYearlyIncome':true,          'totYearlyAnnuity':true,
          'totYearlyRentPos':true,          'totYearlyRentNeg':true,
          'totYearlyRevenue':true,          'totYearlyRevenueAT':true,
          'totLoanOriginal':true,           'totLoanPayYear':true,          'totYearlyLoan':false,
          'totYearlyExpense':true, 'totYearlyExpenseAT':true,
          'totAssetSale':true,              'totAssetSaleNetAT':true,
          'cashChange':true,
          'totExpensePeriod_AT':true,
          'totRevenuePeriod_AT':true,          'totTaxOnRevenuePeriod':true,
          'totLoanPayPeriod':true,             'totLoanPayPeriod_AT':true,          'totLoanOwed':true,
          'modCashChange':false,
          'totSales':true,                    'totPurchases':true,
          'mod_newList':false,                 'mod_removeList':false,          'mod_changeList':false};

  if (justvars==1) return useVarsRef ;

   let displayVars={} ;

// renames
   let dofinds={'mod_newList':'newList','mod_removeList':'removeList','mod_changeList':'changeList',
               'totYearlyLoan':'totLoanPayYear','cashChange':'change' };

   for (let ip2=0;ip2<doPorts.length;ip2++) {
       let apname=doPorts[ip2];
       if (!simInvDsets['showValues_summary1'].hasOwnProperty(apname)) {
          alert('showValues_summary1 error: no such portoflio   '+apname);
          continue ;
       }
       if (!simInvDsets['showValues_summary1'][apname].hasOwnProperty(aviewDate)) {    // check for all the needed (displyable) variables
              displayVars[apname]=false ;
       } else {                  // summary1 data exists for this portfolio/date
         let useVars={},errs=[] ;
         let use1=simInvDsets['showValues_summary1'][apname][aviewDate] ;
         for (let avv0 in useVarsRef) {           // the needed variables
            let avv= (dofinds.hasOwnProperty(avv0)) ? dofinds[avv0] : avv0 ;    // rename?
            let bmult=(useVarsRef[avv0]===true) ? amult : false  ;
            if (use1.hasOwnProperty(avv))  {
               let avv2= (bmult===false) ? use1[avv] : use1[avv]*bmult;
               useVars[avv0]=avv2;
            } else if (use1['changes'].hasOwnProperty(avv)) {
               let avv2= (bmult===false) ? use1['changes'][avv] : use1['changes'][avv]*bmult;
                 useVars[avv0]=avv2;
            } else if (use1['cashGrow'].hasOwnProperty(avv)) {
               let avv2= (bmult===false) ? use1['cashGrow'][avv] : use1['cashGrow'][avv]*bmult;
               useVars[avv0]=avv2;
            } else {
                errs.push(avv);
            }      // not   in summary1
         }     // useVarsRef
         if (errs.length>0) {
            showDebug(errs,'Misspecification of variables in showV_3_B',1);
         } else {
           displayVars[apname]=useVars;
         }
       }    // viewdate
   }      // doports
   return displayVars ;


}

// .............  ..............
// display viewDates (one row per date, one col per portoflio
// uses doPorts and dataStore "global to function" vars
// 20 march 2024 : aamult always 1.0 (inf adjustment now done in v_3b)

function showV_4(rdata,aamult,nowDate,aviewDate) {
   let bmess='';

   let iconList=getAssetType('*icons');
   let iconSayLong=getAssetType('*sayLong');
    let viewDateSay=setEntryDate(aviewDate).sayDate ;

   for (let apname in rdata) {
       let a1Data=rdata[apname];
       if  (a1Data===false) {
           bmess+='<td><span title="Before this portfolio\' initialization"> &vellip; </span> </td>';
           continue ;
       }

       let dateMatch= a1Data['dateMatch'];
       if  (dateMatch===false) {
           bmess+='<td><span title="Before this portfolio\' initialization"> &vellip; </span> </td>';
           continue ;
       }

       let theBaseEntry=a1Data['theBaseEntry'];
       let theModEntry=a1Data['theModEntry'];
       let qInitEntry= a1Data['qInitEntry'];
       let qModEntry= a1Data['qModEntry'];

       let oofD= setEntryDate(dateMatch)  ;
       let dateMatchSay=oofD.sayDate ;
       let growDays=a1Data['growDays'] ;

       let tdclass=' class="viewPortfolioCell_td " ' , tdTitle='' ;

//       if (theModEntry!==false)  {             // matches an entry (init or mod)
       if (qInitEntry || qModEntry) {
            if (qInitEntry) {
              tdclass=' class="cEntryClass0 viewPortfolioCell_td" ' ;
              tdTitle='This is the initialization (creation) entry ('+dateMatchSay+')   ';
            }  else {
              tdclass=' class="cEntryClass viewPortfolioCell_td" ' ;
              tdTitle='This is modification entry #  '+theModEntry+' ( growth of '+dateMatchSay+') ';
            }
       } else {         // not exact match (so grow from a closest init or mod entry)
            if (theBaseEntry===0) {
              tdTitle='Growing the  initialization (creation) ('+dateMatchSay+') for '+growDays+' days'  ;
            }  else {
              tdTitle='Growing modification entry # '+theBaseEntry+'  ('+dateMatchSay+')  for '+growDays+' days' ;
            }
       }

// ..... extract a number of displayable variables ...

      let totPortfolioValue= parseInt(a1Data['totPortfolioValue'] *aamult);
      let cashAsset= parseInt(a1Data['cashAsset'] *aamult);
      let nBond=a1Data['nBond'];      // 1 and 2
      let nStock=a1Data['nStock'];  // 0
      let nRegular=a1Data['nRegular'];   //1
      let nTaxDefer=a1Data['nTaxDefer'];    //2
      let nProperty=a1Data['nProperty'];       // 3
      let nIncomeStream=a1Data['nIncomeStream'];    //4
      let nAnnuity=a1Data['nAnnuity'];     //5
      let nIncomeAnnuity=nIncomeStream+nAnnuity ;   // 4 + 5
      let nExpense=a1Data['nExpense'];           // 7
      let nLoan=a1Data['nLoan'];             // from 3
      let nRentPos=a1Data['nRentPos'];       // from 3
      let nRentNeg=a1Data['nRentNeg'];       // from 3
      let totYearlyIncome=parseInt(a1Data['totYearlyIncome']*aamult );
      let totYearlyAnnuity=parseInt(a1Data['totYearlyAnnuity']*aamult );
      let totYearlyRentPos=parseInt(a1Data['totYearlyRentPos']*aamult );
      let totYearlyRentNeg=parseInt(a1Data['totYearlyRentNeg']*aamult );
      let totYearlyRevenue=parseInt(a1Data['totYearlyRevenue']*aamult );
      let totYearlyRevenueAT=a1Data['totYearlyRevenueAT']*aamult ;
      let totLoanOriginal=a1Data['totLoanOriginal']*aamult   ;
      let totLoanPayYear=a1Data['totLoanPayYear']*aamult ;
      let totYearlyLoan=parseInt(a1Data['totLoanPayYear']*aamult );
      let totYearlyExpense=parseInt(a1Data['totYearlyExpense']*aamult );
      let totYearlyExpenseAT=parseInt(a1Data['totYearlyExpenseAT']*aamult );
      let totAssetSale=parseInt(a1Data['totAssetSale'] *aamult);
      let totAssetSaleNetAT=parseInt(a1Data['totAssetSaleNetAT']*aamult );
      let totRevenuePeriod_AT=parseInt(a1Data['totRevenuePeriod_AT']*aamult  );
      let totTaxOnRevenuePeriod=parseInt(a1Data['totTaxOnRevenuePeriod']*aamult  );
      let totExpensePeriod_AT=parseInt(a1Data['totExpensePeriod_AT']*aamult  );
      let totLoanPayPeriod=parseInt(a1Data['totLoanPayPeriod']*aamult  );
      let totLoanPayPeriod_AT=parseInt(a1Data['totLoanPayPeriod_AT']*aamult  );
      let totLoanOwed=parseInt(a1Data['totLoanOwed']*aamult  );
      let cashChange=parseInt(a1Data['cashChange'] *aamult)  ;
      let totOneOffsReceived=a1Data['totOneOffsReceived'];
      let oneOffListUsed=a1Data['oneOffListUsed'];
      let modCashChange=parseInt(a1Data['modCashChange']  );    // changes   due to sales & purchase of a modification
      let totSales=parseInt(a1Data['totSales']  );
      let totPurchases=parseInt(a1Data['totPurchases']  );
      let mod_newList=  a1Data['mod_newList'] ;
      let mod_removeList= a1Data['mod_removeList']
      let mod_changeList=a1Data['mod_changeList'] ;
      let oneOffListPending=a1Data['oneOffListPending'] ;
      let totOneOffPending=parseInt(a1Data['totOneOffPending'])*aamult ;
      let nOneOffPending=a1Data['nOneOffPending'] ;                    // 6

      let isInterp =jQuery.trim(a1Data['isInterp']) ;

// done extracting variables        a1Data
//  ... now create some intermediate displayable  variables .... and create HTML content to display them  ...

   let totYearlyCashInflow= totYearlyIncome+totYearlyAnnuity+totYearlyRentPos ;
   let totYearlyCashOutflow = totYearlyLoan +totYearlyExpense+Math.abs(totYearlyRentNeg)   ;
   let totYearlyCashFlow=totYearlyCashInflow-totYearlyCashOutflow  ;

   let nBondStock=nBond+nStock ;
   let nAssetAll=nBondStock+nProperty+nIncomeAnnuity+nExpense ;
   let assetAllList=['<span class="cAssetAllList"    title="# of '+iconSayLong[0]+'  in portfolio">',iconList[0],nStock, '</span> ' ,
                      ' <span class="cAssetAllList"  title="# of '+iconSayLong[1]+' in portfolio">' ,iconList[1],nRegular,'</span> ' ,
                      ' <span class="cAssetAllList"  title="# of '+iconSayLong[2]+' in portfolio">' ,iconList[2],nTaxDefer,'</span> ' ,
                      ' <span class="cAssetAllList"  title="# of '+iconSayLong[3]+' in portfolio">' ,iconList[3],nProperty,'</span> ' ,
                      ' <span class="cAssetAllList"  title="# of '+iconSayLong[4]+' in portfolio">' ,iconList[4],nIncomeStream,' </span>' ,
                      ' <span class="cAssetAllList"  title="# of '+iconSayLong[5]+' in portfolio">' ,iconList[5],nAnnuity,'</span> ' ,
                      ' <span class="cAssetAllList"  title="# of '+iconSayLong[7]+' in portfolio">' ,iconList[7],nExpense,'</span> '] ;
    let nAssetAll2=nAssetAll ;

    if (nOneOffPending>0) {
       nAssetAll2=nAssetAll2+nOneOffPending;
       assetAllList.push('<span  class="cAssetAllList"  style="font-weight:700"  title="pending (distributed the next day) oneoffs" >');
       assetAllList.push(iconList[6]);
       assetAllList.push(nOneOffPending);
       assetAllList.push('</span>');
    }

    let assetAllListSay=assetAllList.join(' ');

    let totValueSay=wsurvey.makeNumberK(totPortfolioValue,60000);
    let totValueSay2=wsurvey.makeNumberK(totPortfolioValue,160000);

    let bsay='<span class="cportfolioTable1_netValue" title="net portfolio value (\'Cash\' + liquidating all assets: after taxes and loan repayments): '+ totPortfolioValue.toFixed(0) +'" >';
    bsay+=totValueSay;
    bsay+='</span>';
    if (isInterp!='0') {                              // cal;culated using interpolatin
      bsay+='<span title="Interpolated:'+isInterp+'"  class="cInterploatedValue">&#8778;</span> ';
     } else {
      bsay+='<span title="not interpolated"  class="cInterploatedValue">&nbsp;</span> ';
     }

    if (nAssetAll==nAssetAll2) {
      if (theModEntry===false) {
         bsay+=' <span  class="cportfolioTable1_nassets" title="#entries (stocks, regular and tax-deferred bonds, properties, incomes, annuities, expenses"> &nbsp;'+nAssetAll +'</span> ';
      } else {
         bsay+=' <span  class="cportfolioTable1_nassets" title="#entries (stocks, regular and tax-deferred bonds, properties, incomes, annuities, expenses (no oneOffs were added)"> &nbsp;'+nAssetAll +'</span> ';
      }
    } else {
      bsay+=' <span  class="cportfolioTable1_nassets" ';
      bsay+=' title="#entries (stocks, regular and tax-deferred bonds, properties, incomes, annuities, expenses, and  newly added oneOffs\n Receipts from newly added oneoffs are added to \'Cash\' the next day"> &nbsp;'+nAssetAll2 +'</span> ';
    }

    let totYearlyCashFlowSay=wsurvey.makeNumberK(totYearlyCashFlow,1000);
    let bb1=nIncomeStream+' incomes | '+nAnnuity +' annuities  ';
    if (nRentPos>0) bb1+=' | '+  nRentPos+' properties with positive rents ';
    let bb2= nLoan+' loans | '+nExpense +' expenses ';
    if (nRentNeg>0) bb2+=' | '+  nRentNeg+'  title="properties with negative rents ';

    let bb1B=nIncomeStream+' '+iconList[4]+' | '+nAnnuity +' '+iconList[5] ;
    if (nRentPos>0) bb1B+=' | '+  nRentPos+'  <span title="properties with positive rents">rents</span>';
    let bb2B= nLoan+' loans | '+nExpense +' '+iconList[7]  ;
    if (nRentNeg>0) bb2B+=' | '+  nRentNeg+' <span  style="color:red" title="properties with negative rents">rents</span>';

    bsay+=' <span style="color:#1e5b06;" title="Pre-tax yearly net cash flow (as of this date): ';
    bsay+=    totYearlyCashInflow+' ('+bb1+')  minus '+totYearlyCashOutflow+' ('+bb2+')"> ';
    bsay+=    totYearlyCashFlowSay+'</tt></span>   ';

    let totYearlyCashInflowSay=wsurvey.makeNumberK(totYearlyCashInflow,10000);
    let totYearlyCashOutflowSay=wsurvey.makeNumberK(totYearlyCashOutflow,10000);
    let bCashFlow='in: '+totYearlyCashInflowSay+ ' ('+bb1B+') | out: '+totYearlyCashOutflowSay+ ' ('+bb2B+') ';  // used in smmary

    bmess+='<td  width="'+useCellWidth+'px" dog="Fido" style="width:'+useCellWidth+'px" '+tdclass+' title="'+tdTitle+'\n'+viewDateSay+'  [' +apname+']" >'+bsay ;

    let cashAssetSay= wsurvey.makeNumberK(cashAsset,10000);
    let cashAssetSay2= wsurvey.makeNumberK(cashAsset,100000);

    let aflag=' <span title="The \'Cash\' balance is equal, or close, to 0.00">&#8773; '+cashAssetSay+'</span> ';
    let cFrac=cashAsset/totPortfolioValue;
    let ccstyle='';
    if (cFrac>simInvParams['budgetRemainPct']) {
        if (cFrac<0.1) {
           ccstyle=' color:green; ';
           aflag=' <span title="You have a positive amount in \'Cash\': '+cashAsset+'" style="color:green">&#9872; '+cashAssetSay+'</span> ';
       } else {
           ccstyle='  background-color:lime;color:darkgreen; ';
           aflag=' <span title="You have a large positive amount in \'Cash\': '+cashAsset+' " style="background-color:lime;color:darkgreen">&#9872; '+cashAssetSay+'</span> ';
       }
    } else if (cFrac<-simInvParams['budgetRemainPct']) {
            if (cFrac<-0.1) {
               ccstyle=' background-color:yellow;color:red; ';
              aflag=' <span title="You have a large negative  amount in \'Cash\': '+cashAsset+' " style="background-color:yellow;color:red">&#9872  '+cashAssetSay+'</span> ';
           } else {
               ccstyle=' color:red; ';
             aflag=' <span title="You have a negative  amount in \'Cash\': '+cashAsset+' " style="color:red">&#9872;  '+cashAssetSay+'</span> ';
           }
    }
    bmess+=' <span style="float:right;margin-right:0.5em">';
    bmess+='<button title="click for a short summary" onClick="showAllPortfolioValues_summary(this)">'+aflag+'</button>' ;
    bmess+='<button title="View changes since closest modification (or initialization)"  onClick="showAllPortfolioValues_changes(this)">&#10721;</button>';
    bmess+='</span>';

    let asummary='';

    asummary+=' <ul   class="noButtonMenu">';

    asummary+='<li><span title="Portfolio value, including \'Cash\'  -- after tax, after loan payouts" style="border-bottom:1px dotted blue;font-weight:600">Value<tt>: <tt>'+totValueSay2 +'</tt></tt></span>';
    asummary+=' <span title="\'Cash\'" style="font-size:80%;margin-left:0.2em;'+ccstyle+'">['+cashAssetSay2+']</span>';

    let totAssetSaleSay=wsurvey.makeNumberK(totAssetSale,40000);
    let totAssetSaleNetATSay=wsurvey.makeNumberK(totAssetSaleNetAT,40000);

    asummary+='<li> <span title="Net (after-tax, after loan payout) value" style="padding-left:0.2em;border-bottom:1px dotted blue;font-weight:500">~net assets:<tt> '+totAssetSaleNetATSay+'</tt></span>';
    asummary+=' (<span title="Gross (pre-tax, pre loan payout) value" style="font-size:90%"><tt>'+totAssetSaleSay+'</tt>)</span>';
    asummary+='<li><div>Assets: <span style="font-size:80%;color:brown;">'+  assetAllListSay+'</span></div>' ;
    asummary+='<li><div>cashFlow/yr: <span style="font-size:80%;color:#1e5b06;">'+bCashFlow+'</span></div>';
    asummary+='</ul>';

    bmess+='<div name="viewPortfolioCell_summary" style="display:none">'+asummary+'</div> ';

    achanges='<br>';

    if (theModEntry===false) {         // just a growth
      if (theBaseEntry===0) {
             achanges+=' <span style="border:1px solid gray;border-radius:3px">  '+growDays+' days after init</span> ';
      } else {
             achanges+='  <span style="border:1px solid gray;border-radius:3px">  '+growDays+' days after mod #'+theBaseEntry+'</span> ';
      }
    } else {          // modifications after growth
       if (theBaseEntry===0 && theModEntry==0) {
            achanges+='<em>The initialization entry</em> ';
       } else {
           achanges+='<em>Modification #   '+theModEntry+'  </em>   ' ;
       }
    }

    if (qInitEntry===false  ) {     //   not an init

       achanges+=' <b>Growth</b> ';
       if (theModEntry!==false) achanges+=' (<em>'+growDays+' after '+dateMatchSay+' </em>) ';
       achanges+=' <ul class="tighterMenu">';

       achanges+='<li><span title="Change \'Cash\' during this period: due to  bond additions & RMDs, property rents and loan payments, income, annuities, oneOffs ... and within period interest growth on these">';
       achanges+='<tt>&#916;<u>Cash</u>= '+wsurvey.makeNumberK(cashChange,30000)+'</tt></span>';  // &delta;cash

       achanges+='<li>Revenue: <span title="After tax revenue in this period (income, annuities, rents)">';
       achanges+='<tt>net= '+wsurvey.makeNumberK(totRevenuePeriod_AT,10000)+'</tt></span>';
       achanges+=' (tax= <span title="Taxes paid ...">'+wsurvey.makeNumberK(totTaxOnRevenuePeriod,10000)+')</span>';

       achanges+='<li>Loans: ';
       achanges+='<span title="After tax loan payments in this period: principal and interest.\n Pre tax='+totLoanPayPeriod.toFixed(0)+'"  ';
       achanges+='     style="color:#f77f7f;border-bottom:1px dotted blue "> ';
       achanges+=  '  pay= <tt>'+wsurvey.makeNumberK(totLoanPayPeriod_AT,20000) +'</tt></span> ';
       achanges+='  <span title="Remaining balance on all loans"  ';
       achanges+=      ' style="color:red;border-bottom:1px dotted blue;font-weight:500">';
       achanges+='   balance= <tt>'+ wsurvey.makeNumberK(totLoanOwed,10000)+'</tt>';
       achanges+='  </span> ';
       achanges+='</span>';


       let totOneOffsReceivedSay=wsurvey.makeNumberK(totOneOffsReceived,10000)  ;
       let ttcolor=(totOneOffsReceived<0) ? '#f77ff7' : '#7fa77f';
       achanges+='<li>';
       achanges+=' <span  style="color:'+ttcolor+';border-bottom:1px dotted blue" title="oneOffs received (after Tax, on day after prior entry)">';
       achanges+=  ' oneOffsReceived</span>=<tt>'+totOneOffsReceivedSay+'</tt> : ';

       let oneOffListUsedSay=oneOffListUsed.join(' ');
       achanges+='  <span style="font-size:85%">'+oneOffListUsedSay+'</span>';
       achanges+='</span>';

       achanges+='</ul>';

    }       // qInitEntry

// changes since prior (a mod entry)
    if (qModEntry!==false) {

      let mixNew0=[],mixRemove0=[];
      for (let aa in  mod_newList) mixNew0.push(aa);
      for (let aa in  mod_removeList) mixRemove0.push(aa);

      let mixNew=mixNew0.join(' | ');
      let mixRemove=mixRemove0.join(' | ');

      let mixChanges=mod_changeList.join(' | ');

      achanges+=' <b>Changes</b> (<em>after growth</em>) ';
      achanges+=' <ul class="tighterMenu">';
      achanges+='<li>&#916;<u>Cash</u> '+wsurvey.makeNumberK(modCashChange,10000) ;
      achanges+='<li>&#916;<u>totSales</u> <span title="'+totSales.toFixed(0)+'">'+wsurvey.makeNumberK(totSales,10000)+'</span>' ;
      achanges+=' &amp; <u>totPurchases</u> <span title="'+totPurchases.toFixed(0)+'">'+wsurvey.makeNumberK(totPurchases,10000)+'</span>' ;
      achanges+='<li>New: <span style="font-size:85%">'+mixNew;
      achanges+='<li>Changed: <span style="font-size:85%"> '+mixChanges;
      achanges+='<li>Removed: <span style="font-size:85%">'+mixRemove+'</span>';

      let oneOffPendingListSay =oneOffListPending.join(' | ');
      let totOneOffPendingSay=wsurvey.makeNumberK(totOneOffPending,10000)  ;
      let ttcolor=(totOneOffPending<0) ? '#f77ff7' : '#7fa7f';

      achanges+='<li><span style="color:'+ttcolor+';border-bottom:1px dotted blue" title="After tax value of \'pending\' oneOffs (will be added the next day)">oneOffsPending </span>';
      achanges+=' <tt>'+totOneOffPendingSay+'</tt> : <span style="font-size:85%">'+oneOffPendingListSay+'</span>';
      achanges+='</ul>';
    }          // qModEntry

// other stuff...
    if (qInitEntry  ) {          // exact match to init entry
         achanges+='  <ul class="tighterMenu">';
         let cashAssetBegin=cashAsset;                   // no growth!

         achanges+='<li><span  > Yearly revenue (after tax) amounts: <tt>'+wsurvey.makeNumberK(totYearlyRevenueAT,140000)+'</tt></span>' ;
         achanges+='<li><span  >Total loan amounts: <tt>'+wsurvey.makeNumberK(totLoanOriginal,400000)+'</tt></span>' ;
         achanges+='<li><span  >Yearly loan payments (not including tax benefits): <tt>'+wsurvey.makeNumberK(totLoanPayYear,50000)+'</tt></span>' ;

         let oneOffPendingListSay =oneOffListPending.join(' | ');
         let totOneOffPendingSay=wsurvey.makeNumberK(totOneOffPending,10000)  ;
         let ttcolor=(totOneOffPending<0) ? '#f77ff7' : '#7fa7f' ;

         achanges+='<li><span style="color:'+ttcolor+';border-bottom:1px dotted blue"  ';
         achanges+='    title="After tax value of \`pending\` oneOffs (that will be added the next day)">oneOffsPending ';
         achanges+='</span>';

         achanges+=' <tt>'+totOneOffPendingSay+'</tt> : <span style="font-size:85%">'+oneOffPendingListSay+'</span>';
         achanges+='</ul>';

     }              // a mod or a between

     bmess+='<div name="viewPortfolioCell_changes" style="display:none">'+achanges+'</div> ';
     bmess+='</td>';

   }    // this portfolio column

   return bmess;
 }     // showV_4 internal function

}  //     showAllPortfolioValues     doPorts

//=====================
// highlight a row
function highlightThisRow(athis) {
   let ethis=wsurvey.argJquery(athis) ;
   let etr=ethis.closest('tr');
   let ison=ethis.attr('data-mark');
   if (ison==0) {
      etr.addClass('highlightRow');
      ethis.attr('data-mark',1);
      ethis.css({'color':'blue'});
   } else {
      etr.removeClass('highlightRow');
      ethis.attr('data-mark',0);
      ethis.css({'color':'#252429'});
   }
}



//================================
// display notes in popup (on what is displayed in each cell of the display table)
// this is NOT an internal function (it is called via button click)
function showV_1_notes(ii) {
  $('#ishow_v1_notes').toggle();
}



//===================
// extract summary1 info
function   showAllPortfolioValues_getSummary(useInfAdjust)  {
  if (arguments.length<2) useInfAdjust=0;

   let useRows=[],showVars;
   let nowDate ;
   let noCpiAdj0=['nAsset','nStock','nBond','nRegular','nExpense','nTaxDefer','nProperty','nIncome','nLoan','nIncomeStream',
                  'nAnnuity','nOneOff'];
   let noCpiAdj={};
   for (let ino=0;ino<noCpiAdj0.length;ino++) {
       noCpiAdj[noCpiAdj0[ino]]=1;
   }
 
   let oof1=setEntryDate(true);
   nowDate=oof1['dayCount'];  // used for CPI calculation
   let nowDateSay=oof1.sayDate ;
   showVars=['date','scenario','portfolio','dateSay','theModEntry','cpi_'+nowDateSay,'cpi','totPortfolioValue','cashAsset'];

   let q1=true;


// find summary vars
   let tvars={};

   for (let adate in simInvDsets['viewDates_dataStore']) {
      for (let aportfolio in simInvDsets['viewDates_dataStore'][adate]) {
        if (simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['dateMatch']===false) continue ; // no info for this portfolio on this date
        let alist=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['entry']['summary']['totals'] ;
        for (let avar in alist) {
          if (!tvars.hasOwnProperty(avar)) tvars[avar]=1;
       }
     }
   }

   let tlist=[];
   for (let tvar in tvars) {
     showVars.push(tvar);
     tlist.push(tvar);
   }

   tlist2=showVars;
   useRows.push(tlist2);            // header row (list of variables)

   for (let adate in simInvDsets['viewDates_dataStore']) {
      let oof3=setEntryDate(adate);
      let dateSay=oof3.sayDate ;
      for (let aportfolio in simInvDsets['viewDates_dataStore'][adate]) {
        if (simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['dateMatch']===false) continue ; // no info for this portfolio on this date
        let theModEntry=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['theModEntry'] ;
        if (theModEntry===false) theModEntry=0 ;


        let aline;
        let cpiV=calcInflation(nowDate,adate,1);

        let cpiThisDate=cpiV[2];
        let acpi=1.0 ;
        if (useInfAdjust==1)  acpi=cpiV[0]; ;   // ifnlation adjustment?

        let totPortfolioValue=doExportImport_valueSay(simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['totPortfolioValue'] ,'na',acpi);
        let cashAsset=doExportImport_valueSay(simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['cashAsset'],'n.a.',acpi);

       let ascenario=simInvParams['scenarioUse'];
       aline=[adate,ascenario,aportfolio,dateSay,theModEntry,acpi,cpiThisDate,totPortfolioValue,cashAsset] ;

        let alist=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['entry']['summary']['totals'] ;
        for (let  ik=0;ik<tlist.length;ik++) {     // to ensure col order does not change
             let avar=tlist[ik];
             let acpiU=acpi ;
             if (noCpiAdj.hasOwnProperty(avar)) acpiU=1.0;   // don't adjust counts
             let aval=doExportImport_valueSay(alist[avar],'false',acpiU);
             aline.push(aval);
        }

        let aline2;
        aline2=aline;
        useRows.push(aline2);
      }
   }
   return useRows ;

}


//------------------------  =====================

// sleep for ms seconds ... just for info purposes returns measured milliseconds of setTimeout
function sleepQ(ms) {
  let d1=Date.now();
  return new Promise( (resolve) =>
      setTimeout(function() {
        let d2=Date.now(); let dd=d2-d1;
        resolve(dd) ;        // return measured elapsed time
      },
      ms));
}


//======================
// create a viewDate entry for a portfolio -- either read and tweak existing (init or mod), or build a new one
// returns object with current status  (asset mix, porfolie values, etc) for date=aviewDate of portfolio=pname
//
// 9 March 2024: the following are created (portoflioCalcValue), but have a value of false.
//    entry.assets.assetName.  oneOffReceipt_pending and oneOffDate are always false; since .assets NEVER includes oneoff assetss (though assetList does)
//
// Notes: "period" is the time this portoflio/date has grown -- the "growDays"  (from dateMatch to viewDate)
//         "pending" oneoffs are oneoffs just added to a portfolio (if this is an init or mod date). Their value has NOT yet been added
//         "received" oneoffs are oneoffs whose value is "received" during this period -- on the first day after the entry (init or mod) date
//           The "received" value is the same for all days of the period (from the day after the "dateMatch" up to and inluding the viewDate)
//           Thus: the "recieved" oneOffs are shown as "growth" on the date of the modEntry AFTER the oneOFf was added -- BUT not on the next day
//                 (the list of "pending" assets will NOT include oneOffs recieved during the period of growth leading to viewDate)
//         Special cases occur for init entries -- since there can NOT be growth, some pending oneoff info is stored where received oneoff info is typically stored
//
//  return  grwEntryZ ... an object with "displayable" data on a portfolio/date. 
//  grwEntryZ is mostly tweaking stuff returned by growPortfolioDo
//  Its properties:
//
//   name: portfolio name
//   viewDate : as of this date
//   viewDateSay   : string of viewDate
//   theBaseEntry : entry to "grow". 0:init, 1: mod #1, etc.
//   theModEntry : entry to create. 0:init, etc. If false, just grow. If 0, this a "create the init entry". If >0, this is a "create mod # n"
//                 Note:   initEntry if  theBaseEntry===0 && theModEntry===0,   modEntry  if  theModEntry!==false && theModEntry>0 ;
//   dateMatch : the date of theBaseEntry
//   growDays : days of growth (viewDate-dateMatch). If 0, this is a refresh of an existing entry
//   totPortoflioValue : after tax, after loan payback, total portoflioValue (including Cash)
//   cashAsset :    value of Cash (can be negative0
//   nAsset : # of bonds+stocks+properties   BEFORE changes
//   nIncome : # of assets that are income or annuities    BEFORE changes
//   entry :  object with a number of propertes that detail the assets
//      assetList:  array of asset names,  in this portfolio on viewDate -- AFTER changes.
//              Includes "pending" oneOffs (if this is an init or mod entry)
//      assets :  object by assetName -- each object has attributes of the asset (type, #shares, value, loan info, etc)  - after growth and after changes
//      summary: summary of the current assets. Includes properties:
//               totals: -- object with per "year" and other summary stats, aggregated over all assets.
//                          Includes info on  "received" oneoffs (totOneOffReceipt_received)
//               totPeriod --  object with summary stats on revenue etc within the period
//               summaryGrowth -- summary stats on growth of the assets. false if this is an "init" entry
//                                contains some info on received oneOffs
//               summaryChanges  -- summary stats on changes (modifications). false if this is NOT a mod entry.
//                        Includes details on pending oneOffs;  and  what assets were retained, changed, removed, or added
//                         For pending oneoff info:  totOneOffReceipts, and oneOffListNew
//               cashObj : information on changes to the Cash asset due to growtn -- includes endCash (including Cash impacts of changes)
//               sumByTypePeriod : information on after growth (before changes) total asset values by "type" of asset; and for all received oneoffs
//                                 special case: if this is an "init" entry -- oneOffListUsed is the list of "pending" assets (value recieved the next day)
//               assetGrowths:  object, properties are the assets (not including oneOffs). Details on growth (during period) of each asset
//                             includes oneOffs received (during this period)
//                                      Special case: if init entry, assetGrowths is the list of "pending" oneOffs.
//                               For each asset: includes details on "Cash additions" due in this period due to thist asset
//                               (ie; loan payments, RMDS, income & expenses)
//
//  And --  simInvDsets['showValues_summary1'] global is filled (by growPortfolioDo), with a subset of this information

function  showAllPortfolioValues_makeEntry(pname,aviewDate) {

  let oof1=setEntryDate(aviewDate);
  let aviewDateSay=oof1.sayDate ;

  let grwEntry={'name':pname,'viewDate':aviewDate,'viewDateSay':aviewDateSay,
                 'theBaseEntry':false,  'theModEntry':false,
                 'dateMatch':false,'growDays':false,
                 'totPortfolioValue':false,'cashAsset':false,
                 'nAsset':false,'nIncome':false,
                 'entry':{}};
      grwEntry['entry']['assetList']=[];
      grwEntry['entry']['assets']={} ;
      grwEntry['entry']['summary']={} ;
      grwEntry['entry']['summary']['totals']={} ;
      grwEntry['entry']['summary']['totPeriod']={} ;
      grwEntry['entry']['summary']['summaryGrowth']=false ;
      grwEntry['entry']['assetGrowths']={} ;
      grwEntry['entry']['summary']['summaryChanges']=false ;

  let modDates=portfolioLookup['list'][pname]['modDates'];

// too soon ???
   if (modDates.length==0 || aviewDate<modDates[0]) {       // no init of mod info, or before init
       return grwEntry ;  // before first, so no data
    }

// is the desired data the init or a mod entry?

  let useEntry=false,useDate0=false,useDatePrior=false ;
  let useEntryPrior,theBaseEntry,theModEntry  ;
  let qIsMod=false,qIsInit=false;

  i1=jQuery.inArray(aviewDate,modDates) ;
  if (i1>-1)  {               // matches an existing portfolio/date entry
      useDate0=aviewDate ;
      let ddate=false;
      if (i1==0) {                  // the init entry
         useEntry=portfolioInit[pname];
         theBaseEntry=0 ;
         theModEntry=0;
         qIsInit=true;
      } else {                    // a mod entry
        useEntry=portfolioModifications[pname][aviewDate];   // this will be the used to make the modifications (after growing useEntryPrior)
        theBaseEntry=i1-1;;
        theModEntry=i1 ;
        qIsMod=true;

        useDatePrior=modDates[theBaseEntry] ;     // which entry is grown?
        if (theBaseEntry===0) {
           useEntryPrior=portfolioInit[pname];         // this entry is grown
        } else {                    // a mod entry
           useEntryPrior=portfolioModifications[pname][useDatePrior];   // this entry is grown
        }
      }

  } else {                  //   not an exact match -- so grow the "closest" entry

    jjMatch=find_closestDate(modDates,aviewDate);  // find the mod (or init) closest (just before)  aviewDate -- will NOT be equal (given above)

    theBaseEntry=jjMatch;
    theModEntry=false;

    useDate0=modDates[jjMatch] ;
    if (jjMatch===0)   {
       useEntry=portfolioInit[pname];
    } else {
      useEntry=portfolioModifications[pname][useDate0];
    }
  }

// useEntry (and perans useENtryPRior) is simply the asset list -- size of each asset in a portfolio mix -- from the saved init and mod entries
// It is NOT the "grown" init and mod entries create when simInv starts

//   tweak existing init or mod entry, or grown an intermediate entry (from nearest entry)

// These do the work (step 3)
  let grwEntryZ ;  // tweaked version of grwEntry from stuff in useEntryPrior, useEntry, etc
  if (qIsInit) {
       grwEntryZ=showAllPortfolioValues_makeEntry_init(pname,grwEntry,useDate0,aviewDate,useEntry)  ;    // grwEntry is changed in place (pass s by reference)
  } else if (qIsMod) {    // a mod match
       grwEntryZ= showAllPortfolioValues_makeEntry_mod(pname,grwEntry,useDatePrior,useDate0,useEntryPrior,useEntry,theBaseEntry,theModEntry)  ;    // useEntry has start and end date (endDate=viewdate)
  }  else {
       grwEntryZ=showAllPortfolioValues_makeEntry_2(pname,grwEntry,useDate0,aviewDate,useEntry,false,theBaseEntry,theModEntry)  ;   //  direct call
  }
  grwEntryZ['theModEntry']=theModEntry ;
  grwEntryZ['theBaseEntry']=theBaseEntry ;

  return grwEntryZ;
}

//-====================
// this does the work, step 4 (of 5)
//  desired date (aviewdate) is NOT an init or mod entry, this is used dircely
// otherwise, it is called and then mdofied
//   theBaseEntry:  entry  # to be grown and perhaps modified.
//   theModEntry: entry # to save, after growth AND modifiication. If 0, init entry.
//                   If false, no modification.
// IF theBaseEntry=0 and theModEntry=0 --- rebuild init (so NO growth and NO modification)


function showAllPortfolioValues_makeEntry_2(pname,grwEntryA,useDate0,aviewDate,useEntry,modEntry,theBaseEntry,theModEntry) {

   let  grwEntry1=grwEntryA ;

   grwEntry1['theBaseEntry']=theBaseEntry;
   grwEntry1['theModEntry']=theModEntry;
   grwEntry1['dateMatch']=useDate0;

   let growDays ;
   if (theBaseEntry===0 && theModEntry===0 ) {       // rebuild init -- so no growth
       growDays=0;
   } else {
       growDays=aviewDate-useDate0;
   }
   grwEntry1['growDays']=growDays;

  let baseCash1=useEntry['cashAsset'];            // cashasset of the entry to be grown

  let baseAssets=useEntry['assetList']  ;        // assetlist of the entry to be grown

  let modAssets=false;
  if (modEntry!==false) modAssets=modEntry['assetList'];        // if specified, the asset changes (on mod date)

   let grwEntryDo ;

// calculate growth, and possibly modifications. Might read from cache if already done!
   grwEntryDo=growPortfolioDo(pname,baseAssets,baseCash1,useDate0,modAssets,aviewDate,'showAllPortfolioValues',theBaseEntry,theModEntry);  // DO THE WORK 5 of 5 :

// Note : growPortfolioDo will use "cached" information info if  theModEntry is an init or mod entry

   grwEntry1['entry']['assetGrowths']= JSON.parse(JSON.stringify(grwEntryDo['grown']['growths']));
   grwEntry1['entry']['assets']=JSON.parse(JSON.stringify(grwEntryDo['grown']['assetDetails']));

   grwEntry1['entry']['summary']['cashObj']=grwEntryDo['grown']['cashChangeObj'];    // summary of each asset's day-by-day contributions to Cash (day-by-day incroproates daily interest growth)

   let sumByTypePeriod=grwEntryDo['grown']['sumByTypePeriod'];
   grwEntry1['entry']['summary']['sumByTypePeriod']=sumByTypePeriod;

   grwEntry1['entry']['summary']['totals']=JSON.parse(JSON.stringify(grwEntryDo['grown']['totals']));
   grwEntry1['entry']['summary']['totPeriod']=JSON.parse(JSON.stringify(grwEntryDo['grown']['totPeriod']));

   let ggTmp=grwEntry1['entry']['summary']['totals'] ;

   let cashAssetAfterGrowth=grwEntryDo['cashAsset'];
   grwEntry1['cashAsset']=cashAssetAfterGrowth

   grwEntry1['nAsset'] =ggTmp['nAsset'];
   grwEntry1['nIncome'] =ggTmp['nIncome'];

   let daListShort=[];
   for (let ii3=0;ii3<grwEntryDo['assetList'].length;ii3++) {
       daListShort.push(grwEntryDo['assetList'][ii3]['name']) ;
   }
   grwEntry1['entry']['assetList']=daListShort ;    // basic list of assets (details will be in ['assets']


// add some properties to ['assets']
  let dovars=['comment','addedDate','modifiedDate','addedDatePrice','addedDateCost'];
   for (let zzasset in grwEntry1['entry']['assets']) {      // add some variables from useEntry assets
      for (let itt1=0;itt1<dovars.length;itt1++) {
           avar=dovars[itt1];
           grwEntry1['entry']['assets'][zzasset][avar]=useEntry['assets'][zzasset][avar];
      }
   }

// add/replace some totals
   for (let avar in grwEntryDo['totalsNet']) {
         grwEntry1['entry']['summary']['totals'][avar]=grwEntryDo['totalsNet'][avar];
  }

  let stockTax=ggTmp['totStock'] - ggTmp['totStockAT'] ;
  let propTax=ggTmp['totPropertyNet'] - ggTmp['totPropertyNetAT'] ;
  let defTax=ggTmp['totTaxDeferred'] -ggTmp['totTaxDeferredAT'] ;

  grwEntry1['totPortfolioValue']=  grwEntry1['entry']['summary']['totals']['totPortfolioValue'] ;
  grwEntry1['entry']['summary']['totals']['propTax']= propTax ;
  grwEntry1['entry']['summary']['totals']['stockTax']= stockTax ;
  grwEntry1['entry']['summary']['totals']['totDeferredTax']= defTax ;

  if (growDays>0) {          // growth (a non init entry, perhaps a mod , perhaps a showPortfolio date)

      grwEntry1['entry']['summary']['summaryGrowth']={};
      grwEntry1['entry']['summary']['summaryGrowth']['growDays']=growDays ;
      grwEntry1['entry']['summary']['summaryGrowth']['priorDate']=useDate0 ;
      grwEntry1['entry']['summary']['summaryGrowth']['ithBase']=theBaseEntry ;
      grwEntry1['entry']['summary']['summaryGrowth']['totPortfolioValue']= grwEntryDo['totalsNet']['totPortfolioValue'];

      grwEntry1['entry']['summary']['summaryGrowth']['baseCash']=grwEntryDo['base']['cash']    ;
 
// baseReceipt:   oneoffs specified in base entry, but NOT yet recieved
// receiptPeriod: oneoffs recieved within this period (i.e.; distributed on the day after baseDate)

      grwEntry1['entry']['summary']['summaryGrowth']['nOneOffsUsed']= sumByTypePeriod['nOneOffsUsed'];
      grwEntry1['entry']['summary']['summaryGrowth']['oneOffListUsed']= sumByTypePeriod['oneOffListUsed'];
      grwEntry1['entry']['summary']['summaryGrowth']['totOneOffReceipt_received']=sumByTypePeriod['totReceiptPeriod'];;
      grwEntry1['entry']['summary']['totals']['totOneOffReceipt_received']=sumByTypePeriod['totReceiptPeriod'] ;

  }             // else, 0 day gap so no growth

  return grwEntry1  ;

}


// ========================  summaryGrowth
// for init entries   -- same as non-exact match

function showAllPortfolioValues_makeEntry_init(pname,grwEntry,useDate0,aviewDate,useEntry ) {

  let grwEntryB=showAllPortfolioValues_makeEntry_2(pname,grwEntry,useDate0,aviewDate,useEntry,false,0,0 )  ;    // return the init entry
  return grwEntryB ;

}

// ========================
// for mod entries
// modifies (called by reference) newEntry

function showAllPortfolioValues_makeEntry_mod(pname,grwEntry,startDate,endDate, useEntry,modEntry,theBaseEntry,theModEntry) {

// first: grow the "prior" entry

 let grwEntryC=showAllPortfolioValues_makeEntry_2(pname,grwEntry,startDate,endDate,useEntry,modEntry,theBaseEntry,theModEntry )  ;

// and fix some stuff

   for (let basset in grwEntry['entry']['assets']) {
       let atype=grwEntry['entry']['assets'][basset]['assetType'];
        if (atype==3) {
             let arefi=false;
             if (modEntry['summaryChanges'].hasOwnProperty('refiList') &&  modEntry['summaryChanges']['refiList'].hasOwnProperty(basset)) {
                arefi=modEntry['summaryChanges']['refiList'][basset] ;
             }
             if (grwEntry['entry']['assets'][basset].hasOwnProperty('loanSchedule') && grwEntry['entry']['assets'][basset]['loanSchedule']!==false) {
                    grwEntry['entry']['assets'][basset]['loanSchedule']['refiCost']= arefi ;
             }
        }   //

   }

   grwEntryC['entry']['summary']['summaryChanges']=JSON.parse(JSON.stringify(modEntry['summaryChanges']));


   return grwEntryC;
}

//=======
// fix height of portfolioValuesTableDiv in mainDIv2 in maindiv
// add delays to let dom settle

function fixmyheight_maindiv(iter) {

    if (iter>15) return 0 ;   // give up after 10 tries

    let h2,h3;
    let  iter0=iter-1;
    let af1=Math.pow(0.99,iter0);
    afact=0.986*af1 ;

    let emain=$('#mainDiv');
    let emain2=$('#mainDiv2');
    let etable= $('#portfolioValuesTableDiv');

    let heightMain=parseInt(emain.height());

    let etop=$('#portfolioTableTopRow');     // small header row (inflation note)
    let topH=(etop.length>0) ? etop.height() : 0 ;

    h2=parseInt(heightMain*afact);
    emain2.height(h2);

    h3=(h2-(1.05*topH))*0.99 ;
    h3=parseInt(h3);
    etable.height(h3);

    let  qq=wsurvey.isScrollable(emain);
    if (qq===false)  {
       return 1;          // otherwise shrink some more
    }
    window.setTimeout(function(){        // tryagain after 50 millisced delay
       iter2=iter+1;
       fixmyheight_maindiv(iter2) ;
     },50);

     return 0;

}

//=========================
// make lookup tables for summary1 values, save   to  simInvDsets['showValues_summary1_index]
// this index is mostly used in the interpolation step (if interpolation is chosen)

function   showValues_summary1_makeIndex(ifoo) {
  let allDates={},firstDate=1111111111111111,lastDate=-1111111111111;
 
  simInvDsets['showValues_summary1_index']={};
  for (let ap1 in  simInvDsets['showValues_summary1']) {
    if (portfolioLookup['list'][ap1]['isHidden']==1 || portfolioLookup['list'][ap1]['nHistory']==0) continue ;      // skip hidden portofliods
    let list1=[];
    for (let idate in simInvDsets['showValues_summary1'][ap1])  {
        if (!allDates.hasOwnProperty(idate)) allDates[idate]=[];
        allDates[idate].push(ap1)
        list1.push(idate)
        firstDate=Math.min(firstDate,idate);
        lastDate=Math.max(lastDate,idate);
    }
    list1.sort(mySortNumeric);
    simInvDsets['showValues_summary1_index'][ap1]=list1;
  }
   simInvDsets['showValues_summary1_index']['$all']=allDates;
   simInvDsets['showValues_summary1_index']['$firstDate']=firstDate;
   simInvDsets['showValues_summary1_index']['$lastDate']=lastDate;

  return 1;
}

//================================
// make lookup for  simInvDsets['viewDates_dataStore'] global (store as '$portfolios' property

function  showValues_dataStore_makeIndex(ifoo) {
  let clist={} ;
  for (let idate in simInvDsets['viewDates_dataStore']) {
      if (!jQuery.isNumeric(idate)) continue  ;  // should not happen
      for (let apname in simInvDsets['viewDates_dataStore'][idate]) {
          if (!clist.hasOwnProperty(apname)) clist[apname]=[];
          clist[apname].push(idate);
      }
  }
  simInvDsets['viewDates_dataStore_index']=clist;
  return 1;
}

//============         portfolioList
// display a short summary in a cell of "row 1";
function showAllPortfolioValues_summary(athis) {
   let ethis=wsurvey.argJquery(athis);
    let etd=ethis.closest('.viewPortfolioCell_td');
   let esumm=etd.find('[name="viewPortfolioCell_summary"]');
   esumm.toggle();
   return 1 ;
}
function showAllPortfolioValues_changes(athis) {
   let ethis=wsurvey.argJquery(athis);
    let etd=ethis.closest('.viewPortfolioCell_td');
   let esumm=etd.find('[name="viewPortfolioCell_changes"]');
   esumm.toggle();
   return 1 ;
}

//==============
// pick which columns (portfolios) to display
function showAllPortfolioValues_pick(athis,) {
  doPorts=[];
  let bmess='';

    bmess+='<input type="button" value="&#8704;" title="Select all portfolios" onClick="showAllPortfolioValues_pick2(0,1)" >  ';
    bmess+='<input type="button" value="&#10672;" title="De-Select all portfolios" onClick="showAllPortfolioValues_pick2(0,0)" >   ';

    bmess+='<em>Select portfolio (columns),</em> and ';
  bmess+=' then <input type="button" value="display them" onClick="showAllPortfolioValues_pick2(this)"> ';
  bmess+='<ul id="ishowAllPortfolios_pick" class="linearMenu16Pct">';
  for (ith=0;ith<portfolioList.length;ith++) {

     let iexists=portfolioList[ith]['exists'];
     if (iexists==0) continue ; // not initialized
     let isHidden=portfolioList[ith]['isHidden'];
     if (isHidden==1) continue ; // not initialized

     let pname=portfolioList[ith]['name'];
     let adesc=portfolioList[ith]['desc'];
     let pstuff=portfolioLookup['list'][pname];
     bmess+='<li><label title="Display this portfolio" ><input type="checkbox"  checked name="chooseThis" data-name="'+pname+'" >'+pname+'</label>';
     bmess+='<span title="Description..." class="cdescNoteBuildPortfolio">'+adesc+'</span>';
  }
  bmess+='</ul>';
  displayStatusMessage(bmess);
     toggleStatusMessage(0,6);
}

//==========
// display chosen columns
function showAllPortfolioValues_pick2(athis,ido) {
  if (arguments.length<2) ido=false ;
   let showThese={};

   let e1=$('#ishowAllPortfolios_pick');
   let e2=e1.find('[name="chooseThis" ]');
   let nshow=0;
   for (let ie=0;ie<e2.length;ie++) {
       let ae=$(e2[ie]);
       if (ido===false) {  // find the checked
         if (ae.prop('checked')) {
           let aname=ae.attr('data-name');
           showThese[ie+1]=1 ;       // col # (skip header col)
           nshow++;
         }
       } else {  // select or deselect all checkboxes
          if (ido==1) {
             ae.prop('checked',true);
          } else {
            ae.prop('checked',false);
          }
       }
   }
   if (ido!==false) return 0;

   let ediv=$('#portfolioValuesTableDiv');
   let etable=$('#portfolioValuesTable');
   let ecs=etable.find('colgroup');         // view or collapse a <col>
   let ecs2=ecs.find('col');
   let awidth0=ediv.width();

   let awidth1=awidth0-250; // a bit of a buffer (includes widht of date column)
   let tryWidth=parseInt(awidth1/nshow);

   for (let ie1=1;ie1<ecs2.length;ie1++) {
      let acol=$(ecs2[ie1]);
      let nth=acol.attr('data-nth');
      if (showThese.hasOwnProperty(nth)) {
             acol.css({'visibility':'visible'});
             let nowWidth=parseInt(acol.attr('data-origwidth'));
             let useWidth=Math.max(nowWidth,tryWidth);
             acol.attr('width',useWidth+'px');
             nshow++;
      } else {
             acol.css({'visibility':'collapse  '});
      }
    }


}

//===========================
// front end to   showAllPortfolioValues_viewAssetsOverTime -- used by showAllPortfolioValues_monitor()
function showAllPortfolioValues_viewAssetsOverTime_1arg(zargs) {
   $('#valuePortfolioButton').addClass('cdoButtonRegularBig_wow');
   simInvSummaryResults['recentDisplay']=false ;   // force recreating display table (to incorporate the freshly fullyCalculated values for this portofolio)
   showAllPortfolioValues_viewAssetsOverTime(false,zargs[0],zargs[1],zargs[2],zargs[3],zargs[4]);

}


//===========================
// view table of all assets in a portfolio, for all the viewdates.
function showAllPortfolioValues_viewAssetsOverTime(athis,doInfAdjust,aportfolio,cellWidth,ison1,ison2) {

   if (simInvGlobals['cacheStuff']['cacheDisplayResults']=='fast')  { // special case
       let smessage,smessage2;
       smessage='<img src="spinner-icon-gif-1.jpg" height="30" width="30" alt="spinner"> Please wait while simInv initializes and re-calculates your portfolios (from quickDisplay to calculated) ... ';
        smessage2='Please wait while simInv initializes and re-calculates your portfolios (from quickDisplay to calculated) ... ';
        displayStatusMessage(smessage);
        toggleStatusMessage(0,1);
        $('#progressDiv_message').html(smessage2);
        simInv_fastQuickDisplayReCalc(doInfAdjust);
        return 1;
  }


// --- using cache?  won't work... do caclutiatons
   if (simInvGlobals['cacheStuff']['usingCacheNow']===true ) {
     let time1=Date.now();
     simInvGlobals['cacheStuff']['cacheDisplayResults']='write';
     window.setTimeout(function() {         // wait a moment
         showAllPortfolioValuesStart(0,false,1);
         return 1;
      },20);
      return false ;
   }

   if (arguments.length<2) doInfAdjust=0;
   if (arguments.length<4) cellWidth=false;
   if (arguments.length<5) ison1=0;
   if (arguments.length<6) ison2=0;

   if (arguments.length<3) {
     let ethis=wsurvey.argJquery(athis);
     aportfolio=ethis.attr('data-name');
     ethis.removeClass('viewAssetsOverTimeButtons_hilite');
   }

   let sayLong=getAssetType('*sayLong');

// interpolation mode? And no prior call to this function? Need to creat,'datastore index in viewasetsover time ',1);
  if (!simInvDsets['viewDates_dataStore_index'].hasOwnProperty(aportfolio)) {
      let smessage='Creating <u>full calculations</u> for portfolio <b>'+aportfolio+'</b> ... ';
      displayStatusMessage(smessage);
      toggleStatusMessage(0,1);

      let time1=Date.now();
      simInvSummaryResults['wstatus']='' ;  // false means not being worked on , true means done, anything else is a status message
      simInvSummaryResults['wstatusStartTime']=time1;  // false means not being worked on , true means done, anything else is a status message

      let zargs1=[doInfAdjust,aportfolio,cellWidth,ison1,ison2];
      simInvSummaryResults['callFinal']=['showAllPortfolioValues_viewAssetsOverTime_1arg',zargs1];
      simInvSummaryResults['finalMessage']='<b>'+aportfolio+' </b> values have been <em>fully calculated</em>... details will now be displayed ' ;
      showAllPortfolioValues_monitor(0,time1);  // start the monitor  -- showAllPortfolioValues will end it

      window.setTimeout(function() {         // pause while dom settles
         let ahow=showAllPortfolioValues(1.0,aportfolio,2);  // this (showAllPortfolioValues_viewAssetsOverTime) is not async, so timeout function  ends almost immediately (0.1 seconds) --
      },100);               // showAllPortfolioValues is async, so it use showAllPortfolioValues_monitor() to write progress bar, etc.
       return false;
  }

   let oofDate=setEntryDate(true);
   let nowDayCount=oofDate['dayCount'];  // used for CPI calculation
   let onDetails=' ',onMoreDetails=' ',conDetails=' ',conMoreDetails=' ',onGrowthDetails='',conCompare='';
   if (ison1==1)  {
      onDetails=' style="display:block" ' ;
      conDetails=' class="cdetailsHilite" ' ;
   }
   if (ison2==1) {
     onMoreDetails=' style="display:block"  ' ;
     conMoreDetails=' class="cdetailsHilite"  ';
   }

  let firstColWidth=125;   // in px
  let secondColWidth=110;   // in px
  let minCellWidth=225 ;

   let thisStuff={};

   let allAssets=portfolioLookup['list'][aportfolio]['anyDateAsset'] ;  // all assets that appear in any (init or mod) entry of this portoflio

   let allVars={};      // info on assets in this portfolio (several attributes for various dates)
   let nassetsAll=0 ;

   for (let aa1 in allAssets) {           // for each asset that appears in any entry of this portfolio
      nassetsAll++;
      allVars[aa1]={};             // initialize (filled in by make_allVars()
      allVars[aa1]['nAppearEntries']= allAssets[aa1];   // # of  init & mod entries this asset appears in. Note that for oneOffs-- only active on entry date (ignored for inbetween dates)
      allVars[aa1]['dateList']=[];
      allVars[aa1]['dateInfo']={};
   }

// create local working var (thisStuff) that drops "too early" dates (dates before init)
  for (let adate in   simInvDsets['viewDates_dataStore']) {                 // contains dates of ALL portfolios (and calendar and custom dates, etc)
     for (let apname in  simInvDsets['viewDates_dataStore'][adate]) {
         if (apname!=aportfolio) continue ;                           // ignore other portoflioes
         if  (simInvDsets['viewDates_dataStore'][adate][apname]['data']['dateMatch']===false || simInvDsets['viewDates_dataStore'][adate][apname]['data']['entry']===false) continue; // too early
         thisStuff[adate]=simInvDsets['viewDates_dataStore'][adate][apname]['data'];  // work with this date for this portfolio
     }
  }

// build allVars -- basic info on each asset in each date (is it active, is it a oneOff, its important attributes)
  for (let adate in thisStuff) {
      make_allVars(adate);   // update allVars
  }
  for (let azz in allVars) {      // for each asset in allVars
     let dlist=JSON.parse(JSON.stringify(allVars[azz]['dateList']));
     dlist.sort(mySortNumeric);         // sort
     let wasDate=false,dlistNew=[];
     for (let mm=0;mm<dlist.length;mm++) {
       if (dlist[mm]!==wasDate) {
          wasDate=dlist[mm];
          dlistNew.push(wasDate );
       }
     }
     allVars[azz]['dateList']=dlistNew     ; // sorted, duplicates removed
  }

  let bmess='';

  let amessHeader='';
  amessHeader+='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioValuesPVInfoHelp1">&#10068;</button>';
  amessHeader+='&nbsp; <em>Details:</em>  <tt>'+nassetsAll+'</tt> assets in <span class="cPortfolioName_aot">'+aportfolio+'</span> ';
  let ascenario=simInvParams['scenarioUse'] ;
  if (ascenario!='') amessHeader+=' <em>&#127760; scenario '+ascenario+'</em> ';

  amessHeader+='<button  class="csettingsButton" onClick="showAllPortfolioValues_viewAssetsOverTime_growth(this)"  data-ison="0"  >&#129716;  growth</button> ';
  amessHeader+='<button  class="csettingsButton" onClick="showAllPortfolioValues_viewAssetsOverTime_details(this,1)" '+conDetails+' name="tableShowDetails1" data-ison="'+ison1+'" title="view cell details">&#128065;  details</button> ';
  amessHeader+='<button  class="csettingsButton"  onClick="showAllPortfolioValues_viewAssetsOverTime_details(this,2)" '+conMoreDetails+' name="tableShowDetails2"  data-ison="'+ison2+'"  title="view cell details">&#128065;&#65039; more details</button> ';
 
  let vCompare=false;

  if (simInvDsets['showValues_summary1_interp']!==false) {
      if (simInvDsets['showValues_summary1_interp'].hasOwnProperty(aportfolio)) vCompare=simInvDsets['showValues_summary1_interp'][aportfolio] ;
  }

  if (vCompare!==false) {
    amessHeader+='<button  id="iShowCompareButton" class="csettingsButton"  onClick="showAllPortfolioValues_viewAssetsOverTime_details(this,3)" '+conCompare+' name="tableShowDetails3"  data-ison="'+ison2+'"  title="show comparisons to interpolated values">&#9878;Compare</button> ';
  }

   if (doInfAdjust==0) {
      amessHeader+='<label title="display inflation adjusted values"><input  name="viewAssetsUsingInf" data-name="'+aportfolio+'" type="checkbox" onClick="showAllPortfolioValues_viewAssetsOverTime_real(this)">&real; values?</label>';
   } else {
      amessHeader+='<label title="display inflation adjusted values"><input    name="viewAssetsUsingInf"  data-name="'+aportfolio+'" checked type="checkbox" onClick="showAllPortfolioValues_viewAssetsOverTime_real(this)">&real; values?</label>';
   }
   amessHeader+='</span>';

  amessHeader+='<span style="float:right;margin-right:1em">';
  amessHeader+='<button onClick="showAllPortfolioValues_viewAssetsOverTime_cols(this,-1)" data-inf="'+doInfAdjust+'" data-name="'+aportfolio+'" title="rewrite table with narrower columns">&#128476; compress</button> ';
  amessHeader+='<button onClick="showAllPortfolioValues_viewAssetsOverTime_cols(this,1)"  data-inf="'+doInfAdjust+'" data-name="'+aportfolio+'"  title="rewrite table with wider columns">&#8660; expand</button> ';
  amessHeader+='<button class="csettingsButton"  title="export results to CSV file" data-which="details" onClick="doExportImport_viewResults_menu(this)" >';
   amessHeader+='Export</button>';

  amessHeader+='</span>';

   let estatusDiv=$('#statusDiv');
   let mainWidth=estatusDiv.width();
   let mainWidthUse= mainWidth-(2.8*firstColWidth);
   let tryCellWidth=parseInt(mainWidthUse/nassetsAll);

   let edivheader=$('#mainDivHeader');
   edivheader.css({'z-index':100});

  let useCellWidth=(cellWidth===false) ? Math.max(tryCellWidth,minCellWidth) : cellWidth ;
  let tableWidth=parseInt((nassetsAll*useCellWidth)+(3*firstColWidth)+30);     // add 10 just because

  bmess+='<div class="cportfolioValuesTableOverTimeDivOuter"   id="portfolioValuesTableOverTimeDivOuter">';
  bmess+=amessHeader ;
  bmess+='<div id="showAllPortfolioValues_viewAssetsOverTime_noteRow" class="cshowAllPortfolioValues_viewAssetsOverTime_noteRow" ';
  bmess+='  style="display:none"> </div>';

  bmess+='<div class="cportfolioValuesTableOverTimeDiv"  data-origwidth="'+useCellWidth+ '" data-expand="1.0" id="portfolioValuesTableOverTimeDiv">';

  let topRow='';

  topRow+='<tr>';

  topRow+='<td class="freezeRow1Col1_z"   data-origwidth="'+firstColWidth+'" width="'+firstColWidth+'px">';
  topRow+='<input type="button" title="notes ... " data-name="-3" value="&#119137;" onclick="showAllPortfolioValues_viewAssetsOverTime_showHeaderNote(this)"> ';
  topRow+='Date</td> ';

  topRow+='<td class="freezeRow1Col2_z"  data-origwidth="'+secondColWidth+'" width="'+secondColWidth+'">';
  topRow+='<input type="button" title="notes ... " data-name="-2" value="&#119137;" onclick="showAllPortfolioValues_viewAssetsOverTime_showHeaderNote(this)"> ';
  topRow+='<span style="font-size:80%">portfolioValue</span></td> ';

  topRow+='<td  class="freezeRow1_z cHasUseCellWidth" data-origwidth="'+useCellWidth+'" width="'+useCellWidth+'px">';
  topRow+='<input type="button" title="notes ... " data-name="-1" value="&#119137;" onclick="showAllPortfolioValues_viewAssetsOverTime_showHeaderNote(this)"> ';
  topRow+='  <u>Cash</u></td>';

  for (let avar in allVars) {        // a column for all assets that appear in an init or mod entry, even if it does NOT appear in every row of the "portfolio values" table
     let isPublic=doAssetLookup(avar,'isPublic');
     let avarUse= (isPublic==1) ? '<span style="color:brown" title="public asset">&Pscr;</span> '+avar : avar ;
     let aicon=getAssetType(avar,'iconSpan');
     topRow+='<td   class="cviewAssetsOverTime freezeRow1_z cHasUseCellWidth"  data-origwidth="'+useCellWidth+'" width="'+useCellWidth+'px">';
     topRow+='<input type="button" title="notes ... " data-name="'+avar+'" value="&#119137;" onclick="showAllPortfolioValues_viewAssetsOverTime_showHeaderNote(this)"> ';

     topRow+=aicon+' <b>'+avarUse+'</b>';
      let indates= allVars[avar]['dateList'].length;     // init & mod AND customn AND calendar
       let inentries=allVars[avar]['nAppearEntries'];
       topRow+='  ...  <span style="font-size:90%;font-family:monospace;" title="# rows this assets appears in  (# of init+mod entries containing this asset) ">'+indates+' ('+inentries+')</span>';
     topRow+='  </td>';
  }
  topRow+='<td bgcolor="#ababad"><span class="valueTableCellLast">#</span></td>';

  topRow+='</tr>';

  let amess='';
  amess+='<table cellpadding="5"  border="2" width="'+tableWidth+'"  >';
  amess+=topRow ;

// ... one row for each viewDate
  let priorCashAsset=false;
  let ithRow=0;
  let gotOneInterp=false ;
  
  for (let adate in thisStuff) {

      let idate=parseInt(adate);
      let sayDate=thisStuff[adate]['viewDateSay'];

      let thisStuffNow=thisStuff[adate];

      let totals= thisStuffNow['entry']['summary']['totals'];
      let summaryTotals=thisStuffNow['entry']['summary']['totals'] ;
      let theAssets=thisStuffNow['entry']['assets'] ;

      let summaryGrowth= (thisStuffNow['entry']['summary'].hasOwnProperty('summaryGrowth')) ?   thisStuffNow['entry']['summary']['summaryGrowth'] : false ;
      let summaryChanges= (thisStuffNow['entry']['summary'].hasOwnProperty('summaryChanges')) ?   thisStuffNow['entry']['summary']['summaryChanges'] : false ;
      let assetGrowths= thisStuffNow['entry']['assetGrowths']  ;
      let cashInfo= thisStuffNow['entry']['summary']['cashObj']  ;
      let sumByTypePeriod= thisStuffNow['entry']['summary']['sumByTypePeriod']  ;

      let acpi=calcInflation(nowDayCount,idate) ;    // cpi fator
      let aw0=calcInflation(idate,nowDayCount) ;   // deflate to current date

  // deflate to current date
      let aweight=(doInfAdjust==1) ?  aw0 : 1.0 ;

      let theBaseEntry=thisStuffNow['theBaseEntry'];
      let theModEntry=thisStuffNow['theModEntry'];
      let qInitEntry= (theBaseEntry===0 && theModEntry===0 ) ;
       let qModEntry= (theModEntry!==false && theModEntry>0) ;

      let growDays=thisStuffNow['growDays'];

      let dateMatch=thisStuffNow['dateMatch'];
      let oofD=setEntryDate(dateMatch);
      let dateMatchSay=oofD['sayDate'];

      let totPortfolioValue=thisStuffNow['totPortfolioValue']*aweight;
      let acash=thisStuffNow['cashAsset']*aweight;

      let totAssetSaleNet=totals['totAssetSaleNet']*aweight;
      let totAssetSaleNetAT=totals['totAssetSaleNetAT']*aweight;
      let totTaxOnLiquidation=totals['totTaxOnLiquidation']*aweight ;

      let qInterpVal=false;

      if (vCompare!==false) {
         qInterpVal=(vCompare[adate]['isInterp']!==0) ? true : false ;
         totPortfolioValue_interp=vCompare[adate]['totPortfolioValue']*aweight ;
         acash_interp=vCompare[adate]['cashAsset']*aweight ;
         if (qInterpVal) gotOneInterp=true;
      }

      ithRow++ ;
      amess+='<tr valign="top">';
      let acell='',acell2='',acell3='',acell4='',acell5='';

// date and CPI column
      if (theModEntry!==false) {
             if (qInitEntry) {
                acell+='<div class="cEntryClass0"  title="Initialization on '+adate+'">' ;
             } else {
                acell+='<div class="cEntryClass"  title="Modification #'+theModEntry+' on '+adate+'">  ';
             }
      } else {       // not an exact match
            acell+='<div title=" on '+adate+': after '+growDays+' growthDays of modification #'+theBaseEntry+'">  ';
      }
      acell+='<span style="padding-right:1px">'+sayDate+'</span>';
      if (doInfAdjust==1) {
        let cpiSay='<span style="padding-left:2px;float:right;margin-right:0.25em;font-size:90%;font-style:oblique;" title="CPI" >'+acpi.toFixed(2)+'</span>';
        acell+=cpiSay  ;
      }
      amess+='<td class="freezeCol1">'
      amess+='<div class="valueTableCell "  > '+acell+'</div>'

      if (growDays>0) {
         let oofP=setEntryDate(dateMatch);
         let priorDateSay=oofP['sayDate'];
         amess+='<div class="valueTableCell4" title="This periods length (days since most recent init, or modification, entry on ...) ">'+growDays+'<span style="font-size:80%"> to '+priorDateSay+'</span></span></div>';
      }
      if (qInitEntry) {
         let nmods=portfolioLookup['list'][aportfolio]['nHistory']-1 ;
         amess+='<em>w/'+nmods+' mods ...</em>';
      }

      amess+='</td>';

// portfolio value column
      totPortfolioValueSay=wsurvey.addComma(parseInt(totPortfolioValue));
      let  totPortInterp_diffSay='',cashValue_diffSay='';
      if (qInterpVal===true) {
          totPortInterp_diffSay=compare_interp(totPortfolioValue,totPortfolioValue_interp,100.0) ;
          cashValue_diffSay=compare_interp(acash,acash_interp,100.0)
      }  else {         // not interpolated ... perhaps because this was a 'full calculation' date?
          if (vCompare!==false) {
             totPortInterp_diffSay='<span class="valueTableCellCompare" style="display:none"  title="using full calculation (interpolation not done"> &Equal;</span>';
             cashValue_diffSay='<span class="valueTableCellCompare" style="display:none" title="using full calculation (interpolation not done"> &Equal;</span>';
          }  // else, no previous interpolation values

      }
      totAssetSaleNetSay=wsurvey.addComma(parseInt(totAssetSaleNet));
      totAssetSaleNetATSay=wsurvey.addComma(parseInt(totAssetSaleNetAT));
      totTaxOnLiquidationSay=wsurvey.addComma(parseInt(totTaxOnLiquidation));

      totAssetSaleNetSay2=wsurvey.makeNumberK(parseInt(totAssetSaleNet),10000);
      totAssetSaleNetATSay2=wsurvey.makeNumberK(parseInt(totAssetSaleNetAT),10000);
      totTaxOnLiquidationSay2=wsurvey.makeNumberK(parseInt(totTaxOnLiquidation),10000);

      acell2+='   '+totAssetSaleNetSay+' - '+totTaxOnLiquidationSay ;
      acell3+='assetValue ('+totAssetSaleNetATSay+') = assetSale ('+totAssetSaleNetSay+') - taxes ('+totTaxOnLiquidationSay+') ';


      amess+='<td class="freezeCol2_z">'
      amess+='<div class="valueTableCell"  >'+totPortfolioValueSay+' '+totPortInterp_diffSay+'</div>'
      amess+='<div class="valueTableCell2" '+onDetails+'  >'+acell2+'</div>'
      amess+='<div class="valueTableCell3" '+onMoreDetails+' >'+acell3+'</div>'
      amess+='</td>';

// cash column
      acell='',acell2='',acell3='',acell4='',acell5='';
      let swDay=cashInfo['swDay'] ;

      let acashSay=wsurvey.addComma(parseInt(acash))+cashValue_diffSay;
      if (acash<0) acashSay='<span style="color:red">'+acashSay+'</span>';
      if (swDay!==false) {
         acashSay+='<span style="color:brown;padding-left:1em" title="Cash switched sign after '+swDay+' days">&#128710;</span>';
      }
//      acashSay+=acash_interpSay;
      priorCashAsset=acash;

      if (!qInitEntry) {     // a  mod entry, or a non-exact match ... NOT an init entry

         let cashAssetBegin=cashInfo['startCash']*aweight;
         let cashAssetEnd1=cashInfo['endCash']*aweight;
         let cashRawAdd=cashInfo['rawAdd']*aweight;
         let cashEarn =cashInfo['earnAdd']*aweight;
         let totReceiptPeriod=sumByTypePeriod['totReceiptPeriod'];

         let  cashAssetDuring=cashRawAdd;
         let swDay=cashInfo['swDay'] ;

         let cashAssetBeginSay=wsurvey.addComma(parseInt(cashAssetBegin));
         let  cashAssetEnd1Say=wsurvey.addComma(parseInt(cashAssetEnd1));
         let  cashRawAddSay=wsurvey.addComma(parseInt(cashRawAdd));
         let  cashEarnSay=wsurvey.addComma(parseInt(cashEarn));
         let  oneOffsUsedReceipt=wsurvey.addComma(parseInt(totReceiptPeriod));
         let  cashAssetDuringSay=wsurvey.addComma(parseInt(cashAssetDuring));    // raw addition

         acell2+= cashAssetBeginSay+' + '+ cashEarnSay+'+'+cashRawAddSay  ;

         acell3+='Begin ('+cashAssetBeginSay+') +  oneOffs ('+oneOffsUsedReceipt+') ';
         acell3+=' + &Delta;period ('+cashAssetDuringSay+')  ';
         acell3+=' + interest (<span title="over '+growDays+' day period">'+cashEarnSay+')</span>  ';
         if (summaryChanges!==false) {
            let modCashChanges=summaryChanges['totCashChange'];
            let  modCashChangesSay=wsurvey.addComma(parseInt(modCashChanges));    // changs due to modifications (sales, purchases, etc)
            acell3+=' + mods  <span title="\'Cash\' changes due to modifications (sales & purchases of assets) ">'+modCashChangesSay+'</span> ';
         }
         if (swDay!==false)  {
            let oofP2=setEntryDate(swDay);
            if (summaryChanges!==false) {
               acell3+=' : swDay: <span title="Before modification: \'Cash\' sign switch near ">'+oofP2.sayDate+'</span> ';
            } else {
               acell3+=' : swDay: <span title="\'Cash\' sign switch near ">'+oofP2.sayDate+'</span> ';
            }
         }

        let totPeriod=thisStuffNow['entry']['summary']['totPeriod'];

         let allEarns=totPeriod['totIncomeBothPeriod_AT']+totPeriod['totDivIntPeriod_AT']+totPeriod['totRentPosAT'] ;
         let allPayments=totPeriod['totLoanPayPeriod_AT']+ totPeriod['totExpensePeriod_AT']+totPeriod['totRentNegAT'] ;
         let allTax=totPeriod['totTaxOnRevenuePeriod'];  // this includes taxes from  +earnings sources (but NOT future taxes on tax deferred bond interest erarnigns)

         let allEarnsSay=wsurvey.addComma(parseInt(allEarns));
         let allPaymentsSay=wsurvey.addComma(parseInt(Math.abs(allPayments)));
         let allTaxSay=wsurvey.addComma(parseInt(allTax));
         acell4+='<div style="border:1px dotted gray;margin:3px 1px;padding:2px" title="Revenues, payments, and taxes in this period\n Some, but not all, of these directly impact Cash ">';
         acell4+='<span style="padding:1px 3px;color:green" title="After tax earnings: dividends, interest on bonds, +rents, incomes, and annunities">'+allEarnsSay+'</span>'         ;
         acell4+='<span style="padding:1px 3px;color:red"  title="Payments: loans, -rents, expenses">'+allPaymentsSay+'</span>'         ;
         acell4+='<span style="padding:1px 3px;color:brown"  title="Taxes on earnings; does NOT include possible future taxes on tax-deferred bond earnings">'+allTaxSay+'</span>'         ;
         acell4+='</div>';

         if (qModEntry) {

            let tsales=summaryChanges['totSales'];
            let nsales=0;
            for (let goo in summaryChanges['saleList']) nsales++;

            let tpurchases=summaryChanges['totPurchases'];
            let npurchases=0;
            for (let goo in summaryChanges['purchaseList']) npurchases++;

            let ttax=summaryChanges['totTax'];

            let tsalesSay=wsurvey.makeNumberK(parseInt(tsales),10000);
            let tpurchaseSay=wsurvey.makeNumberK(parseInt(tpurchases),10000);
            let ttaxSay=wsurvey.makeNumberK(parseInt(ttax),10000);
            let ttaxD=summaryChanges['taxDeferred_tax'],ttaxC=summaryChanges['capGains_tax']

            acell5+='<div   title="Modifications: purchases, sales, taxes impacts " >'
            acell5+='<span style="padding:1px 3px;color:green" title="Total of '+nsales+' sales (partial or complete: '+tsales.toFixed(0)+' ">'+tsalesSay+'</span>'         ;
            acell5+='<span style="padding:1px 3px;color:red"  title="Total of '+npurchases+'  (augmenting existing, or newly added):' +tpurchases.toFixed(0)+'">'+tpurchaseSay+'</span>'         ;
            acell5+='<span style="padding:1px 3px;color:brown"  ';
            acell5+=' title="Taxes: '+ttaxC.toFixed(0)+' capital gains paid (on net sales) &amp; ' +  ttaxD.toFixed()+' tax deferred taxes (minus if tax offset)">'+ttaxSay+'</span>'         ;
            acell5+=' </div>';

         }  // qModentry

      }            // !qinitEntry

      amess+='<td  >'
      amess+='<div class="valueTableCell"  >'+acashSay+'</div>'
      amess+='<div class="valueTableCell2" '+onDetails+' >'+acell2+'</div>'
      amess+='<div class="valueTableCell3" '+onMoreDetails+' >'+acell3+'</div>'
      amess+='<div    class="valueTableCell4" '+onGrowthDetails+' >'+acell4+'</div>'
      if (acell5!=='') {
         amess+='<div class="valueTableCell4 valueTableCell5"  >'+acell5+'</div>'
      }
      amess+='</td>';

// columns for each asset     (even if never any "stuff" for it

      for (let avar in allVars) {
        if (!allVars[avar]['dateInfo'].hasOwnProperty(idate)) {       // this asset does not appear in this entry
              amess+='<td >...</td>';
              continue;
        }
        let atype=allVars[avar]['dateInfo'][idate]['type'];
        let entNum=allVars[avar]['dateInfo'][idate]['entNum'];
        let avalueNow=allVars[avar]['dateInfo'][idate]['value'];
        let avalueNowSay=wsurvey.addComma(parseInt(avalueNow));
        let avalueNow2=allVars[avar]['dateInfo'][idate]['value2'];   // after tax if tax deffered, $ value if stock. Otherwise same as avalueNow

        let isNew=allVars[avar]['dateInfo'][idate]['isNew'];
        let isChange=allVars[avar]['dateInfo'][idate]['isChange'];
        let isRemove=allVars[avar]['dateInfo'][idate]['isRemove'];

// cell content depends on type
        let acell= ' ',acell2='',acell3='',acell4='',acell5='';

        if (atype==6) {         // a oneoff (using allOneOffsGotStuffValue

              let abaseR=allVars[avar]['dateInfo'][idate]['value'];
              let abaseRSay=wsurvey.addComma(parseInt(abaseR));
              acell+=' :&#9461;: <span title="oneOff specified this period (to be added or subtracted the next day)" style="color:#523737">'+abaseRSay+'</span>' ;

        } else if (isNew==1)   {   // signals new addition
                let avXSay=wsurvey.addComma(parseInt(avalueNow));
                let avXSay2=wsurvey.addComma(parseInt(avalueNow2));
                if (atype==4 || atype==5  ) {   // revenue asset
                    acell+='<span style="color:green">:&#128496;:</span> <span title="'+sayLong[atype]+' added on this date,  with yearly revenue ..." style="color:#523737">'+avXSay+'</span>' ;
                } else if ( atype==7) {   // expanse
                    acell+='<span style="color:green">:&#128496;:</span> <span title="'+sayLong[atype]+' added on this date,  with yearly cost ..." style="color:#523737">'+avXSay+'</span>' ;
                } else if ( atype==0) {   // stock  asset

                    acell+='<span style="color:blue">:&#128496;:</span> <span title="'+sayLong[atype]+' added on this date,    '+avXSay+' shares with value..." style="color:#523737">'+avXSay2+'</span>' ;
                } else if ( atype==3) {   // property
                    acell+='<span style="color:blue">:&#128496;:</span> <span title="'+sayLong[atype]+' added on this date, with a price of ..." style="color:#523737">'+avXSay+'</span>' ;
                 } else {       // 1 and 2
                    acell+='<span style="color:blue">:&#128496;:</span> <span title="'+sayLong[atype]+' added on this date, with a pre-tax value of (post tax='+avXSay2+')" style="color:#523737">'+avXSay+'</span>' ;
                  }

        } else if (atype==0) {        // if here, existing (possibly changed) asset.

             let q=theAssets[avar]['q'];
             let price=theAssets[avar]['price']*aweight;
             let valueNet=theAssets[avar]['valueNet']*aweight;
             let valueNetAT=theAssets[avar]['valueNetAT']*aweight;
             let basis=theAssets[avar]['basis']*aweight;
             let taxOnSale=theAssets[avar]['taxOnSale']*aweight;
             let capGains=theAssets[avar]['capGains']*aweight;

             let qSay=wsurvey.addComma(parseInt(q));
               let priceSay=price.toFixed(2);
               let valueNetSay=wsurvey.addComma(parseInt(valueNet));
               let valueNetATsay=wsurvey.addComma(parseInt(valueNetAT));
               let basisSay=wsurvey.addComma(parseInt(basis));
               let capGainsSay=wsurvey.addComma(parseInt(capGains));
               let taxOnSaleSay=wsurvey.addComma(parseInt(taxOnSale));
               let priceSay2=parseInt(price);
               let qSay2=parseInt(q);
               let valueNetSay2=wsurvey.makeNumberK(parseInt(valueNet),10000);
               let basisSay2=wsurvey.makeNumberK(parseInt(basis));
               let capGainsSay2=wsurvey.makeNumberK(parseInt(capGains),10000);
               let taxOnSaleSay2=wsurvey.makeNumberK(parseInt(taxOnSaleSay),10000);

               acell+='<span title="tax on sale:'+taxOnSaleSay+'">'+valueNetATsay +'</span>';

               if (isChange==1) {                                     // used changed value
                  if (changeMatters(avalueNow,q)) {
                    acell5+='<span title="# shares after modification ">'+avalueNowSay+'</span> ' ;
                  }
               }
               if (isRemove==1) {                                     // used changed value
                    acell5+='<span style="color:#f47d16;border-radius:3px" title="All stocks sold">&#9003;</span> ' ;
               }


             acell2+=qSay2 +'*'+priceSay2+'= '+valueNetSay2+' - '+basisSay2+' = '+capGainsSay2+' &rarr; '+taxOnSaleSay2;
             acell3+='Q (' +qSay +') * P ('+priceSay+') = '+valueNetSay+' - basis ('+basisSay+') = capGains ('+capGainsSay+') &rarr; tax ('+taxOnSaleSay+')';

             if (assetGrowths.hasOwnProperty(avar)) {
               let earnPeriodAT=assetGrowths[avar]['earningsPeriodAT'];
               let earnPeriodATSay=wsurvey.addComma(parseInt(earnPeriodAT));
               let earnPeriodTax=assetGrowths[avar]['earningsTaxPeriod'];
               let earnPeriodTaxSay=wsurvey.addComma(parseInt(earnPeriodTax));
               let dq=assetGrowths[avar]['growthQ']-assetGrowths[avar]['baseQ'];
               let dqSay=dq.toFixed(1);
               acell4+='<span title="After tax dividend earnings in this period">'+earnPeriodATSay;
               acell4+=' (<span style="font-size:80%" title="tax paid">'+earnPeriodTaxSay+'</span>) ';
               acell4+='  <span title="Shares purchased with after tax earnings"> &rarr; &#916;'+dqSay+'</span>' ;
               acell4+='</span>' ;
             }

        } else if (atype==1) {
             let q=theAssets[avar]['q'] ;
             let valueNetAT=theAssets[avar]['valueNetAT']*aweight;
             let valueNetATsay=wsurvey.addComma(Math.round(valueNetAT));

              acell+='<span title="value of shares">'+valueNetATsay +'</span>';
              if (isChange==1) {                                     // used changed value
                 if (changeMatters(avalueNow,valueNetAT)) {
                     acell5+='<span title="Value after modification ">'+avalueNowSay+'</span> ';
                }
              }
               if (isRemove==1) {                                     // used changed value
                    acell5+='<span style="color:#f47d16;border-radius:3px" title="All bonds sold">&#9003;</span> ' ;
               }


             if (assetGrowths.hasOwnProperty(avar)) {
                let dgap=assetGrowths[avar]['daysGap'] ;
                if (dgap==0) {
                   acell3+=' <span title="raw additions (interest growth not accounted for)"  >n.a</span></span>' ;
                   acell4+='<span title="After tax Bond earnings in this period (starting value and additions) " style="font-family:monospace">...(<span style="font-size:80%" title="tax paid"> </span>)</span>  ';
                } else {
                   let totAddPeriodRaw= (assetGrowths[avar]['additionPeriodRaw']*aweight);
                   let totAddPeriodRawSay=wsurvey.addComma(Math.round(totAddPeriodRaw));
                   acell3+=' <span title="raw additions (interest growth not accounted for)"   >'+totAddPeriodRawSay+'</span></span>' ;

                   let startGPeriodAT= (assetGrowths[avar]['startGrowthPeriodAT']*aweight);

                   let AearnPeriodAT=assetGrowths[avar]['additions_earningsPeriodAT'];
                   let bothGrow=startGPeriodAT+ AearnPeriodAT  ;  // earnings on starting amount, and on additions (which could be negative)

                   let earnPeriodTax=assetGrowths[avar]['earningsTaxPeriod'];

                   let bothGrowSay=wsurvey.addComma(parseInt(bothGrow));
                   let earnPeriodTaxSay=wsurvey.addComma(parseInt(earnPeriodTax));
                   acell4+='<span title="After tax Bond earnings in this period (starting value and additions) " style="font-family:monospace">'+bothGrowSay+' (<span style="font-size:80%" title="tax paid">'+earnPeriodTaxSay+'</span>)</span>  ';
                }  // dgap
             }     // rowths.hasOwnProp

        } else if (atype==2) {
             let q=theAssets[avar]['q'];

             let valueNetAT=theAssets[avar]['valueNetAT']*aweight;
             let taxOnSale=theAssets[avar]['taxOnSale']*aweight;
             let valueNetATsay=wsurvey.addComma(parseInt(valueNetAT));
               let qSay=wsurvey.makeNumberK(parseInt(q));
               let taxOnSaleSay=wsurvey.addComma(parseInt(taxOnSale));
             let qSay2=wsurvey.makeNumberK(parseInt(q),10000);
               let taxOnSaleSay2=wsurvey.addComma(parseInt(taxOnSale),10000);

               acell+='<span title="Tax due (due to tax deferral):' +taxOnSaleSay+' on gross value='+qSay+'">'+valueNetATsay +'</span>';

                if (isChange==1) {                                     // used changed value
                    if (changeMatters(avalueNow,q)) {
                      acell5+='<span title="Gross value after modification " >'+avalueNowSay+'</span> ';
                     }
                }
               if (isRemove==1) {                                     // used changed value
                    acell5+='<span style="color:#f47d16;border-radius:3px" title="All bonds sold">&#9003;</span> ' ;
               }


             acell2+=qSay2 +' &rarr; '+taxOnSaleSay2 ;
             acell3+='Tax due:   ' +taxOnSaleSay+' on '+qSay  ;
             if (assetGrowths.hasOwnProperty(avar)) {

               let totAddPeriodRaw=assetGrowths[avar]['additionPeriodRaw']*aweight;
               let totAddPeriodRawSay=wsurvey.addComma(parseInt(totAddPeriodRaw));

               acell3+=' ; cumAdditions= <span title="raw additions (not incorporating growth of obtained/removed assets" >'+totAddPeriodRawSay+'</span>' ;
             }

             if (assetGrowths.hasOwnProperty(avar)) {
               let dgap=assetGrowths[avar]['daysGap'],earnBothSay;
               if (dgap<=0) {
                 earnBothSay='n.a.';
               } else {
                  let earnPeriod=assetGrowths[avar]['earningsPeriod'];
                  let baseEarnPeriod=assetGrowths[avar]['startGrowthPeriod'];
                  let earnBoth= earnPeriod+  baseEarnPeriod
                  earnBothSay=wsurvey.addComma(parseInt(baseEarnPeriod));
               }
               acell4+='<span title="Tax deferred bond earnings in this period (NOT accounting for additions) -- pre tax">'+earnBothSay+'</span> ';
             }

        } else if (atype==3) {

             let salePrice=theAssets[avar]['value']*aweight;
             let valueNet=theAssets[avar]['valueNet']*aweight;
             let valueNetAT=theAssets[avar]['valueNetAT']*aweight;
             let basis=theAssets[avar]['basis']*aweight;
             let taxOnSale=theAssets[avar]['taxOnSale']*aweight;
             let capGains=theAssets[avar]['capGains']*aweight;

             let loanOwed;
             if (qInitEntry) {
                  loanOwed= theAssets[avar]['loanOriginal']*aweight; ; // if  init entry -- be sure to use actual loan amount
             } else {
                  loanOwed =theAssets[avar]['loanOwed']*aweight  ;
             }
             let salePriceSay=wsurvey.addComma(parseInt(salePrice));
             let valueNetSay=wsurvey.addComma(parseInt(valueNet));
             let valueNetATsay=wsurvey.addComma(parseInt(valueNetAT));
             let basisSay=wsurvey.addComma(parseInt(basis));
             let capGainsSay=wsurvey.addComma(parseInt(capGains));
             let loanOwedSay=wsurvey.addComma(parseInt(loanOwed));
             let taxOnSaleSay=wsurvey.addComma(parseInt(taxOnSale));

             let salePriceSay2=wsurvey.makeNumberK(parseInt(salePrice),10000);
             let valueNetSay2=wsurvey.makeNumberK(parseInt(valueNet),10000);
             let basisSay2=wsurvey.makeNumberK(parseInt(basis),10000);
             let capGainsSay2=wsurvey.makeNumberK(parseInt(capGains),10000);
             let loanOwedSay2=wsurvey.makeNumberK(parseInt(loanOwed),10000);
             let taxOnSaleSay2=wsurvey.makeNumberK(parseInt(taxOnSale),10000);

             acell+=' <span title="Value before modification.\ntax on sale:'+taxOnSaleSay+'">'+valueNetATsay +'</span>';

             if (isChange==1) {
                acell5+='<span title="value after modification">'+valueNetATsay +'</span>';      // should never happend
             }
             if (isRemove==1) {                                     // used changed value
                    acell5+='<span style="color:#f47d16;border-radius:3px" title="Property sold">&#9003;</span> ' ;
             }


             acell2+=salePriceSay2+' -  '+loanOwedSay2+' =  '+valueNetSay2;
             acell2+=' &amp; &hellip;  -  '+basisSay2+' = '+capGainsSay2+' &rarr; '+taxOnSaleSay2;

             acell3+=' Sale  ('+salePriceSay+') - loanOwed ('+loanOwedSay+') =  Profit ('+valueNetSay+') | ';
             acell3+=' Sale - basis ('+basisSay+') = capGains ('+capGainsSay+') &rarr; tax ('+taxOnSaleSay+')';

             if (assetGrowths.hasOwnProperty(avar)) {

                let loanPaidAT=assetGrowths[avar]['loanPaidPeriodAT'];
                let loanPaid=assetGrowths[avar]['loanPaidPeriod'];
                let loanPrinPaidAT=assetGrowths[avar]['loanPrincipalPeriod']  ;
                let rentPeriodAT=assetGrowths[avar]['rentPeriodAT'];

                let loanPaidSay=(loanPaid!==false) ? loanPaid.toFixed(0) : '...';
                let loanPaidATSay=(loanPaidAT!==false) ? wsurvey.addComma(parseInt(loanPaidAT)): '...';
                let loanPrinPaidATSay=(loanPrinPaidAT!==false) ? wsurvey.addComma(parseInt(loanPrinPaidAT)): '...';
                let  rentPeriodATSay=(rentPeriodAT!==false) ? wsurvey.addComma(parseInt(rentPeriodAT)) : '...' ;
                acell4+='<span title="Loan this period  "  > Loan=';
                acell4+='<span title="After tax loan payments this period (principal and interest)\n Pre-tax='+loanPaidSay+'"  style="border-bottom:1px solid red">'+loanPaidATSay+'</span> (<span title="principal payment" title="font-size:80%">'+loanPrinPaidATSay+'</span>) ';
                acell4+='<span title="after tax rental earnings">, rents= '+ rentPeriodATSay+'</span>';
                acell4+='</span> ';
             }

        } else if (atype==4) {
             let yearlyRevenue=theAssets[avar]['yearlyRevenue']*aweight;
             let yearlyRevenueSay=wsurvey.addComma(parseInt(yearlyRevenue));

             acell+='<span title="pre tax yearly income " style="color:#023737"> '+yearlyRevenueSay +'</span>';
             if (isChange==1) {                              // should never happen
                 if (changeMatters(avalueNow,yearlyRevenue)) {
                   acell5+='<span title="Value after modification (pre tax yearly income) " style="color:#023737">'+avalueNowSay +'</span>';
                }
             }
             if (isRemove==1) {                                     // used changed value
                    acell5+='<span style="color:#f47d16;border-radius:3px" title="Income stream ends">&#9003;</span> ' ;
             }


              if (assetGrowths.hasOwnProperty(avar)) {
                 let incomePeriod= (assetGrowths[avar].hasOwnProperty('incomePeriodAT'))   ?  assetGrowths[avar]['incomePeriodAT'] : 0;
                  if (incomePeriod===null) incomePeriod=0;

                 let incomePeriodSay=wsurvey.addComma(parseInt(incomePeriod));

                 let incomePeriodTax ;
                if (assetGrowths[avar].hasOwnProperty('taxPeriod')) {
                   incomePeriodTax=assetGrowths[avar]['taxPeriod']   ;
                } else {
                   incomePeriodTax=assetGrowths[avar]['incomePeriod'] -  assetGrowths[avar]['incomePeriodAT'] ;
                }

                if (incomePeriodTax===null) incomePeriodTax=0;

                 let incomePeriodTaxSay=wsurvey.addComma(parseInt(incomePeriodTax));
                 acell4+='<span title="After tax Income stream earnings since beginning of period ('+growDays+' days ago) "> ';
                 acell4+= incomePeriodSay+' <span style="font-size:80%" title="tax paid">'+incomePeriodTaxSay+'</span></span>  ';
              }

        } else if (atype==7) {
             let yearlyExpense=theAssets[avar]['yearlyExpense']*aweight;
             let yearlyExpenseSay=wsurvey.addComma(parseInt(yearlyExpense));

             acell+='<span title="pre tax yearly expenses "  style="color:#023737">'+yearlyExpenseSay +'</span>';
             if (isChange==1) {                                    // should never happen
                 if (changeMatters(avalueNow,yearlyExpense)) {
                    acell5+='<span title="Value after modification (pre tax yearly expenses) " style="color:#023737">'+avalueNowSay +'</span>';
                 }
             }
             if (isRemove==1) {                                     // used changed value
                    acell5+='<span style="color:#f47d16;border-radius:3px" title="Expense ends">&#9003;</span> ' ;
             }

              if (assetGrowths.hasOwnProperty(avar)) {
                 let expensePeriod=(assetGrowths[avar].hasOwnProperty('expensePeriodAT')) ? assetGrowths[avar]['expensePeriodAT']  : 0  ;
                  if (expensePeriod===null) expensePeriod=0;
                 let expensePeriodSay=wsurvey.addComma(parseInt(expensePeriod));
                 let expensePeriodTax= (assetGrowths[avar].hasOwnProperty('taxPeriod')) ? assetGrowths[avar]['taxPeriod'] : 0 ;
                  if (expensePeriodTax===null) expensePeriodTax=0;

                 let expensePeriodTaxSay=wsurvey.addComma(parseInt(expensePeriodTax));
                 acell4+='<span title="Expense stream costs since beginning of period ('+growDays+ ' days ago)">'+expensePeriodSay+' <span style="font-size:80%" title="tax savings (from deducting this expense)">'+expensePeriodTaxSay+'</span></span>  ';
              }

        } else if (atype==5) {

             let yearlyRevenue=theAssets[avar]['yearlyRevenue']*aweight;
             let annuityBase=theAssets[avar]['annuityBase']*aweight;
             let annuityGrowth=theAssets[avar]['annuityGrowth']*aweight;

             let yearlyRevenueSay=wsurvey.addComma(parseInt(yearlyRevenue));
             let annuityBaseSay=wsurvey.addComma(parseInt(annuityBase));
             let annuityGrowthSay=annuityGrowth.toFixed(2);

             let annuityBaseSay2=wsurvey.makeNumberK(parseInt(annuityBase),10000);
             let annuityGrowthSay2=annuityGrowth.toFixed(2);

             acell+='<span title="pre tax yearly annuity "  style="color:#023737">'+yearlyRevenueSay +'</span>';

             if (isChange==1) {                                  // should never happen
               if (changeMatters(avalueNow,yearlyRevenue)) {
                  acell5+='<span title="Value after modification (pre tax yearly annuity ) "  >'+avalueNowSay +'</span>';
               }
             }
             if (isRemove==1) {                                     // used changed value
                    acell5+='<span style="color:#f47d16;border-radius:3px" title="Annuity ends">&#9003;</span> ' ;
             }


             acell2+=annuityBaseSay2+' @ '+annuityGrowthSay2;
             acell3+='Base annuity ('+annuityBaseSay+') with growth  of CPI ('+annuityGrowthSay+')';

             if (assetGrowths.hasOwnProperty(avar)) {
                let incomePeriod= (assetGrowths[avar].hasOwnProperty('incomePeriodAT'))   ?  assetGrowths[avar]['incomePeriodAT'] : 0;
                if (incomePeriod===null) incomePeriod=0;
                let incomePeriodSay=wsurvey.addComma(parseInt(incomePeriod));
                let incomePeriodTax=(assetGrowths[avar].hasOwnProperty('taxPeriod')) ? assetGrowths[avar]['taxPeriod'] : 0 ;
                if (incomePeriodTax===null) incomePeriodTax=0;
                let incomePeriodTaxSay=wsurvey.addComma(parseInt(incomePeriodTax));
                acell4+='<span title="After tax annuity earnings in this period">'+incomePeriodSay+' <span style="font-size:80%" title="tax paid">'+incomePeriodTaxSay+'</span></span>  ';
             }

         }   //    if atype = ....

         amess+='<td > ';
         let acellUse=acell;
         if (isChange==1 && acell5!=='')  acellUse=  '<span style="border:1px dashed blue" title="Modifed on this date">'+acell+'</span>';
         amess+='<div class="valueTableCell" title="'+avar+' on '+adate+'">'+acellUse+'</div>'
         amess+='<div class="valueTableCell2" '+onDetails+'>'+acell2+'</div>'
         amess+='<div class="valueTableCell3" '+onMoreDetails+' >'+acell3+'</div>'
         amess+='<div class="valueTableCell4" '+onGrowthDetails+' >'+acell4+'</div>'
         if (acell5!=='') amess+='<div class="valueTableCell4 valueTableCell5"  >'+acell5+'</div>'
         amess+=' </td>';

       }                   // all columms in a row  (such as asset  columns)

       amess+='<td  bgcolor="#ababad"><span class="valueTableCellLast" >'+ithRow+'</span></td>';
       amess+='</tr>';

   }               // row in table (for a dateadate
   amess+='</table>';

   bmess+=amess+'</div>';
   bmess+='</div>';

   displayStatusMessage(bmess);
   
//   alert('gotone '+gotOneInterp);
   if (!gotOneInterp) $('#iShowCompareButton').hide();

   toggleStatusDiv(0,3);

   return 1;


// ==================   vCompare    qInterpVal
// internal functionse

  function compare_interp(fullVal,interpVal,sdiff) {
// portfolio value column
      let adiff=interpVal-fullVal;
      let  diffSay='&asymp;';         // not worth worrying about
     if (Math.abs(fullVal)<sdiff) {  // special case  -- small calc value
           diffSay='&#8860;';
           if (Math.abs(adiff)>sdiff) {
                diffSay='&ogt;';     // signals interp value is more than who cares differnt from a small calc value
             }

     } else {      // non zero (or small) calc valuie
             let tz=adiff/fullVal;
             if (Math.abs(tz)<0.01) {
                  diffSay='~0 '
             } else {
                  diffSay=Math.abs(tz).toFixed(2);
             }
     }
     let asay='<span title="interpolated value was: '+interpVal.toFixed(0)+'"  class="valueTableCellCompare" style="display:none">'+diffSay+'</span>';
     return asay ;

  }

// internal function: return true if non-trivial size change( >difference > 0.2%)
// apct is % diff that is non-trivial; eg 1.0 for 1%. If not speciifed, 0.2 (0.2%) is used
  function changeMatters(v1,v2,apct) {

      if (arguments.length<3) apct=0.2 ;
      let afactUse=apct/100 ;
      let d1=Math.abs(v1-v2) ;
      if (d1==0) return false;
      let tfact=d1/Math.abs(v1);
      if (tfact>afactUse) return true;
      tfact=d1/Math.abs(v2);
      if (tfact>afactUse) return true;
      return false ;
  }

// ==================
// internal function: modify allVars

  function make_allVars(bdate) {
     let theModEntry= thisStuff[bdate]['theModEntry']
     let theBaseEntry= thisStuff[bdate]['theBaseEntry']
     let qInitEntry= (theBaseEntry===0 && theModEntry===0 ) ;
     let qModEntry= (theModEntry!==false && theModEntry>0) ;


     let q_entry =(theModEntry!==false) ;

// 'value": valuie of asset. If tax deferred, pre-tax. If stock, # shares
// value2: same as value EXCEPT: post-tax if tax deferred, $ value if stock (#shares * price)

     for (let zz0 in thisStuff[bdate]['entry']['assets']) {       // values
       let atype=thisStuff[bdate]['entry']['assets'][zz0]['assetType'];
       allVars[zz0]['dateList'].push(bdate);
       allVars[zz0]['dateInfo'][bdate]={'type':atype,'entNum':theBaseEntry,'value':false,'value2':false,'isNew':'0','isChange':0,'isRemove':0};
       if (atype==0)  allVars[zz0]['dateInfo'][bdate]['value']= thisStuff[bdate]['entry']['assets'][zz0]['q'] ;
       if (atype==1 || atype==2)  allVars[zz0]['dateInfo'][bdate]['value']= thisStuff[bdate]['entry']['assets'][zz0]['q'] ;
       if (atype==3)  allVars[zz0]['dateInfo'][bdate]['value']= thisStuff[bdate]['entry']['assets'][zz0]['value'] ;
       if (atype==4)   allVars[zz0]['dateInfo'][bdate]['value']= thisStuff[bdate]['entry']['assets'][zz0]['yearlyIncome'] ;
       if (atype==5)   allVars[zz0]['dateInfo'][bdate]['value']= thisStuff[bdate]['entry']['assets'][zz0]['yearlyAnnuity'] ;
       if (atype==7)   allVars[zz0]['dateInfo'][bdate]['value']= thisStuff[bdate]['entry']['assets'][zz0]['yearlyExpense'] ;  // type=6: 'value' not used ('baseReceipt' instead)
     }

// special cases (init or mod entry)

     if (qInitEntry)  {         // special case: an init  -- check for one offs (9 march 2024 -- hacky approach for now)
        let olist=thisStuff[bdate]['entry']['summary']['sumByTypePeriod']['oneOffListUsed'] ;  // for init, this is where "pending" is stored
        for (let io=0;io<olist.length;io++) {
            let zz3=olist[io];
            let avalue=thisStuff[bdate]['entry']['assetGrowths'][zz3]['baseReceipt'];  // where the "pending reciept" is stored for inits
            allVars[zz3]['dateList'].push(bdate);
            allVars[zz3]['dateInfo'][bdate]={'type':6,'entNum':theModEntry,'isNew':1};
            allVars[zz3]['dateInfo'][bdate]['value']=avalue ;
         }
     }      //  qInitEntry

     if (qModEntry)  {        // special case: a mod entry   -- check for one offs and newly added assets
             for (let zz3 in thisStuff[bdate]['entry']['summary']['summaryChanges']['oneOffListNew']) {
                 allVars[zz3]['dateList'].push(bdate);
                 allVars[zz3]['dateInfo'][bdate]={'type':6,'entNum':theModEntry,'isNew':1};
                 allVars[zz3]['dateInfo'][bdate]['value']=thisStuff[bdate]['entry']['summary']['summaryChanges']['oneOffListNew'][zz3];
               }

            for (let zz4 in thisStuff[bdate]['entry']['summary']['summaryChanges']['newListVals']) {  // newly added in this mod entry?
                  allVars[zz4]['dateList'].push(bdate);       // might be a  duplicate
                  let atypeN=getAssetType(zz4);
                  allVars[zz4]['dateInfo'][bdate]={'type':atypeN,'entNum':theModEntry,'isNew':1};
                  allVars[zz4]['dateInfo'][bdate]['value']=thisStuff[bdate]['entry']['summary']['summaryChanges']['newListVals'][zz4]; // mod entry starting value  # if stock,
                  allVars[zz4]['dateInfo'][bdate]['value2']=thisStuff[bdate]['entry']['summary']['summaryChanges']['newList'][zz4]; // mod entry starting value $ if stock, afte tax if tax deferred
              }
               for (let zz5 in thisStuff[bdate]['entry']['summary']['summaryChanges']['changeListVals']) {    // changes in this mod entry?
                  allVars[zz5]['dateInfo'][bdate]['value']=thisStuff[bdate]['entry']['summary']['summaryChanges']['changeListVals'][zz5]; // a modified value
                  allVars[zz5]['dateInfo'][bdate]['isChange']=1 ;
              }
               for (let zz6 in thisStuff[bdate]['entry']['summary']['summaryChanges']['removeList']) {    // changes in this mod entry?
                  allVars[zz6]['dateInfo'][bdate]['isRemove']=1 ;
              }


     }       // qModEntry

     return 1;      // caller will remove duplicate dates  (For each [assetname]['dateList']
  }   // end of interntal function make_allVars

}   // end of     showAllPortfolioValues_viewAssetsOverTime

//============
// notes on details
function  showAllPortfolioValues_viewAssetsOverTime_showHeaderNote(athis) {
   let ethis=wsurvey.argJquery(athis) ;
   let anAsset=ethis.attr('data-name');

  let enote=$('#showAllPortfolioValues_viewAssetsOverTime_noteRow');
  let assetType,assetIcon,assetSay,anAssetSay ;

  let abutton ='<input type="button" value="x" title="close this" onClick="wSurvey.wsShow.hide(this,100)" data-wsshow="-1"> ';

   if (anAsset=='-1') {              // Cash colum
      assetType=-1;
      assetIcon='&#65284;' ;
      assetSay='<u>Cash</u>' ;
      anAssetSay='' ;
   } else if (anAsset=='-2') {              // portfolio value column
      assetType=-2;
      assetIcon='&#128144;';
      assetSay='<u>portfolio value</u>'
      anAssetSay='' ;
   } else if (anAsset=='-3') {              // date value column
      assetType=-3;
      assetIcon='&#128467;&#65039;';
      assetSay='<u>Date</u>'
      anAssetSay='' ;

   } else  {
      assetType=getAssetType(anAsset );
      assetIcon=getAssetType(anAsset,'icon');
      assetSay=getAssetType(anAsset,'sayslong');
      anAssetSay=anAsset  ;

   }

   enote.show();
   let anote=abutton+' <u>'+  anAssetSay+'</u> : '+assetIcon+' '+assetSay;

   let cmess='';

   cmess+='<ul class="tightMenu"  style="max-height:80%;overflow:auto">';
   
  if (assetType==-3) {  // date
     cmess+='<li><span style="color:brown">Date</span>';
     cmess+='<li><span style="color:green">Period information</span>';
     cmess+='<br><em>For each date: a <u>period</u>  starts at the initialization, or most recent modification, entry</em>';

     cmess+='<br>Days since portfolio initialization, or since the most recent modification ';
     cmess+='<br>Date of initialization (or the most recent modification)';
     cmess+='</ul>'
   }


  if (assetType==-2) {  // portfolio
     cmess+='<li><span style="color:green">net-value: </span> liquidating all assets, after all taxes, etc. Includes <u>Cash</u>';
     cmess+='<li><span style="color:#b68a4e">Details:</span>';
     cmess+=' assetValue: net-value of non-<u>Cash</u> assets = assetSale - taxes ';
     cmess+='<br>assetSale: pre-tax, post loan payout, value of assets ';
     cmess+='<br>taxes : capital gain taxes (on sum of all capital gains), and deferred taxes ';
     cmess+='</ul>'
   }

  if (assetType==-1) {  // Cash
     cmess+='<li><em>For each date: cumulative values are from the start of a <u>period</u> -- which starts at the initialization, or most recent modification, entry</em>';
     cmess+='<li> <span style="color:blue"><u>Cash</u> available (if negative, Cash owed)  -- after growth &amp; after modifications ' ;
     cmess+='<li><span style="color:#b68a4e">Details:</span>';
     cmess+='<br> <tt> Begin</tt> -- cash at start of period ';
     cmess+='<br> <tt>oneOffs</tt> --  oneOffs recieved on first day of period ';
     cmess+='<br> <tt>&Delta;period</tt> -- after-tax Sum of <tt>raw additions</tt> from start to end of period: rents, loan payments, income and annuity earnings,  expense costs, additions (and RMDS) to/from bonds &amp; tax deferred bonds; ';
     cmess+='<br><input type="button" value="?" title="What is this adjustment" onclick="displayHelpMessage(this)" data-div="#fixCashInfo">';
     cmess+=' <tt>interest</tt> -- cumulative interest earnings of daily <u>Cash</u> balances -- starting with Begin +oneOffs, day-by-day portions of raw additions (&Delta;period) ';
     cmess+='<br> If <span style="color:brown">mods</span> is displayed: net change due to modifications (sales minus purchases)  ';

     cmess+='<br> If <span style="color:brown">&#128710;</span> displayed:  ';
     cmess+=' <tt>swDay</tt> : approximate day cash balance switches sign  ';
     cmess+='<li><div style="border:2px dotted gray">';
     cmess+=' Earnings and payments in this period:';
         cmess+='<div> <span style="padding:1px 3px;color:green">After tax earnings:</span> dividends, interest on bonds, +rents, incomes, and annunities. Includes full value of tax deferred bonds interest earnings (no tax applied)</div> ' ;
         cmess+='<div> <span style="padding:1px 3px;color:red"> After tax payments:</span> loans, -rents, and expenses. After tax means tax offsets are considered</div>  ';
         cmess+='<div> <span style="padding:1px 3px;color:brown"> Taxes on earnings;</span> does NOT include possible future taxes on tax-deferred bond earnings</div>'         ;
         cmess+='Note that dividends and interest earnings, and taxes on earnings and expenses, do <b>not</b> impact <u>Cash</u>. ';
      cmess+='</div>';
     cmess+='<li>';
     cmess+='<div style="border:2px dashed blue">';
     cmess+='If this is a modification entry ...    ';
         cmess+='<div> <span style="padding:1px 3px;color:green">Total earnings from sales</span> (of stocks, bonds, and propeties). Does <u>not</u> include tax impacts. For example: does not include taxes owed from selling tax deferred assets.</div> ' ;
         cmess+='<div> <span style="padding:1px 3px;color:red"> Total payments from purchases</span>. Does <u>not</u> include tax impacts. For example: includes the total value of tax-deferred assets (no adjustment for tax offsets)</div>  ';
         cmess+='<div> <span style="padding:1px 3px;color:brown"> Taxes:</span> net capital gains on sales of stocks and properties (net of purchases),';
         cmess+=' and net tax impacts of sales & purchases of tax-deferred bonds (negative value means more purchases than sales, the difference offsets taxes)</div>'         ;
      cmess+='</div>';
     cmess+='</ul>'
   }

  if (assetType==0) {  // stock
     cmess+='<li><em>For each date: cumulative values are from the start of a <u>period</u>. <br>A  <u>period</u>  starts at the initialization, or most recent modification, entry</em>';
     cmess+='<li> <span style="color:blue">net-value </span> (all shares sold at current price, after capital gains taxed paid) --  after growth (before modifications).';
     cmess+='<li><span style="color:green">Growth: </span>Q * P =  cumulative after-tax dividend earnings.';
     cmess+='<br> (Cumulative tax paid on dividend earnings)';
     cmess+='<br>  &rarr; &Delta; : change in # of shares since init or last mod ';
     cmess+='<li><span style="color:#b68a4e">Details:</span>';
     cmess+='(Number of shares * Current price) = grossValue ';
     cmess+='<br> grossValue - basis = capitalGains  ';
     cmess+='<br> &rarr; the tax on these capital gains ';
     cmess+='<br><tt>basis</tt> : initial acquisition cost plus cost of shares purchased with after-tax dividend earnings';
     cmess+='<li><span style="border:1px dashed blue;color:brown;font-style:oblique">After modification value (# of shares)</span>. Displayed if a non-trivial change (&gt;0.2%) was specified for this asset (in this period). ';
     cmess+='<br> This value is used in the row\'s asset value calculations (and indirectly, in <u>Cash</u> calculations) ';
     cmess+='<br><span style="color:#f47d16;border-radius:3px">&#9003;</span> Displayed if property is sold on this date ';
     cmess+='</ul>'
  }
  if (assetType==1) {  // bond
     cmess+='<li><em>For each date: cumulative values are from the start of a <u>period</u>. <br>A  <u>period</u>  starts at the initialization, or most recent modification, entry</em>';
     cmess+='<li> <span style="color:blue">net-value</span>  (no taxes are owed) -- after growth (before modifications) ';

     cmess+='<li><span style="color:#b68a4e"> Cumulative additions</span>: Negative values mean sales whose proceeds are added to <u>Cash</u> ';
       cmess+='<div style="padding-left:3em">This is a raw value; which does <u>not</u> include added (or forgone) interest earnings due to these additions.</div>';
     cmess+='<li><span style="color:green">Growth: </span>  cumulative interest earnings (after-tax) -- reinvested in the asset.';
     cmess+='<br> (Cumulative tax paid on interest earnings)';

     cmess+='<li><span style="border:1px dashed blue;color:brown;font-style:oblique">After modification value</span>. This value is used in the row\'s asset value calculations (and indirectly, in <u>Cash</u> calculations) ';
     cmess+='<br><span style="color:#f47d16;border-radius:3px">&#9003;</span> Displayed if all bonds converted to cash on this date ';
     cmess+='</ul>'
  }
    if (assetType==2) {  // bond
     cmess+='<li><em>For each date: cumulative values are from the start of a <u>period</u>. <br>A  <u>period</u> starts at the initialization, or most recent modification, entry</em>';
//     cmess+='<li><em>For each date: cumulative values are from the start of a <u>period</u> -- which starts at the initialization, or most recent modification, entry</em>';
     cmess+='<li> <span style="color:blue">net-value</span>  (after deferred taxes are paid)  -- after growth (before modifications)  ';

     cmess+='<li><span style="color:green" title="Interest earnings (untaxed) are reinvested in the asset.">Growth: </span> Tax deferred bond earnings in this period; not accounting for impacts of additions.  ';
     cmess+=' Thus: if there are substantial additions, this number will NOT equal the change in the asset value.';
     cmess+='<li><span style="color:#b68a4e">Details:</span>';
       cmess+='Tax paid (if asset liquidated), on a total (pre-tax) value. The difference is the <span style="color:blue">net value</span> of this tax-deferred bond asset ';
       cmess+='<br><tt>cumAdditions</tt>. Cumulative additions (if negative, withdrawals) during this period. These can be based on explicit per year values, or can be age-based required minimum distributions ';
       cmess+='<div style="padding-left:3em">This is a raw value; which does <u>not</u> include added (or forgone) interest earnings due to these additions.';
       cmess+='<br>And it is a <em>before tax</em> value! The actual addition to <u>Cash</u> is net of taxes due (or, if an addition, adjusts for tax savings from obtaining tax deferred assets). </div>';
     cmess+='<li><span style="border:1px dashed blue;color:brown;font-style:oblique">After modification value.</span> This value is used in the row\'s asset value calculations (and indirectly, in <u>Cash</u> calculations) ';
     cmess+='<br><span style="color:#f47d16;border-radius:3px">&#9003;</span> Displayed if all bonds converted to cash on this date ';

     cmess+='</div>';
     cmess+='</ul>'
  }

  if (assetType==3) {  // property
     cmess+='<li><em>For each date: cumulative values are from the start of a <u>period</u>. <br>A  <u>period</u>   starts at the initialization, or most recent modification, entry</em>';
     cmess+='<li> <span style="color:blue">net-value (if sold on this date)</span>: after paying off loan, and capital gains taxes ';
     cmess+='<li><span style="color:green">Growth: </span> Total loan payments, and (amount of principal paid). ';
     cmess+='<br>Cumulative net rents. <tt>net rents</tt> can include after-tax income (such as rents) and expenses (such as maintenance). ';
     cmess+='They typically do <u>not</u> include mortgage payments. Note that positive rents are subject to tax, but negative ones are not (there are no tax savings from rental losses)' ;

     cmess+='<li><span style="color:#b68a4e">Details:</span>';

     cmess+='Sale price - amount of principal still owed= Profit';
     cmess+='<br> Sale price - basis = capitalGains  ';
     cmess+='<br> &rarr; the tax on these capital gains ';
     cmess+='<br><tt>basis</tt> : property value when purchased (as specified when added to the portfolio) ';
     cmess+='<br>Profit - (saleCost + capital gains tax) = net value (upon liquidation of this asset)';
    cmess+='<li><span style="color:#f47d16;border-radius:3px">&#9003;</span> Displayed if property sold on this date ';

     cmess+='</ul>'
  }

  if (assetType==4) {  // income
     cmess+='<li><em>For each date: cumulative values are from the start of a <u>period</u>. <br>A  <u>period</u>   starts at the initialization, or most recent modification, entry</em>';
     cmess+='<li> <span style="color:#023737;">Gross (pre-tax) <u>yearly</u> income-stream earnings</span>    ';
     cmess+='<li><span style="color:green">Growth: </span> Cumulative net earnings from this income-stream  (during this period).'
     cmess+='<br> Cumulative taxes paid.';
     cmess+='<li><span style="color:#b68a4e">Details:</span>';
     cmess+='no details for income streams';
     cmess+='<li><span style="border:1px dashed blue;color:brown;font-style:oblique">After modification value.</span> This value in <u>Cash</u> calculations ';
     cmess+='<br><span style="color:#f47d16;border-radius:3px">&#9003;</span> Displayed if incomeStream stopped on this date ';
     cmess+='</ul>'
  }
  if (assetType==5) {  // annuity
     cmess+='<li><em>For each date: cumulative values are from the start of a <u>period</u>. <br>A  <u>period</u>   starts at the initialization, or most recent modification, entry</em>';
     cmess+='<li> <span style="color:#023737;">Gross (pre-tax) yearly annuity earnings</span>    ';
     cmess+='<li><span style="color:green">Growth: </span> Cumulative  net earnings from this annuity (during this period).'
     cmess+='<br> Cumulative taxes paid.';
     cmess+='<li><span style="color:#b68a4e">Details:</span>';
     cmess+='Base annuity -- amount received when first added to the portfolio.';
     cmess=='<br>(Growth rate of annuity). After being added to the portfolio), as a fraction of CPI inflation. <tt>1.0</tt>: grows at the inflation rate. <tt>0.0</tt> =no growth';
     cmess+='<li><span style="border:1px dashed blue;color:brown;font-style:oblique">After modification value.</span> This value is used in <u>Cash</u> calculations ';
     cmess+='<br><span style="color:#f47d16;border-radius:3px">&#9003;</span> Displayed if annuity stopped on this date ';
     cmess+='</ul>'
  }
  if (assetType==6) {  // one offs
     cmess+='<li>oneOff values are displayed <u>only</u> for dates they are added to a portfolio. No other information is displayed.';
     cmess+='<li>The oneOff value is added the next day!  ';
     cmess+='<li> Note that positive values are addition to <u>Cash</u>, negative values are subtractions from <u>Cash</u>';
  }

  if (assetType==7) {  // expense streams
     cmess+='<li><em>For each date: cumulative values are from the start of a <u>period</u>. <br>A  <u>period</u>   starts at the initialization, or most recent modification, entry</em>';
     cmess+='<li> <span style="color:#023737;">Pre-tax yearly expense-stream costs</span>  ';
     cmess+='<li><span style="color:green">Growth: </span> Cumulative net costs from this expense-stream (during this period).'
     cmess+='<br> Cumulative tax savings (from deducting this expense).';
     cmess+='<li><span style="color:#b68a4e">Details:</span>';
     cmess+='<li><span style="color:brown;font-style:oblique">After modification value.</span> This value is used in <u>Cash</u> calculations ';
     cmess+='<br><span style="color:#f47d16;border-radius:3px">&#9003;</span> Displayed if expense stream stopped on this date ';

     cmess+='no details for expense streams';
  }


  anote+=cmess;

  enote.html(anote);
  wsurvey.wsShow.show(enote,'show');

   return 1;
}

// ============
// redraw table with a set column size
// 2 nov 2023 ... for some reason, setting <th> widths doesn't work
function showAllPortfolioValues_viewAssetsOverTime_cols(athis,idire) {
    let ethis=wsurvey.argJquery(athis);
    let aportfolio=ethis.attr('data-name');
    let ainf=parseInt(ethis.attr('data-inf'));

    let e1=$('#portfolioValuesTableOverTimeDiv');
    let afactor=parseFloat(e1.attr('data-expand'));
    let origWidth=parseFloat(e1.attr('data-origwidth'));

    aexpand=1+(parseFloat(idire/8.0));
    afactor=aexpand*afactor;
    e1.attr('data-expand',afactor.toFixed(2));
    let newWidth =parseInt(origWidth*afactor);

     let ecols=e1.find('.cHasUseCellWidth');
     for (let ie=0;ie<ecols.length;ie++) {
        let aecol=$(ecols[ie]);
        aecol.attr('width',newWidth+'px');

     }

    return 1;
}

// ============
// hide/show details or more details
// 2 nov 2023 ... for some reason, setting <th> widths doesn't work
// ido=1 details, 2= more details

function showAllPortfolioValues_viewAssetsOverTime_details(athis,ido) {
   let ethis=wsurvey.argJquery(athis);

   let ison=parseInt(ethis.attr('data-ison'));
   if (!jQuery.isNumeric(ison)) ison=1;

   let edo;
   let e1=$('#portfolioValuesTableOverTimeDiv');
   if (ido==1) {
      edo=e1.find('.valueTableCell2');
   } else if (ido==3)  {
      edo=e1.find('.valueTableCellCompare');
   } else {           //  more details
      edo=e1.find('.valueTableCell3');
   }

   let nowon=1-ison ;
   ethis.attr('data-ison',nowon);
   if (nowon==1)  {
      edo.show();
      ethis.addClass('cdetailsHilite');
   } else {
      edo.hide();
      ethis.removeClass('cdetailsHilite');
   }

}

//====================
// real/nominal view checkboxk
function showAllPortfolioValues_viewAssetsOverTime_real(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aportfolio=ethis.attr('data-name');
   let iDoInfAdj= (ethis.prop('checked')) ? 1 : 0  ;

   let e1=$('#portfolioValuesTableOverTimeDiv');
   let ed1=e1.find('[name="tableShowDetails1"]');
   let ison1=ed1.attr('data-ison');
   let ed2=e1.find('[name="tableShowDetails2"]');
   let ison2=ed2.attr('data-ison');

   showAllPortfolioValues_viewAssetsOverTime(0,iDoInfAdj,aportfolio,false,ison1,ison2);

}

//===================================
// view table of portfolio assets over time -- growth info
function showAllPortfolioValues_viewAssetsOverTime_growth(athis )   {

   let ethis=wsurvey.argJquery(athis);

   let ison=parseInt(ethis.attr('data-ison'));

   let edo;
   let e1=$('#portfolioValuesTableOverTimeDiv');
   edo=e1.find('.valueTableCell4');
 
   let nowon=1-ison ;
   ethis.attr('data-ison',nowon);
   if (nowon==1)  {
      edo.show();
      ethis.addClass('cdetailsHilite');
   } else {
      edo.hide();
      ethis.removeClass('cdetailsHilite');
   }

  return 1;

}


//  ========
// show asset mix of  init and mod entries (in a popup box) for a portfolio
function showAllPortfolioValues_viewEntry(athis,ith ) {

  if (arguments.length<2) ith=0;
   let ethis=wsurvey.argJquery(athis);
   let aportfolio=ethis.attr('data-name');
   let hiliteVar=ethis.attr('data-var');
   if (!portfolioInit.hasOwnProperty(aportfolio)) {               // should never happen
      alert('error in  showAllPortfolioValues_viewEntry: no such portfolio= '+aportfolio);
      return false;
   }

   let daStuff=portfolioLookup['list'][aportfolio];
   let nEntries=daStuff['nHistory'];

   let modList=portfolioLookup['list'][aportfolio]['modDates'];
   useDate=modList[ith];  // array starts at index 0
  let nmods= modList.length-1 ;  // [0] is init

   daAssets={};
   for (let aa1 in daStuff['anyDateAsset']) {
      daAssets[aa1]=[];
      let jIn=daStuff['anyDateAsset'][aa1];
      if (jIn==nEntries  ) {
         daAssets[aa1].push('all');
      } else {                        // check if in init
         let initDate=daStuff['modDates'][0] ;
         if (daStuff['assetsList'][initDate].hasOwnProperty(aa1)) {
           daAssets[aa1].push('init');
           if (jIn>1) daAssets[aa1].push( (jIn-1)+' mod');
         } else {
             daAssets[aa1].push(jIn+' mods');
         }
     }
  }
  let goo0='<div style="margin:5px 1em;padding:3px;background-color:#f1f2f5" id="showAllPortfolioValues_viewEntry_summary">';
  goo0+='<ul class="linearMenu13Pct">';
  goo0+='<li><input type="button" value="x" onClick="$(\'#showAllPortfolioValues_viewEntry_summary\').hide()"> ';
  let left1='',right1='';
  if (ith>0)  {
     let ith1=ith-1;
     left1+=' <input type="button" value="&#8612" title="view prior modification"  ';
     left1+='      onClick="showAllPortfolioValues_viewEntry(this,'+ith1+')"   data-var="'+hiliteVar+'" data-name="'+aportfolio+'"   >';
   } else {
     left1+=' <input type="button" value="&#8612" title="no prior modification" disabled style="opacity:0.5"> ';
   }
   if (ith<nmods) {
     let ith1=ith+1;
     right1+=' <input type="button" value="&#8614" title="view next modification" onClick="showAllPortfolioValues_viewEntry(this,'+ith1+')"  data-var="'+hiliteVar+'"  data-name="'+aportfolio+'"   >';
   } else {
      right1+=' <input type="button" value="&#8614" title="no next modification" disabled style="opacity:0.5"> ';
   }
   goo0+=left1+' '+right1;   // the list of assets (above the "currently viewed entry"

  goo0+=' &nbsp;&nbsp;<span title="Assets in one or more entries"><em> Assets &hellip;</em> ';
  for (let az1 in daAssets) {
     let tt1=daAssets[az1].join(' | ');
     let az1Use= (az1==hiliteVar) ?   '<span style="font-weight:700">'+az1+'</span>' : az1 ;
     if (daStuff['assetsList'][useDate].hasOwnProperty(az1)) {
        goo0+='<li title="Entries (init and modification) this is in">   <span title="in currently viewed entry" style="border:2px solid green"> <u>'+az1Use+'</u> : '+tt1+'</span> ';
     } else {
        goo0+='<li title="Entries (init and modification) this is in"><u>'+az1Use+'</u> : '+tt1;
     }
  }
  goo0+='</ul>';
  goo0+='</div>';

    let goo=showPortfolioMix(false,aportfolio,ith,useDate,1,hiliteVar);

   let goo2='<div style="background-color:tan"><b>'+aportfolio+'</b>: ';

   if (ith>0) {
    let ith1=ith-1;
     goo2+=' <input type="button" value="&#8612" title="view prior modification"  ';
     goo2+='      onClick="showAllPortfolioValues_viewEntry(this,'+ith1+')"   data-var="'+hiliteVar+'" data-name="'+aportfolio+'"   >';
   }  else {
     goo2+='&nbsp;';
   }

   if (ith==0) {
      goo2+=' &#127553; initialization entry ';
      goo2+=' <span style="margin-left:0.1em;font-size:85">'+nmods+' modifications</span>';
   } else {
      goo2+=' &#127553; modification entry ';
       goo2+=' <span style="margin-left:3em;font-size:85">'+ith+' of '+nmods+' </span>';
   }

    if (ith<nmods) {
      let ith1=ith+1;
      goo2+=' <input type="button" value="&#8614" title="view next modification" onClick="showAllPortfolioValues_viewEntry(this,'+ith1+')"  data-var="'+hiliteVar+'"  data-name="'+aportfolio+'"   >';
    }

  if (hiliteVar!='')   goo2+='<span style="float:right;margin-right:1em"><span style="background-color:lime">Highlighting:</span> <b> '+hiliteVar+'</b></span>';
   goo2+='</div> ';
   goo2+=goo0 ;
   goo2+=goo;
   displayStatusMessage(goo2);
   toggleStatusMessage(0,2);

}

// ====================================
// toggle view of empty rows
function showAllPortfolioValues_toggleEmpty(athis) {
    let ion ;
    if (athis===1 || athis===0) {
        ion=athis;
    } else {
       let ethis=wsurvey.argJquery(athis);
       ion=ethis.attr('data-on');
       ion=1-ion;
        ethis.attr('data-on',ion);
    }
   let etable=$('#portfolioValuesTable');
   let erows=etable.find('.emptyViewRow');
   if (ion==0) {
      erows.hide();
   } else {
      erows.show();
   }

}

//============
// display a short summary in a cell of "row 1";
function showAllPortfolioValues_allExtraDetails(athis) {
   let ethis=wsurvey.argJquery(athis);
   let isvu=ethis.attr('data-show');
   isvu=1-isvu;
   ethis.attr('data-show',isvu);
   let etable=$('#portfolioValuesTable');
   let esumms=etable.find('[name="viewPortfolioCell_summary"]');
//   let etrans=etable.find('[name="viewPortfolioCell_netTransactions"]');
   if (isvu==1) {
      esumms.show();
//      etrans.show();
   } else {
     esumms.hide();
//     etrans.hide();
   }
  fixmyheight_maindiv(1) ;  // fit intoi maindif
}


//============
// display a short summary -- growth and mods -- in a cell of "row 1";
function showAllPortfolioValues_allChangeDetails(athis) {
   let ethis=wsurvey.argJquery(athis);
   let isvu=ethis.attr('data-show');
   isvu=1-isvu;
   ethis.attr('data-show',isvu);
   let etable=$('#portfolioValuesTable');
   let esumms=etable.find('[name="viewPortfolioCell_changes"]');
   if (isvu==1) {
      esumms.show();
   } else {
     esumms.hide();
   }
  fixmyheight_maindiv(1) ;  // fit intoi maindif
}


