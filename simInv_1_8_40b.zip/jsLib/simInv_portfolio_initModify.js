
//=================
// update some sortuse data  in the asset mix menu
// tt is the return from portfolioCalcValueMenu
function  portfolioCalcValueMenu_sortUpdate(tt) {
   let totvalPortfolio=tt['totNetValue'];
   let usevals=tt['assets'];

   let etable=$('#portfolioHistory1AssetRows');
   let etrs=etable.find('.portfolioHistoryRowNew')  ;
   for (let ie=0;ie<etrs.length;ie++) {
       let aetr=$(etrs[ie]);
       let  ename=aetr.find('[name="portfolioAsset"]');
       let aname=ename.val();
       if (!usevals.hasOwnProperty(aname)) continue ; // should never happen
       let a1=usevals[aname];

       let  val=a1['value'];
       let e1=aetr.find('[name="cell_value"]');
       e1.attr('data-_sortuse',val);

       let netVal=a1['netValue'] ;
       let e2=aetr.find('[name="cell_netValue"]');
       e2.attr('data-_sortuse',netVal);

       let apct=val/totvalPortfolio;
       let e3=aetr.find('[name="cell_pct"]');
       e3.attr('data-_sortuse',apct);
   }           // etrs
   return 1;
}


// init portfolio values (blank for all input fields)

function buildPortfolioMenu_reset(athis) {
   let etable=$('#portfolioHistory1');
   let etrs=etable.find('.portfolioHistoryRow');
   for (let ii=0;ii<etrs.length;ii++) {
       let etr=$(etrs[ii]);
       let ec1=etr.find('[name="cell_value"]');
       let einputs=ec1.find('[data-orig]');
       for (let ii2=0;ii2<einputs.length;ii2++) {
          let einput=$(einputs[ii2]);
          let oval=einput.attr('data-orig');
          einput.val(oval);
       }
   }
   buildPortfolioMenu_expand(0,1);
   return 1;
}

//===========
function  buildPortfolioMenu_expand(athis,ireset) {

  let etable=$('#portfolioHistory1AssetRows_div');
 
  if (etable.length==0) return 0 ;

  if (arguments.length>1 && ireset==1) {          //reseet
      etable.css({'max-height':'35vh'});
      return 1;
  }

  let h1=etable.css('max-height');
  h1=parseInt(h1);
  let h2=h1+30;


  etable.css({'max-height':h2+'px'});
  etable.height(h2+'px');

  return 2;

}



//======================
// show buttons for the view  and modifications, of a portfolio.
// clicking the button displayes an asset mix
// iwhich: 1= show the list of assets for selected portfolio
//     , 3: show the list, and open the "modify" menu,
//       4: view this portfolio button on display viewDates column header

function showPortfolioViewModify(athis,iwhich  ) {

   let ethis=wsurvey.argJquery(athis);
   let pname=ethis.attr('data-name');

   if (!portfolioInit.hasOwnProperty(pname) ) {
      alert('You must initialize the '+pname+' portfolio ');  // should never happen
      return false;
   }

   if (iwhich==4) {
      iwhich=1;
   }

   let zz=portfolioLookup['list'][pname];

   let nHistory=zz['nHistory'] ;

   let iz=zz['ith'];
   let adesc=portfolioList[iz]['desc'];

   let origBudget=portfolioInit[pname]['original']['budget'];
   let origBudgetSay=numberString=wsurvey.makeNumberK(origBudget,90000,0) ;

   let daNassets=parseInt(portfolioInit[pname]['totals']['nAsset']);
   let daNincome=parseInt(portfolioInit[pname]['totals']['nIncome']);
   let daBoth=daNassets+' &amp; '+daNincome ;
   let totAssetSale=portfolioInit[pname]['totals']['totAssetSale'];
   let totNetAssetEst=portfolioInit[pname]['totals']['totNetAssetEst'];   // estiamted not actula (totals vs totalsAfterGrowth

   let daCreation=portfolioInit[pname]['dateStamp'];
   let daCreationSay=portfolioInit[pname]['dateStampSay'];
   let oof3=setEntryDate(daCreation);
   let daCreationYear=oof3['year'];

   let amess='';
    amess+=' <button   title="Return to the list of portfolios"  name="doPortfolioButton"  onClick="showPortfolioTable(this)">&#8617;&#65039;</button>  ';
   amess+='<input type="button" value="&neArr;" title="View in a new window"  data-id="mainDiv3" onClick="displayInWindow(this)"> ';
   amess+='<input type="button" value="&#10068;" onClick="displayHelpMessage(this)" data-div="#portfolioAssetMix1"> ';  // help button

   amess+='<button  data-name="'+pname+'" class="cViewSummaryButton" title="Toggle the list of transactions (sales & purchases in all the modifications)" ';
   amess+='   onClick="showPortfolioViewModify_listMods(this)" data-mode="'+simInvParams['showTransactions']+'" data-name="'+pname+'" > ';   
   amess+=' &#129534; </button> ';

//   amess+=' <button class="cdoButtonRegular" style="font-size:95%;color:blue" id="valuePortfolioButton2"  ';
//   amess+=' title="Display this portfolio`s values using selectedViewDates dates"  name="doDisplayButton"  ';
//   amess+='   onclick="showAllPortfolioValuesStart(this,\''+pname+'\')">&#128176; &#11190; </button> ';       // 30 march 2024 --- not working,


// open modify menu button
   amess+=' <button id="idoButtonModify"  class="cdoButtonModify"  onClick="showModifyPortfolio_step1(this)"  ';
   amess+='     title="Create a modification of  this portfolio`s asset mix (as of a future date that you specify)" ';
   amess+='    data-name="'+pname+'" >&#9998; Modify <u>'+pname+'</u> </button> ';   // &#9998;

   amess+='<span class="cPortfolioName_t1"  >&#128144; <em>Portfolio </em> <u>'+pname+'</u></span> <span style="font-size:90%;font-style:oblique" title="Short description">'+adesc+'</span>'

   amess+='<ul id="portfolioModificationsList" class="linearMenu18Pct">';
   amess+='<li style="width:8em"><div style="font-size:90%">Initial budget=<tt>'+origBudgetSay+'</tt>';
   let mdList0=portfolioLookup['list'][pname] ;

   let amodDate0=mdList0['modDates'][0];
   let daNetValue0=mdList0['totNets'][amodDate0];
   daNetValue0Say=wsurvey.makeNumberK(daNetValue0,100000,0);

   let p1say='<button title="The initialization entry ... " onClick="showPortfolioMix(this)" name="whichPortfolio" ';
   p1say+='   data-date="'+daCreation+'" data-nth="0"  data-name="'+pname+'"  >';

   p1say+=daCreationSay+'</button>';
   p1say+='<span name="portfolioButton_summary" title="#assets & #incomes"> <em>  '+daBoth+' </span>    | '+daNetValue0Say+' </em> ' ;
   amess+='<li class="notHighlightThisLi">'+p1say;

   for (let jj=1;jj<portfolioLookup['list'][pname]['modDates'].length;jj++) {
      let mdList=portfolioLookup['list'][pname];

      let amodDate=mdList['modDates'][jj];             // totNets [0..]

      let amodDateSay=mdList['modDatesSay'][amodDate];
      let daNetValue=mdList['totNets'][amodDate];
      let acomment=mdList['comments'][amodDate];

      let nAssets=mdList['nAssets'][amodDate];
//      let nIncomes=mdList['nIncomes'][amodDate];
//      let nboth=nAssets+nIncomes;
       let nboth=nAssets ;
      let daNetValueSay=wsurvey.makeNumberK(daNetValue,100000,0);

      let modThis='<button   class="cdoButtonModifySmall" title="Change this modification"  onClick="showModifyPortfolio_step1Tweak(this)" data-name="'+pname+'" data-ith="'+jj+'"> ';
       modThis+='&#119585;</button>' ;

      let p1say='<button title="A modification ('+amodDate+'): '+acomment+'" onClick="showPortfolioMix(this)" name="whichPortfolio"  data-date="'+amodDate+'"  ';
      p1say+='    data-nth="'+jj+'"  data-name="'+pname+'"  >';
      p1say+=amodDateSay+'</button>';
     p1say+='<span  name="portfolioButton_summary" style="font-style:oblique" title="#assets '+nAssets+' |  netValue"> <em>('+nboth+ ' | '+daNetValueSay+')</em> ' ;
//      p1say+='<span  name="portfolioButton_summary" style="font-style:oblique" title="#assets '+nAssets+'+ # incomes'+nIncomes+' |  netValue"> <em>('+nboth+ ' | '+daNetValueSay+')</em> ' ;
      amess+='<li class="notHighlightThisLi">'+modThis+' '+p1say;
   }        // jj

    amess+='</ul>'; // end of list of modifications for this portfolio

   amess+='<div id="viewPortfolioMods_input"  name="aDateHandlerParent" class="cviewPortfolioMods_input">';  // popup box to get a modification date, and then display mod menu
   amess+='Modify portfolio <span style="font-size:110%;background-color:lime">'+pname+'  </span>  ' ;
   amess+='<ul class="boxList2">';
   amess+='<li>Enter a date after <tt>'+daCreationSay+' </tt>  &#8620; ';

// these value fields filled with lastEntryDate values (by
   amess+='  <span name="modDateSetter" >    ';
   let minDate=wsurvey.validateDate(simInvGlobals['theMinYear'] ,1,1).value;
   let maxDate=wsurvey.validateDate(simInvGlobals['theMaxYear'],12,31).value;

   let oof1=$(document).data('lastEntryDate');         // and set some defualt values for year/month/day
   let y1=parseInt(oof1['year']);
   let m1=parseInt(oof1['month']);
   let d1=parseInt(oof1['day']);

   let dopts={'minDate':minDate,'maxDate':maxDate,
                 'callback':'showPortfolioViewModify_date','month3':2,
                 'attribs':{'pname':pname}
              }  ;
   let dstring=wsurvey.dateBox_make(y1,m1,d1,dopts);

   amess+=dstring;
   amess+='</span>';


   amess+='<li><button  name="modButton1" data-name=""  data-creationDate=""  class="cdoButtonRegular"  data-daycount=""  ';
   amess+=' onClick="showModifyPortfolio_step2(this)">';
   amess+='Specify the modifications </button> <em>for the above date!</em>';
   amess+='</ul>';
   amess+='</div>';

   amess+='<div id="mainDiv3b"></div>';

   wsurvey.wsShow.show('#mainDiv','show');
   wsurvey.wsShow.show('#mainDiv3','show');
   $('#mainDiv3').html(amess);

  let asay='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioHistoryHelp1">&#10068;</button> ';
  asay+=' <button   title="Return to list of portfolios"  name="doPortfolioButton"  onClick="showPortfolioTable(this)">&#8617;&#65039;</button>  ';
  asay+='Viewing asset mix for  <b>'+pname+'</b> &#128144; '
  hidePortfolioHeader(1,asay);

   if (iwhich==3) $('#idoButtonModify').trigger('click') ;

   if (iwhich==1) {        // view creation entry   (nb: iwhich=4 is converted to iwhich=1)
      let e1=$('#portfolioModificationsList');
      let e2=e1.find('[data-nth="0"]');
      e2.trigger('click') ;
   }

   return 1;
}

// callbck on date change (select a modifiction date
function showPortfolioViewModify_date(ediv,astuff)    {
   return 1 ; // nothing to do  -- user should hit specify button
}
//===============================
// display a list of the modifications to this portfolio
// if pname arg specified it is always show. Otherwise its a button click -- so toggle
// modes:
//  0: small buttons
//  1 : large buttons
// 2:  large buttons and summary table
// 3:  small buttons and summary table
// 4 :  no buuttons and summary table

function showPortfolioViewModify_listMods(athis,pname,aMode,noScroll) {
  if (arguments.length<4) noScroll=0;

  if (arguments.length<3) {
     let ethis=wsurvey.argJquery(athis);
     aMode=ethis.attr('data-mode');
     pname=ethis.attr('data-name');
     aMode++;
     if (aMode>4 || aMode<0)  aMode=0;
     ethis.attr('data-mode',aMode);
  } else {
      if (aMode>4 || aMode<0)  aMode=0;
  }

   let eList=$('#portfolioModificationsList');
  let eListSummary=eList.find('[name="portfolioButton_summary"]');
  let esummary=$('#iPortfolioTransactions');

  if (aMode==0)  { // just small buttons
    eList.show();
    esummary.hide();
    eListSummary.hide();
    eList.removeClass('linearMenu18Pct');
    eList.addClass('linearMenu10Pct');

  } else if (aMode==1) {   // large buttons (buttons + #assets/netValue
    eList.show();
   esummary.hide();
    eListSummary.show();
    eList.addClass('linearMenu18Pct');
    eList.removeClass('linearMenu10Pct');


  } else if (aMode==2) {   // large buttons (buttons + #assets/netValue) and summary table
 
    eList.show();
    esummary.show();
    eListSummary.show();
    eList.addClass('linearMenu18Pct');
    eList.removeClass('linearMenu10Pct');

  } else if (aMode==3) {   // small buttons (buttons  ) and summary table
    eList.show();
    esummary.show();
    eListSummary.hide();
    eList.removeClass('linearMenu18Pct');
    eList.addClass('linearMenu10Pct');

  } else if (aMode==4) {   //    summary table
    eList.hide();       // no need to hide summaries in eListSummary
    esummary.show();
  }

  simInvParams['showTransactions']=aMode ;  // this is now the "default" (used by showPortfolioMix

 let asummMade=esummary.attr('data-made');
 if (asummMade==1) {
   if (aMode==2 && noScroll==0) {
      let e3b=$('#mainDiv');
      let atop=esummary.offset().top ;
      e3b.animate({scrollTop:atop}, 500);
    }
    return 1;
 }

//  create and display for this portfolio the table of summaries (for init and each mod)

  let oof,oofComments;
  if (!portfolioModifications.hasOwnProperty(pname)) {
     modStuff=false;
  } else  {
      modStuff=portfolioModifications[pname];
  }

   let amods={},agrows={};
   let ntrans=0;
   if (modStuff!==false) {
     for (let adate in modStuff) ntrans++ ;
   }

   let amess='';
   amess+='<input type="button" value="&#8613;" title="scroll to top of modifications list" onClick="showPortfolioViewModify_listMods_top(this)">';
   amess+='<tt>'+ntrans+'</tt> modifications for <b>'+pname+'</b><br>';
   amess+='<table cellpadding="3" rules="rows" xborder="1" >';

   amess+='<tr><th> ';
   amess+='<input type="button" value="?" onclick="displayHelpMessage(this)" data-div="#portfolioTransactionList">    ';
   amess+='Date</th>';
   amess+='<th  style="border-left:3px solid black" colspan="2">Current</th>'
   amess+='<th  style="border-left:3px solid black" colspan="4">Changes in <u>Cash</u> due to modifications</th>'
   amess+='<th  style="border-left:3px dotted black" colspan="4">... assets that were modified</th>'
   amess+='<th style="border-left:3px solid black" colspan="6">Changes in <u>Cash</u>: growth & <span style="border-bottom:1px dotted blue" title="additions include RMDs">additions</span> </th>'
   amess+='<th style="border-left:3px dotted black" colspan="3">After Growth</th>'
//   amess+='<th style="border-left:3px solid black" colspan="3">Prior entry</th>'
   amess+='</tr>';

   amess+='<tr><th> </th>';
   amess+='<th  style="border-left:3px solid black" ><u>Cash</u></th><th>netValue</th> ';
   amess+='   <th  style="border-left:3px solid black"> ';
   amess+= '  <span style="border-bottom:1px dotted cyan" title="Changes in cash (revenue from sales - cost of purchase"> Net &#129008; </span> </th>';
   amess+='  <th>Sales</th>  <th> - Purchases</th> <th> + reFinance</th>';
   amess+=' <th  style="border-left:3px dotted black">Sold  </th>  <th>Purchased  </th>  <th>Changed  </th>  <th>reFinanced  </th> ';
   amess+='<th style="border-left:3px solid black"> RevnAT </th><th>ExpnAT</th> <th>loanAT</th><th>addRaw</th><th>cashInt</th><th>oneOffs</th> ';
   amess+='<th style="border-left:3px dotted black" ><u>Cash</u></th> <td>netVal</td>  <td>days</td>  ';
   amess+='</tr>';

// first data row is  just cash and netValue for initialzation entry

   let initStartDateSay=portfolioInit[pname]['dateStampSay'];
    let initStartDate=portfolioInit[pname]['dateStamp'];
   let initCashAsset=portfolioInit[pname]['cashAsset'];
   let initCashAssetSay=wsurvey.makeNumberK(initCashAsset,100000,0)  ;
   let initTotNetValue=portfolioInit[pname]['totNetValue'];
   let initTotNetValueSay=wsurvey.makeNumberK(initTotNetValue,100000,0)  ;

   let totRevenue=portfolioInit[pname]['totals']['totYearlyRevenue'];
   let totRevenueSay= wsurvey.makeNumberK(totRevenue,100000,0)  ;

   let totLoans=portfolioInit[pname]['totals']['totLoanPayYear'];
   let totLoansSay= wsurvey.makeNumberK(totLoans,100000,0)  ;


// initialzation

  let initStartDateButton='<input type="button" value="'+initStartDateSay+'" data-date="'+initStartDate+'" onClick="clickWhichPortfolio(this)" > ';
  let amess0='';
   amess0+='<tr  bgcolor="#dfdfda"><td>'+initStartDateButton+'</td> ';

   amess0+='<td style="border-left:3px solid black">' ;
   if (initCashAsset<0) {
      amess0+='<span style="color:red">'+initCashAssetSay+'</span>';
   } else {
      amess0+='<span>'+initCashAssetSay+'</span>';
   }
   amess0+='</td>';

   amess0+='<td >'+initTotNetValueSay+'</td>';
   amess0+='<td  style="border-left:3px solid black; text-align: right;margin-right:1em " colspan="8 align="middle"><em>the initial entry (initial yearly values) ... </em></td> '
   amess0+='<td style="border-left:1px dotted lightgray">'+totRevenueSay+'</td>';
   amess0+='<td>'+totLoansSay+'</td>';
   amess0+='<td> ... </td>';
   amess0+='<td colspan="6"> ... </td>';
   amess0+='</tr>';

    amess+=amess0;


// now the modification entries  ...

   if (modStuff!==false) {

   for (adate in modStuff) {
      let amods1=modStuff[adate];

      let adateSay=setEntryDate(adate).sayDate ;
      let adateSayButton='<input type="button" value="'+adateSay+'" data-date="'+adate+'" onClick="clickWhichPortfolio(this)" > ';

       let aTotNetValue=amods1['totalsNet']['totPortfolioValue'];
       let aCashAsset=amods1['totalsNet']['cashAsset'];
       aTotNetValueSay= wsurvey.makeNumberK(aTotNetValue,100000,0)  ;
       aCashAssetSay= wsurvey.makeNumberK(aCashAsset,100000,0)  ;

        let netProceeds=amods1['summaryChanges']['totCashChange'];        // changes   due to sales & purchase of a modification
        let totSales=amods1['summaryChanges']['totSales'];
        let totPurchases=amods1['summaryChanges']['totPurchases'];
        let refiExtra=amods1['summaryChanges']['totRefiExtra'] ;

       let taxDeferred_tax=amods1['summaryChanges']['taxDeferred_tax'] ;
       let capGains_tax=amods1['summaryChanges']['capGains_tax'] ;

       let proceedsSay=wsurvey.makeNumberK(netProceeds,100000,0);
      let refiSay=wsurvey.makeNumberK(refiExtra,10000,0);
        let salesSay=wsurvey.makeNumberK(amods1['totSales'],100000,0)  ;
        let netSalesSay=wsurvey.makeNumberK(totSales,100000,0)  ;         // pre tax
        let purchasesSay=wsurvey.makeNumberK(totPurchases,100000,0);       // indluces reficosts
        let sellArray=[],purchArray=[],changeArray=[],refiArray=[] ;

        changeArray=amods1['summaryChanges']['changeList'];
        for (let aa in amods1['summaryChanges']['removeList']) sellArray.push(aa);  // object to array
        for (let aa in amods1['summaryChanges']['newList']) purchArray.push(aa);
        for (let aa in amods1['summaryChanges']['refiList']) refiArray.push(aa);

      amess+='<tr><td>'+adateSayButton+'</td> ';

// current colspan
      amess+='<td style="border-left:3px solid black">';
      if (aCashAsset<0) {
         amess+='<span title="\`Cash\` after growth and modifications." style="color:red">'+aCashAssetSay+'</span>';
      } else {
         amess+='<span title="\`Cash\` after growth and modifications.">'+aCashAssetSay+'</span>';
      }
      amess+='</td> ';
      amess+='<td ><div title="Net value (including `Cash`">'+aTotNetValueSay+'</div></td> ';

// $changes due to modifciations
      amess+='<td style="border-left:3px solid black">';
      let zt1=wsurvey.addComma(parseInt(taxDeferred_tax));
      let zt2=wsurvey.addComma(parseInt(capGains_tax));
      amess+='    <div title="Includes\n * '+zt1 +' taxImpacts of changes in tax-deferred bonds\n * '+zt2+' capital gains taxes" >'+proceedsSay+' = </div></td> ';
      amess+='<td><div    title="The pre tax value: '+totSales.toFixed(0)+'">'+netSalesSay+'</div></td> ';
      amess+='<td><div  title="Cost of acquiring new assets: '+totPurchases.toFixed(0)+'. Before tax (does not adjust for tax-deferred tax impacts)">'+purchasesSay+'</div></td> ';
      amess+='<td><div    title="Cost (or extra cash) from refinancing loans: '+refiExtra.toFixed(0)+'">'+refiSay+'</div></td> ';

// which assets were changed/sold/etc
      amess+='<td style="border-left:3px dotted black">';
      amess+='  <div style="border:1px dotted brown">'+sellArray.join(' ')+'</div></td> ';
      amess+='<td><div style="border:1px dotted brown">'+purchArray.join(' ')+'</div></td> ';
      amess+='<td><div style="border:1px dotted brown">'+changeArray.join(' ')+'</div></td> ';
      amess+='<td><div style="border:1px dotted brown">'+refiArray.join(' ')+'</div></td> ';

// changes due to grwoth (note that cashChanges incorporate within period interest growth)

      let cashGrowth= amods1['grown']['grown']-amods1['grown']['cashChangeObj']['startCash'];
      let cashAssetChangeGrowSay=wsurvey.makeNumberK(cashGrowth,100000,0)  ;

      let totRevenue=amods1['grown']['totPeriod']['totIncomeBothPeriod_AT'] + amods1['grown']['totPeriod']['totRentPosAT'];
      let revenueSay=wsurvey.makeNumberK(totRevenue,100000,0)  ;

      let totExpense=amods1['grown']['totPeriod']['totExpensePeriod_AT'] + amods1['grown']['totPeriod']['totRentNegAT'];
      let expenseSay=wsurvey.makeNumberK(totExpense,100000,0)  ;

       let loanPayment=amods1['grown']['totPeriod']['totLoanPayPeriod_AT'];
      let loanPaymentSay=wsurvey.makeNumberK(loanPayment  ,100000,0)  ;

      let otherAdds= amods1['grown']['sumByTypePeriod']['bondAddSumPeriod']     ;
       let additionSay=wsurvey.makeNumberK(otherAdds ,100000,0)  ;

      let daysGrow=amods1['growDays']

      let cashAssetAfterGrowth=amods1['grown']['cash'];
      let cashAssetAfterGrowthSay=wsurvey.makeNumberK(cashAssetAfterGrowth,100000,0);

      let oneOff=amods1['grown']['sumByTypePeriod']['totReceiptPeriod'];;
      let oneOffSay=wsurvey.makeNumberK(oneOff,10000,0);

      let netValueAfterGrowth=amods1['totalsNet']['totAssetSaleNetAT']+  cashAssetAfterGrowth ;
      let netValueAfterGrowthSay=wsurvey.makeNumberK(netValueAfterGrowth,100000,0);

      let zcashInterest=amods1['grown']['cashChangeObj']['earnAdd']  ;
      let zcashInterestSay=wsurvey.makeNumberK(zcashInterest,10000,0);

      amess+='<td style="border-left:3px solid black" ><div  title="+rents + incomes + annuities: '+totRevenue.toFixed(0)+'   ">'+revenueSay+'</div></td>';
      amess+='<td ><div  title="-rents+ expenses"'+totExpense.toFixed(0)+'    ">'+expenseSay+'</div></td>';
      if (Math.abs(loanPayment)<1.0) {
         amess+='<td><span title="loan payments     ">0</span></td>';
      } else {
         if (loanPayment>0) {
            amess+='<td><span title="loan payments: '+loanPayment.toFixed(0)+'"  style="color:red">-'+loanPaymentSay+'</span></td>';
         } else {
            amess+='<td><span title="loan payments" >-'+loanPaymentSay+'</span></td>';
         }
      }
      amess+='<td><span title=" Negative: used to purchase of more bonds  \n Positive: deposits from sale of bonds (including RMDS) ">'+additionSay+'</span></td>';

       amess+='<td><span title=" interest on `Cash` (growth of starting amount, and growth of daily changes)">'+zcashInterestSay+'</span></td>';
      amess+='<td><span title=" oneOff reciepts (on first day after start of prior period"    ">'+oneOffSay+'</span></td>';

// values after growth
      amess+='<td style="border-left:3px dotted black"><div    title="`Cash` asset (after growth, before modifications). ">'+cashAssetAfterGrowthSay+'</div></td>';
      amess+='<td><span title="approximate netValue, including `Cash` (after growth, before modifications). ">'+netValueAfterGrowthSay+'</span></td>';
      amess+='<td><span title="days of growth (since prior entry)">'+daysGrow+'</span></td>';

      let cashAssetPrior=amods1['grown']['cashChangeObj']['startCash'];
      let cashAssetPriorSay=wsurvey.makeNumberK(cashAssetPrior,100000,0);

      amess+='</tr>';
   }
   amess+='</table>';

   } else {  // no modifications ...
       amess+='</table>';
   }


   esummary.html(amess);
   esummary.attr('data-made',1);

   if (aMode==2 && noScroll==0) {
      let e3b=$('#mainDiv');
      let atop=esummary.offset().top ;          // 21 dec 2023 ... this sometimes throws an error (but not fatal)
      e3b.animate({scrollTop:atop}, 500);
   }
   return amess;
}


function showPortfolioViewModify_listMods_top(athis) {   // scroll to top of mainDiv (the list of modifications
      let e3b=$('#mainDiv');
      atop=0;
      e3b.animate({scrollTop:atop}, 500);
}


///==================
// click a whichPortfolio button (to display its asset mix.
// event handler for date col in transactions table
function clickWhichPortfolio(athis) {
   let ethis=wsurvey.argJquery(athis);
   let adate=ethis.attr('data-date');
  let eList=$('#portfolioModificationsList');
  let eListSummary=eList.find('[name="whichPortfolio"]');
  let e1=eListSummary.filter('[data-date="'+adate+'"]');
  if (e1.length!=1) {
     alert('Unable to find button for: '+adate);
  } else {
     e1.trigger('click');
  }
  return 1;
}

//===========================    agrows
// modify a portfolio: first step --  open a menu that asks for a date
// this is called from the "Modify xx" button

function showModifyPortfolio_step1(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-name');
   let sayDate=ethis.attr('data-creationDate');
   let daycount=ethis.attr('data-daycount');
   let e1= $('#viewPortfolioMods_input');                // this is hard coded, so show it...
   e1.show();
   let ebutton=e1.find('[name="modButton1"]')
   ebutton.attr('data-name',aname);
   ebutton.attr('data-creationDate',sayDate);
   ebutton.attr('data-daycount',daycount);              // note that a submit button,which  calls   showModifyPortfolio_step2, is hard coded

}

//=================
// modify an existing modificiaton entry (click handker for the tetragamChange 'change this modification' button
function  showModifyPortfolio_step1Tweak(athis) {
  let ethis=wsurvey.argJquery(athis);
  let pname=ethis.attr('data-name');
  let ith=ethis.attr('data-ith');                 // the position (in list of entries) of the "Modification entry" to be changed. Must be > 0

  showModifyPortfolio_step2(pname,ith)  ;  // showModifyPortfolio_step1Tweak:  ith identifies the "mod entry to change"

// change header ...
   let eb=$('#portfolioMenu_initDateBlock');

   let eb3=eb.find('[name="portfolioDate0"]');
   eb3.show();
   eb3.html('Change existing modification ...');
   eb3.attr('title', 'Using existing modification # '+ith);
}

//===========
// make the modifications .. step 2
// see modPortfolioNotes.txt for details
//
// called by "specify the modifications" button in   showPortfolioViewModify, or by showModifyPortfolio_step1Tweak ---
//   step1  -- the user specifies a date, and then clicks the button.  -- single argument
//   step1Tweak -- use the date of an existing modification (so as to change the modification)  -- 2 arguments

function showModifyPortfolio_step2(athis,ith) {       // if ith specified, this is a "modify existing modification"

   let pname,useEntry,theModDate ;    // false not same as 0
   let changeExisting=false  ;

   if (arguments.length==1)  {                 //  modify just prior (possibly initialziation)  called via button (step version)

      let ethis=wsurvey.argJquery(athis);
      pname=ethis.attr('data-name');
      let dd2=wsurvey.dateBox_read('#viewPortfolioMods_input',1)  ;
      if (dd2===false)  {
         alert("Bad date entry: please try again!");
         return 0;
      }

      ayear=parseInt(dd2['year']);
      amonth=parseInt(dd2['month']);
      aday=parseInt(dd2['day']);

      let oof=setEntryDate(ayear,amonth,aday);
      if (oof===false)  {    // should not happen
         alert("Bad date entry in showModifyPortfolio_step2");
         return 0;
      }
      theModDate=oof['dayCount'];
      useEntry=portfolio_findBaseEntry(pname,false,theModDate,0) ;  // user entered date
      if (useEntry['status']!='error') $(document).data('lastEntryDate',oof);  // use this as default  in enter-a-date fields (in future modifcations)


    } else   {     // modify existing  (using ith modification)

       pname=athis;
       useEntry=portfolio_findBaseEntry(pname,ith);              // date of an existing modification (or init)
       theModDate=useEntry['modDate'];
       changeExisting=ith
    }

    if (useEntry['status']=='error') {
      alert('showModifyPortfolio_step2 errror: '+ useEntry['message']);
      return false;
    }
    if (useEntry['status']=='cancel')  return false ;

// useEntry is the entry to be modified (either the initialization entry, or an existing modifiction)

    wsurvey.wsShow.hide('#statusDiv');

    let ithUse=useEntry['ith'],startDate=useEntry['baseDate'],cashAsset=useEntry['entry']['cashAsset'],assetUse=useEntry['entry']['assetList'];

// ::: This grows   the "prior" entry at closestStamp(up to theModDate)    ...
 
// last arg is false since modifications have not been made yet! --- they will be specified by ther user
    let grownEntry=growPortfolioDo(pname,assetUse,cashAsset,startDate,false,theModDate,'new modification',ithUse,false) ;

// build a summary  (pre change, after growth)
   let summA;
   let growDays=grownEntry['growDays'] ;

     if (growDays>0) {
      summA=portfolio_totalSummary(grownEntry,'<span title="after '+growDays+' days of  growth, before modification"><em>after '+growDays+' days </em></span>',1);
   } else {     // if 0, MUST be a "change existing modification" (given iug check above)
      summA=portfolio_totalSummary(grownEntry,'<em>change an existing modification</em>',1);
   }


// ....... ANd this DISPLAYS the user modifiable menu (with the grown asset values) ...
// reminder: grownEntry starts with a clone of baseEntry.

    buildPortfolioMenu_mod(grownEntry,theModDate,changeExisting);     // showModifyPortfolio_step2: display the assets in the "grown" entry,  OR display the "mod entry to change" assets

   $('#assetHistory_currentSummary').html(summA[0]).show();   // will happen on button push (for initialziation of a portfolio)

    let tnet=grownEntry['totNetValue'];       // should be actual
   let cashAssetNow=grownEntry['cashAsset'];
    portfolioCalcValueBudgetWarn(cashAssetNow,1,tnet) ;  // write warning messages?

    simInvDsets['entryWorking']=grownEntry ;                 //  entryWorking is a global  used when a "modified" entry is submitted

    let asay='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioHistoryHelp1">&#10068;</button> Modify portfolio <b>'+pname+'</b> &#128144;  '

    hidePortfolioHeader(1,asay);
    return 1 ;
}



//================
// reset portfolio values on a "modified entry" menu

function growPortfolio_reset(athis) {
   let etable=$('#portfolioHistory1');
   let efields=etable.find('.portfolioAssetNameNew');

   for (let i1=0;i1<efields.length;i1++) {     // un remove
     let eb=$(efields[i1]);
      let erow=eb.closest('tr');
      erow.attr('data-remove',0);
      erow.css({'opacity':1.0,'font-size':'100%'});
   }

   let einputs=etable.find('.modReset');           // all input fields that can be "reset" when "modifying a portflio"
   for (let i1=0;i1<einputs.length;i1++) {       // reset to "original"
       let  e1=$(einputs[i1]) ;
       let v1=e1.attr('data-orig');
         v1=jQuery.trim(v1);
       let v1say=''
       if (v1!=='')   {
           v1=parseFloat(v1);
           v1say=v1.toFixed(2);
        }
        e1.val(v1say);
   }


   let einputs2=etable.find('.modResetHide');           // the loan fields that might be non-hidden due to refiance -- hide them!
   for (let i1=0;i1<einputs2.length;i1++) {
       let  e1=$(einputs2[i1]) ;
       e1.attr('type','hidden');
   }


   let ep1=etable.find('[name="portfolioLoan_currentSpecs"]'); 
   if (ep1.length==1) {
      ep1.removeClass('cLoanSpecsRefi');
      ep1.attr('title','Current loan specs');
   }

   return 1;
}


//====================
// review the modifications to the portfolio
function reviewPortfolioMod(athis) {

 let ethis=wsurvey.argJquery(athis);
 let pname=ethis.attr('data-name');

  let  astuff=portfolioCalcValueMenu_modify(athis);          // in reviewPortfolioMod
  if (astuff===false) return 1;                               // an error

  let newvals= simInvDsets['entryWorking']['changed']['modifiedEntry']['assetList'];
  if (newvals===false) return false ;

  let dateStamp= simInvDsets['entryWorking']['changed']['portfolioValue']['dateStamp'];
  let dateStampSay= simInvDsets['entryWorking']['changed']['portfolioValue']['dateStampSay'];
  let cashAsset= simInvDsets['entryWorking']['changed']['portfolioValue']['cashAsset'];

  let totNetValue= simInvDsets['entryWorking']['changed']['summary']['totPortfolioValue'];

  let totAssetSaleNetAT= simInvDsets['entryWorking']['changed']['summary']['totAssetSaleNetAT'];

  let  nAssets=newvals.length;

  let  nNew=0,nRemove=0;
  for (let oink in simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['newList']) nNew++ ;
  for (let oink in simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['removeList']) nRemove++ ;
  let nChange=simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['changeList'].length;

  let nStock=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nStock'];
  let nRegular=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nRegular'];
  let nTaxDefer=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nTaxDefer'];
  let nProperty=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nProperty'];
  let nIncome=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nIncome'];
  let nLoan=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nLoan'];
  let nExpense=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nExpense'];

  let totStockAT=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totStockAT'];
  let totRegular=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totRegularAT'];
  let totTaxDeferredAT=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totTaxDeferredAT'];
  let totPropertyNetAT=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totPropertyNetAT'];
  let totYearlyNetRent=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totYearlyNetRent'];
  let totLoanOwed=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totLoanOwed'];
  let totLoanPayYear=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totLoanPayYear'];
  let totYearlyIncomeAT=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totYearlyIncomeAT'];
  let totYearlyAnnuityAT=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totYearlyAnnuityAT'];
  let totYearlyExpenseAT=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['totYearlyExpenseAT'];

  let totOneOffReceipts=simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['totOneOffReceipts'];

   let nAnnuity=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nAnnuity'];
   let nIncomeStream=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nIncomeStream'];
   let nOneOff=simInvDsets['entryWorking']['changed']['portfolioValue']['totals']['nOneOff'];

  newvals['comment']='modification and review (of grown entry): '+dateStampSay;

 bmess="<b>Summary of modification</b>";
 if (astuff['statusMessage'].length>0) {
    let smess='<table cellpadding="5"><tr><td width="10%" valign="top">';
    smess+='<input type="button" value="x" title="close these notes " onClick="$(\'#modSummaryNotes\').hide()"><em>Notes:</em> ';
    smess+='</td><td width="88%">';
     smess+=astuff['statusMessage'].join('<br>');
    smess+='</td></tr></table>';
    bmess+='<div id="modSummaryNotes" style="margin:3px 3em;background-color:tan">';
    bmess+=smess;
    bmess+='</div>';
 }
 bmess+='</div>';
 bmess+='<menu class="boxList">';
 bmess+=' <li>Enter a comment:<input type="text" value="" id="modComment" title="Optional comment about this modification" size="60">';
 bmess+=' <li><em>and then ... </em> ';
 bmess+='<button class="cdoButton" onClick="saveModifiedPortfolio(this)" data-name="'+pname+'">Save this modified portfolio</button> ';
 bmess+=' <span style="float:right;margin-right:1em" > <em>or ... </em> <button title="Do not save -- you can make additional changes!" onClick="hideStatusMessage(100)">do not save</button></span> ';
 bmess+='</menu>';

 bmess+='<ul class="tightMenu">';

 bmess+='<li><div style="font-size:115%;border:1px solid blue;border-radius:3px;padding:3px"> ';
 bmess+=' netValue (assets and <u>Cash</u>): <tt>'+wsurvey.addComma(parseInt(totNetValue))+'</tt> ';
 bmess+=' :: net assets (after tax)= <tt>'+wsurvey.addComma(parseInt(totAssetSaleNetAT))+'</tt> ' ;

 if (cashAsset>0) {
   let cc=(100*simInvParams['cashInterest']).toFixed(1);
   bmess+=' &amp; <span style="color:green" title="Positive cash assets grow  @ '+cc+'%/yr"><u>Cash</u>=  <tt>'+wsurvey.addComma(parseInt(cashAsset))+'</tt></span> ' ;
 } else {
   let cc=(100*simInvParams['cashPenalty']).toFixed(1);
   bmess+=' &amp; <span style="color:red" title="Negative cash assets grow (become more negative) @ '+cc+'%/yr"><u>Cash</u>=  <tt>'+wsurvey.addComma(parseInt(cashAsset))+'</tt></span> ' ;
}
  bmess+='</div>';

// bmess+=' &amp; <u>Cash</u>=  <tt>'+wsurvey.addComma(parseInt(cashAsset))+'</tt> ' ;

 bmess+='<li>Number of assets: <tt>'+nAssets+'</tt> ';

 bmess+=' &nbsp;&nbsp;(#removed= <tt>'+nRemove+'</tt>, #added= <tt>'+nNew+'</tt>, ';
 bmess+='#changed= <tt>'+nChange+'</tt> ).';
 bmess+='<menu class="tighterMenu">';
 bmess+='<li> <tt>'+ nStock +'</tt> stock assets  ~netValue (after tax): <tt>'+wsurvey.addComma(parseInt(totStockAT))+'</tt> ';
 bmess+='<li> <tt>'+ nRegular +'</tt> regular bonds: ~netValue: <tt>'+wsurvey.addComma(parseInt(totRegular))  + '</tt>';
 bmess+=' &amp; '+ nTaxDefer +'</tt>  taxDeferred bonds  ~netValue (after tax) : <tt>'+wsurvey.addComma(parseInt(totTaxDeferredAT))+'</tt> ';
 bmess+='<li> <tt>'+ nProperty +'</tt> properties ~netValue (after tax): '+wsurvey.addComma(parseInt(totPropertyNetAT))+'</tt> ';

 bmess+=' (~netRent=<tt>'+wsurvey.addComma(parseInt(totYearlyNetRent))  +'</tt>)';

 if (nLoan>0) {
    bmess+=' &hellip;<tt>'+nLoan+'</tt> loans: <em>owed</em>: <tt>'+wsurvey.addComma(parseInt(totLoanOwed)) +'</tt>, ' ;
    bmess+=' yearly loan payments (pre tax): <tt>'+wsurvey.addComma(parseInt(totLoanPayYear))+'</tt> ';
 }
 let inc2=totYearlyIncomeAT+ totYearlyAnnuityAT ;
 bmess+='<li> <tt>'+ nIncomeStream+'</tt> incomeStreams &amp; <tt>'+nAnnuity+'</tt> annuities (yearly): approximate after tax= <tt>'+wsurvey.addComma(parseInt(inc2)) +'</tt> ';
 bmess+='<li> <tt>'+ nExpense +'</tt> expense assets after tax (yearly): <tt>'+wsurvey.addComma(parseInt(totYearlyExpenseAT))+'</tt> ';
 bmess+='<li> <tt>'+ nOneOff+'</tt> oneOffs  ~ one time receipt: <tt>'+wsurvey.addComma(parseInt(totOneOffReceipts)) +'</tt> ';


 let capGainsTax=simInvDsets['entryWorking']['changed']['summary']['totCapGainTax'];
 let deferredTax=simInvDsets['entryWorking']['changed']['summary']['totDeferredTax'];
 capGainsTaxSay=wsurvey.addComma(parseInt(capGainsTax));
 deferredTaxSay=wsurvey.addComma(parseInt(deferredTax));

 bmess+='<li>Taxes (if all assets liquidated):  capGains= $'+capGainsTaxSay+', taxDeferred tax= $'+deferredTaxSay ;

 bmess+='</menu>';

 bmess+='<li><em>Modifications:</em> ';

 let achange=parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['totCashChange']) ;
 let achangeSay=wsurvey.addComma(achange);
 bmess+='netTransactions: '+ achangeSay;
 bmess+=' &#129008; ';

 let totSalesPeriod=parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['totSales'])
 let totPurchasesPeriod=parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['totPurchases'])

 bmess+='  <span style="color:green" title="Proceeds from liquidation and sale of existing assets"> <tt> $'+ wsurvey.addComma(parseInt(totSalesPeriod))+'</tt> </span>  ' ;
 bmess+='&#8722;  ';
 bmess+='  <span style="color:red" title="Costs of obtaining newly added assets"><tt> $'+ wsurvey.addComma(totPurchasesPeriod) +'</tt></span>  ' ;

  let tpnet=simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['totPropertyNet'] ;
  if (tpnet>0)  bmess+=' &hellip;  <em> net property sales</em>: <tt> '+ wsurvey.addComma(parseInt(tpnet))+'</tt>' ;

// stats on added + removed incomeStreams + annuities
  let nIncomeStop=0,tIncomeStop=0,nIncomeStart=0,tIncomeStart=0,nExpenseStop=0,tExpenseStop=0,nExpenseStart=0,tExpenseStart=0;
  for (let aaa in simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['removeList']) {       // assets liquidated or stopped
    if (simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['incomeListChange'].hasOwnProperty(aaa)) {
        nIncomeStop++;
        tIncomeStop+=simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['incomeListChange'][aaa];
    }
    if (simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['expenseListChange'].hasOwnProperty(aaa)) {
        nExpenseStop++;
        tExpenseStop+=simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['expenseListChange'][aaa];
    }

  }
  for (let aaa in simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['newList']) {
    if (simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['incomeListChange'].hasOwnProperty(aaa)) {
        nIncomeStart++;
        tIncomeStart+=simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['incomeListChange'][aaa];
    }
    if (simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['expenseListChange'].hasOwnProperty(aaa)) {
        nExpenseStart++;
        tExpenseStart+=simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['expenseListChange'][aaa];
    }

  }
 tIncomeStopSay=wsurvey.makeNumberK(tIncomeStop,30000);
 tIncomeStartSay=wsurvey.makeNumberK(tIncomeStart,30000);

 tExpenseStopSay=wsurvey.makeNumberK(tExpenseStop,30000);
 tExpenseStartSay=wsurvey.makeNumberK(tExpenseStart,30000);


 bmess+='<menu class="tightMenu">';
 if (nIncomeStop+nIncomeStart>0) {
   bmess+='<li>Changes in income &amp; annuities): '+nIncomeStop+' ended (' +tIncomeStopSay+') &amp; '+nIncomeStart+' added ('+tIncomeStartSay+') ';
   bmess+='<li>Changes in expenses: '+nExpenseStop+' ended (' +tExpenseStopSay+') &amp; '+nExpenseStart+' added ('+tExpenseStartSay+') ';
 }

 bmess+='<li> ';
 let ff1=[];
 for  (let aa in  simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['refiList']) {
     let refiExtra=simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['refiList'][aa];
     if (Math.abs(refiExtra)<1.0) refiExtra=0;      // ignore small differences
     if (refiExtra<0) {             //   refinaced for less than outstanding loan
        z1='<span style="color:red" title="Refinance less than loanOwed (difference drawn from `Cash`): '+parseInt(refiExtra)+'">'+aa+'</span>';
    } else if (refiExtra>0) {
        z1='<span style="color:green" title="Refinance greater than loanOwed (difference deposited in`Cash`): '+parseInt(refiExtra)+'">'+aa+'</span>';
    } else {
        z1='<span style="color:brown" title="Refinance equals loanOwed ">'+aa+'</span>';
    }
    ff1.push(z1);
 }
 let refiSay= ff1.join(' | ');


// stats on removed assets (liquidated or stopped)
 let ss1=[];
 for  (let aa in  simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['removeList']) {
     let z1;

     if (simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['incomeListChange'].hasOwnProperty(aa)) {       // not an income ... so earnings recieved
         z1='<span style="color:blue" title="Loss of yearly income: '+parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['incomeListChange'][aa])+'">'+aa+'</span>';
     } else if (simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['expenseListChange'].hasOwnProperty(aa)) {       // not an income ... so earnings recieved
          z1='<span style="color:orange" title="Loss of yearly expense: '+parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['expenseListChange'][aa])+'">'+aa+'</span>';
     } else {
        z1='<span style="color:red" title="Earnings from liquidated asset: '+parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['saleList'][aa])+'">'+aa+'</span>';
     }
    ss1.push(z1);
 }
 let rmSay= ss1.join(' | ');


//stats on newly purchases assets
 let nn1=[];
 for  (let aa in  simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['newList']) {
     let z1;

     if (simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['incomeListChange'].hasOwnProperty(aa)) {       //   an income ... so earnings recieved
         z1='<span style="color:darkblue" title="Increase in yearly income: '+parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['incomeListChange'][aa])+'">'+aa+'</span>';
     } else if (simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['expenseListChange'].hasOwnProperty(aa)) {       //   an expense
         z1='<span style="color:darkblue" title="Increase in yearly expense: '+parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['expenseListChange'][aa])+'">'+aa+'</span>';
     } else {
        z1='<span style="color:red" title="Cost of newly added asset: '+parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['purchaseList'][aa])+'">'+aa+'</span>';
     }
     nn1.push(z1);
 }
 let newSay= nn1.join(' | ');


 let rr1=[];
 for  (let iaa=0; iaa<simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['changeList'].length;iaa++) {
     let aa =simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['changeList'][iaa];
     let z1;
     if (simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['purchaseList'].hasOwnProperty(aa)) {       // an addition
         z1='<span style="color:red" title="Cost of change (addition): '+parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['purchaseList'][aa])+'">'+aa+'</span>';
      } else {
         z1='<span style="color:green" title="Earnings from sales (pre-tax): '+parseInt(simInvDsets['entryWorking']['changed']['modifiedEntry']['summary']['saleList'][aa])+'">'+aa+'</span>';
      }
      rr1.push(z1);
 }
 let chgSay= rr1.join(' | ');

 bmess+='<span class="cListOfChangeAssets" >Removed:<tt> '+ rmSay+'</tt></span> ';
 bmess+='<span class="cListOfChangeAssets">New:<tt> '+newSay+'</tt></span> ';
 bmess+='<span class="cListOfChangeAssets">Changed:<tt> '+ chgSay+'</tt></span> ';
 bmess+='<span class="cListOfChangeAssets">reFinance:<tt> '+refiSay+'</tt></span> ';

 bmess+='</menu>';

 bmess+='</ul>';
 displayStatusMessage(bmess);
 toggleStatusDiv(0,0)     ;

}

function propertiesToString(alist,ajoin) {
  if (arguments.length<2) ajoin=', ';
   let plist=[];
   for (let aa in alist) plist.push(aa) ;
   let psay=plist.join(ajoin);
   return psay;
}

//=======================
// save modified portfolio to server   -- called from a button on the review modified portfolio page
function saveModifiedPortfolio(athis) {

  let ethis=wsurvey.argJquery(athis);     // could just use entryWorking, but wth
  let pname=ethis.attr('data-name');

  let qqv=portfolioCalcValueMenu_modify(0,pname);   //  in saveModifiedPortfolio -- probablyh redundant (given review step), but wth

  if (qqv===false) return false ;     // should never happen

  let e1=$('#modComment');
  let acomment_mod=jQuery.trim(e1.val());

  let  modDate=simInvDsets['entryWorking']['changed']['portfolioValue']['dateStamp'];
  let  modDateSay=simInvDsets['entryWorking']['changed']['portfolioValue']['dateStampSay'];

  let priorDate=simInvDsets['entryWorking']['base']['priorDate'];
  let priorIth=simInvDsets['entryWorking']['base']['ith'];

  let useEntry={'name':pname, 'dateStamp':modDate,'dateStampSay':modDateSay,'priorDate':priorDate,'priorIth':priorIth};
  useEntry['modComment']= acomment_mod;
  useEntry['cashAsset']=simInvDsets['entryWorking']['changed']['cashAsset'];
  useEntry['assetList']=simInvDsets['entryWorking']['changed']['modifiedEntry']['assetList'];
  useEntry['summary']=simInvDsets['entryWorking']['changed']['summary'];

//  -- add to existing porgfolioes

   let nowTime=wsurvey.get_currentTime(0);
   let ddata={'time':nowTime,'data':{}};

   for (let aport in simInvDsets['allCurrentData']['portfolioModifications']['data']) {  // copy
       ddata['data'][aport]=JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['portfolioModifications']['data'][aport])) ;
   }
   if (!simInvDsets['allCurrentData']['portfolioModifications']['data'].hasOwnProperty(pname)) ddata['data'][pname]={};  // no prior modifications
   ddata['data'][pname][modDate]=useEntry;

  let bmess='Saving modification, with '+useEntry['assetList'].length+' assets ';

   simInvGlobals['temp']['autoLogonDetails']={'action':'portfolioModification','portfolio':pname} ;
   saveSimInvData_portfolioModification(userName,ddata,bmess);
   simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie


}


//=============
// add a  empty (no values assigned) row to the portfolio assetMix menu -- using asset name assigned to athis (button push)
// addARowPortfolioAssetMix to specify values
// if aname and assettype arguments, use them. Otherwise read from button attributes

function portfolioAddAssetNew(athis,isMod,aname,assetType ) {
   let ethis,jdate,ison=0;
   if (arguments.length<2) isMod=1;
   if (arguments.length<3) {
      ethis=wsurvey.argJquery(athis);
      aname=ethis.val();
     assetType=ethis.attr('data-type');
     let ison=ethis.attr('data-chosen');
   }
   if (isMod==1) {
      if (arguments.length>2) {
         let oof=getCreationDate('#portfolioMenu_initDateBlock');
         jdate=oof['dayCount'];
      } else {
         jdate=ethis.attr('data-date');
      }
   } else {                     // init date can be set by user menu
       let oof=getCreationDate('#portfolioMenu_initDateBlock');
       jdate=oof['dayCount'];
   }

   let etable=$('#portfolioHistory1AssetRows');

   if (ison==1) {             // already selected, so scroll it into view

     let egots=etable.find('[name="portfolioAsset"]');
     let egot1=egots.filter('[data-orig="'+aname+'"]');
     if (egot1.length==0) return 0  ;     // should not happen
     let etr=egot1.closest('.portfolioHistoryRow');
     wsurvey.centerInParent(etr,{'duration':300});

     let erems=etable.find('[name="removeThisRowButton"]');
     erems.removeClass('chighlightAssetButton');

     let erem=etr.find('[name="removeThisRowButton"]');
     erem.addClass('chighlightAssetButton');

     return 1;
   }

// check if asset from same family already in protfolio -- also test for asset already added, which should not happen (give disabling of buttons)
   let omess=portfolio_checkAssetAdded(aname);    // portfolioAddAssetNew: asset exists? Not alredy in portfolio?  Not in same family (if sameFamily not permitted)
   if (omess!==false) {
        alert(omess);
        return 0;
   }

   if (arguments.length<3) {
       ethis.attr('data-chosen',1);
       ethis.addClass('chighlightAssetButton');
   }


// empty (except for name and type) pre-population data
   useTheseEmpty={'name':aname,'nShares':'','comment':'','basis':'','assetType':assetType,'comment':'','cost':'','price':'',
            'loanAmount':'','loanTerm':'','loanRate':'','incomeStart':'','modState':0,'acqCost':0,'purchaseCost':0,'addition':0,'doRMD':0,'rmdStart':''};

 // add the row

   let etr=addARowPortfolioAssetMix(isMod,useTheseEmpty,0,jdate,'portfolioMenu_initDateBlock') ;    // portfolioAddAssetNew: add new (no specs) row to portfolio menu   ... etr is used for highlighting
   wsurvey.centerInParent(etr,{'duration':300});      // scroll to this row in the portfolio menu

   let erems=etable.find('[name="removeThisRowButton"]');
   erems.removeClass('chighlightAssetButton');
   let erem=etr.find('[name="removeThisRowButton"]');
   erem.addClass('chighlightAssetButton');


  return etr;


}

//============================    ethis  egoo     eli   aprice
// check if an asset is already added, or if one of its family has been added
// return false if okay (no match, and no family match)
// otherwise a string error message
// anamex : full name of asset to check 
// haveLIst : ojbect of asset, as created by portfolioMenu_assetFamily. If not specified, portfolioMenu_assetFamily is called
function  portfolio_checkAssetAdded(anameX,haveList) {

   let aname=jQuery.trim(anameX).toLowerCase();

   if (!assetLookup.hasOwnProperty(aname)) return 'Missing asset ('+aname+')' ;

   if (arguments.length<2)   haveList=portfolioMenu_assetFamily(2);    // get list of currently specified (and non removed) assets, and their family
   let anameFamily=aname.split('.',1)[0] ;

    for (let zname in haveList ) {           // look at all the assets currently added to the portfolio's menu ...

        if (zname=='') continue ;                 // will never happen
        if (zname==aname) return 'Asset already added ';

        if (simInvParams['sameAssetFamilyOk']==1) continue ;    // else check for members of current family
        if (haveList[zname]==anameFamily)     return 'There already is a `'+anameFamily+'` asset ('+zname+'). To add '+aname+', you must remove '+zname ;

     }

    return false ;  // false means no problem
}


//=============
// retrieve list of assetnames added to portfolio table
function portfolioMenu_assetFamily(ifoo) {
     haveList={} ;
     let etable=$('#portfolioHistory1AssetRows');
     let eaa=etable.find('[name="portfolioAsset"]');
     for (let ii=0;ii<eaa.length; ii++) {           // look at all the assets currently added to the portfolio's menu ...
        let ea1=$(eaa[ii]);
        let etr=ea1.closest('.portfolioHistoryRow');
        if (etr.attr('data-remove')==1) continue ;
        let zname=jQuery.trim(ea1.val()).toLowerCase();
        if (zname=='') continue ;

        let znameFamily=zname.split('.',1)[0].toLowerCase();
        haveList[zname]=znameFamily;
   }
   return haveList;
}

// ================
// changes between "base, with growth"  (entry0) and "modified by user" (entry1) entries.
// returns a changeEntry and summaires
//
// Note changeEntry modifies entry1 (the user changed entries)  -- for example fixing 'costs' and 'basis' when there is a partial sale of a stock

function  portfolioCalcValueMenu_difference(pname,modDate,entry0,entry1 ) {

  let wasAssets={};
  for (let ia=0;ia<entry0 .length;ia++) {
      let zza=entry0[ia]['name'];
      wasAssets[zza]=ia ;
  }

// a) Clone the list of changed assets, which is then tweaked
   let modList2=[],nowAssets={} ;
   for  (let iz=0;iz<entry1.length;iz++) {
     let tmp1=entry1[iz];
     let atmp2=JSON.parse(JSON.stringify(tmp1))  ;
     atmp2['modifiedDate']=false ;
     modList2.push(atmp2);
     let zza=entry1[iz]['name'];    //   list of  now (new or retianed) assets

     nowAssets[zza]=iz ;
  }

//  let dCosts={},dShares={},dTaxDeferred={},dTaxDeferredAdd={}, dCapGains={} ;

  let  propertySaleList={}, propertySaleListNet={}  ; // changes in costs, sales revenut, and basis
  let retainList=[],removeList={},changeList=[],changeListVals={};
  let incomeListChange={}, expenseListChange={}, newList={} , newListVals={},refiList={};
  let oneOffListNew={} ;
  let saleList={},purchaseList={}  ;
  let saleListTaxDeferred={},purchaseListTaxDeferred={};  // aggregate all tax deferred transactions to determin taxDeferred tax
  let saleListCapGains={} ;                               // aggregate all sales subject to gapCains to determine capGains tax

// new entries == sum up their costs of purchase , or income stream

   for  (let iz=0;iz<modList2.length;iz++) {

     let aentry1=modList2[iz];
     let aAsset =aentry1['name'];

     if  (wasAssets.hasOwnProperty(aAsset)) continue ;         // if not a new asset ... deal with below

     let atype=aentry1['assetType'];

// ...... newly added assets  ...

     if (atype==0) {
          let acost1=aentry1['cost'] ;
          modList2[iz]['basis']=acost1 ;         // fill this in
          newList[aAsset]=acost1;
          newListVals[aAsset]=aentry1['nShares'];

          purchaseList[aAsset]=acost1;

     } else if (atype==1  ) {
          let acost1= aentry1['cost'] ;
          newList[aAsset]=acost1;
          newListVals[aAsset]=aentry1['nShares'];

          purchaseList[aAsset]=aentry1['nShares'] ;
          modList2[iz]['origCost']=acost1 ;         // fill this in

     } else if ( atype==2) {
          let acost1= aentry1['cost'] ;
          purchaseList[aAsset]=aentry1['nShares'];
          purchaseListTaxDeferred[aAsset]=aentry1['nShares'];
          newList[aAsset]=acost1 ;                    // cost will already incorporate tax savings
          newListVals[aAsset]=aentry1['nShares'];
          modList2[iz]['origCost']=acost1 ;         // fill this in

     } else if (atype==3 ) {
          let acost1=aentry1['cost'];
          purchaseList[aAsset]=acost1;                // no need to track "purchases that will be subject to cap gains"
          newListVals[aAsset]=getAssetValue(modDate,aAsset,'price',1) ;;
          newList[aAsset]=acost1 ;

     } else if (atype==4 ) {

          let acost1=aentry1['cost'];
          newList[aAsset]=acost1;
          newListVals[aAsset]=getAssetValue(modDate,aAsset,'income',1);

          purchaseList[aAsset]=acost1;           // acquisitoin cost
          let oof=getAssetValue(modDate,aAsset,false,1);
          incomeListChange[aAsset]=oof['income'];
          modList2[iz]['acqCost']=acost1 ;         // fill this in

     } else if (atype==7 ) {
          acost1=0;
          newList[aAsset]=0;

          newListVals[aAsset]=getAssetValue(modDate,aAsset,'expense',1);

          purchaseList[aAsset]=acost1;          // acquisitoin cost
          let oof=getAssetValue(modDate,aAsset,false,1);
          expenseListChange[aAsset]=oof['expense'];

     } else if (atype==5) {

          let acost1=aentry1['cost'];
          newList[aAsset]=acost1;
          let istart0=aentry1['incomeStart'];
          let xx=calcAnnuityValue(aAsset,istart0,modDate)   ;   // [baseValue,baseGrowth,calcValue,day1,day2,dointerp,growthRateAgg]
          newListVals[aAsset]=xx[2];

          purchaseList[aAsset]=acost1;
          let oof=getAssetValue(modDate,aAsset,false,1);
          incomeListChange[aAsset]=oof['income'];
          modList2[iz]['acqCost']=acost1 ;         // fill this in

     } else if (atype==6) {                         // oneOffs are simpler (just a receipt value)
         oneOffListNew[aAsset]= aentry1['oneOffReceiptOrig'];   ;
     }

     modList2[iz]['addedDate']=modDate;
  }         // new assets

// retained, possibly changed assets    ....  costs from additions, or sale proceeds
//    check if NOT changed.

   for  (let iz=0;iz<modList2.length;iz++) {      // look at assets in the modification (look for removals below ...)

     let aentry1=modList2[iz];
     let aAsset =aentry1['name'];

     if  (!wasAssets.hasOwnProperty(aAsset)) continue ;         // a new asset ... dealt  with above
     retainList.push(aAsset);

     iww=wasAssets[aAsset];
     let aentryZ=entry0[iww];

     let atype=aentry1['assetType'];

     if (atype==0)  {              // stocks sold or purchased ?

       let d_shares=aentry1['nShares']- aentryZ['nShares'];

       let aprice=getAssetValue(modDate,aAsset,'price',1) ;

       if (d_shares<0) {                // sale!
          let abasis0=aentryZ['basis'];
          let acost0=aentryZ['cost'];

          let cfrac=aentry1['nShares']/aentryZ['nShares'] ;        // fraction of existing shares retained
          modList2[iz]['cost']=acost0*cfrac ;         // fraction of pre sales cost
          modList2[iz]['basis']=abasis0*cfrac ;         // fraction of pre sales cost
          avalue= Math.abs(d_shares*aentry1['price']);
          saleList[aAsset]=avalue ;
          saleListCapGains[aAsset]=avalue-(abasis0*(1-cfrac)) ;

       }  else if (d_shares>0) {                      // purchased
          let acost1=d_shares * aprice ;
          purchaseList[aAsset]=acost1 ;                          // no need to track purchases of  "subject to cap gains when sold"
          modList2[iz]['cost']=aentryZ['cost']+acost1 ;         // add cost of added assets  to prior cost
       }

       if (d_shares!=0) {
          changeList.push(aAsset);
          changeListVals[aAsset]=aentry1['nShares'];
          modList2[iz]['modifiedDate']=modDate;
       }

     } else if (atype==1)  {              // bonds sold or purchased ?

        let d_shares=aentry1['nShares']- aentryZ['nShares'];
        if (d_shares<0) {                // sale!
           let acost0=aentryZ['cost'];
           let cfrac=aentry1['nShares']/aentryZ['nShares'] ;        // fraction of existing shares retained
           modList2[iz]['cost']=acost0*cfrac ;         // fraction of pre sales cost
           saleList[aAsset]=Math.abs(d_shares) ;

       } else if (d_shares>0) {                      // purchased
           let acost1=d_shares  ;
           purchaseList[aAsset]=Math.abs(d_shares) ;
           modList2[iz]['cost']=aentryZ['cost']+acost1 ;         // add cost of added assets  to prior cost
       }
       if (d_shares!=0) {
          changeList.push(aAsset);

          changeListVals[aAsset]=aentry1['nShares'];
          modList2[iz]['modifiedDate']=modDate;
       }

     } else if (atype==2)  {              // tax deferred bonds sold or purchased ?

        let d_shares=aentry1['nShares']- aentryZ['nShares'];
        if (d_shares<0) {                // sale!
           let acost0=aentryZ['cost'];
           let cfrac=aentry1['nShares']/aentryZ['nShares'] ;        // fraction of existing shares retained
           modList2[iz]['cost']=acost0*cfrac ;         // fraction of pre sales cost
           saleList[aAsset]=Math.abs(d_shares) ;
           saleListTaxDeferred[aAsset]=Math.abs(d_shares);     // modifications  (abs value for all sales)

       }   else if (d_shares>0 ) {                      // purchased
           let atax=calcAsset_taxAmount('*taxdeferred',d_shares,1)   ;
           let atax1= (atax>0) ? atax : 0 ;
           let acost1=d_shares  ;
           purchaseList[aAsset]=acost1 ;           //   "tax savings" from cost of purchase dealt with by purchaseListTaxDeferred
           purchaseListTaxDeferred[aAsset]=acost1;       //
           modList2[iz]['cost']=aentryZ['cost']+acost1 ;
       }
       if (d_shares!=0) {
          changeList.push(aAsset);
          changeListVals[aAsset]=aentry1['nShares'];
          modList2[iz]['modifiedDate']=modDate;
       }

     } else if (atype==3)  {              //  property might have loan changed   (but not sold -- since can't sell fraction of property)

      if (aentry1.hasOwnProperty('loanStart') && aentry1['loanStart']!==false) {           // if no loan, nothing to refinance
         if (aentry1['refiEnabled']==0)  {   // no refi, use prior loan specs (if refi, the values in entry1 are the refi values
            let domes=['loanOwed','loanStart','loanAmount','loanTerm','loanRate','loanTaxDeduct','cost','price','origPrice','origCost','basis'];
            for (let jj=0;jj<domes.length;jj++) {
                let vb=domes[jj];
                modList2[iz][vb]=aentryZ[vb];
            }
            modList2[iz]['loanPayYearly']= 12* montlyLoanAmount(aentryZ['loanAmount'],aentryZ['loanTerm'],aentryZ['loanRate']);

         }  else {                // calculate changes in cash (if refi amount is <> loanowed ). ALl other parameters alerady saved in entry1
             let refiExtra= aentry1['loanAmount'] -  aentry1['loanOwed'] ;        // borrowed more or less than amount owed   (neg values mean withdraw from Cash
             refiList[aAsset]=refiExtra;
             modList2[iz]['loanOwed']=modList2[iz]['loanAmount'];
             modList2[iz]['modifiedDate']=modDate;

             modList2[iz]['basis']=aentryZ['basis'];

             modList2[iz]['cost']=aentryZ['cost'];
             modList2[iz]['price']=aentryZ['price'];
             modList2[iz]['origCost']=aentryZ['origCost'];
             modList2[iz]['origPrice']=aentryZ['origPrice'];
          }
       }   
       let iwasIndx= wasAssets[aAsset]     ;
       modList2[iz]['basis']=entry0[iwasIndx]['basis'];
       modList2[iz]['origPrice']=entry0[iwasIndx]['origPrice'];
       modList2[iz]['origCost']=entry0[iwasIndx]['origCost'];



     } else if (atype==4)  {             // incomes can be stopped, but can not be changed
          modList2[iz]['cost']= modList2[iz]['origCost'];


     } else if (atype==5)  {          // annuities  can be stopped, but can not be changed
          modList2[iz]['cost']= modList2[iz]['origCost'];
          modList2[iz]['incomeStart']=aentryZ['incomeStart'];

     } else if (atype==7)  {                    // expenses can be stopped, but can not be changed


     } else  {        // should never happen    --  oneOff (6) doesn't appear in this list     (i.e.; oneOffs can only be added on an entry date)
        alert('error in  portfolioCalcValueMenu_difference : type='+atype+' for asset '+asset1);
        return false;
     }
   }         // retained assets



// ... removed (sold) assets  ...

   for  (let iz=0;iz<entry0.length;iz++) {      // look at assets in the modification (look for removals below ...)

       let aentryZ=entry0[iz];

       let aAsset=aentryZ['name'];
       if  (nowAssets.hasOwnProperty(aAsset)) continue ;         // a retain asset,  dealt  with above

       removeList[aAsset]=iz ;

      let  atype=aentryZ['assetType'];

      if (atype==0) {

       let aprice=getAssetValue(modDate,aAsset,'price',1) ;

         let nshares0=parseFloat(aentryZ['nShares']);
         let avalue=nshares0*aprice;
         let abasis=aentryZ['basis'];

         saleList[aAsset]=avalue;
         saleListCapGains[aAsset]=avalue- abasis  ;

      } else if (atype==1) {                            // no taxes, so simple
         let nshares0=parseFloat(aentryZ['nShares']);
         saleList[aAsset]=nshares0;

     } else if (atype==2) {                    // track all tax deferred sales
         let nshares0=parseFloat(aentryZ['nShares']);
         saleList[aAsset]=nshares0;
         saleListTaxDeferred[aAsset]=nshares0;       // removed (liquidated)

     } else if (atype==3) {
         let loanOwed=aentryZ['loanOwed'];

         let aprice=getAssetValue(modDate,aAsset,'price',1) ;

         let abasis=aentryZ['basis'];
         let aprofit=aprice-loanOwed;      // can be < 0

         propertySaleList[aAsset]=aprice ;                    // subject to capital gains tax....
         propertySaleListNet[aAsset]=aprofit                    // subject to capital gains tax....
         let taxFreeFrac=doAssetLookup(aAsset,'taxFreeFrac',1);
         saleList[aAsset]=aprofit;
         saleListCapGains[aAsset]=(1-taxFreeFrac)*(aprice-abasis) ;

     }  else if (atype==4  ) {      // if 4 (incomeSTream) removed
         let aincome=getAssetValue(modDate,aAsset,'income',1);
         incomeListChange[aAsset]= aincome ;

     }  else if (atype==7  ) {      // if 4 (incomeSTream) removed
         let aexpense=getAssetValue(modDate,aAsset,'expense',1);
         expenseListChange[aAsset]= aexpense ;

     }  else if ( atype==5 ) {      // if 5 (annuity) removed
         let istart=aentryZ['incomeStart'];
         let zaincome=calcAnnuityValue(aAsset,istart,modDate)   ;   // [baseValue,baseGrowth,calcValue,day1,day2,dointerp,growthRateAgg]
         let aincome=zaincome[2];
         incomeListChange[aAsset]=aincome ;

     }


   }             // end of removes

// totals ..

    let totPurchases=portfolioCalcValueMenu_difference_sum(purchaseList);   // costs    -- purchase of assets + acquistion costs
    let totSales=portfolioCalcValueMenu_difference_sum(saleList);           // earnings  -- sale (partial or liquidation) of assets

    let totTaxDeferredSale=portfolioCalcValueMenu_difference_sum(saleListTaxDeferred);       // sales of all tax deferred
    let totTaxDeferredPurchase=portfolioCalcValueMenu_difference_sum(purchaseListTaxDeferred);      // purchase  of all tax deferred
    let totCapGains=portfolioCalcValueMenu_difference_sum(saleListCapGains);       // cap gains from stocks and properties

    let netTaxDef=totTaxDeferredSale-totTaxDeferredPurchase ;                                // net sales
    let ttax= calcAsset_taxAmount('*taxdeferred',Math.abs(netTaxDef),1) ;
    taxDeferred_tax= (netTaxDef>0)? ttax : -ttax ;              // if purchase of tax deferred > sales, difference is current tax savings

    let capGains_tax= (totCapGains>0) ? calcAsset_taxAmount('*capgains',totCapGains,1) : 0 ;

    let totRefiExtra=portfolioCalcValueMenu_difference_sum(refiList);

    let totTax=taxDeferred_tax+capGains_tax ;

    let   totCashChange=totSales+ (-totPurchases) + (-totTax) + totRefiExtra  ;     // changes   due to sales & purchase of a modification  (includes cap gans tax, and tax-deferred tax impacts)

    let totPropertySale=portfolioCalcValueMenu_difference_sum(propertySaleList);
    let totPropertySaleNet=portfolioCalcValueMenu_difference_sum(propertySaleListNet);

    let totOneOffReceipts=portfolioCalcValueMenu_difference_sum(oneOffListNew);

// 9 march 2024 .. totOneOffReceipts_pending added for clarity (shoiuld get rid of  totOneOffReceipts)
   let cc1={'totCashChange':totCashChange,
             'totSales':totSales,'totPurchases':totPurchases,'totTax':totTax,'totRefiExtra':totRefiExtra,
             'totTaxDeferredSale':totTaxDeferredSale,'totTaxDeferredPurchase':totTaxDeferredPurchase,'taxDeferred_tax':taxDeferred_tax,
             'totCapGains':totCapGains,'capGains_tax':capGains_tax,
            'totPropertySale':totPropertySale,'totPropertySaleNet':totPropertySaleNet,
            'totOneOffReceipts':totOneOffReceipts,
            'totOneOffReceipts_pending':totOneOffReceipts,
            'removeList':removeList,'newList':newList,'newListVals':newListVals,
            'retainList':retainList,'refiList':refiList,
            'changeList':changeList,'changeListVals':changeListVals,
            'oneOffListNew':oneOffListNew,
            'saleList':saleList,'purchaseList':purchaseList,
            'incomeListChange':incomeListChange,'expenseListChange':expenseListChange,
           'propertySaleList':propertySaleList, 'propertySaleListNet':propertySaleListNet,
           'saleListTaxDeferred':saleListTaxDeferred, 'purchaseListTaxDeferred':purchaseListTaxDeferred, 'saleListCapGains':saleListCapGains
            };


   let entryNew={};
   entryNew['assetList']=modList2 ;
   entryNew['summary']=cc1;

   return entryNew;

}


// ============

// sum of properties in an object
function portfolioCalcValueMenu_difference_sum(alist) {
 let atotal=0;
 for (let aa in alist) {
     let aval=alist[aa];
     atotal+=aval;
 }
 return atotal;
}

