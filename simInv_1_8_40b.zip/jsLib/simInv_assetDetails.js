// functions for calculating the attributes of an asset for a set of dates  (using assetHistory)
//
// makeAssetDetails_histCum()  :  creates assetDetailsCum global
// calcAssetValuesCum_all() :   creates assetValuesCum_byDate -- uses assetDetailsCum
// calcAnnuityValue()  :     calculate annuity value given start date
// updateAssetHistory_inflation() : creates assetHistory -- which has "inflation imputed" entries
// makeAssetValues_useDates() :     create date info -- a record for all dates that have portfolio or  asset  info specified
//
// =================================

//=================
// calculate simInvDsets['assetDetailsCum']: global cumulative values; 
// using global  assetDetails -- the history entries
// main indcies are assetNames -- with a history of cumulative values
// calls  makeAssetDetails_histCum_do using information cached in  assetDetails

function makeAssetDetails_histCum(ifoo) {

   let dovars=[];
     dovars[0]={'assetPrice':'price','assetDividend':'dividend'};
     dovars[1]={'assetInterest':'interest'};
     dovars[2]={'assetInterest':'interest'};
     dovars[3]={'assetSalePrice':'price','assetNetRent':'rent'} ;
     dovars[4]={'assetIncome':'income'};
     dovars[5]={'assetIncome':'income','assetIncomeGrowth':'growthFrac'};
     dovars[6]={'assetOneOff':'receipt'};
     dovars[7]={'assetExpense':'expense'};

   let assetDetailsCum0={};        // a local
   simInvDsets['assetDetailsCum']={};        // clear global

   let allExist={} ;
   let calendarAdds={} ;

   let oof3=setEntryDate(simInvParams['lastYearUse'],1,1);

   let dateFinal=oof3['dayCount'];           // final date
   let dateFinalSay=oof3['sayDate'];

   for (let anAsset in assetHistory) {
     if (assetHistory[anAsset]['entries'].length==0) continue ;      // no entries yet
     let useDates=[];
     let atype=doAssetLookup(anAsset,'assetType');
     assetDetailsCum0[anAsset]={'type':atype,'existing':{},'list':{},'dates':[]}   ;

     for (let ii=0;ii<assetHistory[anAsset]['entries'].length;ii++) {         // entry dates for this asset
          let jdate=assetHistory[anAsset]['entries'][ii]['date'];
          assetDetailsCum0[anAsset]['existing'][jdate]=ii;
          let oofk=setEntryDate(jdate);
          allExist[jdate]=oofk.sayDate ;
          useDates.push(jdate);
      }
     useDates.sort(mySortNumeric);         // sort to find first date in the history of this asset

// now add jan  1 dates, starting from earliest usedates
     let firstDate=useDates[0];
     let oof1=setEntryDate(firstDate);
     let  ayear=oof1['year'];

     for (let jyear=ayear+1;jyear<simInvParams['lastYearUse'];jyear++)  {   // every jan 1 from year after first entry to finalEntry
         let oofj=setEntryDate(jyear,1,1);
         let oofjDate=oofj['dayCount'];
         calendarAdds[oofjDate]=oofj['sayDate'];;
         if (assetDetailsCum0[anAsset]['existing'].hasOwnProperty(oofjDate)) continue  ; // do not replicate existing
         useDates.push(oofjDate);
     }

// every 6 30?
    if (simInvParams['addEntryDates_yearly']>1) {
       for (let jyear=ayear+1;jyear<simInvParams['lastYearUse'];jyear++)  {   // every jan 1 from year after first entry to finalEntry
         let oofj=setEntryDate(jyear,6,30);
         let oofjDate=oofj['dayCount'];
         calendarAdds[oofjDate]=oofj['sayDate'];
         if (assetDetailsCum0[anAsset]['existing'].hasOwnProperty(oofjDate)) continue  ; // do not replicate existing
         useDates.push(oofjDate);
       }
     }

// every 3/30 and 9 30
    if (simInvParams['addEntryDates_yearly']>3) {
       for (let jyear=ayear+1;jyear<simInvParams['lastYearUse'];jyear++)  {   // every jan 1 from year after first entry to finalEntry
         let oofj=setEntryDate(jyear,3,30);
         let oofjDate=oofj['dayCount'];
         calendarAdds[oofjDate]=oofj['sayDate'];
         if (assetDetailsCum0[anAsset]['existing'].hasOwnProperty(oofjDate)) continue  ; // do not replicate existing
         useDates.push(oofjDate);
       }
     }
    if (simInvParams['addEntryDates_yearly']>3) {
       for (let jyear=ayear+1;jyear<simInvParams['lastYearUse'];jyear++)  {   // every jan 1 from year after first entry to finalEntry
         let oofj=setEntryDate(jyear,9,30);
         let oofjDate=oofj['dayCount'];
         calendarAdds[oofjDate]=oofj['sayDate'];
         if (assetDetailsCum0[anAsset]['existing'].hasOwnProperty(oofjDate)) continue  ; // do not replicate existing
         useDates.push(oofjDate);
       }
     }

     useDates.sort(mySortNumeric);

      for (let ii=0;ii<useDates.length;ii++) {           // create empty entries for all candidate dates
          let jdate=useDates[ii];
          assetDetailsCum0[anAsset]['list'][jdate]={};
          assetDetailsCum0[anAsset]['dates'].push(jdate);
      }

   }          // anasset

// step through each  asset's history  -- finding values for each entry ... and store in pairs (for cumulative stats)

   for (let anAsset in assetDetailsCum0) {
      let nDates=assetDetailsCum0[anAsset]['dates'].length;

      let date1=assetDetailsCum0[anAsset]['dates'][0];
      let date2=date1  ;  // if only one history entry
      let atype=assetDetailsCum0[anAsset]['type'];
      let att1={},att2={} ;

      for (let dvar in  dovars[atype]) {        // will always be the first existing asset entry
            att1[dvar]= parseFloat(assetHistory[anAsset]['entries'][0][dvar])   ;
      }

      for  (let ii=1;ii<nDates;ii++) {     // if one history entry... this is skipped
         date2=assetDetailsCum0[anAsset]['dates'][ii];
         let histEntry=(assetDetailsCum0[anAsset]['existing'].hasOwnProperty(date2)) ?   assetDetailsCum0[anAsset]['existing'][date2] : false;  // matches actual entry for this asset

         let daysGap=date2-date1;
         att2={} ;

         for (let dvar in  dovars[atype]) {
               let aget=dovars[atype][dvar];
               let tt=getAssetValue(date2,anAsset,aget,1);  // aget is attribute (price, etc) for this asset/date
               att2[dvar]=tt;
          }
          assetDetailsCum0[anAsset]['list'][date1]={'startDate':date1,'endDate':date2,'gap':daysGap,'att1':att1,'att2':att2};

          att1=JSON.parse(JSON.stringify(att2)) ;  // clone
          date1=date2;
      }        // anAsset

      if (date2<=dateFinal) {               // add far future
            daysGap=dateFinal-date2;        // assume far future entry is same as final actual entry
            assetDetailsCum0[anAsset]['list'][date2]={'startDate':date2,'endDate':dateFinal,'gap':daysGap,'att1':att1,'att2':att1};
      }


      date1=date2;
  }   // anAsset

// cleanup above...  to use to  compute cumGrowth and cumEarn for each asset/date (after first asset entry)

   let assetDetailsCum1={} ;

   for (let anAsset in assetDetailsCum0) {
     assetDetailsCum1[anAsset]={};
     let atype= assetDetailsCum0[anAsset]['type'];
     assetDetailsCum1[anAsset]['type'] =atype;
     assetDetailsCum1[anAsset]['nEntries'] =false ;
     assetDetailsCum1[anAsset]['firstEntry'] =false ;
     assetDetailsCum1[anAsset]['lastEntry'] =false ;
     let tt1= calcAsset_taxRate(anAsset,0);  // asset specific (but not date dependent)

     assetDetailsCum1[anAsset]['earningsTaxRate'] = tt1 ;

     let aprior=makeAssetDetails_histCum_do(anAsset,false);   // initialize starting "cumulative" values for attributes (depends on type)

     let cumVars={};
     for (let acc in aprior) {
         if (acc=='existing' || acc=='daysGap' || acc=='daysGapTotal' || acc=='earningsTaxRate'  ) continue ;     //29 jan 2024 .. earningsThisGap will be incorrect (for interpolated values)
         cumVars[acc]=1;
     }
     assetDetailsCum1[anAsset]['cumVars']=cumVars;

     let currentVars={};
     for (let acc0 in dovars[atype]) {
         let acc=dovars[atype][acc0];
         currentVars[acc]=1;
     }
     assetDetailsCum1[anAsset]['currentVars']=currentVars;

     assetDetailsCum1[anAsset]['list']={};

     let nDates=assetDetailsCum0[anAsset]['dates'].length;

     let kdate;
     for (let jk=0;jk<nDates;jk++ ) {
         kdate=assetDetailsCum0[anAsset]['dates'][jk];
         assetDetailsCum1[anAsset]['list'][kdate]={};
         for (let anatt in  assetDetailsCum0[anAsset]['list'][kdate]['att1'] ) {
            let anatt2=dovars[atype][anatt];                                    // deal with differing names (for same attribute)
            assetDetailsCum1[anAsset]['list'][kdate][anatt2]=parseFloat(assetDetailsCum0[anAsset]['list'][kdate]['att1'][anatt]);
         }

        if (jk==0) {      // first entry: more defaults
           assetDetailsCum1[anAsset]['list'][kdate]['existing']=1;
           assetDetailsCum1[anAsset]['list'][kdate]['daysGap']=0 ;
//           assetDetailsCum1[anAsset]['list'][kdate]['daysGapTotal']=0 ;
           let oink=setEntryDate(kdate);
//            assetDetailsCum1[anAsset]['list'][kdate]['datesSay']=oink.sayDate ;
        }

        for (let zatt in cumVars) {                     // the starting values (0.0 and 1.0)
            if (jk==0) {        // use starting values of cum stuff
               assetDetailsCum1[anAsset]['list'][kdate][zatt]=parseFloat(aprior[zatt]);
            } else {
              assetDetailsCum1[anAsset]['list'][kdate][zatt]='woof1';      // filler (will be overwritten below)
            }
         }    // zatt

         assetDetailsCum1[anAsset]['list'][kdate]['calendarEntry']=(calendarAdds.hasOwnProperty(kdate)) ? 1   : 0 ;
     }     // ndates

     assetDetailsCum1[anAsset]['list'][dateFinal]={};        //     add "far future" date
     for (let anatt in  assetDetailsCum0[anAsset]['list'][kdate]['att1'] ) {
         let anatt2=dovars[atype][anatt];
         assetDetailsCum1[anAsset]['list'][dateFinal][anatt2]=parseFloat(assetDetailsCum0[anAsset]['list'][kdate]['att1'][anatt]);
     }
       assetDetailsCum1[anAsset]['list'][dateFinal]['calendarEntry']=(calendarAdds.hasOwnProperty(dateFinal)) ? 1  : 0 ;

     for (let zatt in aprior) {
          assetDetailsCum1[anAsset]['list'][dateFinal][zatt]='woof4';      // filler (will be overwritten below)
    }

     assetDetailsCum1[anAsset]['dates'] =JSON.parse(JSON.stringify(assetDetailsCum0[anAsset]['dates'] ));      // use the assets in the "prior" entry (they will be grown)
     assetDetailsCum1[anAsset]['dates'].push(dateFinal) ;

     assetDetailsCum1[anAsset]['existing'] =JSON.parse(JSON.stringify(assetDetailsCum0[anAsset]['existing'] ));      // use the assets in the "prior" entry (they will be grown)

   }    // anAsset in assetDetailsCum0


// now  compute cumGrowth and cumEarn for each asset/date (after first asset entry)

   for (let anAsset in assetDetailsCum1) {
     let atype= assetDetailsCum1[anAsset]['type'];
     let nDates=assetDetailsCum1[anAsset]['dates'].length;
     let firstDate=assetDetailsCum1[anAsset]['dates'][0];
      let cumVars=assetDetailsCum1[anAsset]['cumVars'] ;

     assetDetailsCum1[anAsset]['firstEntry']=firstDate ;
     assetDetailsCum1[anAsset]['lastEntry']=assetDetailsCum1[anAsset]['dates'][nDates-1];
     assetDetailsCum1[anAsset]['nEntries'] =nDates ;

     let kdatePrior =firstDate;
     let attPrior=assetDetailsCum1[anAsset]['list'][kdatePrior];

     for (let jk=1;jk<nDates;jk++ ) {             // growth from prior entry to this one ... [0] is preset to starting values
        let kdateNow=assetDetailsCum1[anAsset]['dates'][jk];
        let attNow=JSON.parse(JSON.stringify(assetDetailsCum1[anAsset]['list'][kdateNow]));
        let daysGap=kdateNow-kdatePrior ;

        let attCums= makeAssetDetails_histCum_do(anAsset,daysGap,attPrior,attNow,kdateNow,kdatePrior ) ;     // THIS CALCULATES CUM values

        for (let aax in attCums)  assetDetailsCum1[anAsset]['list'][kdateNow][aax]=attCums[aax];

        let isExist=(assetDetailsCum1[anAsset]['existing'].hasOwnProperty(kdateNow)) ? 1 :  0 ;  ;
        assetDetailsCum1[anAsset]['list'][kdateNow]['existing']=isExist ;

//        assetDetailsCum1[anAsset]['list'][kdateNow]['daysGapTotal']=kdateNow-firstDate ;

        attPrior= assetDetailsCum1[anAsset]['list'][kdateNow] ; // used in next iteration
//        if (anAsset=='ml') wsurvey.dumpObj(attPrior,1,'attprior for '+kdateNow);

        kdatePrior=kdateNow ;    // used in next iteration
     }            // dates


    }       //= assets

    let alldates={};
    for (let aa in assetDetailsCum1) {
      ndo=assetDetailsCum1[aa]['dates'].length;
      for (let ii=0;ii<ndo;ii++) {
         kdate=assetDetailsCum1[aa]['dates'][ii];
         if (!alldates.hasOwnProperty(kdate)) alldates[kdate]=0;
         alldates[kdate]++ ;          // could just set to 1 but maybe use this count later (28 jan 2024)
      }
    }

    let alldates2=[];
    for (let jdate in alldates) alldates2.push(jdate);
    alldates2.sort(mySortNumeric);

    simInvDsets['assetDetailsCum']['assets']=assetDetailsCum1 ;
    simInvDsets['assetDetailsCum']['dates']=alldates2 ;         // dates with at least one asset with an entry ([0] is earliest date with an asse with an entry
    simInvDsets['assetDetailsCum']['calendarAdds']=calendarAdds ;
    simInvDsets['assetDetailsCum']['allExist']=allExist ;

   return 1 ;   //    assetDetailsCum   is global

}

// =========== end of assetdetails for history entries.

//...
// for an asset: calculate cumulative growth, income, etc attributes : given start attributes (income, interest,etc), end attributes, and daysGap

function makeAssetDetails_histCum_do(aName,daysGap,att1,att2 ,kdate1,kdate0) {


    let assetType=getAssetType(aName);
   let earningsTaxRate =calcAsset_taxRate(aName,0);  // asset specific (but not date dependent)

   if (daysGap===false) {      // initial values (for first entry of an asset)
     let doVarsCum=[];
       doVarsCum[0]={'daysGap':0,'growthCum':1.0,'growthCumAT':1.0,'earningsCum':0,'earningsCumAT':0,'earningsTaxCum':0,'earningsThisGap':0,
                       'q_1':1,'q_1_at':1};
       doVarsCum[1]={'daysGap':0,'growthCum':1.0,'growthCumAT':1.0,'earningsCum':0,'earningsCumAT':0,'earningsTaxCum':0,'earningsThisGap':0};
       doVarsCum[2]={'daysGap':0,'growthCum':1.0,'growthCumAT':1.0,'earningsCum':0,'earningsCumAT':0,'earningsTaxCum':0,'earningsThisGap':0 };
       doVarsCum[3]={'daysGap':0,'earningsCum':0,'earningsCumAT':0,'earningsTaxCum':0,'earningsThisGap':0,'netCumRentAT':0};
       doVarsCum[4]={'daysGap':0,'earningsCum':0,'earningsCumAT':0,'earningsTaxCum':0,'earningsThisGap':0,'netCumIncomeAT':0};
       doVarsCum[5]={'daysGap':0,'earningsCum':0,'earningsCumAT':0,'earningsTaxCum':0,'earningsThisGap':0,'netCumIncomeAT':0};
       doVarsCum[6]={'daysGap':0};
       doVarsCum[7]={'daysGap':0,'expensesCum':0,'expensesCumAT':0,'netCumExpenseAT':0,'expensesThisGap':0} ;

      return doVarsCum[assetType];
   }

  let taxf=1- earningsTaxRate ;

  let stuff={'daysGap':daysGap };

  let priorStuff=att1 ;                     // 23 nov 2023 edit =-- for first call (per asset), the prior was set to the defaults (growth=1, income=0, etc)!

   if (assetType==0) {                              // stock   -- note that dividends can NOT be negative.

        let D_1=parseFloat(att1['dividend']) ;
        let D_2=parseFloat(att2['dividend']) ;
        let P_1=parseFloat(att1['price']) ;
        let P_2=parseFloat(att2['price']) ;

        let agrowth=assetGrowth_dividend2(D_1,D_2,P_1,P_2,daysGap) ;         // Growth between dates  ....
        stuff['growthCum']=att1['growthCum']*agrowth;                  // cumulativive is growth * prior cumulative

        let D_1b=D_1*taxf ;                    // now for after tax...
        let D_2b=D_2*taxf ;

        let agrowth2=assetGrowth_dividend2(D_1b,D_2b,P_1,P_2,daysGap) ;   // after tax growth rate  (note that prices used are not affected by tax)

        stuff['growthCumAT']=priorStuff['growthCumAT']*agrowth2;


        let Q_1=parseFloat(att1['growthCum']);
        stuff['q_1']=Q_1 ;

        let Q_1_AT=parseFloat(att1['growthCumAT']);
        stuff['q_1_at']=Q_1_AT ;

//        let E_1=parseFloat(att1['earningsCum']);
//        let E_1_AT=parseFloat(att1['earningsCumAT']);

      let t1=assetGrowth_stock(Q_1,D_1,D_2,P_1,P_2,daysGap) ;   // nshares,totDividends
//      let newSharesPT=t1[0];
      let s1=t1[1] ;

      stuff['earningsCum']=priorStuff['earningsCum']+s1;

        stuff['earningsThisGap']=s1;

      let t2=assetGrowth_stock(Q_1_AT,D_1b,D_2b,P_1,P_2,daysGap) ;   // nshares,totDividends
//       let newSharesAT=t1[0];
      let s2=t2[1] ;
        stuff['earningsCumATStart'] =priorStuff['earningsCumAT'];
       stuff['earningsCumAT']=priorStuff['earningsCumAT']+s2;

        stuff['earningsThisGapAT']=s2;
        stuff['datePrior']=kdate0;
        stuff['dateNow']=kdate1;

        stuff['earningsTaxCum']=stuff['earningsCum'] - stuff['earningsCumAT'] ;

//   if (aName=='ml') showDebug(stuff,'stuff for cum '+daysGap ,1);

        return stuff;
   }

    if (assetType==1  ) {                 // regular bond

        let I_1=parseFloat(att1['interest'])/100.0 ;      // as a fraction: eg 0.03 for 3%
        let I_2=parseFloat(att2['interest'])/100.0 ; ;

        let agrowth=assetGrowth_interest(I_1,I_2,daysGap) ;

        stuff['growthCum']=priorStuff['growthCum']*agrowth;
        stuff['earningsCum']=stuff['growthCum']-1;
        stuff['earningsThisGap']=stuff['earningsCum']-priorStuff['earningsCum'];

        if (agrowth>=1.0 ) {        // growth, so taxable...
          let I_1b=I_1*taxf ;
          let I_2b=I_2*taxf ;
          let agrowth2=assetGrowth_interest(I_1b,I_2b,daysGap) ;
          stuff['growthCumAT']=priorStuff['growthCumAT']*agrowth2;
          stuff['earningsCumAT']=stuff['growthCumAT']-1;

          stuff['earningsTaxCum']= stuff['earningsCum']-  stuff['earningsCumAT']  ;

        } else {           // shrinkage  -- so no taxes
           stuff['growthCumAT']=stuff['growthCum'];
           stuff['earningsCumAT']=stuff['earningsCum'] ;
           stuff['earningsTaxCum']=priorStuff['earningsTaxCum'] ;     // no tax paid  this period
        }

        return stuff ;

     }

     if (assetType==2) {                 //  taxdeferred bond    -- no tax on earnings

        let I_1=parseFloat(att1['interest'])/100.0 ;
        let I_2=parseFloat(att2['interest'])/100.0 ; ;

        let agrowth=assetGrowth_interest(I_1,I_2,daysGap) ;

        stuff['growthCum']=priorStuff['growthCum']*agrowth;
        stuff['growthCumAT']=stuff['growthCum'];

        stuff['earningsCum']=stuff['growthCum']-1;
        stuff['earningsCumAT']=stuff['earningsCum'] ;

          stuff['earningsThisGap']=stuff['earningsCum']-priorStuff['earningsCum'];

        stuff['earningsTaxCum']=0 ;     // no tax EVER paid

        return stuff;
     }

   if (assetType==3) {                 // property (no growth rate calculations)

        let N_1=parseFloat(att1['rent'])/365.0 ;
        let N_2=parseFloat(att2['rent'])/365.0 ;

        let ss2= assetGrowth_sum(daysGap,N_1,N_2) ;
        stuff['earningsCum']=priorStuff['earningsCum']+ss2;
        stuff['earningsThisGap']=ss2;

        if (ss2>=0)  {          // gains, so taxes
           let N_1b=N_1*taxf ;
           let N_2b=N_2*taxf;
           let ss2AT=assetGrowth_sum(daysGap,N_1b,N_2b) ;
           stuff['earningsCumAT']=priorStuff['earningsCumAT']+ss2AT;
           stuff['earningsTaxCum']= stuff['earningsCum']-  stuff['earningsCumAT']  ;
       } else {                  // lossses, so  no taxes
           stuff['earningsCumAT']=stuff['earningsCum'] ;
           stuff['earningsTaxCum']=priorStuff['earningsTaxCum'];

       }
       stuff['netCumRentAT']= stuff['earningsCumAT'] ;

        return stuff;

     }

      if (assetType==4) {                 // income (-income is deprecated )

        let N_1=parseFloat(att1['income'])/365.0 ;
        let N_2=parseFloat(att2['income'])/365.0 ;

        let ss2= assetGrowth_sum(daysGap,N_1,N_2) ;
        stuff['earningsCum']=priorStuff['earningsCum']+ss2;
        stuff['earningsThisGap']=ss2;

        if (ss2>=0)  {          // gains, so taxes
           let N_1b=N_1*taxf;
           let N_2b=N_2*taxf ;
           let ss2AT=assetGrowth_sum(daysGap,N_1b,N_2b) ;
           stuff['earningsCumAT']= priorStuff['earningsCumAT']+ss2AT;
           stuff['earningsTaxCum']=stuff['earningsCum']-  stuff['earningsCumAT']  ;


       } else {                  // lossses, so  no taxes
           stuff['earningsCumAT']=stuff['earningsCum'] ;
           stuff['earningsTaxCum']=priorStuff['earningsTaxCum'];
       }
       stuff['netCumIncomeAT']= stuff['earningsCumAT'] ;

        return stuff;

    }
    
     if (assetType==7) {                 // expense

        let N_1=parseFloat(att1['expense'])/365.0 ;
        let N_2=parseFloat(att2['expense'])/365.0 ;

        let ss2= assetGrowth_sum(daysGap,N_1,N_2) ;

        stuff['expensesCum']=priorStuff['expensesCum']+ss2;
        stuff['expensesThisGap']=ss2;

        let N_1b=N_1*taxf;                // 1-taxf will offset other income... so realized expense is taxf. Ie.; taxrate=20%, taxFrac=90%, then 0.84 of expense is realized (after tax deeductiosn)
        let N_2b=N_2*taxf ;
        let ss2AT=assetGrowth_sum(daysGap,N_1b,N_2b) ;
        stuff['expensesCumAT']= priorStuff['expensesCumAT']+ss2AT;

        stuff['netCumExpenseAT']= stuff['expensesCumAT'] ;   // only differs if property!

        return stuff;

    }

    if (assetType==5) {                 // annuity (-income is possible)

        let N_1=parseFloat(att1['income'])/365.0 ;
        let N_2=parseFloat(att2['income'])/365.0 ;

        let ss2= assetGrowth_sum(daysGap,N_1,N_2) ;
        stuff['earningsCum']=priorStuff['earningsCum']+ss2;
        stuff['earningsThisGap']=ss2;

        if (ss2>=0)  {          // gains, so taxes
           let N_1b=N_1*taxf;
           let N_2b=N_2*taxf ;
           let ss2AT=assetGrowth_sum(daysGap,N_1b,N_2b) ;
           stuff['earningsCumAT']= priorStuff['earningsCumAT']+ss2AT;
           stuff['earningsTaxCum']=stuff['earningsCum']-  stuff['earningsCumAT']  ;


       } else {                  // lossses, so  no taxes
           stuff['earningsCumAT']=stuff['earningsCum'] ;
           stuff['earningsTaxCum']=priorStuff['earningsTaxCum'];
       }
       stuff['netCumIncomeAT']= stuff['earningsCumAT'] ;

        return stuff;

  }                  //annuity

   if (assetType==6) {                 // oneOff (- is possible) has no accumulation (occurs day after inclusion in a portfolio entry)
        return stuff ;
    }


  alert('Error in makeAssetDetails_histCum_do: no such assetType ('+assetType+') for '+aName);
  return false;
}

//==========
// 5 March 2024: now use  simInv_interest() -- rather than the integral based apprxomation

function assetGrowth_interest(I_0a,I_1a,tspan) {
 let tt0=simInv_interest(I_0a*100.0,I_1a*100.0,tspan);
 return tt0 ;


}



// ===================================================
// functions to calculate asset values on a gven date, using an asset's history
// ===================================================

// =====================================
//  creates an array of dates, for use by calcAssetValues_all
//  This regenerates viewDates -- using firstYear, lastYear, calendar dates at least yearly,custom, and mod+entry dates
//  AND adds "asset history entry" dates -
// if idetails=1, return object whose properties are the dates, with extra info

function makeAssetValues_useDates(iDetails) {

  let allList=[];

// just to be careful, add first and last day of range
 let firstYearUse =simInvParams['firstYearUse'];
  let oofX=setEntryDate(firstYearUse,1,1);
  let firstDayUse=parseInt(oofX['dayCount']);
  allList.push(firstDayUse) ;

  let lastYearUse=simInvParams['lastYearUse']
  let oofY=setEntryDate(lastYearUse,12,31);
  let lastDayUse=parseInt(oofY['dayCount']);
  allList.push(lastDayUse) ;

  let viewDates= simInvDsets['viewDates'] ;  // custom or calendarDate may be more than the minimum?

  let custDates=viewDates['customDates'];
  let firstDayA=viewDates['firstDateAllow'],lastDayA=viewDates['lastDateAllow'];
  let jcalDate=Math.max(viewDates['addCalendarDates'],1);
  let vNew={'customDates':custDates,'addEntryDates':2,'addCalendarDates':jcalDate,'firstDateAllow':firstDayA,'lastDateAllow':lastDayA} ; // don't get viewDates outside of user specified range
  let arf1=buildDateList(vNew,false,false);
  for (let ia=0;ia<arf1.length;ia++) {
      allList.push(arf1[ia]);
  }
 
// dates of assset history entries
  let assetListSay={};
  for (let ana in assetHistory  ) {
      for (let idd=0;idd<assetHistory[ana]['entries'].length;idd++) {
         let jdate=parseInt(assetHistory[ana]['entries'][idd]['date']) ;
         allList.push(jdate);
         assetListSay[jdate]=1 ;// could get fancy and include other info?
      }
   }
// sort them, and remove duplicates
  allList.sort(mySortNumeric);
  let allListB=[];
  let wasDate=false;
  for (let mm=0;mm<allList.length;mm++) {
      let zdate=allList[mm] ;
      if (zdate<firstDayUse || zdate>lastDayUse)   continue;     // asset history dates  outside of "viewDates" range are allowed
      if (allListB[mm]!==wasDate) {
         wasDate=zdate ;
         allListB.push(wasDate );
      }
  }

  if (iDetails!=1) return allListB ;

// create an informative list
let pallList2={};
 for (jj=0;jj<allListB.length;jj++) {
    let aobj={'say':'','calendar':-1,'entry':-1,'custom':-1,'asset':-1};
      let zdate=allListB[jj] ;
      if (viewDates['allSay'].hasOwnProperty(zdate)) {
          for (let ug in viewDates['allSay'][zdate]) aobj[ug]=viewDates['allSay'][zdate][ug];
      }
      if (assetListSay.hasOwnProperty(zdate)) {
          aobj['asset']=1;
          if (aobj['say']=='') aobj['say']=setEntryDate(zdate).sayDate ;
      }
      pallList2[zdate]=aobj;
  }

  return pallList2 ;

}


///=============================
// display a few asset details   -- html
// No portfolio info used!
// output not used anywhere else

// =====================================
/// calculate asset values for all assets on all dates in useDates
// useDates: array with dates  (dates to calculate asset values for
//       typically created by     makeAssetValues_useDtes()
// sets value of  simInvDsets['assetValues_byDate'] global

function calcAssetValues_all(useDates ) {

  let dateList=[],dateSayList=[];
  for (let adate in useDates) {
     let jdate=parseInt(adate);
     dateList.push(parseInt(adate));
     let dateObj=setEntryDate(adate) ;
     dateSayList.push(dateObj['sayDate']);
  }
  let goos={};
  let assetList={};
  let ifoo=0;

  for (let mm=0;mm<dateList.length;mm++) {
    let idate=dateList[mm];

    let dateSay=dateSayList[mm] ;
    goos[idate]={'sayDate':dateSay,'assets':{}};

    for (let anAsset in assetLookup) {
       goos[idate]['assets'][anAsset]={};
       let earliestAsset=assetLookup[anAsset]['earliestEntryDate'];

       if (earliestAsset===false || idate<earliestAsset) {   // false if no asset history entries have been entered
          goos[idate]['assets'][anAsset]['info']='n.a.';
          continue;
       }
       let latestAsset=assetLookup[anAsset]['latestEntryDate'];

       if (!assetList.hasOwnProperty(anAsset)) assetList[anAsset]=0;
       assetList[anAsset]++ ;

       goos[idate]['assets'][anAsset]['info']=  getAssetValue(idate,anAsset,false,1);    // THIS DOES A LOT OF WORK   -- either by calculating, or cache lookup
    }   // assetsLookup

  }   // datelist
  simInvDsets['assetValues_byDate']={'vals':goos,'dateList':dateList,'assetList':assetList,'created':1} ;

  return 1;     // assetValues_byDate global  contains the results

}


//=================
// uses  assetDetailsCum global to compute assetValuesCum_byDate -- a global with current and cum stats for a list of dates (possibly interpolated)

function calcAssetValuesCum_all(useDates) {          //    assetValuesCum_byDate  global
  simInvDsets['assetValuesCum_byDate']={};

// for all dates that have an entry for any asset.
// Thus: assets with just a few entries will have more  interpoloaced cumualtive values

  for (let jj=0;jj<simInvDsets['assetDetailsCum']['dates'].length; jj++) {   // must already be ascending sorted
      let jdate=simInvDsets['assetDetailsCum']['dates'][jj];      // values computed for this date for all assets
      simInvDsets['assetValuesCum_byDate'][jdate]={} ;

      for (anAsset in  simInvDsets['assetDetailsCum']['assets']) {
        let firstDate=simInvDsets['assetDetailsCum']['assets'][anAsset]['firstEntry'];
        let lastDate=simInvDsets['assetDetailsCum']['assets'][anAsset]['lastEntry'];

        if (jdate<firstDate) {                           // not specified before this date - flag with a false
           simInvDsets['assetValuesCum_byDate'][jdate][anAsset]=false ;
           continue ;
        }

        let cumVars=simInvDsets['assetDetailsCum']['assets'][anAsset]['cumVars'] ;

        let currentVars=simInvDsets['assetDetailsCum']['assets'][anAsset]['currentVars'];

        simInvDsets['assetValuesCum_byDate'][jdate][anAsset]={};
        simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['type']=simInvDsets['assetDetailsCum']['assets'][anAsset]['type'] ;
        simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['existing']=0;       // assume not an existing asset entry


        if (simInvDsets['assetDetailsCum']['assets'][anAsset]['list'].hasOwnProperty(jdate))  {     // already computed (don't need to interploate)

            simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['existing']=simInvDsets['assetDetailsCum']['assets'][anAsset]['list'][jdate]['existing'] ;
            simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['usingDate']=jdate;
            simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['priorDate']=false ;
            simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['nextDate']=false ;

            for (let acurrent in currentVars) {
                  simInvDsets['assetValuesCum_byDate'][jdate][anAsset][acurrent] = simInvDsets['assetDetailsCum']['assets'][anAsset]['list'][jdate][acurrent];
            }
            for (let acum in cumVars) {
                  let tt1=simInvDsets['assetDetailsCum']['assets'][anAsset]['list'][jdate][acum];
                  simInvDsets['assetValuesCum_byDate'][jdate][anAsset][acum] = tt1;
            }
            continue;
       }       // exact match

       if (jdate>lastDate)  {     // if after last date, use last date values (no interpolation)
            simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['existing']=0;       // assume not an existing asset entry

            simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['priorDate']=lastDate ;
            simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['nextDate']=false ;
            for (let acurrent in currentVars) {
                  simInvDsets['assetValuesCum_byDate'][jdate][anAsset][acurrent] = simInvDsets['assetDetailsCum']['assets'][anAsset]['list'][lastDate][acurrent];
            }
            for (let acum in cumVars) {
                  simInvDsets['assetValuesCum_byDate'][jdate][anAsset][acum] = simInvDsets['assetDetailsCum']['assets'][anAsset]['list'][lastDate][acum];
            }
            continue;
       }   // jdate>lastDate


 // else, an intepolation is necessary

       simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['existing']=0;       // assume not an existing asset entry

       let myDates=simInvDsets['assetDetailsCum']['assets'][anAsset]['dates'] ;         // dates with some info for this asset
       let useIth=find_closestDate(myDates,jdate);   //       index int myDates
       if (useIth===false || useIth<0) {           // should never happen
          alert('Error in calcAssetValuesCum_all using date='+jdate+' : ' +useIth)
          return false;
       }
       let date0=myDates[useIth];                // the date in (mydates) that is just before jdate (won't be last date, due to above check)
       let date1=myDates[useIth+1] ;

       simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['priorDate']=date0 ;
       simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['nextDate']=date1 ;

       let vals0=simInvDsets['assetDetailsCum']['assets'][anAsset]['list'][date0]  ;

       let vals1=simInvDsets['assetDetailsCum']['assets'][anAsset]['list'][date1]  ;

       let daysGap=date1-date0;
       let thisGap=jdate-date0;
       if (thisGap==0) alert(['calcAssetValuesCum_all error: unexpected dayGap=0',anAsset,jdate,date0,date1]);
       let gapFrac=thisGap/daysGap ;
       simInvDsets['assetValuesCum_byDate'][jdate][anAsset]['gapFrac']=gapFrac+' = ' +thisGap+'/'+daysGap ;

        for (let acurrent in currentVars) {
            let aval0= vals0[acurrent];
            let aval1= vals1[acurrent];

            let vnew=aval0+ (gapFrac*(aval1-aval0));                  // THIS DOES THE INTERPOLATION
            simInvDsets['assetValuesCum_byDate'][jdate][anAsset][acurrent]=vnew  ;
        }      //

        for (let acum in cumVars) {
            let aval0= vals0[acum];
            let aval1= vals1[acum];
            let vnew=aval0+ (gapFrac*(aval1-aval0));   // the interploation!

            simInvDsets['assetValuesCum_byDate'][jdate][anAsset][acum]=vnew   ;
        }



      }   // an asset


  }   // a datee


  return 1 ;
}


//=======================
// create assetHistory from assetHistoryOrig -- by adding "inflation imputed" entries
// also tweaks assetLookup global (since this is called after makeAssetLookup

function updateAssetHistory_inflation(hOrig, lastYearToUse) {

  let dovars=['assetPrice','assetDividend','assetSalePrice','assetNetRent','assetIncome','assetAddition','assetExpense','assetSaleCost'] ;
  let dovarsRel=['assetInterest'] ;
  let noDovars=['assetIncomeGrowth'];
  assetHistory={} ;        // global

// copy assetHistoryOrig global (provided as argument)
  for (let aname in hOrig) {                  // all assets that have some history info
    assetHistory[aname] =JSON.parse(JSON.stringify(hOrig[aname])) ;
    if (assetHistory[aname].hasOwnProperty('entries')) {
      for (iu=0; iu<assetHistory[aname]['entries'].length;iu++) {
         assetHistory[aname]['entries'][iu]['original']=1;       // a non-imputed entry
      }
    }
 }

// add "imputed" (inflation calculated) entries?
  for (let aname in assetHistory) {                  // all assets that have some history info

// 1 march 2024: autoAddEntries avaialble for stocks (price and dividend), properties (sale and rent and salecost), income (yearly income)
//  and expenses (expenses)
// It is NOT available for annuities or oneOffs.
// And makes no sense for bonds or tax deferred bonds (since these don't have a price, they just have interest rate)

    if (assetHistory[aname]['autoAddEntries']==0) continue;        //  not selected for this asset

    let a1Use=assetHistory[aname]['entries'];

// auto add entries? (1 per after the year of the last entry, until end of yearRange?
     let lastEntry=a1Use[a1Use.length-1];
     lastDate=parseInt(lastEntry['date']) ;  // date of last entry
     let lastDateYear=setEntryDate(lastDate).year;
     let infRateLastDate=calcInflation(lastDate,lastDate,3);
     for (kyear=lastDateYear+1;kyear<=lastYearToUse;kyear++) {
             let addme={};
             let kyearDayCount=setEntryDate(kyear,1,1).dayCount;  // date of this "to be imputed" entry
             addme['date']=kyearDayCount ;
             let infRate=calcInflation(lastDate,kyearDayCount);
             addme['comment']='imputed values calculated: from '+lastDateYear+' to '+kyear+' @ '+infRate.toFixed(3);

            for (ij=0;ij<dovars.length;ij++) {
                a1=dovars[ij];
                addme[a1]=  (lastEntry.hasOwnProperty(a1)) ? (infRate*parseFloat(lastEntry[a1]) ) : 0 ;    // adjust if this attribute specified for this asset
            }
            for (ij=0;ij<dovarsRel.length;ij++) {          // interest rates
                a1=dovarsRel[ij];
                if (!lastEntry.hasOwnProperty(a1)) {
                       addme[a1]=0;
                } else {
                   let rateLast=parseFloat(lastEntry[a1]) ;
                   let diffr=rateLast-infRateLastDate ;
                   addme[a1]= Math.max(0,infRate+diffr);
                }
//                addme[a1]=  (lastEntry.hasOwnProperty(a1)) ? ((infRate/infRateLastDate)*parseFloat(lastEntry[a1]) ) : 0 ;    // adjust if this attribute specified for this asset
            }

            for (ik=0;ik<noDovars.length;ik++){
                a2=noDovars[ik];
                addme[a2]=  (lastEntry.hasOwnProperty(a2)) ? parseFloat(lastEntry[a2]) : 0 ;     // set these to 0 (in the future)
            }
            addme['original']=0;

            assetHistory[aname]['entries'].push(addme);      // add to end of historyEntries for this asset
            assetLookup[aname]['nImputed']++ ;        // initialized to 0 by makeAssetLookup

     }           // kyear
  }           // aname

  return 1 ; // modifies global history assetHistory

}

//------
// calculate annuity value given start date
// 5 feb 2024 -- this is basically a front end to  calcAnnuityValueCurrent
//   if you have the acqusition data and growth factor, you can use them in a direct call to calcAnnuityValueCurrent()
//
// if forDate specified, compute the value at this date, give that the annuity started on baseDate
//
//   returns [baseValue,baseGrowth,calcValue,day1,day2,dointerp,growthRateAgg]
//        baseValue : value at "start of annuity" (on basedate)
//        baseGrowth : growth rate (as fraction of CPI) --  applied to baseValue (using CPIs at baseDate and forDate
//        calcValue : annuity income on forDate
//            calcValue ~= baseValue * (1+ (baseGrowth   * (cpiForDate/cpiBaseDate - 1) )
//         dointerp =0 if basevalue is an assethistory entry . NOT if forDate is assetHistory!
// NOte: the "growthRate" is actually "the fraction of the CPI". 1.0 - grow at inflation rate, 0.0: no growth

function calcAnnuityValue(anAsset,basedate,forDate,onLogon) {

  if (arguments.length<3) forDate=false;
  if (arguments.length<4) onLogon=0;

 let ibasedate=parseInt(basedate);
 let agrowths=doAssetLookup(anAsset,'growths') ;
 let avalues=doAssetLookup(anAsset,'acqValues') ;
 let usevalue=false.userate=false;

 if (agrowths.hasOwnProperty(basedate)) {    // exact match?
    let useGrowth=parseFloat(agrowths[basedate]);
    let baseValue=parseFloat(avalues[basedate]);
    if (forDate!==false) {
       let usevalue2=calcAnnuityValueCurrent(baseValue,useGrowth,ibasedate,forDate);
       usevalue=usevalue2[0];
       userate=usevalue2[1];
    }
    return [baseValue,useGrowth,usevalue,ibasedate,forDate,0,userate];    // basevalue matches an entry
  }

 let idates=[];
 for (let g1 in agrowths) idates.push(parseInt(g1));
 let ndates=idates.length;

 if (ndates==0) {       // no entries (should not happen)
    return [0,0,false,false,false,false,false];
 }

 idates.sort(mySortNumeric);

 let ivalues=[],igrowths=[];
 for (let ii=0;ii<idates.length;ii++) {
     let jdate=idates[ii];
     igrowths[ii]=parseFloat(agrowths[jdate]);
     ivalues[ii]=parseFloat(avalues[jdate]);
 }

 if (ibasedate<=idates[0]) {   // before start  -- assume 0
    return [0,0,0,ibasedate,forDate,0,0];
 }

// 9 dec: note that this assumes that starting value of an annuity -- when obtained after "last entry"  -- is the value at the last annuity
// there is NO growth until AFTER an asset is added to a portfolio

 if (ibasedate>=idates[ndates-1]) {      // after last .. use last's value    (or if just one date entry)
     useGrowth=parseFloat(igrowths[ndates-1]);
     baseValue=parseFloat(ivalues[ndates-1]);
     if (forDate!==false) {

       let usevalue2=calcAnnuityValueCurrent(baseValue,useGrowth,ibasedate,forDate);
       usevalue=usevalue2[0];
       userate=usevalue2[1];

     }
       return [baseValue,useGrowth,usevalue,ibasedate,forDate,1,userate];  // 8 dec 2023 : USE BASEDATE, not last entry date
 }

// interpolate! target date is after earliest and before latest (and more than one entry)
 let dy1=idates[0],va1=ivalues[0],gr1=igrowths[0];
 for (let ii=0;ii<ndates;ii++) {

    let trydate=idates[ii];       // date of this entry (in asset history)
    if (trydate<ibasedate)  {       // the "basedate" is after this entry ... so keep looking
       dy1=idates[ii];
       va1=ivalues[ii];
       gr1=igrowths[ii];
       continue;
     }
     let dy2=idates[ii];           // interplolate baseValue (and grwoth) betweey dy1 and dy2
     let va2=ivalues[ii];
     let gr2=igrowths[ii];
     let deltaDays=parseFloat(dy2-dy1);
     let delta1=parseFloat(ibasedate-dy1);
     let dfrac=0;
     if (deltaDays>0) dfrac=delta1/deltaDays;

     baseValue=va1+(dfrac*(va2-va1)) ;

     useGrowth=gr1+(dfrac*(gr2-gr1)) ;
     if (forDate!==false) {
         let usevalue2=calcAnnuityValueCurrent(baseValue,useGrowth,ibasedate,forDate);

         usevalue=usevalue2[0];
         userate=usevalue2[1];

       }

     return [baseValue,useGrowth,usevalue,ibasedate,forDate,1,userate];
 }

showDebug(idates,1,'calcAnnuityValue error with   '+anAsset+ ' on ' +basedate,1);  // should never happen
 return [0,0,false,false,false,false,false];
}

//=======================
//  annuity value given  basevalue, fraction of inflation, and inflition between day1 and day2
function  calcAnnuityValueCurrent(baseValue,useGrowthFrac,day1,day2) {

  if (!jQuery.isNumeric(day1) || !jQuery.isNumeric(day2) ) {   // an immediatly fatal error
      alert('calcAnnuityValueCurrent error: odd days : day1 ='+day1+', day2='+day2);  // 24 sep 2023 : reenable this ??
      let forceError=13/forceError0 ;
      return [false,false];   // bad
  }
  if  ( day2<day1) {
     return [0,0]  ; // before acquistion , hence 0
  }

  let ainf=calcInflation(day1,day2);
  let ainf2=ainf-1;
  let afact=ainf2*useGrowthFrac;
  let afact2=1+afact;
  avalue=baseValue*afact2 ;
  let ddays=day2-day1;
  return [avalue,afact2,baseValue,useGrowthFrac,ainf,ddays];
}



//=========================
// read entry in   !simInvDsets['assetValuesCacheCum']['list'] (a global)
// if no such entry, return false
function assetsCacheCum_read(aname,adate1,adate2) {
  if (simInvGlobals['cacheStuff']['suppressCache']===true) {
//      nCacheNotUseGlobal++   ;
      simInvGlobals['cacheStuff']['nCacheNotUseGlobal']
      return false ;
  }

    if (!simInvDsets['assetValuesCacheCum']['list'].hasOwnProperty(aname))  simInvDsets['assetValuesCacheCum']['list'][aname]={} ;
    if (!simInvDsets['assetValuesCacheCum']['list'][aname].hasOwnProperty(adate1)) {
            simInvDsets['assetValuesCacheCum']['list'][aname][adate1]={} ;
    }
    if (!simInvDsets['assetValuesCacheCum']['list'][aname][adate1].hasOwnProperty(adate2)) {
         simInvGlobals['cacheStuff']['nCacheNotUseGlobal']++    ;
         simInvDsets['assetValuesCacheCum']['list'][aname][adate1][adate2]=false ;  // false means "needs to be initialized)
    } else {             // in cache!
        simInvGlobals['cacheStuff']['nCacheUseGlobal']++   ;
    }
   return simInvDsets['assetValuesCacheCum']['list'][aname][adate1][adate2];   // if not in cache, false is returned

}

//=========================
// write entry to   !simInvDsets['assetValuesCacheCum']['list'] (a global)

function  assetsCacheCum_write(aname,adate1,adate2,ts) {
  if (simInvGlobals['cacheStuff']['suppressCache']===true) return false ;       // no point in writing to cache if suppressed

   let foo=assetsCacheCum_read(aname,adate1,adate2) ;    // create spot  (if already exists, ignore return
   simInvDsets['assetValuesCacheCum']['list'][aname][adate1][adate2]=ts;
   return 1;
}