// asset, and asset history, functions (simInv)
//=============
// show asset table, and allow adding assets

function showAssetTable(ifoo) {

  redisplayHeaderLine(1);

  let nHidden=0;
  for (let jj=0;jj<assetList.length;jj++) {
      if (assetList[jj]['isHidden']==1 ) nHidden++ ;
  }

  let amess='';
  amess+='<div style="background-color:tan;font-weight:500">';
  amess+='  <span class="biggerNameBold">&#127803; Assets</span> ';
  amess+=' <em>You can </em>';
  amess+=' <button title="not this button, the one in the top row of the table!" >Add</button> a new asset, or ';
  amess+='<button title="not this button, the one in the on the row of the asset you want to remove!">Remove</button> an existing asset ...  ';
  amess+=' and then</em> <input type="button" title="not this button, the one in the top row of the table!" onClick="scrollAssetsTable(this)" value="Save">  &boxV;   ';
  amess+='<input type="button" value="&#128201;" >To view/modify an asset\'s <span title="History: the price/dividend/interest trend of an asset" >';
  amess+=' history </span> &boxV; ';
  amess+='  <input type="button" value="&#9998;Init" style="background-color:lime" > To specify an asset\'s first price, etc.';
  amess+='<span style="float:right;margin-right:0.6em"> ';
  amess+='<button id="ishowAssetTable_mixes" onClick="showAssetTable_mixes(this)" data-on="0" class="csettingsButton" title="QuickView the asset mix for the init, and all modifications, of your portoflios">Portfolio asset mixes</button> ';
  amess+='</div>';
  amess+='<div id="assetTablePreview" class="cassetTablePreview"></div>  ';

// =========== quick view of all portfolio asset mixes
  amess+='  <div id="assetsTable_above" style="display:none;max-height:5em;overflow:auto;border:3px solid blue;border-radius:3px">';
  let goofAll=[];
 // showDebug( portfolioLookup['list'],'asdfasdf',1);
  for (let paname in portfolioLookup['list']) {
 
      let ihide=portfolioLookup['list'][paname]['isHidden'];
     let nin=portfolioLookup['list'][paname]['nHistory'];
      let bb1;
      if (ihide==1) {
          bb1='<button  title="View this Hidden portfolio`s '+nin+'  entries"  style="font-family: ui-rounded; color:#8b8aa5;"  ' ;
      } else {
         bb1='<button  title="View this portfolio`s '+nin+' entries"  ';
      }
      bb1+='   onclick="showAllPortfolioValues_viewEntry(this)" data-ith="0"  data-var="" data-name="'+paname+'"> ';
      bb1+=paname+'</button>';
      goofAll.push(bb1);        // will overfwrite prior save, but so what
  }
  let gsay=goofAll.join(' ');
  amess+='<input type="button" value="x" onClick="$(\'#ishowAssetTable_mixes\').trigger(\'click\')" >';
  amess+='<em>View asset-mix of a portfolio ...</em> '+gsay ;
  amess+='  </div>';

// the table of each asset
  amess+='<div id="assetsTableOuter" style="max-height:70%; overflow:auto;margin:0.9em" >';
  amess+='<table  border="1" id="assetsTable" width="95%"  class="cassetsTable0">';
  amess+='<tr class="headerRow">';

  amess+='<td width="24%"  title="sort by: first entry date (in asset history)" >';

  amess+='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#assetTableHiddenHelp">?</button> ';
    amess+=' <button class="cHideButton" style="font-size:90%" data-show="1" title="Toggle view of hidden assets" onClick="showHiddenAssets(this)">Hide '+nHidden+' &hellip;</button>';
  amess+=' <button class="cdoButtonTan" title="Click to add a new row" onClick="addARowAssets(this)">Add</button>';
    amess+='<span style="float:right;margin-right:0.25em"> <button class="csaveButton" title="Save these assets " onClick="saveAssets(this)">Save!</button></span>';

  amess+='</td>';

  amess+='<th width="12%" > <span class="choiceNameSay">Name</span> ';
    amess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#assetsTableHelp1">&#10068;</button>';
  amess+='</th>';
  amess+='<th width="22%"  > <span title="What type of asset: stock, bond, property, income...">assetType? &amp; attributes  </span></th>';

  amess+='<th width="20%"  > <span title="Short description">Desc &amp; taxSettings  </span></th>';
  amess+='<th width="22%" title="sort by: # of entries (assetHistory)"  > <span title="Long description">DescLong &amp;  <span title="What portfolios does this asset appear in" class="cinWhatPortfolios">portfolios</span> </span></th>';
  amess+='</tr>';

  amess+='<tr class="assetRowCash" data-name="cash">';
  amess+='<td><button title="The `cash` asset can not be removed!" class="cdescNoteLittle" ><u>Cash</u> can not be removed</button>&hellip;</td>';
  amess+='<td><u>Cash</u></td>';
  amess+='<td>';
  amess+='<button title="Toggle short description of asset types..." onClick="$(\'#assetTypeNote\').toggle()" >&#9834</button>';
  amess+='<div id="assetTypeNote" style=display:none;font-size:90%;border:1px dotted gray;padding:3px">';
  amess+='<div>';
  amess+="<em>The asset types:</em> ";
  for (let ioof=0;ioof<8;ioof++) {
      let aoof=getAssetType(ioof,'say');
      amess+='<span style="border:1px solid black;padding:0px;white-space:nowrap">'+aoof+'</span> ... ';
  }
  amess+='</div>';

  amess+='<div style="border-top:1px dotted black;margin-top:5px;padding-top:4px"><em>Attributes:</em>';
  amess+='  <span  class="cnImputedAssetEntries"># imputed assetHistory entries</span> ';
  amess+='  <span  class="ctaxFreeFrac">Tax free fraction</span> ';
  amess+='</div>';

  amess+='</div>';

  amess+=' </td>';

  amess+=' <td><button readonly title="The `cash` asset is auto-calculated" >Cash... </button></td>';
  amess+='<td><button readonly"><u>Cash</u>  =  <tt> budget  -  portfolioCost </tt></button></td></tr>';

  for (let aname in assetLookup) {

    let aname0=aname;
    let sayName=doAssetLookup(aname,'sayname','',1);
    let nHistory=doAssetLookup(aname,'nHistory',2,1)  ;  // the actual # entrieds (does NOT include inflationImputed entries)
    let isPublic=doAssetLookup(aname,'isPublic' ) ;

    let firstEntryDayCount=doAssetLookup(aname,'date','',1);
    let firstEntryDateSay=doAssetLookup(aname,'firstEntryDateSay','',1);
    let nImputed=doAssetLookup(aname,'nImputed','',1);
    let isHiddenAsset=doAssetLookup(aname,'isHidden');
    let cIsHidden= (isHiddenAsset==1) ?  ' cHideThisAsset ':  ' ';

    amess+='<tr class="assetRow  '+cIsHidden+'"  data-name="'+aname+'">';
    amess+='<td  data-_sortuse="'+firstEntryDayCount+'" >';
    if (isHiddenAsset==1) {
       amess+='<span>';
       amess+= '<button  class="cHiddenAssetSpan" data-status="1" title="unHide this asset " onClick="hideAssetRow(this)">';
       amess+='<span> unHide</span></button>';
       amess+='</span>';
    } else {
       amess+='<span> ';
       amess+='<button data-status="0"   title="hide this asset "  onClick="hideAssetRow(this)">&nbsp;Hide&nbsp;</button>';
       amess+=' </span>';
    }
    amess+='<span> <input type="button" value="Remove" onClick="removeAssetRow(this,0)"></span>';

    let inPortfolios=  (assetsUsed['list'].hasOwnProperty(aname)) ? assetsUsed['list'][aname]['nPortfolios'] : 0 ;
    if (inPortfolios=='Nan' || isNaN(inPortfolios)) inPortfolios=0;

    if (nHistory>0) {
      amess+='<input type="button" value="&#128201;" title="View history of this asset (price/dividend/interest)"  ';
      amess+='  class="cButtonAssetHistory"  data-sayname="'+sayName+'"   data-init="0"   data-name="'+aname+'" onClick="showAssetHistory(this)"  >';
      amess+='<span title="Date of first entry /  # entries " class="cAssetHistoryShow">'+firstEntryDateSay+' / '+nHistory+'</span>';

    } else {
      amess+='<input type="button" value="&#9998;Init" style="background-color:lime" title="No history entries have been assigned to this asset)"  ';
      amess+=' class="cButtonAssetHistory"  data-sayname="'+sayName+'"  data-init="1" data-name="'+aname+'" onClick="showAssetHistory(this)"  >';
    }
    amess+='</td>';


    let assetType=doAssetLookup(aname,'assetType','',1); // suppress alerts (catch below)
    if (assetType===false) {        // a missing asset?
       amess+='<td bgcolor="yellow">'+aname+'</td>';
       amess+='<td>bad asset (no type)';
       amess+=' <input type="hidden" name="assetName" data-nocheck="1" value="'+aname+'">';
       amess+='       </td>';
       amess+='</tr>';
       continue ;
    }

    let sayName2= (isPublic==1) ? '<span title="a public asset">&Pscr; '+sayName+'</span> '  : sayName ;
    amess+='<td data-_sortuse="'+sayName+'" ><span name="assetNameSay" class="cNameSay">'+sayName2+'</span>';
    amess+='<input type="hidden" name="assetName" value="'+aname+'">';     // hack to facilitate read of all assetnames in menu
    amess+='</td>';

    let assetTypeSay=getAssetType(assetType,'iconSpan');
    let taxFreeFrac=doAssetLookup(aname,'taxFreeFrac',1);

    let   annuitySay='' ;
    if (assetType==5) {
         annuitySay=' <span title="Annuity amount set when asset acquired (although it can grow) "  class="cnImputedAssetEntries" ';
         annuitySay+='   xstyle="font-style:oblique;font-size:85%">~</span> ' ;
    }

    amess+='<td data-_sortuse="'+assetType+'"><span name="assetBond"  data-type="'+assetType+'" class="cBondSay cassetTypeSay">'+ assetTypeSay+' </span>';
    amess+=annuitySay ;

    if (nImputed>0) {
       amess+='<span class="cnImputedAssetEntries"  title="# of imputed (using predicted inflation) entries">'+nImputed+'</span>';
    }

    if (taxFreeFrac===false || taxFreeFrac==='false') taxFreeFrac=0.0;
    amess+='<span style="float:right;margin-right:0.1em">';
    if (assetType==1 ) amess+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=interest earnings are not taxed)">'+taxFreeFrac+'</span>';
    if (assetType==3 ) amess+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=capitalGains are not taxed)">'+taxFreeFrac+'</span>';
    if (assetType==4 ) amess+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=income is not taxed)">'+taxFreeFrac+'</span>';
    if (assetType==5 ) amess+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=annuity is not taxed)">'+taxFreeFrac+'</span>';
    if (assetType==6 ) amess+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=income is not taxed)">'+taxFreeFrac+'</span>';
    if (assetType==7 ) amess+='<span class="ctaxFreeFrac" title="fraction of expense that offsets taxable income  (1.0=fully offsets">'+taxFreeFrac+'</span>';

    amess+='</td>';


// short descirption
   let adesc3=doAssetLookup(aname,'desc');
    amess+='<td><span name="assetDesc"  class="cDescSay">'+adesc3+'</span></td>';

// long descrition & what portfolios this asset appears in
    amess+='<td  data-_sortuse="'+nHistory+'">';;

   let zalist='';

    if (assetsUsed['list'].hasOwnProperty(aname)) {         // this asset is in at least one portfolio
       let goof=[];
       for (let pp1 in assetsUsed['list'][aname]['portfolios']){

           let adisable=' ',ihide=0 ;
           if (typeof(portfolioLookup)=='undefined' || !portfolioLookup.hasOwnProperty('list') ||  !portfolioLookup['list'].hasOwnProperty(pp1)) {
                adisable=' disabled '  ;
           } else {
                ihide=portfolioLookup['list'][pp1]['isHidden'];
           }
           let nin=assetsUsed['list'][aname]['portfolios'][pp1].length

           let bb1;
           if (ihide==1) {
              bb1='<button  title="View this Hidden portfolio`s '+nin+' entries"  '+adisable+' style="font-family: ui-rounded; color:#8b8aa5;"  ' ;
           } else {
                bb1='<button  title="View this portfolio`s '+nin+' entries"  '+adisable ;
           }
           bb1+='   onclick="showAllPortfolioValues_viewEntry(this)" data-ith="0"  data-var="'+aname+'" data-name="'+pp1+'"> ';
           bb1+=pp1+'</button>';

           goof.push(bb1);
       }
       zalist=goof.join(' &nbsp;  ');
    }
    let adesc3long=doAssetLookup(aname,'descLong');
    amess+='<div name="assetDescLong" class="cDescLongSay">'+adesc3long+'</div>';
    amess+='<div title="Portfolios that `'+aname+'` appears in" class="cinWhatPortfolios">'+zalist+'</div>';


    amess+='</td>';

    amess+='</tr>';
  }
  amess+='</table>  ';
  amess+='<div style="margin-top:2px;font-size:80%;opacity:0.66;color:blue;padding-left:10em"> ... list of assets ... </div>';

  amess+='</div> ';
  $('#mainDiv3').html(amess);

   $('#assetsTable').data('removes',{});  // reset every time table is displayed

  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv2');
  wsurvey.wsShow.show('#mainDiv3','show');

  let oof1={'skips':[],'startRow':2}   ;

  let asay='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#assetsTableHelp1">&#10068;</button> &#127803;  Create or specify <b>assets</b>    ... '
  asay+='<button  class="csettingsButton" name="doAssetButton"   title="Compressed view " onClick="showAssetHistory(this)" > &#128476; vu</button> ';

  hidePortfolioHeader(2,asay);

  wsurvey.sortTable.init('assetsTable',oof1);

 fitInMainDiv3('assetsTableOuter');
  return 1;
}

//===========
// show the "quick smmary of all portoflio" mixes row
function showAssetTable_mixes(athis) {
   let ethis=wsurvey.argJquery(athis);
   let ison=ethis.attr('data-on');
   if (ison==1) {
       $('#assetsTable_above').hide();
       ethis.attr('data-on',0);
   } else {
       $('#assetsTable_above').show();
       ethis.attr('data-on',1);
   }
}

//===============
// toggle view or hidden assets (rows in the asset table)
function showHiddenAssets(athis) {
   let ethis=wsurvey.argJquery(athis);
   let isShow=parseInt(ethis.attr('data-show'));
   let ug=1-isShow;
   ethis.attr('data-show',ug);

   let etable=$('#assetsTable');
   let ehides=etable.find('.cHideThisAsset');
   let nhides=ehides.length;
   if (nhides==0) return 0;              // no hiddend assets

   if (isShow==1) {    // currentliy  shown -- so hide
       ehides.hide();
       ethis.addClass('hideAssetsButtonOn');
       ethis.html('Unhide ' +nhides+' &hellip; ')
   } else {
       ehides.show();
       ethis.removeClass('hideAssetsButtonOn');
       ethis.html('Hide '+nhides+' &hellip; ')
   }


  return ehides.length;
}

//===============
// hide asset row -- this is saved, so that on next logon this asset is not displayed in asset table
// but.... it is still available for use in portfolios (i.e.; portfolios it was added to BEFORE being hidden)
function hideAssetRow(athis) {
   let ethis=wsurvey.argJquery(athis);
   let ishidden=ethis.attr('data-status');
   let etr=ethis.closest('.assetRow');
   if (ishidden==0) {          // currently unhidden, so  hide
       ishidden=1;
       ethis.attr('data-status',1);
       ethis.addClass('cHiddenAssetSpan');
       ethis.html('unHide');
       etr.addClass('cHideThisAsset');
   } else {              // currently hidden, so unhide
       ishidden=0;
       etr.removeClass('cHideThisAsset');
       ethis.removeClass('cHiddenAssetSpan');
       ethis.attr('data-status',0);
       ethis.html('&nbsp;Hide&nbsp;');
   }

}


//====================
// add a row to assets Table
//&#127463;ond;
//&#127480;tock
//&#127299;axDefer
//&#127477;roperty
//&#127470;ncome
//&#66304;nnuity
//&#120793;oneOff


function addARowAssets(ifoo,useName) {
   if (arguments.length<2) useName='' ;
   let etable=$('#assetsTable');

   let amess=''
    amess+='<tr class="assetRow assetRowNew">';
    amess+='<td> <input type="button" value="Remove this row ..." onClick="removeAssetRow(this,1)">';
    amess+='</td>';
    amess+='<td> <input type="text" size="12" name="assetName" value="'+useName+'"></td>';
    amess+='<td> ';
    amess+='<div  name="assetTypeBlock" data-assetType="0">';    // default is stock


// extra attributes (what is shown depends on selected type
// displayed in DESC .... cell

    let amessOther='',aicon='';

       amessOther+='<div   name="assetTypeBlock_more"   class="cassetTypeBlock_more" title="attributes ...">';
       amessOther+='<div name="type0_span" class="cassetTypeBlock_more1" style="display:inline-block"  >';
       aicon=getAssetType(0,'icon');

       amessOther+=aicon+' Earnings fully taxed<br>CapGains fully taxed';
       amessOther+='</div>  ';

       aicon=getAssetType(1,'icon');
       amessOther+='<div name="type1_span" class="cassetTypeBlock_more1"  >'+aicon+' Fraction of earnings NOT taxed:';
       amessOther+=' <input name="nbondTaxFrac" value="0.0" title="taxFree fraction (0.0=interest earnings IS fully taxed ... 1.0:  interest earnings are NOT taxed" type="text" size="4" >';
       amessOther+='<br><span style="border:1px dotted gray;white-space:nowrap;display:inline-block">Sales (capGains) are <u>not</u> taxed</span> ';
       amessOther+='</div>  ';

       aicon=getAssetType(2,'icon');
       amessOther+='<div name="type2_span" class="cassetTypeBlock_more1"  >';
       amessOther+=aicon+' Earnings <u>not</u> taxed<br> Sales (capGains) fully taxed  ';
       amessOther+='</div>  ';

       aicon=getAssetType(3,'icon');
       amessOther+='<div name="type3_span"  class="cassetTypeBlock_more1">'+aicon+' ';
       amessOther+='<span style="margin-left:1em;font-size:80%;white-space:nowrap;display:inline-block">+Rents fully taxed</span>  ';
       amessOther+='<br> Fraction of capitalGains NOT taxed: ';
       amessOther+='  <input name="ncapGainsTaxFreeFrac" value="0.0" title="non-taxable fraction of capital gains (0.0=capitals gains IS taxed (at capital gains rate),... 1.0:  capital gains NOT taxed" type="text" size="4" >';

       amessOther+='</div>  ';

       aicon=getAssetType(4,'icon');
       amessOther+='<div  name="type4_span"  class="cassetTypeBlock_more1" >'+aicon+' ';
       amessOther+='Fraction of income <u>not</u> taxed: ';
       amessOther+=' <input name="nincomeTaxFreeFrac" value="0.0" title="non-taxable fraction of income (0.0= income IS taxed,... 1.0:  income is NOT taxed" type="text" size="4" >';
       amessOther+='</div>  ';

       aicon=getAssetType(5,'icon');
       amessOther+='<div name="type5_span"  class="cassetTypeBlock_more1" >'+aicon+' ';
       amessOther+=' Fraction of annuity NOT taxed: ';
       amessOther+=' <input name="nannuityTaxFreeFrac" value="0.0"  ';
       amessOther+='    title="non-taxable fraction of annuity income \n0.0= income IS taxed,... 1.0:  income is NOT taxed" type="text" size="4" >';

       amessOther+='<br>';
       amessOther+='</div>  ';

       aicon=getAssetType(6,'icon');
       amessOther+='<div name="type6_span"  class="cassetTypeBlock_more1">'+aicon+' ';
       amessOther+='</div>  ';

       aicon=getAssetType(7,'icon');
       amessOther+='<div name="type7_span"  class="cassetTypeBlock_more1">'+aicon+' ';
       amessOther+=' Fraction that offsets income: ';
       amessOther+=' <input name="nexpenseTaxOffsetFrac" value="0.0" title="fraction of expense that offsets taxable income.\n 0.0=none, 1.0=expense can be claimed as a deduction" type="text" size="4" >';
       amessOther+='</div>  ';

    amessOther+='</div>';

    amess+='<div style="background-color:#dfe59d;">';
    amess+=' <span class="cassetTypeBlock1 cassetTypeBlock1_highlight"><label title="Stock asset">';
    amess+='   <input checked   onClick="selectAssetType(this)" type="radio" value="0"  >';
        amess+=getAssetType(0,'iconSpan')+'  </label> ' ;
    amess+='</span> ' ;

    amess+='<span class="cassetTypeBlock1 "><label  title="Bond (regular) asset"><input  onClick="selectAssetType(this)" type="radio" value="1">';
        amess+=getAssetType(1,'iconSpan')+'</label>';
    amess+='</span> ' ;

    amess+=' <span class="cassetTypeBlock1"><label  title="Bond (tax-deferred) asset"><input onClick="selectAssetType(this)" type="radio" value="2" >';
        amess+=getAssetType(2,'iconSpan')+'</label> ' ;
    amess+='</span> ' ;

    amess+=' <span class="cassetTypeBlock1"><label  title="Property asset"><input onClick="selectAssetType(this)" type="radio" value="3" >';
        amess+=getAssetType(3,'iconSpan')+'</label>' ;
    amess+='</span> ' ;

    amess+=' <span  title="Income-stream   asset" class="cassetTypeBlock1">';
       amess+='<label ><input onClick="selectAssetType(this)" type="radio"  value="4" >'  ;
       amess+=getAssetType(4,'iconSpan')+'</label> ' ;
    amess+='</span> ' ;

    amess+=' <span  title="Annuity asset" class="cassetTypeBlock1">';
       amess+='<label ><input onClick="selectAssetType(this)" type="radio"  value="5" >'  ;
       amess+=getAssetType(5,'iconSpan')+'</label> ' ;
    amess+='</span> ' ;


    amess+=' <span  title="oneOff asset" class="cassetTypeBlock1">';
       amess+='<label ><input onClick="selectAssetType(this)" type="radio"  value="6" >'  ;
       amess+=getAssetType(6,'iconSpan')+'</label> ' ;
    amess+='</span> ' ;

    amess+=' <span  title="expenseStream asset" class="cassetTypeBlock1">';
       amess+='<label ><input onClick="selectAssetType(this)" type="radio"  value="7" >'  ;
       amess+=getAssetType(7,'iconSpan')+'</label> ' ;
    amess+='</span> ' ;

    amess+='</div>';
    amess+='</div>';
    amess+='</td>';  // asset type radio buttons & more

    amess+='<td>';
    amess+='<div name="assetAttribs_other" >';
    amess+=amessOther ;
    amess+='</div>';
    amess+='Desc:<input title="Short description" type="text" size="34" name="assetDesc" value="">  ';
    amess+='</td>';


    amess+='<td> <textarea rows="2" cols="40" name="assetDescLong"></textarea></td>';
    amess+='</tr>';

    let ec1=etable.find('.assetRowCash');
    ec1.after(amess);

    let aamess='After specifying new assets to add, and existing assets to remove -- click  <button onClick="scrollAssetsTable(this)" title="not this button, the one in the top row of the table!"><b>Save!</b></button>';

    aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em>  ';
    aamess+=' <button class="csaveButton" onClick="showAssetTable(this)">reload the assets list </button> <em>without making these changes!</em>';
    $('#assetTablePreview').html(aamess);


}

//================
// select asset type button highligher
// val: 0:stock,1:bond, 2:tax defererd bond, 3:property, 4:income , 5=annuity, 6=oneoff, 7=expense
function selectAssetType(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aval=ethis.val();

   let eblock=ethis.closest('[name="assetTypeBlock"]');
   eblock.attr('data-assetType',aval);         // make it easy to determine assetType of newly added asset

// highlight/check the clicked on type
   let espans=eblock.find('.cassetTypeBlock1');
   espans.removeClass('cassetTypeBlock1_highlight');

   for (let iss=0;iss<espans.length;iss++) {
      let einput=$(espans[iss]).find('input');
      einput.prop('checked',false);
   }
   let espan1=ethis.closest('.cassetTypeBlock1');
   espan1.addClass('cassetTypeBlock1_highlight');
   ethis.prop('checked',true);

// extra attribute?
   let etr=ethis.closest('.assetRowNew');
   let eOthers=etr.find('[name="assetAttribs_other"]');
   let emore=eOthers.find('[name="assetTypeBlock_more"]');
    let efoo=emore.find('.cassetTypeBlock_more1');
    efoo.hide();

    let goo='type'+aval+'_span';
    let egoo=emore.find('[name="'+goo+'"]');
    egoo.show();


}

//=================
// hide show tax derer and tax free if this is bond/stock
function addARowAssetsCheck(athis) {
  let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('.assetRowNew');
   let ischeck=ethis.prop('checked');      // if chcked, this is a bond
   let efree=erow.find('[name="assetTaxFreeFraction"]');

   edefer.prop('checked',false);
   efree.val(0.0)  ;       // reset to defaults

   if (ischeck) {   // bond
      edefer.prop('disabled',false);
      efree.prop('disabled',false);
   } else {
      edefer.prop('disabled',true);
      efree.prop('disabled',true);
   }
}

//=================
// set taxfree pct if taxDefer chosen/unchosen
function addARowAssetsCheck2(athis) {
   let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('.assetRowNew');
   let ischeck=ethis.prop('checked');      // if chcked, this is a bond
   let efree=erow.find('[name="assetTaxFreeFraction"]');
   efree.val(0.0)  ;       // reset to default
   if (ischeck) {   // tax defered
      efree.prop('disabled',true);
   } else {
      efree.prop('disabled',false);
   }

}
///==================
// called as an event handler
// save the new assets, or remove  assets.
function saveAssets(athis) {
 
  let nustuff=[];
   let etable=$('#assetsTable');
   let removes=$('#assetsTable').data('removes');
   let remove1=[];
   let nowTime=wsurvey.get_currentTime(0);
   let aNewAsset=false;
   for (let ab in removes) remove1.push(ab);

   let gotNames={};
   let hideAssets=[];

// find specified assets (new and old) -- caution if in removes. Used to prevent trying to specify an asset BEFORE removing it
// also check for improper names
   let etrs=etable.find('.assetRow');
   for (let jet=0;jet<etrs.length;jet++) {
         let aetr=$(etrs[jet]);
         let e1=aetr.find('[name="assetName"]')

         let aname0=jQuery.trim(e1.val().toLowerCase());
         if (aname0=='') continue ; // ignore blank
         let aname=aname0;

         if (gotNames.hasOwnProperty(aname)) {
             alert(aname+' is already specified. Use a different name for this new asset. Note that to respecify an asset -- remove it, save, then add it back');
             return 0
         }
         gotNames[aname]=1;
         if (aetr.hasClass('cHideThisAsset')) hideAssets.push(aname)
   }

   let etrsNew=etable.find('.assetRowNew');

   for (let j1=0;j1<etrsNew.length;j1++) {     // read new rows assets
         let aetr=$(etrsNew[j1]);
         let e1=aetr.find('[name="assetName"]')
         let aname=fixString(jQuery.trim(e1.val()),1);
         if (aname=='') {
              alert('You did not specify an asset name ');
              return 0;
         }
         let sayName=aname;      // allow capitals in displayed name
         aname=aname.toLowerCase();
         if (aname=='cash') {
            alert('`cash` can not be used as an asset name');
            return 0;
         }

         if (aname.substr(0,1)=='_') {
            alert('`_` can not be the first letter of an asset name ');
            return 0;
         }


         let aname0=aname;
         aname=fixStringRemoves(aname0);
         if (jQuery.isNumeric(aname)) {
            alert('You can not use a number as an asset name: `'+aname0+'`');
            return 0;
         }

         if (aname0!==aname) {
             alert('Improper asset name: `'+aname0+'`\n Use a different name without any of the following characters: embedded spaces, commas, %,  &, +, *, /, \\, \', `, ", #, !, $, <, >, or  | ');
             return false;
         }

         let oof=aname.split('.');
         if (oof.length>2) {           // too many .
            alert('Improper asset name: too many periods: '+aname0+'\n You can specify `family` or `family.variant` ');
            return false;
        }

         let e2b=aetr.find('[name="assetTypeBlock"]');
         let iAssetType=e2b.attr('data-assettype')

         let afrac=false;  //   used for types 1,3,4 (regular bond, properties, incomeStream)

         if (iAssetType==1)  {  // regular bond...
             let e3=aetr.find('[name="nbondTaxFrac"]');
             afrac=jQuery.trim(e3.val());
             if (afrac==='' || !jQuery.isNumeric(afrac) || parseFloat(afrac)<0.0 || parseFloat(afrac)>1.0 ) {
                 alert('Please enter value between 0.0 and 1.0 for '+aname+'  (non taxable portion of interest earnings) ');
                 return 0;
             }
         }
         if (iAssetType==3)  {  // property
             let e3=aetr.find('[name="ncapGainsTaxFreeFrac"]');
             afrac=jQuery.trim(e3.val());
             if (afrac==='' || !jQuery.isNumeric(afrac) || parseFloat(afrac)<0.0 || parseFloat(afrac)>1.0 ) {
                 alert('Please enter value between 0.0 and 1.0 for '+aname+'  (non taxable portion of capital gains) ');
                 return 0;
             }
         }

         if (iAssetType==4)  {  // income
             let e3=aetr.find('[name="nincomeTaxFreeFrac"]');
             afrac=jQuery.trim(e3.val());
             if (afrac==='' || !jQuery.isNumeric(afrac) || parseFloat(afrac)<0.0 || parseFloat(afrac)>1.0 ) {
                 alert('Please enter value between 0.0 and 1.0 for '+aname+'  (non taxable portion of income stream) ');
                 return 0;
             }
         }

         if (iAssetType==5)  {  // income
             let e3=aetr.find('[name="nannuityTaxFreeFrac"]');
             afrac=jQuery.trim(e3.val());
             if (afrac==='' || !jQuery.isNumeric(afrac) || parseFloat(afrac)<0.0 || parseFloat(afrac)>1.0 ) {
                 alert('Please enter value between 0.0 and 1.0 for '+aname+'  (non taxable portion of annuity) ');
                 return 0;
             }
         }

         if (iAssetType==6)  {  // oneOff
         }

         if (iAssetType==7)  {  // expense
             let e3=aetr.find('[name="nexpenseTaxOffsetFrac"]');
             afrac=jQuery.trim(e3.val());
             if (afrac==='' || !jQuery.isNumeric(afrac) || parseFloat(afrac)<0.0 || parseFloat(afrac)>1.0 ) {
                 alert('Please enter value between 0.0 and 1.0 for '+aname+'  (fraction of expense that offsets taxable income) ');
                 return 0;
             }
         }

         let e2=aetr.find('[name="assetDesc"]')
           let adesc=fixString(jQuery.trim(e2.val()),2);
           adesc=wsurvey.removeAllTags(adesc);
         let e3=aetr.find('[name="assetDescLong"]')
           let adescLong= jQuery.trim(e3.val())  ;
           adescLong=wsurvey.removeAllTags(adescLong);

        let arow={'name':aname,'sayname':sayName,'assetType':iAssetType,'taxFreeFrac':afrac,'desc':adesc,'descLong':adescLong} ;
        nustuff.push(arow);    // new ones
        
        if (aNewAsset===false) aNewAsset=aname;  // used in autologon 

   }   // new row

  
  let aHides={};
  for (let jj=0;jj<hideAssets.length;jj++) {
     let az=hideAssets[jj];
     aHides[az]=1;
  }

// new hiddens?
  let newHides={},nHideChanges=0 ;
  for (let ijj=0;ijj<assetList.length;ijj++) {
      ass1=assetList[ijj];
      assName=ass1['name'];
      wasHide=ass1['isHidden'];
      if (wasHide==1) {                    // wass hidden.. but not  hidden now?
         if (!aHides.hasOwnProperty(assName)) {
           newHides[assName]=0;             // unhide this
           nHideChanges++;
         }
     } else {                                // was not   hidden... but now hidden?
         if (aHides.hasOwnProperty(assName)) {
           newHides[assName]=1;               // hide this
           nHideChanges++;
         }
     }
  }

  if (remove1.length==0 && nustuff.length==0 && nHideChanges==0) {
      alert('You did not remove, add, or hide  ... any assets');
      return 0;
  }
// assets: [] with each row descrigin an asset (with 'name' propreryt)
// assetHistory {} with property being name. Each [assetName] has a 'entries'=[] (list of entries) and an 'autoAdd'= 0/1

 let newAssets={'time':nowTime,'data':[] } ;           // list is an array -- each row is an asset
 let newAssetHistory={'time':nowTime,'data':{}};  // assetList will have (date,entries,autoAddEntries)

 let remHash={};  // easier to work with a hash...
 for (let irr=0;irr<remove1.length;irr++)  remHash[remove1[irr]]=1;  // 15 dec 2023.. a bit goofy re-creating a hash, but for now wth

 let nretain=0,nremove=0;
// only keep assets entries NOT in remHash
 for (let ij=0;ij<simInvDsets['allCurrentData']['assets']['data'].length;ij++) {
     let aname=simInvDsets['allCurrentData']['assets']['data'][ij]['name'] ;
     if (remHash.hasOwnProperty(aname)){
         nremove++;
         continue ;
     }
     nretain++ ;
     let aentry=JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['assets']['data'][ij]));
     if (newHides.hasOwnProperty(aname)) {        // if not in newHides,   isHidden attribute is unchanged
        aentry['isHidden']=newHides[aname];
     }
     newAssets['data'].push(aentry);
 }

// add newly added assets
let nadd=0;
 for (let jj in nustuff) {
    let goo=JSON.parse(JSON.stringify(nustuff[jj]));
    goo['addTime']=nowTime;      // vars NOT in input form...
    goo['isHidden']=0;
    goo['isPublic']=0;
    newAssets['data'].push(goo);
    nadd++;
 }

// only keep assetHistory entries NOT in remHash
  for (anasset in  simInvDsets['allCurrentData']['assetHistory']['data']) {
      if (remHash.hasOwnProperty(anasset)) continue ;
      newAssetHistory['data'][anasset]= JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['assetHistory']['data'][anasset])); // includes 'entries' and 'autoAddEntries'
 }

//   for each new assets  -- add entry in assetHistory
 for (let jj in nustuff) {
    basset=nustuff[jj]['name'];
    newAssetHistory['data'][basset]={'updateTime':nowTime,'entries':[],'autoAddEntries':0};
 }

// and save them (to server or locally)...

   let bmess=newAssets['data'].length  +' assets:  after '+nretain+' retained, '+nremove+' removed, '+nadd+' added  ';
   if (nadd>0) bmess+= '<br> After reloading -- use  <button> &#128065; assets</button> to add history-entries for the newly added assets ';

  simInvGlobals['temp']['autoLogonDetails']={'action':'assetsSave','asset':aNewAsset} ;
  saveSimInvData_assetsSave(userName,newAssets,newAssetHistory,bmess);      // saveSimInvData_assetsSave deals with callbacks
  simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

  return 1;

}


//====================
// remove row from asset, or asset history, table
function removeAssetRow(athis,isNew) {

   let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('tr');

   if (isNew==1)  {  // new row, just remove it
      erow.remove();
      return 1;
   }

   let aname=erow.attr('data-name');

   if (jQuery.trim(aname)!='') {          // removing existing asset
    if (assetsUsed['list'].hasOwnProperty(aname)) {
       let a1=assetsUsed['list'][aname];        // appears in portfolio/entryy
       if (a1['entries']>0)  {            // entries  (all portfolios inits and mods)
         let q=confirm('The asset ('+aname+') appears in '+a1['entries']+' portfolios entries. If you remove it, these portfolios will be unusable! Are you sure? ');
         if (!q) return 1;
       }
      }
    }

    let aremoves=$('#assetsTable').data('removes');

    if (aremoves.hasOwnProperty(aname)) {
       erow.css({'opacity':1.0});
       delete aremoves[aname];
    } else {
       aremoves[aname]=1;
       erow.css({'opacity':0.2});
       let aamess='After specifying new assets to add, and existing assets to remove -- click  <button onClick="scrollAssetsTable(this)"><b>Save!</b></button>';
       aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em> <button class="csaveButton" onClick="showAssetTable(this)">reload the assets list </button> <em>without making these changes!</em>';
       $('#assetTablePreview').html(aamess);
    }
    $('#assetsTable').data('removes',aremoves);


}

//===============
// scroll to top of asset  assetsTableOuter
function scrollAssetsTable(athis) {
   let e1=$('#assetsTableOuter');
    e1.animate({scrollTop:0}, 500);

   let e1b=$('#assetsTable');
    e1b.animate({scrollTop:0}, 200);
  return 1  ;
}

//====================
// copy an asset history row   (Add button click_
function copyARowAssetHistory(athis) {
  let ethis=wsurvey.argJquery(athis);
  let etr=ethis.closest('.assetHistoryRow');
  let uStuff1=etr.data('useStuff');
 
  let aname=ethis.attr('data-name');
  let tdate=parseInt(uStuff1['date'])+1 ;
  addARowAssetHistory('copy',false,uStuff1,1,etr,tdate,aname) ;
}

//====================
// remove row  from  asset history,
function removeARowAssetHistory(athis,isNew) {

   let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('tr');

  let aname=ethis.attr('data-name');

   if (isNew==1)  {  // new row, just remove it
      erow.remove();
      return 1;
   }

    let aremovesH=$('#assetHistory1').data('removesHistory');

    let edate=erow.find('[name="assetDateValue"]');
    let jdate=edate.val();
    if (aremovesH.hasOwnProperty(jdate)) {
       erow.css({'opacity':1.0});
       erow.attr('data-remove',0);
       delete aremovesH[jdate];
    } else {
       aremovesH[jdate]=1;
       erow.css({'opacity':0.2});
       erow.attr('data-remove',1);
       let aamess='After specifying new asset history entries, or removing existing entries  -- click  ';
       aamess+='<button onClick="removeARowAssetHistory_scrollSave(1)"><b>Save!</b></button>';
       aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em> ';
       aamess+=' <button  data-name="'+aname+'" class="csaveButton"  data-sayname="'+aname+'"  onClick="showAssetHistory1(this)">reload the asset history </button> <em>(do NOT make these change)</em>';
       $('#assetTableHistoryPreview').html(aamess);
    }
    $('#assetHistory1').data('removesHistory',aremovesH);

}

//=========
function removeARowAssetHistory_scrollSave(ifoo) {
    let e1=$('#iAssetTable');
    e1.animate({scrollTop:0}, 500);

   let e1b=$('#assetHistory1');
    e1b.animate({scrollTop:0}, 200);
  return 1
  
}

//============
// special case show history -- add a new row with a given date. Used when asset needs fixing ( in afterLogon())
// iadd=1 means "add to existing
//  0  measn Create new
function addEmptyRowToAssetHistory(athis,iadd) {
   let ethis=wsurvey.argJquery(athis);
  let daname=ethis.attr('data-name');
  let tryDate=ethis.attr('data-adddate');
  if (iadd==1) {
    showAssetHistory(0,daname);
    addARowAssetHistory('addEmpty',false,{},1,false,tryDate,daname);
  } else {
    showAssetTable(athis);        // athis is not currently used by either of these (8 dec 2023)
    addARowAssets(0,daname) ;     // add a new asset (using this name in the name field)
  }
}


//======================
// show values of assets (history)
function showAssetHistory(athis,use1)   {

  redisplayHeaderLine(1);

  let anames=[],isInit=0;
   if (arguments.length<2) {
     let ethis=wsurvey.argJquery(athis);
     use1=ethis.wsurvey_attr('data-name','*');
     isInit=ethis.attr('data-init');
     if (!jQuery.isNumeric(isInit)) isInit=0;
   }

  let use1Say='';
  let adescs={},saynames={},saytypes={},itypes={} ;
  let gotit=0;
  let nhidden=0;
  for (let daname in assetLookup) {

    let isHidden=doAssetLookup(daname,'isHidden');
    if (isHidden==1) {
       nhidden++;
       continue ;       // don't show hidden assets in compressed list
    }

    anames.push(daname);
    saynames[daname]=doAssetLookup(daname,'sayname');      // note that 'sayname' has any   preceding _  stripped (_ signals 'this is a public asset')
    itypes[daname]=parseInt(doAssetLookup(daname,'assetType'));

    let type1=getAssetType(daname,'icon');

    saytypes[daname]=type1;

    adescs[daname]=doAssetLookup(daname,'desc');

    if (daname==use1) {             // pre selected asset to use
       gotit=1;
       use1Say=doAssetLookup(daname,'sayname');
    }
  }
  let amess='' ;

  amess+='<div style="background-color:tan;font-weight:600">';
  amess+='<button title="Return to list of assets" onClick="showAssetTable(this)"> &#8617;&#65039;</button>  ';
  amess+='&#127803; Date-specific asset attributes (price/interest rate/dividends). ';
  amess+='Click an <button>assetName</button> to view &amp; modify, ';
  amess+=' <button style="background-color:lime">assetName</button> to initialize.';

  amess+='<span style="float:right;margin-right:1em">';
    amess+='<button title="toggle sort the list of assets (date of entry, type, name)" data-which="1" ';    // 1 means "order of entry"
     amess+='  onClick="showAssetHistory_sort(this)" >&rArr; sort</button>';
    amess+='<button title="shrink size of list of assets box "  onClick="showAssetHistory_boxSize(-1)" >&#8648; shrink</button>';   // &#8650;  &ddarr;      &#8648; &upuparrows;
    amess+='<button title="expand size of list of assets box " onClick="showAssetHistory_boxSize(1)" > &#8650;  expand</button>';


  amess+='</span>';

  amess+='</div>';

  amess+='<div style="max-height:7em; overflow:auto" id="showAssetHistory_assetButtons"><ul class="linearMenu22Pct">';
  let say1,aa1,nHistory,adesc,firstEntryDate ;
  for (let i1=0;i1<anames.length;i1++) {
      nHistory=0;
      aa1=anames[i1];
      let sayname1= saynames[aa1] ;
      say1=saytypes[aa1]+' '+sayname1;
      let atype=itypes[aa1];
      adesc=adescs[aa1] ;
      if (!assetHistory.hasOwnProperty(aa1) || assetHistory[aa1]['entries'].length==0 )  {
        nHistory=0;
        firstDateDay='';
      } else {
         nHistory=assetHistory[aa1]['entries'].length;
         let d0=assetHistory[aa1]['entries'][0]['date'];
         let oof=setEntryDate(d0);
         firstEntryDate=oof['sayDate'];
      }
      let isPublic=doAssetLookup(aa1,'isPublic');
      let sayPublic=(isPublic==1) ? '<span title="a public asset">&Pscr;</span> ' : ' ' ;
      if (nHistory>0) {
        amess+='<li>';
        amess+='<input type="button" value="'+say1+'" data-name="'+aa1+'"    data-sayname="'+say1+'"  data-init="0"  name="assetHistoryButton_top" ';
        amess+='  data-type="'+atype+'" data-ith="'+i1+'"  data-sortname="'+sayname1+'" ';
        amess+='  onClick="showAssetHistory1(this)" title="'+adesc+'\nView/set this asset value"> ';
        amess+=sayPublic;
        amess+='<span title="Date of first entry /  # entries " class="cAssetHistoryShow">'+firstEntryDate+' / '+nHistory+' </span>';
        amess+='</li>';
      } else {
        amess+='<li><input type="button" data-init="1" value="'+say1+'" data-name="'+aa1+'"  style="background-color:lime"   data-sayname="'+say1+'"  ';
        amess+='  data-type="'+atype+'" data-ith="'+i1+'"  data-sortname="'+sayname1+'" name="assetHistoryButton_top" '  ;
        amess+='  onClick="showAssetHistory1(this)" title="'+adesc+'\nInitialize this asset value"> (no entries) </li>';
      }
  }
  if (nhidden>0) amess+='<li><em>'+nhidden+'</em> hidden assets not displayed';
  amess+='</ul></div>';

  amess+='<div id="mainDiv3a"></div>';

  $('#mainDiv3').html(amess);

   wsurvey.wsShow.hide('#mainDiv1');
   wsurvey.wsShow.hide('#mainDiv2');

   wsurvey.wsShow.show('#mainDiv','show');
   wsurvey.wsShow.show('#mainDiv3','show');

  let asay='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#assetsTableHelp1">&#10068;</button> &#127803; Create or specify <u>assets</u>    ... '
//  asay+='<button  class="csettingsButton" name="doAssetButton"   title="Compressed view " onClick="showAssetHistory(this)" >&#128476; x vu</button> ';
  asay+='  <button  class="cdoButtonRegular"  id="assetsTableButton" name="doAssetButton" title="Full view"   onClick="showAssetTable(this)">&#10133;</button>';


  hidePortfolioHeader(2,asay);

  if (gotit==1)  {                // display a selected asset (due to a button push)
     showAssetHistory1(1,use1,use1Say,false,false,isInit);
  }

}

//=========
// incrase size of container containg asset history entries
function showAssetHistory_historySizeFix(ifoo,ith) {

  if (arguments.length<2) {
      window.setTimeout(function(){
         showAssetHistory_historySizeFix(1,1)  ;      // resize container to better fit browser window 
      },120);
      return false ;  // wait for dom to settle
  }

    let emain=$('#mainDiv');
     let elist=$('#showAssetHistory_assetButtons');
     let ehist=$('#iAssetTable');
     let hHist=ehist.height();

// tweak history box size
    let qscroll=wsurvey.isScrollable(emain);
    if (!qscroll) {
       return true ;
    }

    let wheight=hHist*0.98,mm2=0;
    for (let mm=0;mm<15;mm++) {
        mm2=mm;
        let size2=parseInt(wheight);
        ehist.height(size2+'px');
        let qscroll2=wsurvey.isScrollable(emain);
        if (!qscroll2) {
          return mm ;
        }
        wheight=wheight*0.98;
    }

    return false ;
}




//=========
// incrase size of container containg clickal asset buttons
function showAssetHistory_boxSize(idire) {
    let elistOuter=$('#showAssetHistory_assetButtons');
    let iheight=parseInt(elistOuter.height());
    let eparent=$('#mainDiv');
    let ipheight=parseInt(eparent.height());
    let fChange=parseInt(idire)*0.1;
    let newHeight= iheight*(1+fChange) ;
    let nh0=newHeight;

    newHeight=Math.max(60,newHeight);
    newHeight=Math.min(ipheight*0.50,newHeight);
    newHeight=parseInt(newHeight);

    elistOuter.height(newHeight+'px');
    elistOuter.css({'max-height':newHeight+'px'});
    

}

//===========
// sort the list of asset buttons (in the linear list of asset buttons
function showAssetHistory_sort(athis) {
     let ethis1=wsurvey.argJquery(athis) ;
     let nowSort=parseInt(ethis1.attr('data-which'));
     nowSort= (nowSort<3) ? nowSort+1 : 1 ;
     ethis1.attr('data-which',nowSort);

     let sortons=[0,'data-ith','data-sortname','data-type'];
     let sorthow=[0,'Order of entry','Asset name','Asset type'];

     let elistOuter=$('#showAssetHistory_assetButtons');
     let ebuttons=elistOuter.find('[name="assetHistoryButton_top"]');
     let doem=[];
    let ause=sortons[nowSort];
     let sortHow1=sorthow[nowSort];

     for (let ii=0;ii<ebuttons.length;ii++) {
         let abutton=$(ebuttons[ii]);
         let aname=abutton.attr('data-name');
         let sorton=abutton.attr(ause);
         let tt=[sorton,ii,aname];
         doem.push(tt);
     }
     doem.sort(showAssetHistory_sort1)


// could sort dom elements, but "collections" can yields wierd stuff when re-arranged (8 dec 2023 probably should figure it out)
     let stuff1= '<ul class="linearMenu22Pct" title="Sorted by: '+sortHow1+'" >';
     for (let ii=0;ii<doem.length;ii++) {
        let juse=doem[ii][1];
        let abutton=$(ebuttons[juse]);
        let eli=abutton.closest('li');
        let buse=eli.prop('outerHTML');

        stuff1+=buse;
     }
     stuff1+='</ul>';

     elistOuter.html(stuff1) ;

}

function showAssetHistory_sort1(a0,b0) {  // this does the sorting (on first element of 3 element array entries

  let a=a0[0],b=b0[0];

   if (!jQuery.isNumeric(a) || !jQuery.isNumeric(b)) {  // one or both not numbers
       if (jQuery.isNumeric(a)) return 1 ;     // just b is nonnumeric, so b should  be before a
       if (jQuery.isNumeric(b)) return -1 ;   // just a is nonnumeric, so a should  be before b
       if (a>b) return  1;
       if (a==b) return 0;
       return -1 ;
   }
   let a1=parseFloat(a);  // both are numbers
   let b1=parseFloat(b);
   return a1 - b1;

  }


//===========
// show asset value history  --  a chosen asset
function showAssetHistory1(athis,aname,sayName,ahistory,adesc,isInit) {

   if (arguments.length==1)  {
     let ethis=wsurvey.argJquery(athis);
     aname=ethis.attr('data-name');
     isInit=ethis.attr('data-init');
   }  else {
      if (arguments.length<6) isInit=0;
   }
   if (arguments.length<4 || ahistory===false) {
      ahistory= (assetHistory.hasOwnProperty(aname)) ? assetHistory[aname]: []  ;
   }

   let autoAddEntries=0;
   let autoAddChecked=' ',autoAddWas=0,taxFreeFrac=0,nImputed ;

   let aIcon=getAssetType(aname,'icon');
   let sayAsset=getAssetType(aname,1);
   let assetType=getAssetType(aname);
   taxFreeFrac=doAssetLookup(aname,'taxFreeFrac',1);
   if (taxFreeFrac===false || taxFreeFrac=='false') taxFreeFrac=0;

   nImputed=doAssetLookup(aname,'nImputed',1);

   if (arguments.length<3 || sayName===false) sayName=doAssetLookup(aname,'sayname');

   if (arguments.length<4 || adesc===false) {
      autoAddEntries=doAssetLookup(aname,'autoAddEntries');
      autoAddChecked=' ',autoAddWas=0 ;
      if (autoAddEntries==1)  {
        autoAddChecked=' checked ' ;
        autoAddWas=1;
     }
     adesc=doAssetLookup(aname,'desc');

   }      // arguemnets < 4


  let amess='';

  let taxFreeFracSay =(100.0*taxFreeFrac).toFixed(1);

// info bar
  let attMess=aIcon+' <b>'+aname+'</b>: <em>'+adesc+'</em> |  %TaxFree= '+taxFreeFracSay+'%'   ;
  attMess+=' | #imputed= '+nImputed;

   amess+='<div id="assetTableHistoryBasics" title="asset attributes" style="display:block" class="cassetTableHistoryPreview  "> '+attMess+'</div> ';

   amess+='<div id="assetTableHistoryPreview" class="cassetTableHistoryPreview"></div> ';
   amess+='<div class="cassetsTable" id="iAssetTable" name="nAssetTable">';
  amess+='<table  border="1" id="assetHistory1" width="97%"  >';
  amess+='<tr class="headerRow">';

  amess+='<td width="16%" >   ';
    amess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#showAssetHistoryHelp1">&#10068;</button> ';
   amess+='<input type="button" value="&neArr;" title="View assetHistory in a new window"  data-id="mainDiv3a" onClick="displayInWindow(this)"> ';
    amess+='  <button name="addRowToHistory" class="cdoButtonTan" title="Click to add a new row"   data-type="'+assetType+'"data-name="'+aname+'" onClick="addARowAssetHistory(0,this)">Add</button>';
   if (isInit==1)   amess+=' <button  title="Copy the history of an existing asset " data-name="'+aname+'" onClick="copyAsset(this)">Copy</button>';
    amess+=' <button class="csaveButton" title="Save this asset history  " data-name="'+aname+'" onClick="saveAssetHistory(this)">Save!</button>';

    amess+='<span >';
    amess+='<button class="csaveButtonSmall" style="float:right;margin-right:3px" title="Toggle view of asset atributes, and `what to do`, lines" ';
    amess+='     data-name="'+aname+'" onClick="$(\'.cassetTableHistoryPreview\').toggle()">&#9673;</button>';
    amess=='</span>';

  amess+='</td>';

  amess+='<td width="20%" > '
    amess+='<span   title="'+adesc+'" class="choiceNameSay">'+aIcon+' <u>'+sayName+'</u> </em></span> ';
    if (assetType==1 || assetType==3 || assetType==4 || assetType==5 || assetType==6) {
        let atmp=(taxFreeFrac===false || taxFreeFrac==='false') ?  0.0 : taxFreeFrac ;
        amess+='<span title="The tax free fraction (0.0: fully taxed, 1.0: not taxed"  class="ctaxFreeFrac">'+atmp+'</span> ';
    }
    if ( assetType==7) {
        let atmp=(taxFreeFrac===false || taxFreeFrac==='false') ?  0.0 : taxFreeFrac ;
        amess+='<span title="The tax offset fraction (0.0: no offset, 1.0: expense can be deducted from taxable"  class="ctaxFreeFrac">'+atmp+'</span> ';
    }


  amess+='</td>';

// Header row: fields in this col depend on assettype
  let amess1='missing assetType';

  if (assetType==0)  {              // stock: price and dividend.    basis is set on a portfolio specific bais
    amess1='<input type="button" title="notes ... " value="&#119137;" onclick="showAssetHistory1_showHeaderNote(this)"> ';
    amess1+='<span class="cshowAssetHistory1_afieldHdr" title="Share price">Price</span> ';
    amess1+='<span class="cshowAssetHistory1_afieldHdr" title="Dividend (dollars per year)">Dividend</span> ';

    amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  adjusting `price` and `dividend` using inflation">';
      amess1+='<input  type="checkbox" '+autoAddChecked+'  name="autoAddEntries" data-was="'+autoAddWas+'" value="1" > autoAdd?';
    amess1+='</label></span>';

    amess1+='<div name="showAssetHistory1_headerNote" style="font-size:80%;display:none;padding:3px 3px">';
    amess1+='  <u>price</u> is per share sale price on this date: what you pay to obtain a share of the stock, or would receive if you sold a share.';
    amess1+='<br><u>Dividend</u> is yearly dividends (pre-tax). It can <u>not</u> be negative.';
    amess1+=' <br><u>autoAdd</u>: if checked, simInv will add yearly entries; for every year after the final entry you specify.';
    amess1+=' These autoAdd values are calculated using an average inflation rate. ';
    amess1+='</div>';

  } else if (assetType==1) {        // bond reguar       taxFreeFrac set when asset created
    amess1='<input type="button" title="notes ... " value="&#119137;" onclick="showAssetHistory1_showHeaderNote(this)"> ';
    amess1+='<span class="cshowAssetHistory1_afieldHdr" title="Interest rate (per year, as a percent). Example: 5=5%  ">Interest</span> ';

    amess1+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=interest earnings are tax free)">taxFreeFrac</span>';

    amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  using interest rate that are relative to inflation">';
      amess1+='<input  type="checkbox" '+autoAddChecked+'  name="autoAddEntries" data-was="'+autoAddWas+'" value="1" > autoAdd?';
    amess1+='</label></span>';

    
    amess1+='<div name="showAssetHistory1_headerNote" style="font-size:80%;display:none;padding:3px 3px">';
    amess1+='<u>Interest</u>: the year interest rate earned by this bond. For example: <tt>3.6</tt> = 3.6%/year.';
    amess1+=' <br>the <u>taxFreeFrac</u> is specified when the asset is created (you can not change it here). It is the fraction of earnings <u>not</u> subject to taxation.';
    amess1+=' <br><u>autoAdd</u>: if checked, simInv will add yearly entries; for every year after the final entry you specify.';
    amess1+=' autoAdd interest rates use future yearly inflation rates to calculate a nomimal rate equivalent to the asset\'s real rate (as of the last entry). ';
    amess1+='<br>autoAdd can be useful if a scenario specifies future inflation rates, and the asset\'s real interest rate is constant' ;
    amess1+='</div>';


  } else if (assetType==2) {          // tax deferred
    amess1='<input type="button" title="notes ... " value="&#119137;" onclick="showAssetHistory1_showHeaderNote(this)"> ';
    amess1+='<span class="cshowAssetHistory1_afieldHdr" title="Interest rate (per year, as a percent). Example: 5=5%\nReminder: interest earnings are tax deferred">Interest</span>';

    amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  using interest rate that are relative to inflation">';
      amess1+='<input  type="checkbox" '+autoAddChecked+'  name="autoAddEntries" data-was="'+autoAddWas+'" value="1" > autoAdd?';
    amess1+='</label></span>';


    amess1+='<div name="showAssetHistory1_headerNote" style="font-size:80%;display:none;padding:3px 3px">';
    amess1+='<u>Interest</u>: the year interest rate earned by this tax-deferred bond. For example: <tt>4.2</tt> = 4.2%/year.';
    amess1+=' <br><u>autoAdd</u>: if checked, simInv will add yearly entries; for every year after the final entry you specify.';
    amess1+=' autoAdd interest rates use future yearly inflation rates to calculate a nomimal rate equivalent to the asset\'s real rate (as of the last entry). ';
    amess1+='<br>autoAdd can be useful if a scenario specifies future inflation rates, and the asset\'s real interest rate is constant' ;
    amess1+='</div>';


  } else if (assetType==3) {          // property
    amess1='<input type="button" title="notes ... " value="&#119137;" onclick="showAssetHistory1_showHeaderNote(this)"> ';

    amess1+='<span class="cshowAssetHistory1_afieldHdr2" title="Sales price">salePrice</span> ';
    amess1+='<span class="cshowAssetHistory1_afieldHdr2" title="Rent (earnings - costs), dollars per year)">$Rent/yr</span> ';
    amess1+='<span class="cshowAssetHistory1_afieldHdr2" title="Cost when asset is sold">saleCost</span> ';

    amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  adjusting `price` and `rent` using inflation"  >';
      amess1+='<input  type="checkbox" title="Add entries after the final (one per year, with values increasing at CPI)"  ';
      amess1+= autoAddChecked+'  data-was="'+autoAddWas+'" name="autoAddEntries" value="1" >autoAdd? ';
    amess1+='</label></span>';

    amess1+='<div name="showAssetHistory1_headerNote" style="font-size:80%;display:none;padding:3px 3px">';
    amess1+='<u>Property</u>: price is sale price of this property on this date: what you pay to obtain the property, or would receive if you sold it.';
    amess1+='You can use <tt>xxxK</tt> for <tt>xxx,000</tt> ';
    amess1+='<br><u>Rent/tr</u> is yearly revenues minus yearly costs -- it can be negative! Costs should not include mortgage payments -- ';
    amess1+=' instead, specify a mortgage when you add the property to a portfolio';
    amess1+='<br><u>saleCost</u> is the cost of selling the property. It is removed from the salePrice before the proceeds are added to <u>Cash</u>.';
    amess1+=' However, they do <u>not</u> reduce capital gains. ';
     amess1+=' <br><u>autoAdd</u>: if checked, simInv will add yearly entries; for every year after the final entry you specify.';
    amess1+=' These autoAdd values are calculated using an average inflation rate. ';
    amess1+='</div>';


  } else if (assetType==4) {          // income
    amess1='<input type="button" title="notes ... " value="&#119137;" onclick="showAssetHistory1_showHeaderNote(this)"> ';
    amess1+='<span class="cshowAssetHistory1_afieldHdr" title="Yearly income (pre tax). Dollars per year">income</span> ';
       amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  estimate future income "  >';
      amess1+='<input  type="checkbox" title="Add entries after the final (one per year, with values increasing at CPI)"  ';
      amess1+= autoAddChecked+'  data-was="'+autoAddWas+'" name="autoAddEntries" value="1" >autoAdd? ';
    amess1+='</label></span>';

    amess1+='<div name="showAssetHistory1_headerNote" style="font-size:80%;display:none;padding:3px 3px">';
    amess1+='<u>Income</u>: in pre-tax dollars per year. You can use <tt>xxK</tt> for <tt>xx,000</tt>. Negative values are <u>not</u> allowed. ';
    amess1+=' <br><u>autoAdd</u>: if checked, simInv will add yearly entries; for every year after the final entry you specify.';
    amess1+=' These autoAdd values are calculated using an average inflation rate. ';
    amess1+='</div>';


  } else if (assetType==5) {          // annuity
    amess1='<input type="button" title="notes ... " value="&#119137;" onclick="showAssetHistory1_showHeaderNote(this)"> ';
    amess1+='<span class="cshowAssetHistory1_afieldHdr" title="Yearly annuity income (pre tax). Dollars per year">annuity <span style="font-size:70%">(pre-tax $/year)</span></span> ';
    amess1+='<span class="cshowAssetHistory1_afield2Hdr" title="The per year growth rate -- as a fraction of inflation (of the value on acquisition date)">Growth ';
    amess1+='<input  type="hidden"  name="autoAddEntries" value="0" >  ';
    amess1+='<span style="font-size:70%">(fraction of inflation ) </span>';
    amess1+='</span> ';

    amess1+='<div name="showAssetHistory1_headerNote" style="font-size:80%;display:none;padding:3px 3px">';
    amess1+='<u>Annuity</u>: annuity income in pre-tax dollars per year. You can use <tt>xxK</tt> for <tt>xx,000</tt>. Negative values are <u>not</u> allowed. ';
    amess1+=' <br><u>Growth</u> is the yearly growth as a fraction of yearly inflation. Example: <tt>0.75</tt> = 75% of inflation';
    amess1+='<br>There is <u>no</u> autoAdd attribute for annuities -- <u>growth</u> is used instead!';

    amess1+='</div>';

  } else if (assetType==6) {          // oneOff
    amess1='<input type="button" title="notes ... " value="&#119137;" onclick="showAssetHistory1_showHeaderNote(this)"> ';
    amess1+='<span class="cshowAssetHistory1_afieldHdr" title="oneOff receipt (income or cost), in dollars">oneOff</span> ';

    amess1+='<div name="showAssetHistory1_headerNote" style="font-size:80%;display:none;padding:3px 3px">';
    amess1+='<u>oneOff</u>: the after-tax receipts delivered from this oneOff asset (on this date). For example, an inheritance.';
    amess1+='<br> If negative, the cost of obtaining this oneOff asset. For example, purchasing new kitchen cabinets. ';
    amess1+='<br>There is <u>no</u> autoAdd attribute for oneOffs.' ;
    amess1+='</div>';

  } else if (assetType==7) {          // expense
    amess1='<input type="button" title="notes ... " value="&#119137;" onclick="showAssetHistory1_showHeaderNote(this)"> ';

    amess1+='<span class="cshowAssetHistory1_afieldHdr" title="Yearly expense (pre tax). Dollars per year">expense</span> ';
    amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  estimate future expense  "  >';
      amess1+='<input  type="checkbox" title="Add entries after the final (one per year, with values increasing at CPI)"  ';
      amess1+= autoAddChecked+'  data-was="'+autoAddWas+'" name="autoAddEntries" value="1" >autoAdd? ';
    amess1+='</label></span>';

    amess1+='<div name="showAssetHistory1_headerNote" style="font-size:80%;display:none;padding:3px 3px">';
    amess1+='<u>Expense</u>: in pre-tax dollars per year. You can use <tt>xxK</tt> for <tt>xx,000</tt>. Negative values are <u>not</u> allowed. ';
    amess1+=' <br><u>autoAdd</u>: if checked, simInv will add yearly entries; for every year after the final entry you specify.';
    amess1+=' These autoAdd values are calculated using an average inflation rate. ';
    amess1+='</div>';

  }         // assetType

  amess+='<td width="45%"><div class="cshowAssetHistory1_showHeaderNote">'+amess1+'</div></td>';

  amess+='<th width="24%"  > <span title="Comment">Comment </span>';
  amess+='<div style="font-weight:500;color:blue;display:none" id="assetHistory1_comment_a"></div>';
  amess+='</th>';
  amess+='</tr>';

  let useStuffs={};

  for (let a1=0;a1<ahistory['entries'].length;a1++) {
    let anasset=ahistory['entries'][a1];

    let adate=parseInt(anasset['date'])   ;

    amess+='<tr class="assetHistoryRow"  data-which_hist="'+a1+'" data-date="'+adate+'"  data-remove="0"   >';
    amess+='<td><span class="cNameSay">';
    amess+='<input type="button" data-name="'+aname+'" value="Copy" title="Copy this row " onClick="copyARowAssetHistory(this,0)"> ';
    amess+='<input type="button" data-name="'+aname+'" value="Remove" onClick="removeARowAssetHistory(this,0)">';

    amess+='</span></td>';
    amess+='<td>';

    let oof=setEntryDate(adate);
    let jyear=oof['year'];
    let jday=oof['day'];
    let jmonth=oof['month'];
    let jmonth3=oof['month3'];

     amess+='<input type="hidden"  name="assetDateValue" value="'+adate+'"> ';
     amess+='<span name="assetDateYearSet"  title="Day count='+adate+'" >'+jyear+'</span> / ';
     amess+='<span name="assetDateMonthSet"  >'+jmonth3 +'</span> / ';
     amess+='<span name="assetDateDaySet"  >'+jday+'</span>';
    amess+='</span>';
    amess+='</td>';

    let  useStuff=anasset;
    useStuff['name']=aname;
    useStuff['year']=jyear;
    useStuff['month']=oof['month'];
    useStuff['day']=jday;
    useStuffs[a1]=useStuff;

    let arow= addARowAssetHistory('exist',false,useStuff);  // add this row to the asset history table (with unchangeable values, but user can remov/add rows

    arow+='<td width="26%"><span name="fs"><div style="font-size:80%;color:blue;max-height:2.4em;overflow:auto">'+anasset['comment']+'</div></td>';

    amess+=arow+'</tr>';
  }      //  a1=0;a1<ahistory['entries']

  amess+='</table>';
    amess+='<div style="margin-top:2px;font-size:80%;opacity:0.66;color:#0057ff;padding-left:10em"> ... '+aname+' history ... </div>';
  amess+='</div>';


  let emain=  $('#mainDiv3a');
  emain.html(amess);

  let ehist=$('#assetHistory1');
  let etrs2=ehist.find('[data-which_hist]');

  for (let iee=0;iee<etrs2.length;iee++) {
     let aetr2=$(etrs2[iee]);
     let j1=aetr2.attr('data-which_hist');
     let u1=useStuffs[j1];
     aetr2.data('useStuff', u1);
  }

  $('#assetHistory1').data('removesHistory',{});  // reset every time table is displayed

   wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.show('#mainDiv3','show');


// size to fit...
  showAssetHistory_historySizeFix(1) ;


}

//==========
// toggle dipsplay of "header notes"
function  showAssetHistory1_showHeaderNote(athis) {
   let ethis=wsurvey.argJquery(athis);
   let etd=ethis.closest('.cshowAssetHistory1_showHeaderNote');
   let enote=etd.find('[name="showAssetHistory1_headerNote"]');
   if (enote.is(':visible')) {
       enote.hide();
   } else {
     enote.show();
   }
}


//=================
// quick calculate of value of new row (given prior row value)
function  showAssetHistory1_calcNew(athis) {
   let ethis=wsurvey.argJquery(athis);

   let etable=ethis.closest('#assetHistory1');
   let aetr=ethis.closest('.assetHistoryRow');

   let myDate=showAssetHistory1_calcNew_date(aetr);
   if (myDate<0)  {  // an error
     let derrs=['','Bad year','Bad month','Bad day','Bad overall date'];
     let aerr=derrs[Math.abs(myDate)];
     alert('The date of this entry is misspecified: '+aerr);
     return 0;
   }

// date of this row... if  any field is missing or bad, give up


// find closest entry (by date) that is before myDate
   let etrs=etable.find('.assetHistoryRow');
   let useDiff=1111111111111111,priorDate=false,priorVal ;

   for (let iie=0;iie<etrs.length;iie++) {
      let aetr1=$(etrs[iie]);
      let adate=showAssetHistory1_calcNew_date(aetr1);
      if (adate===false ) continue ;                  // no, or bad, date. .. ignore
      if (adate>=myDate) continue ;                    // after, or same date... skip
      let bdiff=myDate-adate;
      if (bdiff<useDiff) {
         let etrx=aetr1.closest('.assetHistoryRow');
         let evv=etrx.find('[name="assetIncome"]');
         if (evv.length==1) {                    // got an income field
             let cval=evv.val();
             cval=jQuery.trim(cval);
             cval=fixString(cval,1); 
             if (!jQuery.isNumeric(cval))  continue  ; // nope, not valid. Skip
             useDiff=bdiff;
             priorDate=adate;
             priorVal=parseFloat(cval) ;
          }   // evv.length
      }     // bdiff<useDiff
   }
   if (priorDate===false) {
       alert('No entry before this date ');
       return 0;   // could not find a prior entry ... give up
   }
   let   daInf= calcInflation(priorDate,myDate) ;    // cpi factor
   
   let oof1=setEntryDate(myDate);
   let oof2=setEntryDate(priorDate);

   let damess=oof1.sayDate+': <tt>'+useDiff+'</tt> days after '+oof2.sayDate+', with value=<tt>'+priorVal.toFixed(0)+'</tt><br>';

   damess+='<div name="showAssetHistory1_calcNew_s0">';
   damess+='<ul  class="boxList">';
   let valInf=priorVal*daInf;

   let tmp1=Math.log(1.08)/365 ;
   let gg1=Math.exp(tmp1) ;
   let fact1=Math.pow(gg1,useDiff);
   let val8=fact1*priorVal;

   damess+='<li>Inflation growth ('+daInf.toFixed(3)+ ') = <span name="showAssetHistory1_calcNew_inflation" style="font-family:monospace">'+valInf.toFixed(0)+'</span>';
   damess+=' <button data-which="showAssetHistory1_calcNew_inflation" title="copy this value to clipboard" onClick="showAssetHistory1_calcNew_clipboard(this)">&#169;&#65039;</button> ';

   damess+='<li>@8%/year growth ('+fact1.toFixed(3)+ ') =  <span name="showAssetHistory1_calcNew_8pct" style="font-family:monospace"><tt>'+val8.toFixed(0)+'</span>';
   damess+=' <button data-which="showAssetHistory1_calcNew_8pct" title="copy this value to clipboard" onClick="showAssetHistory1_calcNew_clipboard(this)">&#169;&#65039;</button>  ';

   damess+='<li>Custom early growth <input type="text" value="1.040" name="showAssetHistory1_calcNew_user" ';
   damess+=' title="Enter a yearly growth rate\n Example: 1.15 = 15% yearly growth"> ';
   damess+=' <button title="calculate value using this yearly growth rate"   ';
   damess+='   data-usediff="'+useDiff+'" data-priorval="'+priorVal+'" onclick="showAssetHistory1_calcNew_fromUser(this)">Calculate .. </button>';
   damess+='<li>(<span name="showAssetHistory1_calcNew_s1"> </span>) = <span style="font-family:monospace" name="showAssetHistory1_calcNew_s2"> </span>  ';
   damess+=' <button data-which="showAssetHistory1_calcNew_s2" title="copy this value to clipboard" onClick="showAssetHistory1_calcNew_clipboard(this)">&#169;&#65039;</button>  ';

   damess+='</ul>';
   damess+='</div>'

// showAssetHistory1_calcNew_inflation showAssetHistory1_calcNew_8pct showAssetHistory1_calcNew_s2
   displayStatusMessage(damess);
   toggleStatusDiv(0,5);

   return 1;


// convert y/m/d input fields into a dayCount -- or false if bad entry
  function  showAssetHistory1_calcNew_date(aetr) {

    let mdate=aetr.attr('data-date');
    if (jQuery.isNumeric(mdate)) return mdate  ;      // old row... compare to myDate

    let aeek= wsurvey.dateBox_read(aetr,1) ;

    if (aeek===false || !jQuery.isPlainObject(aeek)) return -3 ;

    let oof=setEntryDate(aeek.year,aeek.month,aeek.day,1);
    if (oof===false) return -4;
    mdate=oof.dayCount ;
    return mdate;

  }     // showAssetHistory1_calcNew_date

}

//  calculate value with user supplied yearly growth rate
function showAssetHistory1_calcNew_fromUser(athis) {
     let ethis1=wsurvey.argJquery(athis);
     let priorVal=parseFloat(ethis1.attr('data-priorval'));
     let useDiff=parseFloat(ethis1.attr('data-usediff'));
     let ediv=ethis1.closest('[name="showAssetHistory1_calcNew_s0"]');

     let euser=ediv.find('[name="showAssetHistory1_calcNew_user"]');
     let esay1=ediv.find('[name="showAssetHistory1_calcNew_s1"]');
     let esay2=ediv.find('[name="showAssetHistory1_calcNew_s2"]');
     let gval=euser.val();

     if (!jQuery.isNumeric(gval) || gval<0.0 ) {
         esay1.html('Not a +  number (please reenter)')  ; // bad value
         return 0;
     }

     let tmp2=Math.log(gval)/365 ;
     let gg2=Math.exp(tmp2) ;
     let fact2=Math.pow(gg2,useDiff);
     esay1.html(fact2.toFixed(3))  ;
     let val8b=fact2*priorVal;
     esay2.html(val8b.toFixed(0));
     return 1;

}         // showAssetHistory1_calcNew2

//==========
// copy a value to clipboard
function  showAssetHistory1_calcNew_clipboard(athis) {
   let ethis=wsurvey.argJquery(athis);
   let awhich=ethis.attr('data-which');
   let eli=ethis.closest('li');

   let earf=eli.find('[name="'+awhich+'"]');
   if (earf.length!=1) return 0;
   let astuff=earf.text();

   navigator.clipboard.writeText(astuff).then(
    () => {
        ethis.addClass('cClipboardOkay');
        },
    () => {
          // clipboard write failed
       }
  );   // then

  return 1;
  }

//=================
// add a row to the history of a particluar asset
// either called by Add button, or from copyAsset1
// 2 march 2024 : forceAdd is deprecated (how='exist' is used instead)
function addARowAssetHistory(how,athis,useStuff,forceAdd,addAfter,useThisDate,useName1) {

   if (arguments.length<5) useThisDate=true;    // date to use (true means "use current date"
     if (arguments.length<4) addAfter=false;
     if (arguments.length<3) forceAdd=false;

    let amess='',aname,isExist=0,isReadonly='' ;

    let minDate=wsurvey.validateDate(simInvGlobals['theMinYear'] ,1,1).value;
    let maxDate=wsurvey.validateDate(simInvGlobals['theMaxYear'],12,31).value

    let oof=setEntryDate(useThisDate);
    let jyear=oof['year'];
    let jday=oof['day'];
    let jmonth=oof['month'];
    let jmonth3=oof['month3'];

    if (how==0) {               // add New row (button push)
        isExist=0 ;
        let ethis=wsurvey.argJquery(athis);
        aname=ethis.attr('data-name');
        useStuff={};
        useStuff={'assetPrice':'','assetInterest':'','assetDividend':'','assetNetRent':'','assetAddition':'',
                     'assetSalePrice':'','assetIncome':'','assetOneOff':'','assetExpense':'','comment':'',
                      'assetIncomeGrowth':0,'assetSaleCost':''};
        let oof=setEntryDate(true);
        useStuff['year']=oof['year'];
        useStuff['day']=oof['day'];
        useStuff['month']=oof['month'];

    } else if (how=='addEmpty') {
        isExist=0 ;
        useStuff={'assetPrice':'','assetInterest':'','assetDividend':'','assetNetRent':'','assetAddition':'',
                     'assetSalePrice':'','assetIncome':'','assetOneOff':'','assetExpense':'','comment':'',
                     'assetIncomeGrowth':0,'assetSaleCost':''};
        let oof=setEntryDate(useThisDate);
        useStuff['year']=oof['year'];
        useStuff['day']=oof['day'];
        useStuff['month']=oof['month'];
        aname=useName1 ;

   } else if (how=='copy') {         // use the "row to be copied" attributes
        isExist=1 ;
        let oof=setEntryDate(useThisDate);         // use suggested date (typically one day after date being copies)
        useStuff['year']=oof['year'];
        useStuff['day']=oof['day'];
        useStuff['month']=oof['month'];
        aname=useName1 ;

    } else if (how=='exist') {

        isExist=1;
        aname=useStuff['name'];
        isReadonly=' readonly  style="opacity:0.6" ';

    }  else {
       alert('unknown how ('+how+') in  addARowAssetHistory');
       return false;
    }

    let  assetType=getAssetType(aname);

//    if (isExist==0 || forceAdd==1) {
     if (how!='exist')   {         // creating full row (not adding cols to an existing tr )
       amess+='<tr class="assetHistoryRow assetHistoryRowNew"  >';

       amess+='<td><input type="button" value="Remove row ... " onClick="removeARowAssetHistory(this,1)"></span>';
       if (assetType==5) {          // calc tool for annuities!
         amess+='<span style="float:right;margin-right:0.5em"><input type="button" data-name="'+aname+'" value="&#129518;" title="Tool: calculate value (by growing prior value at a specified rate)" ';
         amess+='  onClick="showAssetHistory1_calcNew(this)"></span>';
       }

       amess+='</td>';

       amess+='<td> ';

       dopts={'minDate':minDate,'maxDate':maxDate,'compress':2,'month3':2};
       let dstring=wsurvey.dateBox_make(jyear,jmonth,jday,dopts);

       amess+='<span name="assetAdd_date">';
       amess+=dstring;
       amess+='</span>';

       amess+='</td>';
    }    //

    let amess1;
    if (assetType==0)   { // stock
      amess1='<span class="cshowAssetHistory1_afield">Price: ';
      amess1+=' <input '+isReadonly+' type="text" name="assetPrice"  value="'+useStuff['assetPrice']+'" size="5"   title="Price per `share` (in $)." >';
      amess1+='</span>';
      amess1+='<span class="cshowAssetHistory1_afield">Dividend: ';
      amess1+=' <input '+isReadonly+' type="text" name="assetDividend"  value="'+useStuff['assetDividend']+'" size="3.5" title="Yearly dividend per `share` (in $)."   >';
      amess1+='</span>' ;

    } else if (assetType==1) {          //regular bond
      amess1='<span class="cshowAssetHistory1_afield">Interest: ';
      amess1+='  <input '+isReadonly+' type="text" name="assetInterest"  value="'+useStuff['assetInterest']+'" size="5"  ';
      amess1+='      title="Yearly interest rate per `share`, as percent.\nExample: 4.0 for 4% growth per year"   >';
      amess1+='</span>';

      let tta=doAssetLookup(aname,'taxFreeFrac',1).toFixed(3);
      amess1+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=interest earnings are tax free)">'+tta+'</span>';

    } else if (assetType==2) {          //tax deferred bond
      amess1='<span class="cshowAssetHistory1_afield">Interest: ';
      amess1+=' <input '+isReadonly+' type="text" name="assetInterest"  value="'+useStuff['assetInterest']+'" size="5" ';
      amess1+='     title="Yearly (tax free) interest rate per `share`" >';
      amess1+='</span>';


    } else if (assetType==3) {          // property
      amess1='';

       amess1='<button style="font-size:85%" onClick="specifyLoanSchedule(this)" data-aname="'+aname+'" class="cdoButton" title="View a loan worksheet">Loan?</button> ';
       amess1+='<span class="cshowAssetHistory1_afield">Price: ';
         let sspr=useStuff['assetSalePrice'] ;
         ssprSay= (jQuery.isNumeric(sspr))  ? sspr.toFixed(0) : 0 ;
         amess1+='<input '+isReadonly+' type="text" name="assetSalePrice"  value="'+ssprSay+'" size="6" title="Purchase price of property"   >';
         amess1+='<input type="button" class="smallButton" value="k" title="Convert k to 1000. Eg: 5.1k becomes 5100"  data-namefind="assetSalePrice"  onclick="convertKto1000(this)"> ';
       amess1+='</span>';
       amess1+='<span class="cshowAssetHistory1_afield"  title="Yearly net rent (earnings - costs). Typically does NOT include mortgage payments. Can be negative">Rent: ';
         let nnr=useStuff['assetNetRent'] ;
         let nnrSay = (jQuery.isNumeric(nnr)) ?  nnr.toFixed(0) : 0 ;
         amess1+='<input  '+isReadonly+'  type="text" name="assetNetRent"  value="'+nnrSay+'" size="6" > ';
         amess1+='<input type="button" class="smallButton" value="k" title="Convert k to 1000. Eg: 15 becomes 15000"  data-namefind="assetNetRent"  onclick="convertKto1000(this)"> ';
       amess1+='</span>';
       amess1+='<span class="cshowAssetHistory1_afield"  style="font-size:80%" title="Cost when sold (deducted from `Cash`)">saleCost:';
         let tss=useStuff['assetSaleCost'];
         let tssSay=(jQuery.isNumeric(tss)) ?  tss.toFixed(0) : 0 ;
         amess1+='<input  style="font-size:90%" '+isReadonly+'  type="text" name="assetSaleCost"  value="'+tssSay+'" size="5" > ';
         amess1+='<input type="button" class="smallButton" value="k" title="Convert k to 1000. Eg: 15 becomes 15000"  data-namefind="assetSaleCost"  onclick="convertKto1000(this)"> ';
       amess1+='</span>';


    } else if (assetType==4) {          // income stream
       let aGrowth=0;

       amess1='<span class="cshowAssetHistory1_afield">Income: ';
       amess1+='<input '+isReadonly+' type="text" name="assetIncome"  value="'+useStuff['assetIncome']+'" size="6" title="Yearly income  (i.e; from a part time job)" >';
       amess1+='<input type="button" class="smallButton" value="k" title="Convert k to 1000. Eg: 15 becomes 15000"  data-namefind="assetIncome"  onclick="convertKto1000(this)"> ';

       amess1+='</span>';


    } else if (assetType==5) {          // annuity
         let aGrowth=(useStuff.hasOwnProperty('assetIncomeGrowth')) ?  useStuff['assetIncomeGrowth'] : 0 ;
         amess1='<span class="cshowAssetHistory1_afield">Annuity: ';
         amess1+=' <input '+isReadonly+'   type="text" name="assetIncome"  value="'+useStuff['assetIncome']+'" size="6" ';
         amess1+='      title="Yearly annuity (i.e; from social security)" >';
         amess1+='<input type="button" class="smallButton" value="k" title="Convert k to 1000. Eg: 15 becomes 15000"  data-namefind="assetIncome"  onclick="convertKto1000(this)"> ';

         amess1+='</span>';

         if (isExist==0) {
            amess1+='<span class="cshowAssetHistory1_afield">Growth...: ';
            amess1+=' <input '+isReadonly+'   type="text" name="assetIncomeGrowth"   size="3"  value="" ';
            amess1+='    title="Growth rate of `value on acquisition date` annuity, as a fraction of inflation  (i.e; social security COLA adjustments).';
            amess1+='   \n For example: 1.0 for `keep up with inflation`"  >';
            amess1+='<span style="font-size:70%">(fraction of inflation) </span>';
            amess1+='</span>';


         } else {
            amess1+='<span class="cshowAssetHistory1_afield">Growth: ';
            amess1+='<input '+isReadonly+'   type="text" name="assetIncomeGrowth"   value="'+aGrowth+'"   size="3" ';
            amess1+='  title="Growth rate of annuity (i.e; social security COLA adjustments). For example: 0.66 for 2/3 of inflation"   >';
            amess1+='</span>';
           }


    } else if (assetType==6) {          // oneOff receipt
       let aGrowth=0;
       amess1='<span class="cshowAssetHistory1_afield">oneOff: ';
       amess1+='<input '+isReadonly+'   type="text" name="assetOneOff"  value="'+useStuff['assetOneOff']+'" size="6"  ';
       amess1+='   title="oneOff receipt (i.e; positive for an inheritance; negative for a large purchase )" >';
       amess1+='</span>';


    } else if (assetType==7) {          // expenase stream
       let aGrowth=0;
       amess1='<span class="cshowAssetHistory1_afield">Expense: ';
       amess1+=' <input '+isReadonly+'   type="text" name="assetExpense"  value="'+useStuff['assetExpense']+'" size="6" title="Yearly expense  (i.e; summer vacations)">';
       amess1+='<input type="button" class="smallButton" value="k" title="Convert k to 1000. Eg: 15 becomes 15000"  data-namefind="assetExpense"  onclick="convertKto1000(this)"> ';

       amess1+='</span>';
       amess1+='&hellip; <input type="hidden" name="assetExpenseGrowth" value="0">  ';  // 11 oct 2023: to be deprecated

    }          // assettype

    amess+='<td>'+amess1+'</td>';

    if (how=='exist')   return amess;   // caller will add comment column ,etc

    amess+='<td><input type="text" name="assetComment" size="42  value="'+useStuff['comment']+'" title="optional comment"></td>';
    amess+='</tr>';

    if (addAfter===false) {
       $('#assetHistory1').append(amess);
    } else {
        addAfter.after(amess);
    }

    if (how=='0') {             // button click to add a row  (not a load exsiting assets)
       let aamess='After specifying new asset history entries, or removing existing entries-- click   ';
        aamess+='<button onClick="removeARowAssetHistory_scrollSave(1)"><b>Save!</b></button>';
       aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em>';
       aamess+=' <button  data-name="'+aname+'" class="csaveButton"     onClick="showAssetHistory1(this)">reload the asset history </button> <em>without making changes!</em>';
       $('#assetTableHistoryPreview').html(aamess);
    }
}


//===========   isExist
// save asset history  -- a particular asset

// date comment assetPrice assetDividend assetInterest assetSalePrice assetNetRent assetIncome  assetSaleCost

function saveAssetHistory(athis) {

  let nowTime=wsurvey.get_currentTime(0);

  let ethis=wsurvey.argJquery(athis);
  let aname=ethis.attr('data-name');
  let iforce= ethis.attr('data-force');
  if (!jQuery.isNumeric(iforce)) iforce=0;

  let assetType=getAssetType(aname);

// get list of existing eddats
  let eTable=$('#assetHistory1');
  let eExist=eTable.find('[data-which_hist]');

  let nremove=0,nstart=0,nadd=0;
  let existDates={};              // get list of existing dates in this assethistory
  for (let k1=0;k1<eExist.length;k1++) {
       let ae1=$(eExist[k1]);
       let adate=ae1.attr('data-date');
       let isremove=ae1.attr('data-remove');
       if (isremove!=1)  {
          existDates[adate]=1;
          nstart++;
       }  else {
           nremove++;
       }
  }        // end of find existing rows to retain   (existDates)

  let varList=['assetPrice','assetDividend','assetInterest', 'assetSalePrice','assetNetRent','assetIncome','assetExpense',
             'assetSaleCost','assetIncomeGrowth'];
  let gotems=[] ;
  gotems[0]=['assetPrice','assetDividend'];       // stock
  gotems[1]=['assetInterest'];                    // bond
  gotems[2]=['assetInterest'];                     // tax deferred bond
  gotems[3]=['assetSalePrice', 'assetNetRent','assetSaleCost' ];    // property
  gotems[4]=['assetIncome'];   // income stream
  gotems[5]=['assetIncome','assetIncomeGrowth'];    // annuity
  gotems[6]=['assetOneOff'];                     // one off
  gotems[7]=['assetExpense'];                     // expense strream

  let noNegs={'assetIncome':1,'assetExpense':1,'assetPrice':1,'assetDividend':1,'assetInterest':1,'assetDividend':1};     //29 dec 2023: allow property sale price, and oneofffs, to be < 0

  let fracVars={'assetIncomeGrowth':1};

  let nustuff=[];
   let etable=$('#assetHistory1');
   let etrs=etable.find('.assetHistoryRowNew');

   let aremoves=[];
   let removes0=etable.data('removesHistory');
   for (let aa in removes0) aremoves.push(aa);

   let newdates={};
   let warnings=[],errors=[];

   for (let j1=0;j1<etrs.length;j1++) {     // read new entries

      let aetr=$(etrs[j1]);
      let e2=aetr.find('[name="assetAdd_date"]') ;
      let dstuff=wsurvey.dateBox_read(e2,1);
      if (!jQuery.isPlainObject(dstuff)) {
         alert('saveAssetHistory error: ' +dstuff);
         let asstHistErr=dateReadError/3;
         return 0 ;
      }
      let ayear=dstuff['year'];
      let amonth=dstuff['month'];
      let aday=dstuff['day'];

       let adate=setEntryDate(ayear,amonth,aday);
       if (adate===false) return  0;  //  bad date (alert done in setEntryDate

       let dcount=adate['dayCount'];
       if (existDates.hasOwnProperty(dcount)) {
            alert('You have an existing entry with the date: '+adate['sayDate']+'. You must Remove it');
            return 0;
       }

       if (newdates.hasOwnProperty(dcount)) {
            alert('You have two new entries with the same date: '+adate['sayDate']);
            return 0;
      }
      newdates[dcount]=1;
      nadd++ ;

      let saveVals=[];
      for (let jj=0;jj<varList.length;jj++) saveVals[varList[jj]]=0;     // iniitialize

      let doits=gotems[assetType];      // list of attributes that can be specified in the input fields ...  depends on attribut type!

      for (let id=0;id<doits.length;id++) {
             agot=doits[id];
             e2=aetr.find('[name="'+agot+'"]') ;
             let aval0=jQuery.trim(e2.val());
             if (aval0==='')    {
                  errors.push('For '+adate['sayDate']+': '+agot+' not specified ');
                  continue ;
              }
              aval=fixNumberValue(aval0);
              if (aval===false) {
                  errors.push('For '+adate['sayDate']+': '+agot+' is not a number:<tt>'+aval0+'</tt>');
                  continue;
              }
              aval=parseFloat(aval);
              if (noNegs.hasOwnProperty(agot) && aval<0) {
                  errors.push('For '+adate['sayDate']+': '+agot+' can NOT be less than 0.0: <tt>'+aval0+'</tt>');
                  continue ;
              }
              if (iforce==0) {
                if (fracVars.hasOwnProperty(agot) && (aval<0.0 || aval>1.0) ) {
                  warnings.push('For '+adate['sayDate']+': '+agot+' is less than 0.0 or greater than 1.0: <tt>'+aval0+'</tt>');
                }
              }
              saveVals[agot]=aval;
       }   // doits

       let ec=aetr.find('[name="assetComment"]')  ;
       let acomment=jQuery.trim(ec.val());
       let arow={'date':adate['dayCount'], 'comment':acomment };
       for (let zz in saveVals) arow[zz]=saveVals[zz] ; // add the attributes read from input fields
       nustuff.push(arow);

   }      // end of new entry (nustuff) (etrs.length)
   if (errors.length>0) {
      let zmess='<em>Entry errors: </em>';
      zmess+='<ul class="tightMenu"><li>';
      zmess+=errors.join('<li>')+'</ul>';
      zmess+='<div style="font-size:110%;padding:5px">Please fix them <button>Save</button> again!</div> ';
      displayStatusMessage(zmess);
      toggleStatusDiv(0,0);
      return 0;
   }

   if (iforce==0  && warnings.length>0) {
      let zmess='<em>Warnings: </em>';
      zmess+='<ul class="tightMenu"><li>';
      zmess+=warnings.join('<li>')+'</ul>';
      zmess+='<div style="font-size:110%;padding:15px 2em">You can ';
      zmess+='<input type="button" value="reenter" onclick="hideStatusMessage(44)">, ';
      zmess+=' ...  or  <input type="button" value="Save these values" onClick="saveAssetHistory(this)" data-name="'+aname+'" data-force="1"> ';
      zmess+='  </div>' ;
      displayStatusMessage(zmess);
      toggleStatusDiv(0,0);
      return 0;
   }

// auto add?
   let changeAutoAdd=0,autoAddEntriesDo=0;
   let eauto=etable.find('[name="autoAddEntries"]');
   if (eauto.length>0) {
     let iwas=eauto.attr('data-was');
     autoAddEntriesDo= (eauto.prop('checked')) ? 1 :  0;
     if (autoAddEntriesDo!=iwas) changeAutoAdd=1 ;
   }


  if (nremove==0 && nustuff.length==0 && changeAutoAdd==0) {
     alert('No asset history entries were added, or removed');
     return 0;
  }

// 15 dec 2023 : create new assetHistory list... retained from original (from server) + new ones
  let newAssetHistory={'time':nowTime,'data':{}};  // assetList will have (date,entries,autoAddEntries)
  let astuff=[] ;

  let nThisAsset=0;
  let entryList,aentry;
  let thisExists=false;

// only keep assetHistory entries  not removed
  for (anasset in  simInvDsets['allCurrentData']['assetHistory']['data']) {
      let aentry1=JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['assetHistory']['data'][anasset]));
       if (anasset!=aname) {          // keep all the assets (other than this one being changed)

           newAssetHistory['data'][anasset]= aentry1;
           continue;
        }      // else save the changes for this one!

// found exsiting assetHistory (to add to or remove from)
       thisExists=true ;
       aentry=aentry1;
       aentry['autoAddEntries']= autoAddEntriesDo ;
       aentry['updateTime']= nowTime ;

       entryList=[];
       for (let ihh=0;ihh<aentry['entries'].length;ihh++) {    // drop "removes" history entries for this asset
          let entx=aentry['entries'][ihh];
          let odate=entx['date']
          if (!existDates.hasOwnProperty(odate)) continue ; // this was removed   (not retained)
          entryList.push(entx);          // keep this asset history entry (for this aset)
       }

   }     // building assetHistory (loop over all assets, change just this one)


  if (thisExists===false) {       // first time asset histories specified for this asset!
     aentry={'updateTime':nowTime,'autoAddEntries':autoAddEntriesDo};
     entryList=[];
   }

// add new asset history entries (for this asset)...
   for (let iii=0;iii<nustuff.length;iii++) {
          entryList.push(nustuff[iii]);
   }

   nThisAsset=entryList.length;
   entryList.sort(simInvData_sortDate);  // sort by data (ascending)
   aentry['entries']=entryList;

   newAssetHistory['data'][aname]= aentry;      // save sorted list of entries for this asset (the one being changed)

  let bmess='assetHistory for '+aname+': '+nThisAsset+' entries :: '+nstart+' (retained)  + '+nadd+' (added) - '+nremove+' (removed) ';

  simInvGlobals['temp']['autoLogonDetails']={'action':'assetHistorySave','asset':aname} ;
  
  saveSimInvData_assetHistorySave(userName,newAssetHistory,bmess)
  simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

}

//=================
// copy an existing asset's history to an asset (an event handler)
// note (3 july 2023):
// this an event handler is only available  unintialized assets -- and the user must click the "lime" button  in the
// list of buttons (the shortcut to init an asset, from the "n assets" page) doesn't add this button

function copyAsset(athis) {
  let ethis=wsurvey.argJquery(athis);
  let aname0=ethis.attr('data-name');
  let amess='';

  amess+='<em>Which existing asset should be <em>copied</em> ...';
  amess+='<ul class="linearMenu16Pct">';
  for (let aname in assetLookup) {
     if (aname0==aname) continue ; // can't copy own self
//     let aa1=assetLookup[aname];
     let atype=doAssetLookup(aname,'assetType','i');
     let aicon=getAssetType(atype,'icon');
     adesc=doAssetLookup(aname,'desc');
     amess+='<li> <button title="'+adesc+'" onClick="copyAsset1(this)" data-forname="'+aname0+'" data-name="'+aname+'">'+aicon+' '+aname +'</button>';
  }
  amess+='</ul>';
  displayStatusMessage(amess);

}

//=================
// copy an existing asset's history to an asset
// step 2: asset chosen... so copy its rows

function copyAsset1(athis) {

  let ethis=wsurvey.argJquery(athis);

  let aname=ethis.attr('data-name');     // the asset to copy from  -- user selected from list of assets
     let anameType=getAssetType(aname);
     let anameSay=getAssetType(aname,'saysimple');

  let forName=ethis.attr('data-forname');  // the asset being specified (aname's value will be used )
    let aforNameType=getAssetType(forName);
    let forNameSay=getAssetType(forName,'saysimple');

  displayStatusMessage(false);  // hide status message box

  if (anameType!=aforNameType) {
     qq=confirm('The asset to be copied '+aname+' ('+anameSay+') does not match the type of '+forName+' ('+forNameSay+'). Are you sure you want to use it?');
     if (!qq) return 0;
  }

 for (let ii=0;ii<assetHistory[aname].length;ii++) {
   uStuff=assetHistory[aname][ii];

   let oof1=setEntryDate(parseInt(uStuff['date']));
    uStuff['name']=aname;
    uStuff['year']=oof1['year'];
    uStuff['month']=oof1['month'];
    uStuff['day']=oof1['day'];
    uStuff['price']=uStuff['assetPrice'];
    uStuff['interest']=uStuff['assetInterest'];
    uStuff['dividend']=uStuff['assetDividend'];
    uStuff['comment']=uStuff['comment']  ;
    addARowAssetHistory('exist',false,uStuff,1) ;
 }

 wsurvey.wsShow.hide('#statusDiv',200);

  $('#assetHistory1_comment_a').html('Copied from asset: <u>'+aname+'</u>').show();
}

