

///================
// get local storage stats (asynchrous) and display/enable button
function simInv_indexDbStorageStats(ifoo) {


  let elocalStorage=$('#iLocalStorage');
  let elocalStorageButton=$('#iLocalStorageButton');
  if ( simInvDsets['simInvLocalStorage']['enabled']===false) {
      elocalStorage.show();
      elocalStorage.css({'opacity':0.3,'text-decoration':'line-through','color':'red'});
      let lMess;
      let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
      if (!qLocal)   {
           lMess='Local storage is NOT enabled   by this simInv installation ';
      } else {
            lMess='Local storage is  enabled by this simInv installation  ' ;
      }
      elocalStorage.attr('title',lMess);
      elocalStorageButton.attr('title',lMess);
      elocalStorageButton.prop('disabled',true);

  } else {

         simInvDsets['simInvLocalStorage']['usage']='indexDb is used for local stroage';    // 16 dec 2023... could estimate this stuff, but is it worth the trouble?
         simInvDsets['simInvLocalStorage']['quota']=='indexDb limits set by browser';

        elocalStorage.show();
        elocalStorage.attr('title','Local storage enabled. ');
        elocalStorageButton.attr('title','Local storage enabled. ');
        elocalStorageButton.prop('disabled',false);
   }
   return 1;
}

//============
// button in index.html calls this
function simInv_viewIndexDbInfo(athis) {
    getUserList_indexDb(simInv_viewIndexDbInfo2);  //  list of all users
    return ;
}

//===============
// callback for simInv_viewIndexDbInfo -- arg is userList
function simInv_viewIndexDbInfo2(allUsers) {

   let bmess='';
   bmess+='<input type="button" value="x" onclick="wsurvey.wsShow.hide(this,200)" data-wsshow="#mainDiv3"> ';
   bmess+='<b>Local storage:</b> for user=<tt>'+userName+'</tt>   ';

   let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
   if (!qLocal) {           // should never happen
      alert('<em>local storage not used for simInv data (online mode)</em>');
      return false ;
   }

  if ( simInvDsets['simInvLocalStorage']['onLineLocalStorage']===false) {
        bmess+='<em>local storage used for simInv data (standAlone mode)</em>'
   } else {                 // either
        bmess+='<em>local storage used for simInv data (onLine/localStorage mode)</em>'
   }

   let ulist={};
   for (let ij=0;ij<allUsers.length;ij++) {
       let aname=allUsers[ij]['name'];
       ulist[aname]=allUsers[ij];
   }

    if (!ulist.hasOwnProperty(userName)) {  // should never happen
        bmess+='No entry for '+userName;
    } else {
       let updateDate=ulist[userName].updateDate;
       let sayDate=wsurvey.get_currentTime(31,1,updateDate);
       bmess+= ':: last update on <tt>'+ sayDate+'</tt> <br>';
       bmess+='<p>You can <input type="button" value="Remove this user ('+userName+')"  data-online="0"   data-ask="0" data-name="'+userName+'" onClick="simInv_removeDb(this)" > (and clear all her data)' ;
    }

    bmess+=' <ul class="linearMenu16Pct">';
    bmess+='<li style="background-color:lime;font-weigh:600">You can switch users ...';
    let nOnLine=0;
    for (let auser in ulist ) {
       let initDate=ulist[auser].initDate;
       let isdis='  ';
       if (auser==userName) isdis=' disabled  title="(current user)" ';
       if (initDate!==false) {
          bmess+='<li><button onClick="simInv_switchUser(this)" '+isdis+'  data-online="0"  data-user="'+auser+'">'+auser+'</button>';
          if (auser!==userName) bmess+=' <button   data-online="0"  data-name="'+auser+'"  style="color:red" data-name="'+auser+'" data-ask="1" onClick="simInv_removeDb(this)">&#9003;</button>';
       } else {   // a "chose online storage" user
          nOnLine++;
          bmess+='<li><button onClick="simInv_switchUser(this)" data-online="1" disabled  ';
          bmess+='  title="using online storage" data-user="'+auser+'">'+auser+' </button> <em>onLine</em>';  // disabled button (do not allow storage mode switching from here)
          if (auser!==userName) bmess+=' <button  data-online="1" data-name="'+auser+'"  style="color:darkred" data-name="'+auser+'" data-ask="1" onClick="simInv_removeDb(this)">&#8998;</button>';

       }
    }
    bmess+='</ul>';

  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv1');
  wsurvey.wsShow.hide('#mainDiv2');
  wsurvey.wsShow.show('#mainDiv3','show');
  $('#mainDiv3').html(bmess);

}

//================
// switch users
function simInv_switchUser(athis) {
   let ethis=wsurvey.argJquery(athis);
   let auser =ethis.attr('data-user');
   doLogoff(1,'',auser);
}

//===============
// remove username from local storage
function simInv_removeDb(athis) {
    let ethis=wsurvey.argJquery(athis);
    let aname=ethis.attr('data-name');
    let ask=ethis.attr('data-ask');
    let isonline=ethis.attr('data-online');
    if (ask==1) {
       let qq;
       if (isonline==1) {
           qq=confirm('Are you sure you want to remove this reference to an onLine user (who chose server storage): '+aname);
       } else {
          qq=confirm('Are you sure you want to remove this user (and delete her local simInv data): '+aname);
       }
       if (!qq) return 0;
    }
    removeUser_indexDb(aname,simInv_removeDb2,isonline) ;
}

function simInv_removeDb2(status) {
    displayStatusMessage('Removed user: '+status);
    toggleStatusDiv(0,5);
}



// =============
// generic
//===============

