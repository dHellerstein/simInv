// help content for simInv
// note use of varname=` mutliline content `
// this is read by index.html, and written to the mainHelp_div container

let largeHelpContent=`

<!-- help divs for simInv : 1 march 2024 -->

<!-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::    -->
<!-- Help divs! -->
<!-- ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: -->

<!--  // &#127480; S blue  ,  &#127463; B blue,  &#127299;  T box      &#9332; (1)   &#9450; circle 0  -->


<!-- :::::;  Intro ::: -->

<div id="simInvHelp" class="csimInvHelp   helpBox" data-desc="Introduction to simInv" >
<div style="margin-bottom:1em">

<div style="float:left;margin-left:0.5em">
<input type="button" value="x" onClick="wsurvey.wsShow.hide(this)" data-wsshow="-3">
<button onclick="wsurvey.wsShow.inFront(this)" title="Move this box to the foreground" data-wsshow="#simInvHelp" >&#127913;</button>
<input type="button" value="&neArr;" title="View in a new window"  data-id="simInvHelp" onClick="displayInWindow(this)">
<button onclick="viewAllHelp(this)" title="View all help and tips (in a new window)">&forall;? More help ...</button>
</div>


<div class="cIntro" style="float:left;margin-left: 1em;max-height:3.2em;overflow:auto;max-width:50%">
  <b>simInv</b>
    <span id="simInvIntro_ver" title="simInv version" style="font-size:80%;font-style:oblique"></span>:
  simulate the performance of one or more investment portfolios</span>
</div>

<span style="float:right;margin-right:1em">
<input type="button" value="Welcome..." title="Display the welcome screen" onClick="reShowWelcome(1)">
</span>
</div>
<br clear="all" />

With <b>simInv</b> you can specify <em>investment portfolios</em>, each of which can have its own mixture of <em>assets</em>.
And you can modify these portfolios -- changing their mix of assets over time.
<p>
<b>The goal</b>: to display the impacts of different asset mixes, and how changing them can effect overall performance
<p>
<b>The basics: </b>
You specify <em>assets</em> that you may wish to invest in. And <em>portfolios</em> that are mix of these assets. simInv then calculates
the values of these portfolios over time -- values that evolve as  assset attributes (prices, interest, etc) change -- and as you modify
the asset mix in a portfolio!

<div class="simInvIntroTopic"  ">Assets</div>

Use
  <button  class="cdoButtonRegular" >&#128065;  n assets</button>
 to specify several kinds of assets.
<ul class="boxList">

<li><u>&#127463;onds</u>:  <em>bonds</em> refer to assets that have an interest rate: such as government bonds, bank accounts, IRAs,  etc.
<br>Interest earnings on <em>bonds</em> are taxable. However, you can specify <em>&#127299;ax deferred bonds</em> --
their interest earnings are not taxed, but withdrawals are (including withdrawals of principal).
<br> Or, you
can specify bonds that have <em>tax free interest earnings</em>.

<li><u>&#127480;tocks</u>:  <em>stocks</em> refer to assets that have a  per-share price, and that pay dividends.
<br>Dividend payments are taxable. And, capital gains (sales of stock shares) are subject to capital gains taxes.


<li><u>&#127477;roperties</u>:  <em>properties</em> refer to assets that have a sale price, and a <tt>Rent</tt>.
They can be purchased with a loan.<br>
The <tt>Rent</tt> can be positive or negative.
It is the difference between rental income and ownership costs (ownership costs do not include
mortgage payments). Positive Rents are subject to tax.
<div style="margin-left:3em">

<br>
After-tax <tt>Rent</tt>,  and <tt>mortgage interest payments </tt> (after tax deductions) impact the value of a portfolio's <u>Cash</u> asset.
<br>Capital gains when a property is sold are taxable -- although you can specify what fraction is not subject to capital gains tax.

<li><u>&#127470;ncome</u>:  <em>income</em> refer to income streams. They have a <tt>yearly income</tt> (that is specified in
an asset's history), and an  <tt>acquisition cost</tt>.
For example: a part time job (perhaps one requiring a one time startup cost).
<br> <tt>yearly income</tt>  impacts the value of a portfolio's <u>Cash</u> asset.  <br>
<div style="margin-left:3em">



<li><u>&#127466;xpense</u>:  <em>expense</em> refer  to expoense streams. They have a <tt>yearly exepense</tt> (that is specified in
an asset's history) .
For example: yearly vacations (perhaps one requiring a one time purchase).
<br> <tt>yearly expense</tt>  impacts the value of a portfolio's <u>Cash</u> asset.  <br>
<div style="margin-left:3em">

<p>


<li><u>&#66304;nnuity</u>:  <em>annuities</em> refer to income streams whose value depends on when they are added to a portfolio.
That is: its value is based on its <u>acquisition date</u> (the date it is added to a portfolio).<br>
 For example: social security payments depend on your age when you choose to enroll in social security.
<br> They have a <tt>yearly income</tt> (that can increase with inflation), and an  <tt>acquisition cost</tt>.
<menu class="tighterMenu"
<li>As with <u>&#127470;ncome</u>:   <u>&#66304;nnuities</u> impact  the value of a portfolio's <u>Cash</u> asset.
<li>Reiterating: in contrast to <u>&#127470;ncome</u>: the value of an annuity does not depend solely on a <em>display date</em>
-- it also depends on the <u>acquisition date</u>.
</menu>

<li><u>&#120793;off</u>:  <em>oneOff</em> refer to an expense, or receipt, that occurs just once -- they are <u>not</u> repeated.
For example: an inheritance, or purchasing a new car.

</ul>
You <b>must</b> specify the <em>history</em> of each asset: such as a bond's interest rate,
or  a stock's  price and dividend payments.
<br>This is done by specifying  date-specific entries for each asset.
Linear interpolation is used to impute values to dates for which an explicit entry does not exist.

<blockquote>
When specifying <em>a history entry</em>  for an asset: the goal is to <em>accurately</em> -- but not necessarily perfectly --
track its performance over the time. If an asset's charateristics don't change much over time, a few (perhaps just one)
<em>history</em> entries may suffice. <br>
But if it changes  quickly -- say, it is a stock with a volatile price --
several entries may be useful.

<div style="background-color:yellow;margin:3px 3em">
 If the <em>history </em> entries for an asset do <u>not</u> accurately track the asset's actual characteristic: simInv's results will
 <b>not</b> be informative!
</div>

</blockquote>

After specifying assets (and their histories), use
<button  class="cdoButtonRegular" >&#128463;Info</button> to view trend information on prices, interest rates, etc.

<div  class="simInvIntroTopic"  >Public assets</div>
  As an aid, simInv comes packaged with several <u>public assets</u>: assets that are available on the market.
  Using<button  class="cdoButtonRegular"   >&#127760;Public</button>,
  you can add one, or many, of these  <u>public assets</u> to the available assets -- where <em>available</em> means
  <em>can be added to a portfolio's asset mix</em>.
  <br>Note: it is not hard to add <a href="publicAssets/readme.txt" target="readme2">assets to the list</a> of <u>public assets</u>



<div  class="simInvIntroTopic"  >Portfolios</div>
After specifying the available assets,
use   <button  class="cdoButtonRegular" >&#128065;  n portfolios</button>

to can create <em>portfolios</em>.
<br>Each portfolio consists of a selected mix of assets. You specify the portfolio's <em>creation date</em>, and a total budget.
<br>
And, for each selected asset you specify how much of the budget to allocate to it.
You can do this by specifying a dollar amount, or the # of shares (of a <em>stock</em>), or the percent of the total budget.
<blockquote>
After initializing a portfolio's <em>mix of assets</em>  -- you can add modifications. These
modifications will occur on a date you specify.  However: the specified date <b>must</b> be <em>after</em> the date of the initialization.
</blockquote>
<b>Note</b>: when specifying asset <em>historys</em>: be sure the earliest entry is <b>before</b> the earliest <em>creation date</em>
(across all the portfolios you create).


<div class="simInvIntroTopic"  >Viewing results</div>
Using  <button  class="cdoButtonRegular" >&#128176; Display</button> you can view the results  of all your portfolios over time.
In particular: the <tt>net value</tt>: the value (after taxes) from liquidating all the portfolio's asset..
<p>
Perhaps one of the portfolio's you thought was superior.... was not? Or perhaps it was, up until you modified its asset mix!
<p>
You can use simInv that anticipate the future -- just specify modification dates that are in the future.

<div class="simInvIntroTopic"  >Simulating portfolio performance</div>
simInv provides two means for simulating the performance -- how will a portfolio change if the attributes of its assets
change?
<ul class="tightMenu">
<li><b>Variants</b>
<br>
 You can create <em>variants</em> -- several similar portfolios that use <em>variant specific</em> versions of each asset.
Typically: the assets in each <em>variant specific</em> version have the same characteristics up until a certain date:
and then deviate.

<li> You can specify what dates to view  with
  <button   class="cdoButtonRegular">&#128197;displayDates</button>.

<li>  <button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#showScenarioHelp1">&#127760; Scenarios</button>
<br>
  <em>scenario </em>  are broad specifications of the scenarios describing the future state of the world. Will costs increase more rapidly then expected?
 Will interest rates be lower then expected?
</ul>
<p>
Using <em>scenarios</em>  is not as fine grained as using <em>variant specific</em> versions of assets.
<br>
But for broad visions of what future might prevail (what the general state of the world could be) -- it is quicker to specify.

<div style="margin:4px 3em;border:1px dotted gray">Either method  (variants, or scenarios) provides a method of comparing the returns
and risks of alternative portfolios.  </div>



<div class="simInvIntroTopic"  >Export and archive</div>
   <button  class="cdoButtonRegular" > &#128194; </button> is used to export simInv data. You can
 <ul class="tightMenu">
 <li>Export asset information (asset attributes over time) -- to a CSV file
 <li>Export portfolio information (portfolio asset mix and summary stats)-- to CSV files
 <li>Archive all simInv data (to a simInv text file)
 <li>Restore simInv data (from an archived simInv text file).

</ul>
 

<hr>
The <a href="readme.txt" target="readme">installation notes ... </a> contains another summary of simInv.

</div>  <!-- simInvHelp -->


<!-- :::::;  first time  ::: -->

<div id="simWelcome" style="display:none" class="helpBox"   data-desc="Welcome to simInv" >

<div class="cIntro">Welcome to <b>simInv</b></div>
If you are automatically seeing this -- that means you are a new user!
<ul class="boxList">
<li> You can change settings and parameters using
<button class="csettingsButton" id="isettingsButton" onclick="personalSettings(this)">&#9965;</button>.
For example: you can suppress this welcome message!
<li>You can <button   onclick="showAssetTable(this)" >view or add assets </button>.
Once you have specified at least one asset -- the welcome screen will <u>not</u> be automatically displayed.
<li>You can   <button id="portfoliosTableButton2"  name="doPortfolioButton"  onclick="showPortfolioTable(this)">View/add/modify a portfolio </button>
<li>Once you have specified assets, and portfolios that contains these assets, you can
<button>&#128176; Display </button> their performance over time.

</ul>
Need more help?
<ul class="tighterMenu">
<li> View the  <button onclick="wsurvey.wsShow.show(this)" data-wsshow="#simInvHelp">&#10068; simInv introduction</button>
<li>A short <a href="readme.txt" target="readme">readme.txt</a>
<li>Within simInv menu and other pages:  <button>&#10068;</button> will display topic specific help
</ul>


</div>


 <!-- :::::::::::::::::::::::::;; -->
<!-- help for : first logon (initialization, encryption key) -->
 <div id="firstLogonInit" style="display:none" class="helpBox"  data-desc="First logon: initialize account / select an encryption key" >
In <em>online</em> mode: when you first logon to a simInv, initialization is required.<br>
In particular, you can chose whether or not to encyrpt your simInv data.
 Encryption helps keep your information secure. Even if someone can access your data (either online or by reading files on the server),
 they will not be readable.
 <p>
 If you choose to specify an encryption key, it must be used in <b>all</b> future logons!
<br>So do <b>not</b> forget it --  simInv does <b>not</b> store it.
 <p>
As an aid, you can store a <em>hint</em>. The hint is displayed if you enter the wrong encryption key.
<p>
If you don't care if others might see your simInv data -- it is easier to not specify an encryption key.
<p>

 <button title="Tips" onClick="displayHelpMessage(this,false,1)" data-div="#encryptionKeyHelp1">&#10068; details...</button>

</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- help for : adding a new asset -->
<!--      let asays=['&#127480;tock','&#127463;ond','&#127299;axDefer','&#127477;roperty','&#127470;ncome','&#66304;nnuity']; '&#120793;off','&#66308;xpense'] -->

<div id="assetsTableHelp1" style="display:none" class="helpBox"  data-desc="Adding a new asset" >

<button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#showAssetHistoryHelp1">Adding to asset history...</button>
<b>Adding a new asset</b>
<br>
When you add a new asset, you specify its name, its asset type, and its description. Depending on the asset type, you can also specify a few basic attributes.
<ul class="boxList">

 <li><b>Name</b>:a short name.
  <br>It can <u>not</u> contain any of the following characters:
  <tt>   embedded spaces, commas, %,  &, +, *, /, \ , ', ", ', #, !, $, &lt;, &gt;, </tt> or  <tt> | </tt>
  <br>You can specify  a <tt>family.variant</tt> name. If specified in settings, you can only choose one asset
  from a <tt>family</tt>. Or you can automatically select a set of assets with the same variant.

<li><b>assetType</b>  simInv supports several <em>types of assets</em>
 <button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#showAssetHistoryHelp_assetTypes">Details on simInv  asset types ...</button>
   <menu class="tightMen">
   <li> <b>&#127480;tocks</b>
   <li><b>&#127463;onds</b>  -- you can specify <span style="border:1px dotted gray;white-space:nowrap;display:inline-block">Fraction of earnings NOT taxed</span>
   <li><b>&#127299;axDeferred Bonds</b>
   <li><b>&#127477;roperty</b> - you can specify <span style="border:1px dotted gray;white-space:nowrap;display:inline-block">Fraction of capitalGains  NOT taxed</span>
   <li><b>&#127470;ncome streams</b>  -- you can specify <span style="border:1px dotted gray;white-space:nowrap;display:inline-block">Fraction of income <u>not</u> taxed</span>
   <li><b>&#66304;nnuity </b>  -- you can specify <span style="border:1px dotted gray;white-space:nowrap;display:inline-block">Fraction of annuity  <u>NOT</u> taxed</span>
   <li><b>&#120793;off</b>
   <li><b>&#66308;xpense streams </b>  -- you can specify <span style="border:1px dotted gray;white-space:nowrap;display:inline-block"> Fraction that offsets income</span>
  </menu>

<li><b>Desc</b> a several word phrase describing this asset.
<li><b>DescLong</b> a longer description (no html)
</ul>

You can also ...
<ul class="tighterMenu">
<li><b>&#128201; </b>
View the <em>price/interest/dividend</em> entries (history entries) of an asset. The <tt>n</tt> is the number of entries currently specified (for this asset)
<br><em>or...</em>
<input type="button" value="&#9998;Init" style="background-color:lime" >  Initialize (specify its first entry) an asset's history.

<li><button>Hide</button> : hide this asset. You can hide/unHide an asset at any time.
<button title="Why hide an asset?" onclick="displayHelpMessage(this,0,1)" data-div="#assetTableHiddenHelp">?</button>

<li><button>Remove </button> : remove this asset. Removed assets are permanently deleted -- when
 you <button>Save!</button> you will asked to confirm that you really want to remove some assets!

 <li>For existing assets: the <b>DescLong &amp; <span class="cinWhatPortfolios">portfolios</span></b> column displays what portfolios this asset appears in.
 Click an <input  type="button" value="assetName"> to view the asset mix of a portfolio  --  at least one of its history entries includes this asset!.
</ul>

</div>    <!--   assetsTableHelp1   -->


<!-- :::::::::::::::::::::::::;; -->
<!-- help for : basics on the asset types  -->

<div id="showAssetHistoryHelp_assetTypes" style="display:none" class="helpBox"  data-desc="simInv asset types" >
<button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#assetsTableHelp1">Adding a new asset ...</button>
The simInv assets ...

<menu class="boxList">

<!-- ::::: regular bonds ::: -->

<li ><em>&#127480;tock</em>: Stocks have a  per-share price, and a yearly dividend.
<br>For example: shares of a publically traded stock.
<br>
The price and dividend can fluctuate over time.
Dividend earnings accrue on a daily basis: they are taxed and the after-tax amount is reinvested in the stockAsset.
<br>Note that  as a stock's dividend and price fluctuate,
the number of shares purchased will fluctuate (higher if dividends increase or if the price decreases).
<menu class="tightMenu">
<li>When initializing a portfolio: when you add shares of a stock you also specify a <em>basis</em>  -- the original purchase price of these shares.
This is used when computing capital gains (when the stock is sold).
<li>When modifying a portfolio: the # of shares and the basis increase by the same amount (in $ terms).
</menu>

<!-- ::::: regular defered bonds ::: -->

<li style="border:5px solid cyan;margin-top:5px;background-color:#e4eff9"><em>&#127463;ond</em>:
     Bonds (regular) have an interest rate (that can fluctuate over time). The <em>share price</em>  of a bond is always <tt>1.0</tt>.
<br>For example: a savings account, or a corporate bond fund.
<br>
Interest earnings are taxed as they accrue (on a daily basis), and the after-tax amount is invested in the bondAsset.
<menu class="tightMenu">
<li>You can specify an <span class="ctaxFreeFrac">tax free fraction</span> : <tt>0.0</tt> (fully taxed) to <tt>1.0</tt> (no tax).
<br> For example:  a muni-bond fund (or a Roth IRA) could have a tax free fraction of <tt>1.0</tt>.
</menu>

<!-- ::::: tax defered bonds ::: -->

<li style="border-top:1px dotted cyan;margin-top:5px;"><em>&#127299;axDefer</em>:
   Bonds (tax deferred) have an interest rate  (that can fluctuate over time). The <em>share price</em>  of a tax-deferred bond is always <tt>1.0</tt>.
<br>For example: a 401k, or an IRA.
<br>
<menu class="tightMenu">
<li>Interest earnings are <u>not</u> taxed as the accrue (on a daily basis), and are re invested in the bondAsset.<br>
<li>However: when a tax deferred bond is <em>sold</em>, taxes are levied on the entire sales price.
</menu>

<!-- ::::: property ::: -->

<li style="border-top:1px dotted cyan;margin-top:5px;background-color:#e4eff9"><em>&#127477;roperty</em> :
Properties, such as a house or a car, have several attributes:
<menu class="tightMenu">
<li> a price     <em>specified in the asset history entries.</em>
<li> yearly rent (net of property related expenses)    <em>specified in the asset history entries.</em>
<li>  acquisition costs  <em>paid when added to the portfolio </em>-- for example: a down payment.
<li>You can specify a <u>Loan</u> to be paid out over time.
<li> A capital gains tax fraction (when sold, what fraction of capital gains are subject to capital gains tax)
</menu>
<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#assetsTableHelp_property">Property details ...</button>



<!-- ::::: income ::: -->

<li style="border-top:1px dotted cyan;margin-top:5px;"><em> &#127470;ncome</em> :
  Incomes are yearly income streams. They have a value and an acquisution cost. The aquisition cost is a one-shot payment.
<br>For example: income from a small business, that you purchase with a one-time payment..
<p>
The value (cash generated) from an &#127470;ncome, on a given date, depends on what you specified in its history.
Thus, it could be steady, or fluctuate.
For example, salaries from a part-time job that you spend less and less time on.


<br>The after-tax proceeds from an <tt>income streams</tt>   are added to the <u>Cash</u> asset.


<menu class="tightMenu">
<li>The <span class="ctaxFreeFrac">income NOT taxed:</span> is the portion of income that is <u>not</u> subject to income taxes.
<br>For example: <tt>0.0</tt>=all income (from this income stream) is taxed  <tt>1.0</tt> income is not taxed
</menu>

<!-- ::::: annuity ::: -->

<li style="border-top:1px dotted cyan;margin-top:5px;background-color:#e4eff9"><em> &#66304;nnuity</em> :

  Annuities are yearly income streams.   For example: social security, or a defined benefits pension.
<br>  &#66304;nnuity are similar to  &#127470;ncome.
  <menu>
  <li>They have a value and an acquisition cost. <br>
  <li>The after-tax proceeds are added  to the <u>Cash</u> asset.
  <li>You can specify what fraction of yearly annuity income is subject to income tax
 </menu>

  <em>However,</em> the income it generates  (for use when calculating a portfolio's net value on a given date) depends on 
  the <em>annuity value</em>, and the <em>growth rate</em>, as of its <tt>acquisition date</tt>.

<br>
<button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#assetsTableHelp_annuity">Annuity details ...</button>

<!-- :::::; one off :::::: -->
<li style="border-top:1px dotted cyan;margin-top:5px;"><em>&#120793;off</em> :
  oneOffs are receipts that are received just once -- on the day after the asset is added to the portfolio.
  <br> oneOffs can be positive (such an inheritance) or negative (such as a large purchase).
<p>
The receipt (cash generated) from an &#120793;off on a given date, depends on what you specified in its history.
Thus, it could be steady, or fluctuate.
For example, the cost of a new car may change over time -- so its impact (when added to a portfolio) depends on when you add it.

<br>The  receipts from a <tt>oneOff</tt>   are added to the <u>Cash</u> asset.  oneOffs are <u>not</u> taxed -- if they
are subject to a tax, the after-tax amount should be incorporated in its asset history entries.

<p>
 You can add the same oneOff asset to several different modifications of a portfolio. Each time it is added the receipt occurs.
<br>For example: purchasing a new car (same model!) every several years.



<!-- ::::: expense ::: -->
<li style="border-top:1px dotted cyan;margin-top:5px ;background-color:#e4eff9"><em> &#66308;xpense</em> :
  Expenses are yearly expense streams. They have a value .
<br>For example: costs of a yearly vacation.
<p>
The value (cash generated) from an &#66308;xpense, on a given date, depends on what you specified in its history.
Thus, it could be steady, or fluctuate.
For example, charitable donations that change as needs vary.

<br>The after-tax proceeds from an <tt>expense streams</tt>   are subtracted from the <u>Cash</u> asset.

<menu class="tightMenu">

<li>The <span class="ctaxFreeFrac">fraction of expense that offsets taxable income:</span>
is the portion of the expense that is <u>offsets taxable income</u>.
<br>For example: <tt>0.0</tt>=costs (from this expense stream) do <u>not</u> impact taxes;  <tt>1.0</tt> expense costs can be treated as
deductions from taxable income (hence lead to reduce taxes)..
<br>Note that simInv uses a shortcut: the amount withdrawn from <u>Cash</u> is a function of the expense amount, the tax rate, and expense not taxed.
<li> Example: <tt>expense=10,000</tt>, taxRate=<tt>20%</tt>, fraction that offsets=<tt>80%</tt> ... the amount withdrawn would be 8,400.
</menu>


<li style="border-top:1px dotted cyan;margin-top:5px;background-color:#d3ffc9">
 <u>Cash</u>: the <em>cash</em> asset is special kind of <em>bond</em>.
It has one interest rate when its balance is &gt; 0.0, and a different one when &lt; 0.0.
These rates are set using the  <button>&#9965; personal settings</button>
<br>
 <u>Cash</u> is automatically computed  -- it is where taxes from sale of an asset, rents, oneOffs, annuities, incomeStreams, and expenseStreams are added to (or drawn from).
<div style="margin:3px 3em 3px 3em;border:2px solid gold;padding:5px;font-size;110%">
If <u>Cash</u> becomes large (positive or negative) -- it is sensible to modify the asset-mix!
</div>
</menu>

<li><em> How are yearly values (such as income streams, expense streams, and dividends) used? </em>
Basically, a <em>daily value</em> is computed, and used (say, to purchase more bonds, or to add to <u>Cash</u>) at the end of each day.

</div>          <!-- showAssetHistoryHelp_assetTypes -->

<!-- :::::::::::::::::::::::::;; -->
<!-- help for : annuity details -->

<div id="assetsTableHelp_annuity" style="display:none" class="helpBox"  data-desc="Annuity details" >

<button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#assetsTableHelp1">Adding a new asset  ...</button>
<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#showAssetHistoryHelp_assetTypes">Details on simInv  asset types ...</button>

<b>Details on annuities</b>
<br>
 &#66304;nnuities, such as social security, are a special kind of yearly income stream.
  <menu>
  <li>They have a value and an acquisition cost. <br>
  <li>The after-tax proceeds are added  to the <u>Cash</u> asset.
 </menu>

 How is an annuity's yearly income (on a given date) calculated?
  <menu>
  <li> Annuities have an <tt>acquisition value</tt> -- a value that depends on when it is added to your portfolio.
   <li> And they have a <em>growth rate</em> -- which also depends on when the annuity is added to your portfolio.

 <li> Both of these  are determined  by matching the <tt>acquisition date</tt> to the annuity's asset history entries (using interpolation if necessary).

    <div style="margin:3px 3em">
    In contrast: &#127470;ncome streams values do <u>not</u> depend on when they are added to a portfolio, and they do not have
    a built in <em>growth rate</em>.
    </div>
<li> The <tt>acquisition value</tt> value is then grown at its <em>growth rate</em> -- from the <tt>acquisition date</tt> until the <tt>given date</tt>.
 </menu>

The growth rate is a fraction of inflation.
<div style="margin:3px 3em">
<menu class="tighterMenu">
  <li>1.0</tt> means <em>grows at the inflation rate</em><br>
  <li>0.0</tt> means <em>does not grow</em> (the <tt>acquisition date</tt> value is used on all future dates).
</menu>
</div>

 <em>Example: </em>
 <menu class="tightMenu">
 <li> in 2024 you are 68 years old
 <li> you specify two entries for social security payments:    $48,000 in 2024, and $55,987 in 2026
 <br> (since <em>social security increases by 8%/year until age 70)</em>
 <li> it grows at 100% of inflation (a growth factor of <tt>1.0)</tt>, and inflation is 4% per year.
 </menu>
 <table cellpadding="5" style="margin:3px 5em 3px 5em;border:1px solid tan">
 <tr><td>(in k$ pre-tax)</td>  <th>2024 (68)</th>    <th>2026 (70)</th>    <th>2028 (72)</th>     <th>2030 (74)</th>   <th>2032 (76)</th></tr>
 <tr><th>Add in 2024 (68)</th> <td>48k</td>     <td>51.9</td>     <td>56.1k</td>          <td>60.7</td>       <td>65.7</td></tr>

 <tr><th>Add in 2026 (70)</th> <td>0</td>       <td>55.9k</td>     <td>60.6k</td>           <td>65.5</td>       <td>70.8</td></tr>

 <tr><th>Add in 2030 (74)</th> <td>0</td>       <td>0</td>          <td>0</td>              <td>55.9k</td>       <td>60.6k</td></tr>
 </table>

<br>Note that after 70 years old, the earnings in the acquisition year are the <u>same</u> -- they do <u>not</u> grow at the rate of inflation.
That's why the <tt>Add in 2026</tt> value in 2026 is the same as the <tt>Add in 2030</tt> value in 2030!

</div>    <!--   assetsTableHelp_annuity   -->


<!-- :::::::::::::::::::::::::;; -->
<!-- help for : property details -->

<div id="assetsTableHelp_property" style="display:none" class="helpBox"  data-desc="Property details" >

<button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#assetsTableHelp1">Adding a new asset  ...</button>
<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#showAssetHistoryHelp_assetTypes">Details on simInv  asset types ...</button>
<b>Details on properties</b>
<br>


<menu class="tightMenu">
<li>When you add a &#127477;roperty to a portfolio, you specify acquisition costs (down payments, etc); and you can specify a loan to pay for it.

<div style="margin:2px 3em 2px 3em">If these two do <u>not</u> add up to the price of the property ... that means you are obtaining it at below (or above) market value!
</div>

<li>Price is the sale price of the property -- what you pay for it when added to a portfolio. And, what you receive for it if/when you sell it.
<li>Rent are yearly rents (and other earnings) minus yearly costs. Costs could include  real estate taxes, and maintainance -- but should <b>not</b>
include mortgage payments
<br>After tax rents are added to (or subtracted from) the <u>Cash</u> asset. Note that negative rents are not subject to tax, and they do not
reduce other taxable income.


<li>You can specify a <span class="ctaxFreeFrac">capital gains NOT taxed:</span>  the portion of capital gains (when you sell the property)
that is <u>not</u> subject to capital gains taxes.
<div style="margin:2px 3em 2px 3em">For example: <tt>0.0</tt>=all capital gains are taxed, <tt>1.0</tt> capital gains are not taxed</div>
</menu>


</div>    <!--   assetsTableHelp_property   -->

<!-- :::::::::::::::::::::::::;; -->
<!-- help for : hiding assets -->

<div id="assetTableHiddenHelp" style="display:none" class="helpBox" data-desc="Hiding assets" >
<button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#assetsTableHelp1">Adding a new asset  ...</button>
<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#showAssetHistoryHelp1">Adding to asset history...</button>
<br>
<b>Hiding assets</b>


To save space on simInv's various menus, you can <u>hide</u> assets.

<div style="background-color:yellow;margin:3px 3em 4px 3em">
<b>Why hide an asset?</b> If you have assets that were included in older portfolios, that you are unlikely to include in a newly created
(or modified) portfolio -- hiding them can save some screen space.
</div>

 <u>Hidden</u> assets will not be displayed in:
<ul class="tightMenu">
<li>Optionally, the list of assets
<li>The list of compressed assets
<li>The list of assets at the top of a porfolio table  -- which means you can <b>not</b> add hidden assets to a portfolio.
</ul>
Hidden assets <u>are</u> still useable. In particular, a hidden asset can still be included in existing portfolios.

And ... you can unhide (or hide) an asset at any time!

</div>    <!--   assetTableHiddenHelp   -->


<!-- :::::::::::::::::::::::::;; -->
<!-- help for : adding asset history -->

<div id="showAssetHistoryHelp1" style="display:none" class="helpBox" data-desc="Adding to an asset's  history" >

 <button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#assetsTableHelp1">Adding a new asset ...</button>
 <button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#showAssetHistoryHelp_assetTypes">Details on simInv  asset types ...</button>
 <p>
<b>Adding to an asset's <u>history</u></b>

<p><u> Actions ... </u>
<ul class="boxList">
<li><button>add</button> : add a row -- then specify a date; the asset's characteristics (price, interest rate, dividend)
on that date; and an optional comment<br>
<li><button>Save!</button> : save these rows -- they become this asset's <em>history</em> <br>
<li>
   <span class="caddAsset_addAfterHelp"><input  type="checkbox" > autoAdd?</span>  :
   automatically add entries <u>after</u> the final entry.  These entries will have attributes that grow
   using the <em>inflation (CPI) schedule</em>. 
   <div style="border:1px solid cyan;margin:3px 3em;padding:4px">
   autoAdd is <u>not</u> supported for annuities!<br>
    Why? The  <tt>Growth</tt> attribute of annuities is used instead (growth as fraction of inflation)
   </div>

   <em>How does autoAdd work?</em>
   <ul>
   <li>For each years after the year of the final asset-history entry (for a given asset)
   <li>Until the end of the yearRange (for example, <tt>2035</tt>)
   <li>Using the values of the last entry. For example:  for a stock asset --
   its <tt>price</tt> and <tt>dividend</tt>
   <li> Adjusting these values using inflation (as specified in the CPI schedule) on the specified date.
   <br>The adjustment depends on the attribute:
   <menu class="tightMenu">
   <li>For prices (stocks, properties), rents (properties), and incomes &amp; annuities: the final entry is multiplied by the cumulative
   inflation (between the final entry data and the specified date).  Thus: the inflation adjusted value stays constant.
   <li>For interest rates: the difference between inflation and interest rate (on the final entry) is added to the
   inflation rate (on the specified date).  Thus: the &real;eal interest rate stays constant.
   </menu>

</ul>
If you do <u>not</u> check <tt>autoAdd</tt>... the last entry's values are used for all dates after this last entry.
If you are (as recommended) entering <em>nominal</em> values, this could be inaccurate.

<div style="background-color:yellow;margin:3px 3em">
These values are calculated dynamically: so if you change the inflation schedule, use a scenario with inflation specified , or add a new final entry -- the
autoAdded <em>future</em> asset-history entries will change.
<p>
 This is a shortcut!  A more rigrous approach is to specify attributes for all years of each asset (up until the
 end of the yearRange). That is: update asset attributes over the course of time (as they become known  &#129300;) .
 </div>


<li><button>Copy ... </button> : copy the history of an existing asset (add rows to the table)
</ul>

<br>For all types of assets you specify a date  (year/month/day) , and (<em>optionally</em>) a comment.
The date must <u>not</u> be an existing date.

<br><u>Variables to specify </u> depend on the type of asset.

<table style="margin:2em 1em " cellpadding="4" rules="rows">
<tr><th>&#127480;tocks</th>
<td><ul>
<li><em>Price</em>: the price per share. Must be non-negative.
<li><em>Dividend</em>: Dividends per share per year. Must be non-negative.
</ul>
</td>   </tr>

<tr><th>&#127463;ond (regular and &#127299;axDeferred).</th>
<td><ul>
<li><em>Interest rate</em>: The yearly interest (i.e. <tt>5</tt> for 5%/year). Must be non-negative.

</ul>
Note that a <span class="ctaxFreeFrac">tax free fraction of interest earnings</span> is specified when creating a regular bond asset -- it can  <u>not</u> be changed over time.
</td>
</tr>

<tr><th>&#127477;roperties </th>
<td><ul>
<li><em>Price</em>: the sale price of the property.

<li><em>Rent</em>:
The yearly net earnings (or costs) from owning this property. For example: rental income minus (taxes + maintenance).
This should <u>not</u> include mortgage payments.

<li><em>saleCost</em>
The cost of selling this property. This is applied when a property is sold (liquidated) -- the amount is deducted from the sale price.
It is a non-reimbursable out of pocket cost associated with liquidating the property.
<br>that means is does<u>>not</u> affect taxable income (it is not used as a tax deduction), 
and it does <u>not</u> impact capital gains.
</ul>
Note that a <span class="ctaxFreeFrac">tax free fraction of capital gains </span> is specified when creating a property  bond asset -- it can  <u>not</u> be changed over time.

</td>
</tr>

<tr><th>&#127470;ncomeStreams</th>
<td><ul>
<li><em>Income</em>: The yearly income received. Must be non-negative.
</ul>
Note that a <span class="ctaxFreeFrac">tax free fraction of income</span>  is 
specified when creating an income asset -- which can  <u>not</u> be changed over time.
</td>
</tr>


<tr><th>&#66304;nnuity</th>
<td>
<ul>
<li><em>Income</em>: The yearly income received.  Must be non-negative.
<li><em>Growth</em>: You can specify a growth rate (as a fraction of inflation).
 This growth rate  is applied to the annuity on its <u>acquisition date</u>. It is specifed as fraction of inflation.<br>
 Thus: <tt>1.0</tt> (<em>100%</em>) = <em>keep up with inflation</em> ; <tt>0.0</tt>  = <em>no growth</em><br>
 <em>Example:</em> </tt> social security income is determined at the age you acquire it -- with a cap at 70 years old.
 It then grows every year at about 100% of the CPI.
</ul>
Note that a <span class="ctaxFreeFrac">tax free fraction of annuity</span> is specified when creating an annuity asset --
it can  <u>not</u> be changed over time.
<br> <button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#assetsTableHelp_annuity">Annuity details ...</button>

</td>
</tr>

<tr><th>&#66308;xpense</th>
<td><ul>
<li><em>Expense</em>: The yearly expense.  Must be non-negative.
</ul>
Note that a <span class="ctaxFreeFrac">tax offset fraction </span> (expenses can reduce taxable income)  is
specified when creating an expense asset -- which can  <u>not</u> be changed over time.

</td>
</tr>




</table>

<br><u>Notes:</u>
<ul >
<li>Each asset's entries will be sorted by date -- so don't worry about the date-order when you add an entry.

<li>To replace an entry (on a given date), you must first <b>remove</b> the existing entry. And then add a new entry.
<li> The price/interest/dividend of an asset, on a given date (for example, on a portfolio's creation date)
  are calculated  using ...
<menu class="tightMenu">
 <li>Linear interpolation is used to calculate values (using entries before and after a given date)
 <li> For dates before the earliest entry: the asset has no values (it doesn't exist).
 <li> For dates after the latest entry: the values of the last entry are used (linear interpolation is not attempted).
</menu>
<li>As time goes by: you should can add entries to the <u>publicAssets</u> (that you have added to the list of available assets).


</ul>


</ul>
</div>      <!--   assetHistoryHelp1   -->

<!-- :::::::::::::::::::::::::;; -->
<!-- help for : initaizliating a portfolio -->

<div id="portfolioHistoryHelp1" style="display:none" class="helpBox" class="helpBox" data-desc="Initialize a portfolio  ... or modify an existing portfolio" >

<div>
  <div style="float:left;margin-left:1em"<b>Initialize a portfolio  ... or modify an existing portfolio </b>
  </div>
  <div style="float:right;margin-right:2em">
  <a name="helpAssets_buttons">&nbsp;</a>
<a href="#helpAssets_bond" class="cdoButtonTan" title="Specifying bonds (regular and tax-deferred">&#127463;</a>
<a href="#helpAssets_stock" class="cdoButtonTan" title="Specifying stocks">&#127480;</a>
<a href="#helpAssets_property" class="cdoButtonTan" title="Specifying properties">&#127477;</a>
<a href="#helpAssets_income" class="cdoButtonTan" title="Specifying income streeams">&#127470;</a>
<a href="#helpAssets_annuity" class="cdoButtonTan" title="Specifying annuities">&#66304;</a>
 </div>

</div>
<br clear="all" />

<ol>
<li> Specify a budget
<li> Specify the creation date   ... or the modification date
<li> Add assets to the porfolio -- click on  <button>assetName</button> buttons  ... or modify existing assets.
<br> If your portfolio has a <em>variant</em>, then assets with a different variant will <u>not</u> be listed.
<li> Specify values for these asset (such as # of stock shares).
<li><em>Shortcut:</em> When initializing a  porfolio: you can copy the asset mix of a different portfolio (and then modify its values).
use <button>Copy a portfolio</button>

<li>Once you have the desired mix of assets -- click <button>Initialize</button> to initialize the portfolio .. or <button>Save</button> to
review &amp; save your modifications.
</ol>
<br>
<em>Portfolio variables and buttons ... </em>
<br>
<ul class="boxList2">
<li> <em>Creating a portfolio</em>:
<menu>
<li> <b>Budget</b>: Dollars to allocate to all assets. You can use <tt>xxxK</tt> as a shortcut!
<li><b>Creation date</b>: The date this portfolio was assembled (assets were obtained).
<br> Note that any funds remaining in the budget (funds not allocated to an asset)  is allocated to <u>Cash</u>
<li><button>&#128712;</button> View information on each asset: price, dividend, interest rate, etc. As of the chosen
creation date. If you change the creation date, click this to refresh this information!

</menu>
<li><em>Modifying a portfolio</em>:
<menu>
<li><p>Portfolio net value  is the current net (after tax, etc) value of the assets
in the portfolio (including <u>Cash</u>. Where <tt>current</tt> means <em>as of the specified modification date</em>.
This is a function of the
growth of your assets, income streams and annuities, and expenses (such as taxes and mortgages).
<br>It is what you can spend on a new asset-mix if you sold all of them!
<li>The   <span class="cdescNoteLittle">[gross value]</span> is pre-tax, and pre loan payoff.
<li>The <span style="color:#a66529;margin-right:1em">modification date</span>
<li><button>&#128712;</button> View information on each asset: price, dividend, interest rate, etc. As of the chosen
creation date. If you change the creation date, click this to refresh this information!
<li><button>&#9918;</button>  Display the current asset allocation. This incorporate changes
due to growth (since the creation date, or the most recent modification).  In other words: the asset values <b>before</b>
your modifications.
<li><button>&#8710;</button> Display changes due to growth for each asset. Before your modifications!
</menu>

<li>Note: when a portfolio initialization menu is first displayed, today's date is used as the creation date.
<br>The <b>creation</b> and <b>modification</b> dates are used to determine the current attributes (price, interest rate, dividend) of an asset.

<li></b>&#1769;</b> : Allocate remaining cash to first <em>no shares allocated</em> asset.
</ul>

<hr>
<em>Asset variables and buttons ... </em>
The variables to be specified depends on the type of the asset..
<ul class="boxList2">

<li>
<a href="#helpAssets_buttons" title="top of this help section">&uarr;</a>
<a name="helpAssets_bond"><em>&#127463;ond</em> </a> (regular and &#127299;axDeferred) assets:
  <menu>
    <li> <tt>$dollar</tt>: the dollar value in this bond asset.
     <ul class="pointerMenu">
      <li>The cost of purchasing a tax-deferred asset is based on <em>pre-tax</em> income.
      <li> For example, if the taxRate is <tt>20%</tt>, then $10,000 of tax-deferred assets will cost $8,000.
      <li> This is a shortcut... do you really have seperate pools of taxed and pre-tax funds?<br>
      Thus: if you want to accurately compare portfolios, be consistent when specifying tax-deferred assets.
     </ul>

    <li> <a name="sayRMD"><tt>&plusmn;additions</tt></a>: yearly additions. If non-zero (and not blank), an amount to add (in dollars).
    This amount is pulled from <u>Cash</u>. Or, if a negative amount -- is added to <u>Cash</u>.
    <div style="margin:3px 4em">
    For example: if a <tt>1,000</tt> is specified: then every year the value of these bonds (in
    this porfolio) will increase using both its interest rate <u>and</u> by $1000.
    </div>
<br>    <em>Note:</em>: since additions come from <u>Cash</u>: yearly additions cause will decreaset the size of the <u>Cash</u>
(or increase, if a -addition is used).
<br>    <em>Note:</em>: for  &#127299;axDeferred bonds: the cost (hence the change in <u>Cash</u>) is net of taxes. For example:
for a $1000 addition and a 20% tax rate: the cost will be $800.

    <li> <tt>&hellip; RMD</tt>:
    For <u>&#127299;ax deferred bonds</u> you can specify a special kind of <em>addition</em>: a required minimum distribution (RMD).
    <br>RMDs are negative additions -- they are withdrawals from the tax deferred bonds that are deposited into <u>Cash</u>.
    <br>These yearly withdrawals are a fraction of the value of an asset (for example: the dollar value of an IRA).
   <div style="margin:3px 4em">
 This fraction is based on a current age. Basically, the older one is the larger the fraction.

   <br>simInv supports two kinds of RMDS: for your <em>own</em> accounts, and for accounts for which you are a beneficiary.
   The age specific fraction of these differ --  you can <input type="button" value="View these fractions" onClick="viewRmdSchedules(1)">
 </div>

   When specifying an RMD, you must  specify the <u>current age</u> age (as of the date of this portfolio entry).
   In future  years this age is augmented (and used to calculate the withdrawal fraction).


  </menu>
  Note: the tax-free fraction (of interest earnings), and whether or not it is tax-deferred ... is specified when a bond asset is created.
  It can not be changed on a portfolio specific basis.

<li>
<a href="#helpAssets_buttons" title="top of this help section">&uarr;</a>
<a name="helpAssets_stock"><em>&#127480;tock</em></a> assets:
  <menu>
    <li> <tt>#shares</tt>: # of shares. Each share has a price (as of the creation or modification date).
     The cost of obtaining these shares <tt>#shares * currentPrice</tt>.

    <li> <tt>Basis</tt>:  The basis (in dollars) of all the shares. Used in capital gains calculations

  <span class="portfolioAssetBasis"> Basis</span> is the dollar value of the <em>basis</em> -- the initial expenditure used to obtain the stocks.
    <br>The basis is used when computing capital gains:  <tt>capitalGain=(#initialShares * priceWhenSold) - basis  </tt>.

   <menu class="pointerMenu">
      <li>As a shortcut, you can use <tt>xx%</tt> : the percent of the cost of the shares. This will be converted to dollars
      by <button>calculate portfolio value</button>
       <li><em>Note:</em> the <tt>basis</tt> increases whenever new shares are purchased (say, using dividend earnings).
    </menu>

  </menu>


<li>
<a href="#helpAssets_buttons" title="top of this help section">&uarr;</a>
<a name="helpAssets_property"><em>&#127477;roperty</em></a> assets:
  <menu>
    <li> <tt>acqCost</tt>: acquisition  (one-time) costs. These are <em>upfront costs</em>: such as   downpayments and closing costs -- but should <u>not</u> include mortgage payments.
    <br>These costs are used when computing a porfolio's cost (for comparision to its budget).
    <li> <tt>basis</tt>: The value of the property when obtained.  This is used when calculating capital gains (when the property is sold).
    <li>  You can also specify a loan -- with  <tt>loan amount</tt>, interest <tt>rate</tt>, <tt>term</tt>, and whether interest payments are <tt>tax deductible</tt>.
<br>     simInv will the loan payments(such as cumulative interest and principal payments) when calculating date-specific portfolio values.
     <li>Note that the salesPrice, loan amount, and basis can be different! Perhaps you did not have to pay the full market value for a property, and
     its basis is derived from its price a decade ago?
  </menu>

  Note: the tax-free fraction (of capital gains)  ... is specified when a property asset is created.
  It can not be changed on a portfolio specific basis.

  <div style="margin:3px 4em;border:1px solid black">
  When modifying a portfolio: &#127477;roperty assets can <u>not</u> be modified. However, they can be sold off (&#128184;)-- the net sales price
  (after capital gains) is immediately available for use (or will be added to <u>Cash</u>).
  </div>

<li>
<a href="#helpAssets_buttons" title="top of this help section">&uarr;</a>
<a name="helpAssets_income"><em>&#127470;ncome</em></a> assets:
  <menu>
    <li> <tt>acquisitionCost</tt>:  Cost of obtaining this yearly income stream (for example: the cost of buying a small business).
  </menu>
  Note: the tax-free fraction (of an income stream  is specified when income asset is created.
  It can not be changed on a portfolio specific basis. The per-year income can vary (as specified by the asset's history entries).

  <div style="margin:3px 4em;border:1px solid black">
  When modifying a portfolio: &#127470;ncome assets can <u>not</u> be modified. They can be terminated (&#128721;)-- the income stream will end, without any
  impact on current <u>Cash</u>.
  </div>


<li>
<a href="#helpAssets_buttons" title="top of this help section">&uarr;</a>
<a name="helpAssets_annuity"><em>&#66304;nnuity</em></a> assets:
  <menu>
    <li> <tt>acquisitionCost</tt>:  Cost of obtaining this annuity.
    <li><tt>Growth</tt> The growth of the income (once acquired) -- as a fraction  of inflation.
  </menu>
  Note: the tax-free fraction  of an annuity can not be changed on a portfolio specific basis.

  <div style="margin:3px 4em;border:1px solid black">
  When modifying a portfolio:&#66304;annuity assets can <u>not</u> be modified. They can be terminated (&#128721;)--
   the income stream will end, without any  impact on current <u>Cash</u>.
  </div>

<li>
<a href="#helpAssets_buttons" title="top of this help section">&uarr;</a>
<a name="helpAssets_oneOff"><em>&#120793;off</em></a> assets:
  <menu>
    <li>No value to set. The <tt>receipt</tt>   are set in oneOff asset histories.
  </menu>

  <div style="margin:3px 4em;border:1px solid black">
  When modifying a portfolio: a &#120793;off  from the prior (initialization or prior modification) portfolio entry are <u>not</u> displayed
  -- since they have no impact after the date added to a portfolio.
  </div>


<li> For all assets, you can <em>optionally</em> specify a <b>comment</b>

<li>
<b>Calculated totals</b> : filled by <button>calculate portfolio value</button>.
The totals do <b>not</b> include the amount in <u>Cash</u>.
<ul class="pointerMenu">
<li style="margin:5px"><span style="border:2px ridge green">Gross value</span>: Value of all shares of all assets (as of creation date).
The $value, and the % of total budget, are displayed.
<li style="margin:5px"><span style="font-size:90%;border:2px ridge green">Net value</span>:
Net value</span> is an estimate of the value of the asset when sold -- it accounts for (but not precisely)
 capital gains, and deferred, taxes.
 </ul>
</ul>


  <hr>
<table cellpadding="5" rules="rows">
<tr><td><em>Shortcuts   </td>
<td>
 <menu>
<li> You can freely insert commas. And you can use <tt>xxxK</tt>. Eg; <tt>10.3k</tt> = <tt>10300</tt>
<li>You can specify a <em>percent of total budget</em>: use <tt>xx%</tt>
(or enter a value and then use <input type="button" class="smallButton" value="%" >)
<li>For stocks  you can specify a <em>dollar expenditure</em>: use <tt>$xx</tt>
(or enter a value and then use <input type="button" class="smallButton" value="$" >).
The entered amount will be converted to a number of shares (using the current stock price).
</menu>
</td></tr>

<tr><td><em>Note on modifying a portfolio  </td>
<td>
When modifying an existing portfolio (either the initial entry, or an existing modfication), you can
<ul>
<li>&#127480;tock : Sell, or buy more,  shares of a stock. Or  sell all shares (&#128176;).
<br>The sale amount (#shares sold * current price) minus taxes,  is added to <u>Cash</u> -- and is immediately available for investment.
<br>If you purchase additional shares: the funds are drawn from <u>Cash</u>

<li>&#127463;ond and &#127299;axDeferred Bond: Increase, or decrease, the dollars in the bond. Or convert all bonds to cash  (&#128176;)
<br>The sale amount ($ converted), minus taxes (if a tax-deferred bond)    is added to <u>Cash</u> -- and is immediately available for investment.
<br>If you purchase additional shares: the funds are drawn from <u>Cash</u>

<li>&#127477;roperty :  Sell  (&#128184;) the property. You can <u>not</u> withdraw a portion of its value.
<br>The sale price, minus taxes and remaining loan balance,  is added to <u>Cash</u> -- and is immediately available for investment..
<br>You can <u>refinance</u> the loan using the  <button>reFinance?</button>. You change the terms of the loan, and/or payoff a portion.

<li>&#127470;ncome : Terminate (&#128721;)  an income stream. This does <u>not</u> effect current <u>Cash</u> (the acquisition cost is not refunded).
<li>&#66304;nuity : Terminate (&#128721;)  an annuity. This does <u>not</u> effect current <u>Cash</u> (the acquisition cost is not refunded).
</ul>
If you add a new asset, its cost is drawn from <u>Cash</u>.
</td></tr>

<tr><td><em>Note on variants  </td>
<td>
When specifying a portfolio, or an asset, you can assign a <em>variant</em> to it -- by including a <tt>.variantName</tt>.
<br>For example:
<menu class="tightMenu">
<li> The portfolio: <tt>my_portfolio.goodtimes</tt> is assigned to the <tt>goodtimes</tt> variant
<li> The portfolio: <tt>my_portfolio.bads</tt> is assigned to the <tt>bads</tt> variant,
<li> The asset: <tt>stock1.goodtimes</tt>  is assigned to the <tt>goodtimes</tt> variant
<li> The asset: <tt>stock1.bads</tt>  is assigned to the <tt>baes</tt> variant
</menu>
When you assign assets to <tt>my_portfolio.goodtimes</tt>
<menu class="tightMenu">
<li> The asset: <tt>stock1.goodtimes</tt>  is available
<li> The asset: <tt>stock1.bads</tt>  is <u>not</u> available
</menu>
Of particular use: a <em>variant</em> is used when copying a portfolio. Thus: if you first created <tt>my_portfolio.goodtimes</tt> (and
included <tt>stock1.goodtimes</tt>) <br>
... if you copy it to <tt>my_portfolio.bads</tt>:  <tt>stock1.bads</tt> is added (<u>not</u> <tt>stock1.goodtimes</tt>).
 <p>
 Note that assets that do <u>not</u> have a variant are available to all portfolios.
 
 <div style="margin:4px 3em">Instead of specifying variants, consider using
 <button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#showScenarioHelp1">&#127760; Scenarios</button>
 </div>

</td></tr>



</table>  <!-- shortcuts -->


</div>      <!--   portfolioHistoryHelp1   -->


<!-- :::::::::::::::::::::::::;; -->
<!-- help for : hiding portfolios -->

<div id="portfolioTableHiddenHelp" style="display:none" class="helpBox" data-desc="Hiding portfolios" >
<b>Hiding portfolios</b>

To save space on simInv's various menus, you can <u>hide</u> portfolios.

<div style="background-color:yellow;margin:3px 3em 4px 3em">
<b>Why hide a portfolios?</b> If you have portfolios that you are not currently interested in,
  hiding them can save some screen space. And if you become interested in them at some future date, it is easy to unHide them!
</div>

 <u>Hidden</u> portfolios will not be displayed in:
<ul class="tightMenu">
<li>Optionally, the list of portfolios
<li>The  <em> &#128176; portfolio values</em> table
<li>Exported portfolio values
</ul>
Hidden portfolios  <u>not</u> removed .... you can unhide (or hide) a portfolio at any time!

</div>    <!--   portfolioTableHiddenHelp     -->


<!-- :::::::::::::::::::::::::;; -->
<!-- help for : specifing asset mix of  a portfolio -->

<div id="portfolioAssetMix1" style="display:none" class="helpBox"  data-desc="Specifing the asset mix of a portfolio">
<b>Portfolio asset mix </b> <em>You can ... </em>
<ul class="boxList">
<li> view the <span class="notHighlightThisLi"> initial asset mix</span> of a portfolio, or the asset mix of a
<span class="notHighlightThisLi">modification</span>.
<li> <button>Remove</button> a modification (you can <b>not</b> remove the initial asset mix).
<li>
  <button class="cViewSummaryButton">&#129534; </button>  toggle view of the transactions -- a summary of
  sales and purchases for each modification.

<li>
  <button class="cdoButtonModify">Modify </button>  add a new modification
(on a specified date <b>after</b> the initialization date).

<li>
  <button  class="cdoButtonModifySmall">&#119585;</button>  change an existing modification
(but not the initialization entry).

<li>
If this is a modification, and assets were dropped (that were in the prior entry), a  list of
<span class="portfolioMix_dropLine">Dropped assets</span> is displayed below the asset table.
</ul>


<br>
<em>Information for  each asset in an asset mix ... </em>
<table rules="rows" style="margin:2em 1em">
<tr><th>Asset type</th>
<td>Six asset types are supported:
<ul class="linearMenu13Pct">
<li>&#127480;tock
<li>&#127463;ond
<li>&#127299;axDeferred bond
<li>&#127477;roperty
<li>&#127470;ncome
<li>&#66304;nnuity
</ul>
</td></tr>

<!--'&#127480;tock','&#127463;ond','&#127299;axDefer','&#127477;roperty','&#127470;ncome','&#66304;nnuity','&#120793;off'];  -->
<tr><th>Asset name</th>
<td>The name of this asset. In modifications entries, the name may be highlighted:
<ul class="linearMenu22Pct">
<li><span class="portfolioMix_added">Added asset</span>
<li><span class="portfolioMix_change">Changed asset</span>
<li><span class="portfolioMix_oneOff">oneOff asset added</span>
</ul>


</td></tr>
<tr>
<td>$ or # shares</th>
<td>If a  &#127480;tock:  number of shares. The per-price share is also displayed
<br>If a &#127463;ond: $ value
<br>If a &#127299;axDeferred bond: pre-tax $value
<br>If a &#127477;roperty: the sale price
<br>If an &#127470;ncome : the yearly income
<br>Inf an  &#66304;nnuity : the start year income
<br>If a &#120793;off: the receipt from this oneOff (positive or negative)

</td></tr>


<tr><th>Gross value,  cost,
and <span title="approximate net value" style="white-space:nowrap" class="sayNetValue">net Value</span>
</th>
<td>The <em>gross value</em> is the pre-tax (and pre-loan payout) dollar value of this asset.
<br>The <em>net value</em> is after tax (and after loan payout).
<br> The  <span title="acquisition cost" class="sayCost">acquisition cost</span> is what it cost to acquire (purchase) this asset.
<menu class="tightMenu">
<li>
Tax rates on withdrawals (or sales) of assets depends on the asset type, and on the <em>tax free fraction</em>
specified when the asset was created.

<li>For &#127480;tock: and  &#127477;roperty: the <span class="portfolioAssetBasis">basis value</span>  is also displayed. This is calculated using the
<tt>basis</tt> (specified  when the portfolio was created) <u>plus</u> all future purchase of additional shares
(such as dividend earnings, or modifications to the portfolio).
<li>The  <span title="approximate net value" class="sayNetValue">net Value</span> is an <u>approximate</u> measure of the
value of this asset after taxes (capital gains, or deferred taxes) are paid. If there are capital losses, the
capital gains are set to 0 -- hence this is an approximation (when calculating portfolio values, capital losses can
offset capital gains).
<li>The  <span title="acquisition cost" class="sayCost">acquisition cost</span>
  may be less than the initial net value  (say, if you acquired a property at less than market price).
<br>
Note that the sum of all costs, <b>plus</b> the <u>Cash</u> asset,  will equal the budget.


</menu>
</td></tr>

<tr><th>Loan info or growth info</th>
<td>
For &#127477;roperty: the current loan balance (if a loan was used), and the rate and term of the loan
<br>For  &#127480;tock: the yearly dividend payments
<br> For &#127463;ond  and  &#127299;axDeferred bond: the yearly interest rate.
<br> Yearly <em>&plusmn; additions</em> are also shown. These can be required minimum distributions (RMD) -- that use either an <em>own</em>
or <em>beneficiary</em> schedule, and your age (as specfied for this asset).
</td></tr>
<th>net Revenue</th>
<td>
For &#127477;roperty: net rents (rents - costs, pre -tax). Cost do <u>not</u> include mortgage payments
<br> For  &#127470;ncome and &#66304annuity : yearly income (pre-tax);
<p>
Tax info is also displayed (the asset type specific rate, adjusted using an asset's taxFreeFraction)
</td></tr>

<tr><th>Comment</th>
<td>Optional comment </td>
</tr>
</table>

</div>      <!--   portfolioAssetMix1   -->

<!-- :::::::::::::::::::::::::;; -->
<!-- help for : copying the asset mix of  a portfolio -->

<div id="copyPortfolioHelp1" style="display:none" class="helpBox"  data-desc="Copying the asset mix of  a portfolio">
When creating a portfolio, you can <tt>copy the asset-mix</tt> of an existing portfolio. This simplifies creation of similar portfolios.


<p>
In particular: this simplifies creation of different <em>variants</em> --  portfolios with the same asset mix but with different asset histories!
<br>This simplifies comparing different futures -- such as a future where bonds do well versus one where bonds do not do well.
<p>

When copying a portfolio that has a variant (that has as <tt>.variantName</tt> -- simInv will check if an asset (in the copied portfolio)
has a variant. If it does, it will add the verison of the asset in the same variant as the target portfolio (the portfolio being created).

<b>Example</b>:
<menu xclass="tightMenu">
<li> Twos assets in the same <em>stock1</em> family exist: <tt>stock1.goodtimes</tt> and  <tt>stock1.bads</tt>
<li> One asset in the <em>bond1</em> family: <tt>bond1.goodtimes</tt>.
<li>  <tt>stock1.goodtimes</tt> and  <tt>bond1.goodtimes</tt> are  in <tt>my_portfolio.goodtimes</tt>
<li>You copy  <tt>my_portfolio.goodtimes</tt> to the <tt>my_portfolio.bads</tt> target portfolio.

<li>&#8692; <tt>stock1.bads</tt>  is added (<u>not</u> <tt>stock1.goodtimes</tt>)
<li>&#8692; Since <tt>bond1.bads</tt> does not exist, no <em>bond1</em> asset is added.

</menu>

<p>
<b>Note:</b> if there is no asset with the same variant as the target portfolio -- a warning is displayed (and the asset is not included).

</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: display of portfolio values   ::: -->
<div id="portfolioValuesHelp1" style="display:none" class="helpBox"
      data-desc="Display:  viewing the values of your active portfolios over time" >
<b>Display portfolio values on specified dates. </b>
<div style="margin:5px 0.1em">
<menu class="tightMenu">
<li>The table displays the values for your active portfolios
(portfolios where an asset mix has been specified, and which you have not <tt>hidden</tt>).
<li>These values are displayed for the dates specified with
   <button title="Details on selecting display dates"  class="csettingsButton"
      onclick="displayHelpMessage(this,0,1)" data-div="#displayDatesHelp">&#128197; displayDates</button>
<li>You can use
   <button title="Details on plotting display-portfolio-table variables "  class="csettingsButton"
       onclick="displayHelpMessage(this,0,1)" data-div="#displayGraphHelp1">&#128200;</button>
  to plot these values.

<li> Depending on your   <button>&#9965; settings</button>: these values may be <u>fully calculated</u>, <em>interpolated</em>,
or <tt>from prior results</tt>.
</menu>
</div>

<ul class="boxList">
<li>Header row info
<ul class="tightMenu">
 <li> <tt>(&#127760; using scenarioName)</tt> : if a scenario is chosen, this is displayed (where <tt>scenarioName</tt> will be the name of the
 selected scenario)
 <li><span style="font-style:italic;background-color:#eaf8fb;margin:3px 2em;padding:1px 5px"> inflation adjusted</span> : displayed if
 <button>&real;eal values</button> was selected
 <li> <span class="cInterpolatedValue" style="border:1px dotted brown;color:brown">interpolated values</span> : displayed if interpolation is
 used to calculate values
</ul>

<li>The header row buttons:
<ul class="tighterMenu">
<li><button >&Sscr;ave</button>: Save the <b>portfolio values </b> data to a CSV file.
&nbsp;&nbsp;&nbsp;
<button title="Saving display-portfolio-table variables "  class="csettingsButton"
  onclick="displayHelpMessage(this,0,1)" data-div="#exportResultsHelp1">Details on &Sscr;aving &#128176;portfolio values</button>

<li><button>&forall;&#9872;</button> Show, or hide, all cell (<tt>date/portfolio</tt>) summaries;
<li><button>&forall;&#10721;</button> Show, or hide, all cell (<tt>date/portfolio</tt>) summaries of growth &changes
<li><input type="button" value="&#9935;"> opens a popup where you can select which portfolios to display -- non-displayed
portfolios will have their columns temporarily hidden.
<li><button> &real;eal values</button> Display real (inflation adjusted) values -- using multipliers derived from the
  &#206;nflation series.
These &real;eal values are displayed using <em>italics</em>. <br>
You can toggle between nominal and real values!
<br>However,  details (displayed with &#128270;) are not inflation adjusted.
</ul>
<p>

<li>The first row of the table lists the portfolio name, and its comment.
<br>The top row buttons:
<ul class="tighterMenu">

<li><button>&#128468;</button>: Expand table to fill the window. Click again to unexpand.
<li><button>&#8998;</button>: Toggle view of empty rows -- displayDates before any portfolio initialization date.


<li><input value="&#128366;" type="button" > Display (in a popup) a time trend of the assets in this portfolio.
For all the displayDates.
<p> &nbsp;&nbsp;&nbsp;
<button class="viewAssetsOverTimeButtons_hilite">&#128366;</button> signals that interpolated values are displayed --
clicking it will also re-calculate the values (using the full calculations). You can display these fullCalculation values by
clicking <button>Display</button>.

<li><input value="&#127553;" type="button" > displays the asset mix of the portfolio's initialization and modification entries.
If there are modifications, you can use &#8612; and &#8614; to view them.
</ul>


<li>
The second row of the table lists the portfolio initialization date, and its initial budget.

<li>
The remaining rows display values for each of the displayDates. 
<ul>
<li> <div class="cEntryClass0">Rows with this border are <em>initializiation entries</em>
<li> <div class="cEntryClass">Rows with this border are <em>modification entries</em>
</ul>
Each row contains:

<menu class="tightMenu">
<li><span class="cportfolioTable1_netValue">net  value</span>:  the after-tax (and after loan repayment) dollar value of all the assets (including <u>Cash</u>).
Taxes include any capital gains from selling stocks and properties, and income taxes from selling tax-deferred bonds.

<li> If this portfolio/date\'s values are calculated using <em>interpolation</em>, a  <span title="Interpolated: details..."  class="cInterpolatedValue">&#8778;</span> is displayed.

<li><span class="cportfolioTable1_nassets"># assets</span>:  the number of assets in this portfolio mix: stock, regular bonds, tax-deferred bonds,
properties, incomeStreams, annuities, expenses, and oneOffs.

<li><span style="color:#1e5b06;" class="cportfolioTable1_earnings">earnings</span>:
pre-tax earnings= <tt>(incomeSteams+ annuities + Rent  )</tt>  minus  <tt>(loanPayments)</tt>"

<li>A <button>&#8773;</button> indicates a <u>Cash</u> balance near zero.
<br>A <button>&#9872;</button> indicates if you have a
<span  style="background-color:lime;color:darkgreen">large positive</span>,
<span style="color:green">positive</span>,
<span  style="color:red">negative</span>, or
<span style="background-color:yellow;color:red">large negative</span>
<u>Cash</u> balance.
<br>Click it to see a few details!

<li> <button>&#10721;</button>: Click this to display a summary of portfolio growth &amp; changes --
 since the most recent entry -- either the initialization entry, or the most recent modification entry.
If viewing a <span class="cEntryClass"> modification entry</span>:  information on changes to the asset mix is also displayed.


</menu>

<li>
 <button>&#8773;</button>  (or<button>&#9872;</button> ) displays the following information for a <tt>date/portfolio</tt>.
<ul class="noButtonMenu">
  <li><span style="border-bottom:1px dotted blue;font-weight:600">Value:</span> <tt>total portfolio value, including <u>Cash</u></tt>
     <span  style="font-size:80%;margin-left:0.2em; color:green; ">[<u>Cash</u>]</span></li>
   <li><span   Assets: <span title="2 bonds, 1 stocks"> <tt># stocks and bonds</tt> | 
         <tt># properties </tt> |
         <tt># incomeStreams and annuities</tt> |
         <tt># expenses</tt> |
         <tt># oneOffs</tt>
     <br> <tt> # oneOffs  </tt>  are non-zero only if an initialization or modification date
    </li>

   <li> <span  style="padding-left:0.2em;border-bottom:1px dotted blue;font-weight:500">~net assets:
          <tt> after-tax, after loan payout</tt></span>
          <span style="font-weight:700">(</span><span style="font-size:90%"><tt>Gross, pre-tax &amp; pre loan payout, value</tt></span><span style="font-weight:700">)</span>
    </li>
   <li> Revenue: <tt>Yearly preTax earnings = incomeStreams + annuities + Rent  </tt>  <span style="font-weight:700">|</span>
        Loan <span ><tt>Yearly loan payments</tt>
   </li>
   </ul>


</ul> <!-- box list -->


</ul>
<br><em>Notes:</em>
<menu class="tightMenu">
<li>Taxes on  &#127470;ncomes, and &#66304;nnuities, are paid from <u>Cash</u>.
<li> earnings from bonds and stocks are immediately deducted, and the remaining amount is reinvested. Hence:
taxes on dividends and interest earnings are <u>not</u> paid from <u>Cash</u>.
</menu>
</ul>


</div>      <!--   portfolioValuesHelp1    -->


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: chosing displayDates  ::: -->
<div id="displayDatesHelp" style="display:none"  class="helpBox"
      data-desc="Selecting dates to use when displaying portfolio values "  >
<button title="Displaying portfolio values "  class="csettingsButton" onclick="displayHelpMessage(this,0,1)" data-div="#portfolioValuesHelp1">&uArr;</button>

<b>Selecting dates to use when displaying portfolio values </b>
<br>
  <button  class="cdoButtonRegular" >&#128176; Display</button> is used to display a time trend of the value of all your active (and unHidden) portfolios.
  You can specify what dates to display!
<br>

<table cellspacing="5">

<tr> <th valign="top">Earliest and latest dates </th>
<td> the earliest and latest dates displayed. All specified dates (such as an initialization, or custom, date) that is outside
of this bounds will <u>not</u> be used.
</td></tr>

<tr> <th valign="top">Display initialization and modification entry dates </th>
</td>
<td>
You can display dates on which an initialization, or a modification, entry occurs.
A list of all initialization and/or modification dates is created, and values for <u>all</u> of the portfolios
are calculated for each of these dates. That is: even if no modification occured on that date (for a particular portfolio).
<br>
Note that values are always <u>fully calculated</u>  for each portfolio\'s initialization and modifications.
This only controls whether or not to display these values.
</td></tr>

<tr> <th valign="top">Display calendar dates</th>
</td>
<td>
You can use dates that occur on a regular basis. For example: at the start of every year.
Or, at the start of every quarter (Jan 1, Apr 1, Jul 1, and Oct 1).
<br> Note that values for these <em>calendar dates</em> may be calculated using
 <button title="interpolation tips" onClick="displayHelpMessage(this,0,1)" data-div="#portfolioValuesInterpolate1"><u>interpolation</u></button>

</td></tr>

<tr> <th valign="top">Display custom dates</th>
</td>
<td>
You can custom dates to display. You can add as many as you want.
<br>Values will be calculated for each portfolio for each custom date.
Note that <u>full calculation</u> (not interpolation) is used.
</td>
</tr>

<tr> <th valign="top">Current date</th>
</td>
<td>
Add the <em>date of the simInv session</em>. This is dynamic -- it changes each time you run simInv (assuming you run simInv on different days)!
</td>
</tr>

</table>
</div>

<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: display of quick display (using localStorage cache of the Display results html tables) ::: -->
<div id="portfolioQuickDisplay" style="display:none" class="helpBox"
      data-desc="Using quickDisplay (to display Results)"  >
<b>Using quickDisplay (to display  &#128176; Results  </b>
To speed up display, you can select <u>quickDisplay</u> (using   <button class="csettingsButton" >&#9965; Settings</button>).
 This can be much faster than calculating the results... but there are limitations!

<table border="1" style="margin:3px 1em">

<tr><th width="45%">quickDisplay advantages</th> <th width="53%">quickDisplay disadvantage</th></tr>

<tr><td>
<ul>
<li>The table of results is quickly displayed.
<li>Uses your browser's local storage to semi-permanently save information
<li>Displays the most recently calculated <em>full-calculation</em> (or <em>interpolated</em>) portofolio values.
<li>The <em>Fast</em> version of quickDisplay is faster -- it skips a few initialization steps
</ul>
</td>
<td>
<ul>

<li>Whenever anything changes (portfolios, assets, or settings), the  <em>recent full-calculation</em> are deleted.
They will be recreated the next time you use <button> &#128176; Display</button>
<li>
 Viewing details of a portoflio (with <button xclass="viewAssetsOverTimeButtons_hilite">&#128366;</button>) requires information
 not saved to localStorage. Thus: a full calcluation will automatically be done.
<li> Similarly, exporting  or &Scr;aving data requires a full calculation.
<li>The <em>Fast</em> version of quickDisplay requires a longer full calculation (since it skipped some initialization steps)
</ul>

</td>
</tr>
</table>

You can recalculate portfolio values with <button> &#128497;</button> : a <u>full</u> (or <em>interpolated</em>) calculation is done.
<p>You can then view details of a portoflio with <button >&#128366;</button>

</div>



<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: interpolation of portfolio values ::: -->
<div id="portfolioValuesInterpolate1" style="display:none" class="helpBox"
      data-desc="Using interpolation to calculate portfolio values"  >
<b>Using interpolation to calculate portofolio values </b>
<br>
When simInv displays the time trend of your portfolio values (using  <button>&#128176;Display</button>), two calculation methods can be used.
<ol>
<li><u>Full calculation</u>: the value of a portfolio on a given date is calculated by <em>growing</em> (and possibly modifying) the asset mix of the
<em>most recent</em> modification (or initialization) entry for this portoflio.
Where <em>most recent</em> means <em>closest in the past</em>.
<br>  Growth is based on the attributes of the assets in the portfolio
mix (such as interest rates or yearly income) -- all of which can vary over this timespan (between the given date and the most recent date).

<li><u>Interpolation</u>:  the value of a portfolio on a given date is calculated by interpolating between <u>calculated</u> entries
entries that bracket the given date: the dates <em>just before</em> and <em>just after</em> the given date.
Thus: variations in asset attributes (over these bracketing dates) are <u>not</u> considered.

</ol>
<u>Full calculation</u> is more accurate, but can be time consuming.
If there are a lot of dates (say, you chose <tt>quarterly</tt> calendar dates), this could take a minute or more.
<br><u>Interpolation</u> is much quicker, but can be inaccurate; especially if there are large changes to asset attributes during the timespan between
the <em>just before</em> and <em>just after</em> entries.
<br>
<table cellpadding="5">
<tr><th valign="top"><br>Notes:</th>
<td>
<menu>
<li> For each portfolio: initialization and modification dates, and custom dates, use <u>full calculation</u>.
<li> Thus: a <em>just before</em>  (or a <em>just after</em>)  entry can be an initialization entry, a modification entry, or a
custom date entry. 
<br> Thus: only <em>calendar dates</em> may be calculated using <u>interpolation</u>.
<li>Adding custom dates can improve the accuracy of <u>interpolation</u>, at the cost of extra processing time.
<li> You can enable, or disable, interpolation using the  <button>&#9965;</button> settings.
<li> Viewing details of a portoflio (with <button xclass="viewAssetsOverTimeButtons_hilite">&#128366;</button>) will also perform a <u>full calculation</u>
of the portfolio\'s values.
<p>After viewing details, click  <button xclass="cdoButtonRegularBig cdoButtonRegularBig_wow" >&#128176; Display </button>
to display these freshly calculated <u>full calculation</u> values.



</menu>
</td></tr></table>

</div>

<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: plotting Display values -->
<div id="displayGraphHelp1" style="display:none" class="helpBox"
      data-desc="Plotting the Display variables"  >

<button title="Displaying portfolio values "  class="csettingsButton" onclick="displayHelpMessage(this,0,1)" data-div="#portfolioValuesHelp1">&uArr;</button>

<b>Plotting the Display variables</b>
<br>The  <button>&#128200;</button>  -- in the top row of a
  <button>&#128176; Display </button> -- allows you to graph values shown in the table. You can choose which variable, from which portfolio, to graph.
<br><em>For example:</em>
<ul class="tightMenu">
<li>The <tt>totalValue</tt> for several different portofolio
<li>The <tt>totalValue</tt>, <tt>totalAssets</tt>, and <tt>Cash</tt> for one portfolio
<li>The <tt>propertyValue</tt> and <tt>loans</tt> for two different portofolios
</ul>
After selecting what to display, you can graph it. Or you can save a CSV file suitable for use in a presentation program (such as Powerpoint)

</div>

<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: display of price and value  for asset(portfolio values table -->
<div id="portfolioValuesPVInfoHelp1" style="display:none"  class="helpBox"
      data-desc="Portfolio values table: price and  value trends" >
<b>Display <em>Price &amp; value</em> trends ... for assets in a chosen portfolio</b>
<br>The  <button>&#128366;</button>  -- in the header column of the
 <em>&#128176; portfolio values</em> table displays a table of information (prices, values, etc) on each asset in the
 portfolio. Each row is for a viewdate, and each asset (that ever appears in the portfolio) is displayed in the column cells.
 <p>
On each date-specific row:
<menu class="tightMenu">
<li> the first cell is the date, and the date range  -- the number of days since the most recent portfolio modification (or
initialization)

<li> the second first cell is the total portfolio value (including <u>Cash</u>): the value of the portfolio
if all assets were cashed in or sold -- and after taxes and loans paid off.
<li> The third column is the  <u>Cash</u> asset.
<li>The other columns list all the assets that appear (on any date) in the portfolio.
<br>For a given date row, if the asset is not in the portfolio on that date:, the cell is empty.
<br><b>Otherwise:</b>  each cell contains a value: <u>after tax</u> value for: stocks, bonds, and properties; <u>pre-tax</u> for for incomes  and annuities,
 oneOffs and expenses.
 </menu>
You can display more information (in each non-emtpy cell) using &hellip;
<ul class="boxList">
<li> <button>&#129716; growth</button> : for each asset display after tax earnings in the period, and the tax paid.
<li>  <button  >&#128065;  details</button> : Details on  the growth of the asset, in terse format.
<li>  <button  >&#128065;&#65039;  details</button> : Details on  the growth of the asset, in a verbose format
<li>  <button  >&#9878;Compare</button> : Display some comparisons to interpolated values 

</ul>
<b>Comparisons to interpolated values</b>
<div style="margin-left:2em">
<br>If interpolation is used, using <button>&#128366;</button> will re-calculate all values using Full Calculation.
<br> For <u>totalPortfolioValue</u>, and <u>Cash</u>, <button  >&#9878;Compare</button>  will display the fractional difference between the two.
<ul class="tightMenu">
<li><tt>&Equal;</tt>  : Identical -- interpolation not used on this date (for example, this is an initialization or modification date)
<li><tt>~0</tt> : Almost zero: the difference between the two is less than 1% of the Full Calculation value
<li> <tt>x.xx</tt> : The fractional difference:  <tt>(interpolateValue - fullCalclulationValue) / fullCalculationValue</tt>. The absolute value is displayed.
<br>For example: <tt>0.06</tt> means <em>the difference is 6% of the fullCalculation value</em>.
</ul>
</div>

</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: display of price and value  for asset(portfolio values table -->
<div id="fixCashInfo" style="display:none" class="helpBox" data-desc="Cash interest earnings ... and Cash switching sign ">
The impact on interest earnings of additions (or withdrawals) from <u>Cash</u> incorporates interest earnings.
<div style="margin:5px 3em">
 For example: if <tt>$100</tt> (say, in <tt>income</tt>) is added to <u>Cash</u> every day of a 100 day period,
 <ol type="i">
 <li><tt>$10,000</tt> is added
<li>  PLUS 100 days of  interest earnings of the first days deposit of <tt>$100</tt>
<li> PLUS 99 days of interest of the second days deposit of <tt>$100</tt>,
<li> ...
<li> PLUS 1 day of interest earning of the 100th day deposit  <tt>$100</tt>.
</ol>
 If <u>Cash</u> yearly interest is 1%, this would be approximately <tt>$10,013.</tt>
<br>Similarly, withdrawals from <u>Cash</u> reduce the interest earnings of the <u>Cash</u> (as well as reducing its principal).
</div>

The interest earnings (or penalty) are computed every day (within the period) -- using
an interest rate used depends on the <u>Cash</u> balance:
<ul>
<li>If <u>Cash</u> is positive on a given day, the <tt>cashInterest</tt> is used (for example: the daily equivalent of a yearly 1%).
<li>If <u>Cash</u> is negative  on a given day, the <tt>cashPenalty</tt> is used (for example: the daily equivalent of a yearly 6%).
</ul>

For informational purposes: simInv reports what date a sign switch occurrs -- when <u>Cash</u> becomes negative (or becomes positive0.

<div style="margin:5px 3em;border:1px solid blue">
It may be useful to add portoflio modification near the date this switch occurs
</div>






</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: set tax rates and other settings::: -->
<div id="settingsHelp1a" style="display:none" class="helpBox"   data-desc="Customizing user settings " >

<em>Tax rates, interest rates, and other settings </em>

<div style="margin:1em;border:1px solid black">Default budget</div>
The default budget used when creating a portfolio's initialziation entry.

<div style="margin:1em;border:1px solid black">Cash interest</div>
The <u>Cash interest rate</u>, and <u>Cash penalty rate</u> are yearly rates.
They should be a fraction between <tt>0.0</tt> and <tt>1.0</tt> .
<menu  class="tightMenu">
<li>The <u>Cash</u> asset is a remainder: it holds the portion of a budget that is not allocated to assets
<br>It is also used when earnings occur (such as dividend earnings), or expenses paid (such as capital gains taxes)
<li><b>Thus</b>: it can be <tt>&gt; 0.0</tt> or <tt>&lt; 0.0</tt>
<li>When   <tt>&gt; 0.0</tt>: the <u>Cash interest rate</u> is used to increase the size of <u>Cash</u>
<br>When   <tt>&lt; 0.0</tt>: the <u>Cash penalty rate</u> is used to decrease (make more negative) the size of <u>Cash</u>
<li>For example: Positive <u>Cash</u> balances are  in a simple checking account;
 Negative <u>Cash</u> balances are on a credit card
</menu>

<div style="margin:1em;border:1px solid black">Tax rates</div>
The <u>tax rate</u>, and <u>capital gains rate</u> should be a fraction between <tt>0.0</tt> and <tt>1.0</tt> .
<menu  class="tightMenu">
<li>Earnings on   assets:
 <u>tax rate</u> is applied whenever earnings are calculated.
  Earnings are:  the <u>interest</u> of <em>bonds</em>, or the <u>dividends</u> of <em>stocks</em>, income from annuities and
  incomes, widthdrawals from tax-deferred assets, and rents.  Expenses also use this rate (when calculating tax offsets) .<br>
 <u>capital gains</u> is applied whenever a <em>stock</em>, or a property, is sold :
  using the difference between sales price and the   basis.
</menu>
Note that the same tax rates  are used : regardless of timing or total income (this may be changed in a later version of simInv).


<div style="margin:1em;border:1px solid black">Reporting range</div>
The <u>Reporting range</u> is the range of years for which results will be calculated and displayed.
It is used as the default in
 <button title="Tips" onClick="displayHelpMessage(this,false,1)" data-div="#displayDatesHelp">displayDates</button>

<br>Asset and Portfolio entries before (or after) this range are not used
<br>Setting an asset range that is very wide can slow execution down.

<div style="margin:1em;border:1px solid black">Encryption key hint</div>
Optional. A short hint that can help you remember your encryption key. This will be displayed if enabled encryption, and entered an
incorrect encryption key.

<div style="margin:1em;border:1px solid black">Generic warnings</div>
How many warnings to show. You can <tt>show all warnings</tt> or , <tt>suppress minor warnings</tt>

<div style="margin:1em;border:1px solid black">Use interpolation</div>
If there are lot of displayDates, or a lot of portoflios, it can take a while to <button>Display</button> portofolio values.
Enabling <em>interpolation</em> can speed up this process -- but reduces accuracy.
<br>
 <button title="Tips" onClick="displayHelpMessage(this,false,1)" data-div="#portfolioValuesInterpolate1">Interpolation</button>
  is not used for: init entries, mod entries, and custom dates.   It <b>is</b> used for calendar date entries.

<br>Note that using judiciously specified custom entries can reduce interpolation errors.

<div style="margin:1em;border:1px solid black">Use quickDisplay</div>
If you enable quickDisplay, then the results of prior sessions can be used to Display portfolio values.
This can be very quick, especially if the <em>fast</em> variant of quickDisplay is selected.
<br>There is a drawback: if you want to view details, simInv must recalculate (which can take time).
<br>quickDisplay is most useful if you typically just want to review portfolio values, without making changes (to portfolios or to assets).

 <button title="Tips" onClick="displayHelpMessage(this,false,1)" data-div="#portfolioQuickDisplay">details...</button>



<div style="margin:1em;border:1px solid black">How to show a portfolio's entries </div>
When first viewing a  <button>portfolio</button>, there are several ways of display information -- and buttons to get the details --
 on the initialization and modification entries.
You specify which method to use.
<ul class="tightMenu">
<li> A list of small buttons: displaying just the date for the initialization and each modification.
<li> A list of larger rbuttons: displaying  the date, the number of assets, and the netValue
<li>A list of larger buttons. And, a summary table (at the bottom of the page).
Each row of the summary table summarizes the growth, and modifications, of an entry.
<li> A list of small buttons, and the summary table.
<li> The summary table
</ul>
You can toggle between these modes using the  <button>&#128220;</button> icon -- this setting determines what you start with!

<div style="margin:1em;border:1px solid black"><u>Cash</u> warnings</div>
Issue a warning if the <u>Cash</u> is greater that this fraction of the budget (or of the portfolio's netValue).

<div style="margin:1em;border:1px solid black">Future inflation</div>
Number of years to use when estmating future inflation rates. Must be at least 1. For example, <tt>5</tt> means <em>use the average of 
the last 5 entries (one per year)</em>.

<div style="margin:1em;border:1px solid black">Allow more than one asset from the same family</div>
Asset names can have two components: <tt>familyName.variant</tt>. For example <tt>my_stocks.risky</tt> and <tt>my_stocks.safe</tt>
are both in the <tt>my_stocks</tt> family. Using this structure can be way of choosing just one from a set of assets.
<br>You can enforce a <em>one asset per family</em> constraint with this parameter.

<div style="margin:1em;border:1px solid black">Character string to use</div>
Character string to use in headers of CSV export files:
Spaces will not be trimmed -- thus a single space is a legitimate seperator! 
<br> Usage example: the name of an asset\'s attributes,  in the top row of  Export Assets

</div>     <!--   settingsHelp1a   -->



<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: inflation series  ::: -->
<div id="inflationSeriesHelp1" style="display:none" class="helpBox" data-desc="Specifying an inflation series">
<span style="float:right;margin-right:2em">
  <button  class="csettingsButton" title="Notes on scenarios (which can also be used to specify inflation)"
    onclick="displayHelpMessage(this,0,1)" data-div="#showScenarioHelp1">&#127760; Scenarios?</button>.
</span>
<br>

<div style="margin:1em 5em;background-color:#e6e988">
<b>How to account for inflation?</b>
simInv assumes that all prices are entered using <em>nominal</em> values -- values that are <u>not</u> adjusted for inflation.
<p>
While simple to specify: nominal prices can be deceiving, especially when comparing results across a several year timespan.
<p>
The &#206;nflation schedule can help! In particular, you can  <button> &#128176; Display </button> &real;eal values that account for inflation.
And, when specifying future prices and dividends:  you can auto-calculate values using inflation applied to the last entered values!

</div>

<dl>
<dt>Specifying an  &#206;nflation  schedule
</dt>
<dd>
simInv has built-in yearly values of the CPI-u series -- from 1980 to 2023.
</dd>

<dt>You can add values  -- say, for time periods after  Jan 1 2023. </dt>
<dd>
When specifying a new values, make sure it is in the same scale as the existing schedule.
For example, simInv's built-in schedule has  values: <tt>105.5</tt> for 1985, <tt>168.8</tt> for 2000, and   <tt>299.1</tt> for 2023.
<br>
Ambitious users, who prefer some other measure of inflation... can replace all the values (or, edit <tt>simInv_schedules.js</tt>).
</dd>
<dt>
The inflation schedule is similar to asset histories -- linear interpolation is used to find inflation on dates not explicitily
specified.
</dt>
<dd> However, there is a difference when calculating for dates after the final entry.
  <menu>
  <li>For asset values the last specified value is used.
  <li>However, for inflation: simInv uses an average over the final 5 years (specified in the CPI-u series)  for  future inflation --
    the same value is used for all future years.
  </menu>
  <br> You can change this <tt>5 year timespan</tt>  in the &#9965; settings.
</dd>
</dl>
Scenarios can also be used to specify inflation values -- typically for dates in the future (after the last specified inflation value).
Using scenarios is bit less accurate than specifying inflation values (interpolation is used, rather than daily exponential growth) --
but allows for scenario specific inflation schedules!




</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: display portfolio value (read user inputs) ::: -->
<div id="calcPortfolioValueHelpInit1" style="display:none" class="helpBox" data-desc="Display value of a portfolio: initialization">
<ul class="boxList">
<li>After specifying the <b>initial asset-mix</b>  for this portfolio  --
<button>Calculate portfolio value</button> to view summary information.
<li>If the cost of the specified portfolio is above (or below) the <b>proposed budget</b>, 
 the difference (betwween cost and budget) is allocated to <u>Cash</u>.
 <li>If this difference is large, a warning message is displayed.
 <li>You can increase (or decrease) the budget! This is useful if a large portion of the  asset-mix is an <em>endowment</em> -- you own it already.
 </ul>
  A <b>portfolio summary</b> information box is displayed:
<ul class="tightMenu">
<li><b>~netValue</b> : Approximate Net value, accounting for <u>Cash</u>, and accounting for negative capital gains.
 Since this measure does not attempt to allocate capital losses to other income, it is approximate.

<li><tt>non-<u>Cash</u> assets</tt>: the number of assets
&#127480;tock, &#127463;ond, &#127299;axDefer bond, and  &#127477;roperty assets selected; and the number of   &#127470;ncomes &amp; &#66304;nnuities.
<li><tt>~Cost:</tt> approximate cost -- amount needed to obtain the assets. This is the amount used to obtain assets,
including upfront costs for &#127477;roperty  and &#127470;ncome   &amp; &#66304;nnuitiesassets.
This is the cost if you   just purchased these assets -- ignoring the possibilty that you may already own a subset of these assets.


<li><b>Revenue:</b> Sum of (after tax) yearly income and yearly rents. This can be negative!
<li><tt>Loans</tt>: yearly loan payments (pre-tax), and (amount owed on loans).
</ul>


</div>     <!--   calcPortfolioValueHelpInit1   -->


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: display portfolio value (read user inputs) ::: -->
<div id="calcPortfolioValueHelpMod" style="display:none" class="helpBox" data-desc="Display value of a portfolio: modification ">
<ul class="boxList">
<li>After making <b>modifications</b> (removing assets, changing existing assets, or adding new asset) ... use the
<button>Calculate modified value</button> to view your modified portfolio.
<li>To facilitate cross-portfolio comparisons -- you can <u>not</u> quickly increase (or decrease) a portfolio's budget.
<blockquote>
In particular, when modifying a budget <u>Cash</u> may become substantial -- perhaps large negative due to mortgage payments, or
large positive due to an income stream.
</blockquote>

There is a simple workaround --   specify a oneOff   asset.
<br><em>Reminder:</em> oneOffs are recieved after the modification date. That is, it will show up the next day.

</ul>

<table cellpadding="4">
<tr><td width="15%">
  Two information boxes are displayed.
</td>
<td width="80%">
<ul class="tightMenu">
<li>  The <b>Before modification</b> box displays the value of the portfolio as of the
chosen date -- incorporating growth of the asset, but before any modifications.
<li><button>Calculate modified value</button> will display an <b>after modifiocation</tt> box --
with summary information on your modifications to the portfolio.
</ul>
</td></tr></table>

<br>
The fields in each box:
<ul class="tightMenu">
<li><b>netValue</b> : Net value, acounting for <u>Cash</u>, and accounting for negative capital gains.

<li><tt>non-<u>Cash</u> assets</tt>: the number of assets
&#127480;tock, &#127463;ond, &#127299;axDefer bond, and  &#127477;roperty assets selected; and the number of income &#127470;ncome &amp; &#66304;nnuities.
<li><tt>~Cost:</tt> approximate cost -- amount needed to obtain the assets (including reinvested interest and dividend payments).
Since simInv uses aggregation in various calculations (rather than day by day steps) --this is an approximate measure.

<li><tt>pre-tax value</tt> The gross value of the asset it were sold. This is before any taxes (taxes on tax deferred bonds, and capital gains
on stocks and properties). And it is before paying off any loans.
<li><tt>netValueAsset</tt> Net value of assets -- the gross value with taxes paid, and loans paid off. This is calculated for all
assets at once, so negative capital gains are accounted for
<br>It does <u>not</u> incorporate <u>Cash</u>.
<li><tt>&#120491;netRevenue</tt> : After tax value of (<tt>netRevenue</tt> + <tt>income streams</tt>) -- since the initialization or most recent modification.
 The <tt>tax was</tt> is that was tax paid.
<li><tt>&#120491;loanPayment</tt> : Total loan payments (both principal and interest) -- since the initialization or most recent modification.
<li><tt>unpaidLoans</tt> : Amount owed on loans.

</ul>


</div>     <!--   calcPortfolioValueHelpMod   -->

<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: specify portfolio: adding an asset -->
<div id="calcPortfolioValueAddAsset" style="display:none" class="helpBox" data-desc="Portfolio values: adding assets ">
<dl>
<dt>To add assets</dt>

<dd>  click on a <button>asset name</button> in the  <span style="background-color:#daf7f9;">add an asset table</span>.
<br>
A new row will be added to the list of assets -- you can specify the # of shares, etc.!
<menu class="tightMenu">
<li>If the asset is already in the portfolio, clicking its  <button class="chighlightAssetButton">asset name</button> will highlight
the row (in the portfolio) containing the asset. In other words: you can <u>not</u> have more than one version of the same asset in
a portfolio
<li>If <tt>allow more than one asset from the same family</tt> is <u>disabled</u> -- simInv will check to see if the portfolio already
contains such an asset -- an asset from the same <em>family</em> as the selected asset.  If one exists, you will not be allowed to
add the selected asset.
<br><em>What is an asset's family?</em> The <em>family</em> is the (case insensitive) part of its name before the first <tt>.</tt>.
<br><em>For example:</em> <tt>greatbond.normal</tt> and <tt>greatbond.maybe</tt> are in the <tt>greatbond</tt> <em>family</em>.
<div style="margin:3px 4em">Use  <button>&#9965; settings </button>   to enable (or disable) this check.</div>
</menu>
</dd>

<dt>Remove assets </dt>
<dd>
To remove a row, click  <button>&#10060;</button>
<br><em>When modifying a portfolio</em>... clicking a &#128184;,  &#128176;, or  &#128721; will <em>sell off</em> the asset.
</dd>

<dt>Copy a portfolio (only available when initializing a portfolio)</dt>
<dd>
The <button>Copy a portfolio ...</button> will display a list of current portfolios. Click on a button to copy the
asset-mix of the selected portfolio. That means copying the values of the assets in its <em>initial</em> asset-mix.
<br>Note that copying will skip assets (in the copied from portfolio) that are already in the table.
</dd>
</dl>
</div>     <!--   calcPortfolioValueAddAsset   -->



<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: specify portfolio: adding an asset -->
<div id="portfolioRMDHelp" style="display:none" class="helpBox" data-desc="Portfolio: specifying required minimum distributions">
When adding a tax-deferred asset to a portfolio, you can specify that required minimum distributions (RMD)
be withdrawn from it (on a yearly basis).
Yearly RMD withdrawals are a fraction of the value of an asset (for example: the dollar value of an IRA).
 This fraction is based on one's current age. Basically, the older one is the larger the fraction.
 <br>
  Note that this RMD can start in the future. For example, if you specify a <b>Self</b> RMD, with an age less that 72.
<p>
<input type="button" value="View these fractions" onclick="viewRmdSchedules(1)">
<button style="margin-bottom:5px" title="RMD details..."   onClick="displayHelpMessage(this,false,1,'sayRMD')"
     data-div="#portfolioHistoryHelp1">How are RMDs calculated </button>

<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: specify portfolio: pubic assets -->
<div id="publicAssetsDesc" style="display:none" class="helpBox" data-desc="What are publicAssets ">


  simInv's <tt>publicAssets</tt> are assets (stocks, bonds, and tax deferred bonds) that are <b>public</b> -- they are available on the market.
  <br>simInv users can add one, or many, public assets to the mix of assets <u>available</u>. Where <u>available</u> means
  <em>can be added to a portfolio</em>

<p>

  simInv comes with a number of these publicAssets.
       <button  class="cdoButtonRegular"  >&#127760;Public</button>  will display them.
  <ul class="tightMenu">
  <li>    <input type="button" value="&#10133; Add" > To add (make <u>available</u> a public asset).
  <br>You will be shown a popup menu -- click <input type="button" value="&#10133; Add this public asset" > to add the asset.
  <br>For bond assets -- you should first specify its <tt>Fraction of earnings NOT taxed</tt>

  <li> <button>view entries</button> to view the entries  -- price/dividend/interest over time; and a short and longer description.
  <br>For example: prices and dividends of a stock from 2013 to 2023, using public data available from the web.

  </ul>
<p>
<a href="publicAssets/readme.txt" target="readme">Details on creating new public assets.</a>

</div>     <!--   publicAssetsDesc   -->


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: specify portfolio: refinancint a loan -->
<div id="calcPortfolioValueRefinance" style="display:none" class="helpBox" data-desc="Portfolio entries: refinancing a loan ">
When you enter a modification, you can refinance any of the loans -- using its <button>reFinance?</button>.
<br>You will provide:
<menu class="tightMenu">
<li><tt>Refi amount</tt>: The amount of the refinanced loan.
The default is what you currently own. However....
<ul class="tightMenu">
<li> If <b>less</b> than the currently owed amount: the difference is withdrawn from <u>Cash</u>. For example, to paydown
part of the mortgage
<li> If <b>more</b> than the currently owed amount: the difference is added to <u>Cash</u>. For example, for use in a remodel.
</ul>

<li><tt>New rate</tt>: the loan's interest rate: such as <tt>4.2</tt> for 4.2%.
<li><tt>New term</tt>: the loan's term (in years). The default is the remaining time on the existing loan.
<li><tt>Deduct</tt>: checkbox if the interest payments on the loan are tax deductible.
</menu>
<p>
After specifying the above, <button>&#128065;</button> will display a yearly loan schedule.


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: display portfolio values: all dates for one portfolio tax rates and other settings::: -->
<div id="portfolioValuesTableHelp1" style="display:none" class="helpBox" data-desc="Portfolio values: all dates for a portfolio ">
The cells  in the <em>portfolio values: all dates for one portfolio</em> table
<ul class="tightMenu">
<li><tt>Assets</tt>: # of assets. And the list of assets (you will have  scroll down to see them)
<li><tt>net value   <span class="cportfolioValueGross">gross value</span>  </tt>:
the net (after tax) value of the portfoli. And its   <span class="cportfolioValueGross">gross value (before tax)</span>
value. Note that <em>taxes</em> are taxes on tax-deferred bonds, and taxes on capital gains of stocks.
<
<li><tt>Asset value </tt>: gross value (pre tax) of all assets.
<li><tt>Cash value </tt>: the value of remaining cash.  If positive, this can be thought of as cash in a checking account --
it is where extra cash (that is not allocated to an asset) is placed. If negative, this can be thought of as a credit card --
where funds are obtained when the cost of the assets exceeds the budget. Note that the interest earnings (or interest charges)
on the <u>Cash</u> are specified in the  &#9965;  settings menu.
<li><tt>stockValue</tt>: pre-tax value of all stocks
<li><tt>.. basis <em>(tax)</em></tt>: the basis  and the (capital gains tax) if all stocks were sold.
The capital gains tax is calculated using the capitalGain taxRate, applied to the stockValue-basis (summed over all stocks)
<li><tt>bondValue</tt>: Value of all bonds
<li><tt>... regular</tt>: Value of regular bonds
<li<tt>... tax deferred <em>(tax)</em>: value of tax-deferred bonds. And the tax that would be owed if all of them were withdrawn.
</ul>
</div>     <!--   portfolioValuesTableHelp1   -->



<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: stand alone mode-->
<div id="standAloneHelp1" style="display:none" class="helpBox" data-desc="Using simInv in standAlone mode">
simInv can run in <em>standAlone</em> mode -- no connection to a server is needed -- a <tt>file:///x:/myDirectory/simInv/index.html</tt> url can be used!

<p>
In standAlone mode, all data is saved on your computer, in your browser's storage area. This storage area is accessible only through
your browser. Thus, it is somewhat transient in nature.
<div style="margin:3px 5em">
Hence ... when running in standAlone mode it is wise to frequently backup your simInv data -- using
  <button    class="cdoButtonRegular"  "> &#128194; </button> and
</div>
In standAlone mode: there can be multiple users. You can switch between users with
  <button    class="cdoButtonRegular"  "> &#128511; </button>.

<hr>
&nbsp;&nbsp;<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#localOnlineHelp1">What is onLine mode with local storage?</button>
&nbsp;&nbsp;<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#standAloneHelp2">Comparing standAlone and onLine modes</button>
&nbsp;&nbsp;&nbsp;&nbsp;<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#exportHelp2">Notes on saving standAlone data</button>

</div>

<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: online mode with local storage-->
<div id="localOnlineHelp1" style="display:none" class="helpBox" data-desc="Using simInv in onLine mode with local storage">
simInv can run in <em>onLine</em> mode and use local storage. A connection to a server is needed to run simInv, but all information is
stored on your own computer.

<p>
When using local storage in onLine mode, all data is saved on your computer, in your browser's storage area.
 This storage area is accessible only through your browser. Thus, it is somewhat transient in nature.
<p>
Hence ... when using onLine mode with local storage,  it is wise to frequently backup your simInv data.

<hr>
&nbsp;&nbsp;<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#standAloneHelp1">Using standAlone mode</button>
&nbsp;&nbsp;<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#standAloneHelp2">Comparing standAlone and onLine modes</button>
&nbsp;&nbsp;&nbsp;&nbsp;<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#exportHelp2">Notes on saving standAlone data</button>

</div>



<!-- :::::;  help for: comparing online and stand alone mode-->
<div id="standAloneHelp2" style="display:none" class="helpBox" data-desc="Comparing onLine and standAlone modes">
 simInv can be run in two modes:

<ul>
<li>online mode --  requires a server that supports php 7.0 or above.
<li>standalone mode -- can be run directly from a browser that directly accesses <tt>file:///.../simInv.html</tt> on your computer

<div style="font-weight:600;padding:5px;border-top:2px solid cyan;margin:1em 1em ">
   Advantages and disadvantages
</div>
<table><tr>
<th valign="top" width="15%"> Online mode</th>
<td>
<ul class="tightMenu">
<li> Accessible from anywhere via the web
<li> Requires installation on a http: (or https:) server that
 supports php 7.0 or above
<li>allows php to write files to a directory
<li> Users do not have to worry about file maintenance
<li> Security is not great -- though encryption can help.
<li> It is easy to add, or modify existing, publicAssets.

</ul>
</td></tr>

<th valign="top"> onLine mode -- local storage</th>
<td>
Similar to <b>onLine mode</b>, with ...
<ul class="tightMenu">
<li>  To use your data, you must use access simInv (on the web) from the <u>same</u> computer. Each computer you use has its own set of simInv data!
<li>  Uses local file storage. Some browser installations may not enable local file storage (using indexDB local storage)
<li>  Users are responsible for maintaining files. In particular: archiving local file storage files requires a few steps.
<li>  Fairly secure, so long as users control access to their computer
<li>  Anyone with access to this computer can view all of the simInv users (who are using the same computer)
<li>  Accounts are automatically created -- no admin action needed!
</ul>
</td>
</tr>

<tr>
<th valign="top"> Stand alone mode</th>
<td>
<ul class="tightMenu">
<li>  Accessible from a user's computer -- a file:/// url is used
<li>  Does NOT require a server -- and does not require php
<li>  Uses local file storage. Some browser installations may not enable local file storage using indexDB
<li>  Users are responsible for maintaining files. In particular: archiving local file storage files requires a few steps.
<li>  Fairly secure, so long as users control access to their computer
<li>  Anyone with access to this computer can view all of the simInv users (who are using the same computer)
<li>  public assets can not be easily added or modified
<li>  Accounts are automatically created -- no admin action needed!

</ul>
</td>
</tr>

</table>
<hr>
&nbsp;&nbsp;<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#localOnlineHelp1">What is onLine mode with local storage?</button>
&nbsp;&nbsp;&nbsp;&nbsp;<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#exportHelp2">Notes on saving standAlone data</button>
&nbsp;&nbsp;
<a href="readme.txt" target="readme">More details ... </a>
</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: using an encryption ke portfolio values: all dates for one portfolio tax rates and other settings::: -->
<div id="encryptionKeyHelp1" style="display:none" class="helpBox" data-desc="Using an encryption key">
<div id="encryptionHelp_custom">(userName status displayed here)</div>   <!-- custom message -->
In <em>onLine</em> mode you can use a <em>encryption key</em> for extra security.
The  <em>encryption key</em> is used   ...
<ul class="tightMenu">
<li>As a password
<li>To encrypt your data
</ul>

The data encryption part is important -- even if someone can access (without your permission) the server hosting simInv,
it will be difficult to read the stored data.
<div style="margin:3px 3em;padding:5px">
In other words: if you do <u>not</u> specify an  <em>encryption key</em>, anyone who logons on with your username
 can view &amp; change all your data.
</div>
<div style="margin:1em;background-color:#e6e988">There is a drawback!</div>
When you choose to use an <em>encryption key</em>  &hellip;
<ul class="tightMenu">
<li>You <u>must</u> use it in all future simInv logons
<li>The <em>encryption key</em>  is used to encrypt your data, and is <u>not</u> stored on the server.
<br>That means: it can <u>not</u> be changed.
If you forget it, you will have to re-enter all your data (portfolios and assets), and the admin
will have to reset your account
</ul>
<dl>
<dt>
<em>Specifying a hint</em>
</dt>
<dd>
As a memory aid, when you specify an encryption key (on your first simInv logon) ... you can specify an <tt>encryption key hint</tt> (in the  &#9965;  settings).
</dd>
</dl>
<em>Notes:</em>
<ul class="tightMenu">
<li>If you aren't concerned that your simInv data can be seen by others
(perhaps you use cryptic wording when specifying your asset and portfolios), then it is simpler
to <u>not</u> specify an encryption key!
<li>As an aid, when you specify an  <em>encryption key</em> you can also specify a  hint (in the  &#9965; settings).
 This hint is displayed if you enter the wrong  <em>encryption key</em>.
<li> As an alternative: install simInv on your own computer, and run simInv in <em>standAlone</em> mode.
</ul
</ul>

</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: proposed budget:: -->
<div id="portfolioProposedBudgetHelp1" style="display:none" class="helpBox" data-desc="Initializing a portfolio: the proposed budget">
When you <u>initialize</u> a portfolio you
<menu>
<li>Add assets to it -- specifying the quantity (and other attributes) of each sset
<li> <b>and</b> you specify a proposed budget!
</menu>
<dl>
<dt>
The proposed budget can be thought of as a chunk of $$ to spend on acquiring assets.
</dt>
<dd>
When you <button>calculate portfolio value</button>, simInv will compare the cost of the specified asset-mix against this
proposed budget. If the cost is too high, or too low, a warning message will appear, which lists a few options.
In particular -- you can allocate the overage (or underage) to the <u>Cash</u> asset.
</dd>
<dt>
But what if the asset-mix is something you already own --   you do not have to purchase it?
</dt>
<dd>
In this case, when the warning shows up you should <button>adjust the budget</button> -- and choose a
<u>Cash</u> value that reflects your available <u>Cash</u>. The budget will then be automatically adjusted.
<p><em>For example:</em>
<menu class="tightMenu">
<li> you first specify a <b>proposed budget</b>  of <tt>100,000</tt>
<li> and you have <tt>20,000</tt> in available <u>Cash</u>
<br> and the cost of your pre-existing asset-mix turns out to be <tt>90,000</tt>,
<li>  <button>calculate portfolio value</button> will issue a warning.
<li>Use <button>adjust the budget</button> and specify a value of <tt>20,000</tt> in the <u>Cash</u> input box.
<li>your budget will be adjusted to <tt>110,000</tt>.
</menu>
</dd>
</dl>

</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: specifying scenarios -->
<div id="showScenarioHelp1" style="display:none" class="helpBox" data-desc="Specifying scenarios --  future states-of-the-world ">
&#127760; <u>scenarios</u>  are used by simInv to simulate &amp; compare the performance of portoflios under different
scenarios about the  <em>future state-of-the-world.</em> They are not as fine-grained as using <em>variants</em>, but can be a lot quicker to specify!

<div style="border:1px solid gray;padding:5px 3em;margin-top:1em">How are <u>scenarios</u> used ?</div>

 The basic idea is to specify future values of inflation, <b>and</b> to specify <em>multipliers</em> used when calculating the <em>value of asset attributes</em>.
 <ul class="tighterMenu" style="border:1px solid brown;margin:3px 3em">
 <li>The <em>value of asset attributes</em>   are calculated by matching a date to the
<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#showAssetHistoryHelp1">asset's history...</button>
 -- with interpolation used  when there is no exact match.
 <li>The date is also matched to the entries in the currently selected <u>scenario</u>.
 <li>Multipliers are read from this matching entry, and applied to the calculated <em>value of asset attributes</em>
</ul>

<div style="border:1px solid gray;padding:5px 3em;margin-top:1em">How to add an entry to a <u>scenario</u>?</div>

Using  <button>&#127760; Scenario</button>
you can specify a name, and a date, for a <u>scenario</u> --- and specify <em>inflation</em> and <em>multipliers</em>.
<div style="margin:3px 4em">You can  specify several dates for a <u>scenario</u> -- with different (or similar)
<em>inflation</em> and <em>multipliers</em>.</div>

<div style="border:1px solid gray;padding:5px 3em;margin-top:1em">Inflation ...</div>

<em>Inflation</em> (if specified) values will tweak the inflation series. While you can specify inflation values before the last entry (such as Jan 1 2023) in
the inflation series, typically one will specify guesses of inflation in the future. These scenario-specific guesses
 will be used instead of the <em>average of the last 5 years</em>
 <button  class="csettingsButton" title="Specifying inflation"
    onclick="displayHelpMessage(this,0,1)" data-div="#inflationSeriesHelp1">notes on inflation</button>.


<div style="border:1px solid gray;padding:5px 3em;margin-top:1em">Multipliers ...</div>

There are two kinds of <em>multipliers</em>:
<ul class="tightMenu">
<li>Multipliers applied to all assets of a type. For example: a price &amp; dividend multiplier for all <u>stocks</u>
 <li> Multipliers applied to specific assets.
</ul>

In either case: you specify multiplier values that depend on the type of the asset.
<div style="margin:3px 4em">For example: <tt>interest</tt> for bonds; or <tt>sale price</tt> and <tt>yearly net rent</tt>
 for properties.</div>

<div style="border:1px solid gray;padding:5px 3em;margin-top:1em">Multiplier values ...</div>
<ul class="tightMenu">
<li> <tt>1.0</tt>: do not change
<li> less than 1.0 : reduce the value. For example: <tt>0.8</tt> means <tt>80%</tt> of the calculated value
<li> greater than 1.0 : increase  the value. For example: <tt>1.35</tt> means <tt>35%</tt>  greater than the calculated value
</ul>

<div style="border:1px solid gray;padding:5px 3em;margin-top:1em">How are multipliers used ...</div>
<ol type="i">
<li>For a given date, the <em>value of asset attributes</em>  are calculated (such as a stock price, or the yearly value of an income stream).
<menu><li>If you have <u>not</u> selected a <u>scenario</u>  -- this calculated value is used as is.
<li>If you have, then the given date is matched to the entries in the <u>scenario</u>.
<br>In particular, the <em>most recent date</em> is used.  
</menu>
<li>If the given date is before the earliest entry (for this <u>scenario</u>), the calculated value is used as is
<li>If there is a <em>most recent date</em> a multiplier is looked up (from this <em>most recent date</em> entry).
 <menu>
 <li>If the asset was specifically assigned multipliers, these specifically assigned multipliers are used
 <li>Otherwise, the <em>generic</em> multipliers (for this asset type) are used.
 </memu>
</ol>
Note: linear interpolation is <u>not</u> used! Thus, the last entry (in a  <u>scenario</u>) is used for
all  dates after the date of this last entry.


<div style="border:1px solid gray;padding:5px 3em;margin-top:1em">Examples:</div>
<ul type="tightMenu">
<li>A bond with a calculated interest rate of 2.0%; and the generic <em>bond</em> multiplier is 1.5: <tt>3.0%</tt> is used
<li>A property  with a  calculated  sale price 400,000; and the generic <em>property</em> multiplier is 0.8: <tt>320,000</tt> is used
<li>An expense named <tt>food</tt> with a calculated yearly cost of 12,000;  the generic <em>expense</em> multiplier is 1.2,
and a <tt>food</tt> specific multiplier of <tt>1.5</tt>: <tt>18,000</tt> is used.
<li>An expense named <tt>travel</tt> with a calculated yearly cost of 8,000;  the generic <em>expense</em> multiplier is 1.2, and
there is no <tt>travel</tt> specific multiplier: <tt>9,600</tt> is used.
<li> A scenario with 1 Jan 2026 and 30 June 2027 entries:
 <br>  ... 1 Jan 2026 property multiplier=1.2,  30 June 2027 multiplier=1.4
 <br> The property multipliers on different dates

<table width="80%" cellpadding="3" style="margin-left:3em">
<tr><th>Date</th><th>Multiplier</th><th> </th></tr>
<tr><td> 1 Dec 2025  </td><td>1.0</td> <td>1 Dec 2025 is before the first entry (1 Jan 2026)</td></tr>
<tr><td> 1 Feb 2026  </td><td>1.2</td> <td>Use 1 Jan 2026 as the most recent entry </td></tr>
<tr><td> 30 May 2027 </td><td>1.2</td> <td>Use   1 Jan 2026 as the most recent entry. Note that interpolation is <u>not</u> used!</td></tr>
<tr><td> 3 Sep 2027  </td><td>1.4</td> <td>30 June 2027 (the last entry) as the most recent entry</td></tr>
<tr><td> 15 Mar 2030 </td><td>1.4</td> <td>30 June 2027 (the last entry) as the most recent entry</td></tr>
 </table>

 </ul>


</div>



 <!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for:  Modifying a portfolio: view information -->
<div id="buildPortfolioMenu_others1" style="display:none" class="helpBox" data-desc="Modifying a portfolio: view information ">
The 4th column of the <em>modify a portfolio</em> table displays information on the asset-mix. There are several options,
 which display different information.
<ul class="tightMenu">
  <li><input type="button" value="&#128712;"> Display price, yearly income,yearly loan payments,interest rate, etc. ... as of the modification date. What is displayed depends on the assetType!
  <li><input type="button" value="&#9918;"> Display: cost/value/netValue/netRevenue of the  <u> before modification</u> (&amp; before growth)  asset-mix
  <li><input type="button" value="&#8710;"> Show changes in the asset-mix due to growth (before modification)
  <li><input type="button" value="&#128496;"> Show asset-mix after growth (before modification)
</ul>
Note: use <input type="button" value="Calculate modified values"> to display: cost/value/netValue/netRevenue of the  <u>proposed  modification</u> (&amp; after growth &amp; after modification)  asset-mix
</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: exporting simInv data:: -->
<div id="portfolioTransactionList" style="display:none" class="helpBox" data-desc="Modifying a portfolio: summary of modfication entries growth and changes ">

Details on columns (in the &#129534; <em>list of transactions</em>).
<div style="margin:3px 3em">
<ul class="tightMenu">
<li> <em>Growth</em> is growth of the <em>prior</em> entry's asset mix.
<menu class="tighterMenu">
<li>Growth occurs between the date of the <em>prior</em> entry and the date of the entry.
<li>Growth can be from interest earnings or bond dividends (that are reinvested); from capital gains (increases in stock or property values) that are realized when
the asset is sold; from income earned (from incomeStreams, annuities, or property rents); and from oneOff receipts.
</menu>
<li><em>Modifications</em> are due to  changes in the asset mix (of an after growth asset-mix).
<li>For the initialization (creation) entry -- there is no prior entry (hence no growth or asset-mix-modifications)

</ul>
</div>

<ul class="boxList2">
<li><b>Date</b> : The first row is the portfolio's creation date. Other rows are creation dates of the modifications.
<li><b>Current</b> : After growth and after changes.
<menu class="tightMenu">
<li><b><u>Cash</u>  </b> Amount in the <u>Cash</u> asset -- after growth  and changes.
<li><b> netValue  </b> The net (after liquidation) value of all asests + <u>Cash</u>
</menu>

<li><b>Changes in Cash due to modifications  </b>   : changes in <u>Cash</u> -- due to changes
in  <em>after growth</em> assets.
<menu class="tightMenu">
<li><b>Net  </b> :  Net changes
<li><b>Sales  </b> :  proceeds (from asset sales)
<li><b>Purchases  </b> :  costs (from asset acquisitions)
<li><b>reFinance</b> :   Extra cash from a refinance (or cash deficit if refinance is less than outstanding loan)
</menu>

<li><b>... assets that were modified </b>   :  which assets where changed
<menu class="tightMenu">
<li><b>Sold  </b> :  Assets liquidated (properties, or stocks or bonds completely sold). Also  incomeStreams and annuities that stop.
<li><b>Purchased  </b> :  Assets newly acquired. Note that purchasing an incomeStreams or annuities may require an acquisition cost
<li><b>Changed  </b> :  Stocks or bonds that were changed (increase or decreased)
<li><b>reFinanced</b> :   Property assets that were refinanced
</menu>

<li><b>Changes in <u>Cash</u>: growth &amp additions</b>   :  changes in assets (the prior assets) due to growth (before changes in the asset mix).

<menu class="tightMenu">
<li><b>RevnAT  </b> :  Revenue -- incomeStreams, annuities, and +property rents   (after tax)
<li><b>ExpnAT    </b> :  Expenses -- expense streams (after tax), and -property rents
<li><b>loanAT  </b> :  Loan payments (after tax credits)
<li><b>addRaw  </b> :  Additions to (or withdrawals from) bonds -- raw values.
These include both explicit yearly negative values (<u>Cash</u> used to increase bonds), yearly positive values
(withdrawals from bonds deposited in <u>Cash</u>), and  yearly RMD  withdrawals from  tax-deferred bonds.
<li><b>oneOffs</b> : oneOff receipts. These are received (added to <u>Cash</u>) on the <em>day after</em> the prior entry's date (the date the oneOff was added
to the portfolio).
<li><b>cashInterest</b> :   Interest growth of  (over <b>days</b> days) of: priorEntry<u>Cash</u> + additions to/from bonds + daily  income and expenses + oneOff receipts.
     The priorEntry<u>Cash</u> is the <b>Current <u>Cash</u> </b>.  Daily income and expenses are daily changes to cash (based on asset &amp; date specific
     yearly values), with interest growth occuring daily. Note that simInv uses approximations to calculate daily growth.
</menu>
<li><b>After growth</b>   :  after growth (and before changes)
<menu class="tightMenu">
<li><b><u>Cash</u>  </b> : <u>Cash</u> value: the sum of the prior entry cash and the several <b>Changes in cash</b>
<li><b>netValue </b> :  Liquidation of all assets (after tax)
<li><b>days </b> :  Days between the date of  modification and the date of the <em>prior entry</em>. The prior entry
is either an earlier modification, or the initialization entry.
</menu>
</ul>

<div style="border:1px dotted cyan;margin:1em 3em">
 <u>Cash</u> calculation formula:
<ol type="i">
<li>Start with <b>Current <u>Cash</u></b> from <em>prior entry</em>
<li>Add the 5 columns from <b>Changes in <u>Cash</u> due to growth</b>.
<li> = <b>After growth <u>Cash</u></b>
<li> Add the <b>Net</b> from <b>Changes in <u>Cash</u> due to modifications</b>
<li> = <b>current <u>Cash</u></b>
</ol>
</div>

</div>
<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: exporting simInv data:: -->
<div id="exportArchiveRestoreHelp1" style="display:none" class="helpBox" data-desc="Exporting/archiving/restoring data">

<div> <em>Export &amp; archive simInv data ...</em>
<span style="float:right;margin-right:1em">
Are you looking for help on
 <button  class="csettingsButton" title="Saving portfolio results variables "  onclick="displayHelpMessage(this,0,1)" data-div="#exportResultsHelp1">&Sscr;aving &#128176;portfolio values</button>
</span>
</div>

<ul  class="fingerMenu">

  <li><input type="button" value="Summary stats">
 Create a <tt>CSV</tt> file containing a summary of  all the <u>&#128176; displayed scenarios</u> you viewed during this session --
 since the time you logged on. These can be read by spreadsheets  programs.<br>
 Note that this allows you to compare results from different scenarios, or from the same scenario with and without inflation adjustment.
<br>  These files are <u>not</u> used to import simInv data.
  <p>

<li><input type="button" value="Asset histories"> Save  a <tt>CSV</tt> file containing simInv data -- details on available assets over time.
 This can be read by spreadsheet programs. This is <u>not</u> used to import simInv data.
<p>
&nbsp;&nbsp;
<a href="assetHistory_varList.txt" target="varlist"  class="cdoButton" title="View asset descriptions in a popup window">Description of asset history variables</a>

<p>
<li><input type="button" value="Export"> and <input type="button" value="Import">
<menu class="tightMenu">
<li><input type="button" value="Export"> :
Create a .txt file containing basic simInv data (in a JSON type of format).
This file contains specifications of your assets and portfolios.
<br>You can save this to your computer (and Import it a later dart/place).

<br>Note  in <em>standAlone</em> mode: saving these files to your computer requires that you use
cut &amp; paste  (to a text file or a spreadsheet).
  <br>
<li><input type="button" value="Import"> :

 Import data from .txt file (created using Export).
<div style="margin:5px 3em;border:1px dotted gray"><em>Import</em> means: <em>create simInv data for this user</em>.
 This can be used to recover your simInv data if it becomes corrupted. <br>
Or, you can use this to setup a new user with a different user's asset and portfolio specification.
</div>
</menu>
<p>
<li><button>Create or restore</button><br>

simInv can save its data to an <u>internal archive</u>. <br>
These are used to quickly restore your data, should it become corrupted or otherwise messed up.
<br>
You can create <button>manually saved archive</button>, or restore from an <button>automatically saved archive</button>
or a  <button>manually saved archive</button>


 </ul>



<div  style="background-color:tan;margin-top:1em">Using import and export</div>
  <div style="margin:3px 4em;border:1px solid blue;border-radius:3px">
   You can use export &amp; import to copy assets &amp; portfolios from a different user! Just logon as the original user, export, logon as
 the new user, and import (using overwrite or add)!</div>

 <br> For security reasons: you must cut and paste the Import data into a textbox.
This means you will open (with a text editor)  a previously created Export file -- that you saved on your computer.
 Then, do a simple cut and paste into a textbox; and validate its contents (to make sure it is properly formatted).
<br>It isn't that hard!
</menu>

<p>When importing, you can either:
<menu class="tighterMenu">
<li><b>Overwrite</b> : overwrites <b>all</b> existing data -- your prior portfolios and assets will be removed.
Useful for initializing a new user, or if you somehow deleted (or mangled) your assets &amp; portfolios!
<li><b>Add</b> : adds portfolios and assets that are <u>not</u> currently specified. Useful to add assets &amp; portfolios
created by some other user.
<br>Note: settings and viewDates will <b>not</b> be added (your current values are retained).
</menu>



<div  style="background-color:tan;margin-top:1em">Using auto-archive</div>
<a name="exportArchiveRestoreHelp1_autoArchive"><tt>auto-archive</tt></a> is an alternative method of saving your simInv data.
Auto-archiving saves information to the server (in onLine storage), or to
your computer (if  you are using local storage).
It is less robust than using <button>export</button> and <button>import</button>, but is quicker and easier.
<p>A main advantage of <u>auto-archive</u> is that archiving can be  done <em>automatically!</em>
Every time you sucessfully logon to simInv, simInv can save the most recent simInv data.
 <div style="margin:3px 3em">
 Thus, if your data becomes corrupted, or you make some ill-advised changes-- it is easy to restore your data to the most recent version!
 </div>

<ul class="pointerMenuBlack">
<li>If auto-archiving is enabled, every time you successfully logon ... simInv will <tt>auto</tt> save your data (asset &amp; portfolios).
 <div style="margin:3px 3em">
  <u>succesfully</u> means simInv was able to retrieve its data with <u>no errors detected</u>. In particular: the portfolios and assets are properly specified.
</div>
<li>In addition: you can <tt>manually</tt> archive your data at any time.
 <div style="margin:13px 3em 5px 3em">
A <tt>auto</tt> saved archive will overwrite a prior <tt>auto</tt> archive (from your most recent logon).
Thus: only the data from the most recent <u>sucessful</u> simInv logon is available.
<br>A <tt>manually</tt> saved archive will overwrite a prior <tt>manually</tt> saved archive.
Thus: only the data from the your most recent <u>manual</u> save is available.
</div>

<li>You can restore either the <tt>auto</tt> or   <tt>manually saved</tt> archive at any time.
<div style="border:1px solid yellow;margin:5px 3em">Restoring will <u>overwrite</u> your current simInv data -- so be careful!</div>

<li>When you logon to simInv: if errors are detected, you will be given an opportunity to immediately restore either of these archives.

</ul>
<br><em>Note:</em> Auto (and manually created) archives are for simInv internal use.
Thus: they can <u>not</u> be downloaded   -- and they can not be used to initialize a new user.

<!-- :::::::::::: end of  exportArchiveRestoreHelp1 :::::::::::::;; -->


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: saving summary stats: -->

<div id="doExportImport_summaryStats_help1" style="display:none" class="helpBox" data-desc="Saving simInv summary statistics (on displayed scenarios)">
For every scenario  that you have displayed during the current <u>session</u> -- a set of
<em>summary statistics</em> are stored.  You can save these summary statistics to a CSV file!
<div style="margin:3px 5em 6px 5em;border:2px dotted cyan;border-radius:3px"> A <u>session</u> starts with your most recent logon.  If you logoff (and immediately logon), a new session starts.
Or, if you change assets, portfolios, or scenarios... a new session starts.
</div>

<button>Summary stats</button> displays a menu that allows you to chose ...
 <ul class="boxList">
 <li>Which <u>scenarios</u> to display. Two versions of a scenario may be available: with, or without, inflation adjustment.
 <br>Note that <tt>0</tt> means <em>no scenario</em> chosen -- the values are calculated &amp; displyed <u>without</u> scenario weighting.
 <li>Which <u>portfolios</u> to display
 <li>Which <u>summary statistics</u> to display
 <br>Two shortcuts may be useful:
 <menu>
  <li><button>2</button> : just display  <tt>CPI</tt>  and   <tt>totPortfolioValue</tt>
  <li><button>8</button> :   display
  <tt>dateSay</tt>   <tt>CPI_yy-mm-dd</tt>   <tt>CPI</tt>   <tt>totPortfolioValue</tt>
   <tt>cashAsset</tt>   <tt>totAssetSaleNetAT </tt>   <tt>totYearlyRevenueAT </tt>   <tt> totYearlyExpenseAT</tt>
   <tt>totOneOffReceipt_received </tt>
  </menu>
 <li>Note that for each of these:  <button>&forall;</button> and <button>&empty;</button> will select all, or none, of the choices
</ul>
By default...
<menu class="tightMenu">
<li> Each row contains <u>summary statistics</u> for a seperate date, scenario, &amp; portfolio.
<br>This yields a lot of rows, with relatively few columns. And with a header row with simple names (such as <tt>totPortfolioValue</tt>).

</menu>

If you check the <button>Consolidate?</button>, the output is converted to...
<menu class="tightMenu">
<li>Each row contains  <u>summary statistics</u> for a seperate date.
Within each row: seperate set of columns is created for each scenario &amp; portfolio.
<br>This yields fewer rows, but can have a lot of columns. And with a header row with 3 part names of the form:
<span style="font-family:monospace;white-space:nowrap"> scenario name :  portfolio name : summary statistic name </span>.
For example: <tt> boomTimes : lowrisk : totAssetSaleNetAT </tt>
<div style="border:1px solid green;margin:5px 4em">Consolidation may be useful when using the <button>2</button> or <button>8</button> sets of summary statistics! </div>
</menu>
</ul>

</div>
<!-- :::::::::::: end of  doExportImport_summaryStats_help1 :::::::::::::;; -->

<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: exporting simInv data:: -->
<div id="exportHelp1" style="display:none" class="helpBox" data-desc="Exporting simInv data">
You can export all of your simInv data to a .JSON file. This includes information on assets (including their history),
and on portfolios.
<br>
<ol>
<li>Open the export box using <button title="Tips" onClick="displayHelpMessage(this)" data-div="#exportHelp1">&#128194;</button>
<li> Specify a comment (or use the default)
<li>A new window will open containing a <em>stringified</em> version of the .JSON file.
<li>You can view it in a new windog (using a <em>javascript object viewer</em>)  --  cut/paste its <em>stringified</em>
 contents into the textarea box.
<li>Or you can save it to a file, for later use (or viewing)
</ol>
</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: exporting simInv data:standalone: -->
<div id="exportHelp2" style="display:none" class="helpBox" data-desc="Exporting simInv data: standalone ">
You can archive a user's simInv data to a file on your computer --  information on assets  and on portfolios.
 At a later date you can restore this data -- to the same username, or to a different one.
And you can do this restoration on completely different computer.
<blockquote>
Due to security concerns, javaScript  does not allow direct access to your file system. Thus: archiving and restoring data
requires a few steps. These are described below.
</blockquote>


<ul class="boxList">

<li><button>Archive</button> : archive the current user's simInv data.

<br>You will create (on your computer) a text file that contains a <tt>JSON</tt> version of the current user's simInv data.
<menu>
<li>Click the <button>Copy the archived infornation</button>. This will copy the <em>archived information</em> to your clipboard.
<li>Using your favorite text editor, paste this content (in the clipboard) to a new file.
<li>Save this file (using a name &amp; directory that you won't forget!)
</menu>
Optional: you can <button>Preview</button> the data (to be archived) in a popup window.

<li><button>Restore</button> : restore simInv data from an archive file.

 <br> You will open aa text file that contains a <tt>JSON</tt> version of the current user's simInv data -- a file you created using
 <button>archive</button>.
 <menu>
 <li>Open, using a text editor or viewer, an archive file.
 <li>Copy its entire contents to the clipboard
 <li>Paste this contents into the <span style="border:4px dotted purple;padding:5px">Paste the contents to this textbox </span>
 <li> You can <button>Preview</button> it.
 <li>You can use this data to either <button>Overwrite</button> or <button>Add</button> to the current users's simInv data.
 <ul class="tightMenu">
 <li  <button>Overwrite</button>  will remove any simInv data assigned to the current user, and add simInv data from the archive file.

 <li   <button>Add</button> will add assets and portfolios that are <u>not</u> currently specified for the current user -- including the
 portfolio's (or asset's) history. This is a useful way of adding assets (and portfolios) that are already specified by a different user.
 </ul>
 </menu>

  </ul>

</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: saving results (viewDates by portfolios): -->
<div id="exportResultsHelp1" style="display:none" class="helpBox" data-desc="Saving portfolioValues ">

<div>
<span style="float:right;margin-right:1em">
<button class="csettingsButton" title="Tips" onclick="displayHelpMessage(this,0,1,)" data-div="#portfolioValuesHelp1">Display  &#128176; portfolio values ...</button>
<button class="csettingsButton" title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#exportArchiveRestoreHelp1">Exporting and archiving simInv data</button>
</span>
</div>
<br clear="all">
You can <button>&Sscr;ave</button> information displayed in the most recently displayed  <em>&#128176; portfolio values</em> table.

<div  style="margin:1em 5em;background-color:#e6e988">
<tt>CSV</tt>  data is created and written to a text box on your browser window.
You can <em>copy and paste</em> this CSV  to a text file or spreadsheet.
<br>Or, in onLine mode you can save the contents of this window to a file on your computer.
</div>

There are several types of CSV text files, each containing a different set of simInv data.
Each row of a CSV file contains information about a portfolio on a given date.
For some types, several rows are used for each portfolio/date combinaton (one for each asset).
<p>
The types of CSV  <tt>save</tt> files:

<ul class="boxList2">
<li><b>summary stats</b>: summary statistics about a <tt>date/portfolio</tt> (one row per <tt>date/portfolio, <u>not</u> inflation adjusted)</tt>.
  Includes summary information on:
  <menu class="tightMenu"
  <li> the current (as of the given date) portoflio mix: such as <tt>totPortfolioValue</tt>, and <tt>cashAsset</tt>.
  <li>the <em>growth</em> of the portfolio during the period: such as <tt>totLoanPayPeriod </tt> and <tt>totRevenuePeriod_AT</tt> --
  where <u>period</u> is the time span between the given date and the date of the <em>most recent</em> modification (or initialization) entry.
  <li> If a modification was specified on the given  date: <em>changes</em> due to modifications -- such as
  <tt>totSales</tt> and <tt>totCapGains</tt>
  </menu>

  <input type="button" value="details..." title="Saving portfolio table data" onclick="displayHelpMessage(this,0,1)" data-div="#exportResultsHelp1_summary">

  <div style="margin:5px 5em"> Use
        <button title="Export simInv data: CSV of asset and portfolio info "
          class="cdoButtonRegular" onClick="doExport_menu(this)"> &#128194; </button> to archive inflation adjusted summary stats (from
          all scenarios displayed in this session)
 </div>

<li><b>assetMix: Growth</b>:  the after growth attributes of each asset in a <tt>date/portfolio</tt> (one row for each asset)
The values are <u>after</u> growth, but <u>before</u> modification.

   <br>Thus: these do <u>not</u> include newly added assets,
   and <u>does</u> include assets that have just been removed (if this <tt>date/portfolio</tt> entry is a modification entry).

  <br> Includes:  <tt>earningsPeriodAT</tt>, <tt>changeCashPeriod</tt>, <tt>additionPeriod</tt>, <tt>growthIncome</tt>, &hellip;
   <input type="button" value="details..." title="Exporting simInv data" onclick="displayHelpMessage(this,0,1)" data-div="#exportResultsHelp1_assetGrowth">

<div style="border:1px solid yellow;margin:5px 1em">
If you are using <em>interpolation</em>:  information is only available for portofolios whose <em>details</em>
were displayed using <button>&#128366;</button>.
</div>

<li><b> assetMix:</b> current attributes of each asset in a <tt>date/portfolio</tt> (one row for each asset). The values are
the asset attributes <u>after</u> growth and <u>after</u> after  modifications (if modifications occured on this date).

 <br>Thus, if modifications occured  -- this does include newly added assets, and does <u>not</u> include assets that have just been removed

 <br>Includes: <tt>assetName</tt>, <tt>assetType</tt>, <tt>quantity</tt>, <tt>value</tt>, &hellip;
 <input type="button" value="details..." title="Exporting simInv data" onclick="displayHelpMessage(this,0,1)" data-div="#exportResultsHelp1_assets">

<div style="border:1px solid yellow;margin:5px 1em">
If you are using <em>interpolation</em>:
information is only available for portofolios whose <em>details</em> were displayed using <button>&#128366;</button>.
</div>


</ul>


</div>

<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: savubg portfolio values (viewDates by portfolios): -->
<div id="exportResultsHelp1_summary" style="display:none" class="helpBox" data-desc="Saving simInv portfolioValues: summary">

<button class="csettingsButton" title="Back to: help on saving simInv data" onclick="displayHelpMessage(this,0,1)" data-div="#exportResultsHelp1">&uArr;</button>

The summary variables are a superset of the information displayed in the <button>&#128176; Display </button> table.
  <menu class="tightMenu"
  <li> the current (as of the given date) portoflio mix: such as <tt>totPortfolioValue</tt>, and <tt>cashAsset</tt>.
  <li>the <em>growth</em> of the portfolio during the period: such as <tt>totLoanPayPeriod </tt> and <tt>totRevenuePeriod_AT</tt> --
  where <u>period</u> is the time span between the given date and the date of the <em>most recent</em> modification (or initialization) entry.
  <li> If a modification was specified on this date: <em>changes</em> due to modifications -- such as
  <tt>totSales</tt> and <tt>totCapGains</tt>
  </menu>
<p>
You can view a  <a class="csaveButtonSmall" title="Descriptions of summaryStats variables" href="summary_varList.txt" target="varDesc">&#128462 complete list;</a>


</div>

<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: saving portfolio values : summary (assets by portfolios): -->
<div id="exportResultsHelp1_assets" style="display:none" class="helpBox" data-desc="Saving simInv portfolioValues: assets">
<button class="csettingsButton" title="Back to: help on saving simInv  data" onclick="displayHelpMessage(this,0,1)" data-div="#exportResultsHelp1">&uArr;</button>
The <tt>asset-mix</tt> is the current attributes (such as quantity, and price)
 of each asset in a <tt>date/portfolio</tt> (one row for each asset).
 The values are <u>after</u> growth and <u>after</u>  modifications (if modifications occured on this date).

   <br>Thus: if modifications occured -- this <u>does</u> include newly added assets,
   and does <u>not</u> include assets that have just been removed

<p>
You can view a  <a class="csaveButtonSmall" title="Descriptions of the asset-mix variables" href="assetMix_varList.txt" target="varDesc">&#128462 complete list;</a>


</div>


<!-- :::::::::::::::::::::::::;; -->
<!-- :::::;  help for: saving portfolio values  : asset growth (viewDates by portfolios): -->
<div id="exportResultsHelp1_assetGrowth" style="display:none" class="helpBox" data-desc="Saving simInv portfolioValues: asset growth">
<button class="csettingsButton" title="Back to: help on saving simInv data" onclick="displayHelpMessage(this,0,1)" data-div="#exportResultsHelp1">&uArr;</button>
Description of the <em>assetMix: Growth</em> variables (used to create the <em>portfolio values</em> table).

<br>The <tt>afterMix:Growth</tt> values are <u>after</u> growth, but <u>before</u> modification.
   <br>Thus: these do <u>not</u> include newly added assets,
   and <u>does</u> include assets that have just been removed (if this <tt>date/portfolio</tt> entry is a modification entry).

<p>
You can view a  <a class="csaveButtonSmall" title="Descriptions of assetMixGrowth variables" href="assetMixGrowth_varList.txt" target="varDesc">&#128462 complete list;</a>


</div>
 


`;
