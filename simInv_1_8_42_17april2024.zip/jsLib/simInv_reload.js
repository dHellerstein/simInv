// reload (not relogon!) simiNv data

//=============================
// reload after a change .. with "no auto" and "relogon" options
// and with 'auto logon, if logon"
function doReload(athis) {
   let ethis=wsurvey.argJquery(athis);
   let autoLogon=jQuery.trim(ethis.attr('data-autologon'));
 
   let doAutoArchive=true;
   let e1=$('#statusDivServerResponse_logoff_noAutoArchive');
   if (e1.prop('checked')) doAutoArchive=false;

   let doReLogon=false;
   let e2=$('#statusDivServerResponse_logoff_relogon');
   if (e2.prop('checked')) doReLogon=true ;

   if (doReLogon)   {   // full logon
     let userMe=userName;

     let oof;
     if (autoLogon!='') {      // auto logon using username, and trigger an action button (using its id)
        oof=window.location.protocol + "//" + window.location.host + window.location.pathname+'?username='+userMe+'&autoLogon='+autoLogon ;
    } else {
       oof=window.location.protocol + "//" + window.location.host + window.location.pathname+'?username='+userMe ;
    }
    window.location.href = oof;
    return ;
  }

// if here ... reload!

// (use simInvSummaryResults instead of the full datastore)

   if (simInvDsets['simInvLocalStorage']['enabled']) {       // local storage is being used ..
         getUserData_indexDb(userName,doLogon2_local); // retrieved local stored user data
         return 1;
   }
   
// else server storage
   let encKeyA=simInvGlobals['encryptionKey'];
   let encKeyAmd5=simInvGlobals['encryptionKey_md5'];

    init_simInvStuff(0)         ;  // clear stuff (but not   simInvSummaryResults
    
    encKeyA=simInvGlobals['encryptionKey']=encKeyA;
    encKeyAmd5=simInvGlobals['encryptionKey_md5']=encKeyAmd5;

    $('#mainDiv2').hide();
    $('#mainDiv3').hide();
    $('#portfolioSummary').hide();
    hideStatusMessage(10);
    redisplayHeaderLine(1) ;
 
    let ddata={'todo':'getData','username':userName,'encMd5':simInvGlobals['encryptionKey_md5']};
    $.ajax({
        url: 'phpLib/simInv2.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {

        if (response.hasOwnProperty('error') && response['error']===true) {
              displayStatusMessage(response['errorMessage']);
              toggleStatusMessage(0,0);
             return 1;
        }

       let response2x=simInvData_unstringify(response,simInvGlobals['encryptionKey']);   // decrypt and unstringify -- the return is a js array or object
       if (response2x===null) return false ;

      simInvGlobals['lastUpdateDate']=response2x[1]['updateDate']*1000 ;      // updateDate is php time (not milliseconds)

      simInvGlobals['originalServerResponse']= JSON.parse(JSON.stringify(response2x));  //  this is used by diagnostics (clone it to avoid possible issues)

       let response3=checkUserExistsOnline2_tweak(response2x);  // tweak structure to be what afterLogon expects (to match local storage structure)

      afterLogon(response3,true,doAutoArchive);
      return ;
   });
}
