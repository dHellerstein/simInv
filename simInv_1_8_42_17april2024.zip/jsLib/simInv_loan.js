//========
// make loan info and saves to portfolioLoans cache, or read from portfolioLoans    cache

function getLoanInfo(pname,istart,aname,loanAmount,adateStamp,loanRate,loanTerm,loanTaxDeduct,forceCreate) {  // read from portfolioLoans cache .. might have to create!

    if (arguments.length<9) forceCreate=0;

   if (  forceCreate==1  || !portfolioLoans.hasOwnProperty(pname)  ||
         !portfolioLoans[pname].hasOwnProperty(istart)  ||
         !portfolioLoans[pname][istart].hasOwnProperty(aname) ) {     //  NOt an existing loan

      let daLoan0=figLoanSchedule(loanAmount,loanTerm,loanRate);             // CREATE THE LOAN !!
      let daLoan1=figLoanSchedule_cum(daLoan0,loanAmount,istart);
      daLoan=figLoanSchedule_cumAT(daLoan1,loanTaxDeduct,simInvParams['taxRate'])  ; 

      daLoan['startDate']=parseInt(istart) ;
      daLoan['amount']=loanAmount ;
      daLoan['term']=loanTerm;
      daLoan['rate']=loanRate;
      daLoan['taxDeduct']=loanTaxDeduct;
      let cumMonth=JSON.parse(JSON.stringify(daLoan['cumMonth']));
      delete daLoan['cumMonth'];
      let loanArray=[],lastDate;
      for (let idate in cumMonth)  {
          loanArray.push(parseInt(idate));
          lastDate=idate;
      }
      if (!portfolioLoans.hasOwnProperty(pname)) portfolioLoans[pname]={};
      if (!portfolioLoans[pname].hasOwnProperty(istart)) portfolioLoans[pname][istart]={};
      daLoan['lastMonth_dateStamp']=parseInt(lastDate);
      portfolioLoans[pname][istart][aname] ={'loanSchedule':daLoan,'loanPaymentsDates':loanArray,'loanPayments':cumMonth};   // save to global
   }

// === exists, or created above .. use if
//           if (pname=='p2') alert(pname+' make it '+ adateStamp+' ' +istart);

   let use1=JSON.parse(JSON.stringify(portfolioLoans[pname][istart][aname])) ; // clone it

   let lastMonthDate=use1['loanSchedule']['lastMonth_dateStamp'];
   let firstMonthDate=use1['loanSchedule']['month1_dateStamp'];

// yearPay  loanOwed  prinPaid  interestPaid interestPaidAT monthsPaid
  use1['forDate']=adateStamp ;
  let oof=setEntryDate(adateStamp);
  use1['forDateSay']=oof['sayDate'];
   use1['amount']=use1['loanSchedule']['amount'];         // does not change over course of loan
   use1['yearPay']=use1['loanSchedule']['yearPay'];         // does not change over course of loan
   use1['monthPay']=use1['loanSchedule']['monthPay'];         // does not change over course of loan
   if (adateStamp<firstMonthDate || adateStamp==istart) {  // before first payment, or the day of the loan
         use1['loanOwed']=use1['loanSchedule']['amount'];
         use1['prinPaid']=0 ;
         use1['interestPaid']=0 ;
         use1['interestPaidAT']=0 ;
         use1['monthsPaid']=0 ;
         use1['dateOfPayment']=false;

         return use1 ;
   } else  if (adateStamp>=lastMonthDate) {  // after last payment
        let ug=use1['loanPayments'][lastMonthDate]    ;  // last entry is 0 payment -- the loan is paid off
         use1['loanOwed']=0;
         use1['prinPaid']=ug['cumPrincipal'] ;
         use1['interestPaid']=ug['cumInterest'];
         use1['interestPaidAT']=ug['cumInterestAT']; ;
         use1['monthsPaid']=use1['loanPaymentsDates'].length ;
         use1['dateOfPayment']=false;

         return use1 ;
   } else {                                            // find entry bracketed by loanPaymentsDates
         let  loanPaymentDates=use1['loanPaymentsDates'];
         for (let idd=1;idd<loanPaymentDates.length;idd++) {
              let d1b=loanPaymentDates[idd];
              if (d1b>adateStamp) {         // use prior entry
                d1=loanPaymentDates[idd-1];
                let ug=use1['loanPayments'][d1]   ;
                use1['loanOwed']=ug['owed'];
                use1['prinPaid']=ug['cumPrincipal'] ;
                use1['interestPaid']=ug['cumInterest'];
                use1['interestPaidAT']=ug['cumInterestAT']; ;
                use1['monthsPaid']=idd ;
                use1['dateOfPayment']=d1;
                return use1 ;
              }
         }
    }

    alert('Unable to find loan date info for: '+adateStamp+' ('+firstMonthDate+' to '+lastMonthDate+')');  // shold never happen
    return false;

}          // getLoanInfo

//=============
// front end to getLoanInfo (returns dates specific values, dropping schedules)
function getLoanInfoShort(pname,istart,aname,loanAmount,adateStamp,loanRate,loanTerm,loanTaxDeduct) {  // read from portfolioLoans cache .. might have to create!
  let getVars=['amount','yearPay','monthPay','loanOwed','prinPaid','interestPaid','interestPaidAT','monthsPaid','dateOfPayment','forDate','forDateSay'];
   let use0= getLoanInfo(pname,istart,aname,loanAmount,adateStamp,loanRate,loanTerm,loanTaxDeduct) ;
   if (use0===false) return false;
   let use1={};
   for (let ij=0;ij<getVars.length;ij++) {
       let avar=getVars[ij];
       use1[avar]=use0[avar];
   }
   return use1;
}

//=======================
//  this is called from the asset specification menu (to preview what a loan, given a specified asset price, would look like
function specifyLoanSchedule(athis) {
   let ethis=wsurvey.argJquery(athis);
   let etr=ethis.closest('.assetHistoryRow');
   let aname=ethis.attr('data-aname');
   let eprice=etr.find('[name="assetSalePrice"]');
     let aprice0=(eprice.val());
     let aprice=fixNumberValue(aprice0);
   if (aprice===false  ) {
       alert('Please enter a numeric value for the price of '+aname+' ('+aprice0+') ');
       return 0;
   }

   let amess='<div class="loanSpecsBox">';
   amess+='<b> Loan worksheet.</b> When you add a <u>property</u> asset to a portfolio, you can specify a loan to pay for it.';
   amess+='This worksheet previews what a mortgage may look like.. ';
   amess+='<br>For <u>'+aname+'</u> with a purchase price=<tt>'+wsurvey.addComma(aprice)+'</tt>'  ;
   amess+='<ul>';
   amess+=' <li>Amount: <input type="text" value="'+aprice+'" title="Amount of loan (dollars). " name="loanAmt" size="8"><br>';
   amess+='   <li>Term: <input type="text" value="30" title="Length of loan (years)" name="loanTerm" size="8"><br>';
   amess+='<li>Interest rate: <input type="text" value="4.0" title="Yearly interest rate as percent. Example: 3.0 for 3% interest rate" name="loanRate" size="8"><br>';
   amess+='<li>Appreciation rate: <input type="text" value="1.0" title="Yearly apprecation rate in property price rate as percent. Example: 3.0 for 3% interest rate" name="apprecationRate" size="8"><br>';
   amess+='<li><input type="button" value="Show payment schedule" onClick="specifyLoanSchedule2(this)" data-aname="'+aname+'"  ';
   amess+=  ' data-price="'+aprice+'"  > ';
   amess+='</ul>';
   amess+='<b>Notes:</b>';
   amess+='<menu class="tighterMenu">';
   amess+='<li> If this is a refinance, or you are paying less than market value: the loan can be less than the <tt>price</tt>. Or you may pay part of the price with a downpayment.' ;
   amess+='<li>The <tt>apprecation rate</tt> should be a percent -- say, 3.1 for 3.1% ... and it can be less than 0).<br> It is used to display the trend in the yearly price of the property. ';
   amess+='</menu>';
   amess+='</div>';

   displayStatusMessage(amess);
   toggleStatusDiv(0,2);       // makt it big


}
//================
// calc a loan
function specifyLoanSchedule2(athis) {
   let ethis=wsurvey.argJquery(athis);
   let etr=ethis.closest('.loanSpecsBox');
   let aname=ethis.attr('data-aname');
   let aprice=ethis.attr('data-price');

   let eamount=etr.find('[name="loanAmt"]');
     let amount0=  eamount.val() ;
     let amount=fixNumberValue(amount0);

   let eterm=etr.find('[name="loanTerm"]');
     let aterm0=  eterm.val() ;
     let aterm=fixNumberValue(aterm0);

   let erate=etr.find('[name="loanRate"]');
     let arate0=  erate.val() ;
     let arate=fixNumberValue(arate0);

   let eappr=etr.find('[name="apprecationRate"]');
     let appr0=  eappr.val() ;
     let appr=fixNumberValue(appr0);

   if (aterm===false || arate===false ||   amount===false || appr===false)  {
       alert('Please enter a numeric value for the loan amount ('+amount0+'), term ('+aterm0+'), interest rate ('+arate0+'), and appreciaton rate ('+appr0+') ');
       return 0;
   }

  let amess='For <u>'+aname+'</u>: price='+wsurvey.addComma(aprice)+'   : loan size='+wsurvey.addComma(amount);
  amess+='<br>Loan amount='+wsurvey.addComma(amount)+' :  <tt>'+aterm+'</tt> years @ <tt>'+arate.toFixed(2)+' %</tt>';

  let oof=figLoanSchedule(amount,aterm,arate);
  let monthPay=oof[0];
  let yearPay=monthPay*12;
  let schedule=oof[1];

  let len1= oof[1].length-1 ;

  let oof2=[];
  let cumPrincipal=0,cumInterest=0,wasCum;

  let apprUse=1+(appr/100);
  let price1=aprice;
  for (let iyear=1;iyear<1000000;iyear++) {
    let istart=(iyear-1)*12;
    if (istart>=schedule.length) break;
    for (let ii=0;ii<12;ii++) {
       let iuse=istart+ii;
       cumPrincipal+=schedule[iuse][1];
       cumInterest+=schedule[iuse][2];
    }
    let owed=amount-cumPrincipal ;
     price1=price1*apprUse ;
    let netSale=price1-owed;
    let oink={'cumInterest':cumInterest,'cumPrincipal':cumPrincipal,'owed':owed,'price':price1,'netSale':netSale  };
    oof2[iyear]=oink;

  }                           // [i][endOfYear#,princPaidMonth,interestPaindM

    amess+='<br><em>Yearly status of loan (end of year cumulative amounts). Does not include inflation adjustments.</em> ';
  let mtable='<table cellpadding="3">';
  mtable+='<tr bgcolor="#cfefde"><td>Year</td><th>Owned</th><th>Remaining<br>debt</th><th>interest<br>payments</th><th>appreciated<br>Price</th><th>netSale</th></tr>';
  for (let ioof=1;ioof<oof2.length;ioof++) {
     let aoof=oof2[ioof];
     let aprinc=wsurvey.makeNumberK(parseInt(aoof['cumPrincipal']),20000);
     let aowed=wsurvey.makeNumberK(parseInt(aoof['owed']),20000);
     if (aowed<0.1) aowed=0

     let bprice=wsurvey.makeNumberK(parseInt(aoof['price']),20000);
     let bnetSale=wsurvey.makeNumberK(parseInt(aoof['netSale']),20000);

     let aint=wsurvey.makeNumberK(parseInt(aoof['cumInterest']),20000);
     mtable+='<tr><td>'+ioof+'</td><td>'+aprinc+'</td><td>'+aowed +'</td><td>'+aint +' </td><td>'+bprice+'</td><td>'+bnetSale+'</td></tr>';
  }
  mtable+='</table>';
  amess+=mtable;

 
  displayStatusMessage(amess);
}



//=========================
// compute [monthly payment,  schedule]
// schedule is a matrix, each row being [month#,principalPaidThisMonth,interestPaidThisMonth,cumulativePrincipalPaid]
// (assuming payment occurs at end of month)

function figLoanSchedule(loanAmt,termYears,intrYear )  {

  var bpayment=0,nmonths,pwas,cumPrinc,pPaid,pInt,sline,schedule=[];

  bpayment=montlyLoanAmount(loanAmt,termYears,intrYear) ;
  nmonths=termYears*12 ;
  pwas=0 ;

  for (im=1;im<=nmonths;im++) {
     cumPrinc=principalPaid(loanAmt,bpayment,intrYear,im) ;
     pPaid=cumPrinc-pwas ;
     pInt=bpayment-pPaid ;
     pwas=cumPrinc;

     sline=[im,pPaid,pInt,cumPrinc];
     schedule.push(sline);
  }

  return [bpayment,schedule] ;
}



//=========================
// loan calc functions
///============================
// monthly loan amount calculator
// princ: original loan amount (i.e. 100000 for 100k loan
// termYears : # of years of loan (i.e.; 15 if a 15 year loan with monthly payments)
// intrYear: interest rate as a percent.  (i.e.; 3.1 means 3.1%
//=========================
//http://www.wikihow.com/Calculate-Loan-Payments
function montlyLoanAmount(princ,termYears,intrYear) {

var term=termYears * 12;

// special case: 0 % interset
if (intrYear == 0) {
    intr=0;
    avalue=princ/(termYears*12) ;  // monntly payment
    return avalue;
}
// non 0 % loan

var intr=intrYear/1200 ;   // divide by 100 to convert pct to decimal value (and divide by 12 to convert yearly to monthly rate)

var avalue = princ * intr / (1 - (Math.pow(1/(1 + intr), term)));
return avalue;

}

//===============
// http://www.financeformulas.net/Remaining_Balance_Formula.html
// princiapl paid on loan, after n months (given original amount, interest rate, and monthly payment
// you can use monthlyLoanAmount to compute monthly payment (given origional principal, term (# months of loan), and yearly interst rate
function principalPaid(originalAmt,payment,intrYear,nmonths) {

  var m1,m2,m3,v1,v2,v2a ;
  var intr=intrYear/1200 ;   // divide by 100 to convert pct to decimal value (and divide by 12 to convert yearly to monthly rate)

// special case: 0% interest
  if (intrYear==0) {
    return nmonths*payment;
  }

  m1=Math.pow(1+intr,nmonths);
  v1=originalAmt*m1;

  v2a=(m1-1)/intr;
  v2=payment*v2a ;

  v3=v1-v2 ;
  return  originalAmt-v3;
}

//=======================
// view loan specs (call from specifying a property input cell on the  portfolio init page -- specified in function addARowPortfolioAssetMix)

function specifyLoanScheduleB(athis) {
  let ethis=wsurvey.argJquery(athis);
  let ebox=ethis.closest('[name="loanSpecs"]');

  let ename=ebox.find('[name="portfolioLoanName"]');
  let aname=ename.val();

  let etable=$('#portfolioHistory1');

  let oofD=getCreationDate('#portfolioMenu_initDateBlock');
  let jdate=oofD['dayCount'];

  let aprice= getAssetValue(jdate,aname,'price',1);

  let amount ;
  let eamount=ebox.find('[name="portfolioLoanAmount"]');
  let amount0= eamount.val() ;
  if (amount0.substr(amount0.length-1,1)=='%') {
        amount=amount0.substr(0,amount0.length-1);
        amount=fixNumberValue(amount);
        if (amount!==false) amount=(amount/100)*aprice;
     } else {
        amount=fixNumberValue(amount0);
     }

  let erate=ebox.find('[name="portfolioLoanRate"]');
     let arate0=  erate.val() ;
     let arate=fixNumberValue(arate0);

  let eterm=ebox.find('[name="portfolioLoanTerm"]');
     let aterm0=  eterm.val() ;
     let aterm=fixNumberValue(aterm0);

   if (aterm===false || arate===false ||   amount===false  )  {
       alert('Please enter a numeric value for the loan amount ('+amount0+'), term ('+aterm0+'), and interest rate ('+arate0+')  ');
       return 0;
   }

   let ededuct=ebox.find('[name="portfolioLoanTaxDeductInt"]');
   let aDeduct= (ededuct.prop('checked')) ? 1  : 0 ;

  let amess='For... loan amount='+wsurvey.addComma(parseInt(amount))+' :  <tt>'+aterm+'</tt> years @ <tt>'+arate.toFixed(2)+' %</tt>';

  let oof=figLoanSchedule(amount,aterm,arate);
  let aLoanSchedule1=figLoanSchedule_cum(oof,amount) ;
  let aLoanSchedule=figLoanSchedule_cumAT(aLoanSchedule1,aDeduct,simInvParams['taxRate'])  ;  

  let monthPay=aLoanSchedule['monthPay'];
  let yearPay=aLoanSchedule['yearPay'];
  amess+=' :: Monthly payment='+monthPay.toFixed(2)+' , yearly='+wsurvey.addComma(parseInt(yearPay)) ;

  amess+='<br><em>Yearly status of loan (end of year cumulative amounts)</em>.... ';
  let mtable='<table cellpadding="3">';
  mtable+='<tr bgcolor="#cfefde"><td>Year</td><th>Owned</th><th>Remaining<br>debt</th><th>interest payments</th><th> ...interest<br>payments<br>after tax deduction</tr>';
  for (let ioof=0;ioof<aLoanSchedule['cumYear'].length;ioof++) {
     let aoof=aLoanSchedule['cumYear'][ioof];
     let aprinc=wsurvey.makeNumberK(parseInt(aoof['cumPrincipal']),20000);
     let aowed=wsurvey.makeNumberK(parseInt(aoof['owed']),20000);
     if (aowed<0.1) aowed=0
     let aint=wsurvey.makeNumberK(parseInt(aoof['cumInterest']),20000);
     let aintAT=wsurvey.makeNumberK(parseInt(aoof['cumInterestAT']),20000);

     mtable+='<tr><td>  '+(ioof+1)+'</td><td>'+aprinc+'</td><td>'+aowed +'</td><td>'+aint +' </td><td>'+aintAT +' </td></tr>';

  }
  mtable+='</table>';
  amess+=mtable;


  displayStatusMessage(amess);
}

//==================
// running sums from a a loan schedule generated by   figLoanSchedule
function figLoanSchedule_cum(aschedule,loanAmount,startDateStamp) {

  if (arguments.length<3) startDateStamp=false;
  let useStartDate=startDateStamp,month1_dateStamp=0 ;
  let cumMonth,cumYear=[];
  if (useStartDate!==false) {
       let oof2=setEntryDate(useStartDate)  ;
       let ayear=oof2['year'];
       let amonth=oof2['month'];
       let aday=oof2['day'];
       let oof3=setEntryDate(ayear,amonth,24);    // pay near end of month, could be  before acquistion date... wth, it's just one payment
       useStartDate=oof3['dayCount'];
       month1_dateStamp= useStartDate ;
       cumMonth={};
  } else {
     cumMonth=[];
  }

  let monthPay=aschedule[0];
  let yearPay=monthPay*12;

  let schedule0=aschedule[1];
  let len1= schedule0.length-1 ;

  let cumPrincipal=0,cumInterest=0   ;
  let oink;
  for (let iyear=0;iyear<1000000;iyear++) {
   let istart=(iyear)*12;
    if (istart>=schedule0.length) break;  // no more to do
    for (let ii=0;ii<12;ii++) {
       let iuse=istart+ii;
       cumPrincipal+=schedule0[iuse][1];   // principal payment this month
       cumInterest+=schedule0[iuse][2];     // interest payment this mont
       let owed=loanAmount-cumPrincipal ;
       oink={'cumInterest':cumInterest,'cumPrincipal':cumPrincipal,'owed':owed    };
       if (startDateStamp===false) {
            cumMonth[iuse]=oink;               // payment at end of month i (i=0 is first month)
       } else {
            let oof2=setEntryDate(useStartDate)  ;
            oink['sayDate']=oof2['sayDate'];
            oink['nMonth']=iuse;
            cumMonth[useStartDate]=oink;
            let useStartDate3=useStartDate+31 ;  // pay in "next month"
            let oof3=setEntryDate(useStartDate3)  ;
            ayear=oof3['year'];
            amonth=oof3['month'];
            aday=oof3['day'];
            let oof4=setEntryDate(ayear,amonth,1);
             useStartDate=oof4['dayCount'];       // the date of next payment

         }
    }
    cumYear[iyear]=oink;                 // payment at end of year i (i=0 is first year)

  }
  
  amonthPay_int=cumMonth[month1_dateStamp]['cumInterest'];
  amonthPay_intAT= amonthPay_int ;
  amonthPay_prin=cumMonth[month1_dateStamp]['cumPrincipal'];


  return {'monthPay':monthPay,'yearPay':yearPay,'cumYear':cumYear,'cumMonth':cumMonth,
       'month1_dateStamp':month1_dateStamp,'month1_intAT':amonthPay_intAT,'month1_int':amonthPay_int,'month1_prin':amonthPay_prin} ;

}

//=================
// add "tax deductible mortgate" to output of figLoanSchedule_cum
function figLoanSchedule_cumAT(aLoanSchedule0,isTaxDeduct,taxRate)  {
// add in "after tax deduction" cumInterest
  for (let ii in  aLoanSchedule0['cumYear'] ) {
     let aint=aLoanSchedule0['cumYear'][ii]['cumInterest'];
     if (isTaxDeduct==0) {
        aLoanSchedule0['cumYear'][ii]['cumInterestAT']= aint;
        continue;
     }
     let aintAT=aint*(1-taxRate);
     aLoanSchedule0['cumYear'][ii]['cumInterestAT']= aintAT ;
  }
  let i0=0;
  for (let ii  in  aLoanSchedule0['cumMonth']) {
     i0++ ;
     let aint=aLoanSchedule0['cumMonth'][ii]['cumInterest'];
     if (isTaxDeduct==0) {
        aLoanSchedule0['cumMonth'][ii]['cumInterestAT']= aint ;
        continue;
     }
     let aintAT=aint*(1-taxRate);
     aLoanSchedule0['cumMonth'][ii]['cumInterestAT']= aintAT ;
     if (i0==1)  aLoanSchedule0['month1_intAT']= aintAT;
  }

  return  aLoanSchedule0 ;
}

//============
// compute loan stats -- between two dates. Return false if no loan for this portfolio/date/asset
//     dateStampEntry is the start date of the loan
function computeLoanStanding(pname,dateStampEntry,zasset,date0,date1) {

    if (!portfolioLoans.hasOwnProperty(pname)) return false;
    if (!portfolioLoans[pname].hasOwnProperty(dateStampEntry)) return false;
    if (!portfolioLoans[pname][dateStampEntry].hasOwnProperty(zasset)) return false;
    if (date1<date0) return false ;

    let dates=portfolioLoans[pname][dateStampEntry][zasset]['loanPaymentsDates'];
    let dateFirst=portfolioLoans[pname][dateStampEntry][zasset]['loanSchedule']['month1_dateStamp'];
    let payments=portfolioLoans[pname][dateStampEntry][zasset]['loanPayments'];
    let loanAmount=portfolioLoans[pname][dateStampEntry][zasset]['loanSchedule']['amount']

//    if (pname=='p1') alert('datefirst for '+zasset+' = '+dateFirst);

// special case -- loan has not started yet
    if (date0<dateFirst && date1<dateFirst)  {   // before start of loan for this portfolio/entry/asset
       return {'interestPaidPeriod':0,'interestPaidPeriodAT':0,'principalPaidPeriod':0,
                 'loanPaidPeriod':0,'loanPaidPeriodAT':0,'loanTaxDeductValue':0,
                 'loanOwedStart':loanAmount,'loanOwedEnd':loanAmount,
                 'loanPaidTotal':0, 'loanPaidTotalAT':0,
                 'loanAmount':loanAmount,'date0':date0,'date1':date1,'lastPaymentDate':false};
    }


// special case -- loan is one or fewer days old - set payments to 0 (assume payments are at end of day
    if (date0<dateFirst &&  date1<=dateFirst )  {
       return {'interestPaidPeriod':0,'interestPaidPeriodAT':0,'principalPaidPeriod':0,
                 'loanPaidPeriod':0,'loanPaidPeriodAT':0,'loanTaxDeductValue':0,
                 'loanOwedStart':loanAmount,'loanOwedEnd':loanAmount,
                 'loanPaidTotal':0, 'loanPaidTotalAT':0,
                 'loanAmount':loanAmount,'date0':date0,'date1':date1,'lastPaymentDate':false};
    }

// special case (similar to above): after loan acquistion date  ... assume first monthy payment ( @ month1_dateStamp) occurs after end of day --
  if (dateStampEntry==date1 && date0==date1) {
    return {'interestPaidPeriod':0,'interestPaidPeriodAT':0,'principalPaidPeriod':0,
                 'loanPaidPeriod':0,'loanPaidPeriodAT':0,'loanTaxDeductValue':0,
                 'loanOwedStart':loanAmount,'loanOwedEnd':loanAmount,
                 'loanPaidTotal':0, 'loanPaidTotalAT':0,
                 'loanAmount':loanAmount,'date0':date0,'date1':date1,'lastPaymentDate':false};
  }


    let  gIntpay0,gPrinpay0,gIntpay0AT,loanOwed0,gIntpay1,gPrinpay1,gIntpay1AT,loanOwed1 ;
    let loanPaidTotalAT=0,loanPaidTotal=0;

// cum info for date0
    let ause=false;
    if (date0>dateStampEntry) {                          // loan payjments start day after loan acquired
      for (let jj=dates.length-1;jj>=0;jj--) {
          let adate=dates[jj];
          ause=false;
          if (date0>adate) {        // this is the entry just before ... so use it
                ause=payments[adate] ;
                gIntpay0=ause['cumInterest'];
                gPrinpay0=ause['cumPrincipal'];
                gIntpay0AT=ause['cumInterestAT'];
                loanOwed0=ause['owed'];         // use this as is (no need to adjust using ba
                break;
          }  //    date0   > adate
      }   // for
    }            // special case of date0 = loanStarT date
    if (ause===false) {        // nothing paid yet
           let jdate=dates[0];
           let ause1=payments[jdate] ;
           gIntpay0=0;
           gPrinpay0=0;
           gIntpay0AT=0;
           loanOwed0=loanAmount;         // use this as is (no need to adjust using ba
    }

    let lastPaymentDate;

      for (let jj=dates.length-1;jj>=0;jj--) {
           let adate=dates[jj];
           if (date1>adate) {        // this is the  payment entry just before the target date... so use it
              lastPaymentDate=adate;
              let ause=payments[adate] ; ;
              gIntpay1=ause['cumInterest'];
              gPrinpay1=ause['cumPrincipal'];
              loanPaidTotal=gIntpay1+gPrinpay1;
              gIntpay1AT=ause['cumInterestAT'];
              loanPaidTotalAT=gIntpay1AT+gPrinpay1;
              loanOwed1=ause['owed'];         // use this as is (no need to adjust using ba
              break;
         }     //> adate
      }            // for

    let interestPaidPeriod=gIntpay1-gIntpay0;
    let interestPaidPeriodAT= gIntpay1AT - gIntpay0AT ;

    let principalPaidPeriod= gPrinpay1-gPrinpay0 ;

    let loanPaidPeriod= principalPaidPeriod+interestPaidPeriod ;
    let loanPaidPeriodAT= principalPaidPeriod+interestPaidPeriodAT ;

    let loanTaxDeductValue=interestPaidPeriod-interestPaidPeriodAT ;
    return {'interestPaidPeriod':interestPaidPeriod,'interestPaidPeriodAT':interestPaidPeriodAT,'principalPaidPeriod':principalPaidPeriod,
                 'loanPaidPeriod':loanPaidPeriod,'loanPaidPeriodAT':loanPaidPeriodAT,'loanTaxDeductValue':loanTaxDeductValue,
                 'loanOwedStart':loanOwed0,'loanOwedEnd':loanOwed1,
                 'loanPaidTotal':loanPaidTotal, 'loanPaidTotalAT':loanPaidTotalAT,
                 'loanAmount':loanAmount,'date0':date0,'date1':date1,'lastPaymentDate':lastPaymentDate};

}

//=======================
// view loan specs (click handler for Loan button on a portfolio menu

function specifyLoanScheduleC(athis,loanMess,zasset,loanAmount,loanTerm,loanRate,isTaxDed,startDate) {
  
//  alert([loanMess,zasset,loanAmount,loanTerm,loanRate,isTaxDed,startDate].join(', '))

   if (arguments.length<2) loanMess=false;

   let amess='';
   let noYes=['No','Yes'];

  if (arguments.length<3) {
    let ethis=wsurvey.argJquery(athis);
     zasset=ethis.attr('data-asset') ;
    loanAmount=parseFloat(ethis.attr('data-amount'));
    loanTerm=parseInt(ethis.attr('data-term'));
    loanRate=parseFloat(ethis.attr('data-rate'));
    isTaxDed=parseInt(ethis.attr('data-taxDed'));
    startDate=ethis.attr('data-start');
  }

  let oofD=setEntryDate(startDate);
  let startDateSay=oofD['sayDate'];


  let oof=figLoanSchedule(loanAmount,loanTerm,loanRate);    // month#,principalPaidThisMonth,interestPaidThisMonth,cumulativePrincipalPaid
  let aLoanSchedule1=figLoanSchedule_cum(oof,loanAmount) ;
  let aLoanSchedule=figLoanSchedule_cumAT(aLoanSchedule1,isTaxDed,simInvParams['taxRate'])  ;

  let sayAmount= wsurvey.makeNumberK(loanAmount,10000000,2) ;
    amess+='<br><b>'+zasset+'</b> loan status (start date: '+startDateSay+'). ';
    let monthPay=parseInt(aLoanSchedule['monthPay']), yearPay=parseInt(aLoanSchedule['yearPay']);
    amess+='<span title="yearly payment: '+yearPay+'">Monthly payment: '+wsurvey.addComma(monthPay)+' </span> ';
    if (loanMess!==false) amess+='<span style="font-style:oblique;margin:3px 1em 3px 1em">'+loanMess+'</span>';


    amess+='<br>Starting amount=<tt>'+sayAmount+'</tt></em> ';
    amess+='| Rate='+loanRate.toFixed(1)+' | Term='+loanTerm + '| tax deductible interest='+noYes[isTaxDed];

   amess+='<div style="border-top:1px solid green;font-style:oblique">end of year cumulative amounts</div>'
  let mtable='<table cellpadding="3">';
  mtable+='<tr bgcolor="#cfefde"><td>Year</td><th>Owned</th><th>Remaining<br>debt</th><th>interest payments</th><th> ...interest<br>payments<br>after tax deduction</tr>';
  for (let ioof=0;ioof<aLoanSchedule['cumYear'].length;ioof++) {
     let aoof=aLoanSchedule['cumYear'][ioof];
     let aprinc=wsurvey.makeNumberK(parseInt(aoof['cumPrincipal']),20000);
     let aowed=wsurvey.makeNumberK(parseInt(aoof['owed']),20000);
     if (aowed<0.1) aowed=0
     let aint=wsurvey.makeNumberK(parseInt(aoof['cumInterest']),20000);
     let aintAT=wsurvey.makeNumberK(parseInt(aoof['cumInterestAT']),20000);
      let ioof2=ioof+1;
     mtable+='<tr><td>'+ioof2+'</td><td>'+aprinc+'</td><td>'+aowed +'</td><td>'+aint +' </td><td>'+aintAT +' </td></tr>';

  }
  mtable+='</table>';
  amess+=mtable;


  displayStatusMessage(amess);
}

