//======================
// make and display html table of  asset Details  -- by day. Yearly interest for bonds, current price and yearly dividend for  tocks
// &#127480; S blue  ,  &#127463; B blue,  &#127299;  T box      &#9332; (1)   &#9450; circle 0

function showAllAssetDetailsHtml(ifoo) {

  if (!simInvDsets['assetValues_byDate'].hasOwnProperty('created')) {    // not yet created ...
     displayStatusMessage('Building table of trends in asset values ...');
     let assetLookupDates=makeAssetValues_useDates(1);
     calcAssetValues_all(assetLookupDates );   // populate the assetValues_byDate global
      makeAssetDetails_histCum(1);               //  populate the  assetDetailsCum  global
     calcAssetValuesCum_all(simInvDsets['assetDetailsCum']['dates']) ;          //   populate the   assetValuesCum_byDate  global
     displayStatusMessage('<br>... completed! ',1);
  }
 
  let ascenario=simInvParams['scenarioUse'] ;

  if (simInvDsets['assetDetailsCum']['dates'].length==0) {        // should never happen
      alert('No asset entries! ');
      return false;
  }
  let firstDate=simInvDsets['assetDetailsCum']['dates'][0];

   let calendarAdds= simInvDsets['assetDetailsCum']['calendarAdds']  ;         // dates with at least one asset with an entry ([0] is earliest date with an asse with an entry
   let allExist= simInvDsets['assetDetailsCum']['allExist']  ;         // dates with at least one asset with an entry ([0] is earliest date with an asse with an entry

  let existDates=simInvDsets['assetDetailsCum']['existDates'];
  let calendarDates=simInvDsets['assetDetailsCum']['calenderAdd']
   let doAssets=[];
   for (let anasset in simInvDsets['assetDetailsCum']['assets']) doAssets.push(anasset);
   let assetsSay=doAssets.join(',');
   let ahtml='';

   ahtml+='<input type="hidden" id="assetTable_assetList" value="'+assetsSay+'"> ';
   ahtml+='<div  id="assetTable_choseMenu"  class="cassetTable_choseMenu" ></div>' ; // for pick assets menu

  ahtml+='<div style="background-color:cyan">';
  ahtml+='<a name="showDetailsTop">&nbsp;</a> ';
  ahtml+='<a href="#showDetailsDesc" title="View some descriptive notes">&#127901;</a> ';
  ahtml+='<span style="font-style:oblique -45deg">Asset summary</span> for <u>'+userName+'</u> @ '+wsurvey.get_currentTime(31,1)
  if (ascenario!='') ahtml+='... using &#127760; <b>'+ascenario+'</b>    <u>scenario</u>';

// 30 dec 2023... doesn't work well with frozen columns. Instead, pick assets BEFORE generating table
// ahtml+='<span style="float:right;margin-right:1em">';
// ahtml+='<button class="cdoButtonRegular" display"="" title="Choose which assets to display" onclick="showAllAssetValues_pick(this)">&#9935;</button>';
// ahtml+='</span>';
  ahtml+='</div>';

  ahtml+='<div id="assetValuesTableDiv" class="cassetValuesTableDiv">';

  ahtml+='<table id="assetValuesTable" class="cassetValuesTable" cellpadding="3" border="1"> ';

  ahtml+='<colgroup>';
  ahtml+='<col style="color:blue" title="Date">';
  ahtml+='<col style="color:blue" title="Inflation">';
  for (let ijj=0;ijj<doAssets.length;ijj++) {
    let ij2=ijj+1;
    ahtml+='<col data-nth="'+ij2+'"  title="Asset: '+doAssets[ijj]+'" style="color:green;font-size:200%;visibility:visible">';
  }
  ahtml+='</colgroup>';

  ahtml+='<tbody>';

  let atr1='',atr2='';

  atr1+='<td class="freezeRow1Col1">date</td>';
  atr1+='<td class="freezeRow1Col2" >&#205;nflation</td>';

  let aabutton='<input type="button" value="&#128295;" title="pick attributes to display" onclick="showAllAssetValues_pickAttributes(this)" >';
  atr2+=' <td class="freezeRow2Col1" >'+aabutton+' </td>';
  atr2+=' <td class="freezeRow2Col2" > </td>';

// header row (asset names, list of displayed attributes)
// and 2nd header row (variable names)

  for (let aName in  simInvDsets['assetDetailsCum']['assets']) {

     let aNameUse=aName;
     if (aName.substr(0,1)=='_') {
         aNameUse='<span title="a public asset">&Pscr;_ </span>'+aName.substr(1);
     }
     let assetType=getAssetType(aName) ;
      let aextra=aNameUse;
      if (assetType==5) {
           aextra='<span title="Annuity fixed on acquisition, with a growth rate" style="font-style:oblique;font-size:85%">'+aNameUse+'</span>';
      }
     let aIcon=getAssetType(assetType,'icon');

     let abutton='<input type="button" value="&#664;" onClick="showAllAssetValues_highlight(this)" title="highlight this column" data-hilite="0" data-which="'+aName+'">' ;
     atr1+='<th class="freezeRow"><div style="min-height:2em" > '+abutton+' '+aIcon+' '+aextra+'</div></th>';

     let dd='';
     if (assetType==0) {
         dd+=' <span name="assetTableAttribute_price" title="Price per share"  style="border:1px solid gray;font-family:monospace">Price</span>';
         dd+=' <span  name="assetTableAttribute_dividend" title="Yearly dividend rate per share "  style="border:1px solid gray;font-family:monospace">Dividend</span>';
         dd+=' <span name="assetTableAttribute_cumGrowth" title="Cumulative after-tax growth (per share multiplier). Pre-tax: ..." style="border:1px solid gray;font-family:monospace">cumGrowth</span>';
         dd+=' <span  name="assetTableAttribute_cumDividend" title="Cumulative after-tax dividends (per share). Pre-tax: ..." style=" border:1px solid gray;font-family:monospace">cumDividend</span>';
     } else if (assetType==1 || assetType==2 ) {
         dd+=' <span name="assetTableAttribute_interest" title="Yearly interest rate per share "  style="border:1px solid gray;font-family:monospace">Interest</span>';
         dd+=' <span name="assetTableAttribute_cumGrowth"  title="Cumulative after-tax growth (per share multiplier). Pre-tax: ..." style="border:1px solid gray;font-family:monospace">cumGrowth</span>';
     } else if (assetType==3) {
            dd+=' <span name="assetTableAttribute_price"  title="Sale price"  style="border:1px solid gray;font-family:monospace">salePrice</span>';
            dd+=' <span name="assetTableAttribute_rent"   title="Yearly netRent: earnings-costs. Costs include mortgate interest payments"  style="border:1px solid gray;font-family:monospace">rent</span>';
            dd+=' <span name="" title="Cumulative after tax earnings (can be negative). Pre-tax: .." style="border:1px solid gray;font-family:monospace">cumEarn</span>';
     } else if (assetType==4) {
            dd+=' <span  name=""  title="Yearly income (pre tax)"  style="border:1px solid gray;font-family:monospace">Income</span>';
            dd+=' <span  name="assetTableAttribute_cumEarn"  title="Cumulative after tax earnings (can be negative). Pre-tax ..." style="border:1px solid gray;font-family:monospace">cumEarn</span>';
     } else if (assetType==5) {
            dd+=' <span  name="assetTableAttribute_income"  title="Yearly annuity  income (pre tax)"  style="border:1px solid gray;font-family:monospace">Income</span>';
     } else if (assetType==6) {
            dd+=' <span  name="assetTableAttribute_receipt"  title="oneOff receipt(pre tax)"  style="border:1px solid gray;font-family:monospace">Receipt</span>';
     } else if (assetType==7) {
            dd+=' <span  name=""  title="Yearly expense (pre tax offset)"  style="border:1px solid gray;font-family:monospace">Expenses</span>';
            dd+=' <span  name=""  title="Cumulative pre-tax expenses. Pre-tax ..." style="border:1px solid gray;font-family:monospace">cumExpense</span>';
     }
     atr2+='<td  class="freezeRow2">'+dd+'</td>';   // list of attributes displayed in each cell (in this col)

  }

  let atr1b='<tr class="c_existDate c_calendarDate">'+atr1+'</tr> ';       // asset row  ( the c_ classes are  a small
  let atr2b='<tr  class="c_existDate c_calendarDate" bgcolor="pink">'+atr2+'</tr>'      ; // var name rows

  ahtml+=atr1b+atr2b ;

// one row for each date   -- dates with at least one asset history entry, or with auto generated dates (i.e. jan 1 xxxxx)

 for (let aDate in simInvDsets['assetValuesCum_byDate']) {
    if (aDate<firstDate) continue ;    // should never happen
     let oofx=setEntryDate(aDate);
     let adaySay=oofx.sayDate;

     let sayTr='' ;
     if (allExist.hasOwnProperty(aDate))     sayTr+='c_existDate';
     if (calendarAdds.hasOwnProperty(aDate))   sayTr+=' c_calendarDate';
     sayTr=jQuery.trim(sayTr);
     if (sayTr!='') sayTr=' class="'+sayTr+'" ';              // should always be tru
     let atr='<tr '+sayTr+' title="'+adaySay+'" >';

     atr+=' <td class="freezeColA"><span title="'+aDate+'"> '+adaySay+'</span></td>';

     let gfactor=calcInflation(firstDate,aDate);
     atr+='<td class="freezeCol2">'+parseFloat(gfactor).toFixed(3)+'</td>';

     let aclass=' class="cAssetTableHtml " ';

     for (let aName in  simInvDsets['assetDetailsCum']['assets']) {

        if (!simInvDsets['assetValuesCum_byDate'][aDate].hasOwnProperty(aName)) continue ;  // probably an asset with no history

        let ahist=simInvDsets['assetValuesCum_byDate'][aDate][aName];

        if (ahist===false) {            // no values as of this date
              let dd='<td><div name="assetTableCol_'+aName+'"  title="Asset: '+aName+' @ '+adaySay+': before first history entry "  style="border:1px solid gray">&hellip;</div></td>';
              atr+=dd;
              continue;
         }

        let assetType=ahist['type'];
        let isExist=ahist['existing'];   // if 1, this is from an actual history entry (for this asset on this date). 0: interpolated

       let aclass=' class="cAssetTableHtmlSpan " ';

         let dd;
         if (isExist==1) {
            dd='<td><div  name="assetTableCol_'+aName+'"  title="Asset (explicit entry): '+aName+' @ '+adaySay+'" style="border:2px solid purple">';
         } else {
            dd='<td><div  name="assetTableCol_'+aName+'"  title="Asset (imputed entry): '+aName+' @ '+adaySay+'" style="border:1px solid tan;padding:1px">';
         }

         if (assetType==0 ) {   // bond (regular or tax deferred)
         // showDebug(ahist,aDate+' anahsit showAllAssetDetailsHtml ',1);
            dd+=' <span   name="assetTableAttribute_price" title="Price per share" '+aclass+' >';
              dd+=ahist['price'].toFixed(1) ;
            dd+='</span>';
            dd+=' <span  name="assetTableAttribute_dividend"  title="Yearly dividend rate per share " '+aclass+'>';
              dd+=ahist['dividend'].toFixed(2) ;
            dd+='</span>';
            dd+=' <span  name="assetTableAttribute_cumGrowth"   title="Cumulative after-tax growth (per share multiplier). \nPre-tax: '+ahist['growthCum'].toFixed(6)  +'"'+aclass+'>';
               let v1=ahist['growthCumAT'],v1use;
               if (Math.abs(v1-1.0)<0.001) {
                   v1use="~1.0";
               } else {
                  v1use=v1.toFixed(3) ;
               }
               dd+=v1use;
             dd+='</span>';

            dd+=' <span  name="assetTableAttribute_cumDividend"   title="Cumulative after-tax dividend payments (per share).\nPre-tax: '+ahist['earningsCum'].toFixed(6)  +'"'+aclass+'>';
               let v1I=ahist['earningsCumAT'],v1IUse;
               if (Math.abs(v1)<0.001) {
                   v1IUse="~0.0";
               } else {
                  v1IUse=v1I.toFixed(1) ;
               }
               dd+=v1IUse;
             dd+='</span>';


         } else if (assetType==1 || assetType==2) {   // bond (regular or tax deferred)
            dd+=' <span  name="assetTableAttribute_interest" title="Yearly interest rate" '+aclass+'>';
              dd+=ahist['interest'].toFixed(3) ;
            dd+='</span>';
            dd+=' <span name="assetTableAttribute_cumGrowth"  title="Cumulative after-tax growth (per share multiplier). Pre-tax: '+ahist['growthCum'].toFixed(6)  +'"'+aclass+'>';
               let v1=ahist['growthCumAT'],v1use;
               if (Math.abs(v1-1.0)<0.001) {
                   v1use="~1.0";
               } else {
                  v1use=v1.toFixed(3) ;
               }
               dd+=v1use;
             dd+='</span>';

         } else if (assetType==3 ) {

            dd+=' <span  name="assetTableAttribute_price"  title="Sale price"  '+aclass+'>';
               dd+=wsurvey.makeNumberK(parseInt(ahist['price']),50000);
            dd+='</span>';
            dd+=' <span  name="assetTableAttribute_rent"  title="Yearly netRent: earnings-costs. Costs include mortgage interest payments"'+aclass+'>';
              dd+=wsurvey.addComma(parseInt(ahist['rent']));
            dd+='</span>';
            dd+=' <span  name="assetTableAttribute_cumEarn"  title="Cumulative after tax earnings (can be negative). Pre-tax: '+ahist['earningsCum'].toFixed(1)  +'" '+aclass+'>';
               let v1use=wsurvey.makeNumberK(parseInt(ahist['earningsCumAT']),50000);
               dd+=v1use;
             dd+='</span>';

         } else if (assetType==4 ) {
            dd+=' <span  name="assetTableAttribute_income"  title="Yearly income (pre tax)"  '+aclass+'>';
              dd+=wsurvey.addComma(parseInt(ahist['income'])) ;
            dd+='</span>';
            dd+=' <span  name="assetTableAttribute_cumEarn"  title="Cumulative after pre-tax: '+ahist['earningsCum'].toFixed(1)  +'" '+aclass+'>';
               let v1use=wsurvey.makeNumberK(parseInt(ahist['earningsCumAT']),50000);
               dd+=v1use;
             dd+='</span>';

         } else if (assetType==5 ) {
            dd+=' <span  name="assetTableAttribute_income"  title="Yearly annuity (pre tax) -- if acquired on this date"  '+aclass+'>';
            dd+=wsurvey.addComma(parseInt(ahist['income'])) ;
            dd+='</span>';
            let v1use='<span title="depends on acquisition date">&hellip;</span>';
           dd+=v1use;


         } else if (assetType==6 ) {
            dd+=' <span  name="assetTableAttribute_receipt"  title="oneOff receipt"  '+aclass+'>';
              dd+=wsurvey.addComma(parseInt(ahist['receipt'])) ;
            dd+='</span>';

         } else if (assetType==7 ) {
            dd+=' <span  name="assetTableAttribute_expense"  title="Yearly expense (pre tax)"  '+aclass+'>';
              dd+=wsurvey.addComma(parseInt(ahist['expense'])) ;
            dd+='</span>';
            dd+=' <span  name="assetTableAttribute_cumExpense"  title="Cumulative, after tax. Pre-tax value='+ahist['expensesCum'].toFixed(0)  +'" '+aclass+'>';
               let v1use=wsurvey.makeNumberK(parseInt(ahist['expensesCum']),50000);
               dd+=v1use;
             dd+='</span>';

         }         // assettype

         atr+=dd+'</div></td>';

     }    // this aName


     atr+='</tr>';
     ahtml+=atr;
  }      // this daate

  ahtml+='</tbody>'    ;
  ahtml+='</table>'    ;
  ahtml+='<div style="margin-top:2px;font-size:80%;opacity:0.66;color:#0057ff;padding-left:10em">  .. asset summaries ... </div>';

  ahtml+='</div>'    ;

  ahtml+='<div style="margin:1em;background-color:cyan"><a href="#showDetailsTop">&uarr;</a> <a name="showDetailsDesc">&#127901;Key</a></div>';
  ahtml+='<ul class="boxList">';
  ahtml+='<li><span>Dates have an assetHistory entry (for at least one asset) </span>.';
  ahtml+='<span class="cAssetTableHtmlSpanHist ">Asset specification entries</span> are highlighted (calculation and Interpolation not needed) ';
  ahtml+='<br><tt>cumGrowth</tt>, <tt>cumDividend</tt>, and <tt>cumEarn</tt> values are <u>after tax</u>, and are relative to the first entry for an asset. ';
  ahtml+='<br><tt>interest</tt>, <tt>income</tt>, <tt>price</tt>, <tt>salePrice</tt>,   <tt>rent</tt>, and <tt>receipt</tt> values are  <u>pre tax</u>, ';
  ahtml+=' and are <em>yearly values</em> as of that date. ';
  ahtml+='<li><em>Asset Types</em>: ';
  ahtml+=getAssetType(0,'icon')+' '+getAssetType(0,'sayslong')+' | ';
  ahtml+=getAssetType(1,'icon')+' '+getAssetType(1,'sayslong')+' | ';
  ahtml+=getAssetType(2,'icon')+' '+getAssetType(2,'sayslong')+' | ';
  ahtml+=getAssetType(3,'icon')+' '+getAssetType(3,'sayslong')+' | ';
  ahtml+=getAssetType(4,'icon')+' '+getAssetType(4,'sayslong')+' | ';
  ahtml+=getAssetType(5,'icon')+' '+getAssetType(5,'sayslong')+' | ';
  ahtml+=getAssetType(6,'icon')+' '+getAssetType(6,'sayslong')+' ';
  ahtml+='<br>';
  ahtml+='<br><span >&#66304;nnity entries display base values  -- the amount recieved  --  if annuity started that date. Since an annuity income depends on when it was added to a porfolio, cumulative values are not displayed.  ';
  ahtml+='<br><span >&#120793;off entries display amount that would be received if the asset were included in the portfolio on this date (after, the day after this date) ';

  ahtml+='<li> <em>Descriptions:</em>';
  ahtml+='<menu xclass="tightMenu">';
 
  for (let aName in  simInvDsets['assetValues_byDate']['assetList']) {

     let atype=doAssetLookup(aName,'assetType',2);
     let taxFreeFrac=doAssetLookup(aName,'taxFreeFrac',1);
     taxFracSay='n.a.';
     if (taxFreeFrac!=='false') {
           taxFracSay=parseFloat(taxFreeFrac).toFixed(2);
     }
     let aextras='';

     if (doAssetLookup(aName,'autoAddEntries','i')==1) {
           let nImputed=doAssetLookup(aName,'nImputed','i')   ;
           aextras+=nImputed+ ' entries added (using imputed inflation) after last explicit entry.<br>';
     }

     if (atype==0) {
        aextras+='';
     } else if (atype==1 ) {
         let tt0=parseFloat(taxFreeFrac)*100;
         let tt=tt0.toFixed(1)+'%';
         aextras+='Percent of interest earnings <u>not</u> taxed: '+tt;
     } else if (atype==2 ) {
        aextras+='';
     } else if (atype==3 ) {
         let tt0=parseFloat(taxFreeFrac)*100;
         let tt=tt0.toFixed(1)+'%';
         aextras+='Percent of capital gains <u>not</u> taxed: '+tt;

     } else if (atype==4 ) {

         let tt0=parseFloat(taxFreeFrac)*100;
         let tt=tt0.toFixed(1)+'%';
         aextras+='Percent of income <u>not</u> taxed: '+tt;

     } else if (atype==7 ) {

         let tt0=parseFloat(taxFreeFrac)*100;
         let tt=tt0.toFixed(1)+'%';
         aextras+='Percent of expense that offsets other taxable income: '+tt;
     }

      let aIcon=getAssetType(atype,'icon');
      let adesc=doAssetLookup(aName,'desc');
      let nhistory=doAssetLookup(aName,'nHistory','i');
      ahtml+='<li>'+aIcon+' <b>'+aName+'</b> <span title="# of asset history entries" class="cHistoryAssetDescs"># entries:' +nhistory+'</span>  <tt>'+adesc+'</tt>';
      ahtml+='<br> '+aextras;
  }
  ahtml+='</menu>';

   let wname='assetDetails';
   if (ascenario!='') wname+='_'+ascenario;
   let jsFiles='jsLib/simInv_assetDetails.js,jsLib/simInv_assetHistoryHtml.js,lib/jquery-3.6.0.min.js,lib/wsurvey.utils1.js,jsLib/simInv.js,jsLib/simInv_utils.js';
    wsurvey.displayInNewWindow(0,{'content':ahtml,
        'jsFiles':jsFiles,'cssFiles':'cssLib/simInv.css,cssLib/simInv3.css',
        'name':wname,'title':'Asset details (by various dates) '});

     displayStatusMessage('<br>... trends in asset attributes displayed in popup window! ',1,4);
     displayStatusMessage(false,0,5000);

  return 1;

}

//==================
// select/deslect asset columns to display
function showAllAssetValues_pick(athis) {

  let emenu=$('#assetTable_choseMenu');
  if (emenu.is(':visible')) {
      emenu.hide();
      return 1;
  }

  let e1=$('#assetTable_assetList');
  let t1=e1.val();
  let doAssets=t1.split(',');

   let bmess='';
   bmess+='<input type="button" value="x" title="Close this menu" onClick="$(\'#assetTable_choseMenu\').hide()" >  ';
   bmess+='<input type="button" value="&#8704;" title="Select all assets" onClick="showAllAssetValues_pick2(0,1)" >  ';
   bmess+='<input type="button" value="&#10672;" title="De-Select all assets" onClick="showAllAssetValues_pick2(0,0)" >   ';

   bmess+='<em>Select assets (columns),</em> and ';
    bmess+=' then   <button  class="calcButton"  onClick="showAllAssetValues_pick2(this)">display them </button> ';
    bmess+='<ul id="ishowAllAssets_pick" class="linearMenu16Pct">';
   for (ith=0;ith<doAssets.length;ith++) {
     let aname=doAssets[ith] ;
     bmess+='<li><label title="Display this asset" ><input type="checkbox"  checked name="chooseThis" data-name="'+aname+'" >'+aname+'</label>';
  }
  bmess+='</ul>';
  emenu.html(bmess).show();

}

//==========
// display chosen columns
function showAllAssetValues_pick2(athis,ido) {
  if (arguments.length<2) ido=false ;
   let showThese={};

   let e1=$('#ishowAllAssets_pick');
   let e2=e1.find('[name="chooseThis" ]');
   let nshow=0;
   for (let ie=0;ie<e2.length;ie++) {
       let ae=$(e2[ie]);
       if (ido===false) {  // find the checked
         if (ae.prop('checked')) {
           let aname=ae.attr('data-name');
           showThese[ie+1]=1 ;       // col # (skip header col)
           nshow++;
         }
       } else {  // select or deselect all checkboxes
          if (ido==1) {
             ae.prop('checked',true);
          } else {
            ae.prop('checked',false);
          }
       }
   }
   if (ido!==false) return 0;

   let ediv=$('#assetValuesTableDiv');
   let etable=$('#assetValuesTable');
   let ecs=etable.find('colgroup');         // view or collapse a <col>
   let ecs2=ecs.find('col');


   for (let ie1=2;ie1<ecs2.length;ie1++) {
      let acol=$(ecs2[ie1]);
      let nth=acol.attr('data-nth');
      if (showThese.hasOwnProperty(nth)) {
             acol.css({'visibility':'visible'});

             nshow++;
      } else {
             acol.css({'visibility':'collapse  '});
      }
    }
}

//=======
// highlight a column
function showAllAssetValues_highlight(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-which');
   let ison=parseInt(ethis.attr('data-hilite'));

   ethis.attr('data-hilite',(1-ison));
   let etable=$('#assetValuesTable');
   let awhat='assetTableCol_'+aname ;
   let ewhich=etable.find('[name="'+awhat+'"]');
    let ed1=ethis.closest('div');
   if (ison==0) {
      ewhich.addClass('chiliteAssetColD');
      ed1.addClass('chiliteAssetColD');
   } else {
      ewhich.removeClass('chiliteAssetColD');
      ed1.removeClass('chiliteAssetColD');
   }
}

//========
// select attributes to display
function showAllAssetValues_pickAttributes(athis) {

    let emenu=$('#assetTable_choseMenu');
  if (emenu.is(':visible')) {
      emenu.hide();
      return 1;
  }
  let daAtts={'income':'assetTableAttribute_income',
     'expense':'assetTableAttribute_expense',
     'cumExpense':'assetTableAttribute_cumExpense',
     'rent':'assetTableAttribute_rent',
     'price':'assetTableAttribute_price',
     'dividend':'assetTableAttribute_dividend',
     'interest':'assetTableAttribute_interest',
     'cumGrowth':'assetTableAttribute_cumGrowth',
     'cumDiv':'assetTableAttribute_cumDividend',
     'cumEarn':'assetTableAttribute_cumEarn',
     'receipt':'assetTableAttribute_receipt'
   }

   let bmess='';

    bmess+='<ul id="ishowAllAssetAttributes_pickRows" class="linearMenu16Pct">';
     bmess+='<li><em>Rows to display: </em>';
     bmess+='<li><label title="Display all dates" ><input type="radio"  checked name="chooseThisDate" value="all" data-name="all" >All</label>';
     bmess+='<li><label title="Display dates specified for at least one asset"><input type="radio"  value="exist"  name="chooseThisDate" data-name="Exist" >Exist</label>';
     bmess+='<li><label title="Display calendar dates" ><input type="radio"   name="chooseThisDate"  value="calendar" data-name="calendar " >Calendar</label>';
  bmess+='</ul>';

   bmess+='<input type="button" value="x" title="Close this menu" onClick="$(\'#assetTable_choseMenu\').hide()" >  ';
   bmess+='<input type="button" value="&#8704;" title="Select all asset attributes" onClick="showAllAssetValues_pickAttributes2(0,1)" >  ';
   bmess+='<input type="button" value="&#10672;" title="De-Select all asset attributes" onClick="showAllAssetValues_pickAttributes2(0,0)" >   ';

   bmess+='<em>Select attributes (values in a cell), and dates (rows) ... </em> and ';
    bmess+=' then <button  class="calcButton" onClick="showAllAssetValues_pickAttributes2(this)">display them</button> ';
    bmess+='<ul id="ishowAllAssetAttributes_pick" class="linearMenu16Pct">';
   for (aname in daAtts) {
     bmess+='<li><label title="Display this asset attribute" ><input type="checkbox"  checked name="chooseThis" data-name="'+aname+'" >'+aname+'</label>';
  }
  bmess+='</ul>';
// bmess+='<p>Note: to display a subset of the assets, choose them before generating this table ';
  emenu.html(bmess).show();
 

}

//=======
// highlight  column attributes
function showAllAssetValues_pickAttributes2(athis,ido) {

    let daAtts={'income':'assetTableAttribute_income',
     'expense':'assetTableAttribute_expense',
     'cumExpense':'assetTableAttribute_cumExpense',
     'rent':'assetTableAttribute_rent',
     'price':'assetTableAttribute_price',
     'dividend':'assetTableAttribute_dividend',
     'interest':'assetTableAttribute_interest',
     'cumGrowth':'assetTableAttribute_cumGrowth',
     'cumDiv':'assetTableAttribute_cumDividend',
     'cumEarn':'assetTableAttribute_cumEarn',
     'receipt':'assetTableAttribute_receipt'
   }

  if (arguments.length<2) ido=false ;
   let showThese={};

   let e1=$('#ishowAllAssetAttributes_pick');
   let e2=e1.find('[name="chooseThis" ]');
   let nshow=0;
   for (let ie=0;ie<e2.length;ie++) {
       let ae=$(e2[ie]);
       if (ido===false) {  // find the checked
         if (ae.prop('checked')) {
           let aname=ae.attr('data-name');
           showThese[aname]=1 ;       // col # (skip header col)
           nshow++;
         }
       } else {  // select or deselect all checkboxes
          if (ido==1) {
             ae.prop('checked',true);
          } else {
            ae.prop('checked',false);
          }
       }
   }
   if (ido!==false) return 0;      // a select or deselect all checkboxes. so return

   let etable=$('#assetValuesTable');

   for (let aname in daAtts) {
     let ado=daAtts[aname];
     if (showThese.hasOwnProperty(aname)) {
         $('[name="'+ado+'"]').show();
     } else {
         $('[name="'+ado+'"]').hide();
     }
   }

// and now do dates
   let e1b=$('#ishowAllAssetAttributes_pickRows');
   let eradios=e1b.find('[name="chooseThisDate"]');
   let e3=eradios.filter(':checked') ;
   let avalue=e3.val();
   let etrs=etable.find('tr');

   if (avalue=='exist') {
      etrs.hide() ;     // hide all
      let et1=etrs.filter('.c_existDate')   ;
      et1.show();
   } else if (avalue=='calendar')   {
      etrs.hide() ;     // hide all
      let et1= etrs.filter('.c_calendarDate ') ;
      et1.show();
   } else {
      etrs.show() ;     // show all
   }
}
