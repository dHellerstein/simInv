//==========


//============
// Display a menu to specify a portfolio --  populated with details of an existing asset mix
//
//  grownEntry   -- "after growth" portfolio portfolioSummaryalues, and   "list of assets" to pre-populate menu with
//         the "list of assets" array  is typically from  portfolioInit or portfolioModification  -
//  newDate : date of the modificationEntry to create... ignored if ismod=0
//
// Since  This creates an onscreen menu, it does NOT return anything. Nor does is set or change globals
//
// Called by showModifyPortfolio_step2

function buildPortfolioMenu_mod(grownEntry,newDate,cExist) {

   displayStatusMessage(' modifying a portfolio ...');

   buildPortfolioMenu_doMod(grownEntry,newDate,cExist );
   displayStatusMessage(false,0,1000);

   return 1;

 }


//==============
// build a "portfolio specification" menu -- for initialziation entries.
// also used to create empty menu that is filled in by assets in an existing entry (init or modification)

function buildPortfolioMenu_create(athis,ismod,useDate) {

  let pname,makeThisDate,makeThisDateSay,jyear,jday,jmonth;

  if (arguments.length<2) ismod=0;
  if (ismod==0) {
      displayStatusMessage(' initializing a portfolio ...<br>');
      let ethis=wsurvey.argJquery(athis);
      pname=ethis.attr('data-name');
  } else {
      pname=athis;
      displayStatusMessage(' modifying a portfolio ...<br>');
  }
  
  let asay='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioHistoryHelp1">&#10068;</button> Initialize <b>'+ pname+'</b> ... '
  hidePortfolioHeader(1,asay);

  let oof;
  if (arguments.length<3) {
     oof=setEntryDate(true);      // returns most recenlty saved, or current date if no save in this session
  } else {
     oof=setEntryDate(useDate);
  }
  jyear=oof['year'],jday=oof['day'],jmonth=oof['month'];
  makeThisDate=oof['dayCount'];
  makeThisDateSay=oof['sayDate'];


   let useVariant;
// a "variant" version of a portfolio? If so, exclude assets that have a different variant
   let pnameF=getAssetFamily(pname,1,false);

   if (pnameF['variant']=='') {
      useVariant=false;
   } else {
      useVariant=pnameF['variant'];
   }

   let ithBase=false,growThisDate=false,growThisDateSay=false;
   let  grownEntry={};

   let zz=portfolioLookup['list'][pname];
   let pdesc=portfolioList[iz]['desc'];

    ithBase=false;


   assetsAvail=getAssetValueInfo(makeThisDate,1);

   let nHidden=0,nCanUse=0,ntot=0;   // used below
   for (let casset in  assetsAvail) {          // assetsAvail only contains assets that have been defined as of   makeThisDate
      ntot++;
      let isHidden=doAssetLookup(casset,'isHidden');
      if (isHidden==1) {
           nHidden++;
      } else {
         nCanUse++;
      }
   }

   let amess='';

//   divs are created and displayed :     portfolioHistory1     portfolioSummary

//  1) portfolioHistory1:  the main container --  portfolioHistory1Head ,    portfolioHistory1AssetHeaderDiv ,portfolioHistory1AssetRows_div

   amess+='<div style="border:1px solid gray" id="portfolioHistory1"     >';

// top table: info cells, Initialize, etc cells,
   amess+='<table  xborder="1" id="portfolioHistory1Head" width="98%"   class="cportfolioTable">';

   amess+='<tr class="headerRowInit">';  // just 1 row in this table

// navigation, submit, and help button cell
    amess+='<td width="18%" >';

    amess+='<button title="Return to portfolio list ... " data-name="'+pname+'"  name="doPortfolioButton"  onClick="showPortfolioTable(this)">&#8617;&#65039;</button>  ';
    amess+='<input type="button" value="&neArr;" title="View portfolioMenu in a new window"  data-id="mainDiv" onClick="displayInWindow(this)"> ';

    if (ismod==0) {
         amess+=' <button class="csaveButton" title="Preview, and then save (or change it)  " data-name="'+pname+'" onClick="savePortfolioPreview(this)">Preview!</button>';
    } else {
         amess+=' <button class="csaveButton" title="Preview & save the modifications " data-name="'+pname+'" onClick="reviewPortfolioMod(this)"> Preview ...</button>';
    }

    amess+='</td>';

// portfolio name and short descirpiton cell

    amess+='<td width="14%"> '
    amess+='<span class="portfolioNameSay">&#128144;<em>portfolio: '+pname+'</em></span> ';
    amess+='<span title="Short description"   class="cdescNoteBuildPortfolio"> '+pdesc+'</span> ';
    amess+='</td>';

// budget cell    . defaultBudget is global setting

    amess+='<td width="22%"   > '
    amess+='<span style="font-size:110%;font-weight:600">';
    amess+='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioProposedBudgetHelp1">?</button>  ';
    if (ismod==0) {
       amess+='Proposed budget</span>:';
    } else {
       amess+='Portfolio value</span>:';
    }

    amess+='   <input type="text" name="portfolioBudget"  style="font-size:110%" size="7" title="Dollars to allocate to various assets"  ';  // initialziation
    amess+= '    data-budget="'+simInvParams['defaultBudget']+'" data-orig="'+simInvParams['defaultBudget']+'" value="'+simInvParams['defaultBudget']+'">';
    amess+='   <span name="portfolioBudgetA"  style="float:right;margin-right:0.5em;font-size:90%" title="Net (after tax) value of assets\n Does NOT include `Cash`"></span>  ';  // initialziation

    amess+='</td>';

// dates (initialization, modificatoin, priorentry..) cell

   amess+='<td width="41%"   style="border-right:0px dotted blue;text-align:right"> ' ;
     amess+='<div id="portfolioMenu_initDateBlock"  name="aDateHandlerParent"  style="background-color:cyan"> '
     amess+='<span name="portfolioDate0" title="Prior (modified) entry"  ';
     amess+='      style="float:left;display:none;font-size:80%;font-family:monospace;padding:3px 5px;border:1px dotted gray;margin-right:1em"></span>';
     amess+='<span style="float:left;dcolor:green;display:none" id="updatedCreationDate">Initialization date changed ...  prices were updated ... </span> ';
     amess+='<span style="float:left;dcolor:#a69b29;margin-right:1em;" name="portfolioDate">Initialization date ... </span> ';

     let minDate=wsurvey.validateDate(simInvGlobals['theMinYear'] ,1,1).value;
     let maxDate=wsurvey.validateDate(simInvGlobals['theMaxYear'],12,31).value;
     amess+='<span style="float:right;margin-right:0.5em;white-space:nowrap;background-color:#b9f6e7"  > ';
     
     let dopts;
     if (ismod==0) {
       dopts={'minDate':minDate,'maxDate':maxDate,'month3':2,
                 'callback':'buildPortfolioMenu_dateHandler',
                 'attribs':{'pname':pname}
              };
    } else {
       dopts={'minDate':minDate,'maxDate':maxDate,'compress':1,'readonly':1,'month3':2};

    }
     let dstring=wsurvey.dateBox_make(jyear,jmonth,jday,dopts);

     amess+=dstring;


     amess+='</div>';
   amess+='</td>';

  amess+='</tr>';
  amess+='</table>';

// list of  buttons .. for all existing assets... with highlighting of assets currently in the portfolio's asset-mix

  amess+='<div id="portfolioHistory1AssetHeaderDiv" style="max-height:9em;overflow:hidden ">';
  amess+='<table  border="1" id="portfolioHistory1AssetHeader" width="98%"   class="cportfolioTable">';

  amess+='<tr bgcolor="#edf6f6" id="portfolioHistoryAssetList"   >';

// button cell (copy protoflio, sort buttons..)

  amess+='<td width="15%" valign="top" >';
  amess+='<div id="portfolioHistoryAssetList_a">';

  amess+='<div style="background-color:#cfdeaa;padding:3px 5px;margin:1px 2px 4px 2px;height:1.75em">';
  amess+='<label  class="cbuildPortfolioMenu_create_amenu"   style="font-size:90%;  " title="shrink table of assets"> ';
    amess+=' <input value="1" onClick="buildPortfolioMenu_create_amenu(this)"  style="display:none;" type="radio" name="portfolioMenuAssetStyle" >&#9712;</label> ';
  amess+='<label  class="cbuildPortfolioMenu_create_amenu buildPortfolioMenu_create_amenu2"   style="font-size:100%;"  title="normal (3 rows)">   ';
    amess+=' <input value="2" onClick="buildPortfolioMenu_create_amenu(this)" style="display:none"   type="radio" name="portfolioMenuAssetStyle" >&#8863;</label> ';
  amess+='<label  class="cbuildPortfolioMenu_create_amenu"   style="font-size:105%;" title="large (most of screen)">';
    amess+=' <input value="3"  onClick="buildPortfolioMenu_create_amenu(this)"   style="display:none" type="radio" name="portfolioMenuAssetStyle" >&#9634;</label> ';

//amess+='<input type="button" value="goo" onClick="testGoo(1)" >';

  amess+='<button style="color:blue;float:right;margin-right:0.5em"   data-how="0" ';
  amess+='   onclick="buildPortfolioMenu_sortAsset(this)" title="sort the asset list -- order of creation, alphabetical, by type ">sort '+nCanUse+' &#10143;</button>';

  amess+='</div>';
 //  amess+='<br clear="all">';

  amess+='<div name="nportfolioHistoryAssetList">';
  amess+=' <span style="background-color:#daf7f9;padding;3px" title="add an asset to the portfolio">&hellip;add an asset &hellip; ';
  amess+='</span>';
  amess+='<br><em>or </em> <input type="button" data-name="'+pname+'" value="Copy a portfolio... " title="Copy the asset mix of an existing portfolio" onClick="copyPortfolio(this)">';
  amess+='</div>'   ;

  amess+='</div>'       ;  //nportfolioHistoryAssetList_a

  amess+=' </td>';

// list of buttons: add asset to asset-mix menu
  amess+='<td width="83%" >';
  amess+='<div id="portfolioHistoryAssetList_b" class="buildPortfolioMenu_create_amenu3" >';

  amess+='<ul class="linearMenu18Pct" name="portfolioTable_assetButtons" title="Available assets ... ">   ';
  amess+='<li data-type="-1" data-name="Cash" data-orig="0"  data-init="1">  ';       // -1:cash

  amess+='<span  title="The remaining cash (or, if negative, additional required cash) after allocation of the budget to selected assets">Cash &#65284;</span>';

// the "add this asset to the mix" buttons     -- all available assets
  let ifoo=0
  let titleA='Click to add this asset';
 
  for (let casset in assetsAvail) {          // assetsAvail only contains assets that have been defined as of   makeThisDate
      let isHidden=doAssetLookup(casset,'isHidden');     // 3 dec 2023 : could create "assetAvailUse above ...
      if (isHidden==1) continue ;

      let assetType=getAssetType(casset) ;
      let assetSay=getAssetType(assetType,'say');
      let isPublic=doAssetLookup(casset,'isPublic');

      let titleAUse,cassetSay ;
      if (isPublic==1) {
         cassetSay='<span style="color:brown">&Pscr;</span>'+casset;
         titleAUse= 'Click to add this Public Asset ' ;
      } else {
         titleAUse='Click to add this asset ... ' ;
         cassetSay=casset;
      }

      if (useVariant!==false)   { // check if  this asset is in a different variant. If so, skip
          let cFamily=getAssetFamily(casset,1);
          if (cFamily['variant']!='')   {        // non-variant assets avaialable to all portfolios
             if (cFamily['variant']!=useVariant) continue ; // in a different variant .. don't show
           }  // this asset has a variant
      }    // this portfolio has  a variant
      ifoo++;
      amess+='<li data-type="'+assetType+'" data-name="'+casset+'" data-orig="'+ifoo+'"  >';
      let adesc=doAssetLookup(casset,'desc');
      amess+='<label  title="Description: '+adesc+'"> ';

       amess+='<button value="'+casset+'" data-type="'+assetType+'"   data-chosen="0"   title="'+titleAUse+'"  data-datex="'+makeThisDate+'" ' ;
       amess+='   data-name="'+casset+'" name="portfolioTable_assetButtons_1"  onClick="portfolioAddAssetNew(this,0)" > '; //  buildPortfolioMenu_create
       amess+= cassetSay+' </button>';
       amess+='<span  >'+assetSay+'</span> </label>';

// these infoettes (next to the add this asset button) can be pcpulated (22 nov 2023 to be implemented)
        if (assetType==0 ) {
            amess+='<span name="assetValue_now" data-type="0" data-name="'+casset+'" data-value="" title="Per share price: as of '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==3 ) {
            amess+='<span name="assetValue_now"  data-type="3"  data-value=""   data-name="'+casset+'" title="Property price:  as of  '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==4 ) {
            amess+='<span name="assetValue_now"  data-type="4"  data-value=""   data-name="'+casset+'" title="Yearly income:  as of  '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==5 ) {
            amess+='<span name="assetValue_now"  data-type="5"  data-value=""   data-name="'+casset+'" title="Annuity income, if acquired on '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==6 ) {
            amess+='<span name="assetValue_now"  data-type="6"  data-value=""   data-name="'+casset+'" title="oneOff receipt -- if acquired on '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         if (assetType==7 ) {
            amess+='<span name="assetValue_now"  data-type="4"  data-value=""   data-name="'+casset+'" title="Yearly expense:  as of  '+makeThisDateSay+'" style="font-family:monospace;background-color:#dfdfda"></span>';
         }
         
         amess+='</span>';

  }          // add asset buttons

  if (nHidden>0) amess+='<li><em>'+nHidden+'</em> hidden assets not show ';
  amess+='</ul>';
  amess+='</td> ';
  amess+='</div>  ' ;  //     portfolioHistoryAssetList_b
  amess+='</tr>';        // clickable list of assets
  amess+='</table>';     //portfolioHistory1AssetHeader

  amess+='</div>';      // portfolioHistory1AssetHeaderDiv

// column names

  amess+='<div id="portfolioHistory1AssetRows_div" class="cportfolioHistory1AssetRowsDiv">';

  amess+='<table  border="1" id="portfolioHistory1AssetRows" width="99%"   class="cportfolioTable">';

   amess+='<tr class="headerRow">';
   amess+='<td  width="1%"  >';
   amess+='<input type="button" style="font-family:oblique" value="Reset" title=" values " onClick="buildPortfolioMenu_reset(this)"> ';

   amess+='<input type="hidden" name="baseEntry_ith" value="0">';
   amess+='<input type="hidden" name="baseEntry_closestDate" value="0">';

  amess+='</td>';
  amess+='<th  width="14%" ><span  title="Name of an existing asset">';
  amess+='<button style="margin-bottom:5px" title="Tips on adding assets" onClick="displayHelpMessage(this)" data-div="#calcPortfolioValueAddAsset">&#10068;</button>';

  amess+='<b>Name</b></span>';
  amess+='</th>';
  amess+='<th width="36%"> <span title="Allocation to this asset --. As #shares, $ amount, or % of budget">Allocations (# shares or $, etc.)</span></th>';
  amess+='<td  width="35%">  ';

// these fields are filled by addARowPortfolioAssetMix_assetSummary
  amess+='<div name="allocationHeader_allocation" class="cAllocationHeader" style="display:none" title="current values .."> ';
//    amess+='<u>Current</u>: <span  title="Cost (to obtain asset), and pct of total cost" class="cmyCost_span">Cost</span>';
   amess+='<span  title="Cost (to obtain asset), and pct of total cost" class="cmyCost_span">Cost</span>';
    amess+=' <span  title="Gross (pre-tax, pre loan payback) value, and pct of total value " class="cmyValue_span">Value</span>';
    amess+=' <span  title="Net (after-tax, after loan payback) value, and pct of total net value " class="cmyNetValue_span">netValue</span>';
    amess+=' <span  title="Net revenue (such as rents - mortgagePayments). Can be negative " class="cmyNetRevenue_span">netRevenue</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_info" style="overflow-wrap: break-word;overflow:auto;white-space:normal;" class="cAllocationHeader"  style="display:none"> ';
    amess+='<span title="Information for each asset, as of the current modification (or creation) date" class="cmyValue_span">Info (yearly):  dividends, interest rate, income, &hellip;</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_base"  class="cAllocationHeader"  style="display:none"> ';
    amess+='<span  title="PreGrowth: Cost (to obtain asset), and pct of total cost" class="cmyCost_span">Cost</span>';
    amess+=' <span  title="PreGrowth: Gross (pre-tax, pre loan payback) value, and pct of total value " class="cmyValue_span">Value</span>';
    amess+=' <span  title="PreGrowth: Net (after-tax, after loan payback) value, and pct of total net value " class="cmyNetValue_span">netValue</span>';
    amess+=' <span  title="PreGrowth: Share price, or loan amount owed" class="cmyNetRevenue_span">Price or loan</span>';
  amess+='</div>'

  amess+='<div name="allocationHeader_changes"  class="cAllocationHeader"  style="display:none"> ';

  amess+='</div>'

  amess+='</td>';
  amess+='<th  width="10%"> <span title="Comment">Comment</span></th>';
  amess+='</tr>';

//end of header and help rows

// the cash row

   amess+='<tr class="portfolioHistoryRowCash"  >';
   amess+='<td title="sort by: asset type">';

// 3 dec -- use resize assetlist buttons instead
//   amess+='<input type="button" style="font-family:oblique" value="&#8661;" title="expand view of asset table" onClick="buildPortfolioMenu_expand(this)"> ';

   amess+='&hellip;</td>';

   amess+='<td title="sort by: asset name"><u>Cash</u> </td>';
   amess+='<td title="sort by: gross (pre-tax) value" >';
   amess+=' <input readonly style="background-color:#eaebea;opacity:0.6;color:blue" type="text" name="portfolioCashRemain" size="9" value="" data-value=""   ';
   amess+=' title="Remaining cash; if negative, additional cash required  to obtain asset mix.\nThis is automatically calculated "  size="4"     >';
   amess+=' <button  data-name="'+pname+'"  data-ismod="'+ismod+'" title="Allocate remaining cash to first empty asset" onClick="allocateCashToEmpty(this)">&#1769;</button> ';
   amess+='<span name="cashPreChange" class="cCashPreChange" title="Cash asset: after growth, before asset modifications"></span>';
   amess+='</td>';

//   amess+='<td title="sort by: net (after tax) value">';
   amess+='<td title="net (after tax) value">';

   if (ismod==0) {
//     amess+='<span class="cgrossValue"  ><tt>  &hellip;</tt></span>  ';
     amess+='<input type="button"  id="iUpdatePricesButton" value="&#11118; &#128712;" title="Display prices, etc. ... as of the Creation date" onClick="buildPortfolioMenu_priceUpdate_show(0)" >'; // update using currently specified creation date
     amess+='<button id="calcPValueButton2"  class="calcButton" title="Calculate values of this proposed asset-mix ... as of the specified creation date"   ';
     amess+=' onClick="portfolioCalcValueMenu_init(this)" data-name="'+pname+'">&#129518; value</button>'; // in buildPortfolioMenu -- suppress summary
   } else {
       amess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#buildPortfolioMenu_others1">&#10068;</button>';
       amess+='<input type="button"  id="iUpdatePricesButton" value="&#128712;" title="Display prices, etc. ... as of this modification date" onClick="buildPortfolioMenu_priceUpdate_show(1)" >'; // update using currently specified creation date
       amess+='<input type="button" value="&#9918;" title="Show current asset allocation  (before growth, before modification)  " onClick="buildPortfolioMenu_showBase(this)" >';
       amess+='<input type="button" value="&#8710;" title="Show changes due to growth (before modification) asset allocation " onClick="buildPortfolioMenu_showGrowth(this)" >';
       amess+='<input type="button" value="&#128496;" title="Show changes due to modifications of asset allocation " onClick="buildPortfolioMenu_showMods(this)" >';
       amess+='<span style="float:right;margin-right:1em;font-size:85%;font-style:oblique" title="info being shown" id="buildPortfolioMenu_whatshow">Asset specs</span>';
   }

   amess+='</td>';

   amess+='<td  title="sort by: fraction of portfolio in this asset"><input type="hidden" name="portfolioComment" value="Cash remaining (or required) ">';
   amess+='<input type="text" disabled size="35"  value="remaining, or (if negative) required, cash"></td>';
   amess+='</tr>'

  amess+='</table>'; //portfolioHistory1AssetRows
   amess+='<div style="margin-top:2px;font-size:80%;opacity:0.66;color:#0057ff;padding-left:10em"> ... assets in '+pname+' ( '+makeThisDateSay+') &hellip; </div>';

  amess+='</div> ' ;   //portfolioHistory1AssetRows_div

  amess+='</div>';  // end of portfolioHistory1

//  display resuilts  of portfolioValue calculation

  $('#mainDiv3').html(amess);
  wsurvey.wsShow.show('#mainDiv3','show');
  wsurvey.wsShow.hide('#portfolioSummary');    // this is where the table is shown

  if (ismod==0) {
    let a1='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioHistoryHelp1">?</button>';
    hidePortfolioHeader(1,a1+' Specify the asset mix of portfolio '+pname+' &#128144; ');
  } else {
    let a1='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioHistoryHelp1">?</button>';
    hidePortfolioHeader(1,a1+' Modify the asset mix of portfolio '+pname+' &#128144; ');
  }

  $('#icalcPortfolioValue_init').show();
  $('#icalcPortfolioValue_mod').hide();

  if (ismod==0) {              // if 1, then stuff is added to the empty menu created above
    displayStatusMessage(false,0,1000);
    buildPortfolioMenu_expand(0,1)  ; // set max height of portfolio table to default
  }
   return 1   ;          // nothing to pre-popoulate with

 }                     //  buildPortfolioMenu_create


//==============
// change size of portfolio build "list of assets"
function buildPortfolioMenu_create_amenu(athis) {

   let ethis=wsurvey.argJquery(athis);
   let asize=ethis.val();

// format buttons
   let ediv=ethis.closest('div');
   let eradio=ethis.find('[name="portfolioMenuAssetStyle"]');
   eradio.prop('checked',false);
   let elabels=ediv.find('label');
   elabels.removeClass('buildPortfolioMenu_create_amenu2');
   ethis.prop('checked',true);
   let elabel=ethis.closest('label');
   elabel.addClass('buildPortfolioMenu_create_amenu2');


// first resize header
   let eheader=$('#portfolioHistory1AssetHeaderDiv');
     let e1=$('#portfolioHistoryAssetList_a');
     let e2=$('#portfolioHistoryAssetList_b');

   if (asize==1)  {          // small size

     eheader.css({'max-height':'2.9em'});
     e1.css({'max-height':'2.6em'});
     e2.css({'max-height':'2.6em'});
//     emenu.css({'max-height':'65vh'});
   }
   if (asize==2)  {          // regular  size
     eheader.css({'max-height':'8em'});
     e1.css({'max-height':'7em'});
     e2.css({'max-height':'7em'});
//     emenu.css({'max-height':'35vh'});

   }
   if (asize==3)  {          // large  size
     eheader.css({'max-height':'24em'});
     e1.css({'max-height':'22em'});
     e2.css({'max-height':'22em'});
  //   emenu.css({'max-height':'15vh'});

   }


// ressize specs asset menu
 window.setTimeout(function() {     // let dom settle
   let emainDiv=$('#mainDiv');
   let hmainDiv=emainDiv.height();
   let emainDiv3=$('#mainDiv3');
   let hmainDiv3=emainDiv3.height();
   let emenuParent=$('#portfolioHistory1');
   let hmenuParent=emenuParent.height();
   let emenu=$('#portfolioHistory1AssetRows_div');
   let hmenu=emenu.height();
   let menuPosTop=emenu.position().top;

    let havail= (hmainDiv-menuPosTop)* 0.95    ;

    let ihavail=parseInt(havail);
    let ihavail_div3=hmainDiv-5;
    emainDiv3.height(ihavail_div3+'px');
    emainDiv3.css({ 'max-height':ihavail_div3+'px'});

    let  ihavail_parent=hmainDiv-24;
    emenuParent.height(ihavail_parent+'px' ) ;
    emenuParent.css({'max-height':ihavail_parent+'px'});

    let iuse2=ihavail -5 ;
    emenu.height(iuse2+'px');
    emenu.css({ 'max-height':iuse2+'px'});


  },60);


}

//==============
// build a "portfolio specification" menu -- for adding a new modification entry.
// this is similar (and uses common functions) to   buildPortfolioMenu

function buildPortfolioMenu_doMod(grownEntry,newDate,cExist) {
   let pname,gotUse;

   let priorDate=grownEntry['startDate'] ;
   let priorIth=grownEntry['base']['ith'];

   pname=grownEntry['name'];
   let zz=portfolioLookup['list'][pname];

   buildPortfolioMenu_create(pname,1,newDate);         // create basic menu for modification ... and fill below

   let eb=$('#portfolioMenu_initDateBlock');
   let eb1=eb.find('[name="portfolioDate"]');
   eb1.html('Modification date &hellip;');

   let eb3=eb.find('[name="portfolioDate0"]');
   eb3.show();
   let oof=setEntryDate(priorDate);
   let oof2=oof.sayDate;
   if (priorIth==0) {
     eb3.html('Initialized on: '+oof2);
   } else {
     eb3.html('Using modification #'+priorIth+': '+oof2);
   }

  let etable=$('#portfolioHistory1AssetRows_div');
  let ecash=etable.find('[name="portfolioCashRemain"]');

  let acash=parseInt(grownEntry['grown']['cash']) ;

  ecash.val(acash);

// note: changeCashOneOff are the "oneOffs"  specified in the 'priorEntry' -- that are recieved  the "day after" the prior entry's start date
//  changeCashAssetEnd is : bond additions (if from cash) including RMDS, property rents - loan payments,  incomeSreamm earnings, and annuity earnings

//showDebug(grownEntry,'predcccc ',1);
 let   cashAssetRawAdd=0,cashAssetBaseGrowth=0,cashAssetEarnAdd=0,cashAssetOneOff=0;
  if (cExist==false) {
    cashAssetOneOff=parseInt(grownEntry['grown']['cashChangeObj']['rawOneOff']) ;   // one-off receipts
    cashAssetRawAdd=parseInt(grownEntry['grown']['cashChangeObj']['rawAdd']) ;      // rent loans income expenses additions ... etc
    cashAssetBaseGrowth=parseInt(grownEntry['grown']['baseGrowthInfo']) ;   // growth in starting caseh during period
    cashAssetEarnAdd=parseInt(grownEntry['grown']['cashChangeObj']['earnAdd']) ;   // growth in starting caseh during period
  }

  let ecashI=etable.find('[name="cashPreChange"]');  // pre modifications
  let acashSay= (Math.abs(acash)>1000) ? wsurvey.addComma(acash) : acash ;

  let acashPreGrowth=parseInt(grownEntry['base']['cash']) ;
  let acashPreGrowthSay=wsurvey.makeNumberK(acashPreGrowth,10000);

  let sayHelp1;
  if (cExist!==false) {
       let ppAfterGrowth='<span style="padding:1px 3px" title="Cash of this existing modification (after growth & achanges) ">'+acashSay+'</span>';
       ecashI.html(ppAfterGrowth).show();
  } else {
     sayHelp1='<input type="button" value="&#119136;" title="After growth `Cash` ?" onClick="$(\'#iGrowthCalcNote\').toggle()"> ';
     let ppAfterGrowth='<span style="padding:1px 3px" title="Starting cash: after growth (before changes) ">'+acashSay+'</span>';
      let pp0='<span style="padding:1px 1px" title="Pre change Cash= (starting Cash )  ">'+acashPreGrowthSay+'</span>';
      let pp2='<span style="padding:1px 1px"  title="oneOff receipts">'+cashAssetOneOff+'</span>';
      let pp4='<span style="padding:1px 1px" title="incomes, annuities, & expenses, additions & RMDS to bonds, property rents and loan payments">'+cashAssetRawAdd+'</span>';
      let pp3='<span style="padding:1px 1px" title="interest growth of Cash during period ">'+cashAssetEarnAdd+'</span>';

       let pp1234=ppAfterGrowth+' = '+pp0+ '+' + pp2+ '+' +pp4+ '+'+pp3 ;
       let pp1234Note='<span id="iGrowthCalcNote" style="inline-block;font-size:90%;display:none;margin-left:3em;border:1px dotted green ">';
       pp1234Note+='<br><u>Cash</u> after growth =  <tt>starting<u>Cash</u></tt> +  <tt>oneOffReciepts</tt>  + <tt>bond additions & rents & loans & incomes & expenses</tt> +  <tt><u>Cash</u>&nbsp;interest&nbsp;growth</tt>)';
       pp1234Note+='</span>';

       ecashI.html(sayHelp1+' '+pp1234+' '+pp1234Note).show();
  }
  let etable0=$('#portfolioHistory1');

  let ttotalAsset=parseInt(grownEntry['grown']['totals']['totAssetSaleNetAT']);

  let ttotalAssetSay=wsurvey.addComma(parseInt(ttotalAsset)) ;
  let ttotalAssetShortSay=wsurvey.makeNumberK(parseInt(ttotalAsset),10000) ;

  let ttotalAll=parseInt(grownEntry['totalsNet']['totPortfolioValue']);
  let ttotalAllSay=wsurvey.addComma(ttotalAll) ;

  let ebudget=etable0.find('[name="portfolioBudget"]');     //doMod
  ebudget.val(ttotalAllSay);
  ebudget.attr('data-budget',ttotalAllSay)
  ebudget.prop('readonly',true);
  ebudget.css({'background-color':'#dfdfdf'});
  ebudget.attr('title','Available budget (includes `Cash`).\n Net, after tax, value of assets: '+ ttotalAssetSay )

  let ebudgetA=etable0.find('[name="portfolioBudgetA"]');     //doMod
  ebudgetA.attr('title','Net (after tax) value of assets (NOT including `Cash`)= '+ttotalAssetSay);
  ebudgetA.html(ttotalAssetShortSay) ;

  let ebuttons0=etable0.find('[name="portfolioTable_assetButtons"]');
  let ebuttons=ebuttons0.find('[name="portfolioTable_assetButtons_1"]');


  for (let im=0;im<grownEntry['assetList'].length;im++) {
//     let vasset=grownEntry['mod']['assetList'][im];
     let vasset=grownEntry['assetList'][im];
     let aname=vasset['name'];
     let atype=vasset['assetType'];
     let ebutton1=ebuttons.filter('[data-name="'+aname+'"]');
     ebutton1.addClass('chighlightAssetButton') ;
     ebutton1.attr('data-chosen',1);

     let etr=portfolioAddAssetNew(0,1,aname,atype )  ;     // in buildPortfolioMenu_doMod

     let ecomment=etr.find('[name="portfolioComment"]');
     ecomment.val(vasset['comment']);

// now fill in input fiels using "after growth" values
     if (atype==0) {
        let e1=etr.find('[name="portfolioShares"]');
        let e2=etr.find('[name="portfolioSharesBasis"]');
        let nshares=vasset['nShares'];
        let abasis=vasset['basis'];

        e1.attr('data-orig',nshares);
        e1.val(parseInt(nshares));
        e2.attr('data-orig',abasis );
        let abasisSay=wsurvey.makeNumberK(abasis,15000) ;

        e1.attr('data-change',0);                 // for detecting a change
        e1.on('change',buildPortfolioMenu_doModMarkChange);
        e2.attr('data-change',0);
        e2.on('change',buildPortfolioMenu_doModMarkChange);

        e2.val(parseInt(abasis));

     } else  if (atype==1) {
        let e1=etr.find('[name="portfolioShares"]');
        let e2=etr.find('[name="portfolioAdditions"]');
        let nshares=vasset['nShares'];
        let addVal=vasset['addVal'];
        e1.attr('data-orig',nshares);
        e1.val(parseInt(nshares));
        e2.attr('data-orig',addVal);
        e2.val(parseInt(addVal));

        e1.attr('data-change',0);                 // for detecting a change
        e1.on('change',buildPortfolioMenu_doModMarkChange);
        e2.attr('data-change',0);
        e2.on('change',buildPortfolioMenu_doModMarkChange);

     } else  if (atype==2) {

        let e1=etr.find('[name="portfolioShares"]');
        let e2=etr.find('[name="portfolioAdditions"]');
        let nshares=vasset['nShares'];
        let addVal=vasset['addVal'];
        e1.attr('data-orig',nshares);
        e1.val(parseInt(nshares));
        e1.attr('data-change',0);                 // for detecting a change
        e1.on('change',buildPortfolioMenu_doModMarkChange);

        e2.attr('data-orig',addVal);
        e2.val(parseInt(addVal));

        let dormd=vasset['doRMD'];

        let ebut1=$('[name="portfolioAdditionsRMD"]');
        ebut1.prop('disabled',true);

        let eb1=$('.cportfolioAdditions_rmdCheckbox');
        eb1.hide();

        if (dormd==1 || dormd==2) {       // rmd distributions specified..

           let esa=$('[name="rmdStartSay"]');
           let oofS=setEntryDate(vasset['rmdStart']);
           esa.show();
           esa.html(oofS['sayDate']);

           let ermd=etr.find('.cportfolioAdditions_rmd');
           ermd.show();

           let rmdage=parseFloat(vasset['nowAge']);
           let eage=etr.find('[name="portfolioAdditionsRMD_age"]');
           eage.attr('data-orig',rmdage);
           eage.prop('readonly',true);
           eage.val(rmdage.toFixed(1));
           eage.css({'background-color':'#dfdfdf'});

           let eben=etr.find('[name="portfolioAdditionsRMD_beneficiary"]');
           if (dormd==2) {
               eben.prop('checked',true);
           } else {
               eben.prop('checked',false);
           }
           eben.prop('disabled',true);

           e2.prop('readonly',true);
           e2.css({'background-color':'#dfdfdf'});

        } else {         // include a "start rmd distributions" button
          eb1.show();
          ebut1.prop('checked',false);
          ebut1.prop('disabled',false);
        }

     } else  if (atype==3) {
          let e1=etr.find('[name="portfolioShares"]');
          let addv=parseInt(vasset['cost']);
          e1.attr('data-orig',addv);
          e1.val(addv);
          e1.prop('readonly',true);
          e1.css({'background-color':'#dfdfdf'});

          let e2=etr.find('[name="portfolioPropertyBasis"]');
          let abasis=parseInt(vasset['basis']);
          let abasisSay=wsurvey.makeNumberK(abasis,25000) ;
          e2.attr('data-orig',abasis);
          e2.val(abasisSay);
          e2.prop('readonly',true);
          e2.css({'background-color':'#dfdfdf'});

          let eloanY=etr.find('[name="loanYes"]');
          eloanY.hide();

          let aowed=parseFloat(vasset['loanOwed']);

          if (aowed>0) {

            ebut=etr.find('[name="porfolioLoanEnable"]');
            ebut.prop('disabled',true);
            ebut.prop('checked',true);

            eamt=etr.find('[name="portfolioLoanAmount"]');
            let aamt=parseInt(vasset['loanAmount']);
            eamt.attr('data-orig',aamt);
            let aamtSay=wsurvey.makeNumberK(aamt,5000) ;
            eamt.val(aamtSay);
            eamt.prop('disabled',true);
            eamt.css({'background-color':'#dfdfdf'});


            eterm=etr.find('[name="portfolioLoanTerm"]');
            let iterm=parseInt(vasset['loanTerm']);
            eterm.attr('data-orig',iterm);
            eterm.val(iterm);
            eterm.prop('disabled',true);
            eterm.css({'background-color':'#dfdfdf'});

            erate=etr.find('[name="portfolioLoanRate"]');
            let arate=parseFloat(vasset['loanRate']);
            erate.attr('data-orig',arate);
            let arateSay=arate.toFixed(2);
            erate.val(arateSay);
            erate.prop('disabled',true);
            erate.css({'background-color':'#dfdfdf'});

            ededuct=etr.find('[name="portfolioLoanTaxDeductInt"]');
            let adeduct=parseFloat(vasset['loanTaxDeduct']);
            let ydeduct;
            if (adeduct==0) {
               ededuct.prop('checked',false);
               ydeduct='no';
            } else {
               ededuct.prop('checked',true);
               ydeduct='yes';
            }
            ededuct.prop('disabled',true);

            let estart=etr.find('[name="loanStartDate"]');
            let oofy=setEntryDate(vasset['loanStart']);
            let dSay=oofy['sayDate'];
            let tt1=iterm+'y / '+ arateSay +'% / deduct:'+ydeduct;
            let gooZ='<span title="loan terms: '+tt1+'">'+dSay+'</span> ';
            estart.show();
            estart.html(gooZ);

            let eowed=etr.find('[name="loanOwedNow"]');
            let aowedSay=wsurvey.makeNumberK(aowed,90000) ;
            let goo2=' <input type="button" value=" Refi '+aowedSay+'?"  name="doRefiButton"';
            goo2+=' data-enabled="0"  data-name="'+aname+'"  data-im="'+im+'"  data-date="'+newDate+'"';
            goo2+='   title="Click to refinance this remaining balance" onClick="showRefiOptions(this)">';
            eowed.html(goo2);
            eowed.show();

            let especs=etr.find('[name="loanSpecs"]');
            especs.hide();
          }

          let esmalls=etr.find('.smallButton');
          esmalls.hide();

     } else  if (atype==4 || atype==5) {
          let e1=etr.find('[name="portfolioShares"]');
          let addv=parseInt(vasset['cost']);
          e1.val(addv);
          e1.attr('data-orig',addv);
          e1.prop('readonly',true);
          e1.css({'background-color':'#dfdfdf'});

     } else  if (atype==7 ) {
          let e1=etr.find('[name="portfolioShares"]');    // 1 dec 2023 ... needs checking
          e1.prop('readonly',true);
          e1.css({'background-color':'#dfdfdf'});
     }               // atype will never = 6 (since oneOffs in the "base entry" (for a modifications) are NOT retained

  }      // im

}
//=================
// mark field as changed
function buildPortfolioMenu_doModMarkChange(athis) {
    let ethis=wsurvey.argJquery(athis) ;
    ethis.attr('data-change',1);
}

//================
// show refinance options (on button push)
function showRefiOptions(athis) {

  let ethis=wsurvey.argJquery(athis);
  let etr=ethis.closest('.portfolioHistoryRow');
  let erefi=etr.find('[name="refinanceOptions"]');

  if (erefi.is(':visible')) {
     erefi.hide();
     ethis.attr('data-enabled',0);
     return false;
  }

  let aname=ethis.attr('data-name');
  let im=ethis.attr('data-im');
  let idate=ethis.attr('data-date');

  let vasset=simInvDsets['entryWorking']['base']['assetList'][im];
    let iterm=parseInt(vasset['loanTerm']);
    let arate=parseFloat(vasset['loanRate']);
    let adeduct=parseFloat(vasset['loanTaxDeduct']);
    let aowed=parseFloat(vasset['loanOwed']);
    let loanStart=parseInt(vasset['loanStart']);
    
    let oof=setEntryDate(loanStart);
    let startYear=oof['year'];
    
    let oof2=setEntryDate(idate);
    let nowYear=oof2['year'];
    let diffYear=Math.max(nowYear-startYear,0);
    let itermUse=iterm-diffYear;

  let amess='';

  amess+='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#calcPortfolioValueRefinance">?</button> ';
  amess+=' <button title="Preview this refinanced loan"  data-owed="'+aowed+'" ';
  amess+='        onClick="previewRefiLoan(this)" data-name="'+aname+'" data-date="'+idate+'" >&#128065;</button> ';

  amess+=' <span style="font-size:90%;white-space:nowrap;margin-left:3px;padding-left:2px">';
  amess+='RefiAmount: <input type="text"  class="modReset" data-orig="'+aowed+'" size="7"   value="'+aowed.toFixed(0)+'"     ';
  amess+='    title="refinance amount\n Values over loan owed added to `Cash`\n Values under withdrawn from `Cash`" name="portfolioRefiAmount" >';
  amess+='</span>';

  amess+=' <span style="font-size:90%;white-space:nowrap;margin-left:3px;border-left:1px solid black;padding-left:2px">';
  amess+='Term: <input type="text"  data-orig="'+itermUse+'" size="2"  title="refinance: loan term (in years)" name="portfolioLoanTerm" value="'+itermUse+'"> ';
  amess+='</span>';

  amess+=' <span style="font-size:90%;white-space:nowrap;margin-left:3px;border-left:1px solid black;padding-left:2px">';
  amess+='   Rate: <input type="text"  class="modReset"  data-orig="'+arate+'"  size="3"    ';
  amess+= '         title="refinance: loan Rate (eg; 2.0 for 2%)" name="portfolioLoanRate" value="'+arate+'">';
  amess+='</span>';

  let achecked=' ';
  if (adeduct==1)   achecked=' checked ';
  amess+=' <span style="font-size:90%;white-space:nowrap;margin-left:5px;border-left:1px solid black;padding-left:4px">';
  amess+=' Deduct:';
  amess+='  <input type="checkbox" '+achecked+'  class="modReset"  data-orig="'+adeduct+'" size="1"  ';
  amess+='       title="refinance: interest tax deductible?" name="portfolioTaxDeduct" value="'+adeduct+'">';
  amess+='</span> ';

   ethis.attr('data-enabled',1);

  erefi.html(amess);
  erefi.show();
}

//-====---------------------
// preiew a loan refiance
function previewRefiLoan(athis){
  let ethis=wsurvey.argJquery(athis);
  let ebox=ethis.closest('[name="refinanceOptions"]');
  let errors=[];

  let aname=ethis.attr('data-name');
  let idate=ethis.attr('data-date');
  let aowed=ethis.attr('data-owed');

  let eamt=ebox.find('[name="portfolioRefiAmount"]');
  let aamt=eamt.val();
  if (jQuery.trim(aamt)==''  || !jQuery.isNumeric(aamt)) {
      errors.push('You must specify an amount (as a number)');
  } else {
     aamt=parseFloat(aamt);
  }

  let erate=ebox.find('[name="portfolioLoanRate"]');
  let arate=erate.val();
  if (jQuery.trim(arate)=='' || !jQuery.isNumeric(arate) ) {
      errors.push('You must specify a  rate (eg; 4.0 for 4%) ');
  } else {
     arate=parseFloat(arate);
  }

  let eterm=ebox.find('[name="portfolioLoanTerm"]');
  let aterm=eterm.val();
  if (jQuery.trim(aterm)=='' || !jQuery.isNumeric(aterm)) {
     errors.push('You must specify a term (number of years) ');
  } else {
     aterm=parseInt(aterm);
  }

  let ededuct=ebox.find('[name="portfolioTaxDeduct"]');
  let adeduct=ededuct.prop('checked');
  let ideduct=(adeduct) ? 1 : 0 ;

  if (errors.length>0) {
      let oof=errors.join('\n ');
      alert('Please correct these errors:\n'+oof);
      return false;
  }

  let diff=aamt-aowed ;
  let diffSay=wsurvey.makeNumberK(diff,20000);
  let asay='Refinance ' ;
  if (diff>0.1) {
      asay='<div>Refinance, with $'+diffSay+' extra added to <u>Cash</u></div>';
  }
  if (diff<-0.1) {
      asay='<div>Refinance, with $'+diffSay+' one-time payment withdrawn from <u>Cash</u></div>';
  }

  specifyLoanScheduleC(0,asay,aname,aamt,aterm,arate,ideduct,idate)  ;  // write yearlyi schedule to status messages box
}


//=========================        a
// event handler for date change (on portfolio init)
// athis not  used

function buildPortfolioMenu_dateHandler(ediv,astuff) {
 
  let pname=ediv.attr('data-pname');

  let oof=getCreationDate(astuff);    // let getCreationDate extract info from astuff
  let nowdate=oof['dayCount'];

  let eu=$('#updatedCreationDate');
  eu.show();

  let etable=$('#portfolioHistory1AssetRows');
  let erows=etable.find('.portfolioAssetNameNew');
  for (let ii=0;ii<erows.length;ii++) {
     let arow=$(erows[ii]);
     aname=arow.attr('data-orig');
     let asay=portfolioAssets_currentInfo(aname,nowdate) ;

     let etr=arow.closest('.portfolioHistoryRow');
     let esummary=etr.find('.cportfolioTable1_summaryCell');
     let ediv=esummary.find('div');
     ediv.html(asay);
  }
  window.setTimeout(function() {
     eu.fadeOut(1500);
     buildPortfolioMenu_priceUpdate_show(0,astuff);
  },200);
}


//=-------------------
// redisplay asset attributres (in col 4 of the initialize portfolio menu) --
// if 2nd arg: astuff has current date info

function buildPortfolioMenu_priceUpdate_show(ifoo,astuff) {
   let nowdate,nowdateSay;

   if (arguments.length==2) {
      let dstuff=getCreationDate(astuff);
      if (dstuff===false) return false  ; // bad date (out of bounds)
      nowdate=dstuff.dayCount;
      nowdateSay=dstuff['sayDate'];
   } else {
      let oof1= getCreationDate('#portfolioMenu_initDateBlock');
      nowdate=oof1.dayCount ;
      nowdateSay=oof1.sayDate;
   }


  let etable=$('#portfolioHistory1AssetRows');
  let etrs=etable.find('.portfolioHistoryRow');
  for (let itt=0;itt<etrs.length;itt++) {
     let aetr=$(etrs[itt]);
     let ainput=aetr.find('.portfolioAssetNameNew');
     let aname=ainput.attr('data-orig');
     let goo= portfolioAssets_currentInfo(aname,nowdate);
     let esummary=aetr.find('.cportfolioTable1_summaryCell');
     esummary.html(goo);
  }

  if (ifoo==1) {         // modification

    let etable=$('#portfolioHistory1');
    let daheaders=etable.find('.cAllocationHeader');
    daheaders.hide();
    let amess2='Asset attributes as of '+nowdateSay;
    let da1=etable.find('[name="allocationHeader_changes"]');
    da1.html(amess2);
    da1.show();

    $('#buildPortfolioMenu_whatshow').html('&#128712; Asset attributes ... ');

  }

  return 1;

}


//=================================
// display asset specific "growth" (bafore a change)
function buildPortfolioMenu_showGrowth(athis) {

  let agrowths= simInvDsets['entryWorking']['grown']['growths'] ;
  let modlist= simInvDsets['entryWorking']['grown']['assetList'] ;
  let assetValues=simInvDsets['entryWorking']['grown']['assetDetails'] ;

  let mlookup={};
  for (let i0=0;i0<modlist.length;i0++) {
      let aname=modlist[i0]['name'];
      mlookup[aname]=i0;
  }

  let growDays=simInvDsets['entryWorking']['growDays'] ;    // if 0, a change existing modification

  let cash0=simInvDsets['entryWorking']['base']['cash'];
  let cash1=simInvDsets['entryWorking']['grown']['cash'];

  let dcash=cash1-cash0;

  let etable=$('#portfolioHistory1');
  let eins=etable.find('[name="portfolioAsset"]');


  for (let ii=0;ii<eins.length;ii++) {

     let ein=$(eins[ii]);
     let etr=ein.closest('.portfolioHistoryRow');
     let esummary=etr.find('.cportfolioTable1_summaryCell');
     let aname=ein.attr('data-orig');

     let atype=getAssetType(aname);

     if (!agrowths.hasOwnProperty(aname)) {   // newly added, so no changes
        let amess='&hellip;';
        esummary.html(amess);
        continue;
     }

     let achange1= agrowths[aname]  ;

     let amess='';
     if (atype==0 ) {
          let dq=achange1['growthQ']-achange1['baseQ'];
          let taxpaid=achange1['earningsPeriod']-achange1['earningsPeriodAT'] ;
          amess+='<span class="cshowChanges" title="Change in # shares">';
          amess+=   ' dQ=<tt>'+dq.toFixed(1)+'</tt>' ;
          amess+='</span>';
          amess+='<span class="cshowChanges" title="After tax earnings -- it is used to buy additional shares">';
          amess+=   '&nbsp;&nbsp; using earnings= <tt>'+achange1['earningsPeriodAT'].toFixed(1)+'</tt> ';
           amess+='  (<span style="font-size:85%" title="Tax paid">tax:<tt> '+achange1['earningsTaxPeriod'].toFixed(0)+'</tt></span>) ';
          amess+='</span> ';

          let netv=assetValues[aname]['valueNetAT'];

          let netvSay=wsurvey.makeNumberK(netv,10000);
           amess+='<span title="approximate (standalone) net value after cap gains tax" class="netValueAfterGrowth">netValue AT: '+netvSay+'  </span>';


     } else if (atype==1) {
          amess+='<span class="cshowChanges" title="Change in after-tax earnings  -- it is reinvested ">';
          amess+=   ' Earnings= <tt>'+achange1['startGrowthPeriodAT'].toFixed(0)+'</tt> ';
          amess+='  (<span style="font-size:85%" title="Tax paid (on starting value growth + additions growth)">tax: <tt>'+achange1['earningsTaxPeriod'].toFixed(0)+'</tt>  </span>) ';
          amess+='  (<span style="font-size:85%" title="Raw additions">additions: <tt>'+achange1['additionPeriodRaw'].toFixed(0)+'</tt>  </span>) ';
          amess+='</span> ';

          let netv=assetValues[aname]['valueNetAT'];

          let netvSay=wsurvey.makeNumberK(netv,10000);
           amess+='<span  title="value (bonds are not taxed when sold)"  class="netValueAfterGrowth">netValue: '+netvSay+'</span>';

     } else if (atype==2) {
          let isI= mlookup[aname];
          isrmd=modlist[isI]['doRMD'];
          amess+='<span class="cshowChanges" title="Change in pre-tax earnings -- it is reinvested">';
          amess+=   ' Earnings= <tt>'+achange1['earningsPeriod'].toFixed(0)+'</tt> ';
          if (isrmd==0) {
             amess+='  (<span style="font-size:85%" title="Additions (possibly due to RMD)">additions: <tt>'+achange1['additionPeriod'].toFixed(0)+'</tt>  </span>) ';
          } else {
             let aadd=-parseInt(achange1['additionPeriod']);
             amess+='  (<span style="font-size:85%" title="RMD withdrawals (pre-tax)"> <tt>RMDs: '+aadd +'</tt>  </span>) ';
          }
          amess+='</span> ';

          let netv=assetValues[aname]['valueNetAT'];

          let netvSay=wsurvey.makeNumberK(netv,10000);
          amess+='<span  title="value (after paying deferred tax)"  class="netValueAfterGrowth">netValueAT: '+netvSay+'</span>';

     } else if (atype==3) {

          amess+='<span class="cshowChanges" title="Change in after-tax earnings (rents)  -- it is added to `Cash` ">';
           amess+=   ' Earnings= <tt>'+achange1['rentPeriodAT'].toFixed(1)+'</tt> ';

           let taxpaid=achange1['rentPeriod']-     achange1['rentPeriodAT'] ;
           amess+='  (<span style="font-size:85%" title="Tax paid (on rents)">tax: <tt>'+taxpaid.toFixed(0)+'</tt>  </span>) ';
           amess+='</span> ';
           let loanPaidSay = (achange1['loanPaidPeriodAT']!==false)  ? wsurvey.makeNumberK(parseInt(achange1['loanPaidPeriodAT']),20000)  : ' ...' ;
           amess+='&nbsp;&nbsp;&nbsp; [<span class="cshowChanges" title="Loan payments (after tax)">' ;
           amess+=   ' loanPaid= <tt>'+loanPaidSay+'</tt>' ;
           amess+='</span>]';

          let netv=assetValues[aname]['valueNetAT'];

          let netvSay=wsurvey.makeNumberK(netv,10000);
          amess+='<span  title="value (after ... paying off loan, saleCosts, and capital gains tax)"  class="netValueAfterGrowth">netSaleAT: '+netvSay+'</span>';


     } else if (atype==4) {
          amess+='<span class="cshowChanges" title="Income received (after tax) -- it is added to `Cash` ">';
          amess+=   ' Income= <tt>'+achange1['incomePeriodAT'].toFixed(0)+'</tt> ';
          let taxpaid=achange1['taxPeriod']  ;
          amess+='  (<span style="font-size:85%" title="Tax paid">tax: <tt>'+taxpaid.toFixed(0)+'</tt>  </span>) ';
          amess+='</span> ';

          let netv=assetValues[aname]['yearlyIncome'];

          let netvSay=wsurvey.makeNumberK(netv,10000);
          amess+='<span  title="Yearly income (pre tax)"  class="netValueAfterGrowth">Yearly income: '+netvSay+'</span>';

     } else if (atype==5) {
          amess+='<span class="cshowChanges" title="Annuity received (after tax) -- it is added to `Cash` ">';
          amess+=   ' Annuity= <tt>'+achange1['incomePeriodAT'].toFixed(0)+'</tt> ';
          let taxpaid=achange1['taxPeriod']  ;
          amess+='  (<span style="font-size:85%" title="Tax paid">tax: <tt>'+taxpaid.toFixed(0)+'</tt>  </span>) ';
          amess+='</span> ';

          let netv=assetValues[aname]['yearlyAnnuity'];

          let netvSay=wsurvey.makeNumberK(netv,10000);
          amess+='<span  title="Yearly annuity (pre tax)"  class="netValueAfterGrowth">Yearly annuity: '+netvSay+'</span>';

     } else if (atype==7) {
          amess+='<span class="cshowChanges" title="Expense paid (after tax deductions accounted for) -- it is subtracted from `Cash` ">';
          amess+=   ' Expense= <tt>'+achange1['expensePeriodAT'].toFixed(0)+'</tt> ';
          let taxpaid=achange1['taxPeriod']  ;
          amess+='  (<span style="font-size:85%" title="Tax savings">tax: <tt>'+taxpaid.toFixed(0)+'</tt>  </span>) ';
          amess+='</span> ';

          let netv=assetValues[aname]['yearlyExpense'];
          let netvSay=wsurvey.makeNumberK(netv,10000);
          amess+='<span  title="Yearly expense (pre tax)"  class="netValueAfterGrowth">Yearly expense: '+netvSay+'</span>';

     }

     esummary.html(amess);
  }

// show the appropriate header
  let daheaders=etable.find('.cAllocationHeader');
  daheaders.hide();
  let amess2='';
  let dcashSay=wsurvey.makeNumberK(parseInt(dcash),10000);
   amess2+='Changes (earnings, loans,...) in last '+growDays+' day. ';
   amess2+='<span style="border-bottom:1px dotted blue" title="Growth in `Cash`. Includes  ... ';
   amess2+='\n   interest growth on `Cash` from prior entry ';
   amess2+='\n   +/- rents,  + incomeStreams, - expenseStreams, + annuities ';
   amess2+='\n   + RMD distributions ';
   amess2+='\n   +/- additions to (or withdrawals from) regular  &amp; tax-deferred bonds ';
   amess2+='\n   +/- oneOffs ';
   amess2+='\n   - loan payments "><tt>&#8710;Cash:</tt></span> '+dcashSay  ;
  let da1=etable.find('[name="allocationHeader_changes"]');
  da1.html(amess2);
  da1.show();

  $('#buildPortfolioMenu_whatshow').html('<span title="Growth and earnings in this period" style="color:blue">&#8710; Growth &amp; additions</span>   <span title="Net values after growth"style="color:purple"> &rarr; net Values </span> ');

  return 1;
}

//================    baseGrown
// show modifications (change specifed by user) of a portfolio   -- called via button push

function buildPortfolioMenu_showMods(athis) {
  let pname=simInvDsets['entryWorking']['name'];

  let modPortfolioValue=portfolioCalcValueMenu_modify(0,pname)  ; // buildPortfolioMenu_showMods  ...update entryWorking global  (first arg ingored)

  let etable=$('#portfolioHistory1');

  let achanges=simInvDsets['entryWorking']['changed'];     // created by portfolioCalcValueMenu_modify

  let modlistC2=achanges['assetList'];
  let summary=achanges['modifiedEntry']['summary'];

  let eins=etable.find('[name="portfolioAsset"]');
  let growDays=simInvDsets['entryWorking']['growDays'] ;
  let cash0=simInvDsets['entryWorking']['grown']['cash'];

  let changelist=summary['changeList'],newList=summary['newList'];
  let incomeListChange=summary['incomeListChange'] ;
  let removeList=summary['removeList'] ;
  let refiList=summary['refiList'] ;
  let expenseListChange=summary['expenseListChange'] ;

  let purchaseList=summary['purchaseList'],saleList=summary['saleList']  ;

   for (let ii=0;ii<eins.length;ii++) {

     let ein=$(eins[ii]);
     let etr=ein.closest('.portfolioHistoryRow');
     let esummary=etr.find('.cportfolioTable1_summaryCell');
     let aname=ein.attr('data-orig');

     let atype=getAssetType(aname);

     if (removeList.hasOwnProperty(aname))  {   // removed
        let amess=' ';
        if (incomeListChange.hasOwnProperty(aname)) {
           let aamt=incomeListChange[aname];
           let aamtSay=wsurvey.addComma(parseInt(aamt) )  ;
           if (atype==4) {
               amess='Decrease in yearly income: <tt>'+aamtSay+'</tt>';
          } else if (atype==5) {
              amess='Decrease in yearly annuity: <tt>'+aamtSay+'</tt>';
           }
        } else if (expenseListChange.hasOwnProperty(aname)) {
           if (atype==7) {
               amess='Decrease in yearly expense: <tt>'+aamtSay+'</tt>';
           }
        }  else {                 // stock bond taxdeferred or property
           let aamt=saleList[aname];
           let aamtSay=wsurvey.addComma(parseInt(aamt) )  ;
           if (atype==0) {
               amess='&hellip; stock liquidation (pre tax)= <tt>'+aamtSay+'</tt>' ;
           } else if (atype==1) {
              amess='&hellip;  bond liquidation= <tt>'+aamtSay+'</tt>' ;
           } else if (atype==2) {
              amess='&hellip;  tax-deferred liquidation (pre tax)= <tt>'+aamtSay+'</tt>' ;
           } else if (atype==3 ) {
             amess='&hellip;  property sale (pre tax)= <tt>'+aamtSay+'</tt>' ;
           } else {
            amess='zzzz';
         }
       }
       esummary.html(amess);
       continue ;

     }         // removed

     if (newList.hasOwnProperty(aname))  {   // newly added
        let aamt=newList[aname],amess='xxzz';
        let aamtSay=wsurvey.addComma(parseInt(aamt)) ;

        if (atype==0) {
             amess='&hellip; new stock: purchase= <tt>'+aamtSay+'</tt>' ;
        } else if (atype==1) {
             amess='&hellip; new bond purchase= <tt>'+aamtSay+'</tt>' ;
        } else if (atype==2) {
             amess='&hellip; new tax-deferred bond purchase (tax adjusted)= <tt>'+aamtSay+'</tt>' ;
       } else if (atype==3 ) {
          amess='&hellip; new property: acqusition cost= <tt>'+aamtSay+'</tt>' ;
       } else if (atype==4 ) {
          let inc1=(incomeListChange.hasOwnProperty(aname)) ? incomeListChange[aname] : '...' ;;
          let inc1Say=wsurvey.addComma(parseInt(inc1)) ;
          amess='&hellip; new yearly incomeStream=<tt>'+inc1Say+'</tt>, w/acqusition cost= <tt>'+aamtSay+'</tt>' ;
       } else if (atype==5 ) {
          let inc1=(incomeListChange.hasOwnProperty(aname)) ? incomeListChange[aname] : '...';
          let inc1Say=wsurvey.addComma(parseInt(inc1)) ;
          amess='&hellip; new yearly annuity=<tt>'+inc1Say+'</tt>, w/acqusition cost= <tt>'+aamtSay+'</tt>' ;
       } else if (atype==6 ) {
         amess='&hellip; new oneOff (amount added start of next day)' ;
       } else if (atype==7 ) {
          let exp1=(expenseListChange.hasOwnProperty(aname)) ? expenseListChange[aname] : '...' ;;
          let exp1Say=wsurvey.addComma(parseInt(exp1)) ;
          amess='&hellip; new yearly expenseStream=<tt>'+exp1Say+'</tt> ' ;

       }
       esummary.html(amess);
       continue ;
     }          // newList  -- added asset

     if (atype==3 && refiList.hasOwnProperty(aname))  {   // a refi
       let amt=parseInt(refiList[aname]);
       let amess;
       if (amt==0) {
          amess='&hellip; refinance.  ' ;
       } else if (amt>0) {
          amess='&hellip; refinance. with '+wsurvey.addComma(amt)+' loan increase (added to <u>Cash</u>).  ' ;
       } else if (amt<0 ) {
          amess='&hellip; refinance. with  '+wsurvey.addComma(-amt)+' loan reduction (withdrawn from <u>Cash</u>)';
       }
       esummary.html(amess);
       continue;
     }

     if (jQuery.inArray(aname,changelist)<0)  {   // not new and  no changes
        let amess='&hellip; no changes ' ;
        esummary.html(amess);
        continue;
     }       //changelist : retained asset with no chage

// if here, must be a change

     if (saleList.hasOwnProperty(aname))  {   // partial sale..
       let aamt=saleList[aname];
       let aamtSay=wsurvey.addComma(parseInt(aamt)) ;
       let amess='Sale proceeds: <tt>'+aamtSay+'</tt>';
       esummary.html(amess);
       continue;
     }           //earnrlist  -- selling portion of a retained asset

     if (purchaseList.hasOwnProperty(aname))  {         // a purchase addition
       let aamt=purchaseList[aname];
       let aamtSay=wsurvey.addComma(parseInt(aamt)) ;
       let amess='Purchase cost: <tt>'+aamtSay+'</tt>';
       esummary.html(amess);
       continue;
     }        //  cost list (adding to retained asset)

     let amess='should not see this '  ;
     esummary.html(amess);

  }

  let efoo=etable.find('.cAllocationHeader');
  efoo.hide();

  $('#buildPortfolioMenu_whatshow').html('&#128496; Modifications (after growth)');

  let amess2 ='Modifications: changes, additions, and removals (after growth)' ;
  let da1=etable.find('[name="allocationHeader_changes"]');
  da1.html(amess2);
  da1.show();

}



//=======================
// info on "base" (pre growth) of a modification
function buildPortfolioMenu_showBase(athis) {
  let etable=$('#portfolioHistory1');
  let eins=etable.find('[name="portfolioAsset"]');

  let growDays=simInvDsets['entryWorking']['growDays'];
  let cash0=simInvDsets['entryWorking']['cashAsset'];
  let startDate= simInvDsets['entryWorking']['startDate'];

  let vBaseVals=simInvDsets['entryWorking']['base']['assetList']  ;
  let baseVals={};
  for (let ij=0;ij<vBaseVals.length;ij++) {
      let zaa=vBaseVals[ij]['name'];
      baseVals[zaa]=vBaseVals[ij] ;
  }

  let cashAssetBase=simInvDsets['entryWorking']['base']['cash']  ;

  for (let ii=0;ii<eins.length;ii++) {
     let ein=$(eins[ii]);
     let aname=ein.attr('data-orig');
     let amess='';
     if (!baseVals.hasOwnProperty(aname)) {        // not in base portfolio
         amess='&hellip;';
    } else {                               // existing~
       let avals=baseVals[aname];
       let atype=avals['assetType'];
       amess+='<span  title="Estimated cost (to obtain asset) " class="cmyCost_span">'+avals['cost'].toFixed(0) +'</span>';  // all types have a cost
       if (atype==0) {
         amess+=' <span  title="Share price " class="cmyNetRevenue_span">price: '+avals['price'].toFixed(2)   +'</span>';
       } else if (atype==1) {
          let amountSay= wsurvey.makeNumberK(parseInt(avals['nShares']),99000);
          amess+=' <span  title="$value of shares " class="cmyNetRevenue_span">value: '+amountSay +'</span>';

       } else if (atype==2) {
          let amountSay= wsurvey.makeNumberK(parseInt(avals['nShares']),99000);
          amess+=' <span  title="$value of shares (pre-tax) " class="cmyNetRevenue_span">value: '+amountSay +'</span>';

       } else if (atype==3) {
          let aprice=avals['price']   ;
          let apriceSay= wsurvey.makeNumberK(aprice,99000);

          let loanOwed= avals['loanOwed']  ;
          let netV=aprice-loanOwed;
          let netVSay=wsurvey.makeNumberK(netV,99000);

          amess+=' <span  title="Price" class="cmyValue_span">price: '+apriceSay +'</span>';
          amess+=' <span  title="net Value" class="cmyNetValue_span">net: '+netVSay +'</span>';
          let amountSay= wsurvey.makeNumberK(parseInt(avals['loanAmount']),99000);
          amess+=' <span  title="Original loan amount" class="cmyNetRevenue_span">loan: '+amountSay +'</span>';

       } else if (atype==4) {
          let aincome=getAssetValue(startDate,aname,'income');
          let aincomeSay=wsurvey.makeNumberK(aincome,99000);
          amess+=' <span  title="Yearly income " class="cmyValue_span">net: '+aincomeSay +'</span>';

       } else if (atype==5) {
         let incomeStart=  avals['incomeStart']  ;

          let cc1=calcAnnuityValue(aname,incomeStart,startDate) ;  // [baseValue,baseGrowth,calcValue,day1,day2,dointerp,growthRateAgg]
          let baseAnnuity=cc1[0];
          let aincome=cc1[2];
          let aincomeSay=wsurvey.makeNumberK(aincome,99000);
          let baseAnnuitySay=wsurvey.makeNumberK(baseAnnuity,99000);

          amess+=' <span  title="Yearly income (annuity)" class="cmyValue_span">Income: '+aincomeSay +'</span>';
          amess+=' <span  title="Yearly annuity income @ start" class="cmyNetRevenue_span">base: '+baseAnnuitySay +'</span>';


       } else if (atype==6) {
          amess+=' <span  title="Original loan amount" class="cmyNetRevenue_span">oneOff:</span>';

       } else if (atype==7) {
          amess+=' <span  title="Expense amount" class="cmyNetRevenue_span">Expense: </span>';

       }


     }
     let etr=ein.closest('.portfolioHistoryRow');
     let esummary=etr.find('.cportfolioTable1_summaryCell');
     esummary.html(amess);

  }

// show the appropriate header
  let daheaders=etable.find('.cAllocationHeader');
  daheaders.hide();

  let da1=etable.find('[name="allocationHeader_base"]');
  da1.show();

  let cashSay=wsurvey.makeNumberK(cashAssetBase,30000)
  $('#buildPortfolioMenu_whatshow').html('&#9918;Start (preGrowth), <u>Cash</u>='+cashSay);


}


//====================
// sort the list of assets buttons (above the asset-mix table)
// ihow: 0=order of appearanc, 1=name, 2=type/name
function buildPortfolioMenu_sortAsset(athis) {
  let ethis=wsurvey.argJquery(athis) ;
  let isort=ethis.attr('data-how');
   let doSort=parseInt(isort)+1;
   if (doSort>2) doSort=0;
    ethis.attr('data-how',doSort);

  let etable=$('#portfolioHistory1');
  let elist=etable.find('[name="portfolioTable_assetButtons"]');
  let elis=elist.find("li");

  let alist=[];
  let newList=[];
  newList[0]=0   ; // Cash is always first
  let notUseList=[];
  for (let jli=0;jli<elis.length;jli++) {
      let eliA=$(elis[jli]);
      let isInit=eliA.attr('data-init');
      if (isInit==0   ) {   // not initialzd,
         notUseList.push(jli);
         continue ;
      }
      let atype=parseFloat(eliA.attr('data-type'));
      if (atype<0) continue         // cash ;
      let aorig=parseInt(eliA.attr('data-orig'));
      let aname=eliA.attr('data-name');
      let foo;
      if (doSort==1) {     // by name
         foo=[aname,0,jli];
      } else if (doSort==2) {   // type/name
         foo=[atype,aname,jli];
      } else {
         foo=[aorig,0,jli];
      }
      alist.push(foo)
  }
  alist.sort(buildPortfolioMenu_sortAsset_sort);

  for (let ia=0;ia<alist.length;ia++)  newList.push(alist[ia][2]);
  for (let ib=0;ib<notUseList.length;ib++)  newList.push(notUseList[ib] ) ;

  for (let ic=0;ic<newList.length;ic++) {
      let jj=newList[ic];
      elist.append(elis[jj]);
  }


}

//=====
// sort an array of arrays (using first array elment, and 2nd if firsts match)
// do NOT assume numeric (lexigraphic sort)
function buildPortfolioMenu_sortAsset_sort(a,b) {
 let a1=a[0]; let b1=b[0];
 if (a1==b1) {         // use secondary sort
    let a2=a[1], b2=b[1];
    if (a2==b2) return 0;
    if (a2>b2) return 1 ;
    return -1;
 }
 if (a1>b1) return  1 ;
 return -1;
}
