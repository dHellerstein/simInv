//=========== user initialization simInv functions


//======================== ============
// ::::::::::: local storage initialzation ::::::::::
//==============================

//=======================
// initialize a local user
function initUserLocal(ifoo) {
   let bmess='';
   let qStandAlone=( simInvDsets['simInvLocalStorage']['protocol']=='file') ? true : false ;

   if (qStandAlone) {           // standalone mode
      bmess+='<b>Welcome</b> <u>'+userName+'</u>. You  have <u>not</u> been initialized as a simInv user on this device.';
      bmess+='<br><em>You can</em>: '
      bmess+='<ul class="tightMenu">';
      bmess+='<li><button onClick="doLogoff(0)">Logoff</button> (and try logging on using a different name) ';
      bmess+='<li><button onClick="doLogon_localC(this)" data-how="2" data-name="'+userName+'">Initialize!</button> (<em>standAlone</em> mode) ';
      bmess+='<ul>';
      simInv_errorMessage(bmess);
      return 0;
   }

// else, onLine user...
   let qLocal=  simInvDsets['simInvLocalStorage']['enabled'];

   if (qLocal==2)  {   //  user choose storage mode
      bmess+='<b>Welcome</b> <u>'+userName+'</u>. You  have <u>not</u> been initialized as a local-storage simInv user on this device.';
      bmess+='<br><em>You can ....</em> '
      bmess+='<menu>';
            bmess+='<li> <button onClick="doLogoff(0)">Logoff</button> (and try logging on using a different name) ';
            bmess+='<li> <a target="info" href="compareStorage.htm">View a comparision</a> of local and server storage';
      bmess+='</menu>    ';
      bmess+='<em>or</em> chose one of these modes. This choice is permanent -- it is used in all your ('+userName+')  future simInv logons ';
      bmess+='<ul class="tightMenu">';
     let cdomain = window.location.host;
      bmess+='<li><button onClick="doLogon_localC(this)" data-how="4" data-name="'+userName+'">Use local store</button>  <em>(on this device &amp; browser)</em> ';
      bmess+='<li><button onClick="doLogon_localC(this)" data-how="5" data-name="'+userName+'">Use server storage</button>  <em>(on  <tt>'+cdomain+'</tt>)</em>  ';
      bmess+='<ul>';
     
      simInv_errorMessage(bmess);
      return 0;

   }    else {             // onLine assigned to local storage mode

      bmess+='<b>Welcome</b> <u>'+userName+'</u>. You  have <u>not</u> been intiialized as a simInv user on this device.';
      bmess+='<em>Please choose ...</em> '
      bmess+='<em>or</em> '
      bmess+='<ul class="tightMenu">';
      bmess+='<li> <button onClick="doLogoff(0)">Logoff</button> (and try logging on using a different name) ';
      bmess+='<li><button onClick="doLogon_localC(this)" data-how="3" data-name="'+userName+'">Initialize!</button> (<em>onLine using local storage</em> mode ) ';
      bmess+='<ul>';
      simInv_errorMessage(bmess);
      return 0;
 }
}

//========================
// initializing a user on local storage -- he selected mode, so now do the initialization (create an dataStore for this user  in the users database
// event handler -- create user
function doLogon_localC(athis) {
   ethis=wsurvey.argJquery(athis);
   simInv_errorMessage(false);
   let aname=ethis.attr('data-name');
   let ahow=ethis.attr('data-how');        // 2: standalone, 3 online assigned local, 4 online chose local, 5 online chose server
   let rdata={};
   if (ahow!=5) {
       rdata={        'settings':{'time':false,'data':{}},
                      'cpiuSeries':{'time':false,'data':{}},
                      'assets':{'time':false,'data':[]},
                      'assetHistory':{'time':false,'data':{}},
                      'portfolios':{'time':false,'data':[]},
                      'portfolioInit':{'time':false,'data':{}},
                      'portfolioModifications':{'time':false,'data':{}},
                      'scenario':{'time':false,'data':{}},
                      'viewDates':{'time':false,'data':[]},
                      'updateDate':false };
   } else {
       rdata=false;  // if "chose server storage", data is false (nothing to save locally)
   }

   initUserData_indexDb(aname,doLogon_localD,ahow,rdata) ;  // this saves initialization info, for this user, to indexDB local storage ...
}

// user data initlaized. Add "default settings"  and cpiuSeries  -- but NOT if 'user chose server storage" (that will happen on next logon )
function doLogon_localD(astatus,astuff,ahow) {
   let bmess='';

   if (astatus==0) {
       bmess+='<tt>'+astuff+'</tt><br>';
       bmess+='Unable to create simInv data  ... there is a problem with your on line storage. See <a href="readme.txt" target="readme">readme.txt</a> for further information ';
       simInv_errorMessage(bmess);
       return 0;
   }

    cmess=' You can change your <em>personal settings</em>, at any time, using <button>&#9965;</button>settings. ';
   cmess+='<br>And you can update the CPIU (inflation) series at any time, using <button class="cdoButtonRegular"   >&#11192; &#206;nflation</button> ';
   let myHint='';

   if (ahow==5) {     // online chose server ... do inits on next logon
       bmess+='You (<tt>'+userName+'</tt>) chose server storage! When you next logon, simInv will initialize your account ' ;
       simInv_errorMessage(bmess,1);       // user should "logon again" ... now that the simInv data has been initialized (locally)
       return 1;
    }

//  else a local storage...
   saveSimInvData_settingsInit(userName,doLogon_localE,simInvParams,simInvGlobals['cpiuSeries'],myHint,cmess) ;       // in doLogon_localD... save default settings and cpiUseries

}

// ==============
// callback -- user initialized, so now do a logon (now with local storage data available for this user)
function doLogon_localE(astatus,astuff) {

   let bmess='';
   if (astatus==0) {
       bmess+='<tt>'+astuff+'</tt><br>';
       bmess+='Unable to add settings data .. there is a problem with your on line storage. See <a href="readme.txt" target="readme">readme.txt</a> for further information ';
       simInv_errorMessage(bmess);
       return 0;
   }
   if (astuff['data']===false)  { // chose server storage
       bmess+='You (<tt>'+userName+'</tt>) chose server storage! ' ;
    } else {
       bmess+='You (<tt>'+userName+'</tt>) are initialized to use local storage! ' ;
    }
    simInv_errorMessage(bmess,1);       // user should "logon again" ... now that the simInv data has been initialized (locally)
}


//======================== ============
// ::::::::::: server storage initialzation ::::::::::
//==============================
// ====================
// initialize online user
function initUserOnline(ifoo) {
      clearTimeout(simInvGlobals['monitorStartup_id']);  // relogon should occur, so stop this failure monitor
     let amess='';
     amess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#firstLogonInit">&#10068;</button> ';
     amess+='Hello <tt>'+userName+'</tt>. This is your first logon -- some initialization is required! ';
     amess+='<br><label title="Check to encrypt your simInv data">';
     amess+=' <input id="iwantToEncrypt" onClick="checkUserExistsOnline2_viewEncMenu(this)" type="checkbox" value="1">Do you want to <u>encrypt your data?</u></label> ';
     amess+='<div id="iEncryptionKey_initOuter" style="display:none"> ... please enter your <tt>personal encryption key</tt>: ';
     amess+='<input type="text" size="20" id="iEncryptionKey_init"> ';
     amess+='<br><em>Optional:</em> enter a hint (to help you remember your encryption key) <input type="text" size="40" id="iEncryptionKey_init_hint"> ';
     amess+='</div>';
     amess+='<p><button class="cdoButtonRegular"  onClick="checkUserExistsOnline2_init(this)">Initialize your account!</button>';
     displayStatusMessage(amess);
     toggleStatusMessage(0,0);
     return 1;
}



//============
// toggle view of "specify an encryption key and hint"
function checkUserExistsOnline2_viewEncMenu(athis) {
   ethis=wsurvey.argJquery(athis);
   if (ethis.prop('checked')) {
     $('#iEncryptionKey_initOuter').show();
   } else {
     $('#iEncryptionKey_initOuter').hide();
     $('#iEncryptionKey_init').val('');
   }
}
// ===========  :::::::::::::::::::::::::::::::::::::::;
// checkUserExistsOnline2 determined this is a new user,
// so save settings and other  initialization info (such as encryption choice)
// Note send encruyptionkey hint, and md5 of encryption key, to the server : do NOT send the actual encryption key!
// on return from server, ask user to logon again (since now initialized, will NOT come back here)
// note that several php calls ares used (one for each server based, user specific, database to set up)

function  checkUserExistsOnline2_init(athis) {

  let e1=$('#iwantToEncrypt');
  let qencrypt=e1.prop('checked');

  let nowTime=wsurvey.get_currentTime(0);

   let myhint='',useKey='', encryptionKey_md5X='';

   if (qencrypt) {
      let ekey=$('#iEncryptionKey_init');     // the one for "init",... not the one for "logon"
      let encryptionKeyX=jQuery.trim(ekey.val());
      if (encryptionKeyX=='') {
         clearTimeout(simInvGlobals['monitorStartup_id']);  // relogon should occur, so stop this failure monitor
         alert('You chose to encrypt your data, but did NOT provide an encryption key! \nPlease try again ');
        return 0;
      }
      encryptionKey_md5X=simInv_makeEncMd5(encryptionKeyX) ;
      let e2h=$('#iEncryptionKey_init_hint');
      myhint=e2h.val();
      myhint=wsurvey.removeAllTags(myhint);
      useKey=encryptionKeyX ;

   } else {
     if (simInvGlobals['encryptionKey']!=='' || simInvGlobals['encryptionKey_md5']!='' ) {
        clearTimeout(simInvGlobals['monitorStartup_id']);  // relogon should occur, so stop this failure monitor
        alert('You chose NOT to encrypt your data, but DID provide an encryption key!   \nPlease try again ');
        return 0;
     }
   }

// encryptionKey_md5 is saved on server (it serves as a logon password)
   let ddata={'time':nowTime,'username':userName,'encMd5':encryptionKey_md5X};   // since hint can change, don't save it to the "permanent" encMd5.json

   let bmess='Initialization step 1 completed.';
   if (encryptionKey_md5X!=''){
             bmess+='<p>You specified an encryption key (<tt>'+useKey+'</tt>)! Don`t forget it, you will need it everytime you logon.';
            bmess+='<br>Hint: you can change specify a <em>hint</em> -- it will be displayed if you logon with an incorrect encryption key.';
            bmess+' This hint can be changed at any time (using <button>&#9965;</button>settings.) ';
   }

   saveSimInvData_saveEncMd5(userName,checkUserExistsOnline2_initB,ddata,bmess,myhint,useKey)    ;   // myhint not used  by saveSimInvData_saveEncMd5, but is sent to  checkUserExistsOnline2_initB
}

//=================
// onlineInit step 2: after creating encMd5.json... now save default user settings and cpiUseries
function checkUserExistsOnline2_initB(astatus,amess,myhint,usekey) {

   if (astatus==0) {
       amess+='<br>Unable to add initialization data .. .. there is a problem with your server  storage. Please contact the site admim (see <a href="readme.txt" target="readme">readme.txt</a> for further information) ';
       simInv_errorMessage(amess,1);
       return 0;
   }
   simInvParams['encryptionKeyHint']=myhint;         // the hint

//   let nowTime=wsurvey.get_currentTime(0);

   let cmess='Default settings saved for <tt>'+userName+'</tt>  -- you can change these at any time using <button>&#9965;</button> settings.' ;
   cmess+='<br>Initialization complete! You can now re-logon to start using simImv  ... ' ;
   if (simInvGlobals['encryptionKey_md5']!='')  {
         cmess+='<div style="margin:1em 5em;border:1px solid green">You specified an encryption key: <tt>'+usekey+'</tt>.';
         cmess+='<br> <b>Don`t forget it</b>, you will need it <b>everytime you logon</b> to simInv!';
         cmess+='<br>Note: your <em>hint</em> will be displayed if you logon with an incorrect encryption key.';
         cmess+='<br>To change the <em>hint</em>: use <button>&#9965;</button>settings. ';
         cmess+='<br>And you can update the CPIU (inflation) series at any time, using <button class="cdoButtonRegular">&#11192; &#206;nflation</button> ';
         cmess+='</div>';
   }

   saveSimInvData_settingsInit(userName,checkUserExistsOnline2_initC,simInvParams,simInvGlobals['cpiuSeries'],myhint,cmess,usekey,simInvGlobals['enableAutoArchive']) ;       // save default settings and cpiUseries, and hint

}

//===========
// settings now saved (or failure). If success, user must relogon (using a button). IF error, no relogon button
function checkUserExistsOnline2_initC(astatus,astuff,usekey) {
   let bmess='';
   if (astatus==0) {
       bmess+='<tt>'+astuff+'</tt><br>';
       bmess+='Unable to add settings data .. there is a problem with your server  storage. Please contact the site admim (see <a href="readme.txt" target="readme">readme.txt</a> for further information) ';
       simInv_errorMessage(bmess);
       return 0;
   }
   hideStatusMessage(200);
   if (usekey===false || jQuery.trim(usekey)=='') {
      simInv_errorMessage(astuff,1,'Please logon again ');         // force a relogon!
   } else {
      simInv_errorMessage(astuff,1,'Please logon again (using your encryption key)');         // force a relogon, using encryption ke!
   }

}

