

//====================
// grow a list of assets from the beginning to the end of a period
// Arguments:
//   pname: portoflio name
//   baseAssetList : array -- the list of assets (current values, etc)     -- NOT including Cash
//   baseCash   : Cash (as of startDate)
//   startDate : the dateStamp at the start of the period
//   modAssetList : array -- the "changed" (aka modified) asset mix. Or false if No Changes Due to Modification  (i.e.; this is a "grow only" call
//   modDate : dateStamp at end of period
//   modComment : comment about this modification
//   theBaseEntry : the entry # to be "grown", and possibly modified
//   theModEntry: the entry  # to saved. 0=save as the "init" entry, >0 save as the  nth modfication. False if a growth, with no modification
//
// What is done:
//   baseAssetList is the the asset mix (of portoflio pname) at start of period; and  baseCash  is Cash at start of period
//   baseAssetList is then "grown" (given interest rates, etc), yielding per aset growths and a grownEntry "after growth" asset mix
//   A final assetList is computed by "changing"  the "grown baseAssetList"
//   And a final Cash is the sum of baseCash, raw additions, interest growth of cash across period, cashChangeMod
//   Note: the "period" is the span between the startDate and endDate. Growth can occur in this period
//
//  Returns allStuff with properties:
//
//    name : portfolio name
//    username : user namae
//    startDate : start of period 
//    endDate: end of period
//    theBaseEntry : the entry # to be "grown", and possibly modified
//    theModEntry: the entry  # to saved. 0=save as the "init" entry, >0 save as the  nth modfication. False if a growth, with no modification
//    dateGrownFrom : the date grown from (theBaseEntry date) -- the prior entry date if a mod (or a growth) -- startDate=endDte=dateGrown from if init entry
//    dateMatch : date grown from if NOT modification; if modification the modificaiton date as dateGrowmFron
//    dateMatchSay : yyyy-mmm-dd version of dateMatch
//    modDateStampSay  : yyyy-mmm-dd of the date of theModEntryDate.. of or the initdate
//    dateStampSay  : same as modDateStampSay (9 march 2024 ... retained for backwards compatablity)
//    growDays : days of growth (viewDate-dateMatch). If 0, this is a refresh of an existing entry
//    base   : object with
//           assetList .. list of assets of theBaseEntry
//    grown::   object of "grown" (pre change) assets
//         growths:  for each assets, details on growth (during period)  -- includs oneOffs just added (hence are pending)
//         assetList :  array.. asset attributes after growth
//         sumByTypePeriod : information on after growth (before changes) total asset values by "type" of asset; and for all received oneoffs
//                               special case: if this is an "init" entry -- oneOffListUsed is the list of "pending" assets (value recieved the next day)
//         totals:  aggregate info on the "grown" entry
//         assetDetails : details on asset growth (including oneoffs)
//         cashChangeObj  : impacts on Cash due to asset growth (and oneOffs received)
//         totPeriod :    object with summary stats on revenue etc within the period
//     mod:  array -- list of modifications. False if init, or  grow only
//    assetList     -- assets AFTEr modifications. If no modifications, after growth (same as grown.assetList
//    cash   -- Cash after growth AND after changes due to modifications
//    cashChangeMod  : the changes in Cash due to modifiations (0 if no modifications, or if init entry
//    totals    -- summary after modification (same as grown.totals if no changes). If init, has info on total pending recevipes
//    totalsNet     --  summary after modification
//    cashAsset :    value of Cash (can be negative) ... after growth and modifications
//   comment:  a comment
//    summaryChanges: summary of changes due to modficiation. Includes oneOff pending info; and what assets were retained, changed, added, or removed
//    interp: 9 march 2024 --- to be used
//
// or false if an error

function growPortfolioDo(pname,baseAssetList,baseCash,startDate,modAssetList,modDate,modComment,theBaseEntry,theModEntry) {

//  console.trace(pname+' '+startDate+' '+modDate);
//       alert('pppp '+pname);

   let cSample=1    ;                       //4 march 2024... not currently used
   let allStuff={} ;                       // this is returned

   if (theModEntry!==false)  {             // check cache   -- use from cache if alredy calculated
     if (theModEntry==0)        {  // init
       if (simInvDsets['modInit_values']['inits'].hasOwnProperty(pname)) {
          allStuff=simInvDsets['modInit_values']['inits'][pname];
          simInvDsets['modInit_values']['stats']['initUse']++;
          return allStuff ;
       }
     } else {          // a mod entry
         if (simInvDsets['modInit_values']['mods'].hasOwnProperty(pname)) {
             if (simInvDsets['modInit_values']['mods'][pname].hasOwnProperty(modDate)) { ;
                allStuff=simInvDsets['modInit_values']['mods'][pname][modDate] ;
                simInvDsets['modInit_values']['stats']['modUse']++;
                return allStuff;
             }
         }
     }     // modentry=0
   }    // modentry=false


// not in cache ....

   let qInitEntry= (theBaseEntry===0 && theModEntry===0 ) ;
   let qModEntry= (theModEntry!==false && theModEntry>0) ;

// if here, do NOT use interpolation -- compute from growth, etc parameters

    simInvDsets['modInit_values']['stats']['noCache']++;

   let growdays=modDate-startDate;
   if (growdays<0) {
       simInvDsets['errors'].push('Trying to grow portfolio '+pname+' less than 0 days: '+startDate+' to '+modDate);
       return false ;
   }

   allStuff['name']=pname;
   allStuff['userName']=userName;
   allStuff['startDate']=startDate;
   allStuff['endDate']=modDate;

   allStuff['theBaseEntry']=theBaseEntry ;
   allStuff['theModEntry']=theModEntry ;

   let dateMatch;               //   date of this entry
   if (theModEntry!=false) {
     dateMatch=modDate;           // an exact match to an init or mod entry
     allStuff['dateGrownFrom']=startDate ;
   } else {
     dateMatch=startDate  ; // a growth from this date
     if (qModEntry) {
        allStuff['dateGrownFrom']=startDate ;
     } else {
        allStuff['dateGrownFrom']=startDate ;
     }
   }

   allStuff['dateMatchSay']=setEntryDate(dateMatch).sayDate; ;
   allStuff['dateMatch']=dateMatch ;

   let modDateSay=setEntryDate(modDate).sayDate;
   allStuff['dateStampSay']=modDateSay ;          // 7 march 2024... should be deprecated (but need to clean up existing references)
   allStuff['modDateStampSay']=modDateSay ;
   allStuff['growDays']=growdays;

   allStuff['base']={};
   allStuff['grown']={};
   allStuff['mod']={'assetList':modAssetList};        // for info purposes

   allStuff['assetList']={};       // after growth and after modification !
   allStuff['cash']=false;
   allStuff['cashChangeMod']=0;
  allStuff['totals']={};
   allStuff['totalsNet']={};
   allStuff['comment']=modComment;

   allStuff['base']['assetList']=baseAssetList;
   allStuff['base']['cash']=baseCash;
   allStuff['base']['ith']=theBaseEntry;

// grow each asset.
//  growthStuff properties:  'growths','doCash','dayGap','baseDateStamp','modDateStamp'}   ;
//   doCash properties:      total,isConstant,allNeg,allPos,info,oneOffs,details
// 1 march 2024 : cSample not currently used

   let growthStuff= portfolioAssetsGrow(pname,baseAssetList,startDate,modDate,growdays,cSample) ;   // grow the starting assets from startDate to modDate (growdays days)

   if (growthStuff==false)  {
       simInvDsets['errors'].push('portfolioAssetsGrow failed: trying to grow portfolio '+pname+' : '+startDate+' to '+modDate);
       return false ;
   }

   let growths=growthStuff['growths'];

   allStuff['grown']['growths']=growths ;

// add the growth info to the baseAssetList
   let growApply=portfolioAssetsGrow_apply(growths,baseAssetList,pname,modDate);          // add growths to base to create "grown" assetList

   let daListGrown=growApply['grownList'] ;

   allStuff['grown']['assetList']=daListGrown ;
   allStuff['grown']['sumByTypePeriod']={};
   for (let akk in growApply) {
      if (akk=='grownList') continue ;  // this is stored elswere
      if (akk=='oneOffsUsed') {         // don't store all of this
          let t1=[],t2={};

          for (let aa3a in  growApply['oneOffsUsed']['list']) {
              t1.push(aa3a);
              t2[aa3a]=growApply['oneOffsUsed']['list'][aa3a]['receiptPeriod'];
          }

          allStuff['grown']['sumByTypePeriod']['oneOffListUsed']=t1;
          allStuff['grown']['sumByTypePeriod']['oneOffListUsed_receiptPeriod']=t2;
          allStuff['grown']['sumByTypePeriod']['totReceiptPeriod']=growApply['oneOffsUsed']['totals']['totReceiptPeriod'] ;
          allStuff['grown']['sumByTypePeriod']['nOneOffsUsed']=t1.length;
      } else {
           allStuff['grown']['sumByTypePeriod'][akk]=growApply[akk];
      }
   }

   let pvalueGrow=portfolioCalcValue(daListGrown,modDate,pname,0,'for grownlist ') ;     // total asset values AFTER growth, BEFORE changes   (does NOT consider Cash)

   allStuff['grown']['totals']=pvalueGrow['totals'] ;
   allStuff['grown']['assetDetails']=pvalueGrow['assets'];

// compute Cash impacts
   let cimpacts=portfolioAssetsGrow_cimpacts(growthStuff['doCash'],baseCash,pname,growdays,modDate,startDate,cSample);  //startCash endCash  rawAdd  earnAdd  earnAddPlus  earnAddMinus  swDay  days

   allStuff['grown']['cashChangeObj']=JSON.parse(JSON.stringify(cimpacts)) ;
   allStuff['grown']['cash']=cimpacts['endCash'];

//ss1 properties: totRevenuePeriod_AT   totTaxOnRevenuePeriod  totLoanPayPeriod_AT
//                totLoanOwed   totLoanPayPeriod  totExpensePeriod_AT  totTaxOnExpensePeriod
//                12 march 2024: several more added
   let ss1=portfolioAssetsGrow_summary(growths,pname,startDate,modDate);

   allStuff['grown']['totPeriod']=ss1;

// do some tweak if this is an init ..
// In particular ... init calculations are idiosyncratic, hence need to do this to find "pending" oneoffs (that are in the init entry of a portfolio
   if (qInitEntry)   {                // init entry. .. check for oneOffs(modAssetList is false)
       let tmpO1=growApply['oneOffsUsed']['totals']['totBaseReceipt'];
       allStuff['grown']['totals']['totOneOffReceipt_pending']=tmpO1 ;
   }

// change the "grownEntry" asset list into the "modAssetList" ?
   let modifiedEntry,assetListAfterMod,cashChangesModification=0,modSummary,pvaluesAfterMod,modSummary2;
   if (modAssetList!==false) {      // modifications to be made! (init, or growonly, always has modAssetList=false


     modifiedEntry=portfolioCalcValueMenu_difference(pname,modDate,daListGrown,modAssetList) ;  // buy/sell assets from daListGrown to achieve modEntry

     let tmpO1=modifiedEntry['summary']['totOneOffReceipts_pending'];
     allStuff['grown']['totals']['totOneOffReceipt_pending']=tmpO1 ;

     let assetListAfterMod=allStuff['grown']['assetList']=modifiedEntry['assetList'];
     let cashChangesModification=modifiedEntry['summary']['totCashChange'];     // changes due to  sales &  purchases of a modification

     let pvaluesAfterMod= portfolioCalcValue(assetListAfterMod,modDate,pname,1,' for motlist ') ;   //  the portofolio values AFTER modfiication

     allStuff['assetList']=assetListAfterMod;

     allStuff['cash']=allStuff['grown']['cash']+ cashChangesModification ;
     allStuff['cashAsset']=allStuff['cash'];

     allStuff['cashChangeMod']=cashChangesModification;
     allStuff['totals']=pvaluesAfterMod['totals'];
     allStuff['summaryChanges']=modifiedEntry['summary'];
     allStuff['summaryChanges']['cashChangeMod']=cashChangesModification;

     allStuff['totalsNet']= calc_netValues(pvaluesAfterMod ,allStuff['cash'],'after modification, with aggregation corrections')  ; // fix netValues ,etc. Note that portfolioCalcValueMenu was  told NOT to do this!


     allStuff['comment']=modComment ;

   }  else {              // else no mod..

     allStuff['assetList']=allStuff['grown']['assetList'] ;
     allStuff['cash']=allStuff['grown']['cash'] ;
     allStuff['cashAsset']=allStuff['grown']['cash'] ;
     allStuff['cashChangeMod']=0;
     allStuff['totals']=pvalueGrow['totals'];;
     allStuff['totalsNet']= calc_netValues(pvalueGrow, allStuff['cash'],'no modification, with aggregation corrections')  ; // fix netValues ,etc. Note that portfolioCalcValueMenu was  told NOT to do this!
     allStuff['summaryChanges']=false ;
     allStuff['comment']='no modification';
   }

   growPortfolioDo_save1(pname,modDate,allStuff,theModEntry,qInitEntry,0)  ;   // save selected variables for use by showAllPortfolioValues
   allStuff['interp']=false;  // not interploated

//if (pname=='p1')   showDebug(allStuff,'alllslsls',1);
   return allStuff ;      //   cSample

}     // end of growPortfolioDo    totOneOffReceipt_pending

//============================
// save selected variables to simInvDsets[showValues_summary1'] ...  for use by showAllPortfolioValues
// also save to modInit_values if init or mod entry
// note:  allStuff is output of growPortfolioDo()

function growPortfolioDo_save1(pname,theDate,allStuff,theModEntry,qInitEntry,isInterp)   {

   if (theModEntry!==false)  {             // a mod or init entry -- save to cache!
     if (theModEntry==0)   {  // init
         simInvDsets['modInit_values']['inits'][pname]=allStuff;
         simInvDsets['modInit_values']['stats']['initSave']++;
     } else {
         if (!simInvDsets['modInit_values']['mods'].hasOwnProperty(pname)) simInvDsets['modInit_values']['mods'][pname]={};
         simInvDsets['modInit_values']['mods'][pname][theDate]=allStuff;
         simInvDsets['modInit_values']['stats']['modSave']++;
     }
   }

    if (!simInvDsets['showValues_summary1'].hasOwnProperty(pname))  simInvDsets['showValues_summary1'][pname]={};

// basic vars
   let acpi=calcInflation(theDate,theDate,2);
   let acpiB=acpi.toFixed(2);
   let acpiSay=parseFloat(acpiB);
    let tsave={'theDate':theDate,'isInterp':isInterp,'cpi':acpiSay };

    tsave['theDateSay']=setEntryDate(theDate).sayDate;
    let vs1=['theModEntry','theBaseEntry','growDays','dateMatch','dateMatchSay','dateGrownFrom' ];
    for (let jj=0;jj<vs1.length;jj++) {
      let zaa=vs1[jj];
      tsave[zaa]=allStuff[zaa] ;
    }

    let S1=allStuff['grown']['totals']['totAssetSaleNetAT'];
    let S2=allStuff['cash'] ;
    tsave['totPortfolioValue']=S1 + S2 ;
    tsave['cashAsset']=S2;

    tsave['qInitEntry']= (tsave['theBaseEntry']===0 && tsave['theModEntry']===0 ) ;  // for quick refernce
    tsave['qModEntry']= (tsave['theModEntry']!==false && tsave['theModEntry']>0) ;

// totals
    for (let aa2 in allStuff['grown']['totals'])  {
      tsave[aa2]=allStuff['grown']['totals'][aa2];
    }
    tsave['nIncomeAnnuity']=tsave['nIncomeStream']+tsave['nAnnuity'];

// totPeriod
// totLoanOwed from this will overwrite totLoanOwed from 'totals'
    for (let aa2b in allStuff['grown']['totPeriod']) {
      tsave[aa2b]=allStuff['grown']['totPeriod'][aa2b];
    }

// sumByTypePeriod
    for (let aa3 in allStuff['grown']['sumByTypePeriod']) {
        let aa3u=aa3;
       tsave[aa3]=allStuff['grown']['sumByTypePeriod'][aa3];
       if (aa3=='totReceiptPeriod') tsave['totOneOffsReceived']= tsave[aa3];  // deal with what show_v3 expectgs

    }        // sumByTypePeriod

// cashChangeObj
   let cshVars={'rawAdd':0,'rawOneOff':0,'baseGrowthInfo':0,'earnAdd':0,'change':0,'endCash':tsave['cashAsset']};
   if (allStuff['grown'].hasOwnProperty('cashChangeObj')) {
     for (let acv in cshVars) {
        cshVars[acv]= allStuff['grown']['cashChangeObj'][acv];
     }
   }
   tsave['cashGrow']={};
   for (let acv in cshVars) {
      tsave['cashGrow'][acv]=cshVars[acv];
   }


// changes (0 or empty defaults if not a mod entry) .....

// 3 lists of variables names (each list is processed a bit diffeently)

   let cvars={'totSales':0,'totPurchases':0,'totTax':0,'totRefiExtra':0,'totTaxDeferredSale':0, 'totTaxDeferredPurchase':0,
              'taxDeferred_tax':0,'totCapGains':0,'capGains_tax':0,'totPropertySale':0,'totPropertySaleNet':0};
   let cvars2={'modCashChange':0, 'oneOffListPending':[],'totOneOffPending':0,'nOneOffPending':0};
   let cvars3={'newList':[],'removeList':[],'changeList':[],'retainList':[] } ;

   if (allStuff['summaryChanges']!==false) {      // ======== read "change" variables (due to a modification AFTER growth)
     for (let aac in cvars) {
         cvars[aac]=allStuff['summaryChanges'][aac]
     }

     cvars2['modCashChange']=allStuff['summaryChanges']['cashChangeMod'] ;
     let tt1=[],tsum=0;
     for (let Z1 in  allStuff['summaryChanges']['oneOffListNew'])  {
        tt1.push(Z1);
        tsum+=allStuff['summaryChanges']['oneOffListNew'][Z1];
     }
     cvars2['oneOffListPending']=tt1;
     cvars2['totOneOffPending']=tsum;
     cvars2['nOneOffPending']=tt1.length;

     for (let gA in  allStuff['summaryChanges']['newList'] ) cvars3['newList'].push(gA);             // saved as obj
     for (let gA in  allStuff['summaryChanges']['removeList'] ) cvars3['removeList'].push(gA);
     cvars3['changeList']=JSON.parse(JSON.stringify(allStuff['summaryChanges']['changeList'] ));      //saved as array
     cvars3['retainList']=JSON.parse(JSON.stringify(allStuff['summaryChanges']['retainList'] ));

  }   // ....  there are changes

// save changes (typyically the 0 or [] defaults)
  tsave['changes']={};
  for (let aa in cvars)  {
     tsave['changes'][aa]=cvars[aa];
  }
  for (let aa in cvars2) {
     tsave['changes'][aa]=cvars2[aa];
  }
  for (let aa in cvars3) {
     tsave['changes'][aa]=cvars3[aa];
  }

// 9 march 2024 ... hacks to deal with oneOffs in an init entry
  if (qInitEntry)  {
    let foo1=JSON.parse(JSON.stringify( tsave['oneOffListUsed']));

    tsave['oneOffListUsed']=[] ;             // can not be "used" oneOffs on the init date (they are received the next day)
    tsave['oneOffListUsed_receiptPeriod']={};
    tsave['totOneOffsReceived']=0;
    tsave['totReceiptPeriod']=0;
    tsave['nOneOffsUsed']=0;

    tsave['changes']['oneOffListPending']=foo1 ;
    tsave['changes']['totOneOffPending']=tsave['totOneOffReceipt_pending'] ;
    tsave['changes']['nOneOffPending']=foo1.length;
  }


  simInvDsets['showValues_summary1'][pname][theDate]=tsave;   // save to cache

}       //  growPortfolioDo_save1   totReceiptPeriod  nOneOffsUsed

//===========       compute cash impacts of additions, etc in a period
// clist properties:
//   total: sum of raw additions (inluding oneoffs0
//  isConstant: true if all pieces have the same value AND cover the entire period
//  allNeg,allPos : 1 if all additions are negative (or positive), NOT considering oneoffs
//  info: array of the information on all pieces of all assets (each row is an object with dates and values)
//  oneOffs: array of oneOff info
// details: object with assetname as properties, #days of oneoffs as values
//
// returns:  properties: startCash days rawAdd rawOneOff baseGrowthInfo earnAdd earnAdd earnAddPlus  earnAddMinus  endCash change swDay  notDayByDay
//
// 13 march 2024: cash interest and penalty are asssumed to be tax free value (taxes are NOT calculated)

function portfolioAssetsGrow_cimpacts(clist,baseCash,pname,ndays,modDate,startDate,sampRate) {

  let res={'startCash':baseCash,  'days':ndays,
            'rawAdd':0,'rawOneOff':0,
            'baseGrowthInfo':0,
            'earnAdd':0,'earnAddPlus':0,'earnAddMinus':0,
            'endCash':baseCash,'change':0,'swDay':false,
            'notDayByDay':0} ;

  res['details']=clist['details'];      // for info purposes

// a degenerate case with ndays=0   should never happen ... but wth
  if (ndays===0) return res ;

// not a degenerate case
  let   cashInterest=1.0+ parseFloat(simInvParams['cashInterest'])  ;
    let cashInterestDay=Math.exp(Math.log(cashInterest)/365)   ;
    let cashInterestDay_m1=Math.max(0,cashInterestDay-1);        // make sure not less than 0
    let cashPenalty= 1.0+parseFloat(simInvParams['cashPenalty'])  ;
    let cashPenaltyDay=Math.exp(Math.log(cashPenalty)/365)   ;
    let cashPenaltyDay_m1=Math.max(0,cashPenaltyDay-1);        // make sure not less than 0

// find oneoffs
   startCash=baseCash ;
   let tsum=0;
   if (clist!==false) {         // startCash includes any oneOffs
     if (clist['oneOffs'].length>0) {
         for (let jj=0;jj<clist['oneOffs'].length;jj++)  tsum+=parseFloat(clist['oneOffs'][jj]);
         res['rawOneOff']=tsum ;
         startCash+=tsum;
     }
   }

// compute growth of "base" + "oneOffs"    -- same values regardless of the prescence of dayByDay additions

// rt1 properties: earnAdd, baseGrowthInfo,earnAddPlus,earnAddMinus,endCash,change
   let rt1=portfolioAssetsGrow_cimpacts_grow_base(baseCash,startCash,ndays,cashInterestDay,cashPenaltyDay) ;

   res['baseGrowthInfo']=rt1['baseGrowthInfo'];       // for info purposes

   let periodList= clist['info'] ;

// simple case:   oneOffs, but no other cash additions -- so use results from rt1
   if (clist===false ||  periodList.length==0  )  {    //   no additions (perhaps just oneOffs)
      for (let aa in rt1) res[aa]=rt1[aa] ;
      res['change']=res['endCash']- baseCash ;
      return res ;
   }

// if here got some period specs

// simple case: one day of growth
   if (ndays==1) {
     let v1=0;
     for (let mm=0;mm<periodList.length;mm++) v1+=periodList[mm]['add1'];    // sum up all the day 1 additions
     res['rawAdd']=v1 ;
     let s2=startCash+v1 ;       //  for just one day, v1 can be treated as a oneoff


     let rt1a=portfolioAssetsGrow_cimpacts_grow_base(baseCash,s2,ndays,cashInterestDay,cashPenaltyDay) ;  // do NOT use  rt1 calculated above
     if ( (rt1a['endCash']*baseCash)<0) res['swDay']=startDate+1;
     for (let aa in rt1a) res[aa]=rt1a[aa] ;   // earnAdd, baseGrowthInfo,earnAddPlus,earnAddMinus,endCash,change  (hence overwrites baseGrowthInfo, but so what)
     res['change']=res['endCash']- baseCash;

     return res ;
   }   // 1 day

// simple case: 2  days.
   if (ndays==2)  {
     let v1=0,v2=0,swDay=false;
     for (let mm=0;mm<periodList.length;mm++) v1+=periodList[mm]['add1'];    // sum up all the day 1 additions
     for (let mm=0;mm<periodList.length;mm++) v2+=periodList[mm]['add2'];    // sum up all the day 2 additions
     res['rawAdd']=v1+v2  ;

     let r2=portfolioAssetsGrow_cimpacts_grow2Days(startCash,v1,v2,cashInterestDay,cashPenaltyDay,startDate) ;

     for (let aa in r2) res[aa]=r2[aa]; // earnAdd, earnAddPlus,earnAddMinus,endCash,change,swDay
     res['change']=res['endCash']- baseCash;

     return res;
   }

// more than 2 days. ..........
// Create an aggregated "piecewise" list
// First: find all dates
   let aPieces=[];
   let tp=[] ;
   for (let ip=0;ip<periodList.length;ip++) {
       let ap1=periodList[ip];
       let date1=ap1['date1'],date2=ap1['date2'] ;
       tp.push(date1);
       tp.push(date2);
   }
   tp=sortNoDuplicates(tp);

   let tp1={};
   for (let itt=0;itt<tp.length;itt++) {
      let tdate=tp[itt];
      tp1[tdate]={'ith':itt,'sumA':0,'sumDiff':0,'details':[]};
   }

// now  for each tdate the values of each piece (aggregated over all peices

   for (let ip=0;ip<periodList.length;ip++) {
       let ap1=periodList[ip];
       let date1= parseInt(ap1['date1']),date2=parseInt(ap1['date2']),
                v1=parseFloat(ap1['add1']),vdiffDay=parseFloat(ap1['vdiffDay']),atype=ap1['type'];

       for (let itt=0;itt<tp.length;itt++) {
           checkDate=parseInt(tp[itt]);
           if (checkDate>=date2) continue ;     // piece is over
           if (checkDate<date1) continue;      // piece has not started

           tp1[checkDate]['sumDiff']+=vdiffDay;
           let ss=(checkDate-date1)*vdiffDay ;   // could checkdate=date1 for 0, but wth
           let v1B=ss+v1 ;
           tp1[checkDate]['sumA']+=v1B ;
           tp1[checkDate]['details'].push( atype+' '+v1B+ ' '+vdiffDay );
       }
   }

// can we do some shortcuts (rather than doing daybyDay )

     if (ndays>10 && simInvGlobals['cacheStuff']['suppressCache']===false )  {        // if less than 10, simpler just to do dayByDay

         if (tp.length==2) {
             let dfoo=tp[0];
             let sumdif=tp1[dfoo]['sumDiff'] ;
             let suma=tp1[dfoo]['sumA'] ;
             let baseSign=Math.sign(startCash)
             let suma2=suma+(sumdif*ndays) ;

             let sumTot=assetGrowth_sum(ndays,suma,suma2 )  ;
             let sCashAdj=startCash+sumTot ;

             if (Math.sign(sCashAdj) ==  Math.sign(startCash)   ) {     // no chance of sign switch
                let ainterest=(baseSign>0) ?  parseFloat(simInvParams['cashInterest']) : parseFloat(simInvParams['cashPenalty']) ;
                zz=simInv_additions(startCash,suma,suma2,100*ainterest,100*ainterest,ndays,false,1 )  ;  // [rawAdd,intAdd,startGrowth,endvalue, samplePoints]
                  res['rawAdd']=zz[0]  ;
                  res['earnAdd']=(zz[1]-zz[0])+zz[2] ;
                  res['goo']=[startCash,suma,suma2,ainterest,ndays].join(' | ' )  ;
                  if (suma>0) res['earnAddPlus']=res['earnAdd'];
                  if (suma<0) res['earnAddMinus']=res['earnAdd'];
                  res['endCash']=zz[3]
                  res['change']=res['endCash'] - baseCash  ;
                  res['notDayByDay']=1;
                  return res ;
            }                // same sign
         }   // tp length=2
     }   // ndays > 10

//  dayByDay: DOn't try any optimiazation shortcuts

     let r2=portfolioAssetsGrow_cimpacts_grow_dayByDay(startCash,tp,tp1,cashInterestDay,cashPenaltyDay,startDate,modDate,pname) ;
     for (let aa in r2) res[aa]=r2[aa]; // rawAdd  earnAdd , earnAddPlus , earnAddMinus, endCash , change , swDay
     res['change']=res['endCash']- baseCash;
     return res;        // note that baseGrowth from rt1 is used


// ======  BEGIN INTERNAL FUNCTIONS ----------------------------

// internal function: grow a starting value for ndays, depending on sign of sCash
// returns properties: earnAdd, baseGrowthInfo,earnAddPlus,earnAddMinus,endCash
  function portfolioAssetsGrow_cimpacts_grow_base(baseC,sCash,ndays1,cashInterestD,cashPenaltyD) {
    let res0={} ;

    let tt0= (baseC>0) ? cashInterestD**ndays1 :  cashPenaltyD**ndays1 ;
    let tgrow=tt0-1.0;
    res0['baseGrowthInfo']=tgrow*baseC;       // growth of just base  -- pretending that NO additions occured -- used for info purposes

    if (sCash>=0) {                    // startCash = baseCash + oneOffs
     let tt1=cashInterestD**ndays1     ;  // depends on startCash, not baseCash
     let tgrow=tt1-1.0;
     res0['earnAdd']=tgrow*sCash;            // growth of BASE+oneOffs
     res0['earnAddPlus']=res0['earnAdd'] ;
     res0['endCash']=sCash+res0['earnAdd'] ;
    } else {
     let tt1=cashPenaltyD**ndays1;
     let tgrow=tt1-1.0;
     res0['earnAdd']=tgrow*sCash;
     res0['earnAddMinus']=res0['earnAdd'] ;
     res0['endCash']=sCash+res0['earnAdd'] ;

    }
    return res0 ;
  }  // ======  internal function portfolioAssetsGrow_cimpacts_grow_base

// internal function: 1 day of growth of vamt, depends on sign
// returns amount of growth
  function portfolioAssetsGrow_cimpacts_1grow(vamt,cashInterestD,cashPenaltyD) {
    if (vamt>0) {
      let tint=cashInterestD-1.0;
      let gamt=tint*vamt;            // pos growth of BASE+oneOffs
      return [gamt,1];
    } else {
      let tint=cashPenaltyD-1.0;
      let gamt=tint*vamt;            // neg growth of BASE+oneOffs
      return [gamt,-1];
    }
  }             // portfolioAssetsGrow_cimpacts_grow!

// =====
// internal function 2 days of grwoth
// return  properties: earnAdd, earnAddPlus,earnAddMinus,endCash, swDay

   function  portfolioAssetsGrow_cimpacts_grow2Days(sCashS,v1d,v2d,cashInterestD,cashPenaltyD,startD) {

     let bSign=Math.sign(sCashS);
     let swDay=false
     let res2={'earnAdd':0,'earnAddMinus':0,'earnAddPlus':0} ;

     let scash=sCashS+v1d;

     let v1gA=portfolioAssetsGrow_cimpacts_1grow(scash,cashInterestD,cashPenaltyD);
     let vadd1=v1gA[0],vpos=v1gA[1];
     res2['earnAdd']+=vadd1;
     if (vpos==1) {
         res2['earnAddPlus']+=vadd1;
     } else {
         res2['earnAddMinus']+=vadd1;
     }
     scash+=vadd1 ;
     if (Math.sign(scash)!=bSign && bSign!==0) swDay=startD+1;

// now day 2
     scash+=v2d ;
     let v1gB=portfolioAssetsGrow_cimpacts_1grow(scash,cashInterestD,cashPenaltyD) ;  // 2nd day of growth of v1
     let vadd2=v1gB[0],vpos2=v1gB[1];
     res2['earnAdd']+=vadd2;
     if (vpos2==1) {
         res2['earnAddPlus']+=vadd2
     } else {
         res2['earnAddMinus']+=vadd2;
     }
     scash=scash+vadd2;
     if (swDay===false && Math.sign(scash)!=bSign && bSign!==0) swDay=startD+2;

     res2['swDay']=swDay ;
     res2['endCash']=scash  ;

     return res2 ;
  }         // portfolioAssetsGrow_cimpacts_grow_grow2Days

// === internal function: day by day growth, no shortcuts (i.e.; 10 or fewer days
// returns properties:  rawAdd  earnAdd , earnAddPlus , earnAddMinus, endCash , swDay
// startCash includes any oneOffs

   function portfolioAssetsGrow_cimpacts_grow_dayByDay(startCsh,pList,pObj,cashInterestD,cashPenaltyD,startD,endD,pname)  {

// check cache

     if (simInvGlobals['cacheStuff']['suppressCache']===false)  {
       if (simInvDsets['additionsValues']['list'].hasOwnProperty(pname)) {
         if (simInvDsets['additionsValues']['list'][pname].hasOwnProperty(startD)) {
            if (simInvDsets['additionsValues']['list'][pname][startD].hasOwnProperty(endD)) {
               return simInvDsets['additionsValues']['list'][pname][startD][endD] ;
           }     // end
         }     //startd
       }  // pname
     }   // suppress cache

// not in cache

     let res={};
     let ndays=endD-startD;
     let signB=Math.sign(startCsh);

   if (simInvGlobals['cacheStuff']['suppressCache']===false)     simInvDsets['additionsValues']['list'][pname]={};

     let dayByDay=[] ;
     for (let jj=0;jj<ndays;jj++) dayByDay[jj]=0;   // initialize  (in case pList doesn't span the entire date range

// fill in dayByDay list
     for (let ip=0;ip<pList.length-1;ip++) {             // aggregate all additions (over all pieces).. to form  'dayByDay" additions array
           let dd1=pList[ip] ,dd2=pList[ip+1];
           if (dd1>=dd2) continue ;                          // should never happen
           let valA=pObj[dd1]['sumA'],valDiff=pObj[dd1]['sumDiff'];
           let dd1a=dd1-startD,dd2a=dd2-startD ;
           let vuse=valA;
           for (let idd=dd1a;idd<dd2a;idd++) {
             dayByDay[idd]=vuse;
             vuse+=valDiff;
           }
     }

     cashNow=startCsh ;
     let rawAdd=0,intAdd=0,intAddPlus=0,intAddMinus=0,swDay=false;


     for (let jd=0;jd<dayByDay.length;jd++)  {  // grow using dayByDay values

         valD=dayByDay[jd];
         rawAdd+=valD ;
         cashNow+=valD ;
         zz=portfolioAssetsGrow_cimpacts_1grow(cashNow,cashInterestD,cashPenaltyD)  ;

         intAdd+=zz[0];
         if (zz[1]==1) {
            intAddPlus +=zz[0];
         } else {
            intAddMinus +=zz[0];
         }
         cashNow+=zz[0];
         if (swDay===false && (Math.sign(cashNow)!==signB && signB!==0) ) swDay=startD+jd ;  // 25march 2024 fix (0 is not a sign switch

         let dd1a=jd +startD;

         if (pObj.hasOwnProperty(dd1a)) {
            let ith2=pObj[dd1a]['ith'];
            if (ith2>0) {                // skip if first in list
                resx1={'jday':jd,'rawAdd':rawAdd,'earnAdd':intAdd,'earnAddPlus':intAddPlus,'earnAddMinus':intAddMinus,'endCash':cashNow ,'swDay':swDay } ;
                let jd2=pList[ith2];
                if (simInvGlobals['cacheStuff']['suppressCache']===false) {
                   if (!simInvDsets['additionsValues']['list'][pname].hasOwnProperty(startD)) simInvDsets['additionsValues']['list'][pname][startD]={};
                   simInvDsets['additionsValues']['list'][pname][startD][jd2]=resx1 ;
                }
            }
         }

     }
     let resx2={'jday':dayByDay.length-1,'rawAdd':rawAdd,'earnAdd':intAdd,'earnAddPlus':intAddPlus,'earnAddMinus':intAddMinus,'endCash':cashNow ,'swDay':swDay};

     if (simInvGlobals['cacheStuff']['suppressCache']===false)  {
        if (!simInvDsets['additionsValues']['list'][pname].hasOwnProperty(startD)) simInvDsets['additionsValues']['list'][pname][startD]={};
         simInvDsets['additionsValues']['list'][pname][startD][endD]=resx2 ;
     }


     res={'rawAdd':rawAdd,'earnAdd':intAdd,'earnAddPlus':intAddPlus,'earnAddMinus':intAddMinus,'endCash':cashNow ,'swDay':swDay  };

     return res ;


   }       //portfolioAssetsGrow_cimpacts_grow_dayByDay

}         //  portfolioAssetsGrow_cimpacts      :::::::::::::::::::::

//===============================================  ================
// find rmd fracdtion (given age and self/beneficiary
function growPortfolio_rmdFrac(age,iwhich) {
    let ageuse=parseInt(age);

     if (iwhich==1) {               // self
         if (age<rmdSelfBounds[0]) return 0.0 ;        // before min age, so no rmd require
         if (age>rmdSelfBounds[1]) ageuse=parseInt(rmdSelfBounds[1]);
         let vv=parseFloat(rmdSelf[ageuse]);
         return parseFloat(1.0/vv);
     } else {                                 // beneficiary
         if (age<rmdBenefciaryBounds[0]) return 0.0 ;        // before min age, so no rmd require  (should never happen)
         if (age>rmdBenefciaryBounds[1]) ageuse=parseInt(rmdBenefciaryBounds[1]);
         let vv=parseFloat(rmdBeneficiary[ageuse]);
         return parseFloat(1.0/vv);
     }
}

//===================================
// some total growth summaries

function portfolioAssetsGrow_summary(growths,pname,startDate,modDate) {
 
   let totRevenuePeriod_AT=0, totTaxOnRevenuePeriod=0;
   let totLoanPayPeriod_AT=0, totLoanOwed=0, totLoanPayPeriod=0 ;
   let totExpensePeriod_AT=0,totTaxOnExpensePeriod=0;

   let totIncomeBothPeriod_AT=0,totIncomeBothPeriod_tax=0;         // 12 march 2024 added
   let totRentPosAT=0,totRentNegAT=0 ;
   let totDivIntPeriod_AT=0,totDivIntPeriod_tax=0,totTaxDefGrowth=0;
   let taxesPaidOn=[];

   let gdays=parseInt(modDate)-parseInt(startDate);
   let qNoGrow=false;
   if (gdays<=0) qNoGrow=true;

   for (let rasset in  growths) {;
      let agg=growths[rasset];
      let atype=agg['type'];


      if (atype==0) {
         if (qNoGrow===false) {
           let aearn=agg['earningsPeriodAT'] ;
           totDivIntPeriod_AT+=aearn;
           totTaxOnRevenuePeriod+=agg['earningsTaxPeriod'];
           totDivIntPeriod_tax+=agg['earningsTaxPeriod'];
           taxesPaidOn.push(rasset) ;
         }
      }
      if (atype==1) {
         if (qNoGrow===false) {
            let aearn=agg['startGrowthPeriodAT']+agg['additions_earningsPeriodAT'];
            totDivIntPeriod_AT+=aearn;
            totTaxOnRevenuePeriod+=agg['earningsTaxPeriod'];      // this includes taxes on startingValue growth and additionsGrowth
            totDivIntPeriod_tax+=agg['earningsTaxPeriod'];
            taxesPaidOn.push(rasset) ;
         }
      }
      if (atype==2) {
         if (qNoGrow===false) {
            let aearn=agg['startGrowthPeriodAT']+agg['additions_earningsPeriodAT'];
            totDivIntPeriod_AT+=aearn;       // no taxes paid YET
            totTaxDefGrowth+=aearn ;      //  pret tax
         }
      }
     if (atype==3) {
        if (qNoGrow===false) {

           if (agg['rentPeriodAT']>0) {
              totRentPosAT+=agg['rentPeriodAT'];
              totTaxOnRevenuePeriod+=(agg['rentPeriod']-agg['rentPeriodAT']);
              taxesPaidOn.push(rasset+'_rent') ;
           } else if (agg['rentPeriodAT']<0) {      // no tax impacts of -rent
              totRentNegAT+=agg['rentPeriodAT'];  // agg['rentPeriodAT'] is same as agg['rentPeriod']  -- 15 march 2024, should clarify this?
           }

           totRevenuePeriod_AT+=agg['rentPeriodAT'];    // includes -rents
        }
        if (agg['gotLoan']==1) {

          if (qNoGrow===false) {
            totLoanPayPeriod_AT+=agg['loanPaidPeriodAT'];
            totLoanPayPeriod+=agg['loanPaidPeriod'];
          }
          totLoanOwed+=agg['loanOwed'];
        }   // gotloan
      }         // type= 3

      if (atype==4 || atype==5) {
        if (qNoGrow===false) {
           totIncomeBothPeriod_AT+=agg['incomePeriodAT'];
           let atax=agg['incomePeriod']-agg['incomePeriodAT']
           totIncomeBothPeriod_tax+=atax;
           totRevenuePeriod_AT+=agg['incomePeriodAT'];
           totTaxOnRevenuePeriod+=atax;
           taxesPaidOn.push(rasset) ;
        }
    }


      if (atype==7) {
        if (qNoGrow===false) {
           totExpensePeriod_AT+=agg['expensePeriodAT'];
           totTaxOnExpensePeriod+=(agg['expensePeriod']-agg['expensePeriodAT']);
        }
      }            // 6 (oneoffs) are not inclded in earning or payments


   }

   let tpaid= taxesPaidOn.join(' ') ;

  let ret0= {'totRevenuePeriod_AT':totRevenuePeriod_AT,'totTaxOnRevenuePeriod':totTaxOnRevenuePeriod,
            'totLoanPayPeriod_AT':totLoanPayPeriod_AT,'totLoanOwed':totLoanOwed,'totLoanPayPeriod':totLoanPayPeriod,
            'totExpensePeriod_AT':totExpensePeriod_AT,' totTaxOnExpensePeriod': totTaxOnExpensePeriod,
            'totDivIntPeriod_AT':totDivIntPeriod_AT,'totRentPosAT':totRentPosAT,'totRentNegAT':totRentNegAT,
            'totIncomeBothPeriod_AT':totIncomeBothPeriod_AT,'totIncomeBothPeriod_tax':totIncomeBothPeriod_tax,
            'totTaxDefGrowth':totTaxDefGrowth,
            'totDivIntPeriod_tax':totDivIntPeriod_tax,'taxesPaidOn':tpaid
            };

  return ret0 ;
}

//====================
// add "growths" to "list0 ... the base assetList" to create new (afterGrowth) assetlist
// note: changeCashOneOff are the "oneOffs"  specified in the 'priorEntry' -- that are recieved  the "day after" the prior entry's start date
//  changeCashAssetEnd is :
//      bond additions (if from cash) including RMDS, property rents - loan payments, expense stream  , incomeSreamm  , and annuities
//

function  portfolioAssetsGrow_apply(growths,list0,apname,modDate) {

 let changeCashOneOff=0;
 let changeCashAssetEnd=0;
 let changeCashAssetEnd_raw=0,changeCashAssetEnd_growth=0, changeCashAssetEnd_growthNew=0,changeCashAssetEnd_growthStart=0;;

 let  bondSum=0,rmdSum=0,propertySum=0,incomeSum=0,nOneOffsUsed=0,expenseSum=0,loanPaymentSum=0,stockSum=0;
 let oneOffsUsed={'list':{},'totals':{'totBaseReceipt':0,'totReceiptPeriod':0}} ;

 let growListUse=[],ij=-1;

// baseReceipt:   oneoffs specified in base entry, but NOT yet recieved
// receiptPeriod: oneoffs recieved within this period (i.e.; distributed on the day after baseDate)

  for (let ij0=0;ij0<list0.length;ij0++) {
           let abase=list0[ij0];
           let zasset=abase['name'];
           let aType=abase['assetType'];
           let nshares0=abase['nShares'];
           let  gstuff1=growths[zasset];

           if (aType==6) {         // oneOff affects cash  -- on the next day
               changeCashOneOff+=parseFloat(gstuff1['changeCashOneOff']) ;   // oneOff receipts collected on baseDate (beginning of period)
               oneOffsUsed['list'][zasset]={};
               oneOffsUsed['list'][zasset]['baseReceipt']=gstuff1['baseReceipt'];
               oneOffsUsed['list'][zasset]['receiptPeriod']=gstuff1['receiptPeriod'];
               oneOffsUsed['totals']['totBaseReceipt']+=gstuff1['baseReceipt'];
               oneOffsUsed['totals']['totReceiptPeriod']+=gstuff1['receiptPeriod'];
               nOneOffsUsed++ ;

               continue ;                 // // atype=6... drop (since oneOffs ONLY used on date of portfolio entry
           }
           ij++ ;
           let vv1=JSON.parse(JSON.stringify(abase));

           growListUse[ij]=vv1;       //initialize using pre-grwoth values

// asset changes (other than oneOff)  ...

           if (aType==0) {
              growListUse[ij]['nShares']=parseFloat(gstuff1['growthQ']);
              growListUse[ij]['basis']=parseFloat(growListUse[ij]['basis'])+parseFloat(gstuff1['basisChange']);   // 25 jan 2024 .... tweak this to deal with approximateion goofs
              stockSum+=gstuff1['earningsPeriod'];

           }  else  if ( aType==1 )  {
                growListUse[ij]['nShares']=parseFloat(gstuff1['growthQ']);
                if (gstuff1.hasOwnProperty('additionPeriodRaw') &&   gstuff1['additionPeriodRaw']!==false)  bondSum+= (-gstuff1['additionPeriodRaw']); // minus since -additions are transfers to cash


           }  else  if (  aType==2)  {

                growListUse[ij]['nShares']=parseFloat(gstuff1['growthQ']);


                if (gstuff1.hasOwnProperty('additionPeriodRaw') && gstuff1['additionPeriodRaw']!==false )  {                        // this should almost always be true
                      bondSum+= (-gstuff1['additionPeriodRaw']);          // minus since -additions are transfers to cash
                      if (gstuff1.hasOwnProperty('additionPeriodRmd_startAge'))  rmdSum+= (-gstuff1['additionPeriodRaw']);  // an rmd addition (from bond to cash)
                 }


           }  else  if ( aType==3)  {

               propertySum+= gstuff1['growthPrice'] ;
               if (gstuff1.hasOwnProperty('loanOwed') && jQuery.isNumeric(gstuff1['loanOwed'])) {
                   growListUse[ij]['loanOwed']= gstuff1['loanOwed'];   // remaining balance
                   loanPaymentSum+=gstuff1['loanPaidPeriod'];        // pre-tax
               }

           }  else  if ( aType==4 || aType==5)  {
                 incomeSum+=  parseFloat(gstuff1['incomePeriod']) ;  // pre-tax

           }  else  if ( aType==7 )  {
                  expenseSum+=  parseFloat(gstuff1['expensePeriod']) ;

           }

   }

   let ret0= {'grownList':growListUse,
             'propertyValueSum':propertySum,'loanPaymentSumPeriod':loanPaymentSum,
             'incomeBothSumPeriod':incomeSum,'expenseSumPeriod':Math.abs(expenseSum),
              'stockDivsSumPeriod':stockSum,'rmdAddSumPeriod':rmdSum,'bondAddSumPeriod':bondSum,        // bondsum could + or -
             'oneOffsUsed':oneOffsUsed,'nOneOffsUsed':nOneOffsUsed} ;



   return ret0 ;
}

//=======================    return
// called by growPortfolioB  and makeModPortfolio, and showAllPortfolioValues_makeEntry
// grow a portfolio, from its starting date to a future date.
// growth has properties that depend on assetType
//   assetLookup[assetName]['acqValues'] is list of dates for which a history entry exists for assetName
//  earliestEntryDate and  latestEntryDate are first and last in this list

function portfolioAssetsGrow(pname,assetsListBase,baseDateStamp,modStamp,growDays ) {

    let doCash_total=0,doCash_info=[],doCash_oneOffs=[],doCash_details={} ;
    let cgrowths={};

    for (let ith=0;ith<assetsListBase.length;ith++)  {

        let valueList=[] ;
        let aentry=assetsListBase[ith];
        let aname=aentry['name'];
        let atype=aentry['assetType'];

        let values0A=getAssetValue(baseDateStamp,aname,'*',1);      // all attributes, compresed format

        if (values0A===false ) {
           alert(pname+' values0a error '+baseDateStamp+', '+aname);
            return false;   // before first asset history entry (for this asset)
        }
        let vx={'date':baseDateStamp,'list':values0A,'inside':0};
        valueList.push(vx);

// get values for all dates with esxplcit asset history entries ge baseDateStamp and before  modDateStamp
        let acqv=assetLookup[aname]['acqValues'];       // the dates an entry were added to this assets history
        for (let kdate in acqv) {
           if (kdate<=baseDateStamp || kdate>=modStamp ) continue ;
           let values0x=getAssetValue(kdate,aname,'*',1);
           let vx={'date':kdate,'list':values0x,'inside':1};
           valueList.push(vx);
        }                // valueList build

        let values1A=getAssetValue(modStamp,aname,'*',1);
        if (values1A===false ) {
           alert(pname+' values1a error '+modStamp+', '+aname);
           return false;   // before first asset history entry (for this asset)
        }
        let vx2={'date':modStamp,'list':values1A,'inside':2};
        valueList.push(vx2);       // one row for each entry in the asset history


// growth in the asset ... different assets have different attributes that can grow (see list above).
        let agrowth=false ;

// "growth" depends on asset type ...
        if (atype==0) {
            agrowth=portfolioAssetsGrow_0(pname,aname,aentry,valueList,growDays,atype,baseDateStamp,modStamp,false)   ;

        } else  if (atype==1  ) {
            agrowth=portfolioAssetsGrow_1(pname,aname,aentry,valueList,growDays,atype,baseDateStamp,modStamp,false)    ;

        } else  if  (atype==2 ) {
            agrowth=portfolioAssetsGrow_2(pname,aname,aentry,valueList,growDays,atype,baseDateStamp,modStamp,false)    ;

        } else if (atype==3) {
            agrowth=portfolioAssetsGrow_3(pname,aname,aentry,valueList,growDays,atype,baseDateStamp,modStamp,false)    ;

        } else if (atype==4) {
            agrowth=portfolioAssetsGrow_4(pname,aname,aentry,valueList,growDays,atype,baseDateStamp,modStamp,false)    ;

        } else if (atype==5) {
            agrowth=portfolioAssetsGrow_5(pname,aname,aentry,valueList,growDays,atype,baseDateStamp,modStamp,false)    ;

        } else if (atype==6) {
            let values0=getAssetValue(baseDateStamp,aname,false,1);   // oneOffs ONLY depend on the entry at baseDateStamp
            agrowth=portfolioAssetsGrow_6(pname,aname,aentry,values0,growDays,atype,baseDateStamp,modStamp,false)    ;

        } else if (atype==7) {
            agrowth=portfolioAssetsGrow_7(pname,aname,aentry,valueList,growDays,atype,baseDateStamp,modStamp,false)    ;

        }
        if (agrowth===false)    return false ;      // an error  -- shouldn't happen

        if (agrowth['doCashAdd']!==false) {          // false means "no Cash impacts from this asset " (no loan payments, rents, bond additions, income, etc...)
           let gadds= agrowth['doCashAdd'] ;

           if (typeof(gadds)=='undefined') {
             showDebug(agrowth, ['problem ',pname,aname,baseDateStamp,modStamp].join(' '),1);
             continue;
           }
           doCash_total+=gadds['totalAddAll'] ;
           for (let ic=0;ic<gadds['info'].length;ic++) doCash_info.push(gadds['info'][ic]);
           for (let ic=0;ic<gadds['oneOffs'].length;ic++) doCash_oneOffs.push(gadds['oneOffs'][ic]);
           for (let aoof in gadds['details']) doCash_details[aoof]=gadds['details'][aoof] ;

        }      // doCashAdd

        cgrowths[aname]=agrowth  ;

    }  // assetsListBase.length

// agglomeration of cashAdd results from all assets  in this portfolio (in this period)
// doCash_stuff  properties:
//  total:  total additions (can be negative0
//  info: array, each row specifies a "piece".
//         each row has propertei: date1,add1,date2,add2,totalAdd, and type (type is an identifer), and vdiffday (add2-add1)/(date2-date1)
//  oneOffs:  array listing offoff values recieved in this peiece
//  details:details: object. Each property identifies where an addition came from, and # of day (in the period) it was ccorruing

   let doCash_stuff={'total':doCash_total,
            'info':doCash_info,'oneOffs':doCash_oneOffs,'details':doCash_details } ;

   return {'growths':cgrowths,'doCash':doCash_stuff,'dayGap':growDays,'baseDateStamp':baseDateStamp,'modDateStamp':modStamp }   ;

}

//====================        return
// insert rows into valueList if large gap between entries, or if large interest rate change between entries
function valueList_fill(valueList,maxGap,maxIntDiff) {
   maxGap=Math.max(2,maxGap);
   maxIntDiff=Math.max(0.000001,maxIntDiff);
   let vnew=[];
   vnew[0]=valueList[0] ;                            // always starts the same

   let adate1=parseInt(vnew[0]['date']);
   let vint1=parseFloat(vnew[0]['list']['interest']);
   for (let jj=1;jj<valueList.length;jj++) {
       let vtry=valueList[jj];
       let adate2=parseInt(vtry['date']);
       let vint2=parseFloat(vtry['list']['interest']);

       let ddate=adate2-adate1 ;
       let dint=vint2-vint1;

       if (ddate<=maxGap && dint<=maxIntDiff)   {         // this pair is okay as is
           vnew.push(vtry);
           adate1=adate2;
           vint1=vint2;
           continue;
     }              // else, probably add one or more entries

     let add_d=ddate/maxGap;      // which of these is larger (requires more added entries
     let add_i=dint/maxIntDiff ;
     let add_use=Math.max(add_d,add_i);
     if (add_use<1.05) {                 // if just 5%, don't bother
           vnew.push(vtry);
           adate1=adate2;
           vint1=vint2;
           continue;
     }              // else, add one or more entries

     let nsplit=parseInt(add_use+0.99) ;  // round up
     let dayChunk=parseInt(ddate/nsplit);         // add entries seperated by this many days
     let dintChunk=(dint/ddate)*dayChunk ;          // change in interest per dayChunk

     let intUse=vint1;
     let dateUse=adate1;
     let dateFills=[];
     for (let jsplit=1;jsplit<nsplit;jsplit++)   {    // if split in 2, add one entry; 3 add 2,...
              intUse+=dintChunk;
              dateUse+=dayChunk;
            let vtry2=JSON.parse(JSON.stringify(vtry));
            vtry2['date']=dateUse;
            vtry2['stuff']=dayChunk+' '+dintChunk+' '+adate1 ;
            vtry2['list']['interest']=intUse;
            vtry2['inside']=11;
            vnew.push(vtry2);
       }

       vnew.push(vtry)   ;            // and add original
       adate1=adate2;
       vint1=vint2;                  // get next in valueList
   }         // valuelise

   return vnew;
}

// ==================================================
// compute earnings and growth changes
// stock version

function portfolioAssetsGrow_0(pname,aname,aentry,valueList,growDays,atype,baseDateStamp,modStamp,doCashSample)   {

   let stuff={'type':0,'baseQ':false,'growthQ':false,
        'earningsPeriod':0,'earningsPeriodAT':0,'earningsTaxPeriod':0,
        'growthPeriodRate':1,'growthPeriodRateAT':1,
         'daysGap':false,'additionPeriod':false,
         'nCacheUse':0,'nCacheNotUse':0,'doCashAdd':false,
        'earningsTaxRate':false,'basisChange':0,'earningsKeepRate':false,
        'steps':0,'noPriceChange':0,'nCacheUse':0,'nCacheNotUse':0,'priceSay':false,'divSay':false }

   let nsharesOrig=parseFloat(aentry['nShares']);

    if (growDays==0) {
      stuff['baseQ']=nsharesOrig;
      stuff['growthQ']=nsharesOrig;
      stuff['daysGap']=0;
      return stuff ;
    }

   let nsharesPT =nsharesOrig;
   let nsharesAT =nsharesOrig;
    let periodEndPrice;

   let earningsTaxRate =calcAsset_taxRate(aname,0);  // asset specific (but not date dependent)
   let taxf=1- earningsTaxRate ;

   let  newSharesATfinal,newSharesfinal,P_1,P_2,D_1,D_2;
   let priceSays=[],divSays=[];

    for (let ii=0;ii<valueList.length-1;ii++) {
        let vv1=valueList[ii];
        let adate1=vv1['date'];               // could use D_2 and P_2 from prior step
          D_1=parseFloat(vv1['list']['dividend']) ;
          P_1=parseFloat(vv1['list']['price']) ;

        if (ii==0) {
          priceSays.push(P_1);
          divSays.push(D_1);
        }

        let vv2=valueList[ii+1];
        let adate2=vv2['date'];
          D_2=parseFloat(vv2['list']['dividend']) ;
          P_2=parseFloat(vv2['list']['price']) ;
          priceSays.push(P_2);
          divSays.push(D_2);
          periodEndPrice=P_2;
        let daysGap1=adate2-adate1;

// .list.date1.date2= {vals}

        let ts=assetsCacheCum_read(aname+'@'+pname,adate1,adate2);             // grow_0
        let t1,t2;

        if (ts!==false) {     // read from cache
             t1=ts['t1'];
             t2=ts['t2'] ;
             stuff['nCacheUse']++ ;

        } else {         // create, and then save to cache
            t1=assetGrowth_stock(nsharesPT,D_1,D_2,P_1,P_2,daysGap1) ;   // nshares,totDividends
            let D_1b=D_1*taxf ;
            let D_2b=D_2*taxf ;
            t2=assetGrowth_stock(nsharesAT,D_1b,D_2b,P_1,P_2,daysGap1) ;   // nshares,totDividends

            let ts={'t1':t1,'t2':t2};
            assetsCacheCum_write(aname+'@'+pname,adate1,adate2,ts);
             stuff['nCacheNotUse']++ ;

        }
        let newSharesPT=t1[0];
        let divEarnPT=t1[1] ;

        let newSharesAT=t2[0];
        let divEarnAT=t2[1] ;

        stuff['earningsPeriod']+= divEarnPT;
        stuff['earningsPeriodAT'] +=divEarnAT  ;

        let basisChange ;
        if (P_1 === P_2) {      // no change in capital gains (value of new purchases = change in basis
           basisChange=(newSharesAT-nsharesAT)*P_1 ;   // changes in shares * price
           stuff['noPriceChange']++ ;
       } else {
           basisChange=divEarnAT ;  // all AT earnings are used to buy new stock
       }
       if (Math.abs(basisChange)<0.01) basisChange=0;
       stuff['basisChange']+=basisChange ;

       nsharesAT =newSharesAT ;              // used in next step
       nsharesPT=newSharesPT ;              // used in next step

       stuff['steps']++ ;
       newSharesATfinal=newSharesAT;   // used if final step
       newSharesfinal=newSharesPT;   // used if final step
    }

// stuff[ 'growthPeriodRate',  'growthPeriodRateAT' 'earningsPeriod',  'earningsPeriodAT',   'earningsTaxPeriod' , 'basisChange'] set above

    stuff['baseQ']=nsharesOrig;
    stuff['growthQ']=newSharesATfinal;
    stuff['growthValue']=newSharesATfinal*periodEndPrice ;
    stuff['changeQ']=newSharesATfinal-nsharesOrig;

   stuff['growthPeriodRate']=newSharesfinal/nsharesOrig;
   stuff['growthPeriodRateAT']=newSharesATfinal/nsharesOrig;
   stuff['earningsTaxPeriod']= stuff['earningsPeriod']-stuff['earningsPeriodAT']   ;

    stuff['daysGap']=growDays;
    stuff['earningsTaxRate']=earningsTaxRate;  // asset specific (but not date dependent)

    stuff['priceSay']=priceSays.join(' ');
    stuff['divSay']=divSays.join(' ');

     return stuff;

}                // portfolioAssetsGrow_0. stocks  Not: stocks do NOT impact Cash unless sold ... so no need to do any additions stuff


//============
// growth of a bond
// period: the timespan between the first and last entry in valueList  -- covering a timespan between portfolio entries
//  (an entry is either the initialization entry, or a modification entry)
// piece: a portion of a period. Within a period asset attributes are fixed (often with a start of piece and end of piece values
//        pieces are often due to an assing having an history entry; but could be "inserted" (say, due to a multi year gap between history etries)
//        The "valueList" contains points that define each piece  (1 to 2, 2 to 3,..)
//
// Note addValue does NOT change within a period  -- EXCEPT for RMDS (which are a function of age and balance at start of a piece)
//  earningsTaxRate > 0 for bones, 0 for tax deferred bonds -- it is used to calculate growth of an asset (due to interest earnings) fsover the period
// taxDeferredRate =0 for bonds, >0 for tax-deferred bonds -- it is used in Cash_addition calculations

// 31 jan 2024 : for now, cash changes assume cashInterest (i.e.; assume cash>0). This could be a problem if cash<0!
// 31 jan 2024 -- interest MUST be non-negative

function portfolioAssetsGrow_bond_grow(aentry,valueList,earningsTaxRate0,daysGap,taxDeferredRate0,aname,pname,atype,baseDateStamp,modStamp){

   let stuff={};

   let nsharesStart=parseFloat(aentry['nShares']);        // starting value of bond

//  -- no days  -- echo back current values
   if (daysGap==0) {
     portfolioAssetsGrow_bond_grow_set0(nsharesStart,earningsTaxRate0);  // creates a 'no changes' version of 'stuff'
     return stuff;
   }

// days of growth >0

   let nSharesStartPiece=parseFloat(nsharesStart) ;
   let nSharesStartPieceAT=nsharesStart ;
   let rawAdd=0,startGrowth=0,startGrowthAT=0;

   let keepRate=1.0,taxDeferredRate=taxDeferredRate0,say1='taxDeferredBond';
   if (atype=='_1') {
       keepRate= 1- earningsTaxRate0 ;           // earningsTaxRate already incorpotates global tax rate and asset specific taxFree attribute
       taxDeferredRate=0;
       say1='bond';
   }

   let grate=1.0,grateAT=1.0,earnPeriod=0,earnPeriodAT=0,nsteps=0;
   let additionsList=[];
   let intSays=[],addSays=[];;
   let adate11,adate22,date2_use ;

   for (let ii=0;ii<valueList.length-1;ii++) {        // ........... start valuelist loop

      let vv1=valueList[ii];
      let adate1=parseInt(vv1['date']);               // could use D_2 and P_2 from prior step

      let I_1=parseFloat(vv1['list']['interest']) ;

      if (ii==0) {
         stuff['taxFreeFrac']=parseFloat(vv1['list']['taxFreeFrac']) ;    // for info purposes
         intSays.push(I_1);
         adate11=adate1;
      }

// addVal (yearly additions) is same from start to end of period (no interpolation)-- using value at start of period
      let addVal ;                        // an absolute value ... or if rmd a fraction of balance  (nSharesStartPiece) at start of this peice
      let addVal0=vv1['list']['addVal'] ;   //  addvals are constant within a piece  (if not -rmd, constant within a period)
      let isRmd= (vv1['list'].hasOwnProperty('addValRmd')) ? vv1['list']['addValRmd'] : false ;  // if not false , addVal (yearly) is a fraction of asset value at start of a period
      if (isRmd!==false) {             // an rmd -- addVal0 is a fraction (not an absolute value)
         addVal= -parseFloat(addVal0)*nSharesStartPiece ;     // - means "withdraw from asset and deposit in Cash"
      }   else {
         addVal=addVal0;
      }

      let vv2=valueList[ii+1];
      let adate2=parseInt(vv2['date']);
      adate22=adate2 ;

      I_2=parseFloat(vv2['list']['interest']) ;
      intSays.push(I_2);

      let daysGap1=adate2-adate1;       // length of this piece of this period

      let resAT=portfolioAssetsGrow_bond_grow_1(nSharesStartPieceAT,I_1,I_2,addVal,adate1,adate2,keepRate,1,aname)    ;
       // [earnH,endVal,grate,rawA,bdate2,startGrowth];
       // earnH + startGrowth are total interest earnigns


      nSharesStartPieceAT=resAT[1];
      earnPeriodAT+=resAT[0];             // AT interest earnings on additions
      grateAT=grateAT*(1+resAT[2]);
      let rawAddPiece =resAT[3];
      startGrowthAT+=resAT[5];
      rawAdd+= rawAddPiece ;
      date2_use=resAT[4];
      resPT=resAT;

      if (keepRate!=1.0) {                  // note use of date2_use (before adate2 if depletion occured)
          resPT=portfolioAssetsGrow_bond_grow_1(nSharesStartPiece,I_1,I_2,addVal,adate1,date2_use,1.0,0,aname)    ;  // [earnH,endVal,grate,rawAdd,date2Use,startGrowth];
      }
      nSharesStartPiece=resPT[1];
      earnPeriod+=resPT[0];         // interest earnings on additions
      grate=grate*(1+resPT[2]);
      startGrowth+=resPT[5];

      nsteps++ ;


   }      //   .........    end valueList loop

// save info used to compute changes to Cash
       if (rawAdd==0) {              // no addvalues -- so go to next "piece" (in valueList)
           addSays.push(0);              // basic stuff to this info field
      } else {

// if here, additions are desired....
         let addValC=-rawAdd ;
         if (atype=='_2') addValC=addValC*(1-taxDeferredRate);  // tax deerred asset? Then account for taxes on wd, or additions, to Cash
         let dlen=date2_use-adate11;
         let tt={'date1':adate11,'add1':(addValC/dlen),'date2':date2_use,'add2':(addValC/dlen),'taxRate':taxDeferredRate,'type':say1} ;
         additionsList.push(tt);
         if (date2_use<adate22) {  // 0 additions at end of period (after depltion date)
             let tt2={'date1':date2_use,'add1':0,'date2':adate22,'add2':0,'taxRate':taxDeferredRate,'type':say1} ;
             additionsList.push(tt2);
         }
    }

    let newshares=nSharesStartPieceAT ;      // nSharesStartPieceAT is end value if last piece of valuesList .. of if asset depelted

    stuff['baseQ']=nsharesStart;
    stuff['growthQ']=nSharesStartPieceAT;    //  since loop exits with this as "the asset value" at end of last peice (hence end of period)!

    stuff['additions_earningsPeriod']=earnPeriod ;
    stuff['additions_earningsPeriodAT']=earnPeriodAT*(1-taxDeferredRate);

// earningsTaxPeriod includes tax on "starting value growth" and on 'growth of additions'
    stuff['earningsTaxPeriod']=nSharesStartPiece-nSharesStartPieceAT;    // sharesStart are set at end of each iteration, hence are tfinal if no more iters

    stuff['growthPeriodRate']=grate;
    stuff['growthPeriodRateAT']=grateAT ;
    stuff['startGrowthPeriod']=startGrowth;
    stuff['startGrowthPeriodAT']=startGrowthAT;

    stuff['additionPeriodRaw']=rawAdd ;

    stuff['daysGap']=daysGap;
    stuff['earningsTaxRate']=earningsTaxRate0;  // asset specific (but not date dependent)
    stuff['steps']=nsteps;
    stuff['intSay']=intSays.join(' ');
    stuff['additionSay']=addSays.join(' , ');

    stuff['doCashAdd']= portfolio_doCashAdds(additionsList,pname,aname,atype,baseDateStamp,modStamp)  ;   // _1 and _2

    return stuff;

// ......... Internal functions, using variables local to parent function ...............

// ------------
// set stuff to default (no growth) values
  function  portfolioAssetsGrow_bond_grow_set0(nsharesStart,earningsTaxRate) {
     stuff['baseQ']=nsharesStart;
     stuff['growthQ']=nsharesStart;    //  since loop exits with this as "the asset value" at end of last peice (hence end of period)!
     stuff['additions_earningsPeriod']=0 ;
     stuff['additions_earningsPeriodAT']=0;  // value of earnings if the asset liquified (and all tax deferred taxes are paid)
     stuff['earningsTaxPeriod']=0;
     stuff['growthPeriodRate']=1.0;
     stuff['growthPeriodRateAT']=1.0 ;
     stuff['daysGap']=0;
     stuff['additionPeriodRaw']=0 ;
     stuff['earningsTaxRate']=earningsTaxRate;  // asset specific (but not date dependent)
     stuff['steps']=0;
     stuff['intSay']='';
     stuff['additionSay']='';
//     stuff['nCacheUse']=0;
//     stuff['nCacheNotUse']=0;
     stuff['doCashAdd']=false;

   }     // portfolioAssetsGrow_bond_grow_set0


}                    // portfolioAssetsGrow_bond_grow

// ============================
// grow period values using growth within this piece.
// start and I_ values should all be AT, or all be PT
// addVal is PT
// kprate is after Tax retentio nrate (1-taxRate). For tax deferred, will be 1.0
// return [earnH,endVal,grate,rawA,bdate2,startGrowth];
//  earnH : interest earned on additions 
//  endVal : final value: additions + earnings  on additiosn + startvalue + earningsOnStartValue 
//  grate: growth rate =     startGrowth/ startValue
//  rawA :  raw additions
//  bdate2 : final date
//  startGrowth : growth of the starting value
// earnH + startGrowth are total interest earnigns

function  portfolioAssetsGrow_bond_grow_1(startV,I_1,I_2,addVal,bdate1,bdate2,kprate,checkSW,aname) {
  let   earnH=0,endVal=startV,grate=1.0,rawA=0,startGrowth=0 ;

  daysGap1a=bdate2-bdate1 ;
  if (startV<=0 || daysGap1a<=0)   return [earnH,endVal,grate,rawA,bdate2,startGrowth];       // depleted asset, or wierd case of same day ... so no growth possible  -- so variables don't change

  if (daysGap1a==1)  {          // avoid some problems by treating this as a special case
      rawA=addVal/365;
      if (I_1==0 && I_2==0)  {  // special case: no growth
          earnH=0;
          endVal=startV;
          grate=1.0;
     } else {
         let I1_day=Math.exp(Math.log(I_1)/365)  ;
         earnH=(I1_day-1)*startV;
         grate=I1_day;
         endVal=startV+earnH+rawA ;
         if (endVal<0) {
             endVal=0;
             rawA=startV+earnH;    // can not withdraw more than start + one day of interest earnings of start
         }
       }
       return [earnH,endVal,grate,rawA,bdate2,earnH];
  }

// more than one day
  let i1Use=I_1*kprate,i2Use=I_2*kprate ;

  let rr=simInv_additions(startV,addVal,addVal,i1Use,i2Use,daysGap1a) ;  // [rawAdd,intAdd,startGrowth,endvalue, samplePoints]

  earnH=rr[1]-rr[0];                  // interestIncludingAdditions - rawAdditions
  endVal=rr[3]                       ;   // startValue + additions + startGrowth + additionsGrowth
  if (I_1!==0 && I_2!==0)  grate=rr[2]/startV ;    // startGrowth/ startValue
  rawA=rr[0] ;
  startGrowth=rr[2];

// check for depletion. (don't bother if PT, since bdate2 was set by AT call)  -- and don't check if this is a "search around SWDAY" call!

  if (endVal>=0 || checkSW!==1)   return [earnH,endVal,grate,rawA,bdate2,startGrowth];    // could be a "in recursion" call

// depletion occured... find the date it occurred!
   let  wasPositive=false;
   let sw=startV/(startV+Math.abs(endVal)) ;
   let ddif=bdate2-bdate1;
   swDay=parseInt(bdate1+ (sw*ddif));        // guess as to when depeltion ccurred

// look on swDay, and on both sides, for value closest to 0
   for (let igoo=0;igoo<100000;igoo++) {      // leave via a brak
      let rr3=portfolioAssetsGrow_bond_grow_1(startV,I_1,I_2,addVal,bdate1,swDay,kprate,0,aname) ;  // [rawAdd,intAdd,startGrowth,endvalue, samplePoints]
      let edval=rr3[3];
      if (edval==0) return rr3  ;            // perfect match might happen. esp if swDay=bdate1+1       ;

      if (edval<0) {       // depleted... try earlier date
        if (wasPositive===false)   {   // keep going back
           swDay=swDay-1;
           continue ;         // try earlier date
        }           // else switch from + to net
        rr[1]=0;
        rr[3]+=edVal;       // remove the "negative balance" from rawAdd
        return rr;
     }

// edval > 0, try to get closer
     swDay=bdate2+1;
     if (swDay>bdate2) return rr3 ;          // should never happen
     wasPositive=true;        // signal to stop if negative endvale
     continue;
  }        // recursive style loop

}        //portfolioAssetsGrow_bond_grow_1


// ------------
// Do some processing of the "additionList" (alist))
//
// alist0 is array of objects, each object has properties:
//      {'date1':tdate1,'add1':addVal,

//       'date2':tdate2,'add2':addVal,
//       'taxRate':taxdRate,'type':'typeOfAddition'}
//   taxRate is NOT used -- it is what was used to calculate add1 and add2
//  awhat: '_type' ( i.e.; '_3' for properties, _1 for regular bonds)
//
// returns false if NO additions
// otherwise, object with properties:
//  info: alist0, with 'totalAdd' (total over all days of the piece, or the oneOff value), and vdiffDay, added to each row
//  totalAddAll: sum of all raw additions
//  oneOffs : array of "oneOffs" values
// details: object with asset name as properties, # day of additions as value. 0 value means "one off"


function  portfolio_doCashAdds(alist0,pname,aname,awhat,sDateB,sDateE ) {

  let daysGap=sDateB-sDateE ;
  if (daysGap==0) return false ;                       // should not happen...

 let oneOffs=[] ;
 let details={} ;

 if (awhat=='_6')  {                          // special case; oneoff -- (zero or one oneOffs per period -- so alist0 is NOT an array)
    oneOffs.push(alist0) ;                  // alist0 is a number (to be added to total additions in period)
    details[aname]=0;         // 0 signals "one off"
    let res1={'info':[],'totalAddAll':alist0,'oneOffs':oneOffs,'details':details } ;
    return res1;
}

// not a one off  -- alist0 will be an array (perhaps empty)

 if (alist0.length==0) return false ;                                     // nothing to check

// check if any of the values are nonzero.. and get date range stuff

  let qnone=true;

  for (let ij=0;ij<alist0.length;ij++) {
      let v1=alist0[ij]['add1'],v2=alist0[ij]['add2'];
      if (v1!=0 || v1!=0)  qnone=false;
  }
  if (qnone) return false ;                            // no non-zero addition

// got at least one non-zero addition (over 1 or more days)

  let alist=JSON.parse(JSON.stringify(alist0)) ;      // avoid js troubles
  let totalAddAll=0;
  let alistNew=[];

  for (let ij=0;ij<alist.length;ij++) {           // each entry in alist specs a differnt addition (either a date range, or a type (ie; rent or loan if awhat=_3)
       let L1=alist[ij];

       let v1=parseFloat(L1.add1),v2=parseFloat(L1.add2);
       if (v1==0 && v2==0) continue ;           // no additions, so skip

       let d1=parseInt(L1.date1),d2=parseInt(L1.date2);

       let aa=JSON.parse(JSON.stringify(alist0[ij])) ;

        let d1Use=d1-sDateB, d2Use=d2-sDateB ;             // normalize ...
        let drangePiece=d2-d1;         // date range of this "piece"
        let anameP=aname+'_'+L1['type'];

        if (!details.hasOwnProperty(anameP)) details[anameP]=0 ;
        details[anameP]+=drangePiece ;        // # days this asset has additions (in this period)

        let vrange=v2-v1;                   // value range of this piece (after tax)

        let vrangeDay =vrange/drangePiece ;         // change of "daily" values per day

// total additions (calculated using v1 v2 and drangePiece)
        let totAdd ;
        if (v1*v2>=0)  {   // both pos or net (or 0)
          let b1=v1*drangePiece ;
          let t1=(vrange/2)*drangePiece ;
          totAdd=b1+t1;
       } else {     // switches sign
          let ff=Math.abs(v1/vrange);
          let gd1=parseInt(ff*drangePiece) ;
          p1=gd1*v1/2 ;
          p2=(drangePiece-gd1)*v2/2 ;
          totAdd=p1+p2;
       }

       aa['totalAdd']=totAdd;
       totalAddAll+=totAdd;
       aa['vdiffDay']=vrangeDay ;

       alistNew.push(aa)
  }  // ij

   let res1={'info':alistNew,'totalAddAll':totalAddAll,'oneOffs':oneOffs,'details':details};

   return res1;

}

// ==================================================
// regular bond version
// valueList has interest (at a given date)
function  portfolioAssetsGrow_1(pname,aname,aentry,valueList,daysGap,atype,baseDateStamp,modStamp,doCashSample)  {

  let addVal=aentry['addVal'];                     // portfolio "period" specific value of addVal (does not change over pieces)
  for (let ij=0;ij<valueList.length;ij++) {
      valueList[ij]['list']['addVal']=addVal;
  }

   let maxGap=(addVal!=0) ? 365 : 1000  ;    // larger max gap if interest is constant
   valueList=valueList_fill(valueList,maxGap,0.1)  ;

  let stuff={'type':1,'baseQ':false,'growthQ':false,'additions_earningsPeriod':false,'additions_earningsPeriodAT':false,'earningsTaxPeriod':false,
        'growthPeriodRate':false,'growthPeriodRateAT':false,'daysGap':false,
          'nCacheUse':0,'nCacheNotUse':0,
        'additionPeriod':false,'additionPeriodRaw':false,
        'additionPeriodGrowth':false,
        'additionPeriodAT':false,'additionPeriodGrowthAT':false,
        'earningsTaxRate':false,'steps':0 ,'intSay':false}   ;   // partial list -- bond_grow adds a few

   let earningsTaxRate =calcAsset_taxRate(aname,0);  // asset specific (but not date dependent)

   let stuffx= portfolioAssetsGrow_bond_grow(aentry,valueList,earningsTaxRate,daysGap,0.0,aname,pname,'_1',baseDateStamp,modStamp)  ;

  let say1=setEntryDate(baseDateStamp).sayDate ;
  let say2=setEntryDate(modStamp).sayDate ;

   stuffx['sayDates']=say1+' to ' +say2 ;
   for (let avv in stuffx) stuff[avv] = JSON.parse(JSON.stringify(stuffx[avv]));

    return stuff;             // doCashAdd stuff done in    portfolioAssetsGrow_bond_grow


}

// ==================================================  newshares
// tax deferredbond version
// valueList has interest (at a given date)
function  portfolioAssetsGrow_2(pname,aname,aentry,valueList,daysGap,atype,baseDateStamp,modStamp,doCashSample)  {

   let addVal=aentry['addVal'];                     // portfolio "period" specific value of addVal
   let doRmd=aentry['doRMD'];
    if (doRmd==0) doRmd=false;

   let maxGap=(addVal!=0 || doRmd!==false) ? 260 : 1000  ;    // larger max gap if interest is contant

   valueList=valueList_fill(valueList,maxGap,0.1)  ;  // add entries if long gaps , or if large interest rate changes

   for (let ij=0;ij<valueList.length;ij++) {
        valueList[ij]['list']['taxFreeFrac']=1.0;         // no taxes on interest when they are earned (tasxes paid when taxdefered bond is sold)
        valueList[ij]['list']['addVal']=addVal;
        valueList[ij]['list']['addValRmd']=doRmd ;
   }


// add entries to valueList -- that contain "age specific" RMD withdrawal fractions  ?
   let startAgeRmd=false,endAgeRmd,endAgeFrac,startAgeFrac ;  // for info purposes
   if (doRmd!==false)   {  // rmd additions -- a fraction that depends on date (and age)
      let rmdStartAge=aentry['nowAge'];
      let rmdStartDate=(aentry.hasOwnProperty('rmdStart')) ? aentry['rmdStart'] : aentry['incomeStart'];;
      for (let ij=0;ij<valueList.length;ij++) {
          let dstamp=valueList[ij]['date'];
          let age2=rmdStartAge+((dstamp-rmdStartDate)/365);          // age at end of period (assume rmd distribiton occurs at end of "period"
          let aFactor=growPortfolio_rmdFrac(age2,doRmd);       // rmd fraction at end of chunk
          valueList[ij]['list']['addVal']=aFactor;
          valueList[ij]['list']['rmdAge']=age2;
          if (ij==0) {           // age and factor used : first piece in of period
              startAgeRmd=age2;
              startAgeFrac=aFactor;
          }
          if (ij==valueList.length-2)  {   // age and factor used : last piece in of period
              endAgeRmd=age2;
             endAgeFrac=aFactor;
      }
      }         // valuelist
   }     // doRmd


  let stuff={'type':2,'baseQ':false,'growthQ':false,'additions_earningsPeriod':false,'additions_earningsPeriodAT':false,'earningsTaxPeriod':false,
        'growthPeriodRate':false,'growthPeriodRateAT':false,'daysGap':false,'additionPeriod':false,'additionPeriodRaw':false,
          'nCacheUse':0,'nCacheNotUse':0,        
         'additionPeriodAT':false,
        'earningsTaxRate':false,'steps':0 ,'intSay':false}   ; // bond_grow will add a few properties

    let taxdefTaxRate =calcAsset_taxRate(aname,1);  // use ,1 for "tax on sale" (rather than tax on interewt earnings)

    let stuffx= portfolioAssetsGrow_bond_grow(aentry,valueList,0,daysGap,taxdefTaxRate,aname,pname,'_2',baseDateStamp,modStamp)  ;  //  stuffx contains many of the above

    for (let avv in stuffx) stuff[avv]=stuffx[avv];
    let say1=setEntryDate(baseDateStamp).sayDate ;
    let say2=setEntryDate(modStamp).sayDate ;
    stuff['sayDates']=say1+' to ' +say2 ;

    stuff['additionPeriodRmd_startAge']=startAgeRmd;
    stuff['additionPeriodRmd_startFrac']=startAgeFrac;
    stuff['additionPeriodRmd_endAge']=endAgeRmd;
    stuff['additionPeriodRmd_endFrac']=endAgeFrac;

    return stuff;                // doCashAdd stuff done in    portfolioAssetsGrow_bond_grow

}                   // tax deferred bonds


//=======
// growth in property value, rents (as income), and loan stuff
// this tracks rent earnings ... and loan payments
// No reinvestement!

function portfolioAssetsGrow_3(pname,aName,aentry,valueList,daysGap,atype,baseDateStamp,modStamp,doCashSample)    {

   let stuff={'type':3,'basePrice':false,'growthPrice':false,'daysGap':false,
         'additionPeriod':false,'additionPeriod':false,'acqCost':0,
         'earningsTaxRate':false,'nCacheUse':0,'nCacheNotUse':0,
         'gotLoan':false,'loanAmount':0,
            'loanOwed':false,'loanPaidPeriod':false,'loanPaidPeriodAT':false,'loanPrincipalPeriod':false,
            'loanInterestPeriod':false,'loanInterestPeriodAT':false,'loanPaidTotal':false,'loanPaidTotalAT':false,
            'loanTaxDeductValue':false
        }

   let adate00=false,adateEE=false;                      // _3
   let additionsList=[] ;

   let earningsTaxRate =calcAsset_taxRate(aName,0);  // asset specific (but not date dependent). Note taht calcAsset_taxRate gets taxFreeFrac with getAssetLookup()
   let taxFreeFrac=0;
   let keepRate=1- earningsTaxRate ;
   let rentsSay=[],datesSay=[];
   let cumRentRaw=0,cumRentRawAT=0;
   let acqCost=0;

   for (let iiJ=0;iiJ<valueList.length-1;iiJ++) {

        let vv1=valueList[iiJ];

        let adate1=vv1['date'];               // could use D_2 and P_2 from prior step
        if (adate00==false) adate00=adate1 ;  // first date in period

        let R_1=parseFloat(vv1['list']['rent']) ;

        if (iiJ==0) {
          rentsSay.push(R_1);
          datesSay.push(adate1);
          taxFreeFrac=vv1['list']['taxFreeFrac'] ;      // used for sales, NOT for rent
          stuff['keepRate']=keepRate;
          let tss=vv1['list']['saleCost'] ;
          if (!jQuery.isNumeric(tss)) tss=0;
          stuff['saleCost']=tss  ;
          stuff['basePrice']=vv1['list']['price'];
          if (vv1['list'].hasOwnProperty('acqCost')) {       // property added
              acqCost=vv1['list']['acqCost'];
              stuff['acqCost']= acqCost;
           }
        }

        let vv2=valueList[iiJ+1];
        let adate2=vv2['date'];
        if (iiJ==valueList.length-2)  adateEE=adate2 ;

        R_2=parseFloat(vv2['list']['rent']) ;
        rentsSay.push(R_2);
        datesSay.push(adate2);

        let R_1_AT= (R_1<0) ? R_1 : R_1*(1-earningsTaxRate);
        let R_2_AT= (R_2<0) ? R_2 : R_2*(1-earningsTaxRate);
        let tt={'date1':adate1,'add1':(R_1_AT/365),'date2':adate2,'add2':(R_2_AT/365),'taxRate':earningsTaxRate,'type':'rent'} ;
        additionsList.push(tt);

        stuff['growthPrice']=vv2['list']['price'];

        let daysGap1=adate2-adate1;

        let ts=false ;        // suppress read from cash for now (14 feb 2024)

        let anameR=aname+'@'+pname+'@rent';
        if (daysGap1>0) {             // if 0 daysgap, no rental income
          let ts=assetsCacheCum_read(anameR,adate1,adate2);          // _3 rental
          let t1,t2
          if (ts!==false) {     // read from cache
               t1=ts['t1'];
               t2=ts['t2'] ;
               stuff['nCacheUse']++ ;

// simInv_additions returns 5 element array:  [rawAdd,intAdd,beginValueGrowth,endvalue, samplePoints]
// note seperation of "raw" from "interest" earnings. Tee interest earnings (approximated) are saved seperatly from the actual Rental reciepts (or -reciepts)
          } else {    //  total rental income (no interest impacts on asset )
               t1=simInv_additions(0,R_1,R_2,0,0,daysGap1 )  ;  //  [rawAdd,intAdd,startGrowth,endvalue, samplePoints]
               let R_1t=R_1,R_2t=R_2;
               t2=t1;
               if (t1[0]>0)  {                            // positive rent -- so pay taxes?
                 R_1t=R_1*keepRate;
                 R_2t=R_2*keepRate;
                 t2=simInv_additions(0,R_1t,R_2t,0,0,daysGap1 )  ;  // total AT rental income (pre deposit in cash)
               }
          }   // ts != false
          ts={'t1':t1,'t2':t2 };
          assetsCacheCum_write(anameR,adate1,adate2,ts);
          stuff['nCacheNotUse']++ ;
          cumRentRaw+=t1[0];            // could use t1[3]
          cumRentRawAT+=t2[0];

// calculate change in Cash due to rents
          let R_1tB,R_2tB;
          if (cumRentRaw>0)   {    // rent is positive -- so is taxed
            R_1tB=R_1*keepRate;
            R_2tB=R_2*keepRate;
          } else {           // losses are not taxed (and can not be used to offset other income)
            R_1tB=R_1 ;
            R_2tB=R_2 ;
          }

      }        // daysgap>0

    }       // valueList

   stuff['daysGap']=daysGap;

   stuff['rentPeriod']=cumRentRaw ;        // actual additions
   stuff['rentPeriodAT']=cumRentRawAT;

   stuff['daysGap']=daysGap;
   stuff['earningsTaxRate']=earningsTaxRate;  // asset specific (but not date dependent)

   stuff['rentSay']=rentsSay.join(' ');
   stuff['dateSay']=datesSay.join(' ');

   let say1=setEntryDate(baseDateStamp).sayDate ;
   let say2=setEntryDate(modStamp).sayDate ;
   stuff['sayDates']=say1+' to ' +say2 ;

// loan info... (for entire period -- no need to do piece by piece)

   let loanStart=aentry['loanStart'];

   let loanAmount=aentry['loanAmount'];

   let loanOwed=aentry['loanAmount'];
   let gotLoan=false ;
   if (jQuery.isNumeric(loanStart) && loanStart>0) {
       let loanTerm=aentry['loanTerm'];
       let loanRate=aentry['loanRate'];
       let loanTaxDeduct=aentry['loanTaxDeduct'];
       gotLoan=getLoanInfo(pname,loanStart,aName,loanAmount,modStamp,loanRate,loanTerm,loanTaxDeduct) ;   // read from cache, or add entry to global portfolioLoans

   }   else {
      loanStart=false;
      loanAmount=0;
      loanOwed=0;
   }

   stuff['loanAmount']=loanAmount;
   stuff['loanOwed']=loanOwed;

   let loanPaidPeriodAT=0;
   if (gotLoan!==false) {
       let loanInfo=computeLoanStanding(pname,loanStart,aName,baseDateStamp,modStamp);   // read from global portfolioLoans  -- compute changes

       if (loanInfo===false) {
            simInvDsets['qStatusList']['errors'].push('Problem with loan start= '+loanStart+' : for asset '+aname+' in portfolio '+pname+' on '+baseDateStamp);
            alert('Problem with loan start= '+loanStart+' : for asset '+aname+' in portfolio '+pname+' on '+baseDateStamp);
            return false;
       }
       stuff['gotLoan']=1;
       stuff['loanOwed']=loanInfo['loanOwedEnd'];
       stuff['loanOwedStart']=loanInfo['loanOwedStart'];
       loanPaidPeriodAT=loanInfo['loanPaidPeriodAT'];
       stuff['loanPaidPeriod']=loanInfo['loanPaidPeriod'];
       stuff['loanPaidPeriodAT']=loanPaidPeriodAT;
       stuff['loanPrincipalPeriod'] =loanInfo['principalPaidPeriod'];
       stuff['loanInterestPeriod']=loanInfo['interestPaidPeriod'];
       stuff['loanInterestPeriodAT']=loanInfo['interestPaidPeriodAT'];
       stuff['loanPaidTotal'] = loanInfo['loanPaidTotal'];
       stuff['loanPaidTotalAT'] = loanInfo['loanPaidTotalAT'];
       stuff['loanTaxDeductValue'] =loanInfo['loanTaxDeductValue'];  ;

// and compute loan payments (impact on Cash)
// incorrect       let pDay= -loanPaidPeriodAT/daysGap ;  // daily AT loan payment each day of period

       let pGoo=loanInfo['principalPaidPeriod']+ loanInfo['interestPaidPeriodAT']  ;
       let pDayAT= -pGoo/daysGap ;  // daily AT loan payment each day of period
       let tt={'date1':adate00,'add1':pDayAT,'date2':adateEE,'add2':pDayAT,'taxRate':earningsTaxRate,'type':'loan'} ;
       additionsList.push(tt);

   } else {
       stuff['gotLoan']=0;
       stuff['loanOwed']=0 ;
       stuff['loanPaidPeriod']=0;
       stuff['cashAddLoan']=false;

   }     // gotloan

   stuff['doCashAdd']= portfolio_doCashAdds(additionsList,pname,aname,'_3',baseDateStamp,modStamp )  ;  // _3

   return stuff ;

}      // portfolioAssetsGrow_3

//=======================
// income stream
// no reinvestement, no price
// the difference between incomeStreams and annuities is ONLY in the value

function portfolioAssetsGrow_4(pname,aName,aentry,valueList,daysGap,atype,baseDateStamp,modStamp,doCashSample)    {
     let stuff={'type':4,'baseIncome':false,'growthIncome':false,'daysGap':false,'additionPeriod':false,'additionPeriod':false,
            'earningsTaxRate':false,'nCacheUse':0,'nCacheNotUse':0,'incomesSay':false,
            'nCacheUse':0,'nCacheNotUse':0 }

   let keepRate=1.0  ;                                // set on first iter of valueList
   let startPieceInc=0 ;
   let startPieceIncAT=0;
   let nCacheUse=0,incomesSay =[];
   let cumInc=0,cumIncAT=0 ;

   let additionsList=[] ;

   let earningsTaxRate =calcAsset_taxRate(aName,0);  // asset specific (but not date dependent).

   for (let ii=0;ii<valueList.length-1;ii++) {

        let vv1=valueList[ii];
        let adate1=vv1['date'];               // could use D_2 and P_2 from prior step

        let Inc_1=parseFloat(vv1['list']['income']) ;

        if (ii==0) {
          incomesSay.push(Inc_1);
          stuff['taxFreeFrac']=vv1['list']['taxFreeFrac'] ;      // same for this asset at all times
          keepRate=1- earningsTaxRate   ;       // earningsTaxRate incorporates taxFreeFrac
          stuff['baseIncome']=Inc_1;
        }
        let vv2=valueList[ii+1];
        let adate2=vv2['date'];

        Inc_2=parseFloat(vv2['list']['income']) ;
        incomesSay.push(Inc_2);
        stuff['growthIncome']=Inc_2;

       let daysGap1=adate2-adate1;
       if (daysGap1>0) {     // if 0, add onthing
          let Inc_1_AT=Inc_1*(1-earningsTaxRate);
          let Inc_2_AT=Inc_2*(1-earningsTaxRate);

          let tt={'date1':adate1,'add1':(Inc_1_AT/365),'date2':adate2,'add2':(Inc_2_AT/365),'taxRate':earningsTaxRate,'type':'income'} ;
          additionsList.push(tt);
        }
    }      // valuelist


    stuff['daysGap']=daysGap;
    stuff['earningsTaxRate']=earningsTaxRate;     // asset specific (but not date dependent)

    stuff['doCashAdd']= portfolio_doCashAdds(additionsList,pname,aname,'_4',baseDateStamp,modStamp)  ;   // _4

     cumIncAT=stuff['doCashAdd']['totalAddAll'];
     cumInc=cumIncAT/keepRate ;

    stuff['incomePeriod']=cumInc ;
    stuff['incomePeriodAT']=cumIncAT;

//    stuff['taxPeriod']=startPieceInc-startPieceIncAT ;
    stuff['taxPeriod']=cumInc-cumIncAT ;


    stuff['earningsTaxRate']=earningsTaxRate;  // asset specific (but not date dependent)

    stuff['incomeSay']=incomesSay.join(' ');

     let say1=setEntryDate(baseDateStamp).sayDate ;
     let say2=setEntryDate(modStamp).sayDate ;
     stuff['sayDates']=say1+' to ' +say2 ;


     return stuff;

}                // income


//=======================
// expense stream
// no reinvestement, no price

function portfolioAssetsGrow_7(pname,aName,aentry,valueList,daysGap,atype,baseDateStamp,modStamp,doCashSample)    {

    let stuff={'type':7,'baseExpense':false,'growthExpense':false,'daysGap':false,'additionPeriod':false,'additionPeriod':false,
         'earningsTaxRate':false,'nCacheUse':0,'nCacheNotUse':0,'expensesSay':false,'taxPeriod':0 }

   let earningsTaxRate =calcAsset_taxRate(aName,0);  // asset specific (but not date dependent). Note taht calcAsset_taxRate gets taxFreeFrac with getAssetLookup()
   let earningsTaxRateUse=0 ;                // assume no tax deductions from this expanse   -- taxFreeFrac!=0   changes this

   let additionsList=[];

   let taxDeduct=0;
   let taxDeductFrac=0  ;            // set on first iter of valueList
   let startPieceExp=0 ;
   let startPieceExpAT=0;
   let nCacheUse=0,expensesSay =[];
   let cumExp=0,cumExpAT=0;

   for (let ii=0;ii<valueList.length-1;ii++) {

        let vv1=valueList[ii];
        let adate1=vv1['date'];               // could use D_2 and P_2 from prior step

        let Exp_1=parseFloat(vv1['list']['expense']) ;

        if (ii==0) {
           expensesSay.push(Exp_1);
           stuff['baseExpense']=Exp_1;
           taxDeductFrac=vv1['list']['taxFreeFrac'] ;      // never changes  -- fraction of expense that can be used for tax deductions
           if (taxDeductFrac>0) earningsTaxRateUse=earningsTaxRate ;           // expenses can be used as tax deduction?
        }

        let vv2=valueList[ii+1];
        let adate2=vv2['date'];

       let  Exp_2=parseFloat(vv2['list']['expense']) ;
        expensesSay.push(Exp_2);
        stuff['growthExpense']=Exp_2;

        let daysGap1=adate2-adate1;

        if (daysGap1>0) {
          if (taxDeductFrac>0){           // expenses can be used as tax deduction?
               let Exp_1_AT=Exp_1* (1-earningsTaxRateUse);
               let Exp_2_AT=Exp_2* (1-earningsTaxRateUse);
               let tt={'date1':adate1,'add1':(-Exp_1_AT/365),'date2':adate2,'add2':(-Exp_2_AT/365),'taxRate':earningsTaxRateUse,'type':'expense'} ;
               additionsList.push(tt);
          } else {
               let tt={'date1':adate1,'add1':(-Exp_1/365),'date2':adate2,'add2':(-Exp_2/365),'taxRate':earningsTaxRateUse,'type':'expense'} ;
               additionsList.push(tt);
          }
        }

     }           // valuelist

     stuff['doCashAdd']=portfolio_doCashAdds(additionsList,pname,aname,'_7',baseDateStamp,modStamp)  ;    // _ 7

     stuff['daysGap']=daysGap;
     if (taxDeductFrac>0)  taxDeduct=(cumExp-cumExpAT)*taxDeductFrac;     // otherwise its 0

      if (taxDeductFrac>0){           // expenses can be used as tax deduction?
         cumExpAT=stuff['doCashAdd']['totalAddAll'];
         cumExp=cumExpAT/ (1-earningsTaxRateUse);
      } else {     // no tax impacts
          cumExp=stuff['doCashAdd']['totalAddAll'];
          cumExpAT=stuff['doCashAdd']['totalAddAll'];
     }

     stuff['daysGap']=daysGap;
     stuff['expensePeriod']=cumExp ;            // will be positive
     stuff['expensePeriodAT']=cumExpAT;

     stuff['taxPeriod']= taxDeductFrac ;       // will be negative , or 0

     stuff['earningsTaxRate']=earningsTaxRate;     // asset specific (but not date dependent)
     stuff['taxDeductFrac']=taxDeductFrac ;                 // reduction in taxes from using expense as tax deduction

     stuff['expenseSay']=expensesSay.join(' ');

     let say1=setEntryDate(baseDateStamp).sayDate ;
     let say2=setEntryDate(modStamp).sayDate ;
     stuff['sayDates']=say1+' to ' +say2 ;


     return stuff;

}                // 


//========
// annuity earnings
//       uses computed annuity earnings at baseDateStamp and modStamp -
//       this is a function of the "annuity value at acquistion (incomeStart)", and its "growth rate at acquistion"
//      Otherwise, similar to  portfolioAssetsGrow_4
function portfolioAssetsGrow_5(pname,aName,aentry,valueList,daysGap,atype,baseDateStamp,modStamp,doCashSample)    {

   let stuff={'type':5,'baseIncome':false,'growthIncome':false,'daysGap':false,'additionPeriod':false,'additionPeriod':false,
         'earningsTaxRate':false,'nCacheUse':0,'nCacheNotUse':0,'incomesSay':false,'baseAnnuity':false};

   let keepRate=1.0  ;                                // set on first iter of valueList
   let startPieceInc=0 ;
   let startPieceIncAT=0;
   let nCacheUse=0,incomesSay =[];

   let acqDate=aentry['incomeStart'];   // same acquistion date for all "pieces"
   let cumInc=0,cumIncAT=0;

   let additionsList=[];

   let earningsTaxRate =calcAsset_taxRate(aName,0);  // asset specific (but not date dependent). this already incoporates taxFreeFrac

   let anameA=aname+'@annuity';

   for (let ii=0;ii<valueList.length-1;ii++) {

        let vv1=valueList[ii];
        let adate1=vv1['date'];               // could use D_2 and P_2 from prior step

        let A_1=vv1['list']['income'];
        let G_1=vv1['list']['growthFrac'];

        let useValue1,useValue2;

        let ts1=assetsCacheCum_read(anameA,acqDate,adate1);  //   _5     (1st)

        if (ts1!==false) {
            useValue1=ts1['useValue1'];
            stuff['nCacheUse']++ ;
        } else {
           usevalue1=calcAnnuityValueCurrent(A_1,G_1,acqDate,adate1);
           assetsCacheCum_write(aname,acqDate,adate1,{'useValue1':useValue1} );
           stuff['nCacheNotUse']++ ;
        }

        let Inc_1=usevalue1[0];
        let GR_1=usevalue1[1];
        if (ii==0) {
          incomesSay.push(Inc_1+' ('+GR_1+') ');
          stuff['taxFreeFrac']=vv1['list']['taxFreeFrac'];     //  for info purposes
          keepRate=1-(earningsTaxRate) ;       // if none of income taxed, then effective tax rate is 0
          stuff['baseIncome']=Inc_1;
        }

        let vv2=valueList[ii+1];
        let adate2=vv2['date'];               // could use D_2 and P_2 from prior step

        let A_2=vv2['list']['income'];
        let G_2=vv2['list']['growthFrac'];

        let ts2=assetsCacheCum_read(anameA,acqDate,adate2);       // _5 (2nd)

        if (ts2!==false) {
            useValue2=ts2['useValue2'];
        } else {
             usevalue2=calcAnnuityValueCurrent(A_2,G_2,acqDate,adate2);
             assetsCacheCum_write(aname,acqDate,adate2,{'useValue2':useValue2});
             stuff['nCacheNotUse']++ ;
        }
        let Inc_2=usevalue2[0];
        let GR_2=usevalue2[1];

        stuff['growthIncome']=Inc_2;
        incomesSay.push(', '+Inc_2+' ('+GR_2+') ');

        let daysGap1=adate2-adate1;

        if (daysGap1>0)  {
           let Inc_1t=Inc_1*keepRate ;
           let Inc_2t=Inc_2*keepRate ;
           let tt={'date1':adate1,'add1':(Inc_1t/365),'date2':adate2,'add2':(Inc_2t/365),'taxRate':earningsTaxRate,'type':'annuity'} ;
           additionsList.push(tt);
        }

     }      // valulise

    stuff['daysGap']=daysGap;
    stuff['earningsTaxRate']=earningsTaxRate;     // asset specific (but not date dependent)

     stuff['doCashAdd']=portfolio_doCashAdds(additionsList,pname,aname,'_5',baseDateStamp,modStamp)  ;   // _5
     cumIncAT=stuff['doCashAdd']['totalAddAll'];
     cumInc=cumIncAT/ keepRate ;

     stuff['daysGap']=daysGap;
     stuff['incomePeriod']=cumInc ;
     stuff['incomePeriodAT']=cumIncAT;

     stuff['incomeSay']=incomesSay.join(' ');

     stuff['taxPeriod']=cumInc-cumIncAT ;
     stuff['earningsTaxRate']=earningsTaxRate;  // asset specific (but not date dependent)

    stuff['incomeSay']=incomesSay.join(' ');

     let say1=setEntryDate(baseDateStamp).sayDate ;
     let say2=setEntryDate(modStamp).sayDate ;
     stuff['sayDates']=say1+' to ' +say2 ;

     return stuff;

}                // annuity income


//==============
// oneOffs -- taxable receipts recieved at start of period... these are added to cash at start of period
// (cash may then grow at cashInterest or cashPenalty rates)
// note that negative oneOffs can NOT offset other income
// 5 feb 2024 : this returns the oneOffs recieved in the period from baseDateStamp to modStamp
//              if its the start of this period (daysGap=0), the oneoff has NOT yet occured -- so 0 is returnd
//              otherwise, the value of the oneOFf.
//              Iow: it is recieved on daysGap=1, and only on daysGap=1 -- but this returns the "sum" of all reciepts in the period
//              (which means the daysGap=1 receipt)

function  portfolioAssetsGrow_6(pname,aName,aentry,values0, daysGap,atype,baseDateStamp,modStamp,doCashSample)    {

   let stuff={'type':6, 'baseReceipt':false,   'modReceipt':false ,'daysGap':false,
       'receiptPeriod':false,
       'nCacheUse':0,'nCacheNotUse':0,
        'additionPeriod':false,'additionPeriod':false,
        'taxPaid':0,'earningsTaxRate':false,
        'changeCashOneOff':0,'changeCashPeriod':false  }    ;

   let areceipt=parseFloat(values0['receipt'])  ;          // the income is recieved "the day after" prior entry

// special case: growDays=0 : oneOff reciepts NOT distributed!

//  let cashAddObj={'nadd':1,'currentVal':false,'rawAdd':false,'growthAdd':false,'cashInt':false} ;

   if (daysGap==0) {              // daysGap=0 means this is a mod or init entry -- so oneOffs are pending (realized the next day)
     stuff['baseReceipt']=areceipt;        // oneoffs specified in base entry, but NOT yet recieved
     stuff['receiptPeriod']=0;              // oneoffs recieved within this period (i.e.; the day after baseDate)
     stuff['receiptPeriodAT']=false;
     stuff['changeCashOneOff']=0;
      stuff['daysGap']=0;
     stuff['doCashAdd']=false ;
     return stuff;
   }

   let receiptPeriod=  areceipt  ;             // note that oneOffs are added to `Cash`, and will grow at cashInterest rate
   stuff['baseReceipt']=areceipt;
   stuff['receiptPeriod']=receiptPeriod ;
   stuff['receiptPeriodAT']=receiptPeriod ;
   stuff['changeCashOneOff']=receiptPeriod   ;
   stuff['daysGap']=daysGap ;

   stuff['doCashAdd']=portfolio_doCashAdds(receiptPeriod,pname,aName,'_6',baseDateStamp,modStamp)  ;                     // _6  -- special case
 
   return stuff;
}


//==================
// calculate correct net values and taxes
// checkEntry is the output of growPortfolioB --    modAssetList

//returns {cashAsset totAssetSale totAssetSaleNet totAssetSaleNetAT totPortfolioValue totCapGainTax totDeferredTax totTaxPaid totPropertySale}

function calc_netValues(checkEntry,cashAsset,amess ) {
  let atotals=checkEntry['totals'];
  let dstamp=checkEntry['dateStamp'];
  let totals2={} ;

 totals2['cashAsset']=cashAsset ;

  let totNetSale=0;
  let totCapGain=0;
  let totTaxDeferredSale=0;
  let totRegularSale=0;
  let totStockSale=0;
  let totPropertyProfit=0;
  let totPropertySale=0;
  let totEarningsAT_est=0;
  let totTaxOnEarnings=0;

  let totAssetSale=0;
  totAssetSale+=atotals['totStock'];
  totAssetSale+=atotals['totRegular'];
  totAssetSale+=atotals['totTaxDeferred'];
  totAssetSale+=atotals['totProperty'];
  totals2['totAssetSale']=totAssetSale ;

 let totAssetSaleNet=0;
  totAssetSaleNet+=atotals['totStock'];
  totAssetSaleNet+=atotals['totRegular'];
  totAssetSaleNet+=atotals['totTaxDeferred'];
  totAssetSaleNet+=atotals['totPropertyNet'];
  totals2['totAssetSaleNet']=totAssetSaleNet ;

 let totAssetSaleNetAT=0;
  totAssetSaleNetAT+=atotals['totRegularAT'];
  totAssetSaleNetAT+=atotals['totTaxDeferredAT'];
  totAssetSaleNetAT+=atotals['totStock'];
  totAssetSaleNetAT+=atotals['totPropertyNet'];
  let totCapGains=0;
  totCapGains+=atotals['totCapGainsTaxable'];
  let capGainsTax=totCapGains*simInvParams['capGainsRate'] ;
  capGainsTax=Math.max(capGainsTax,0);

  totAssetSaleNetAT=totAssetSaleNetAT-capGainsTax ;       // combines all capital gains (allows losses to offset gains)
  totals2['totAssetSaleNetAT']=totAssetSaleNetAT ;

  let totPortfolioValue=totAssetSaleNetAT + cashAsset ;
  totals2['totPortfolioValue']= totPortfolioValue ;

  totals2['totCapGainTax']= Math.max(0,capGainsTax) ;      // no rollovers, either to other income or to other years

  let tdef=atotals['totTaxDeferred']-atotals['totTaxDeferredAT'] ;
  totals2['totDeferredTax']=Math.max(0,tdef);                   // no rollovers, either to other income or to other years

  totals2['totTaxPaid']= Math.max(0,totAssetSaleNet-totAssetSaleNetAT) ;
  totals2['totPropertySale']=atotals['totProperty'] ;

  return totals2 ;

}        //   calc_netValues  cashAsset






