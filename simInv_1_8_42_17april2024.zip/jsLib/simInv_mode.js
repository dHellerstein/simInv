// simInv mode functions -- called by init(). Thus: this is called by init...
// end result is an error message, a relogon message, or a callback to init2
// uses index.html parameters:
//   allowStandAlone=1;           //  1 to allow standAlone mode -- file:/// access using local storage
//   allowOnLine=1;               //  1 to allow onLine mode -- http:// (or https://) using server or local storage
//   onLineLocalStorage=2 ;       //  0 to use server storage, 1 to use local storage, 2 to allow user to decide. Ignored if file:/// access


function simInv_mode(ifoo) {

 // local storage supported?

  if  (simInvGlobals['protocolUsed']=='file') {              // protcolUsed is global set in index.html (before call to init)
     let qq2=simInv_mode_standalone(1);
     return  ;   //  simInv_mode_standalone calls init2
  }

 // if here. onLine mode

  if  (simInvGlobals['protocolUsed']!=='http'  ) {
      bmess+='<b>Sorry:</b> protocol is not http: or https: ('+simInvGlobals['protocolUsed']+')';
      bmess+='<br>Please see <a href="readme.txt" target="viewer">readme.txt</a>, or ';
      bmess+='  <a href="install.txt" target="viewer">install.txt</a>, for the details! ';
      simInv_errorMessage(bmess);
      return  ;
  }

  if (allowOnLine!=1) {
      bmess+='<b>Sorry:</b> onLine mode (using <tt>http://</tt> or <tt>https://</tt>) is not enabled on this simInv installation.';
      bmess+='<br>Please see <a href="readme.txt" target="viewer">readme.txt</a>, or ';
      bmess+='  <a href="install.txt" target="viewer">install.txt</a>, for the details! ';
      simInv_errorMessage(bmess);
      return  ;
  }

  $('#logonStandaloneMessage').hide();
  $('#logonOnlineLocalMessage').hide();
  $('#logonOnlineLocalMessageChoice').hide();

  $('#logonEncryptionBlock').show();
  let nowTime=wsurvey.get_currentTime(0) ;

// note: onLineLocalStorage: 0 to use server storage, 1 to use local storage, 2 to allow user to decide.
  let qEnable=2;           // user choses on first logon (init_locaUser will set 'enabled'
  if (onLineLocalStorage==0) qEnable=false;        // never use online storage
  if (onLineLocalStorage==1) qEnable=true;        // always use local storage
   simInvDsets['simInvLocalStorage']= {'enabled':qEnable,'onLineLocalStorage':onLineLocalStorage,
                  'protocol':simInvGlobals['protocolUsed'],'nowTime':nowTime,
                  'data':{},'statusMessage':'',
                  'usage':0,'quota':0,
                  'lastUpdate':false,'init':false
  } ;

  if (qEnable===false)  { // not local storage, so no need to check for userData, etc
       init2(true);
       return 1;
  }

  simInv_mode_onLineLocal(1)   ; // will call init2 -- note that userData init even if local storage is "user choice"

}

//========
// check onLine with local storage mode ...
function   simInv_mode_onLineLocal(ifoo) {
 let bmess='';

   qq=simInv_indexDbAvailable();     // is local storage indexDb on this browser?
   if (!qq) {      //   indexDB available?
      bmess+='<b>simInv errror (onLine mode with local storage)</b>';
      bmess+=' indexDb storage not enabled on this browser  ';
      bmess+='<br>Please see <a href="readme.txt" target="viewer">readme.txt</a>, or ';
      bmess+='  <a href="install.txt" target="viewer">install.txt</a>, for the details! ';
      simInv_errorMessage(bmess);
       simInvDsets['simInvLocalStorage']['statusMessage']='indexDb storage not enabled on this browser ';
      return false;  // indexDb storage desired, but not available. QUit
   }

// get the list of userNames -- or initialize. If initialize, ask user to logon with his username
     checkDatabaseExists_indexDb(simInv_mode_onLineLocal2)  ; // simInv_mode_onLineLocal :no username yet ... this does something on the "first logon"

}

//========
// callback from  checkDatabaseExists_indexDb
// icode: 1: init not needed, 2:init performed
function simInv_mode_onLineLocal2(qok,icode) {

  if (!qok) {
     simInv_errorMessage('Unable to access indexDb database (errorcode: '+icode+'\n See <a href="readme.txt" target="readme">readme.txt</a> for details ');
     return false;
  }
   if (qok && icode==2)  {               // first time init
      let amess='(online mode, with local storage): <b>This is the first simInv logon (using this browser on this machine).</b>';
      amess+='<br>Userlist initialization was successful.';
      simInv_errorMessage(amess,1);
      return false;
   }

// if here, regular start. Continue -- afterLogon will read the user specific info

  let qlocal2=simInvDsets['simInvLocalStorage']['enabled'];
   if (qlocal2===true) {
      $('#logonEncryptionBlock').hide();  // no encryption if standalone -- but perhaps if user choice
   } else {
       if (qlocal2==2)  {
         $('#logonOnlineLocalMessageChoice').show();  // online, or user choice
       } else {
         $('#logonOnlineLocalMessage').show();  // online, or user choice
       }
       $('#logonStandaloneMessage').hide();  // simInv_mode_onLineLocal2
   }
// onLineLocalStorage = false signals "standAlone" mode

    simInvDsets['simInvLocalStorage']['statusMessage']='indexDb userList initialized' ;
  init2(true);    // continue logging on (read username, etc)
}


//========    :; standalone :::::::::
// check standAlone mode ...
function   simInv_mode_standalone(ifoo) {
 let bmess='';

// fatal errors ....
  if (allowStandAlone!=1) {       // local storage not enabled on this simInv install
      bmess+='<b>Sorry:</b> standAlone mode (using <tt>file:///...</tt>) is not enabled on this simInv installation.';
      bmess+='<br>Please see <a href="readme.txt" target="viewer">readme.txt</a>, or ';
      bmess+='  <a href="install.txt" target="viewer">install.txt</a>, for the details! ';
       simInvDsets['simInvLocalStorage']['statusMessage']='indexDb storage not enabled on this browser ';
      simInv_errorMessage(bmess);
      return false;                   // do not call init2
  }

   qq=simInv_indexDbAvailable();     // is local storage indexDb on this browser?
   if (!qq) {      //   indexDB available?
      bmess+='<b>simInv errror (standAlone mode)</b>';
      bmess+=' indexDb storage not enabled on this browser  ';
      bmess+='<br>Please see <a href="readme.txt" target="viewer">readme.txt</a>, or ';
      bmess+='  <a href="install.txt" target="viewer">install.txt</a>, for the details! ';
      simInv_errorMessage(bmess);
       simInvDsets['simInvLocalStorage']['statusMessage']='indexDb storage not enabled on this browser ';
      return false;  // indexDb storage desired, but not available. QUit
   }

// get the list of userNames -- or initialize. If initialize, ask user to logon with his username
     checkDatabaseExists_indexDb(simInv_mode_standalone2 )  ; // simInv_mode_standalone: no username yet ... this does something on the "first logon"
}

// callback after   checkDatabaseExists_indexDb
function simInv_mode_standalone2(qok,icode) {

  if (!qok) {
     simInv_errorMessage('Unable to access indexDb database (errorcode: '+icode+'\n See <a href="readme.txt" target="readme">readme.txt</a> for details ');
     return false;
  }
   if (qok&& icode==2)  {               // first time init
      let amess='(standAlone mode): <b>This is the first simInv logon (on this devise).</b>';
      amess+='<br>Userlist initialization was succsseful.';
      simInv_errorMessage(amess,1);
      return false;
   }

// if here, regular start. Continue -- afterLogon will read the user specific info
    $('#logonEncryptionBlock').hide();  // no encryption if standalone
    $('#logonStandaloneMessage').show();        //simInv_mode_standalone2
   $('#logonOnlineLocalMessage').hide();


// init simInvLocalStorage
  let nowTime=wsurvey.get_currentTime(0) ;

  let protocolUsed=simInvGlobals['protocolUsed'] ;
  simInvDsets['simInvLocalStorage']= {'enabled':true,'onLineLocalStorage':false,'protocol':protocolUsed,'nowTime':nowTime,
                  'data':{},'statusMessage':'',
                  'usage':0,'quota':0,
                  'lastUpdate':false,'init':false
  };
  init2(true);    // continue logging on (read username, etc)

}


