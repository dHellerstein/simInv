// ============ library of functions: export and import data from simInv

//========================
// menu for export or achive data (local textarea save mode)
// user is responsible for copying/pasting data to a local file

function doExport_menu(ido) {
  if (arguments.length<1) ido=0;
  let bmess='';

  let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;

 let cfoo=$('.cdoExportImport_status');
 cfoo.hide();



// select action
 bmess+='<div style="background-color:#e2ffff;width:99%"> ';
  bmess+='<a name="exportTop">'
  bmess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#exportArchiveRestoreHelp1">&#10068;</button>';
  bmess+='</a>';
  bmess+=' You can save,   export &amp; import, or archive ... your simInv data &hellip;';
  bmess+='<span style="float:right;margin-right:1em">';
  bmess+=' <button class="csettingsButton" title="save most-recently-viewed portfolio summaries to CSV file" data-which="summary" onclick="doExportImport_viewResults_menu(this)">&Sscr;ave current portfolio summaries</button> ';
  bmess+='</span>';
  bmess+='</div>';


  bmess+='<ul class="fingerMenu">';

// 20 march 2024 -- needs fixing
  if (simInvSummaryResults['ngot']>0) {
     bmess+='<li><input class="csettingsButton" title="Note that non-inflation, and inflation adjusted, versions are seperate scenarios" type="button" value="Scenario summaries"  data-ison="0"  onClick="doExportImport_summaryStats(this)"> ';
     bmess+='Scenario summaries ... from  '+simInvSummaryResults['ngot']+' scenarios  (that you  &#128176;  displayed in this session)     ';
     bmess+='<p>';
  }

  bmess+='<li>Save (as a CSV -- suitable for use with spreadsheets) :' ;
  bmess+='<menu class="tighterMenu">';

  let oof=setEntryDate(true);
  let nowDate=oof.sayDate;
  let hdr=userName+'  on '+nowDate;

  bmess+='<li><input class="csettingsButton" type="button" value="Asset histories"  data-ison="0" onClick="doExportImport_assets(0,this)">     ';
  bmess+=' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ... <em>optional comment</em> <input type="text" size="70" value="'+hdr+'" title="optional comment (included at top)" id="doExportImport_assets_comment">';

  bmess+='</menu><p>';

  bmess+='<li>Export (or import) all simInv data (as a JSON-like file) ...';
  bmess+='<menu class="tighterMenu">';
  bmess+=' <li><input  class="csettingsButton"  type="button" value="Export" onClick="doExportImport_export(this)"> data (suitable for importing at a later date)';
  bmess+='<li><input  class="csettingsButton"  type="button" value="Import" onClick="doExportImport_import(this)"> data (that was exported ... at an earlier date)';
  bmess+='</menu>';
  bmess+='<p>';

  if (simInvGlobals['enableAutoArchive']>0) {
     bmess+='<li>Restore from <u>simInv internal archive</u> ';
     bmess+='<br>You can <button  class="csettingsButton"  onClick="autoArchive(0)">create, or restore</button>  your simInv data ';
     bmess+=' (from the most recent auto-archive, or from a manually saved version)';
  }

  bmess+='</ul>';


  bmess+='<div id="doExportImport_menus" style="border:2px solid blue;xdisplay:none"></div>';

  bmess+='<div id="doExportImport_checkAdd" class="cCheckAdd" style="display:none"></div>';


// -- asset displays --

  bmess+='<div id="doExportImport_assetResultsOuter"   style="border:2px solid blue;display:none"> ';
    bmess+='<input type="button" value="x" title="close asset results" onClick="$(\'#doExportImport_assetResultsOuter\').hide()" >';
   if (!qLocal) {     // server storage okay
     bmess+='<button onClick="doExport_serverSave(this)" data-div="doExportImport_assetResults" data-what="assets" title="save to local file (via the server)" >';
     bmess+='&#128193;</button>';
   }

    bmess+='<button onClick="doExport_menuPreview(this)" style="display:none" data-show="assets" >preView ...</button> ';

   bmess+='<a href="assetHistory_varList.txt" target="varlist" class="csaveButtonSmall" title="View asset history description in a popup window">Details on asset history ... </a>';

//    bmess+='<button onClick="scrollToDiv(this)" data-show="0" style="font-size:110%;font-weight:600"  data-parent="statusDiv" data-where="doExportImport_assetAttributes">View asset notes</button> ';

    bmess+='<button onClick="simInv_div_Mark(this)" data-div="doExportImport_assetResults"  data-gotit="doExportImport_assetResultsCopied" >copy assets CSV to the clipboard</button> ';

     bmess+='  <span style="font-size:100%;color:green;display:none" id="doExportImport_assetResultsCopied"  class="cdoExportImport_status" >';
     bmess+='Copied!! You can now paste the asset CSV to a spreadsheet (or other) file</span>';
      bmess+='  <span style="font-size:100%;color:purple;display:none"    class="cdoExportImport_status"  id="doExportImport_resultsSaved_assets"></span>  ';

   bmess+='<div id="doExportImport_assetResults" class="cAssetResults"  ></div>';
   bmess+='</div>';

/* 19 march 2024 derpecated -- use assetHistory_varList.txt
//   bmess+='<div id="doExportImport_assetAttributes" style="border:2px solid orange;display:none;padding:3px;margin:1em 1em ">';
//   bmess+='<input type="button" value="x" title="Close" onClick="$(\'#doExportImport_assetAttributes\').hide()">' ;
   bmess+='<a class="cViewSummaryButton"   title="to top" href="#exportTop">&uarr;</a> ';
   bmess+='Column headers have the form <tt>assetName:attributeName</tt>. Different attributes are available for each asset (depending on the asset type)';
   bmess+='<br>Description of attributes </em>. <tt>n.a.</tt> means this attribute is not specified for this asset ... ';
   bmess+='<br>All cumulative values are relative to the first entry of an asset.';
   bmess+='<ul class="boxList">';
   bmess+='<li><b>Type</b> : asset type. 0=stock, 1=bond, 2=tax deferred bond, 3= property, 4=income stream, 5=annuity, 6=oneOff, 7=expense ';
   bmess+='<li><b>existing</b> 1: value specified in an asset history entry, 0: interpolated';
   bmess+='<li><b>priorDate</b>  date used to find lower bound of interpolation. If false, interpolation not used ';
   bmess+='<li><b>nextDate</b> date used to find upper of interpolation. If false, interpolation not used ';
   bmess+='<li><b>interest</b> Yearly interest rate (as of this date)   ';

   bmess+='<li><b>growthCum</b> Cumulative growth, per share. Example: 1.5 means 50% growth since first entry (for this asset)';
   bmess+='<li><b>growthCumAT</b>  After tax cumulative growth, per share';
   bmess+='<li><b>earningsCum</b> Cumulative earnings, per share. Example: 2.30 means $2.30 growth per share (since first entry)';
   bmess+='<li><b>earningsCumAT</b> After tax  cumulative earnings, per share. ';
   bmess+='<li><b>earningsTaxCum</b> Cumulative taxes paid on earnings, per share ';
   bmess+='<li><b>earningsThisGap</b> Earnings since prior entry';
   bmess+='<li><b>price</b> Price of asset (on this date)   ';
   bmess+='<li><b>dividend</b> Yearly dividend   ';

   bmess+='<li><b>income</b> Yearly income ';
   bmess+='<li><b>netCumIncomeAT</b> Cumulative income  (since first entry)';
   bmess+='<li><b>netCumExpenseAT</b> Cumulative expense  (since first entry)';
   bmess+='<li><b>growthFrac</b> Growth of stock, per share   (since first entry)';
   bmess+='<li><b>rent</b> Yearly rental income earned  ';
   bmess+='<li><b>netCumRentAT</b>  After tax cumulative rental income  (since first entry)'  ;
   bmess+='<li><b>receipt</b> oneOff receipt (received first day after oneOff asset added to a portfolio) ';

  bmess+='</ul>';
 */


  bmess+='</div>';

// -- portfolio displays --

  bmess+='<div id="doExportImport_portfolioResultsOuter" style="border:2px solid cyan;display:none"> ';
   bmess+='<input type="button" value="x" title="close portfolio results" onClick="$(\'#doExportImport_portfolioResultsOuter\').hide()" >';
   if (!qLocal) {  // server storage okay
     bmess+='<button onClick="doExport_serverSave(this)" data-div="doExportImport_portfolioResults" data-what="portfolios" title="save to local file (via the server)" >';
     bmess+='&#128193;</button>';
   }

   bmess+='<button onClick="doExport_menuPreview(this)" data-show="portfolios" >preView zz</button> ';
   bmess+='<button onClick="scrollToDiv(this)" data-show="0"  data-parent="statusDiv" style="font-size:110%;font-weight:600"  data-where="doExportImport_portfolioAttributes">View portfolio notes</button> ';
   bmess+='<button onClick="simInv_div_Mark(this)" data-div="doExportImport_portfolioResults"  data-gotit="doExportImport_portfolioResultsCopied" >copy portfolio CSV to the clipboard</button> ';

    bmess+='  <span style="font-size:100%;color:green;display:none" id="doExportImport_portfolioResultsCopied"  class="cdoExportImport_status" >  ';
    bmess+='Copied! You can now paste the portfolio CSV to a spreadsheet (or other) file</span>';

    bmess+='  <span style="font-size:100%;color:purple;display:none"  class="cdoExportImport_status"  id="doExportImport_resultsSaved_portfolios"></span>  ';

   bmess+='<div id="doExportImport_portfolioResults"  class="cAssetResults" ></div>';
   bmess+='</div>';

     bmess+='<div id="doExportImport_portfolioAttributes" style="border:2px solid tan;display:none;padding:3px;margin:1em 1em ">';
   bmess+='<input type="button" value="x" title="Close" onClick="$(\'#doExportImport_portfolioAttributes\').hide()">' ;
   bmess+='<a class="cViewSummaryButton"   title="to top" href="#exportTop">&uarr;</a> ';

   bmess+='Each initialization and modification entry uses several lines: a summary line, and one line for each asset.';
   bmess+='The asset-attributes and summary variables are in their own columns. <br>';
   bmess+='Thus: on <tt>asset lines</tt> the summary columns are blank; ';
   bmess+=' and on <tt>summary lines</tt> the asset columns are blank.';
   bmess+='<br>Description of <tt>asset attributes</tt> and <tt>summary varibles</tt> </em>. <tt>false</tt> (or empty) means this attribute is not specified for this asset ... ';
   bmess+='<br><b>Asset attributes </b> ';
   bmess+='<ul class="boxList">';

   bmess+='<li><b>totNetValue</b> total value of all assets, and <u>Cash</u> -- after liquidation, taxes, and loan payorrs';
   bmess+='<li><b>cashAsset </b> value of the <u>Cash</u> asset ';
   bmess+='<li><b>growDays</b> Number of days after prior entry. <tt>0</tt> for initialization entries. Assets in the prior entry will grow for this many days (modifications occur after growth)';
   bmess+='<li><b>ith</b>  entry number for this portfolio. 0: initialziation entry, 1: first modification entry';
   bmess+='<li><b>assetName</b> name of asset. For <tt>summary lines</tt> this will be empty';
   bmess+='<li><b>assetType</b> : asset type. 0=stock, 1=bond, 2=tax deferred bond, 3= property, 4=income stream, 5=annuity, 6=oneOff, 7=expense ';
   bmess+='<li><b>q</b> quantity of the asset. For properties this <tt>1</tt>; for  incomes, annuities, expenses, and oneOffs: <tt>0</tt>';
   bmess+='<li><b>value</b> value of the asset (selling all shares, or selling a property).   For incomes, annuities, expenses and oneOffs: <tt>0</tt>';
   bmess+='<li><b>valueNet </b> value of the asset (all share); after paying off loans.  For incomes, annuities, expenses and oneOffs: <tt>0</tt>';
   bmess+='<li><b>valueNetAT </b> value of the asset (all share); after paying off loans, saleCosts (if a property), &amp; paying taxes (capital gains taxes). For incomes, annuities, expenses and oneOff ... this is always <tt>0</tt>';
   bmess+='<li><b>cost </b> Approximate cost of acquiring asset. The purchase price (stocks, bonds), or acquistion cost.';
   bmess+='<li><b>capGains</b> Capitals gains (value-basis). Nn-zero for stocks and properties';
   bmess+='<li><b>yearlyIncome</b> Yearly income stream -- non-zero for incomes.';
   bmess+='<li><b>yearlyAnnuity</b> Base of yearly annuity -- non-zero for annities. Actual annuity grows from this base (at specified fraction of CPI)';
   bmess+='<li><b>yearlyNetRent</b> Yearly after tax rental income  -- non-zero for properties';
   bmess+='<li><b>yearlyRevenue</b> rental stream, income, or annuity';
   bmess+='<li><b>yearlyExpense</b> Yearly expense stream -- non-zero for expenses.';

   bmess+='<li><b>acqCost</b> upfront cost. Non-zero for properties, incomeStreams, annuities, and oneOffs.';

   bmess+='<li><b>purchaseCost </b> purchase cost. Non-zero for stocks and bonds';
   bmess+='<li><b>origPrice </b> purchase price (when added to portfolio). Non-zero for properties';
   bmess+='<li><b>addVal </b> yearly additions (or removals if negative) -- from (or to) <u>Cash</u>. Non-zero for regular and tax-deferred bonds';
   bmess+='<li><b>doRMD </b> required mimimum distributions will be drawn. 0:no, 1:self schedule, 2:inherited schedule. Non-zero for tax-deferred bonds';
   bmess+='<li><b>nowAge </b> your age when rmd added to portfolio.';
   bmess+='<li><b>rmdStart </b> dateStamp -- when this asset (that is subject to rmd) was added to portfolio';
   bmess+='<li><b>basis </b> basis. Non-zero for stocks and properties. capGains is <tt>value - basis</tt>';
   bmess+='<li><b>price </b> price of asset. For bonds: <tt>1.0</tt>  for incomes, annuities, expenses, and oneOffs : <tt>0</tt> ';
   bmess+='<li><b>taxOnSale </b> tax paid when asset sold. Non-zero for stocks, tax-deferred bonds, and properties.';
   bmess+='<li><b>loanOwed </b>';
   bmess+='<li><b>loanOriginal </b>';
   bmess+='<li><b>loanSchedule_startDate </b> Dates loan started';
   bmess+='<li><b>loanSchedule_amount </b> Amount of loan';
   bmess+='<li><b>loanSchedule_term </b> Term of loan';
      bmess+='<li><b>loanSchedule_rate </b> Interest rate of loan';
   bmess+='<li><b>loanSchedule_taxDeduct </b> If <tt>1</tt>: interest payments are tax deductible';
   bmess+='<li><b>loanSchedule_refiCost </b> If this is a loan refinance - the cost of the refinance (negative if extra cash was drawn)';
   bmess+='<li><b> loanSchedule_owed</b> amount owed (same as <tt>loanOwed</tt>';
   bmess+='<li><b>incomeStart </b> starting date of an annuity -- annuityBase calculated as of this date';
   bmess+='<li><b>annuityBase </b> the starting size of an annuity ';
   bmess+='<li><b> annuityGrowth</b> growth rate of an annuity (as fraction of CPI) -- applied to annuityBase';
   bmess+='<li><b>oneOffReceipt_pending </b> oneOff receipt  -- if non-zero, this value is added (or removed) from <u>Cash</u> on the day after oneOffDate';
   bmess+='<li><b>oneOffDate </b> oneOff receipt on the day after this date';
   bmess+='<li><b>comment </b> optional comment for this entry. <tt>false</tt> on asset lines';
   bmess+='<li><b> addedDate</b> Date added to portfolio';
   bmess+='<li><b>modifiedDate </b> Date of most recenet modifcation. empty if never modified';
   bmess+='<li><b> addedDatePrice</b> price when added to portfolio';
   bmess+='<li><b>addedDateCost </b> cost when added to portfolio';
   bmess+='</ul>';

   bmess+='<p>Totals  (summary) variables</b><p> ';

   bmess+='<ul class="boxList">';
   bmess+='<li><b>origBudget </b> budget of the initization entry. For modification entries, <tt>mod</tt>';
   bmess+='<li><b>totAssetSale </b> Total value if all assets sold';
   bmess+='<li><b>totAssetSaleNet </b> Total value net of loan repayments';
   bmess+='<li><b>totAssetSaleNetAT </b> Total value net of loan repayments, and after taxes (deferred taxes and capital gains)';
   bmess+='<li><b>totStock </b> Total value of stocks';
   bmess+='<li><b> totStockAT</b> Total value of stocks, after taxes (capital gains)';
   bmess+='<li><b>totRegular </b> total value of regular bonds ';
   bmess+='<li><b>totRegularAT </b> total value of regular bonds, after taxes. Should be same as totRegular. Note that taxes on regular bonds are paid <em>daily</em> (as interest earning occurs )';
   bmess+='<li><b> totTaxDeferred</b> total value of tax-deferred bonds';
   bmess+='<li><b>totTaxDeferredAT </b> total value of tax-deferred bonds, after taxes';
   bmess+='<li><b>totProperty </b> total value of all properties ';
   bmess+='<li><b>totPropertyNet</b> total value of all properties, after paying off loans';
   bmess+='<li><b>totPropertyNetAT </b> total value of all properties, after paying off loans, and paying capital gains taxes';
   bmess+='<li><b>totCost </b> approximate total cost of assets (purchase and acquisition costs)';

   bmess+='<li><b>totAcqCost </b> acquisition costs (properties, income streams, annuities, and oneOffs';
   bmess+='<li><b> totPurchaseCost</b> purchase costs (stocks and bonds) ';
   bmess+='<li><b> totCapGains</b> total capital gains (stocks and properties)';
   bmess+='<li><b>totCapGainsTaxable </b> taxable portion of capital gains (non-taxed capital gains removed)';
   bmess+='<li><b>totTaxOnLiquidation </b> total capital gains  taxes + tax defered ';
   bmess+='<li><b> totLoanPayYear</b> total loan payments ';
   bmess+='<li><b>totLoanOriginal </b> total original loands';
   bmess+='<li><b>totLoanOwed </b> total amount still owed on loans';

   bmess+='<li><b>totBasis </b> total basis (stocks and properties)';
   bmess+='<li><b>totYearlyNetRent </b> yearly net rents received (from properties)';
   bmess+='<li><b> totYearlyNetRentAT</b> net rents received , after taxes (from properties)';
   bmess+='<li><b>totYearlyIncome </b> Total yearly income (from income streams)';
   bmess+='<li><b>totYearlyIncomeAT </b> Total yearly income, after tax (from income streams)';
   bmess+='<li><b>totYearlyAnnuity </b>  Total yearly income (from annuities';
   bmess+='<li><b> totYearlyAnnuityAT</b> Total yearly income, after tax (from annuities';
   bmess+='<li><b>totYearlyRevenue </b> Total revenue: income + annuites + rent ';
   bmess+='<li><b>totYearlyRevenueAT </b> Total revenue, after taxes income + annuites + rent ';
   bmess+='<li><b>totYearlyExpense </b> Total yearly expense (from income streams)';
   bmess+='<li><b>totYearlyExpenseAT </b> Total yearly expense, after account for impacts on taxable income (from expense streams)';

   bmess+='<li><b>nAsset </b> number of assets (not including incomes, annuities, and oneOffs)';
   bmess+='<li><b>nStock</b> number of stocks ';
   bmess+='<li><b>nBond</b> number of bonds (regular and tax-deferred)';
   bmess+='<li><b>nRegular </b> number or regular bonds ';
   bmess+='<li><b>nTaxDefer </b> number of tax-deferred bonds ';
   bmess+='<li><b>nProperty </b> number of properties ';
   bmess+='<li><b>nIncome </b> number of incomeSteams + annuities ';
   bmess+='<li><b> nLoan</b> number of loans';
   bmess+='<li><b>nIncomeStream </b> number of income streams';
   bmess+='<li><b>nExpense </b> number of expense streams';
   bmess+='<li><b>nAnnuity </b> number of annuities';
   bmess+='<li><b>nOneOff </b> number of oneOffs';

  bmess+='</ul>';

  bmess+='</div>';


  displayStatusMessage(bmess);
  toggleStatusDiv(0,0);

  if (ido==3) {   // auto open archive menu
     window.setTimeout(function() {
         doExportImport_export(0);
     },200);
  }


}


//===========
// preview (either assets or portfolios
function doExport_menuPreview(athis) {
  let ethis=wsurvey.argJquery(athis) ;
  let awhat=ethis.attr('data-show');


  let dd;
  if (awhat=='assets') {
       dd= $('#doExportImport_assetResults').data('dVals');
//      dd=doExportImport_assets(1);
  }
  if (awhat=='portfolios') {
      dd= $('#doExportImport_portfolioResults').data('dVals') ;
//      dd=doExportImport_portfolios(1);
  }

  if (awhat=='portfolioSummary') {
      dd= $('#doExportImport_viewResults_results').data('dVals') ;
}

// clean up
/*
   let stuff={};
    let varRow=dd[0];
    for (let ii=1;ii<dd.length;ii++)  {
       stuff[ii]={};
       for (let jj=0;jj<varRow.length;jj++) {
           let  vname=varRow[jj];
           let kk=vname.indexOf(simInvParams['headerSep']);
           if (kk>-1) {
              let kk2=vname.split(simInvParams['headerSep']);
              let a1=jQuery.trim(kk2[0]);
              if (!stuff[ii].hasOwnProperty(a1)) stuff[ii][a1]={};
              let a2=jQuery.trim(kk2[1]);
              stuff[ii][a1][a2]=dd[ii][jj];
           } else {
              stuff[ii][vname]=dd[ii][jj];
           }
       }
    }
   */

  if (awhat=='assets') {
      showDebug(dd,'Asset info (to be exported as CSV)',11);
  } else if (awhat=='') {
      showDebug(dd,'Portfolio summary info (to be exported as CSV)',11);
  } else {
      showDebug(dd,'Portfolio info (to be exported as CSV )',11);
  }

}

//==============================
// export csv file, with all asset  data, -- write to text area, so user and copy and paste it.
function doExportImport_assets(getIt0,athis) {

 if (arguments.length<1) getIt0=0;
 let getIt=false;
 if (getIt0==1) getIt=true;

// toggle view of asset csv?
  if (getIt0==0 && arguments.length>1) {
    let ethis=wsurvey.argJquery(athis)
    let ison=ethis.attr('data-ison');
    if (ison==1) {
        ethis.attr('data-ison',0);
        $('#doExportImport_assetResultsOuter').hide() ;
        ethis.removeClass('chighlightExportStuff');
        return 1;
    }
    ethis.attr('data-ison',1);
    ethis.addClass('chighlightExportStuff');
  }

 let cfoo=$('.cdoExportImport_status');
 cfoo.hide();

// create assetValuesCum_byDate global (they may already exist)
  let assetLookupDates=makeAssetValues_useDates(1);
  calcAssetValues_all(assetLookupDates );   // populate the assetValues_byDate global
  makeAssetDetails_histCum(1);               // assetDetailsCum  global

 let vdata=simInvDsets['assetDetailsCum']['assets'];
 let vassets={};

 let dvars=['type','nEntries','firstEntry','lastEntry','earningsTaxRate'];

 let allVars={} ;

 for (let zasset in  vdata) {
     vassets[zasset]={};

     for (let adate in  vdata[zasset]['list']) {
        vassets[zasset][adate]={};

        for (let ii=0;ii<dvars.length;ii++) {
          let advar=dvars[ii];
          vassets[zasset][adate][advar]=vdata[zasset][advar];
        }
        vassets[zasset][adate]['dateSay']=setEntryDate(adate).sayDate ;
        vassets[zasset][adate]['nExisting']=0 ;

        let cvars=[];
        for (let zvar  in vdata[zasset]['currentVars']) cvars.push(zvar);
        vassets[zasset][adate]['currentVars']=cvars.join(' ');

        let cumvars=[];
        for (let zvar  in vdata[zasset]['cumVars']) cumvars.push(zvar);
        vassets[zasset][adate]['cumVars']=cumvars.join(' ');

        let nexist=0,ndates=0;

        for (let zooa in  vdata[zasset]['dates']) ndates++;
        for (let zooa in  vdata[zasset]['existing']) nexist++;
         vassets[zasset][adate]['nEntries']=ndates;
         vassets[zasset][adate]['nExisting']=nexist;

        let acpi=calcInflation(adate,adate,2);
        vassets[zasset][adate]['cpi']=acpi ;

        for (let raa in vdata[zasset]['list'][adate]) {
           allVars[raa]=1;
           vassets[zasset][adate][raa]=vdata[zasset]['list'][adate][raa] ;
        }

     }
 }
 let alevels=['asset','date'];
 let headerSep=simInvParams['headerSep']
 let acsv=objectToCsv(vassets,alevels,headerSep,',','','',false) ;

  let ecomment=$('#doExportImport_assets_comment');
  let hdr=jQuery.trim(ecomment.val());

  let outit=acsv.join('\n');
  outit=outit+'\n\n'+hdr;
  outit+='\n';
 $('#doExportImport_assetResultsOuter').show();
 $('#doExportImport_assetResults').html(outit) ;
  $('#doExportImport_assetResults').data('dVals',vassets);




 return 1;
}

//=========================
// export csv file, with summary stats from all "displayed" scenarios
function doExportImport_summaryStats(ifoo) {

// -- summary of Display results  (all scenarios, inflation adjusted
  let ishow=simInvSummaryResults['ngot'] ;

  let bmess='';
  bmess+='<div id="doExportImport_summaryStatsOuter"   style="border:2px solid purple;background-color:#fafbfc;margin:3px 4em"> ';

  bmess+='<input type="button" value="&#8617;&#65039;" title="Return to export menu" onClick="doExport_menu(this)" >';
  bmess+='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#doExportImport_summaryStats_help1">?</button>  ';

  bmess+='<b>Save scenario summaries</b>   ';
  bmess+='<span style="margin:3px 2em;font-style:oblique">From '+ishow+' displayed scenarios!</span> ';

   bmess+='After selecting scenarios, portfolios, and summary stats --   ';
   bmess+='  <input type="button" class="csaveButton" value="save as CSV" onclick="doExportImport_summaryStats_pickGo(this)">';

   bmess+='<div  id="doExportImport_summaryStats_inner" class="cstatusMessage_message doExportImport_summaryStats_c1">';

// choose scenarios to display
   bmess+='<div  class="doExportImport_summaryStats_c1"  style="overflow:auto;max-height:7em;border:2px solid gold;padding:4px;margin:8px">';
   bmess+='<input type="button" value="&forall;" title="Select all scenarios"   onclick="doExportImport_summaryStats_pick2(1,0)">  ';
   bmess+='<input type="button" value="&empty;" title="De-Select all scenarios" onclick="doExportImport_summaryStats_pick2(0,0)">    ';
   bmess+=' <em>Select scenarios  (<tt>0</tt> means <tt>no scenario selected </em>)';
   bmess+='<ul id="doExportImport_summaryStats_list" class="linearMenu17PctHigh">';
   for (let astate in simInvSummaryResults['cache'] ) {
      bmess+='<li> <label title="Display this set-of-results"><input type="checkbox" checked="" name="chooseThis" data-name="'+astate+'">'+astate+'</label> ';
   }
   bmess+='</ul> ';
   bmess+='</div> ';


// choose portfolios to display
   bmess+='<div  class="doExportImport_summaryStats_c1"  style="overflow:auto;max-height:7em;border:2px solid brown;padding:4px;margin:8px">';
   bmess+='<input type="button" value="&forall;" title="Select all portfolios"   onclick="doExportImport_summaryStats_pick2(1,1)">  ';
   bmess+='<input type="button" value="&empty;" title="De-Select all portfolios" onclick="doExportImport_summaryStats_pick2(0,1)">    ';
   bmess+=' <em>Select portfolios</em>';
    bmess+='<ul id="doExportImport_summaryStats_portfolios" class="linearMenu17PctHigh">';
   for (let ip=0;ip<portfolioList.length;ip++) {
       aport=portfolioList[ip];
       if (aport['isHidden']==1) continue;
       let pname=aport['name'];
       let adesc=aport['desc'];
       bmess+='<li> <label title="Display this portfolio\n'+adesc+'"><input type="checkbox" checked="" name="chooseThis" data-name="'+pname+'">'+pname+'</label> ';
   }
   bmess+='</ul> ';
   bmess+='</div> ';

// choose summary stat vars  to display
    let coreVars={'0':1,'1':1,'2':1};          // date,scenario, portfolio
    let base2Vars={'4':1,'totPortfolioValue':1}        ;      // cpiNow totportofliovalue
    let base7Vars={'3':1,'4':1 ,
               'totPortfolioValue':1,'cashAsset':1, 'totAssetSaleNetAT':1, 'totYearlyRevenueAT':1, 'totYearlyExpenseAT':1,
               'totOneOffReceipt_received':1} ;

   bmess+='<div style="overflow:auto;max-height:10em;border:2px solid tan;padding:4px;margin:8px">';
//   bmess+=' <input type="button" value="details..." title="Description of summary statistics variables" onclick="displayHelpMessage(this,0,1)" data-div="#exportResultsHelp1_summary">';
   bmess+='<a target="varlist" class="csaveButtonSmall" href="scenarioSummary_varList.txt"  title="Description of summary statistics variables" >details... </a> ';
   bmess+='<input type="button" value="&forall;" title="Select all summary stat variables"   onclick="doExportImport_summaryStats_pick2(1,2)">  ';
   bmess+='<input type="button" value="&empty;" title="De-Select all summary stat variables" onclick="doExportImport_summaryStats_pick2(0,2)">    ';
   bmess+='<input type="button" value="&#50;&#65039;&#8419;" title="Select: totPortofolio value and CPI" onclick="doExportImport_summaryStats_pick2(2,2)">    ';
   bmess+='<input type="button" value="&#56;&#65039;&#8419;"  onclick="doExportImport_summaryStats_pick2(3,2)" ';
   bmess+='  title="Select: dateSay, cpi_yy-mm-dd, cpi, totPortfolioValue, cashAsset, totAssetSaleNetAT, totYearlyRevenueAT, totYearlyExpenseAT, totOneOffReceipt_received," >    ';
   bmess+=' <em>Select summary variables</em>';
    bmess+='<ul id="doExportImport_summaryStats_vars" class="linearMenu19PctHigh">';
    let vv2=['date','scenario','portfolio','dateSay','cpiNow','CPI'];
    for (ivx=0 ; ivx<simInvSummaryResults['vars'].length;ivx++)  vv2.push(simInvSummaryResults['vars'][ivx]);
   for (let ivv=0;ivv<vv2.length;ivv++) {
       let varname=vv2[ivv];
       let isReadonly= (coreVars.hasOwnProperty(ivv)) ? ' disabled  ' : '  ';  // date scenario and portoflio are required
       dbasic2= (base2Vars.hasOwnProperty(ivv)  || base2Vars.hasOwnProperty(varname) ) ? '1' : '0' ;
       dbasic7= (base7Vars.hasOwnProperty(ivv) || base7Vars.hasOwnProperty(varname) )  ? '1' : '0' ;

       bmess+='<li> <label title="Display this summary statistic"> ';
       bmess+='<input type="checkbox" checked=""  '+isReadonly ;
       bmess+= ' name="chooseThis" data-name="'+varname+'"  data-index="'+ivv+'" data-basic="'+dbasic2+'" data-basicplus="'+dbasic7+'">'+varname+'</label> ';
   }
   bmess+='</ul> ';
   bmess+='<p>';
   bmess+='</div> ';

// reminder ...
  bmess+='<div class="doExportImport_summaryStats_c1" style="border-top:1px solid darkblue;padding:3px;">';
  bmess+='Reminder: you can change scenarios (or enable/disable inflation adjustment), and ';
       bmess+='<button disabled title="Not this button, the one on the main menu!" class="cdoButtonRegularBig"  "  name="doDisplayButton">&#128176; Display </button> ';
   bmess+=' to save a summary of the <em>scenario</em>';
   bmess+='</div>';

   bmess+='</div> ';  //  doExportImport_summaryStats_inner

// write csv to div inside of here

   bmess+='<div id="doExportImport_summaryStats_csv_outer">  ';

   bmess+='<div id="doExportImport_summaryStats_csv_opts" style="display:none">  ';
     bmess+=' <a href="scenarioSummary_varList.txt" target="varlist" class="csaveButtonSmall" title="Description of scenarioSummary variables">Details ... </a> ';
     
//    bmess+='&nbsp;<label style="border:1px dotted tan" title="One row per date -- sets of columns for each scenario/portofolio">';
    bmess+='<button data-on="0"  onClick="doExportImport_summaryStats_consolidate(this)" ';
    bmess+='    id="doExportImport_summaryStats_consolidate" title="consolidate: one row per date (scenarios and portoflios are in sets of columns" >Consolidate?</button> ';

     bmess+='<button onClick="doExportImport_summaryStats_preview(this)" >preView ... </button> ';
     bmess+='<button onClick="simInv_div_Mark(this)" data-div="doExportImport_summaryStats_csv"  data-gotit="doExportImport_summaryStats_csv_optsCopied" >copy summaryStats CSV to the clipboard</button> ';

     bmess+='  <span style="font-size:100%;color:green;display:none" id="doExportImport_summaryStats_csv_optsCopied"    >';
     bmess+='Copied!! You can now paste the summaryStats CSV to a spreadsheet (or other) file</span>';
   bmess+='</div>';    //d oExportImport_summaryStats_csv_outer

   bmess+='<div id="doExportImport_summaryStats_csv"  ';
   bmess+='  style="white-space:pre;border:1px solid black;padding:3px;overflow:auto;max-width:80em;max-height:12em;font-family:monospace">';
   bmess+='</div>';     // doExportImport_summaryStats_csv

   bmess+='</div>';  // doExportImport_summaryStats_csv_outer


   bmess+='</div>';  //"doExportImport_summaryStatsOuter
   displayStatusMessage(bmess);
   toggleStatusMessage(0,3);


   return ;
}

//==================
// dipslay csv in Consolided format
function doExportImport_summaryStats_consolidate(athis) {
 let ethis=wsurvey.argJquery(athis);
 let isCons=parseInt(ethis.attr('data-on'));

  let hsep=simInvParams['headerSep'] ;
  hsep='$';
 let allData= $('#doExportImport_summaryStats_csv').data('allData' );
 
  let newAll={};
  let varnames=allData[0];
  let c3s={'cpiNow':1,'CPI':1,'dateSay':1};
  let cuse=[],istart;
  for (let ijj=2;ijj<7;ijj++) {
    let vv1=varnames[ijj];
    if (c3s.hasOwnProperty(vv1)) {
       cuse.push(vv1)
    } else {
       istart=ijj;
       break;
    }
 }
  let wasDate=false;
  let rnew={},aportfolio,ascenario,adate;
  for (let ij=1;ij<allData.length;ij++) {
    let vv=allData[ij];     // data row
      adate=vv[0] ;
      ascenario=vv[1] ;
      aportfolio=vv[2];

    if (wasDate===false || wasDate!==adate) {
       if (wasDate!==false) {
          if (!newAll.hasOwnProperty(wasDate)) newAll[wasDate]={};
          for (let arf in rnew) newAll[wasDate][arf]=rnew[arf];
       }
       wasDate=adate ;
       rnew={} ;
       for (let ik=0;ik<cuse.length;ik++) {
           let ccvar=cuse[ik];
           rnew[ccvar]=vv[3+ik];
       }
    }
    for (let ij2=istart;ij2<vv.length;ij2++) {
        let aval=vv[ij2];
        let vname=ascenario+hsep+aportfolio+hsep+varnames[ij2];
        vname=vname.replace(/[\"]/g,'');
        vname=vname.replace(/[\s]/g,'_');
        rnew[vname]=aval
    }
  }
  if (wasDate!==false) {
     if (!newAll.hasOwnProperty(wasDate)) newAll[wasDate]={};
     for (let arf in rnew) newAll[wasDate][arf]=rnew[arf];
  }

 let alevels=['date'];
 let headerSep='_' ;
 let acsv=objectToCsv(newAll,alevels,headerSep,',','','',false) ;
 
 let scsv=acsv.join('\n');
 $('#doExportImport_summaryStats_csv').text(scsv);
  let isCons1=1-isCons ;
  ethis.attr('data-on',isCons1);

}

//===========
function doExportImport_summaryStats_preview(athis) {

     let allData= $('#doExportImport_summaryStats_csv').data('allData' );
     showDebug(allData,'Preview of summaryStats data (to be saved)',11);

}

//===========
// ido: 0/1 , 0 dselect all, 1 selectall
// iwhich: 0 : scenarios, 1:portofliols, summary stat variables
function doExportImport_summaryStats_pick2(ido,iwhich) {
  let elist;
  if (iwhich==0) {
     elist=$('#doExportImport_summaryStats_list');
  } else if (iwhich==1){
     elist=$('#doExportImport_summaryStats_portfolios');
  } else    {
     elist=$('#doExportImport_summaryStats_vars');
  }

   let echose=elist.find('[name="chooseThis"]')  ;

   if (ido!==false) {
      for (let iee=0;iee<echose.length;iee++) {
         let aee=$(echose[iee]);
         if (aee.prop('disabled')==false) {  // dont change readonlies
            if (ido!=1) {
               aee.prop('checked',false);
            } else   {              // dselect
               aee.prop('checked',true);
            }
            if (ido==2 )  {       // variables: select "basic" variables
              let isBase2=aee.attr('data-basic');
              if (isBase2==1) aee.prop('checked',true);
           }
            if (ido==3 )  {       // variables: select "basePlus" variables
              let isBase7=aee.attr('data-basicplus');
              if (isBase7==1) aee.prop('checked',true);
           }


         }  // add
      }    // iee
      return 1;
   }   // ido!=false

   let gots=[];
   for (let ii=0;ii<echose.length;ii++) {
      ae1=$(echose[ii]);
      if (ae1.prop('checked')) {
         let ado=ae1.attr('data-name');
         gots.push(ado);
      }
   }

}

//====================
// display the scenario summaries
function doExportImport_summaryStats_pickGo(ifoo) {

   let elist=$('#doExportImport_summaryStats_list');
   let echose=elist.find('[name="chooseThis"]') ;
   let scenList={},portList={},varList=[];

   for (let ii=0;ii<echose.length;ii++) {
      ae1=$(echose[ii]);
      if (ae1.prop('checked')) {
         let ado=ae1.attr('data-name');
         scenList[ado]=1;
      }
   }

   elist=$('#doExportImport_summaryStats_portfolios');
    echose=elist.find('[name="chooseThis"]') ;
   for (let ii=0;ii<echose.length;ii++) {
      ae1=$(echose[ii]);
      if (ae1.prop('checked')) {
         let ado=ae1.attr('data-name');
         portList[ado]=1;
      }
   }

   elist=$('#doExportImport_summaryStats_vars');
   echose=elist.find('[name="chooseThis"]') ;
   for (let ii=0;ii<echose.length;ii++) {
      ae1=$(echose[ii]);
      if (ae1.prop('checked')) {
         let adoV=ae1.attr('data-name');
         varList.push(adoV);
       }
   }

    let varHash={};
    let varHashList=[];
    let dateRows={},dateRowsList=[];

   let all1=[];
   let hdr1=[],qhdr=true;

   for (let zas in simInvSummaryResults['cache']) {
      if (!scenList.hasOwnProperty(zas)) continue   ; // this set is NOT a chosen displayed-scenario
      let do1=simInvSummaryResults['cache'][zas];
      for (let useDate in do1) {
         let ado1=do1[useDate];
         let CPI=ado1['CPI'];
         let amult=ado1['infMult'];
         let adata=ado1['data'];
         for (let pname in adata) {


           if (!portList.hasOwnProperty(pname)) continue ;  // this row is NOT from a chosen poorfolio
           if (!adata.hasOwnProperty(pname) || typeof(adata[pname])=='undefined' || adata[pname]===false) continue ;     // too soon for this portfolio?

           let adata2=adata[pname];

           let vline=[],oline={};
           let ivv0=0 ;            
           
           for (let ivv=ivv0;ivv<varList.length;ivv++) {    //
              let av1Name=varList[ivv];

              if (av1Name=='scenario') {
                 val1='"'+zas+'"';     // fill in scenario
              } else if (av1Name=='date') {
                  val1=parseInt(useDate)
              } else if (av1Name=='dateSay') {
                  val1='"'+setEntryDate(useDate).sayDate+'"' ;
              } else if (av1Name=='portfolio') {
                   val1='"'+pname+'"';
              } else if (av1Name=='cpiNow') {
                  val1=amult ;
              } else if (av1Name=='CPI') {
                  val1=CPI
              } else {
                   val1= (adata2.hasOwnProperty(av1Name)) ? adata2[av1Name] : 'na' ;
                   if (Array.isArray(val1)) {
                       let vtmp=val1.join(',');
                       val1='"'+vtmp+'"';
                   }
              }
              vline.push(val1);
              if (qhdr) hdr1.push('"'+av1Name+'"');

           }           // all vars in this row ...
           if (qhdr) all1.push(hdr1);  // first row examined ... than write the varnames (as the header line)
           qhdr=false;                // only do this once
            all1.push(vline);


         }          //  all portoflolis on this date
      }           // all scenarios
   }     // all dates
// have the values in a ready to csvify object (either consolidated-on-one-row or on-many-rows

   let abigs=[],bigCsv;

   $('#doExportImport_summaryStats_csv').data('allData',all1);

   bigCsv=all1.join('\n');         // all quotes are dealt with above!



  let e1=$('#doExportImport_summaryStats_inner');
  e1.hide();

   $('#doExportImport_summaryStats_csv_opts').show();
   $('#doExportImport_summaryStats_csv').text(bigCsv);

}  // consoli


//=========
// valuie for output
function doExportImport_valueSay(avalue,adef,amult) {
   if (arguments.length<3) amult=1.0;
   if (arguments.length<2) adef='';
   if (typeof(avalue)=='undefined') return adef ;
   if (avalue===null) return adef;
   if (avalue===false) return adef ;

   if (jQuery.isArray(avalue))  {       // an array -- return a space delimited list of its values
      let avalue2=avalue.join(' ');
      return avalue2;
   }

   if (jQuery.isPlainObject(avalue))  {       // an object -- return a space delimited list of its primary properties (not its values)
      let astuff=[];
      for (let aa1 in avalue  ) {
         astuff.push(aa1)
      }
      avalue2=astuff.join(' ');
      return avalue2;
   }

// not an object or array  -- if numeric, scale using imult

  let avalueX,avalueZ ;
  if (jQuery.isNumeric(avalue)) {
      avalueX=parseFloat(avalue)/amult ;
      let ivalue=parseInt(avalueX);   // amult is usually an inflation adjustment

      if (ivalue!==avalueX) {      // not an integer
           avalueZ=avalueX.toFixed(2);      // 2 decimal digits accuracy
      } else {
         avalueZ=ivalue;    // the integer value
      }
   } else {
       avalueZ=fixString(avalue,2);    // strip extraneous spaces
       avalueZ=jQuery.trim(avalueZ);
    }
    return avalueZ;

}

//=====================
// export current data -- same format as when saving  local data
function doExportImport_export(ifoo) {
  let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
  let nowTime=wsurvey.get_currentTime(0)
  let nowTimeSay=wsurvey.get_currentTime(31,1,nowTime)

  let eoink=$('#idoExportImport_export0');
  if (eoink.length>0) {
    if (eoink.is(':visible')) {
       eoink.hide();
       return 1;
    }
  }

// settings, cpiuSeries, and viewDates are NOT exported

   let exportData={'date':nowTime,'dateSay':nowTimeSay,'userName':userName,'content':simInvDsets['allCurrentData'],'exportDate':nowTime} ;

    let nportfolios=simInvDsets['allCurrentData']['portfolios']['data'].length;
    let nassets=simInvDsets['allCurrentData']['assets']['data'].length;
    let fnameSuggest='simInv_'+userName+'_'+nowTime+'.txt' ;

    let arfData=JSON.stringify(exportData);
    let amess='';
    amess+='<div id="idoExportImport_export0">';

    amess+='<div style="font-size:110%;margin:5px;"   > ';

    amess+='simInv <b>export</b> data: for <u>'+userName+'</u> (on '+nowTimeSay+') has '+nassets+' assets and '+nportfolios+' portfolios.';
    amess+=' To save this data to a file: you can <em>copy &amp; paste it directly to a local file</em> ';
    if (!qLocal) amess+=' <u>or</u>   <em> download (via the server) to a file</em> ';
    amess+='</div>';


    if (!qLocal) {
       amess+='<div style="border:1px dotted purple;margin-bottom:0.5em">';
       amess+='&#128073;<em>download (via the server) to a file </em><br> ';

       amess+='<div style="margin-left:2em">';
       amess+='Enter a suggested name: <input type="text" size="25" title="Specify a name (it will be the default name used by the browser) " id="iExportImport_fname" value="'+fnameSuggest+'"> ';
       amess+='<br> and then ... ';
       amess+='<input type="button" value="Download (to a file)" title="The browser might ask you where to save this file (and use the suggested name as the default) .." onClick="doExportImport_export_online(this)">';
       amess+='</div>';
       amess+='</div>';
    }

    amess+='<div style="border:1px dotted green">';
    if (!qLocal) {
       amess+='&#128073; <b>or</b> ... <em>copy &amp; paste it directly to a local file</em> ';
    } else {
       amess+='&#128073;   <em>copy &amp; paste it directly to a local file</em> ';
    }
    amess+='<div id="idoExportImport_export_hint" style="display:none;margin:3px 4em; font-size:90%;background-color:#d4f4f8;padding:3px 5px">';
       amess+='<br><input type="button" value="x" title="close this hint" onClick="$(\'#idoExportImport_export_hint\').hide()"> ';
       amess+='Windows hint (how to copy and paste to a file): ';
       amess+='<ul class="linearMenuHint">';
       amess+='<li> <button style="font-size:90%">Copy the exported information</button>';
       amess+='<li> open a file using <tt>Notepad</tt> (or some other text editor),   ';
       amess+='<li> click anywhere in the text entry window,' ;
       amess+='<li><tt>ctrl-C</tt> to copy it!  ';
       amess+='</ul>';
    amess+='</div> ';


    amess+='<table width="95%" cellpadding="5">';
    amess+='<td width="50%"><ul style="list-style-type: lower-alpha;">';
    
   let qpaste=false;
   let qpaste0=typeof(navigator.clipboard );
   if (qpaste0!=='undefined') {
     qpaste=typeof(navigator.clipboard.readText);
   }
   if (qpaste=='function') {
      amess+='<li><button onClick="doExportImport_export_copy(this)" class="cdoButtonRegular"> ';
      amess+=' Copy the exported simInv data ';
      amess+='</button> (to your clipboard)';
   } else {
      amess+='<li><button onClick="wsurvey.selectText(\'#doexportImport_export_results_string\',\'MARK\')" class="cdoButtonRegular">Mark</button> ';
      amess+='   the contents of preview box     '//doexportImport_export_results_string simInv data ';
   }

//&#9835;
    let osx=operatingSytem();
    if (osx=='Windows')  amess+='<input type="button" value="&#9835;" title="hints on copy an paste" onClick="$(\'#idoExportImport_export_hint\').toggle()" > ';

    amess+=' <span id="doexportImport_export_results_copied"  ';
    amess+=   ' title="export information can now be pasted!" style="color:green;display:none">Copied!';
    amess+='</span>  ';
    amess+='<li>  Cut &amp; paste it to a <u>text</u> file on your computer';
    amess+='<br><em>For example:</em> create/paste/save <tt>'+fnameSuggest+' </tt>  with windows Notepad editor';
    amess+='</ul>';
    amess+=' </td>';
    amess+='<td width="50%"> ';
    amess+='You can <button onclick="doexportImport_export_preview(this)" title="View this javaScript object in a new window">Preview</button> the exported simInv data?<br>';

    amess+='<div title="The export simInv data for user: '+userName+'" id="doexportImport_export_results_string" style="height:3em;width:20em;overflow:auto;background-color:gray;padding:1em">';
    amess+=arfData;
    amess+='</div>';

    amess+='</td>';
    amess+='</tr></table>';
    amess+='</div>';
    amess+='You can <button>import</button> this data at a later date -- don\'t forget where you saved your  text file &#9786;';

    amess+='</div>' ;      // idoexportImport_export0

    $('#doExportImport_menus').html(amess).show();

}

//==========
// display the to-be exported object 

function doexportImport_export_preview(athis) {
   let e1=$('#doexportImport_export_results_string');
   let astuff=e1.text();
   let vv=JSON.parse(astuff);
   let d2=vv['dateSay'];
   let uu=vv['userName'];
   showDebug(vv,'Previewing. simInv archivable data for: '+uu+' on '+d2,11);

   $('#doExportImport_local_export_next').hide();
}

//=====================
// echo the export file back using server echofile feature
function doExportImport_export_online(athis) {
  let e1=$('#doexportImport_export_results_string');
  let vv=jQuery.trim(e1.text());
  let e2=$('#iExportImport_fname');
  let fname=jQuery.trim(e2.val());
   wsurvey.submitQuickForm('phpLib/simInv2.php','post',{'todo':'echoFile','content':vv,'fname':fname},'export1') ;
   alert('Your browser will download a file using this name (that contains the simInv export data)  ...   ');
}

//====================
// import from a saved exported file on local computer
// that must be pasted into a texbox
// 29 nov 2023 : needs to be fixed to work with localMode
function doExportImport_import(athis) {

  let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
  let bmess='';

  let eoink=$('#idoExportImport_import0');
  if (eoink.length>0) {
      if (eoink.is(':visible')) {
         eoink.hide();
         return 1;
      }
  }
  bmess+='<div id="idoExportImport_import0">';

   let qpaste=false;
   let qpaste0=typeof(navigator.clipboard );
   if (qpaste0!=='undefined') {
     qpaste=typeof(navigator.clipboard.readText);
   }

  bmess+='<div style="font-family:sans-serif;margin:3px 4em;padding:3px 1em" >';
  bmess+='Due to javaScript security:  exporting  &amp; importing simInv data requires user actions. You will need to';
  bmess+=' copy data to (or from) a text file on your computer. It\'s not that hard!'
  bmess+='</div>';
  bmess+='<table width="95%">';
  bmess+='<tr><td width="20%"><em>Step 1:</em> Copy (to your browser clipboard) a simInv export file  (from a local file) and  ...</td>';


   bmess+='<td valign="top" width="35%"><em>Step 2:</em>';
   if (qpaste!=='function') {
     bmess+=' paste the contents to this textbox...</em> <br>';
   } else {
     bmess+=' <input type="button" value="paste"  onClick="pasteFromClipboard(this)" data-where="doExportImport_import_textarea">the contents to this textbox...</em> <br>';
   }
   bmess+='<textarea   style="border:4px dotted purple" title="Paste the simInv export data here!" id="doExportImport_import_textarea" nowrap rows="1" cols="40"></textarea>';
   bmess+='<br> <input type="button" value="reset" onClick="doExportImport_import_clear(this)">  ';
   bmess+' </span>';

  bmess+='<td width="35%"><button onClick="doExportImport_import_validate(this)"><em>Step 3:</em> Validate</button> the simInv export data';
  bmess+='<span id="doExportImport_import_check" title="Validated!" style="display:none">&#9989;  .. you can now <b>Overwtire</b> or <b>Add</b> </span>';
  bmess+='<div id="doExportImport_import_1" style="border-top:1px dashed gray;display:none">';
  bmess+='<div id="doExportImport_import_1b" style="font-size:90%;padding:2px"></div>';
  bmess+='</div> ';
  bmess+='</td>';

  bmess+='</tr>';
  bmess+='</table>';

  bmess+='<div id="doExportImport_import_2" style="border:1px dashed green;display:none">';
  bmess+='</div>';
  
  bmess+='</div>' ; // idoExportImport_import0
    $('#doExportImport_menus').html(bmess).show();


}

//=========
function doExportImport_import_clear(ifoo) {
   $('#doExportImport_import_textarea').val('');
   $('#doExportImport_import_1').hide();
   $('#doExportImport_import_check').hide();
   $('#doExportImport_import_2').hide();
   $('#idoExportImport_restore_preview').hide();

}

//==================
// validate the pasted export file
function doExportImport_import_validate(athis) {
 let e1=$('#doExportImport_import_textarea');
 let v1=e1.val();
 let vv;

  let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;

 $('#doExportImport_import_1').hide();
 $('#idoExportImport_import_preview').hide();
 $('#doExportImport_import_2').hide();
 $('#doExportImport_import_check').hide();

 try {
    vv=JSON.parse(v1);
} catch(err) {
  let bmess='Problem processing:\n  '+err ;
  alert(bmess) ;
  return 1;
}

 if (!vv.hasOwnProperty('exportDate') || !jQuery.isNumeric(vv['exportDate'])) {
    let bmess='This is not a simInv export file! ';
    bmess+='\nWould you like to view it (using a JSON viewer)? ';
     let q=confirm(bmess);
    if (!q) return 1;
    showDebug(vv,'Viewing JSON data');
    return 1;
 }
  let oof=setEntryDate(vv['exportDate']);
  let wasuser=vv['userName'];
  let bmess='simInv export file  created by <tt>'+wasuser+'/tt> on  <tt>'+oof.sayDate+'</tt>';
  let nassets=0,nportfolios=0;
  if (vv['content'].hasOwnProperty('assets')) nassets=vv['content']['assets']['data'].length;
  if (vv['content'].hasOwnProperty('portfolios') )    nportfolios=vv['content']['portfolios']['data'].length;
  bmess+='  <em>with</em> <tt>'+nassets+'</tt> assets, <tt>'+nportfolios+'</tt> portfolios ';

  bmess='<em>Step 4:</em> <ul class="boxList"> ';
  bmess+='<li><button class="cdoButton" onclick="doExportImport_import_go(0)" title="import (overwrite existing content)">Import</button>   ';
  bmess+='<span style="margin:3px 3em;border:1px dashed yellow;padding:3px">Caution: this will <b>overwrite</b> existing simInv data (for user <u>'+userName+'</u>)</span>';

  if (!qLocal) {
    bmess+='<li><button class="cdoButton" onclick="doExportImport_import_go(1)" title="add assets and portfolios to existing)">Add</button> Add assets and portfolios that are <u>not</u> specified for '+userName   ;
  }
  bmess+='</ul>';

  let fromUser=vv['userName'];
  let onDate=vv['dateSay'];
  let acomment=(vv.hasOwnProperty('comment')) ? vv['comment'] : ' ' ;
  let nassetsX=vv['content']['assets']['data'].length;
  let nportfoliosX=vv['content']['portfolios']['data'].length;
  let gmess='';
  gmess+='<input type="button"  onClick="doExportImport_import_preview(this)" value="Preview"> ';
  gmess+='Import from <tt>'+fromUser+'</tt> on <tt>'+onDate+'</tt>. With <tt>'+nassetsX+'</tt> assets and <tt>'+nportfoliosX+'</tt> portfolios.';
  gmess+='<br>'+acomment;


 $('#idoExportImport_import_preview').show();
 $('#doExportImport_import_1').show();
 $('#doExportImport_import_1b').html(gmess);
 $('#doExportImport_import_check').show();
 $('#doExportImport_import_2').html(bmess).show();
}

//=======
// preview validated "to be imported" data
function  doExportImport_import_preview(ifoo) {
   let e1=$('#doExportImport_import_textarea');
   let v1=e1.val();

   let vv=JSON.parse(v1);
   let d2=vv['dateSay'];
   let uu=vv['userName'];
   let arf=JSON.parse(JSON.stringify(vv['content']));
   delete arf['settings'];
   delete arf['cpiuSeries'];
   delete arf['viewDates'];

   showDebug(arf,'Previewing: simInv data to be imported. For: user <u>'+uu+'</u> on '+d2,11);

}


//=============
function doExportImport_viewResults_menu(athis) {

// --- using cache?  won't work... do caclutiatons
   if (simInvGlobals['cacheStuff']['usingCacheNow']===true ) {
     let time1=Date.now();
     simInvGlobals['cacheStuff']['cacheDisplayResults']='write';
     window.setTimeout(function() {         // wait a moment
         showAllPortfolioValuesStart(0,false,1);
         return 1;
      },20);
      return false ;
   }
  let ethis=wsurvey.argJquery(athis) ;
  let awhich=ethis.attr('data-which');

   let bmess='';
  let qLocal=simInvDsets['simInvLocalStorage']['enabled'] ;

   $('.cdoExportImport_status').hide();

  let assetList={},dateList={},portfolioList={};
  for (let adate in simInvDsets['viewDates_dataStore']) {
      if (!dateList.hasOwnProperty(adate)) dateList[adate]=0;
      dateList[adate]++;
      for (let aportfolio in simInvDsets['viewDates_dataStore'][adate]) {
          if (!portfolioList.hasOwnProperty(aportfolio)) portfolioList[aportfolio]=0;
          portfolioList[aportfolio]++;
          let alist= simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['entry']['assetList'];
          for (let ia=0;ia<alist.length;ia++) {
               let aaname=alist[ia];
               if (!assetList.hasOwnProperty(aaname)) assetList[aaname]=0;
               assetList[aaname]++;
          }
      }          // aportfolio
  }  // adate in ..
  let dlist=[],plist=[],alist=[];
  for (let adate in dateList) dlist.push(adate);
  dlist.sort(mySortNumeric);

  for (let pname in portfolioList) plist.push(pname);
  for (let aname in assetList) alist.push(aname);

  bmess+='<div>';
  bmess+='<button title="Tips: saving portfolio values "  onclick="displayHelpMessage(this)" data-div="#exportResultsHelp1">&#10068;</button> ';

  let ascenario=simInvParams['scenarioUse'];

  bmess+='The  <em>&#128176; portfolio values</em> table contains information on ';
  if (ascenario!='0' && ascenario!=='') bmess+= ' scenario <u>'+ascenario+'</u> ';
  bmess+='&hellip; ';
  bmess+='<button data-ison="0"  data-which="viewResults_menu_dates" onClick="doExportImport_viewResults_menu_hilite(this)"> '+dlist.length+' dates</button>, ';
  bmess+='with  <button  data-ison="0"  data-which="viewResults_menu_portfolios" onClick="doExportImport_viewResults_menu_hilite(this)">'+plist.length+' portfolios</button>, ';
  bmess+='that use <button  data-ison="0"  data-which="viewResults_menu_assets" onClick="doExportImport_viewResults_menu_hilite(this)">'+alist.length+' assets</button> ';

  bmess+='<span style="float:right;margin-right:2em;font-style:oblique"> ';
  bmess+='<button  title="View summaries of results (from '+simInvSummaryResults['ngot']+' scenarios) "  ';
  bmess+='      class="cdoButtonRegular" onclick="doExport_menu(this)"> &#128194; Archive </button>';
  bmess+='</span>';

  bmess+='</div>';
  bmess+='<br><input  value="&#119137;" data-ison="0"  data-which="viewResults_menu_notes"    ';
  bmess+='    onClick="doExportImport_viewResults_menu_hilite(this)" type="button"   title="Details..."> ';

  bmess+='You can create &amp; &Sscr;ave a CSV file containing (for each portfolio/date) : ';
  bmess+='<ul  id="idisplayResultsWhich" class="linearMenu20PctH">';

  let showValuesInterp=parseInt(simInvParams['showValuesInterp']);
  let aflag= (showValuesInterp==1) ? '&#9888;' : '' ;

  if (awhich=='summary') {
    bmess+='<li><div class="cdisplayResultsWhich2"> ';
    bmess+='<button  class="cdisplayResultsWhich" title="Portfolio summary variables (the variables displayed using \'Display \')" onClick="doExportImport_viewResults(this)" data-which="summary">summary stats</button> ';
     bmess+=' <a class="csaveButtonSmall" title="Descriptions of summaryStats variables" href="summary_varList.txt" target="varDesc">&#128462;</a> ';
     bmess+='</div>';
  } else {
    bmess+='<li><button class="cdisplayResultsWhich" title="Portfolio summary variables (the variables displayed using \'Display \')" onClick="doExportImport_viewResults(this)" data-which="summary">summary stats</button>';
    bmess+=' <a class="csaveButtonSmall" title="Descriptions of summaryStats variables" href="summary_varList.txt" target="varDesc">&#128462;</a> ';
  }


  if (awhich!=='details') {
      bmess+='<li>'+aflag+'<button class="cdisplayResultsWhich"  title="Assets: after growth and modification " onClick="doExportImport_viewResults(this)" data-which="assets">asset mix  </button>';
      bmess+=' <a class="csaveButtonSmall" title="Descriptions of assets variables" href="assetMix_varList.txt" target="varDesc">&#128462;</a> ';
      bmess+='<li>'+aflag+'<button class="cdisplayResultsWhich"  title="Assets: after growth, before modification " onClick="doExportImport_viewResults(this)" data-which="assetGrowth">asset mix: growth </button>';
      bmess+=' <a class="csaveButtonSmall" title="Descriptions of assetGrowth variables" href="assetMixGrowth_varList.txt" target="varDesc">&#128462;</a> ';
  } else {
      bmess+='<li><div class="cdisplayResultsWhich2">';
      bmess+=''+aflag+'<button class="cdisplayResultsWhich"  onClick="doExportImport_viewResults(this)" data-which="assets">asset mix  </button>';
      bmess+=' <a class="csaveButtonSmall" title="Descriptions of the portfolio asset mixes (over time)\n -- incorporating growth and modifications " href="assetMix_varList.txt" target="varDesc">&#128462;</a> ';
      bmess+='</div>';
      bmess+='<li><div class="cdisplayResultsWhich2">';
      bmess+=''+aflag+' <button class="cdisplayResultsWhich" onClick="doExportImport_viewResults(this)" data-which="assetGrowth">asset mix: growth </button>';
      bmess+=' <a class="csaveButtonSmall" title="Descriptions of the within-period growth of portfolio asset mixes (over time)  \n-- incorporating growth, and NOT incorporating modifications" href="assetMixGrowth_varList.txt" target="varDesc">&#128462;</a> ';
      bmess+='</div>';
  }
  bmess+='</ul>'

  if (showValuesInterp==1) {
     bmess+='<div style="background-color:#f8f7ac;"><em>&#9888; Interpolation</em> is being used! <tt>assets</tt> &amp; <tt>asset growth</tt> information is available <u>only</u> for portofolios whose <em>details</em> were displayed using <button>&#128366;</button></div>. ';
  }

// results displayed here
  bmess+='<div id="doExportImport_viewResults_results_outer" style="font-size:90%; display:none"> ';

   if (!qLocal) {      // server storage okay
     bmess+='<button id="doExportImport_viewResults_results_button" onClick="doExport_serverSave(this)" ';
     bmess+='    data-div="doExportImport_viewResults_results" data-what="results" title="save to local file (via the server)" >';
     bmess+='&#128193;</button>';
   }


   bmess+=' <button  id="iMenuPreview" onclick="doExport_menuPreview(this)" data-show="portfolioSummary">preView '+awhich+'</button> ';

   bmess+='<input type="button" value="Copy results to clipboard"  ';
   bmess+='   onClick="simInv_div_Mark(this)" data-div="doExportImport_viewResults_results" data-gotit="doExportImport_viewResults_resultsCopied" >  ';

    bmess+='Results for <span style="color:blue " id="doExportImport_viewResults_results_which"></span>';
    bmess+='<span style="display:none;margin-left:3em;color:green" class="cdoExportImport_status" id="doExportImport_viewResults_resultsCopied"   >';
    bmess+=' Results copied to clipboard! You can paste them into a text file or a spreadsheet.</span> ';

    bmess+='  <span style="font-size:100%;color:purple;display:none"    class="cdoExportImport_status"  id="doExportImport_resultsSaved_results"></span>  ';

    bmess+='<div class="cviewResults_results" id="doExportImport_viewResults_results" ></div>';
  bmess+='</div>';

  bmess+='<div id="viewResults_menu_notes" title="Notes" style="display:none;background-color:#dfcddf;padding:0.5em;border:1px solid lime">';
  bmess+='You can display results from the most-recently displayed <em>&#128176; portfolio values</em> table</em>.';
  bmess+='<br>Given the number of variables, export of results is divided into several <em>pieces</em>. ';
  bmess+='  Each of these <em>pieces</em> generates a CSV file that contains different variables. ';

  bmess+='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#exportResultsHelp1">details on CSV variables ...</button>  ';

  bmess+='<ul class="boxList2">';
  bmess+='<li><b> summary stats</b>: one row per date/portfolio. Includes: summary of current values, after growth summaries, after changes summmary';
  bmess+='<li><b> assetsMix:</b> one row for each asset in a date/portfolio -- the asset values after  modifications (and after growth). Includes: <tt>assetName</tt>, <tt>assetType</tt>, <tt>quantity</tt>, <tt>value</tt>, &hellip;';
  bmess+='<li><b>assetMixGrowth</b>: one row for each asset in a date/portfolio -- the asset values before modification (and after growth). Includes:  <tt>earningsPeriodAT</tt>, <tt>changeCashPeriod</tt>, <tt>additionPeriod</tt>, <tt>growthIncome</tt>, &hellip;';
  bmess+='</ul>';
  bmess+='After choosing, the CSV file is displayed in a text box. You can then copy the CSV file to your clipboad, and then paste it to a text file or a spreadsheet.';
  bmess+='<br>Note: the values saved to CSV files are <u>not</u> inflation adjusted';

  if (!qLocal==0) bmess+='<br>Or you directly save it to a local file (via the server)';
  bmess+='</div>';


  bmess+='<div id="viewResults_menu_dates" title="list of dates" style="display:none;font-size:90%;padding:0.5em;border:1px solid blue">';
  bmess+='<em>Dates ...</em>';
  bmess+='<ul class="linearMenu13Pct"><li>';
  let dlistuse=[];
  for (let idd=0;idd<dlist.length;idd++) {
      let idate=dlist[idd];
      let oof1=setEntryDate(idate);
      let dateSay=' <span style="float:right;margin-right:3px;font-size:85%">'+oof1.sayDate+'</span>';
      let foo1=idate+dateSay;
      dlistuse.push(foo1)
  }

  bmess+=dlistuse.join('<li>');
  bmess+='</ul>';
  bmess+='</div>';

  bmess+='<div id="viewResults_menu_portfolios" title="list of portfolios" style="display:none;font-size:90%;padding:0.5em;border:1px solid blue">';
  bmess+='<em>Portfolios ...</em>';
  bmess+='<ul class="linearMenu16Pct"><li>';
  let plistuse=[];
  for (let ip=0;ip<plist.length;ip++) {
     let apname=plist[ip];

     let nhist=portfolioLookup['list'][apname]['nHistory'];
     let sayCreate=portfolioLookup['list'][apname]['creationDateSay'];
     let foo='<b>'+apname+'</b> <span style="float:right;margin-right:0.5em" title="creation date w/ # of entries (init + mods)" style="font-size:80%">'+sayCreate+' w/ '+nhist+'</span>' ;
     plistuse.push(foo);
  }
  bmess+=plistuse.join('<li>');
  bmess+='</ul>';
  bmess+='</div>';

  bmess+='<div id="viewResults_menu_assets" title="list of assets" style="display:none;font-size:90%;padding:0.5em;border:1px solid blue">';
  bmess+='<em>Assets ...</em>';
   bmess+='<ul class="linearMenu13Pct"><li>';
   let alistUse=[];
   for (let im=0;im<alist.length;im++) {
      let  aaname=alist[im];
      let aicon=getAssetType(aaname,'iconSpan');
      if (aaname.substr(0,1)=='_') aaname='<span title="public asset">&Pscr; </span>'+aaname;
      let foo1=aicon+' '+aaname;
      alistUse.push(foo1);
   }
  bmess+=alistUse.join('<li>');
  bmess+='</ul>';
  bmess+='</div>';

  displayStatusMessage(bmess);
  toggleStatusDiv(0,0);
  return 1;
}

//======================
function doExportImport_viewResults_menu_hilite(athis) {
   let ethis=wsurvey.argJquery(athis);
  let ison=ethis.attr('data-ison');
   let awhich=ethis.attr('data-which');
   let e1=$('#'+awhich);
   if (ison==0) {
     e1.show();
     ethis.addClass('chighlightAssetButton');
   } else {
     ethis.removeClass('chighlightAssetButton');
     e1.hide();
   }
   ison=1-ison;
   ethis.attr('data-ison',ison);
   return 1 ;
}

// =====================
// view results. called by doExportImport_viewResults_menu
// choice of: summary totals, assetValues,    assetGrowthVars
// for assetVlaues and assetGrowthValues : multiple lines (one per row for each asset in a date/portfolio

function doExportImport_viewResults(athis) {

  let ethis=wsurvey.argJquery(athis);

  let e0=$('#idisplayResultsWhich');
  let eall=e0.find('.cdisplayResultsWhich');
  eall.removeClass('chighlightExportStuff');
  ethis.addClass('chighlightExportStuff');

  let ado=ethis.attr('data-which');

  $('#doExportImport_viewResults_resultsCopied').hide();

  let ebutton=$('#doExportImport_viewResults_results_button');

// display depends on ado

 if (ado=='summary')  {     // summary stats
   let bmess=doExportImport_viewResults_summary(1);
   $('#doExportImport_viewResults_results_outer').show();

   $('#doExportImport_viewResults_results').text(bmess) ;
   $('#doExportImport_viewResults_results').data('dVals',simInvDsets['showValues_summary1']) ;

   $('#doExportImport_viewResults_results_which').html('Summary stats ').show();
   ebutton.attr('data-what','resultsSummary');
   $('#iMenuPreview').show();
   return 1;
 }

   if (ado=='assets')  {
   let bmess=doExportImport_viewResults_assets(1);
   $('#doExportImport_viewResults_results_outer').show();
   $('#doExportImport_viewResults_results').text(bmess) ;
   $('#doExportImport_viewResults_results_which').html('Summary of asset-mix (after growth &amp; modification)').show();
   ebutton.attr('data-what','resultsAssets');
   $('#iMenuPreview').hide();
   return 1;
 }


 if (ado=='assetGrowth')  {     // summary stats
   let bmess=doExportImport_viewResults_assetGrowth(1);
   $('#doExportImport_viewResults_results_outer').show();
   $('#doExportImport_viewResults_results').text(bmess) ;
   $('#doExportImport_viewResults_results_which').html('Summary of assetMix-Growth (after growth, <u>before</u> modification)').show();
   ebutton.attr('data-what','resultsAssetGrowth');
   $('#iMenuPreview').hide();
   return 1;
 }
 alert('doExportImport_viewResults error!');
 return ' ';


}




//========
// summarystates for view results export
function doExportImport_viewResults_summary(ifoo) {

   let v1=['portfolio','dateStamp'];
   let dahides={},nhides=0 ;
   for (let app in portfolioLookup['list']) {
      if (portfolioLookup['list'][app]['isHidden']==1) {
          nhides++;
          dahides[app]=1  ;   // skip hidden portfolios
      }
   }
   if (nhides===0) dahides=false;

//(myData,alevels,headerSep,arraySep,defval,quoteRep,skip1) {
   let csvArray= objectToCsv(simInvDsets['showValues_summary1'],v1,simInvParams['headerSep'],',','',false,dahides);

   let oink=csvArray.join('\n');

    return oink;



}


//========
// assets in portfolio
function doExportImport_viewResults_assets(ifoo) {
   let useRows=[];
   let showVars=['date','portfolio','dateSay','theModEntry','dateMatch','assetName'   ];

// find asset vars
   let tvars={};

   for (let adate in simInvDsets['viewDates_dataStore']) {

      for (let aportfolio in simInvDsets['viewDates_dataStore'][adate]) {
        if (simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['dateMatch']===false) continue ; // no info for this portfolio on this date
        let alist=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['entry']['assets']  ;
        for (let basset in alist) {
           for (let avar in alist[basset]) {
              if (jQuery.isPlainObject(alist[basset][avar])) {                        // loanSchedule?
                   tvars[avar]={}  ;
                   for (let cvar in alist[basset][avar]) {
                      tvars[avar][cvar]=1 ;
                    }
              } else {      // not plainobject
                   if (!tvars.hasOwnProperty(avar)) tvars[avar]=1 ;     // prevent overwrite of "object"
              }  // plainobject
           }   // avar in basset
        }  // basset
     }   // aportfolio
   }    // adate

   let tlist=[];
   for (let tvar in tvars) {
     if (jQuery.isPlainObject(tvars[tvar])) {
        for (let cvar in tvars[tvar]) {
            let tvaruse=tvar+simInvParams['headerSep']+cvar ;
            showVars.push(tvaruse);
            let tt1=[tvar,cvar];
            tlist.push(tt1);
        }
     } else {
       showVars.push(tvar);
       tlist.push(tvar);
     }
   }

   let tlist2=showVars.join(', ');
   useRows.push(tlist2);

   for (let adate in simInvDsets['viewDates_dataStore']) {
      let oof3=setEntryDate(adate);
      let dateSay=oof3.sayDate ;
      for (let aportfolio in simInvDsets['viewDates_dataStore'][adate]) {
        if (simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['dateMatch']===false) continue ; // no info for this portfolio on this date
        let theModEntry=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['theModEntry'] ;    //same for all assets in this date/portfoil
        let dateMatch=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['dateMatch'] ;  //same for all assets in this date/portfoil

        let assets=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['entry']['assets']  ;

        for (let basset in assets) {
          let aline=[adate,aportfolio,dateSay,theModEntry,dateMatch,basset] ;  // be sure to include asset name!

           for (let  ik=0;ik<tlist.length;ik++) {     // to ensure col order does not change
             let avar=tlist[ik],aval;
             if (jQuery.isArray(avar)) {  // loanSchedule? --
                    let avar1=avar[0];
                    let  avar2=avar[1];
                    let aval0=assets[basset][avar1][avar2];
                    let aval=doExportImport_valueSay(aval0,'false');
                    aline.push(aval);
             } else {       // just a scalar
                let aval0=assets[basset][avar];
                let aval=doExportImport_valueSay(aval0,'false');
                aline.push(aval);
             }
          }

          let aline2=aline.join(', ');
          useRows.push(aline2);         // one row per asset (in a date/portfolio)
        }     // basset
      }   // aportfoolio
   }   // adate

   let outit=useRows.join('\n')+'\n';

   return  outit ;

}

//========
// assetGrowth in portfolio
function doExportImport_viewResults_assetGrowth(ifoo) {
   let useRows=[];
   let showVars=['date','portfolio','dateSay','theModEntry','dateMatch','assetName'   ];

// find asset vars
   let tvars={};
   for (let adate in simInvDsets['viewDates_dataStore']) {
      for (let aportfolio in simInvDsets['viewDates_dataStore'][adate]) {
        if (simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['dateMatch']===false) continue ; // no info for this portfolio on this date
        let alist=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['entry']['assetGrowths']  ;
        for (let basset in alist) {
           for (let avar in alist[basset]) {
              if (!tvars.hasOwnProperty(avar)) tvars[avar]=1;
           }
        }  // basset
     }   // aportfolio
   }    // adate
   let tlist=[];
   for (let tvar in tvars) {
     let tvaruse=(tvar!=='daysGap') ? tvar : 'growDays';
     showVars.push(tvaruse);
     tlist.push(tvar);
   }

   let tlist2=showVars.join(', ');
   useRows.push(tlist2);

   for (let adate in simInvDsets['viewDates_dataStore']) {
      let oof3=setEntryDate(adate);
      let dateSay=oof3.sayDate ;
      for (let aportfolio in simInvDsets['viewDates_dataStore'][adate]) {
        if (simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['dateMatch']===false) continue ; // no info for this portfolio on this date
        let theModEntry=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['theModEntry'] ;    //same for all assets in this date/portfoil
        let dateMatch=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['dateMatch'] ;  //same for all assets in this date/portfoil

        let assets=simInvDsets['viewDates_dataStore'][adate][aportfolio]['data']['entry']['assetGrowths']  ;

        for (let basset in assets) {
          let aline=[adate,aportfolio,dateSay,theModEntry,dateMatch,basset] ;  // be sure to include asset name!

           for (let  ik=0;ik<tlist.length;ik++) {     // to ensure col order does not change
             let avar=tlist[ik];
             let aval0=assets[basset][avar];
             let aval=doExportImport_valueSay(aval0,'false');
             aline.push(aval);
          }
          let aline2=aline.join(', ');
          useRows.push(aline2);         // one row per asset (in a date/portfolio)
        }     // basset
      }   // aportfolio
   }   // adate

   let outit=useRows.join('\n')+'\n';

   return outit ;

}

//========
// save contents of a text area to a file, using server
function doExport_serverSave(athis) {
   let ethis=wsurvey.argJquery(athis);
   let adiv=ethis.attr('data-div');
   let ediv=$('#'+adiv);
   if (ediv.length==0) {
      alert('doExport_serverSave error: no such id='+adiv);
      return 0;
   }
   let awhat=ethis.attr('data-what');

   let oof=setEntryDate(true);
   let nowDate=oof.sayDate;
   let dcount=oof.dayCount;
   let hdr=userName+'  on '+nowDate;

   let fname=awhat+'_'+userName+'_'+dcount+'.txt';

   let vv=jQuery.trim(ediv.text());

   wsurvey.submitQuickForm('phpLib/simInv2.php','post',{'todo':'echoFile','content':vv,'fname':fname},'export1') ;

   let eres1=$('#doExportImport_resultsSaved_'+awhat);
   if (eres1.length>0) eres1.html('Your browser will download a file (using a name of '+fname+') ...   ').show();
    return 1;

}

//================
// do the restoration!
// iadd:0 overwrite, 1:add (only in onLine mode)
function doExportImport_import_go(iadd) {
  let e1=$('#doExportImport_import_textarea');
  let v1=e1.val();
  let vv;
  let qLocal=simInvDsets['simInvLocalStorage']['enabled'] ;

// read the "import" data (from a textbox) ... make sure it is valid
  try {              // convert back to a js object
    vv=JSON.parse(v1);
  } catch(err) {
     let bmess='Problem processing:\n  '+err ;
     alert(bmess) ;
     return 1;
  }
  if (!vv.hasOwnProperty('exportDate') || !jQuery.isNumeric(vv['exportDate'])) {
    let bmess='This is not a simInv export file! ';
    alert(bmess);
    return 1;
 }
 if (iadd==0) {
   let q=confirm('Caution: this will REMOVE existing simInv data (for user `'+userName+'`)\n Are you sure?') ;
   if (!q) return 0;
 }

// create a js object with the imported data ... perhaps augmenting existing data
  let savemeDataX=doExportImport_import_go_doAdd(vv,iadd);  // if iadd=0, echos back vv. 1 : "adds" vv to allCurrentData

  if (iadd==1) {           // first view
     let dmess= savemeDataX[5];
     let dmess2='If the following is accepable ...';
     dmess2+='<button class="csaveButton""   onClick="doExportImport_import_go(2)">Import this data! </button><br>'+dmess;
     $('#doExportImport_checkAdd').html(dmess2).show();
     return 1;
  }
  let saveMeData1=savemeDataX[0];
  let nassetsRetain=savemeDataX[1],nassetsAdd=savemeDataX[2],nportfoliosRetain=savemeDataX[3],nportfoliosAdd=savemeDataX[4];

  let saveme={} ;
  saveme['userName']= userName;
  saveme['date']= wsurvey.get_currentTime(0)
  saveme['dateSay']=wsurvey.get_currentTime(31,1 ) ;
  saveme['keyMd5']=simInvGlobals['encryptionKey_md5'];
  if (iadd==0)   {
     saveme['comment']='overwrite import ';
  } else {
     saveme['comment']='add import ';
  }

// Convert  import data (perhaps that is augmenting existing data) to a form suitable for uploading to server (or to local storage)
// Note settings and viewdates and cpiUseries are NOT imported
  let daEncVars=['assets','assetHistory','portfolios','portfolioInit','portfolioModifications']    ;

  let dosaves=['assets','assetHistory','portfolios','portfolioInit','portfolioModifications'];

  let savemeData2={};
  let nowTime=wsurvey.get_currentTime(0);

  for (let idd=0;idd<dosaves.length;idd++) {
      let ado=dosaves[idd];
      let sdata,atime
      if (saveMeData1['content'][ado].hasOwnProperty('time') &&  saveMeData1['content'][ado]['time']===false) {
         atime=false;
         sdata=false;
      } else {
         atime=nowTime ;
         if (!qLocal) {
             if (simInvGlobals['encryptionKey']!=='') {
                sdata=simInvEncrypt(saveMeData1['content'][ado],simInvGlobals['encryptionKey']);
             } else {
                sdata=JSON.stringify(saveMeData1['content'][ado]) ;
             }
         } else {     // if local, no encryption and no need to stringify
             sdata=saveMeData1['content'][ado]

         }
      }
      savemeData2[ado]={'time':atime,'data':sdata};
   }

   saveme['content']=savemeData2 ;
   saveme['nassetsAdd']=nassetsAdd ;
   saveme['nPortfoliosAdd']=nportfoliosAdd  ;
   if (iadd==1) {
      saveme['nassetsRetain']=nassetsRetain  ;
      saveme['nportfoliosRetain']=nportfoliosRetain  ;
   } else {
      saveme['nassetsRetain']=false  ;
      saveme['nportfoliosRetain']=false  ;
   }


//  ....
// now save the data (which  could be a pure overwrite, or a constructed add)

   if (qLocal) {     // overwrite
        let dmess= doExportImport_import_go_local(saveme) ;
         let  cmess='Imported (for user name <u>'+userName+'</u> ';
         cmess+='<br>#assets added='+nassetsAdd+'. #portfolios  added='+nportfoliosAdd  ;
         displayResponseFromServer(cmess+dmess,1,1) ;
         return 1;
   }

// if here ...  online mode  .....
   let ddata2={};

   ddata2['todo']='restoreAll';
   ddata2['username']=userName;
   ddata2['data']= saveme ;
   ddata2['encMd5']=simInvGlobals['encryptionKey_md5'];

    $.ajax({
         url: 'phpLib/simInvRestore.php',
        type: 'POST',
        dataType: 'json',
        cache: false,
        data: ddata2
   }).always(function (response) {
     if (typeof(response)!=='string') {
        showDebug(response,'Import problem ',1);
        cmess='Problem importing data ';
     } else {
       cmess='Import results (for user name <u>'+userName+'</u>) : <hr>'+response ;
       if (iadd==1) {
         cmess+='<br>#assets retained='+nassetsRetain +', added='+nassetsAdd+'. #portfolios retained='+nportfoliosRetain +', added='+nportfoliosAdd  ;
       } else {
         cmess+='<br>#assets added='+nassetsAdd+'. #portfolios  added='+nportfoliosAdd  ;
       }
     }
     displayResponseFromServer(cmess,1,1) ;
   });

}


//------------------
// add "imported" data to exsiting data
// vv: the "imported" data, as a js object
// doAdd : 0 -- use vv as is, 1-- vv augments allCurrentData (add mode)
// add mode does:
//     adds assets if they do not exist
//      adds assetHistories for added assets AND for existing assets with NO history. Thus, history entries are not merged
//      adds portfolios if they do not exist
//      adds portfolioInits for added portfolios, and for portfolios with no init entry
//      adds portfolioModifications for added portfolios, and for portfolios with no init entry. THus, an exiting portfolio with an init does NOT
//      have portfolioModifications added

 //
function   doExportImport_import_go_doAdd(vv,doAdd) {

// add and noadd use this
   let vvuse=  JSON.parse(JSON.stringify(vv));   // clone the exported data  (read from textbox)
   let  nassetsRetain=false,  nassetsAdd=0,  nportfoliosRetain=false,nportfoliosAdd=0;

   if (vvuse['content']['assets']['time']!==false) {
        nassetsAdd= vvuse['content']['assets']['data'].length;
   }
   if (vvuse['content']['portfolios']['time']!==false) {
        nportfoliosAdd= vvuse['content']['assets']['data'].length;
   }


  if (doAdd==0)  {                                    // overwrite mode -- use vv as is
     return [vvuse,nassetsRetain,nassetsAdd,nportfoliosRetain,nportfoliosAdd];
  }

// if here ... add mode (
    let nowTime=wsurvey.get_currentTime(0)

    nassetsRetain=0;  nassetsAdd=0;  nportfoliosRetain=0;nportfoliosAdd=0;
    let savemeAdd={'content':{}} ;       // have a 'content' property to make it similar to "overwrite" mode (aka the structure of the import file)

    let origData=JSON.parse(JSON.stringify(simInvDsets['allCurrentData']));     // clone currently-supplied-from-server data

// add assets (do not add from export data if asset already exists)

    savemeAdd['content']['assets']={'time':false,'data':[]}  ; // assume no  assets specifidd
    let gotAssets={},newAssets={},skipAssets={};

    for (let ia=0;ia<origData['assets']['data'].length;ia++) {    // keep existing
       let aname= origData['assets']['data'][ia]['name'];
       gotAssets[aname]=1;
        savemeAdd['content']['assets']['data'].push(origData['assets']['data'][ia]);
       nassetsRetain++ ;
    }
    for (let ia=0;ia<vvuse['content']['assets']['data'].length;ia++) {  // add if not in existing
       let aname2=vvuse['content']['assets']['data'][ia]['name'];
       newAssets[aname2]=1;
       if (gotAssets.hasOwnProperty(aname2)) {
           skipAssets[aname2]=1;
           continue ; // do NOT overwrite assets
       }
        savemeAdd['content']['assets']['data'].push(vvuse['content']['assets']['data'][ia]);
       nassetsAdd++ ;
    }
    if (nassetsRetain+nassetsAdd>0)  savemeAdd['content']['assets']['time']=nowTime;

// add assetHistory (do not add from export data if asset history already exists)

    savemeAdd['content']['assetHistory']={'time':false,'data':{}}  ; // assume no  assetHistory specifidd
    let gotAssetsH={},newAssetH={},mhist=0;

    for (let aname in  origData['assetHistory']['data']) {    // keep existing
       gotAssetsH[aname]=origData['assetHistory']['data'][aname]['entries'].length;
       savemeAdd['content']['assetHistory']['data'][aname]=origData['assetHistory']['data'][aname];
       mhist++;
    }
    for (let aname2 in vvuse['content']['assetHistory']['data'] ) {  // add if not in existing
       if (gotAssetsH.hasOwnProperty(aname2)) continue ; // do NOT overwrite
       mhist++;
       newAssetH[aname2]= vvuse['content']['assetHistory']['data'][aname2] ['entries'].length;
       savemeAdd['content']['assetHistory']['data'][aname2]=vvuse['content']['assetHistory']['data'][aname2];
    }
    if (mhist>0)  savemeAdd['content']['assetHistory']['time']=nowTime;


// add portflioes (do not add from export data if portfoliow already exists)
    savemeAdd['content']['portfolios']={'time':false,'data':[]}  ; // assume no  portfolios specifidd
    let gotPortfolios={},newPortfolios={},skipPortfolios={};

    for (let ia=0;ia<origData['portfolios']['data'].length;ia++) {    // keep existing
       let pname= origData['portfolios']['data'][ia]['name'];
       gotPortfolios[pname]=1;
       savemeAdd['content']['portfolios']['data'].push(origData['portfolios']['data'][ia]);
       nportfoliosRetain++;
    }
    for (let ia=0;ia<vvuse['content']['portfolios']['data'].length;ia++) {  // add if not in existing
       let pname2=vvuse['content']['portfolios']['data'][ia]['name'];
       newPortfolios[pname2]=1
       if (gotPortfolios.hasOwnProperty(pname2)) {
           skipPortfolios[pname2]=1
           continue ; // do NOT overwrite
       }
       savemeAdd['content']['portfolios']['data'].push(vvuse['content']['portfolios']['data'][ia]);
       nportfoliosAdd++ ;
    }
    if (nportfoliosRetain+nportfoliosAdd>0)  savemeAdd['content']['portfolios']['time']=nowTime;


// add portflioInts (do not add from import data if portfolio  already exists)
    savemeAdd['content']['portfolioInit']={'time':false,'data':{}}  ; // assume no  portfolioInitss specifidd
    let gotPortfolioInits={},newPortfolioInits={},minit=0 ;

    for (pname in origData['portfolioInit']['data'] ) {    // keep existing
       gotPortfolioInits[pname]= origData['portfolioInit']['data'] [pname]['assetList'].length;
       savemeAdd['content']['portfolioInit']['data'][pname]=origData['portfolioInit']['data'][pname] ;
       minit++;
    }
    for (let pname2 in  vvuse['content']['portfolioInit']['data']) {  // add if not in existing
       if (gotPortfolios.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       if (gotPortfolioInits.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       newPortfolioInits[pname2]= vvuse['content']['portfolioInit']['data'][pname2]['assetList'].length;   // for info purposes
       savemeAdd['content']['portfolioInit']['data'][pname2]=vvuse['content']['portfolioInit']['data'][pname2];
       minit++;
    }
    if (minit>0)  savemeAdd['content']['portfolioInit']['time']=nowTime;


// add portfolioModifications (do not add from export data if portfoliow already exists)
    savemeAdd['content']['portfolioModifications']={'time':false,'data':{}}  ; // assume no  portfolioModifications specifidd
    let gotPortfolioMods={},newPortfolioMods={},mmod=0;;

    for (pname in origData['portfolioModifications']['data'] ) {    // keep existing
       let imods=0  ;
       for (oof in  origData['portfolioModifications']['data'][pname]) imods++;
       gotPortfolioMods[pname]=imods;
       savemeAdd['content']['portfolioModifications']['data'][pname]=origData['portfolioModifications']['data'][pname];
       mmod++;
    }
    for (let pname2 in  vvuse['content']['portfolioModifications']['data']) {  // add if not in existing
       if (gotPortfolios.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       if (gotPortfolioMods.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       savemeAdd['content']['portfolioModifications']['data'][pname2]=vvuse['content']['portfolioModifications']['data'][pname2];
       mmod++;

       let  imods=0
       for (oof in  vvuse['content']['portfolioModifications']['data'][pname2] ) imods++;    // for info purposes
       newPortfolioMods[pname2]=imods;
    }
    if (mmod>0)  savemeAdd['content']['portfolioModifications']['time']=nowTime;


// build a descriptive table     ........
 let aat='';
 if (doAdd==1) aat=doExportImport_import_go_doAdd_table(1) ;   // if 2, this is a "save it now" call (rather than a "what would be saved" call

  return [savemeAdd,nassetsRetain,nassetsAdd,nportfoliosRetain,nportfoliosRetain,aat];

//======    ::::::::::::::::::::::::
// === builid descriptive taqble

 function   doExportImport_import_go_doAdd_table(ifoo) {


   let atable='<table cellpadding="5" rules="rows">';

   atable+='<tr><th bgcolor="#dfdfdf">  Existing assets </th><td><em># of history entries</em></td></tr>'
   for (let zasset in gotAssets) {
     atable+='<tr><th  bgcolor="#dfdfdf">'+zasset+'</th>'
     let nhists= (gotAssetsH.hasOwnProperty(zasset)) ? gotAssetsH[zasset] : 0 ;
     atable+='<td>'+nhists+'</td></tr>'
   }

   atable+='<tr><th bgcolor="#efefdf"> Assets from import   </th><td><em># of history entries</em></td></tr>'
     for (let zasset in newAssets) {
     atable+='<tr><th  bgcolor="#efefdf">'+zasset+'</th>';
     if (skipAssets.hasOwnProperty(zasset)) {
        atable+='<td><em> skipped &hellip;</em></th></tr>' ;
     } else {
        let nhists= (newAssetH.hasOwnProperty(zasset)) ? newAssetH[zasset] : 0 ;
        atable+='<td>'+nhists+'</th></tr>'
     }
   }

   atable+='<tr bgcolor="#dfdfdf"><th >Existing portfolios </th><td><em>#assets in initialization</em></td><td><em># of modifications</em></td></tr>'
   for (let aport in gotPortfolios) {
     atable+='<tr bgcolor="#dfdfdf"><th bgcolor="#dfdfdf">'+aport+'</th>'
     if (gotPortfolioInits.hasOwnProperty(aport)) {
         atable+='<td>'+gotPortfolioInits[aport]+ '  </td>';
     } else {
         atable+='<td> no init entry</td>';
     }
     if (gotPortfolioMods.hasOwnProperty(aport)) {
         atable+='<td>'+gotPortfolioMods[aport]+ '  </td></tr>';
     } else {
         atable+='<td> no mod  entries</td></tr>';
     }
   }    // aport in gotPortfolios
   atable+='</tr>';

   atable+='<tr bgcolor="#efefdf"><th>Added portfolios  (from import)  </th><td><em>#assets in initialization</em></td><td><em># of modifications</em></td></tr>'
   for (let aport in newPortfolios) {
       atable+='<tr><th bgcolor="#efefdf" >'+aport+'</th>'
        if (skipPortfolios.hasOwnProperty(aport)) {
           atable+='<td colspan="2"><em> skipped &hellip;</em></td>';
           continue;
        }
       if (newPortfolioInits.hasOwnProperty(aport)) {
          atable+='<td>'+newPortfolioInits[aport]+ '   </td>';
       } else {
          atable+='<td> no init entry</td>';
       }
       if (newPortfolioMods.hasOwnProperty(aport)) {
         atable+='<td>'+newPortfolioMods[aport]+ '   </td></tr>';
       } else {
         atable+='<td> no mod  entries</td></tr>';
       }
       atable+='</tr>';
   }    // aport in newPortfolios

   atable+='</table>';
   return atable ;

  }   // doExportImport_import_go_doAdd_table



}   //doExportImport_import_go_doAdd

//==========       ===========
// save "imported"simInv data to local storage (imported data was created via an Export operation, whose results were saved)
function doExportImport_import_go_local(adata) {

   let nowTime=wsurvey.get_currentTime(0)
   let acontent= adata['content'] ;

   let stuff=[];
     let stuff1=doExportImport_import_go_localx(acontent,'assets');
       stuff.push(stuff1);
     let stuff2=doExportImport_import_go_localx(acontent,'assetHistory');
       stuff.push(stuff2);
     let stuff3=doExportImport_import_go_localx(acontent,'portfolios');
       stuff.push(stuff3);
     let stuff4=doExportImport_import_go_localx(acontent,'portfolioInit');
       stuff.push(stuff4);
     let stuff5=doExportImport_import_go_localx(acontent,'portfolioModifications');
       stuff.push(stuff5);

    okmess='Importing simInv data: '+adata['nassetsAdd']+' assets,  '+adata['nPortfoliosAdd']+' portfolios ';
    addUserData_indexDb(userName,doExportImport_import_go_localC,stuff,true,okmess) ;

}

function doExportImport_import_go_localx(acontent,ado) {
         let stuffX={};
         stuffX['avar']=ado ;
         let tx=acontent[ado]['time'],dx;
         if (tx===false) {
            let aempty=assetData_empty(ado);
            dx={'time':false,'data':aempty};
         } else {
            dx= acontent[ado]['data'];      // just copy it
         }
         stuffX['aval']=dx ;
         return stuffX;
}

function doExportImport_import_go_localC(astatus,amess) {
      displayResponseFromServer(amess,1,1 );    // nremove
     return 1;
}


//=============
// copy export  -- a  "stringified" file --  to  clipboard
function doExportImport_export_copy(athis) {
  let e1=$('#doexportImport_export_results_string');
  let astuff=e1.text();
 
   navigator.clipboard.writeText(astuff).then(
  () => {
    $('#doexportImport_export_results_copied').show();
   // clipboard successfully set
  },
 () => {
    // clipboard write failed
  }
);

return 1;
}

// ==========
// paste from clipboard .... but check for support
function pasteFromClipboard(athis) {
  
  let qpaste=false;
  let qpaste0=typeof(navigator.clipboard );
  if (qpaste0!=='undefined') {
    qpaste=typeof(navigator.clipboard.readText);
  }
 if (qpaste!=='function') {
   alert('This browser does not support pasting from clipboard ');
   return 0
  }

  let ethis=wsurvey.argJquery(athis);
  let xawhere=ethis.attr('data-where');
  let awhere='#'+xawhere;

//  let awhere='.editor';
  navigator.clipboard
    .readText()
    .then(
      (clipText) => (document.querySelector(awhere).innerText +=  clipText),
    );
}


