<?php

// ============
// php for simInv -- save encMd5 for a user.. but only if dir exists and no encMd5.json exists
 // request: {'userName':userName,'data':data0 }
//  data0 ={'time':nowTime,'userName':userName,'encMd5':encryptionKey_md5};
session_start() ;
ob_start();

  $curDir1=getcwd();             // will be xxx/yyy/simInv/phpLib ... strip out /phpLib
  $len1=strlen($curDir1);
  $len2=$len1-7;
 $curDir=substr($curDir1,0,$len2);

  if (!array_key_exists('username',$_REQUEST)) {       // a hack to deal with stupid mistakes
     if (!array_key_exists('userName',$_REQUEST)) {
       saveData_error("No username specified");   // exits directly
     }    else {
        $auser=$_REQUEST['userName'];
     }
  } else {
       $auser=$_REQUEST['username'];
  }

  if (!array_key_exists('data',$_REQUEST))  saveData_error("No data specified");   // exits directly
// since this is an initof the encMd5 -- do NOT check for existence of an encMd5  in $_REQUEST

  $daDir=$curDir.'/data/'.$auser;
  if (trim($auser)=='' || !is_dir($daDir)) {
     saveData_error("No such user: $auser");   // exits directly
  }

  $try=$daDir.'/encMd5.json';
  $gotEncKey=file_exists($try);
  if ($gotEncKey) {                        // file already exists... don't overwrite!
   saveData_error("Can not re-initialize: $auser.");   // exits directly
  }

  $data1=$_REQUEST['data'];
  $da2=serialize($data1);

  $nn=file_put_contents($try,$da2);
  if ($nn===false)  {
     saveData_error("Could not save md5 of encryption key in: $try ");
  }

   saveData_okay("Encryption key MD5 saved.") ;

  exit;  // should never get here


//==============
// return a problem response [0,messat]
function saveData_error($amess) {
  ob_end_clean();   // remove prints and other crap
  $vv=[0,$amess];
  $vsuggests=json_encode($vv, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit ;
}

//===========
// return a sucess response [1,message]'
function saveData_okay($amess) {
  ob_end_clean();   // remove prints and other crap
  $vv=[1,$amess];
  $vsuggests=json_encode($vv, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit ;
}


?>
