// local storage functions for simInv

///-========================
// check if local storage permitted, and  initialize simInvLocalStorage global
// this does NOT enable the use of localStorage -- simInv_localEnable does this AFTER username is available!
// return false if some kind of problem (simInvLocalStorage.statusMessage for details)

function simInv_localInit(useLocalStorage) {


// simInvLocalStorage MUST be a declared global!
// https://stackoverflow.com/questions/16719277/checking-if-a-variable-exists-in-javascript
   try{simInvLocalStorage }
   catch(e) {
     if(e.name == "ReferenceError") {
       alert ('simInv_localInit: simInvLocalStorage has not been defined (there should be a `var simInvLocalStorage` in your index.html). ');
       return false;
     }
   }


// if file:///, local storage must be used

  let usingProtocol=location.protocol;
  if (usingProtocol.toLowerCase()=='file:')  {
      useLocalStorage=1;          // if file:// MUST use standalone mode  -- this changes the global var
  }

  let nowTime=wsurvey.get_currentTime(0) ;


// init simInvLocalStorage
   simInvLocalStorage= {'enabled':false,'useLocalStorage':useLocalStorage,'protocol':usingProtocol,'nowTime':nowTime,
                  'data':{},'statusMessage':'',
                  'usage':0,'quota':0,
                  'lastUpdate':false,'init':false
     };


 //  user choice for storage location?

   if (useLocalStorage==0) {      // do not use local storage-- but maybe allow user to choose (on first logon) where to store?

     if (useLocalStorageChoice==0)  {       // do not  allow user to choose
        simInvLocalStorage['statusMessage']='localStorage not enable for this simInv installation. Using online storage ';
        simInvLocalStorage['enabled']=false ;
        simInvLocalStorage['useLocalStorage']=0 ;
 
        localStorage.removeItem('simInv_!useLocal') ; // remove  ,   clearLocalStorage.html usesit
        return true;
     }

     if (useLocalStorageChoice==1)  {       // allow user to choose

        let userLocalChoice=localStorage.getItem('simInv_!useLocal');
        if (userLocalChoice===null )  {  // not yet set
          let amess='This your first simInv logon! You can store your data locally, or online.\n';
          amess+='Which would you prefer: ';
          amess+='<ul>';
          amess+='<li> <input type="button" value="local" onClick="simInv_choseLocalStorage(1)"> Data is saved on this computer ';
          amess+='<li> <input type="button" value="online" onClick="simInv_choseLocalStorage(0)"> Data is saved on online (on the '+window.location.hostname+' server)';
          amess+='</ul>';
          simInvLocalStorage['init']=amess;
          return true;
       }
// else, use the saved localStorage choice
       if (userLocalChoice==0)   {          // online, so done
          simInvLocalStorage['statusMessage']='localStorage not chosen for this simInv installation. Using online storage ';
          simInvLocalStorage['enabled']=false ;
          simInvLocalStorage['useLocalStorage']=0 ;
          return true;
       }
       useLocalStorage=1 ;                        // local storage chosen!
      }        //useLocalStorageChoice
   }               // end of online storage, with choice

// if here, using local stoarge. Check some stuff

  let qq=simInv_storageAvailable("localStorage"); // is local storage available

  if (!qq) {      // uselocal storage enabled...
     simInvLocalStorage['statusMessage']='localStorage not enabled on this browser ';
     return false;  // local storage desired, but not available. QUit
  }


//  user choice for storage location?
  let userList=localStorage.getItem('simInv_!users');  // always same storage for all "users" on this machine

  if (userList===null) {
        alert('First logon. Using standAlone mode... initializing userlist (saved to local storage))! ');
        let u1={'nusers':0,'list':{}};
        let u2=JSON.stringify(u1);
        localStorage.setItem('simInv_!users',u2);    // Initializing userlist
   }

   let nstorage=localStorage.length;
   simInvLocalStorage['useLocalStorage']=1 ;
   simInvLocalStorage['enabled']=true ;
   simInvLocalStorage['statusMessage']=nstorage+' items in all local storage ';
   return true;

}

//=================
// enable local stroage, if choice is available
function simInv_choseLocalStorage(ido) {
  if (ido==1) {
     amess='You chose `local` storage. All simInv users (on this machine) will use local storage' ;
  } else {
     amess='You chose `online` storage. All simInv users (on this machine) will use online storage';
  }
  q=confirm(amess+'\n Are you sure? ');
  if (!q) return 0;
  localStorage.setItem('simInv_!useLocal',ido);
  amess+='<p>See readme.txt for more info (such as how to undo this choice) ';
  displayResponseFromServer(amess,1);

}

//====================
// tweeak simInvLocalStorage global variable -- which MUST be defined by simInv_localInit before calling this
// return false if a fatal error, 1 if okay, 2 if initialization (of this user) is needed

function simInv_localEnable(ifoo) {

// these two conditions should always be met
  if (typeof(simInvLocalStorage)=='undefined') {
       alert('simInv_localEnable error:  simInvLocalStorage global not defined ');
       return false;
   }

   if (jQuery.trim(userName)=='') {
       alert('simInv_localEnable: userName not specified ');
       return false;
   }

// does this username exist in localStorage (if localStorage only)
  if (simInvLocalStorage['useLocalStorage']==1) {             // standalone mode
   let u1=localStorage.getItem('simInv_!users');

   if (u1===null) {
      alert('simInv_localEnable: no userList (simInv_!users not in localStorage)');
      return false;
   }

   let u2=JSON.parse(u1);
   let userList=u2['list'];
   if (!userList.hasOwnProperty(userName)) return 2          // first logon with this userName -- initialization is needed
 }    // useLocalStorage=1


   return 1;

 }


///=========
// read a var from localStorage, specific to a userName
// if varname=true, initialize global (or return false if no local storage)
function simInv_localVar(varname,aval) {
  let isnull ;

  if (typeof(simInvLocalStorage)=='undefined') {
       alert('simInv_localVar error:  simInvLocalStorage global not defined ');
       return false;
   }

  if (arguments.length<2)  {               // get value  ......

    if (simInvLocalStorage['enabled']===false) return isnull ;        // not enabled

// 31 july 2023 -- no long support partial local straoge, so no need to check lastUpdate
//    let lastUpdate=false;
//    if (simInvLocalStorage['useLocalStorage']==0)  {           // if pure local storage, don't bother chcking lastupdate
//      let lastUpdate=simInvLocalStorage['lastUpdate'];        // is there update info? If not, assume NOT available!
//      if (lastUpdate===false) return isnull ;              // no lastUpdate info in live storage -- give up
//      lastUpdate=parseInt(lastUpdate);         // check against this  below ...
//    }

    let aname='simInv_'+userName+'@'+varname ;
    let aval2=localStorage.getItem(aname);
    if (aval2===null) return isnull ;       // no such variable stored

    let zz1=JSON.parse(aval2);

// is it out of date?  --- 31 july 2023 depcreatd
//    if (lastUpdate!==false)   {   // if false, standalone mode (no checking needed)
//      let mydate=parseInt(zz1['date']);
//      if (mydate<lastUpdate) return isnull ;           // cache out of date
//   }


    return  zz1['content'];                    // got a localStorage version that is not out of date!
  }

// set value (returning false if a problem, rather than an undefined

  if (simInvLocalStorage['enabled']===false) return false ;        // false if can't be saved for any reason
  let aname='simInv_'+userName+'@'+varname ;

  if (aval===null)   {   // null means "remove"
     let aname='simInv_'+userName+'@'+varname ;
     localStorage.removeItem(aname);
     return true;
   }

  let nowTime=wsurvey.get_currentTime(0) ;
  let zz={'date':nowTime,'content':aval};        // aval CAN be an object
  let zz1=JSON.stringify(zz);
  localStorage.setItem(aname,zz1);               // this varname  in localStraoge   (for this user)

  simInvLocalStorage['lastUpdate']=nowTime;     // update simInvLocalStorage (live info)
  let anameZ='simInv_'+userName+'!lastUpdate' ;
  localStorage.setItem(anameZ,nowTime);         // lastUpdate timestamp for this user 

  return true;

}



//====================
//  show status message (if no local storage)
function  simInv_localStorageError(atype) {

  if (atype===false) {
     $('#failMessage').remove();  // dont need this

   } else  {                        // pure local storage

    let usingProtocol=location.protocol;

     let bmess='This installation of simInv is in standAlone mode -- it does not interact with a server. ' ;
     if (usingProtocol=='file:') bmess+=' (invoked using a file:// url) ';
      bmess+='<br>However: local storage is not enabled by your browser.';

      bmess+='<br>That means: it <u>must</u> be run using a <tt>file://pathToSiminv.html</tt> url. ';
      bmess+='<p>To use the server based (data stored on a server) -- use <tt>simInv.php</tt> ';
      let goo=$('#headerLine');
      goo.hide();
      let goo2=$('#logonDiv');
      goo2.hide();
      let efail= $('#failMessage');
      efail.html(bmess);
      efail.show();
      return false;
  }

}


///================
// get local storage stats (asynchrous) and display/enable button
function simInv_localStorageStats(ifoo) {

  if (typeof(simInvLocalStorage)=='undefined') {
       alert('simInv_localStorageStats error:  simInvLocalStorage global not defined ');
       return false;
   }

  let elocalStorage=$('#iLocalStorage');
  let elocalStorageButton=$('#iLocalStorageButton');
  if (simInvLocalStorage['enabled']===false) {
      elocalStorage.show();
      elocalStorage.css({'opacity':0.3,'text-decoration':'line-through','color':'red'});
      let lMess;
      if (simInvLocalStorage['useLocalStorage']==0)   {
            lMess='Local storage is NOT enabled by this simInv installation (in simInv.html) '
      } else {
           lMess='This browser does NOT enable local storage  ' ;
      }
      elocalStorage.attr('title',lMess);
      elocalStorageButton.attr('title',lMess);
      elocalStorageButton.prop('disabled',true);

  } else {
      navigator.storage.estimate().then((estimate) => {
        let localStorage_usage=estimate.usage;  // save some globals
        let localStorage_quota=estimate.quota;
        simInvLocalStorage['usage']=estimate.usage;
        simInvLocalStorage['quota']=estimate.quota;

        let  usedPct=((estimate.usage / estimate.quota) * 100).toFixed(2);
        elocalStorage.show();
        elocalStorage.attr('title','Local storage enabled. '+usedPct+'% used');
        elocalStorageButton.attr('title','Local storage enabled. '+usedPct+'% used');
        elocalStorageButton.prop('disabled',false);
     });
   }
   return 1;
}


//=================
// update local storage "lastUpdate" time stamp
// if  noargs, or 0 or false -- get lastUpdate (false if not set)
//    if 1 arg, and is not 0 or false, set lastUpdate to currentTime
// iforce is optional: if 1, then read from localStorage (do NOT check simInvLocalStorage
//  readMode : return dateStamp (if read mode) or false if no update stamp. First look in live stogage  (simInvLocalStorage), then in localStorage
//  writeMode: return false if no local storage, true if lastUpdate saved

function simInv_localLastUpdate(iset,iforce) {
   if (arguments.length<1) iset=false;
   if (iforce<2) iforce=false;

   if (typeof(simInvLocalStorage)=='undefined') {
       alert('simInv_localLastUpdate error:  simInvLocalStorage global not defined ');
       return false;
   }
   if (simInvLocalStorage['enabled']===false) return false ;       // no local storage, return false (but no alerts)

   if (iset===false || iset==0)  {                // read lastUpdate (from localStorage or simInvLocalStorage)
      if (iforce!=1 ) {          // try  simInvLocalStorage first ...
         let aupdate=(!simInvLocalStorage.hasOwnProperty('lastUpdate')) ? false :  simInvLocalStorage['lastUpdate'];
         if (aupdate!==false) return aupdate ;   // if liveVersion!=false, use live version
      }
      
// no lastUpdate in simInvLocalStorage, or iforce=1
      let aname='simInv_'+userName+'!lastUpdate';  // no liveVersion, so read lastUpdate from localStorage
//      alert('read lastupdate using '+aname);

      let aval2=localStorage.getItem(aname);   // not in local version -- read from localStorage
      if (aval2===null)  return false ;        // local storage not initialzied for this user of siminv (leave localVersion as false
      simInvLocalStorage['lastUpdate']=aval2 ;  // update live version
      return aval2 ;                // could be false, could be js datestamp
   }

// ... set last update (using time right now)
   let nowTime=wsurvey.get_currentTime(0) ;
   let zz={'date':nowTime,'content':simInv_localLastUpdate};
   let zz1=JSON.stringify(zz);

   let aname='simInv_'+userName+'!lastUpdate';  // read lastUpdate from localStorage
   localStorage.setItem(aname,zz1);               // update lastUpdate for this user
   simInvLocalStorage['lastUpdate']=nowTime ;  // update live version

   return true ;
}

//============
function simInv_viewLocalInfo(athis) {
  let bmess='';
   bmess+='<input type="button" value="x" onclick="wsurvey.wsShow.hide(this,200)" data-wsshow="#mainDiv3"> ';
   bmess+='<b>Local storage:</b> for user=<tt>'+userName+'</tt>   ';

   allow1=simInvLocalStorage['useLocalStorage'] ;
   if (allow1==0) {
      bmess+='<em>local storage not used for simInv data (online mode)</em>';
   } else {
     bmess+='<em>used for all simInv data (standAlone mode)</em>'
   }

// lastUpdate deprcated 31 july 2023
//   let lDate=simInv_localLastUpdate(0,1);
//   let lDateSay=wsurvey.get_currentTime(31,1,lDate);
//   bmess+='  <tt>last update: '+lDateSay+'</tt>';
//   bmess+='<br>';

   let ns=localStorage.length;
  // bmess+=ns +' stored';

   let anameCheck='simInv_'+userName+'@';
   let ilen=anameCheck.length;
   let alist=[],alistX=[];;
   for (let i = 0; i < localStorage.length; i++) {
      let aname=localStorage.key(i) ;
      if (typeof(aname)!='string') continue;
      let aname0=aname.substr(0,ilen);
      if (aname0!==anameCheck) continue ;
      let anameUse=aname.substr(ilen);
      let ug=[anameUse,aname];
      alistX.push(ug);
   }
   alistX.sort(simInv_viewLocalInfo_sort);
   for (let mm=0;mm<alistX.length;mm++) {
      anameUse=alistX[mm][0];
      aname=alistX[mm][1];
      let zz=localStorage.getItem(aname);
      let zz2=JSON.parse(zz);
      let adate=zz2['date'];
      let aDateSay=wsurvey.get_currentTime(31,1,adate);
      let rname;
      rname='<input type="button" value="'+anameUse+'" title="click to view this" data-name="'+anameUse+'" onClick="simInv_viewLocalInfoVar(this)" > ' ;
      alist.push(rname+' : updated '+aDateSay);
    }


   bmess+='<ul><li>'+alist.join('<li>')+'</ul>';

   bmess+='<p>You can <input type="button" value="Remove this user ('+userName+')" data-allow="'+allow1+'"    onClick="simInv_viewLocalInfoRemoveAll(this)" > (and clear all her data)' ;

  let userList1=localStorage.getItem('simInv_!users');
  let userList=JSON.parse(userList1);

  bmess+=' <ul class="linearMenu16Pct">';
  bmess+='<li style="background-color:lime;font-weigh:600">You can switch users ...';

  for (auser in userList['list']) {
      let isdis='  ';
      if (auser==userName) isdis=' disabled  title="(current user)" ';
      bmess+='<li><button onClick="simInv_switchUser(this)" '+isdis+' data-user="'+auser+'">'+auser+'</button>';
  }
  bmess+='</ul>';

   wsurvey.wsShow.show('#mainDiv','show');
   wsurvey.wsShow.hide('#mainDiv1');    // this is where the table is shown
   wsurvey.wsShow.hide('#mainDiv2');    // this is where the table is shown
   wsurvey.wsShow.show('#mainDiv3','show');
   $('#mainDiv3').html(bmess);

}

//================
// switch users
function simInv_switchUser(athis) {
   let ethis=wsurvey.argJquery(athis);
   let auser =ethis.attr('data-user');
    doLogoff(1,'',auser)
}

function simInv_viewLocalInfo_sort(a,b) {
   let a1=a[0].toLowerCase();
   let b1=b[0].toLowerCase();
   if (a1>b1) return 1 ;
   if (b1>a1) return -1 ;
   return 0;
}
//==========
// clear a localStorage variable
function simInv_viewLocalInfoRemove(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-name');
   simInv_localVar(aname,null);
   simInv_viewLocalInfo(1)
}

//======================
// view this localStroage var
function simInv_viewLocalInfoVar(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-name');
   let vv= simInv_localVar(aname);
   if (typeof(vv)=='undefined') {
      amess='Not yet saved to localStorage:  '+aname ;
      alert(amess);
   } else {
       showDebug(vv,'localStorage of '+aname );
//       alert('Displayed: '+aname);
   }

   return 1;

}

//==========
// clear all simInv_username... localStorage variables
function simInv_viewLocalInfoRemoveAll(athis) {
   let ethis=wsurvey.argJquery(athis);
   let allow1=ethis.attr('data-allow');
   if (allow1==2) {
      let q=confirm('simInv is running in standAlone mode. Clearing localStorage will remove ALL of your simInv data! \n Are you sure? ');
      if (!q) return false;
   }

// make list of vars to delete
   let anameCheck='simInv_'+userName+'@';
   let ilen=anameCheck.length;
   let dodels=[];
   for (let i = 0; i < localStorage.length; i++) {
      let aname=localStorage.key(i) ;
      if (typeof(aname)!='string') continue;
      let aname0=aname.substr(0,ilen);
      if (aname0!==anameCheck)     continue ;
      dodels.push(aname);
    }
   anameCheck='simInv_'+userName+'!';      // for now, just !lastUpdate
   ilen=anameCheck.length;
   for (let i = 0; i < localStorage.length; i++) {
      let aname=localStorage.key(i) ;
      if (typeof(aname)!='string') continue;
      let aname0=aname.substr(0,ilen);
      if (aname0!==anameCheck)     continue ;
      dodels.push(aname);
      localStorage.removeItem(aname);
    }

    for (let ij=0;ij<dodels.length;ij++) {  // and remvoethem
       let aname=dodels[ij] ;
       localStorage.removeItem(aname);
    }

// remove from userlist
   let u1=localStorage.getItem('simInv_!users');
   if (u1===null) {        // should never happen
      alert('simInv_viewLocalInfoRemoveAll: no userList (simInv_!users not in localStorage)');
      return false;
   }
   let u2=JSON.parse(u1);
   let userList=u2['list'];
   let nusers=u2['nusers'];
   delete userList[userName];
     nusers=parseInt(nusers)-1;
   let z1={'nusers':nusers,'list':userList};
   let z2=JSON.stringify(z1);
   localStorage.setItem('simInv_!users',z2);     // remove user for userlist (in simInv_viewLocalInfoRemoveAll)

// check for # of simInv users. If not, remove simInv_!useLocal
   let userList2=localStorage.getItem('simInv_!users');

   displayResponseFromServer('User: '+userName+' has been removed.',1);
}

// =============
// generic
//===============
//https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
// check if local storage is available
function simInv_storageAvailable(type) {
  let storage;
  try {
    storage = window[type];
    const x = "__storage_test__";
    storage.setItem(x, x);
    storage.removeItem(x);
    return true;
  } catch (e) {
    return (
      e instanceof DOMException &&
      // everything except Firefox
      (e.code === 22 ||
        // Firefox
        e.code === 1014 ||
        // test name field too, because code might not be present
        // everything except Firefox
        e.name === "QuotaExceededError" ||
        // Firefox
        e.name === "NS_ERROR_DOM_QUOTA_REACHED") &&
      // acknowledge QuotaExceededError only if there's something already stored
      storage &&
      storage.length !== 0
    );
  }
}

