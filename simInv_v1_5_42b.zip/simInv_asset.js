// asset, and asset history, functions (simInv)
//=============
// show asset table, and allow adding assets

function showAssetTable(athis) {

  let amess='';
  amess+='<div style="background-color:tan;font-weight:600">';
  amess+='<span class="biggerName">Assets</span> ';
  amess+='<em>Before</em> <input type="button" value="save"> <em>you can </em>';
  amess+=' <button>add</button> a new asset, or <button>Remove</button> an existing asset  &boxV; ';
  amess+='<input type="button" value="&#128201;" >To view/modify asset <span title="History: the price/dividend/interest trend of an asset" >';
  amess+=' history </span> &boxV; ';
  amess+='  <input type="button" value="&#9998;Init" style="background-color:lime" > To specify an asset\'s first price, etc.';
  amess+='</div>';
  amess+='<div id="assetTablePreview" class="cassetTablePreview"></div>  ';

  amess+='<table  border="1" id="assetsTable" width="95%"   class="cassetsTable0">';
  amess+='<tr class="headerRow">';

  amess+='<td width="18%"  title="sort by: first entry date (in asset history)" >';
  amess+=' <button class="cdoButtonTan" title="Click to add a new row" onClick="addARowAssets(this)">Add</button>';
    amess+=' <button class="csaveButton" title="Save these assets " onClick="saveAssets(this)">Save!</button>';

  amess+='</td>';

  amess+='<th width="12%" > <span class="choiceNameSay">Name</span> ';
    amess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#assetsTableHelp1">&#10068;</button>';
  amess+='</th>';
  amess+='<th width="25%"  > <span title="What type of asset: stock, bond, property, income...">assetType? &amp; attributes  </span></th>';

  amess+='<th width="20%"  > <span title="Short description">Desc &amp; taxSettings  </span></th>';
  amess+='<th width="25%" title="sort by: # of entries (assetHistory)"  > <span title="Long description">DescLong &amp;  <span title="What portfolios does this asset appear in" class="cinWhatPortoflios">portfolios</span> </span></th>';
  amess+='</tr>';

  amess+='<tr class="assetRowCash" data-name="cash">';
  amess+='<td><button title="The `cash` asset can not be removed!" class="cdescNoteLittle" ><u>Cash</u> can not be removed</button>&hellip;</td>';
  amess+='<td><u>Cash</u></td>';
  amess+='<td>&vellip;</td>';

  amess+=' <td><button readonly title="The `cash` asset is auto-calculated" >Cash... </button></td>';
  amess+='<td><button readonly">The <u>Cash</u> asset =  <tt> budget  -  portfolioCost </tt></button></td></tr>';

  for (let aname in assetLookup) {

    let aname0=aname;
    let sayName=doAssetLookup(aname,'sayname','',1);
    let nHistory=doAssetLookup(aname,'nHistory',2,1)  ;  // the actual # entrieds (does NOT include inflationImputed entries)
    let firstEntryDayCount=doAssetLookup(aname,'date','',1);
    let firstEntryDateSay=doAssetLookup(aname,'firstEntryDateSay','',1);
    let nImputed=doAssetLookup(aname,'nImputed','',1);
    let nIncomeVariants=doAssetLookup(aname,'contantIncomeVariants','',1).length;

    amess+='<tr class="assetRow" data-name="'+aname+'">';
    amess+='<td  data-_sortuse="'+firstEntryDayCount+'" ><span  ><input type="button" value="Remove" onClick="removeAssetRow(this,0)"></span>';

    let inPortfolios=  (assetsUsed['list'].hasOwnProperty(aname)) ? assetsUsed['list'][aname]['entries'] : 0 ;
    if (inPortfolios=='Nan' || isNaN(inPortfolios)) inPortfolios=0;

    if (nHistory>0) {
      amess+='<input type="button" value="&#128201;" title="View history of this asset (price/dividend/interest)"  ';
      amess+='  data-sayname="'+sayName+'"   data-name="'+aname+'" onClick="showAssetHistory(this)"  >';
      amess+='<span title="Date of first entry /  # entries " class="cAssetHistoryShow">'+firstEntryDateSay+' / '+nHistory+'</span>';
      amess+='<span style="font-style:oblique;float:right;margin:1px 10px 1px 3px" title="# of portfolio entries this appears in (initialization or modification)">'+inPortfolios+'</span>';
    } else {
      amess+='<input type="button" value="&#9998;Init" style="background-color:lime" title="No values (price/divdend/interest) assigned to this asset)"  ';
      amess+='  data-sayname="'+sayName+'"   data-name="'+aname+'" onClick="showAssetHistory(this)"  >';
    }
    amess+='</td>';


    let assetType=doAssetLookup(aname,'assetType','',1); // suppress alerts (catch below)
    if (assetType===false) {        // a missing asset?
       amess+='<td bgcolor="yellow">'+aname+'</td>';
       amess+='<td>bad asset (no type)';
       amess+=' <input type="hidden" name="assetName" data-nocheck="1" value="'+aname+'">';
       amess+='       </td>';
       amess+='</tr>';
       continue ;
    }


    amess+='<td data-_sortuse="'+sayName+'" ><span name="assetNameSay" class="cNameSay">'+sayName+'</span>';
    amess+='<input type="hidden" name="assetName" value="'+aname+'">';     // hack to facilitate read of all assetnames in menu
    amess+='</td>';

    let assetTypeSay=getAssetType(assetType,'iconSpan');

    let taxFreeFrac=doAssetLookup(aname,'taxFreeFrac',1);
    let lossesOffset=doAssetLookup(aname,'lossesOffsetIncome');
    let   constantIncomeSay='' ;
    if (assetType==4) {
       let constantIncome=  doAssetLookup(aname,'constantIncome') ;
       if (constantIncome==1) {
          constantIncomeSay=' <span title="Income amount set when asset acquired (although it can grow) : # of versions" style="font-style:oblique;font-size:85%"> Fixed:'+nIncomeVariants+'</span> ' ;
       } else {
          constantIncomeSay= '<span title="Income amount varies (using assetHistory)" style="font-style:oblique;font-size:85%"> Vary</span> ' ;
       }
    }

    amess+='<td data-_sortuse="'+assetType+'"><span name="assetBond"  data-type="'+assetType+'" class="cBondSay cassetTypeSay">'+ assetTypeSay+' </span>';
    amess+=constantIncomeSay ;

    if (nImputed>0) {
       amess+='<span class="cnImputedAssetEntries"  title="# of imputed (using predicted inflation) entries">'+nImputed+'</span>';
    }

    if (taxFreeFrac===false || taxFreeFrac==='false') taxFreeFrac=0.0;
    amess+='<span style="float:right;margin-right:0.1em">';
    if (assetType==1 ) amess+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=interest earnings are not taxed)">'+taxFreeFrac+'</span>';
    if (assetType==3 ) amess+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=capitalGains are not taxed)">'+taxFreeFrac+'</span>';
    if (assetType==4 ) amess+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=income is not taxed)">'+taxFreeFrac+'</span>';

     let alossesOffset='<span  title="..." class="ctaxOffset">&hellip;</span>';
     if (assetType==3 ) {
        if (lossesOffset==1) {
            alossesOffset='<span title="-netRevenue offset other income (for tax purposes)" class="ctaxOffset"> &ltcir; offset!</span>';
       } else {
            alossesOffset='<span title="-netRevenue do NOT offset other income (for tax purposes)" class="ctaxOffset"> &#9723; </span>';
       }
     } else    if (assetType==4) {
        if (lossesOffset==1) {
             alossesOffset='<span title="-incomeStreams offset other income (for tax purposes)" class="ctaxOffset"> &ltcir; offset!</span>';
       } else {
            alossesOffset='<span title="-incomeStreams do NOT offset other income (for tax purposes)" class="ctaxOffset"> &hellip;</span>';
       }
     }
     amess+= alossesOffset;
     amess+='</span>';



    amess+='</td>';


// short descirption
   let adesc3=doAssetLookup(aname,'desc');
    amess+='<td><span name="assetDesc"  class="cDescSay">'+adesc3+'</span></td>';

// long descrition & what portfolios this asset appears in
    amess+='<td  data-_sortuse="'+nHistory+'">';;

   let zalist='';

    if (assetsUsed.hasOwnProperty(aname)) {         // this asset is in at least on portfolio

       let goof=[];
       for (let pp1 in assetsUsed[aname]['portfolios']){
         let bb1='<input value="'+pp1+'" type="button" title="View this portfolio`s entries" onclick="showAllPortfolioValues_viewEntry(this)" data-ith="0" data-name="'+pp1+'"> ';
         goof.push(bb1);
       }
       zalist=goof.join(' &nbsp;  ');
    }
    let adesc3long=doAssetLookup(aname,'descLong');
    amess+='<div name="assetDescLong" class="cDescLongSay">'+adesc3long+'</div>';
    amess+='<div title="Portfolios that `'+aname+'` appears in" class="cinWhatPortoflios">'+zalist+'</div>';


    amess+='</td>';

    amess+='</tr>';
  }
  amess+='</table>';
  $('#mainDiv3').html(amess);

   $('#assetsTable').data('removes',{});  // reset every time table is displayed

  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv2');
  wsurvey.wsShow.show('#mainDiv3','show');

  wsurvey.sortTable.init('assetsTable',{'skips':[],'startRow':2});
//

}

//====================
// add a row to assets Table
//&#127463;ond;
//&#127480;tock
//&#127299;axDefer
//&#127477;roperty
//&#127470;ncome

function addARowAssets(athis) {
   let etable=$('#assetsTable');

   let amess=''
    amess+='<tr class="assetRow assetRowNew">';
    amess+='<td> <input type="button" value="Remove this row ..." onClick="removeAssetRow(this,1)">';
    amess+='</td>';
    amess+='<td> <input type="text" size="12" name="assetName" value=""></td>';
    amess+='<td> ';
    amess+='<div  name="assetTypeBlock" data-assetType="0">';    // default is stock


// extra attributes (what is shown depends on selected type
// displayed in DESC .... cell

    let amessOther='',aicon='';

       amessOther+='<div   name="assetTypeBlock_more"   class="cassetTypeBlock_more" title="attributes ...">';
       amessOther+='<div name="type0_span" class="cassetTypeBlock_more1" style="display:inline-block"  >';
       aicon=getAssetType(0,'icon');

       amessOther+=aicon+' Earnings fully taxed<br>CapGains fully taxed';
       amessOther+='</div>  ';

       aicon=getAssetType(1,'icon');
       amessOther+='<div name="type1_span" class="cassetTypeBlock_more1"  >'+aicon+' Fraction of earnings NOT taxed:';
       amessOther+=' <input name="nbondTaxFrac" value="0.0" title="taxFree fraction (0.0=interest earnings IS fully taxed ... 1.0:  interest earnings are NOT taxed" type="text" size="4" >';
       amessOther+='<br><span style="border:1px dotted gray;white-space:nowrap;display:inline-block">Sales (capGains) are <u>not</u> taxed</span> ';
       amessOther+='</div>  ';

       aicon=getAssetType(2,'icon');
       amessOther+='<div name="type2_span" class="cassetTypeBlock_more1"  >';
       amessOther+=aicon+' Earnings <u>not</u> taxed<br> Sales (capGains) fully taxed  ';
       amessOther+='</div>  ';

       aicon=getAssetType(3,'icon');
       amessOther+='<div name="type3_span"  class="cassetTypeBlock_more1">'+aicon+' ';
       amessOther+='<span style="margin-left:1em;font-size:80%;white-space:nowrap;display:inline-block">Earnings fully taxed</span>  ';
       amessOther+='<br> Fraction of capitalGains NOT taxed: ';
       amessOther+='  <input name="ncapGainsTaxFreeFrac" value="0.0" title="non-taxable fraction of capital gains (0.0=capitals gains IS taxed (at capital gains rate),... 1.0:  capital gains NOT taxed" type="text" size="4" >';
       amessOther+='<br><label title="If unchecked, negative netRevenue from this property are NOT used to offset other income"><input type="checkbox" name="ntaxFreeLosses" value="1">-netRevenue offsets other income?</label>';
       amessOther+='</div>  ';

       aicon=getAssetType(4,'icon');
       amessOther+='<div name="type4_span"  class="cassetTypeBlock_more1" >'+aicon+' ';
       amessOther+=' Fraction of income NOT taxed: ';
       amessOther+=' <input name="nincomeTaxFreeFrac" value="0.0" title="non-taxable fraction of income (0.0= income IS taxed,... 1.0:  income is NOT taxed" type="text" size="4" >';

       amessOther+='<div>';
       amessOther+='<label title="If checked: income is fixed once acquired (it can grow at a fraction of inflation)"> ';
       amessOther+='<input type="checkbox" name="nConstantIncome" value="1">Fixed income?</label> | ';
       amessOther+='<span style="display:inline-block;white-space:nowrap">'
         amessOther+='<label title="If unchecked, losses from this income stream  are NOT used to offset other income"><input type="checkbox" name="nTaxFreeLosses" value="1"> -income offsets other income?</label>';
         amessOther+='</span>';
       amessOther+='</div>  ';

       amessOther+='</div>  ';

    amessOther+='</div>';

    amess+='<div style="background-color:#dfe59d;">';
    amess+=' <span class="cassetTypeBlock1 cassetTypeBlock1_highlight"><label title="Stock asset">';
    amess+='   <input checked   onClick="selectAssetType(this)" type="radio" value="0"  >';
        amess+=getAssetType(0,'iconSpan')+'  </label> ' ;
    amess+='</span> ' ;

    amess+='<span class="cassetTypeBlock1 "><label  title="Bond (regular) asset"><input  onClick="selectAssetType(this)" type="radio" value="1">';
        amess+=getAssetType(1,'iconSpan')+'</label>';
    amess+='</span> ' ;

    amess+=' <span class="cassetTypeBlock1"><label  title="Bond (tax-deferred) asset"><input onClick="selectAssetType(this)" type="radio" value="2" >';
        amess+=getAssetType(2,'iconSpan')+'</label> ' ;
    amess+='</span> ' ;

    amess+=' <span class="cassetTypeBlock1"><label  title="Proerty asset"><input onClick="selectAssetType(this)" type="radio" value="3" >';
        amess+=getAssetType(3,'iconSpan')+'</label>' ;
    amess+='</span> ' ;

    amess+=' <span class="cassetTypeBlock1"><label  title="Income-stream asset"><input onClick="selectAssetType(this)" type="radio" value="4" >'
        amess+=getAssetType(4,'iconSpan')+'</label> ' ;
    amess+='</span> ' ;

    amess+='</div>';
    amess+='</div>';
    amess+='</td>';  // asset type radio buttons & more

    amess+='<td>';
    amess+='<div name="assetAttribs_other" >';
    amess+=amessOther ;
    amess+='</div>';
    amess+='Desc:<input title="Short description" type="text" size="34" name="assetDesc" value="">  ';
    amess+='</td>';


    amess+='<td> <textarea rows="2" cols="40" name="assetDescLong"></textarea></td>';
    amess+='</tr>';

    let ec1=etable.find('.assetRowCash');
    ec1.after(amess);

    let aamess='After specifying new assets to add, and existing assets to remove -- click  <button><b>Save!</b></button>';
    aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em>  ';
    aamess+=' <button class="csaveButton" onClick="showAssetTable(this)">reload the assets list </button> <em>without making these changes!</em>';
    $('#assetTablePreview').html(aamess);


}

//================
// select asset type button highligher
// val: 0:stock,1:bond, 2:tax defererd bond, 3:property, 4:income
function selectAssetType(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aval=ethis.val();

   let eblock=ethis.closest('[name="assetTypeBlock"]');
   eblock.attr('data-assetType',aval);         // make it easy to determine assetType of newly added asset

// highlight/check the clicked on type
   let espans=eblock.find('.cassetTypeBlock1');
   espans.removeClass('cassetTypeBlock1_highlight');

   for (let iss=0;iss<espans.length;iss++) {
      let einput=$(espans[iss]).find('input');
      einput.prop('checked',false);
   }
   let espan1=ethis.closest('.cassetTypeBlock1');
   espan1.addClass('cassetTypeBlock1_highlight');
   ethis.prop('checked',true);

// extra attribute?
   let etr=ethis.closest('.assetRowNew');
   let eOthers=etr.find('[name="assetAttribs_other"]');
   let emore=eOthers.find('[name="assetTypeBlock_more"]');
    let efoo=emore.find('.cassetTypeBlock_more1');
    efoo.hide();

    let goo='type'+aval+'_span';
    let egoo=emore.find('[name="'+goo+'"]');
    egoo.show();


}

//=================
// hide show tax derer and tax free if this is bond/stock
function addARowAssetsCheck(athis) {
  let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('.assetRowNew');
   let ischeck=ethis.prop('checked');      // if chcked, this is a bond
   let efree=erow.find('[name="assetTaxFreeFraction"]');

   edefer.prop('checked',false);
   efree.val(0.0)  ;       // reset to defaults

   if (ischeck) {   // bond
      edefer.prop('disabled',false);
      efree.prop('disabled',false);
   } else {
      edefer.prop('disabled',true);
      efree.prop('disabled',true);
   }
}

//=================
// set taxfree pct if taxDefer chosen/unchosen
function addARowAssetsCheck2(athis) {
   let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('.assetRowNew');
   let ischeck=ethis.prop('checked');      // if chcked, this is a bond
   let efree=erow.find('[name="assetTaxFreeFraction"]');
   efree.val(0.0)  ;       // reset to default
   if (ischeck) {   // tax defered
      efree.prop('disabled',true);
   } else {
      efree.prop('disabled',false);
   }

}
///==================

// save the new assets, or remove  assets.
function saveAssets(athis) {
  let stuff=[];
   let etable=$('#assetsTable');
   let removes=$('#assetsTable').data('removes');
   let remove1=[];
   for (let ab in removes) remove1.push(ab);

   let gotNames={};

// find specified assets (new and old) -- caution if in removes. Used to prevent trying to specify an asset BEFORE removing it
// also check for improper names
   let etrs=etable.find('.assetRow');
   for (let jet=0;jet<etrs.length;jet++) {
         let aetr=$(etrs[jet]);
         let e1=aetr.find('[name="assetName"]')

         let aname0=jQuery.trim(e1.val().toLowerCase());
         if (aname0=='') continue ; // ignore blank
         let aname=aname0;

         if (gotNames.hasOwnProperty(aname)) {
             alert(aname+' is already specified. Use a different name for this new asset. Note that to respecify an asset -- remove it, save, then add it back');
             return 0
         }
         gotNames[aname]=1;
   }

   let etrsNew=etable.find('.assetRowNew');

   for (let j1=0;j1<etrsNew.length;j1++) {     // read new rows assets
         let aetr=$(etrsNew[j1]);
         let e1=aetr.find('[name="assetName"]')
         let aname=fixString(jQuery.trim(e1.val()),1);
         if (aname=='') {
              alert('You did not specify an asset name ');
              return 0;
         }
         let sayName=aname;      // allow capitals in displayed name
         aname=aname.toLowerCase();
         if (aname=='cash') {
            alert('`cash` can not be used as an asset name');
            return 0;
         }

         let aname0=aname;
         aname=fixStringRemoves(aname0);
         if (aname0!==aname) {
             alert('Improper asset name: `'+aname0+'`\n Use a different name without any of the following characters: embedded spaces, commas, %,  &, +, *, /, \\, \', `, ", #, !, $, <, >, or  | ');
             return false;
         }

         let oof=aname.split('.');
         if (oof.length>2) {           // too many .
            alert('Improper asset name: too many periods: '+aname0+'\n You can specify `family` or `family.scenario` ');
            return false;
        }

         let e2b=aetr.find('[name="assetTypeBlock"]');
         let iAssetType=e2b.attr('data-assettype')

         let afrac=false;  //   used for types 1,3,4 (regular bond, properties, incomeStream)
         let lossesOffsetIncome=0;    // used with property (netRent) and income assets
         let constantIncome=0;         // only used with income assets

         if (iAssetType==1)  {  // regular bond...
             let e3=aetr.find('[name="nbondTaxFrac"]');
             afrac=jQuery.trim(e3.val());
             if (afrac==='' || !jQuery.isNumeric(afrac) || parseFloat(afrac)<0.0 || parseFloat(afrac)>1.0 ) {
                 alert('Please enter value between 0.0 and 1.0 for '+aname+'  (non taxable portion of interest earnings) ');
                 return 0;
             }
         }
         if (iAssetType==3)  {  // property
             let e3=aetr.find('[name="ncapGainsTaxFreeFrac"]');
             afrac=jQuery.trim(e3.val());
             if (afrac==='' || !jQuery.isNumeric(afrac) || parseFloat(afrac)<0.0 || parseFloat(afrac)>1.0 ) {
                 alert('Please enter value between 0.0 and 1.0 for '+aname+'  (non taxable portion of capital gains) ');
                 return 0;
             }
             let e3z=aetr.find('[name="ntaxFreeLosses"]');
             lossesOffsetIncome= (e3z.prop('checked')) ?  1 : 0 ;
         }

         if (iAssetType==4)  {  // income
             let e3=aetr.find('[name="nincomeTaxFreeFrac"]');
             afrac=jQuery.trim(e3.val());
             if (afrac==='' || !jQuery.isNumeric(afrac) || parseFloat(afrac)<0.0 || parseFloat(afrac)>1.0 ) {
                 alert('Please enter value between 0.0 and 1.0 for '+aname+'  (non taxable portion of income stream) ');
                 return 0;
             }
             let e3z=aetr.find('[name="nTaxFreeLosses"]');
             lossesOffsetIncome= (e3z.prop('checked')) ?   1 : 0 ;

             let e3z2=aetr.find('[name="nConstantIncome"]');
             constantIncome= (e3z2.prop('checked')) ?   1 : 0 ;

         //    alert('for inc '+lossesOffsetIncome);

         }

         let e2=aetr.find('[name="assetDesc"]')
           let adesc=fixString(jQuery.trim(e2.val()),2);
           adesc=wsurvey.removeAllTags(adesc);
         let e3=aetr.find('[name="assetDescLong"]')
           let adescLong= jQuery.trim(e3.val())  ;
           adescLong=wsurvey.removeAllTags(adescLong);

        let arow={'name':aname,'sayname':sayName,'assetType':iAssetType,'taxFreeFrac':afrac,'desc':adesc,'descLong':adescLong,
                   'lossesOffsetIncome':lossesOffsetIncome,'constantIncome':constantIncome};
        stuff.push(arow);    // new ones

   }   // new row

  if (remove1.length==0 && stuff.length==0) {
      alert('You did not remove, or add new, assets');
      return 0;
  }
  let ddata={};
  ddata['todo']='saveAssets';
  ddata['list']=stuff;           // additions  (array of objects, one row per new asset)
  ddata['removes']=remove1;      // removals    (array of asset names)
  ddata['username']=userName ;
  ddata['encMd5']=encryptionKey_md5;
  saveSimInvData(ddata);
  return 1;



}

//====================
// remove row from asset, or asset history, table
function removeAssetRow(athis,isNew) {

   let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('tr');

   if (isNew==1)  {  // new row, just remove it
      erow.remove();
      return 1;
   }

   let aname=erow.attr('data-name');

   if (jQuery.trim(aname)!='') {          // removing existing asset
    if (assetsUsed['list'].hasOwnProperty(aname)) {
       let a1=assetsUsed['list'][aname];        // appears in portfolio/entryy
       if (a1['entries']>0)  {            // entries  (all portfolios inits and mods)
         let q=confirm('The asset ('+aname+') appears in '+a1['entries']+' portfolios entries. If you remove it, these portfolios will be unusable! Are you sure? ');
         if (!q) return 1;
       }
      }
    }

    let aremoves=$('#assetsTable').data('removes');

    if (aremoves.hasOwnProperty(aname)) {
       erow.css({'opacity':1.0});
       delete aremoves[aname];
    } else {
       aremoves[aname]=1;
       erow.css({'opacity':0.2});
       let aamess='After specifying new assets to add, and existing assets to remove -- click  <button><b>Save!</b></button>';
       aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em> <button class="csaveButton" onClick="showAssetTable(this)">reload the assets list </button> <em>without making these changes!</em>';
       $('#assetTablePreview').html(aamess);
    }
    $('#assetsTable').data('removes',aremoves);


}

//====================
// copy an asset history row
function copyARowAssetHistory(athis) {
  let ethis=wsurvey.argJquery(athis);
  let etr=ethis.closest('.assetHistoryRow');
  let uStuff1=etr.data('useStuff');
   addARowAssetHistory(0,uStuff1,1,etr) ;

//  aetr2.data('useStuff','u1);
//  let newtr=etr.clone();
//   etr.after(newtr);
//   alert(newtr.prop("outerHTML"));
//  let einputs=newtr.find('input');

}

//====================
// remove row  from  asset history,
function removeARowAssetHistory(athis,isNew) {

   let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('tr');

  let aname=ethis.attr('data-name');

   if (isNew==1)  {  // new row, just remove it
      erow.remove();
      return 1;
   }

    let aremovesH=$('#assetHistory1').data('removesHistory');

    let edate=erow.find('[name="assetDateValue"]');
    let jdate=edate.val();
    if (aremovesH.hasOwnProperty(jdate)) {
       erow.css({'opacity':1.0});
       erow.attr('data-remove',0);
       delete aremovesH[jdate];
    } else {
       aremovesH[jdate]=1;
       erow.css({'opacity':0.2});
       erow.attr('data-remove',1);
       let aamess='After specifying new asset history entries, and existing asset history entries to remove -- click  <button><b>Save!</b></button>';
       aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em> ';
       aamess+=' <button  data-name="'+aname+'" class="csaveButton"  data-sayname="'+aname+'"  onClick="showAssetHistory1(this)">reload the asset history </button> <em>without making these changes!</em>';
       $('#assetTableHistoryPreview').html(aamess);
    }
    $('#assetHistory1').data('removesHistory',aremovesH);

}


//======================
// show values of assets (history)
function showAssetHistory(athis)   {
  let anames=[];
  let ethis=wsurvey.argJquery(athis);
  let use1=ethis.wsurvey_attr('data-name','*');
  let use1Say='';
  let adescs={},saynames={},saytypes={} ;
  let gotit=0;
  for (let daname in assetLookup) {
    anames.push(daname);
    saynames[daname]=doAssetLookup(daname,'sayname');
    let type1=getAssetType(daname,'icon');

    saytypes[daname]=type1;

    adescs[daname]=doAssetLookup(daname,'desc');
    if (daname==use1) {             // pre selected asset to use
       gotit=1;
       use1Say=doAssetLookup(daname,'sayname');
    }
  }
  let amess='' ;


  amess+='<div style="background-color:tan;font-weight:600">';
  amess+='<button title="Return to list of assets" onClick="showAssetTable(this)"> &#8617;&#65039;</button>  ';
  amess+='Date-specific asset attributes (price/interest rate/dividends). ';
  amess+='Click an <button>assetName</button> to view &amp; modify. ';
  amess+='Click an <button style="background-color:lime">assetName</button> to initialize.';
  amess+='</div>';

  amess+='<div style="max-height:7em;border:3px solid pink;overflow:auto"><ul class="linearMenu22Pct">';
  let say1,aa1,nHistory,adesc,firstEntryDate ;
  for (let i1=0;i1<anames.length;i1++) {
      nHistory=0;
      aa1=anames[i1];
      say1=saytypes[aa1]+' '+saynames[aa1];
      adesc=adescs[aa1] ;
      if (!assetHistory.hasOwnProperty(aa1) || assetHistory[aa1].length==0 )  {
        nHistory=0;
        firstDateDay='';
      } else {
         nHistory=assetHistory[aa1].length;
         let d0=assetHistory[aa1][0]['date'];
         let oof=setEntryDate(d0);
         firstEntryDate=oof['sayDate'];
      }
      if (nHistory>0) {
        amess+='<li><input type="button" value="'+say1+'" data-name="'+aa1+'"    data-sayname="'+say1+'"  data-init="0"  ';
        amess+='  onClick="showAssetHistory1(this)" title="'+adesc+'\nView/set this asset value"> ';
        amess+='<span title="Date of first entry /  # entries " class="cAssetHistoryShow">'+firstEntryDate+' / '+nHistory+' </span>';
        amess+='</li>';
      } else {
        amess+='<li><input type="button" data-init="1" value="'+say1+'" data-name="'+aa1+'"  style="background-color:lime"   data-sayname="'+say1+'"  ';
        amess+='  onClick="showAssetHistory1(this)" title="'+adesc+'\nInitialize this asset value"> (no entries) </li>';
      }
  }
  amess+='</ul></div>';

  amess+='<div id="mainDiv3a"></div>';


  $('#mainDiv3').html(amess);

   wsurvey.wsShow.hide('#mainDiv1');
   wsurvey.wsShow.hide('#mainDiv2');
   
   wsurvey.wsShow.show('#mainDiv','show');
   wsurvey.wsShow.show('#mainDiv3','show');

  if (gotit==1)  {
     showAssetHistory1(1,use1,use1Say);
  }


}

//===========
// show asset value history  -- of a chosen asset
function showAssetHistory1(athis,aname,sayName,ahistory,adesc) {
   let isInit;

   if (arguments.length==1)  {
     let ethis=wsurvey.argJquery(athis);
     aname=ethis.attr('data-name');
     isInit=ethis.attr('data-init');
   }  else {
      isInit=0;
   }
   if (arguments.length<4) {
      ahistory= (assetHistory.hasOwnProperty(aname)) ? assetHistory[aname]: []  ;
   }

   let aIcon=getAssetType(aname,'icon');
   let sayAsset=getAssetType(aname,1);
   let assetType=getAssetType(aname);

   if (arguments.length<3) sayName=doAssetLookup(aname,'sayname');

   let autoAddEntries=0;
   let autoAddChecked=' ',autoAddWas=0,taxFreeFrac=0,lossesOffsetIncome=0 ;
   if (arguments.length<4) {
      autoAddEntries=doAssetLookup(aname,'autoAddEntries');
      autoAddChecked=' ',autoAddWas=0 ;
      if (autoAddEntries==1)  {
        autoAddChecked=' checked ' ;
        autoAddWas=1;
     }
     taxFreeFrac=doAssetLookup(aname,'taxFreeFrac',1);
     lossesOffsetIncome=doAssetLookup(aname,'lossesOffsetIncome',1);
     adesc=doAssetLookup(aname,'desc');

   }      // arguemnets < 4


  let amess='';
   amess+='<div id="assetTableHistoryPreview" class="cassetTableHistoryPreview"></div>';
   amess+='<div class="cassetsTable">';
  amess+='<table  border="1" id="assetHistory1" width="95%"  >';
  amess+='<tr class="headerRow">';

  amess+='<td width="15%" >   ';
    amess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#showAssetHistoryHelp1">&#10068;</button> ';
   amess+='<input type="button" value="&neArr;" title="View in a new window"  data-id="mainDiv3a" onClick="displayInWindow(this)"> ';
    amess+='  <button class="cdoButtonTan" title="Click to add a new row" data-bond="'+assetType+'" data-name="'+aname+'" onClick="addARowAssetHistory(this)">Add</button>';
   if (isInit==1)   amess+=' <button  title="Copy the history of an existing asset " data-name="'+aname+'" onClick="copyAsset(this)">Copy</button>';
    amess+=' <button class="csaveButton" title="Save this asset history  " data-name="'+aname+'" onClick="saveAssetHistory(this)">Save!</button>';
  amess+='</td>';

  amess+='<td width="20%" > '
    amess+='<span   title="'+adesc+'" class="choiceNameSay">'+aIcon+' <u>'+sayName+'</u> </em></span> ';
    if (assetType==1 || assetType==3 || assetType==4) {
        let atmp=(taxFreeFrac===false || taxFreeFrac==='false') ?  0.0 : taxFreeFrac ;
        amess+='<span title="The tax free fraction (0.0: fully taxed, 1.0: not taxed"  class="ctaxFreeFrac">'+atmp+'</span> ';
    }
    if (assetType==3 || assetType==4)   {
      if (lossesOffsetIncome==1) {
         amess+='<span title="Negative values offset other income (hence reduce total taxes)" class="ctaxOffset">&ltcir;</span> ';
      }
    }

  amess+='</td>';

// fields in this col depend on assettype
  let amess1='missing assetType';
  if (assetType==0)  {              // stock: price and dividend.    basis is set on a portfolio specific bais
    amess1='<span class="cshowAssetHistory1_afield" title="Share price">Price</span> ';
    amess1+='<span class="cshowAssetHistory1_afield" title="Dividend (dollars per year)">Dividend</span> ';

    amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  adjusting `price` and `dividend` using inflation">';
      amess1+='<input  type="checkbox" '+autoAddChecked+'  name="autoAddEntries" data-was="'+autoAddWas+'" value="1" > autoAdd entries after final?';
    amess1+='</label></span>';


  } else if (assetType==1) {        // bond reguar       taxFreeFrac set when asset created
    amess1='<span class="cshowAssetHistory1_afield" title="Interest rate (per year, as a percent). Example: 5=5%  ">Interest</span> ';
    amess1+='<span class="cshowAssetHistory1_afield" title="Additions (per year, as a dollar amount).Negative values for withdrawals\nExample: 1000 for a $1000 addition per year; -2500 for $2500 withdrawals">Additions</span>';
    amess1+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=interest earnings are tax free)">taxFreeFrac</span>';

    amess1+='<span  class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  adjusting `addition` using inflation">';
      amess1+='<input  type="checkbox" '+autoAddChecked+'  data-was="'+autoAddWas+'" name="autoAddEntries" value="1" > autoAdd entries after final?';
    amess1+='</label></span>';

  } else if (assetType==2) {          // tax deferred
    amess1='<span class="cshowAssetHistory1_afield" title="Interest rate (per year, as a percent). Example: 5=5%\nReminder: interest earnings are tax deferred">Interest</span>';
    amess1+='<span class="cshowAssetHistory1_afield" title="Additions (per year, as a dollar amount).  Negative values for withdrawals\nExample: 1000 for a $1000 addition per year; -2500 for $2500 withdrawals">Additions</span>';
    amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  adjusting `addition` using inflation">';
      amess1+='<input  type="checkbox"  '+autoAddChecked+'  data-was="'+autoAddWas+'" name="autoAddEntries" value="1" > autoAdd entries after final?';
    amess1+='</label></span>';

// 2 august 2023.  this is never used if adding publicAsset
  } else if (assetType==3) {          // property
    amess1='<span class="cshowAssetHistory1_afield" title="Sales price">salePrice</span> ';
    amess1+='<span class="cshowAssetHistory1_afield" title="Rent (earnings - costs), dollars per year)">Rent</span> ';

    amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  adjusting `income` using inflation"  >';
      amess1+='<input  type="checkbox"  '+autoAddChecked+'  data-was="'+autoAddWas+'" name="autoAddEntries" value="1" > autoAdd entries after final?';
    amess1+='</label></span>';

// 2 august 2023.  this is never used if adding publicAsset
  } else if (assetType==4) {          // income
    amess1='<span class="cshowAssetHistory1_afield" title="Yearly income (pre tax). Dollars per year">income</span> ';
    if (doAssetLookup(aname,'constantIncome','i')==1) {
       amess1+='<span class="cshowAssetHistory1_afield" title="The per year growth rate -- as a fraction of inflation -- (of this `fixed once acquired` income)\n 0.0: no growth, 1.0: grow at inflation rate">Growth</span> ';
    } else {
       amess1+='<em>Varying...</em>';
    }

    amess1+='<span class="caddAsset_addAfter" >';
      amess1+='<label title="autoAdd entries (after final entry)\ ...  adjusting `price` and `Rent`  using inflation"  >';
      amess1+='<input  type="checkbox" '+autoAddChecked+'   data-was="'+autoAddWas+'" name="autoAddEntries" value="1" > autoAdd entries after final?';
    amess1+='</label></span>';


//    amess1+='<span class="cshowAssetHistory1_afield" title="Cost to acquire income stream. One time dollar amount.">acquisitionCost </span>';
  }
  amess+='<td width="35%">'+amess1+'</td>';

  amess+='<th width="30%"  > <span title="Comment">Comment </span>';
  amess+='<div style="font-weight:500;color:blue;display:none" id="assetHistory1_comment_a"></div>';
  amess+='</th>';
  amess+='</tr>';

  let useStuffs={};
  for (let a1 in ahistory) {
    let anasset=ahistory[a1];

    let adate=parseInt(anasset['date'])   ;

    amess+='<tr class="assetHistoryRow"  data-which_hist="'+a1+'" data-date="'+adate+'"  data-remove="0"   >';
    amess+='<td><span class="cNameSay">';
    amess+='<input type="button" data-name="'+aname+'" value="Copy" title="Copy this row " onClick="copyARowAssetHistory(this,0)"> ';
    amess+='<input type="button" data-name="'+aname+'" value="Remove" onClick="removeARowAssetHistory(this,0)">';
    amess+='</span></td>';
    amess+='<td>';

    let oof=setEntryDate(adate);
    let jyear=oof['year'];
    let jday=oof['day'];
    let jmonth3=oof['month3'];

    amess+='<input type="hidden" name="assetDateValue" value="'+adate+'"> ';
    amess+='<span name="assetDateYear"  title="Day count='+adate+'" >'+jyear+'</span> / ';
    amess+='<span name="assetDateMonth"  >'+jmonth3 +'</span> / ';
    amess+='<span name="assetDateDay"  >'+jday+'</span>';
    amess+='</td>';

   let  useStuff=anasset;
   useStuff['name']=aname;
   useStuff['year']=jyear;
   useStuff['month']=oof['month'];
   useStuff['day']=jday;
   useStuffs[a1]=useStuff;

  let arow= addARowAssetHistory(0,useStuff);

    arow+='<td width="30%"><span name="assetComment"">'+anasset['comment']+'</span></td>';

    amess+=arow+'</tr>';
  }
  amess+='</table></div>';

  let emain=  $('#mainDiv3a');
  emain.html(amess);

  let ehist=$('#assetHistory1');
  let etrs2=ehist.find('[data-which_hist]');

  for (let iee=0;iee<etrs2.length;iee++) {
     let aetr2=$(etrs2[iee]);
     let j1=aetr2.attr('data-which_hist');
     let u1=useStuffs[j1];
     aetr2.data('useStuff', u1);
  }

  $('#assetHistory1').data('removesHistory',{});  // reset every time table is displayed

   wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.show('#mainDiv3','show');


}


//=================

// a row to the history of a particluar asset
// either called by Add button, or from copyAsset1
//

function addARowAssetHistory(athis,useStuff,forceAdd,addAfter) {

    if (arguments.length<4) addAfter=false;
    let amess='',aname,isExist=0,isReadonly='' ;
    if (arguments.length<2) {

        let ethis=wsurvey.argJquery(athis);
        aname=ethis.attr('data-name');
        useStuff={};
        useStuff={'assetPrice':'','assetInterest':'','assetDividend':'','assetNetRent':'','assetAddition':'',
                     'assetSalePrice':'','assetIncome':'','comment':'','assetIncomeConstant':0,'assetIncomeGrowth':0};
        let oof=setEntryDate(true);
        useStuff['year']=oof['year'];
        useStuff['day']=oof['day'];
        useStuff['month']=oof['month'];
    } else {
        if (arguments.length<3) forceAdd=0;
        isExist=1;
        aname=useStuff['name'];
        if (forceAdd==0) isReadonly=' readonly  style="opacity:0.6" ';

    }
    let  assetType=getAssetType(aname);

    if (isExist==0 || forceAdd==1) {
       amess+='<tr class="assetHistoryRow assetHistoryRowNew"  >';
       amess+='<td><input type="button" value="Remove row ... " onClick="removeARowAssetHistory(this,1)"></span></td>';
       amess+='<td> ';
       amess+='    Y:<input type="text"  name="assetDateYear" size="4" title="year" value="'+useStuff['year']+'" >  ';
       amess+='    M:<input type="text"  name="assetDateMonth" size="4" title="Month: 1 ... 12, or Jan ... Dec" value="'+useStuff['month']+'" >  ';
       amess+='    D:<input type="text"  name="assetDateDay" size="4" title="Day of month"  value="'+useStuff['day']+'" >';
       amess+='</td>';
    }

    let amess1;
    if (assetType==0)   { // stock
      amess1='<span class="cshowAssetHistory1_afield">Price: <input '+isReadonly+' type="text" name="assetPrice"  value="'+useStuff['assetPrice']+'" size="5" title="Price per `share` (in $)."   ></span>';
      amess1+='<span class="cshowAssetHistory1_afield">Dividend: <input '+isReadonly+' type="text" name="assetDividend"  value="'+useStuff['assetDividend']+'" size="5" title="Yearly dividend per `share` (in $)."   ></span>' ;

    } else if (assetType==1) {          //regular bond
      amess1='<span class="cshowAssetHistory1_afield">Interest: <input '+isReadonly+' type="text" name="assetInterest"  value="'+useStuff['assetInterest']+'" size="5" title="Yearly interest rate per `share`, as percent.\nExample: 4.0 for 4% growth per year"   ></span>';
      let anAddition = (!useStuff.hasOwnProperty('assetAddition') || jQuery.trim(useStuff['assetAddition'])=='') ? 0 :   parseInt(useStuff['assetAddition'])  ;
      amess1+='<span class="cshowAssetHistory1_afield">Addition: <input '+isReadonly+' type="text" name="assetAddition"  value="'+anAddition+'" size="5" title="Yearly additions (if negative, withdrawals)" ></span>';
     let tta=doAssetLookup(aname,'taxFreeFrac',1).toFixed(3);
      amess1+='<span class="ctaxFreeFrac" title="tax free fraction (1.0=interest earnings are tax free)">'+tta+'</span>';

    } else if (assetType==2) {          //tax deferred bond
      amess1='<span class="cshowAssetHistory1_afield">Interest: <input '+isReadonly+' type="text" name="assetInterest"  value="'+useStuff['assetInterest']+'" size="5" title="Yearly (tax free) interest rate per `share`" ></span>';
      let anAddition = (!useStuff.hasOwnProperty('assetAddition') || jQuery.trim(useStuff['assetAddition'])=='') ? 0 :   parseInt(useStuff['assetAddition'])  ;
      amess1+='<span class="cshowAssetHistory1_afield">Addition: <input '+isReadonly+' type="text" name="assetAddition"  value="'+anAddition+'" size="5" title="Yearly additions (if negative, withdrawals)" ></span>';

    } else if (assetType==3) {          // property
      amess1='';
      if (isExist!=1) amess1='<button onClick="specifyLoanSchedule(this)" data-aname="'+aname+'" class="cdoButton" title="View a loan worksheet">Loan?</button> ';
      amess1+='<span class="cshowAssetHistory1_afield">Price: <input '+isReadonly+' type="text" name="assetSalePrice"  value="'+useStuff['assetSalePrice']+'" size="6" title="Proceeds from sales: price - amount owed (i.e.; principal due)"   ></span>';
      amess1+='<span class="cshowAssetHistory1_afield">Rent: <input  '+isReadonly+'  type="text" name="assetNetRent"  value="'+useStuff['assetNetRent']+'" size="6" title="Yearly net rent (earnings - costs). Typically does NOT include mortgage payments. Can be negative" ></span>';


    } else if (assetType==4) {          // income stream
       let isConstant=doAssetLookup(aname,'constantIncome','i');

       let aGrowth=(useStuff.hasOwnProperty('assetIncomeGrowth')) ?  useStuff['assetIncomeGrowth'] : 0 ;
       amess1='<span class="cshowAssetHistory1_afield">Income: <input '+isReadonly+'   type="text" name="assetIncome"  value="'+useStuff['assetIncome']+'" size="6" title="Yearly income  (i.e; from an annuity)"   ></span>';

       if (isConstant==1) {
         if (isExist==0) {
            amess1+='<span class="cshowAssetHistory1_afield">Growth (fraction of inflation): <input '+isReadonly+'   type="text" name="assetIncomeGrowth"   value="" ';
            amess1+=' size="3" title="Growth rate IF `fixed` income, as a fraction of inflation  (i.e; social security COLA adjustments). For example: 1.0 for `keep up with inflation` "   ></span>';
         } else {
            amess1+='<span class="cshowAssetHistory1_afield">growth (fraction inflation): <input '+isReadonly+'   type="text" name="assetIncomeGrowth" readonly value="'+aGrowth+'" ';
            amess1+=' size="3" title="Growth rate IF `fixed` income  (i.e; social security COLA adjustments). For example: 0.660 for 2/3 of inflation"   ></span>';
          }
         } else {
            amess1+='&hellip; <input type="hidden" name="assetIncomeGrowth" value="0">  ';
         }

    }
    amess+='<td>'+amess1+'</td>';

    if (isExist==1 && forceAdd==0) {
       return amess;
    }
    amess+='<td><input type="text" name="assetComment" size="50"  value="'+useStuff['comment']+'" title="optional comment"></td>';
    amess+='</tr>';

    if (addAfter===false) {
       $('#assetHistory1').append(amess);
    } else {
        addAfter.after(amess);
    }

    if (arguments.length<2) {   // button click (not a load exsiting assets)
       let aamess='After specifying new asset history entries, and existing asset history entries to remove -- click  <button><b>Save!</b></button>';
       aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em>';
       aamess+=' <button  data-name="'+aname+'" class="csaveButton"     onClick="showAssetHistory1(this)">reload the asset history </button> <em>without making these changes!</em>';
       $('#assetTableHistoryPreview').html(aamess);
    }
}

//=====================    
function addARowAssetHistory_incomeConstant(athis) {
  let ethis=wsurvey.argJquery(athis);
  let etd=ethis.closest('.cshowAssetHistory1_afield');
  let ival=(ethis.prop('checked')) ? 1 : 0 ;
  let einput=etd.find('[name="assetIncomeConstant"]');
  einput.val(ival);
  let etr=ethis.closest('.assetHistoryRowNew');
  let eg=etr.find('[name="assetIncomeGrowth"]');
  if (ival==0) {
      eg.prop('disabled',true);
      eg.val('');
  } else {
     eg.prop('disabled',false);
  }

}

//===========        isExist
// save asset history  -- a particular asset
// assetDateYear   assetDateMonth    assetDateDay
//  assetPrice    assetDividend    assetInterest assetAddition  assetSalePrice  assetNetRent assetApprecation   assetIncome assetComment

function saveAssetHistory(athis) {
  let ethis=wsurvey.argJquery(athis);
  let aname=ethis.attr('data-name');
  let assetType=getAssetType(aname);

// get list of existing eddats
  let eTable=$('#assetHistory1');
  let eExist=eTable.find('[data-which_hist]');

  let existDates={};              // get list of existing dates in this assethistory
  for (let k1=0;k1<eExist.length;k1++) {
       let ae1=$(eExist[k1]);
       let adate=ae1.attr('data-date');
       let isremove=ae1.attr('data-remove');
       if (isremove!=1)  existDates[adate]=1;
  }

  let varList=['assetPrice','assetDividend','assetInterest', 'assetSalePrice','assetNetRent','assetIncome'];
  let gotems=[] ;
  gotems[0]=['assetPrice','assetDividend'];
  gotems[1]=['assetInterest','assetAddition'];
  gotems[2]=['assetInterest','assetAddition'];
  gotems[3]=['assetSalePrice', 'assetNetRent' ];
  gotems[4]=['assetIncome','assetIncomeGrowth'];

  let stuff=[];
   let etable=$('#assetHistory1');
   let etrs=etable.find('.assetHistoryRowNew');

   let aremoves=[];
   let removes0=etable.data('removesHistory');
   for (let aa in removes0) aremoves.push(aa);

   let newdates={};

   for (let j1=0;j1<etrs.length;j1++) {     // read new entries

      let aetr=$(etrs[j1]);
      let e2=aetr.find('[name="assetDateYear"]')
           let ayear=fixString(jQuery.trim(e2.val()),1);
      e2=aetr.find('[name="assetDateMonth"]')
           let amonth=fixString(jQuery.trim(e2.val()),1);
       e2=aetr.find('[name="assetDateDay"]')
           let aday=fixString(jQuery.trim(e2.val()),1);
       let adate=setEntryDate(ayear,amonth,aday);
       if (adate===false) return  0;  //  bad date (alert done in setEntryDate

       let dcount=adate['dayCount'];
       if (existDates.hasOwnProperty(dcount)) {
            alert('You have an existing entriy with the date: '+adate['sayDate']+'. You must Remove it');
            return 0;
       }

       if (newdates.hasOwnProperty(dcount)) {
            alert('You have two new entries with the same date: '+adate['sayDate']);
            return 0;
      }
      newdates[dcount]=1;

      let saveVals=[];
      for (let jj=0;jj<varList.length;jj++) saveVals[varList[jj]]=0;


      let doits=gotems[assetType];

      for (let id=0;id<doits.length;id++) {
             agot=doits[id];
             e2=aetr.find('[name="'+agot+'"]') ;
             let aval0=jQuery.trim(e2.val());
             if (aval0==='')    {
                  alert('For '+adate['sayDate']+': '+agot+' not specified ');
                  return 0;
              }
              aval=fixNumberValue(aval0);
              if (aval===false) {
                  alert('For '+adate['sayDate']+': '+agot+' is not a number: '+aval0);
                  return 0;
              }
              aval=parseFloat(aval);
              saveVals[agot]=aval;
       }   // doits

       let ec=aetr.find('[name="assetComment"]')  ;
       let acomment=jQuery.trim(ec.val());
       let arow={'date':adate['dayCount'], 'comment':acomment };
       for (let zz in saveVals) arow[zz]=saveVals[zz]
       stuff.push(arow);

   }
// auto add?
   let changeAutoAdd=0;
   let eauto=etable.find('[name="autoAddEntries"]');
   let iwas=eauto.attr('data-was');
    autoAddEntries= (eauto.prop('checked')) ? 1 :  0;
    if (autoAddEntries!=iwas) changeAutoAdd=1


  if (aremoves.length==0 && stuff.length==0 && changeAutoAdd==0) {
     alert('No asset history entries were added, or removed');
     return 0;
  }

  let ddata={};
  ddata['todo']='saveAssetHistory';
  ddata['list']=stuff;
  ddata['removes']=aremoves;
  ddata['autoAddEntries']=autoAddEntries ;
  ddata['asset']=aname;
  ddata['username']=userName ;
  ddata['encMd5']=encryptionKey_md5;

  saveSimInvData(ddata);

}


// more simIvn functions



//=================
// copy an existing asset's history to an asset (an event handler)
// note (3 july 2023):
// this an event handler is only available  unintialized assets -- and the user must click the "lime" button  in the
// list of buttons (the shortcut to init an asset, from the "n assets" page) doesn't add this button

function copyAsset(athis) {
  let ethis=wsurvey.argJquery(athis);
  let aname0=ethis.attr('data-name');
  let amess='';
 
  amess+='<em>Which existing asset should be <em>copied</em> ...';
  amess+='<ul class="linearMenu16Pct">';
  for (let aname in assetLookup) {
     if (aname0==aname) continue ; // can't copy own self
//     let aa1=assetLookup[aname];
     let atype=doAssetLookup(aname,'assetType','i');
     let aicon=getAssetType(atype,'icon');
     adesc=doAssetLookup(aname,'desc');
     amess+='<li> <button title="'+adesc+'" onClick="copyAsset1(this)" data-forname="'+aname0+'" data-name="'+aname+'">'+aicon+' '+aname +'</button>';
  }
  amess+='</ul>';
  displayStatusMessage(amess);

}

//=================
// copy an existing asset's history to an asset
// step 2: asset chosen... so copy its rows

function copyAsset1(athis) {

  let ethis=wsurvey.argJquery(athis);

  let aname=ethis.attr('data-name');     // the asset to copy from  -- user selected from list of assets
     let anameType=getAssetType(aname);
     let anameSay=getAssetType(aname,'saysimple');

  let forName=ethis.attr('data-forname');  // the asset being specified (aname's value will be used )
    let aforNameType=getAssetType(forName);
    let forNameSay=getAssetType(forName,'saysimple');

  displayStatusMessage(false);  // hide status message box

  if (anameType!=aforNameType) {
     qq=confirm('The asset to be copied '+aname+' ('+anameSay+') does not match the type of '+forName+' ('+forNameSay+'). Are you sure you want to use it?');
     if (!qq) return 0;
  }

 for (let ii=0;ii<assetHistory[aname].length;ii++) {
   uStuff=assetHistory[aname][ii];

   let oof1=setEntryDate(parseInt(uStuff['date']));
    uStuff['name']=aname;
    uStuff['year']=oof1['year'];
    uStuff['month']=oof1['month'];
    uStuff['day']=oof1['day'];
    uStuff['price']=uStuff['assetPrice'];
    uStuff['interest']=uStuff['assetInterest'];
    uStuff['dividend']=uStuff['assetDividend'];
    uStuff['comment']=uStuff['comment']  ;
    addARowAssetHistory(0,uStuff,1) ;
 }

 wsurvey.wsShow.hide('#statusDiv',200);

  $('#assetHistory1_comment_a').html('Copied from asset: <u>'+aname+'</u>').show();
}

