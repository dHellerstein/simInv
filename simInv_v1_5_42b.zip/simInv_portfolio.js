// portfolio, and portfolio mod, functions


//=============
// show portfolio table, and allow adding new portfolio
function showPortfolioTable(athis) {
  let amess='';

  amess+='<div style="background-color:tan;font-weight:600">';
  amess+='<input type="button" value="x" onClick="wsurvey.wsShow.hide(this,200)" data-wsShow="#mainDiv3"> ';
  amess+='<span class="biggerName">Portfolios</span> ';

  amess+=' <em>You can  </em> <button class="cdoButtonTan" onclick="addARowPortfolio(this)">Add</button> new <em>or</em> ';
  amess+=' <button>Remove </button>  existing &hellip; ';
   amess+=' and then <button   title="Save your changes" >Save!</button>   ';
   amess+='&boxV;  ';
   amess+='<em>Or </em> ...  ';
  amess+=' <button>&#128301;</button> view  asset mix. &boxv; ';
  amess+='<input type="button" value="&#128393;">Modify  asset mix  &boxv;  ';
  amess+=' <button style="background-color:lime">Init</button> initialize an asset mix &boxv; ';
  amess+=' <span class="cnAssetsInPortfolio" title="n: # of assets in this portfolio" >&#128065;</span>Preview asset mix</span>  ';
  amess+='</div>';

  amess+='<div id="portfolioTablePreview" class="cportfolioTablePreview"></div>';

  amess+='<table  border="1" id="portfolioTable" width="95%"   class="cportfolioTable">';

  amess+='<tr class="headerRow">';

  amess+='<td width="15%" ><button class="cdoButtonTan"  title="Click to add a new row" onClick="addARowPortfolio(this)">Add</button>';
    amess+=' <button class="csaveButton" title="Add new, or remove existing,  portfolios" onClick="saveAllPortfolios(this)">Save!</button>';
  amess+='</td>';

  amess+='<th width="18%" > <span class="choiceNameSay">Name</span> ';
    amess+='<button title="Tips" onClick="wsurvey.wsShow.show(this)" data-wsShow="#portfolioTableHelp1">&#10068;</button>';
  amess+='</th>';
  amess+='<th width="27%"  > <span title="Short description">Desc</span></th>';
  amess+='<th width="40%"  > <span title="Long description">DescLong </span></th>';
  amess+='</tr>';

  amess+='<tr id="portfolioTableHelp1" style="display:none" >';
  amess+='<td  >&hellip;</td>';
  amess+='<td colspan="4">';
  amess+='<ul><li><b>Name</b>:a short name.<br>';
  amess+='It can <u>not</u> contain any of the following characters:<tt> ';
  amess+=' embedded spaces, commas, %,  &, +, *, /, \\, \', ", `, #, !, $, <, >, </tt> or  <tt> | </tt>' ;
  amess+='<br>The Name can include a <tt>family</tt> and (optionally) a <tt>scenario</tt>. Example: <span style="border:1px solid black"><tt><b>mystocks</b>. <em>goodTimes</em></tt></span>';

  amess+='</tt>';
  amess+='<li><b>Desc</b> a several word phrase describing this portfolio.';
  amess+='<li><b>DescLong</b> a longer description (no html)';
  amess+='</td> ';
  amess+='</tr>';

  for (let a1 in portfolioList) {

    let aportfolio=portfolioList[a1];
    let pname=aportfolio['name'];
    let exists=aportfolio['exists'] ; // 0= not initialized

    let isInit=0,nHistory=0;
    if (exists==1) {
       alookup=portfolioLookup['list'][pname];
         isInit=alookup['isInit'];
         nHistory=alookup['modDates'].length ;
    }
    amess+='<tr class="portfolioRow" data-name="'+pname+'">';
    amess+='<td><span data-_sortUse="'+nHistory+'"  ><input type="button" value="Remove" title="remove this portfolio" onClick="removePortfolioRow(this,1)"></span>';

    if (isInit>0) {
      let  nHist2=nHistory-1;
      if (nHist2>0) {
        amess+='<input type="button" value="&#128301; '+nHistory+'" title="View  the initial, or '+nHist2+' modifications,  asset mix(es) of this portfolio\nAnd you can add a modification! "  ';
        amess+='     data-name="'+pname+'" onClick="showPortfolioViewModify(this,1)"  >';
      } else {
        amess+='<input type="button" value="&#128301; '+nHistory+'" title="View   the initial  asset mix(es) of this portfolio\nAnd you can add a modification! "  ';
        amess+='     data-name="'+pname+'" onClick="showPortfolioViewModify(this,1)"  >';
      }

      amess+='<input type="button" value="&#128393;"  title="Shortcut: modify the asset mix of this portfolio  "  ';
      amess+='     data-name="'+pname+'" onClick="showPortfolioViewModify(this,3)"  >';

    } else {
      amess+='<input type="button" style="background-color:lime" value="&#9998;Init" title="Initialize this portfolio (what assets it contains)"  ';
      amess+='     data-name="'+pname+'" onClick="buildPortfolioMenu(0,this)"  >';    // will fill the menu with default vaules
    }
    amess+='</td>';

    amess+='<td data-_sortuse="'+pname+'"><span name="portfolioName" data-name="'+pname+'" data-dog="snappy" class="cNameSay">';

    let xaname=getAssetFamily(pname,1);
    let pnameSay='<b>'+xaname['family']+'</b>';
    if (xaname['scenario']!='')  pnameSay+='. <span title="The scenario"><em>'+xaname['scenario']+'</em></span>';

    amess+=pnameSay;
//    amess+=pname;


    let cdateSay='',cdate=0 ;

    if (nHistory>0) {
      cdate=portfolioInit[pname]['dateStamp'];
      cdateSay=portfolioInit[pname]['dateStampSay'];

      let jassets=portfolioInit[pname]['totals']['nAsset'] ;

       amess+=' <button  value=""   title="Preview: assets & incomeStream in the assets" onClick="showPortfolioTablePreview(this)" data-name="'+pname+'" > ';
       amess+='&#128065;'+jassets;
       if (portfolioInit[pname]['totals']['nIncome']>0) amess+=' <span style="color:green;font-size:90%" title="income streams "> &amp;'+portfolioInit[pname]['totals']['nIncome']+'</span> ';
       amess+='</button>';
       amess+=' <span  style="float:right;margin-right:1em;font-size:80%;font-weight:500;font-style:oblique">'+cdateSay+'</span>';
    }


//    if (someMissing!='') amess+='<div>'+someMissing+'</div>';   // 11 JUNE fix this

    amess+='</td>';

// shor desc
    amess+='<td data-_sortuse="'+cdate+'"><span name="portfolioDesc"  class="cDescSay">'+aportfolio['desc']+'</span></td>';


// long desc and portfolio list
    amess+='<td><div name="portfolioDescLong" class="cDescLongSay">  '+aportfolio['descLong']+'</div>';
    amess+='</td>';
    amess+='</tr>';
  }
  amess+='</table>';
  $('#mainDiv3').html(amess);
  $('#portfolioTable').data('removes',[]);  // reset every time table is displayed

  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv1');
  wsurvey.wsShow.hide('#mainDiv2');
  wsurvey.wsShow.show('#mainDiv3','show');

    wsurvey.sortTable.init('portfolioTable',{'skipCols':3})

}


//=======================
// preview assets in a portfolio, using basic info

function showPortfolioTablePreview(athis) {
   let ethis=wsurvey.argJquery(athis);
   let pname=ethis.attr('data-name');
   amess='';
   apuse=portfolioLookup['list'][pname]
   let cdate=apuse['creationDate'];
 
   let origBudget=apuse['budget'];
   let totNetAssetEst=apuse['totNets'][cdate] ;
   let totNetAllSay=wsurvey.makeNumberK(parseInt(totNetAssetEst),99000);
   amess+='<input type="button" value="x" title="close this" data-wsshow="#portfolioTablePreview" onClick="wsurvey.wsShow.hide(this)"> ';
   let gg=wsurvey.addComma(parseInt(origBudget));
   amess+='Portfolio <b>'+pname+'</b>: initial asset-mix (original budget: <tt>'+gg+'</tt>).~Net value: <tt> '+totNetAllSay+'</tt>';

   let plist=portfolioInit[pname]['assets']  ;
   amess+='<ul class="linearMenu16Pct">';
   for (let aa in plist) {
      let ztype=parseFloat(plist[aa]['assetType']);
      let aicon=getAssetType(aa,'icon');
      if (ztype!=4) {
        let netVal=parseFloat(plist[aa]['netValue']);
        let netValSay=wsurvey.makeNumberK(netVal,5000,0);
        amess+='<li>'+aicon+' <u>'+aa+'</u>= <tt>$'+netValSay+'</tt>';
      } else {                      // income stream
        let aIncome=parseFloat(plist[aa]['yearlyIncome']);
        let aIncomeSay=wsurvey.makeNumberK(aIncome,10000,0);
        amess+='<li>'+aicon+' <u>'+aa+'</u>= <tt>$'+aIncomeSay+'</tt>';
      }
    }
    amess+='</ul>';
  $('#portfolioTablePreview').html(amess);
  wsurvey.wsShow.show('#portfolioTablePreview','show');
  return 1;
}

//==============
// add a portfolio
function addARowPortfolio(athis){
   let etable=$('#portfolioTable');

   let amess=''
    amess+='<tr class="portfolioRow portfolioRowNew">';
    amess+='<td> <input type="button" value="Remove this row " onClick="removePortfolioRow(this,0)"></td>';
    amess+='<td> <input type="text" size="12" name="portfolioName" value=""></td>';
    amess+='<td> <input type="text" size="42" name="portfolioDesc" value=""></td>';
    amess+='<td> <textarea rows="2" cols="50" name="portfolioDescLong"></textarea></td>';
    amess+='</tr>';
    etable.append(amess);

   let aamess='After specifying new portfolios to add, and existing portfolios to renove -- click  <button><b>Save!</b></button>';
   aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em> <button onClick="showPortfolioTable(this)">reload the portfolio list </button> <em>without making these changes!</em>';
    $('#portfolioTablePreview').html(aamess);

}


//====================
// remove row from list of portfolios
function removePortfolioRow(athis,isExist) {
   let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('tr');
   if (isExist==0)  {    // newly added, so not recored .. just remove the row
      erow.remove();
      return 1 ;
   }

// record portfolio name for transmission to server (for removal)

   let pname=erow.attr('data-name');
   let etable=$('#portfolioTable');
   let aremoves=etable.data('removes');
   aremoves.push(pname);
   etable.data('removes',aremoves);

//   erow.remove();
  erow.css({'opacity':0.2});


 let aamess='After selecting portfolios to remove, and new ones to add -- click  <button><b>Save!</b></button>';
 aamess+='&nbsp;&nbsp;&nbsp;  ... <em>or</em> <button onClick="showPortfolioTable(this)">reload the portfolio list </button> <em>without making these changes!</em>';
 $('#portfolioTablePreview').html(aamess);

}

//====================
// remove row from list of assets in the asset mix of a portfolio
function removePortfolioRowAssetMix(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-name');
   let aexists=ethis.attr('data-exists');
   let erow=ethis.closest('tr');

   if (aexists==0)  {            // new entry, just  zap it

      erow.remove();
      let elist=$('#portfolioHistoryAssetList');
      let ebuttons=elist.find('.chighlightAssetButton');
      let e1=ebuttons.filter('[data-name="'+aname+'"]');
      if (e1.length==1) {
         e1.removeClass('chighlightAssetButton');
        e1.attr('data-chosen',0);
      }
  }

// fade it (so it can be recovered easily)
  let aremove=  erow.attr('data-remove');
  if (aremove==1) {
      erow.attr('data-remove',0);
      erow.css({'opacity':1.0,'font-size':'100%'});
  } else {
      erow.attr('data-remove',1);
      erow.css({'opacity':0.2,'font-size':'70%'});
  }

}


//==============
// save the list of  portfolios: old (minus remvoed) + new
function saveAllPortfolios(athis){
   let stuff=[];
   let etable=$('#portfolioTable');
   let aremoves=etable.data('removes');
   let plist=portfolioLookup['list'];

  let etrs=etable.find('.portfolioRowNew');

   let danames={};

// the new portfolios (to add)

   for (let j1=0;j1<etrs.length;j1++) {
      let aetr=$(etrs[j1]);
      if (aetr.hasClass('portfolioRowNew')) {  // new portfolio
         let e1=aetr.find('[name="portfolioName"]')
         
         let aname0=jQuery.trim(e1.val().toLowerCase());
         if (aname0=='') {
              alert('Portfolio name not specified ');
              return 0;
         }

         if (aname0=='') continue ; // ignore blank

         let aname=fixStringRemoves(aname0);
         if (aname0!==aname) {
             alert('Improper portfolio name: `'+aname0+'`\n Use a different name without any of the following characters: embedded spaces, commas, %,  &, +, *, /, \\, \', ", #, !, $, <, >, or  | ');
             return false;
         }
         let oof=aname.split('.');
         if (oof.length>2) {           // too many .
            alert('Improper portfolio name: too many periods: '+aname0+'\n You can specify `portfolioname` or `portfolioname.scenario` ');
            return false;
        }


         if (plist.hasOwnProperty(aname)) {
            alert('Portfolio name already used ('+aname+')');
            return 0;
         }
         danames[aname]=1;

         let e2=aetr.find('[name="portfolioDesc"]')
           let adesc=fixString(jQuery.trim(e2.val()),2);
           adesc=wsurvey.removeAllTags(adesc);
         let e3=aetr.find('[name="portfolioDescLong"]')
           let adescLong= jQuery.trim(e3.val())  ;
           adescLong=wsurvey.removeAllTags(adescLong);
        let arow={'name':aname,'desc':adesc,'descLong':adescLong,'exists':0};
        stuff.push(arow)
     }   // new row
   }
  if (stuff.length==0 && aremoves.length==0) {
     alert('No portfolios were added, or removed');
     return 0;
  }
  if (aremoves.length>0) {
    let q=confirm('Are you sure you want to remove '+aremoves.length+' existing portfolios? ');
    if (!q) return 0;
  }

  let ddata={};
  ddata['todo']='saveAllPortfolios';
  ddata['list']=stuff;
  ddata['removes']=aremoves;
  ddata['username']=userName ;
  ddata['encMd5']=encryptionKey_md5;

   saveSimInvData(ddata);


}



//============
// add a row to mix of a portfolios asset
// isMod: 0 -- initialization, or adding a row to a mod;  1 - modificction
// useThese: prepopulate the row using this info (if isMod=1)
//         name:  nShares:  comment:  basis:  assetType:  cost:  price:  loanAmount:  loanTerm:  loanRate:  incomeStart:  modState:
//    useThese is   a row from assetList. Or is empty, if a new row is being added (non-pre-populated)
// modState: 0= init, 1: mod, 2: mod no change allowed
// doButton: if 1, then highlight this assets button
// jdateStamp: if ismod=1: the date of the modified entry

function addARowPortfolioAssetMix(isMod,useThese,doButton,jdateStamp)  {

   if (arguments.length<3) doButton=0;
   if (arguments.length<4) jdateStamp=false;

   let aname=useThese['name'];
//   let assetInputClasses=['stockInputClass','bondInputClass','bondInputClass','propertyInputClass','incomeInputClass'];
   let assetInputClasses=['stockInputClassSay','bondInputClassSay','bondInputClassSay','propertyInputClass','incomeInputClass'];


   let assetType=useThese['assetType'] ;
   let assetIcon=getAssetType(assetType,'icon');
   let assetSay=getAssetType(assetType,1);
   let assetSayLong=getAssetType(assetType,'sayslong');

//   let assetVars=assetLookup[aname]
   let taxFreeFrac =doAssetLookup(aname,'taxFreeFrac',1);
   let ainputClass=assetInputClasses[assetType];

    amess='';
    amess+='<tr class="portfolioHistoryRow portfolioHistoryRowNew"  data-remove="0" >';

// remove, or sell off, column
    amess+='<td  name="cell_remove" data-_sortuse="'+assetType+'" >';
    if (isMod==0) {
       amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="Remove this asset from the asset mix (of this portfolio)"  data-exists="0" ';
       amess+='    onClick="removePortfolioRowAssetMix(this)">&#10060;</button>';
    } else {         // "remove" message    depends on assetTYpe
        if (assetType==0) {
         amess+='<button data-name="'+aname+'"  style="border:1px solid gold;border-radius:4px"  data-exists="1"  ';
         amess+='    name="removeThisRowButton" title="Sell all shares" ';
         amess+='    onClick="removePortfolioRowAssetMix(this)">&#128184;</button>';
        } else if (assetType==1) {
         amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="Convert all bonds to cash "   data-exists="1"';
         amess+='    onClick="removePortfolioRowAssetMix(this)">&#128176;</button>';
        } else if (assetType==1  || assetType==2) {
         amess+='<button data-name="'+aname+'" style="border:1px solid green;border-radius:4px"   data-exists="1" ';
         amess+='      name="removeThisRowButton" title="Convert all bonds to cash (and pay a deferred tax) " ';
         amess+='    onClick="removePortfolioRowAssetMix(this)">&#128176;</button>';

        } else if (assetType==3) {
         amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="Sell the property "  data-exists="1" ';
         amess+='    onClick="removePortfolioRowAssetMix(this)">&#128184;</button>';

        } else if (assetType==4) {
          amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="End this income stream"  data-exists="1" ';
          amess+='    onClick="removePortfolioRowAssetMix(this)">&#128721;</button>';
        }
    }
    amess+='</td>';

// asset name == useThese['name'] always exists!
    amess+='<td  name="cell_name"  data-_sortuse="'+useThese['name']+'" class="'+ainputClass+'" > ';
    amess+='<input type="text" name="portfolioAsset"  readonly data-orig="'+useThese['name']+'"  value="'+useThese['name']+'" ';
    amess+='        class="portfolioAssetNameNew" size="12" title="The asset">';
    let tt1;
    tt1='<span title="'+assetSayLong+'">'+assetIcon+'</span>';

    amess+='<span class="portfolioAssetTypeNew" data-type="'+assetType+'" >';
    amess+=tt1+'</span>';

    amess+='</td>';

// # shares, etc.
    amess+='<td  name="cell_value"  data-_sortuse="'+useThese['nShares']+'"   >';
    let zzclass=' ';
    let zz1Say= (assetType==0 ) ? '&#65283; ' : '&#65284; ' ;     // 83=#,  84=$
    let tbdSay='';

    if (assetType==1)  {         // reguarl bond
         let usex=useThese['nShares'];
         if (jQuery.isNumeric(usex)) usex=parseFloat(usex).toFixed(0);

         amess+=zz1Say;
         amess+='<input type="hidden" name="modStatus" value="'+isMod+'" > ';
         amess+='<input type="text" name="portfolioShares"   size="8" data-orig="'+useThese['nShares']+'" ';
         amess+='  value="'+usex+'"   class="bondInputClass autoFillShare modReset " ' ;
         amess+=' title="$ value of bonds. Or xx% for #shares  purchased at xx% of budget.\n Hint: nnnK for nnn thousand"    >';
         amess+='<input type="button" class="smallButton" value="%" title="Specify: % of budget to spend on bonds " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
         amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,0)"  >';

         tbdSay='<div class="bondInputClass_say">'+portfolioAssets_currentInfo(aname)+'</div>';  // written to final column

    } else if ( assetType==2) {         // tax deferred bonds

         let usex=useThese['nShares'];
         if (jQuery.isNumeric(usex)) usex=parseFloat(usex).toFixed(0);

         amess+=zz1Say;
         amess+='<input type="hidden" name="modStatus" value="'+isMod+'" > ';

         amess+='<input type="button" class="smallButton"  value="$" title="Specify: pre-tax $ amount " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
         amess+='<input type="text" name="portfolioShares" size="8" data-orig="'+useThese['nShares']+'"  value="'+usex+'"   class="bondInputClass modReset" ' ;
         amess+=' title=" tax deferred bonds. "    >';
         amess+='<input type="button" class="smallButton" value="%" title="Specify: % of  budget (using pre-tax adjustment) to spend on tax-deferred bonds  " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
         amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of pre-tax dollars " onClick="addARowPortfolioAssetMix_type(this,0)"  >';

         tbdSay='<div class="bondInputClass_say">'+portfolioAssets_currentInfo(aname)+'</div>';


     } else if (assetType==0 ) {          //stock

        zz1Say+='<input type="button" class="smallButton" value="$"  title="Specify: $ amount (to spend on stock shares)" onClick="addARowPortfolioAssetMix_type(this,0)"  >';
        zz1Say+='&nbsp;';
        let usex=useThese['nShares'];
        if (jQuery.isNumeric(usex)) usex=parseFloat(usex).toFixed(2);

        amess+=zz1Say;
        amess+='<input type="hidden" name="modStatus" value="'+isMod+'" > ';
        amess+='<input type="text" data-orig="'+useThese['nShares']+'" name="portfolioShares" size="7" value="'+usex+'"    ' ;
        amess+=' title="# of shares of this stock. Or xx% for at xx% of budget. \nHint: nnnK for nnn thousand"    class="stockInputClass autoFillShare modReset"   >';
        amess+='<input type="button" class="smallButton" value="%" title="Specify: % of budget (to spend on shares)" onClick="addARowPortfolioAssetMix_type(this)"  >';
        amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars (or shares)" onClick="addARowPortfolioAssetMix_type(this)"  >';
        if (isMod==1 ) {         // modification
             amess+='<input type="hidden" name="portfolioSharesBasis" data-dog="rover2"   data-noset="1"  data-orig="'+useThese['basis']+'" value="'+useThese['basis']+'">';
             goo1=wsurvey.addComma(parseInt(useThese['basis']));
             amess+=' &nbsp; &hellip; Basis: <span class="portfolioAssetBasis" title="current value of basis" >'+goo1+'</span>';
        }      else   {  // a creation     usex
             amess+='<span class="portfolioAssetBasis"  >&#65284; &nbsp; Basis:';
             amess+='<input type="text" name="portfolioSharesBasis" data-dog="tucker"  data-orig="100%"   data-noset="0" size="7"  ';
             amess+='       value="100%"  class="stockInputClass"  ';
             amess+=' title="The basis, in $ (used in capital gains calculations).  \n Or, enter nn% (% of $ value of stock shares) -- leave blank for 100% " >';
             amess+='<input type="button" class="smallButton" value="%" title="Specify: % of stock value that is basis " onClick="addARowPortfolioAssetMix_type(this,1)"  >';
             amess+='</span>   ';
        }

        tbdSay='<div class="stockInputClassSay">'+portfolioAssets_currentInfo(aname)+'</div>';   // 90

     } else if (assetType==3 ) {          // property

        let useCost=(useThese.hasOwnProperty('acqCost')) ? useThese['acqCost'] : useThese['cost'];
        let useCostSay=useCost;
        if (jQuery.isNumeric(useCost)) useCostSay=wsurvey.addComma(parseInt(useCost));

        amess+='<div name="loanInfoDiv" >';

        amess+='<input type="hidden" name="modStatus" value="'+isMod+'" > ';


        amess+='<span title="downpayment and other upfront (acquisition) costs">$acqCost</span>: ';
        amess+=' <input type="text" data-orig="'+useCost+'"    class="propertyInputClass" ';
        amess+= ' name="portfolioShares" size="6" value="'+useCostSay+'"    ' ;
        if (isMod==1)  {        // modification
            amess+=' readonly style="opacity:0.6" ';            // one-time costs
            amess+=' title="Upfront costs are specified when portfolio was created (it can not be changed here).\nFor example, the downpayment, and closing costs, of purchasing a house. "  ';
            amess+='  >';
        } else {           // initial, or new property added during a modification
            amess+=' title="Upfront costs. For example, the downpayment, and closing costs, of purchasing a house. \nHint: nnnK for nnn thousand"  ';
            amess+='  >';
            amess+='<input type="button" class="smallButton" value="%" title="Specify: upfront payment as percent of property price " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
            amess+=' <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
         }

        if (isMod==0) {           // initial, or new addition in a modificaton, could have a loan

            amess+='<span class="portfolioAssetBasis">&#65284;Basis:';

            let oyBasis=useThese['basis'] ;
            if (jQuery.trim(oyBasis)=='' )  oyBasis='100%';
            if (jQuery.isNumeric(oyBasis)) oyBasis=wsurvey.addComma(parseInt(oyBasis)) ;

            amess+='<input type="text" name="portfolioPropertyBasis"  class="propertyInputClass"  size="5" style="font-size:100%" value="100%"    data-orig="'+oyBasis+'"   ';
            amess+=' title="The basis, in $ (used in capital gains calculations).  \n Or, enter nn% (% of $ value of property price). Leave blank for 100% " >';
            amess+='<input type="button" class="smallButton" value="%" title="Specify: % of property price  value that is basis " onClick="addARowPortfolioAssetMix_type(this,3)"  >';
            amess+=' <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,3)"  >';
            amess+='</span>   ';

            amess+='<div name="loanSpecs" style="border:2px dotted blue;padding:3px;;font-size:90%"> ';
            amess+='<button onClick="specifyLoanScheduleB(this)"  class="cdoButtonQuiet" title="View loan that uses these specs">&#128065;</button> ';
            amess+='<input type="hidden" value="'+aname+'" name="portfolioLoanName" > ';
            amess+=' $Loan: <input type="text" data-orig="'+useThese['loanAmount']+'" title="Amount of loan (in $.)\nEnter 0, or leave blank, to NOT take out a loan" name="portfolioLoanAmount" class="propertyInputClass"  size="7" value="90%"   >';
            amess+='<input type="button" class="smallButton" value="%" title="Specify: % of price (as the loan amount) " onClick="addARowPortfolioAssetMix_type(this,2)"  >';
            amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,2)"  >';

            amess+='<span style="font-size:90%;white-space:nowrap;display:inline-block;margin:1px 1px 1px 3px;padding:1px 1px 1px 5px;border-left:1px dotted blue">';
            amess+=' Term: <input type="text"  data-orig="'+useThese['loanTerm']+'" title="Term (in years\n Leave blank, or enter 0, to NOT take out a loan" name="portfolioLoanTerm" size="2" value=""  class="propertyInputClass2"  >';
            amess+=' | Rate: <input type="text" title="Interest rate as a percent. i.e.; 4.1 for 4.1%" data-orig="'+useThese['loanRate']+'" name="portfolioLoanRate" size="3" value="" class="propertyInputClass2"    >';

            amess+=' | <label>taxDed: <input type="checkbox" checked title="Interest rate payments are tax deductible" name="portfolioLoanTaxDeductInt" value="1" class="propertyInputClass2"   ></label>';
            amess+='</span>';
            amess+='</div>';

        }   else {        // ismod=1 -- loans on existing should NOT be touched- - but give an option to refiance

            let oyBasis=useThese['basis'] ;
            if (jQuery.trim(oyBasis)=='' )  oyBasis='100%';
            if (jQuery.isNumeric(oyBasis)) oyBasis=wsurvey.addComma(parseInt(oyBasis)) ;

            let LLA=useThese['loanAmount'] ;
            let aterm=parseInt(useThese['loanTerm']);
            let arate=parseFloat(useThese['loanRate'])   ;
            isTaxDed= useThese['loanTaxDeduct']

            let aowed=useThese['loanOwed'];
            amess+='Basis: <input type="text" readonly style="opacity:0.6" name="portfolioPropertyBasis"  class="propertyInputClass"  size="5"  ';
            amess+='     style="font-size:100%" value="'+oyBasis+'"    data-orig="'+useThese['basis']+'"   ';
            amess+=' title="The basis, in $ (used in capital gains calculations)- specified when portfolio was created (it can not be changed here).\n" >';
            amess+='<span style="color:brown;padding:2px;font-size:80%">Owed= ' +  wsurvey.makeNumberK(aowed,90000);

            amess+='</span>';

            let startLoan=useThese['loanStart'];
            let atermUse=aterm;
            if (jdateStamp!==false) {
                let teps=jdateStamp-startLoan ;
                atermUse=parseInt(aterm- (teps/365) ) ;
                atermUse=Math.max(1,atermUse);   // avoid silly problems
            }

            if (aowed>0) {
              amess+='<input type="button" value="reFinance?" title="Click to refinance this loan " ';   // addARowPortfolioAssetMix
              amess+='  data-amount="'+LLA+'" data-term="'+atermUse+'" data-rate="'+arate+'"  data-taxDed="'+isTaxDed+'"  data-owed="'+aowed+'"  data-asset="'+aname+'" ';
              amess+='       onClick="portfolio_loanRefinance(this)" > ';
            }

            amess+='<input type="hidden"    name="portfolioLoanAmountOrig" value="'+LLA+'">';        // current loan values (if any)
            amess+='<input type="hidden"  data-orig="'+useThese['loanOwed']+'"  name="portfolioLoanOwed" value="'+useThese['loanOwed']+'">';
            amess+='<input type="hidden"   data-orig="'+useThese['loanPayYearly']+'"   name="portfolioLoanPay" value="'+useThese['loanPayYearly']+'">';

            let loanMess= wsurvey.makeNumberK(aowed,50000,0)+' owed ' ;
            if (jdateStamp!=false) {
                let oof3=setEntryDate(jdateStamp);
                let dateSay=oof3['sayDate'];
                loanMess+=' on '+dateSay;
            }

            amess+='<span style="display:inline-block;white-space:nowrap;font-size:90%" name="loanStuff"> ';
            if (aowed>0) {
                amess+='<input type="button" value="Loan" title="Click to view the ... ...  loan schedule" ';
                amess+='  data-amount="'+LLA+'" data-term="'+aterm+'" data-rate="'+arate+'"  data-taxDed="'+isTaxDed+'"  data-asset="'+aname+'"  data-start="'+startLoan+'" ';
                amess+='       onClick="specifyLoanScheduleC(this,\''+loanMess+'\')" > ';

                amess+='<span name="portfolioLoan_currentSpecs" title="Current loan specs"> ';
                amess+=' amount=' +  wsurvey.addComma(parseInt(useThese['loanAmount']));
                amess+=' | Term= '+aterm;
                amess+=' | Rate= '+ arate.toFixed(1)+'%';
                if (isTaxDed==1) {
                   amess+=' | taxDeductible  ' ;
                } else {
                     amess+=' | <u>not</u> taxDeductible ' ;
                }
                amess+='</span>';
            }

        amess+='<input type="hidden" class="modReset modResetHide "  data-orig="0" name="portfolioLoanRefinance" value="0">';       // addARowPortfolioAssetMix: can be reset by  portfolio_loanRefinance3

// these made visibile if reFinance chosen
            amess+='<input type="hidden" class="modReset modResetHide "   data-orig="'+LLA+'" size="6" readonly title="refinance: loan amount"  name="portfolioLoanAmount" value="'+LLA+'">';
            amess+='<input type="hidden"    class="modReset modResetHide"  data-orig="'+aterm+'" size="2"  readonly title="refinance: loan term" name="portfolioLoanTerm" value="'+aterm+'">';
            amess+='<input type="hidden"  class="modReset modResetHide"  data-orig="'+arate+'"  size="3"  readonly  title="refinance: loan Rate" name="portfolioLoanRate" value="'+arate+'">';
            amess+='<input type="hidden"  class="modReset modResetHide"  data-orig="'+isTaxDed+'" size="1"   readonly  title="refinance: interest tax deductible?" name="portfolioTaxDeduct" value="'+isTaxDed+'">';
            amess+='<input type="hidden"  class="modReset modResetHide"  data-orig="0" size="4"   readonly  title="refinance cost!" name="portfolioRefiCost" value="">';
            amess+='<input type="hidden"  class="modReset modResetHide"  data-orig="0" size="4"   readonly  title="this is a refiance cost!" name="portfolio_newloan" value="">';

           amess+='</div>';
        }     // ismod

        tbdSay='<div class="propertyInputClass">'+portfolioAssets_currentInfo(aname)+'</div>';

     } else if (assetType==4 ) {          //income

        let useCost=(useThese.hasOwnProperty('acqCost')) ? useThese['acqCost'] : useThese['cost'];
        let useCostSay=useCost;
        if (jQuery.isNumeric(useCost)) useCostSay=wsurvey.addComma(parseInt(useCost));


        amess+='<input type="hidden" name="modStatus" value="'+isMod+'" > ';
        let astart=useThese['incomeStart'];
         amess+='<input type="hidden" name="incomeStart" value="'+astart+'" > ';
        amess+='<span title="acquisition cost" >$acqCost</span>:';
        amess+=' <input type="text" data-orig="'+useCost+'" name="portfolioShares"  class="incomeInputClass" ';
        amess+='  size="7" value="'+useCostSay+'"    ' ;
        if (isMod==1)  {
            amess+=' readonly style="opacity:0.6" ';     // one-time costs
            amess+=' title="Acquisition cost - specified when portfolio was created (it can not be changed here).\n For example, the purchase price of an annuity. \nHint: nnnK for nnn thousand"    ';
            amess+=' >';

        } else {
            amess+=' title="Acquisition cost - specified when portfolio was created (it can not be changed here).\n For example, the purchase price of an annuity. \nHint: nnnK for nnn thousand"   ';
            amess+=' >';
            amess+='<input type="button" class="smallButton" value="%" title="Specify: % of yearly income (as the acquisition cost) " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
            amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
        }
        tbdSay='<div class="incomeInputClass">'+portfolioAssets_currentInfo(aname)+'</div>';

     }

    amess+='</td>';

    amess+='<td   name="cell_netValue"   data-_sortuse="'+useThese['nShares']+'" ><div class="cportfolioTable1_summaryCell"  >';
    amess+=tbdSay;
    amess+='</div></td>';

    amess+='<td name="cell_pct"  data-_sortuse="'+useThese['nShares']+'"  ><div style="width:100%;overflow:auto"> <input type="text" data-orig="'+useThese['comment']+'" name="portfolioComment" size="30"   value="'+useThese['comment']+'"  title="optional comment"></div></td>';
    amess+='</tr>';

    let emess=$(amess);

    emess.appendTo('#portfolioHistory1AssetRows');

   if (doButton!=1)   return emess;

// update asset button (for this asset)  --- to simulate it was clicked on
  let etable=$('#portfolioHistory1');
  let eaButtons=etable.find('[name="portfolioTable_assetButtons_1"]');

  let ea1=eaButtons.filter('[data-name="'+aname+'"]');
  if (ea1.length!=1) return emess;

  ea1.addClass('chighlightAssetButton');
  ea1.attr('data-chosen',1);


}


//===================
// return html with a summary of totals across  all assets asset in a portfolio mix (quantity,cost cost%, totAssetSale, totAssetSale%, netValue netValue%
// amult used for inflation adjustment (if no inf adjustmemt, amult=1.0)

function portfolio_totalSummary(davals,amess0,isMod,amult ) {

  if (arguments.length<4) amult=1.0;
   amult=parseFloat(amult); // probably overkill
  let   totAssetSale,totNetAsset,cashAsset,totNetValue;
 let totRevenue_period=0 ,totTaxOnEarnings_period=0 ,totTaxOnRevenue_period=0 ,totLoanPaid_period=0;
 let totNetAssetEst,gotModifies='' ;

  let totvals=davals['totals'] ;
  if (!davals.hasOwnProperty('totalsG')) {
     alert('portfolio_totalSummary error: no [totalsG].  ');
     return false;
  }

  totNetValue=davals['totalsG']['totNetValue']*amult;
  totAssetSale=davals['totalsG']['totAssetSale']*amult;
  totNetAsset=davals['totalsG']['totNetAsset']*amult;         // actual, not estimatee (totalsG vs totals)
  cashAsset=davals['totalsG']['cashAsset']*amult;

  if (davals.hasOwnProperty('changesGrow')) {
    totRevenue_period=davals['changesGrow']['totRevenueAT']*amult;
    totTaxOnEarnings_period=davals['changesGrow']['totTaxOnEarnings']*amult;
    totTaxOnRevenue_period=davals['changesGrow']['totTaxOnRevenue']*amult;
    totLoanPaid_period=davals['changesGrow']['totLoanPayAT']*amult;
  }

  let amess=''
  if (amess0!==false) amess='<b>Portfolio summary  </b> '+amess0; //  (<em>before modification</em>)';
  amess+='<ul class="tighterMenu">';
   if (amess0!==false) {
     let  xv1=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totNetValue),90000),amult);;
      amess+='<li><span title="Net value, including `Cash` "   style="border-bottom:1px dotted blue;font-weight:600">  ';
      amess+='  netValue :<tt> '+xv1+'</tt></span>';
  }
  if (amess0!==false) {
     let tt1=' title="'+totvals['nBond']+' bonds, '+totvals['nStock']+' stocks, '+totvals['nProperty']+' properties" ';
     amess+='<li>non-<u>Cash</u> assets: <span '+tt1+' style="border-bottom:1px dotted blue;font-weight:500"><tt>'+totvals['nAsset']+'</tt></span>';
     if (totvals['nIncome']>0) amess+='<span title="# of income streams" style="font-size:80%"> &amp; <tt>'+totvals['nIncome']+'</tt> inc </span>';
  }
  if (isMod==0 ) {
     let  xv1=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totvals['totCost']*amult),90000),amult);
      amess+='<li><span title="cost of acquiring assets & incomes" style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500"> ';
      amess+='   Cost:<tt> '+xv1+'</tt></span>';
  } else {
      let  xv1=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totvals['totCost']*amult),90000),amult);
      amess+='<li><span title="approximate cost of acquiring assets & incomes\nIncludes original outlays, and estimated outlays from reinvestments (from stock dividends and bond interest)"  ';
      amess+='    style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">~Cost:<tt> '+xv1+'</tt></span>';
   }

   amess+='<li> <span title="Gross (pre-tax) value" style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">~pre-tax value:<tt> ';
   let xv2=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totvals['totAssetSale']*amult),90000),amult);
   amess+= xv2+'</tt></span>';
   let tt1= 'Net value of all assets (after taxes and loan payouts)\n ... '+totvals['nBond']+' bonds, '+totvals['nStock']+' stocks, '+totvals['nProperty']+' properties  ';
   amess+='<li><span  title="'+tt1+'"  ';
   let xv2b=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totNetAsset),90000),amult);
   amess+='    style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">netValueAsset:<tt> '+xv2b+'</tt></span>';

   if (davals.hasOwnProperty('changesGrow')) {
           amess+='<li><div style="border-top:1px dotted tan"> ' ;
           amess+='<span title="Since portfolio initialization (or last modification):  netRevenue (from properties) + yearly income streams.\n Net revenue can be negative (i.e.; property taxes), but does NOT include loan payments"  ';
           amess+='     style="color:darkgreen; border-bottom:1px dotted blue;font-weight:500"> ';
           let xv2=portfolio_totalSummary_sayval(wsurvey.makeNumberK(totRevenue_period,50000),amult);
           amess+=  ' &#120491;netRevenue :<tt> '+xv2+'</tt></span> ';
           amess+=' <span title="Since portfolio initialization (or last modification):  tax paid on all incomeStreams and netRents\n Does not include taxes on dividend and bond (interest) earnings"  ';
           amess+='     style="color:darkgreen;border-bottom:1px dotted blue;font-weight:500"> ';
           let xv2b=portfolio_totalSummary_sayval(wsurvey.makeNumberK(totTaxOnRevenue_period,50000),amult);
           amess+=  '  &hellip; tax: <span style="font-family:monospace" title="the tax paid"> '+xv2b+'</span></span> ';
           amess+='</div>';

           amess+='<li><span title="Since portfolio initialization (or last modification): loan payments (principal and interest)" ';
           amess+='    style="color:#f77f7f;border-bottom:1px dotted blue;font-weight:500">';
           let xv2c=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totLoanPaid_period),30000),amult);

           amess+= '  &#120491;loanPayment <tt> '+xv2c+'</tt></span>';
           amess+=' &hellip; <span title="Remaining balance on all loans" style="color:red;border-bottom:1px dotted blue;font-weight:500">unpaidLoans<tt> ';

           let xv2d=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totvals['totLoanOwed']*amult),90000),amult);
           amess+=xv2d+'</tt></span>';
    }

   if (davals.hasOwnProperty('changesModify')) {    // these are NOT inflation adjusted
       let cmods=davals['changesModify'];
        amess+='<li><div style="border-top:1px dotted brown"> ';
        amess+=' Modifications: remove=<tt>'+cmods['nremove']+'</tt>, add=<tt>'+cmods['nnew']+'</tt>, change=<tt>'+cmods['nchange']+'</tt>';
        let tproceeds=wsurvey.makeNumberK(cmods['netProceeds'],40000,0);
        let tsales=wsurvey.makeNumberK(cmods['netSales'],40000,0);
        let tcosts=wsurvey.makeNumberK(cmods['totCosts'],40000,0);
        amess+='<br>Proceeds=<tt>'+tproceeds+'</tt> &nbsp; <span title="[net (after tax) sales minus cost of acquisitions]" style="font-family:monospace;font-size:85%">';
        amess+='['+tsales+'-'+tcosts+']</span>';
        amess+='</div>';
   }

  amess+='</ul>';
  return amess;
  
  function portfolio_totalSummary_sayval(atext,amult) {
      amult=parseFloat(amult);
      if (amult==1.0) {
          return '<tt>'+atext+'</tt>';
      } else {
         return '<em>'+atext+'</em>';
      }
  }
}

//=========================    isMod   totvals
// show summary of a initialize portofoli
//===================  assetVars
// return html with a summary of totals across  all assets asset in a portfolio mix (quantity,cost cost%, totAssetSale, totAssetSale%, netValue netValue%
//totals:  object
//      totAssetSale:          totNetAssetEst:       totCost:          totCapGains:          totTaxOnSale:
//      totLoanPayYear:      totLoanOriginal:      totLoanOwed:       totRefiCost:      totNetStock:
//      totNetRegular:       totNetTaxDeferred:       totNetIncomeStream:      totNetProperty:
//      totBasis:       totYearlyIncome:       totYearlyNetRent:      totYearlyRevenue:       nAsset:
 //     nStock:       nBond:       nRegular:       nTaxDefer:      nProperty:      nIncome:      nLoan:



function portfolio_initTotalSummary(davals,amess0) {

 let totNetAllEst=davals['totNetAllEst'];
 let totNetAssetsEst=davals['totals']['totNetAssetEst'];
 let totNetRevenue=davals['totals']['totYearlyRevenue'];
 let totLoanPayments=davals['totals']['totLoanPayYear'];
 let totLoanOwed=davals['totals']['totLoanOwed'];
 let totCost=davals['totals']['totCost'];
 let totAll=davals['totals']['totAssetSale'];
 let nAsset=davals['totals']['nAsset'];
 let nStock=davals['totals']['nStock'];
 let nBond=davals['totals']['nBond'];
 let nProperty=davals['totals']['nProperty'];
 let nIncome=davals['totals']['nIncome'];
 let nLoan=davals['totals']['nLoan'];

   amess='<b>Portfolio summary </b> '+amess0; //  (<em>before modification</em>)';
   amess+='<ul class="tighterMenu">';
   amess+='<li><span title="Net value, including `Cash` "   style="border-bottom:1px dotted blue;font-weight:600">  ';
   amess+='  ~netValue :<tt> '+wsurvey.makeNumberK(totNetAllEst,90000,0)+'</tt></span>';

  let tt1=' title="'+nBond+' bonds, '+nStock+' stocks, '+nProperty+' properties" ';
   amess+='<li>non-<u>Cash</u> assets: <span '+tt1+' style="border-bottom:1px dotted blue;font-weight:500"><tt>'+nAsset+'</tt></span>';
   if (nIncome>0) amess+='<span title="# of income streams" style="font-size:80%"> &amp; <tt>'+nIncome+'</tt> inc </span>';

   amess+='<li><span title="cost of acquiring assets & incomes" style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500"> ';
   amess+='   Cost:<tt> '+wsurvey.makeNumberK(totCost,90000,0)+'</tt></span>';

  amess+='<li> <span title="Gross (pre-tax) value" style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">~pre-tax value:<tt> ';
  amess+=     wsurvey.makeNumberK(totAll,90000,0)+'</tt></span>';

  amess+='<li><span title="Approximate net  value -- the `sales` value of all assets; after paying capital gains & tax deferred taxes, and after paying off loans)\n Does NOT include `Cash` "  ';
  amess+='    style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">~netValueAsset:<tt> '+wsurvey.makeNumberK(totNetAssetsEst,90000,0)+'</tt></span>';

   amess+='<li><span title="Revenue: incomeStreams and rents"   style="border-bottom:1px dotted blue;font-weight:600">  ';
   amess+='   Revenue:<tt> '+wsurvey.makeNumberK(totNetRevenue,90000,0)+'</tt></span>';

   amess+='<li><span title="Loan paymets (pre-tax)"   style="border-bottom:1px dotted blue ">  ';
   amess+='   Loans:<tt> '+wsurvey.makeNumberK(totLoanPayments,90000,0)+'</tt></span>';
   amess+='<span title="amount owed"> (<tt>'+wsurvey.makeNumberK(totLoanOwed,90000,0)+'</tt>)</span>'


  amess+='</ul>';

  return amess;
}



//===================   
// return summary of an asset in a portfolio mix (quantity,cost cost%, totAssetSale, totAssetSale%, netValue netValue%
// percenst are of total (tocal cost, totalValue, totNetAssetEst
// called by portfolioCalcValueMenu
function addARowPortfolioAssetMix_assetSummary(aname,davals) {

 let totals=davals['totals'];

 let astuff=davals['assets'][aname];

 let myCost=astuff['cost'];
 let myValue=astuff['value'];
 let myNetValue=astuff['netValue'];

 let myCostPct=100*myCost/totals['totCost']   ;
 let myValuePct=100*myValue/totals['totAssetSale']  ;
 let myNetValuePct=100*myNetValue/totals['totNetAssetEst']  ;    // estimated, not actual (totals vs totalsG)

 let amess='';

 let aprice=davals['assets'][aname]['price'].toFixed(1);
 let qq=parseInt(davals['assets'][aname]['q']);
 let say1= (davals['assets'][aname]['assetType']==0)  ?  '(~ '+aprice+'*'+qq +')' : ' ' ;
 amess+='<span  title="Acquisition Cost '+say1+'" class="cmyCost_span">'+wsurvey.makeNumberK(myCost,30000);
 amess+=     '  <span  title="as % of total cost" class="cmyCostPct_span">'+ myCostPct.toFixed(0)+'</span></span> ';
 amess+='<span title="Pre tax (and pre loan payback) value" asset" class="cmyValue_span">'+wsurvey.makeNumberK(myValue,30000);
 amess+=     ' <span  title="as % of totalvlue" class="cmyValuePct_span">'+ myValuePct.toFixed(0)+'</span> </span>';
 amess+='<span title="After tax (and after loan payback) value" class="cmyNetValue_span">'+wsurvey.makeNumberK(myNetValue,30000) ;
 amess+=   ' <span title="as % of total netValue" class="cmyNetValuePct_span">'+ myNetValuePct.toFixed(0)+'</span></span> ';

 let atype=astuff['assetType'];

 let myNetRevenue=astuff['yearlyRevenue'] - astuff['loanPayYearly'];
 if (atype==3) {
    amess+='<span title="Yearly Rents + Yearly loan payments" class="cmyNetRevenue_span">'+wsurvey.addComma(parseInt(myNetRevenue))+'</span>';
 } else if (atype==4) {
    amess+='<span title="Yearly income" class="cmyNetRevenue_span">'+wsurvey.addComma(parseInt(myNetRevenue))+'</span>';
 } else {
    amess+='<span  class="cmyNetRevenue_span"> &hellip;</span>';
 }
 return amess;
}


//=================
// return basic info (price, dividend, etc) (given current creation/modificatio ndate
// assetValuesCurrent is created and saved  by  buildPortfolioMenu_priceUpdate
function portfolioAssets_currentInfo(aname)  {

  let etable=$('#portfolioHistory1');

  let myValues=(assetValuesCurrent.hasOwnProperty(aname)) ? assetValuesCurrent[aname][4] : false ;

  let assetType=getAssetType(aname);
  let tbdSay  ;

   if (assetType==0) {
        tbdSay='Price and dividend not set' ;
       if (myValues!==false) {
          let sprice= myValues['price'];
          let sdividend =myValues['dividend']  ;
          let grate=100*sdividend/sprice;
          tbdSay='Price: '+sprice.toFixed(0)+', dividend='+sdividend.toFixed(1) +' ... growth='+grate.toFixed(1)+'%' ;
      }


   } else if (assetType==1) {
       tbdSay='interest and additions  not set' ;

       if (myValues!==false) {
          let irate= (myValues['interest']*100) ;
          let taxrate0=calcAsset_taxRate(aname,0);
          let taxrate= taxrate0 *100  ;
          tbdSay='Interest rate: '+irate.toFixed(1)+', taxRate='+taxrate.toFixed(1)+'%' ;
          let sayAdd=wsurvey.addComma(parseInt(myValues['addition']));
          tbdSay+=', add='+sayAdd;
       }

   } else if (assetType==2) {
       tbdSay='interest and additions  not set' ;
       if (myValues!==false)  {
          let irate= (myValues['interest']*100) ;
          tbdSay='Tax-deferred interest rate: '+irate.toFixed(1) ;
          let sayAdd=wsurvey.addComma(parseInt(myValues['addition']));
          tbdSay+=', add='+sayAdd;
   }


   } else if (assetType==3) {
       tbdSay='salePrice and netRent  not set' ;
       if (myValues!==false)   {
          let sprice=myValues['salePrice'];
          let srent=myValues['netRent'];
          let taxrate0=calcAsset_taxRate(aname,1);
          let taxrate= taxrate0 *100  ;
          tbdSay='Price: '+wsurvey.makeNumberK(sprice,1000000,0) +', Rent= '+srent.toFixed(0)+', capGainsTax='+taxrate.toFixed(1)+'%';

          let loanPayYear=myValues['loanPayYearly'];
          if (loanPayYear>0) {
              let loanAmountSay=wsurvey.makeNumberK(myValues['loanAmount'],100000,0) ;
             tbdSay+=', <span title="Loan amount='+loanAmountSay+'">LoanPay: '+wsurvey.makeNumberK(loanPayYear,100000,0)+'</span>'
          }
       }

   } else if (assetType==4) {
       tbdSay='income  not set' ;
       if (myValues!==false)    {
          let constantIncome=doAssetLookup(aname,'constantIncome');

          let sincome=myValues['income'];
          let taxrate0=calcAsset_taxRate(aname,0);
           let taxrate= taxrate0 *100  ;
          if (constantIncome==1) {
             let grate= myValues['growthRate'];
             let grateSay=(grate*100).toFixed(1);
             tbdSay='<span title="This `fixed income` starts at this value ...  "> Income: '+wsurvey.makeNumberK(parseInt(sincome),100000);
             tbdSay+=' (<span title=" and grows at this yearly rate"><tt>growth='+grateSay+'%</tt>)</span> </span>';
          }    else {
             tbdSay='<span title="This `variable income` changes over time (based on asset history entries), and is currently ... "> Income: '+wsurvey.makeNumberK(parseInt(sincome),100000);
             tbdSay+=' </span>';
          }
          tbdSay+=', taxRate='+taxrate.toFixed(0)+'%' ;
      }
   }
   //alert(tbdSay);
   return tbdSay ;
}


//===============   calcAsset_taxRate
// process one of the helper buttons for entering a numeric value (%, $, or k)

function addARowPortfolioAssetMix_type(athis,isbasis) {
  if (arguments.length<2) isbasis=0;
  let useme;
   let ethis=wsurvey.argJquery(athis);
   let atype=ethis.val();     // k % or $
   let etd=ethis.closest('td');
   let eshares,ispct=0,isdollar=0;
   if (isbasis==0) {
       eshares=etd.find('[name="portfolioShares"]');
   } else if (isbasis==2) {
       eshares=etd.find('[name="portfolioLoanAmount"]');
   } else if (isbasis==3) {
       eshares=etd.find('[name="portfolioPropertyBasis"]');
   } else {
       eshares=etd.find('[name="portfolioSharesBasis"]');
   }

// clear any $,%,or k from the number input field
   let ashares=jQuery.trim(eshares.val());
   if (ashares=='') ashares='0';
   let aprefix='';
   let a1=ashares.substr(0,1);
   if (a1=='$'  ) {
     ashares=ashares.substr(1);
   }
   if (a1=='#'  ) {
     ashares=ashares.substr(1);
   }

   let a2=ashares.substr(ashares.length-1,1);
   if (a2=='%') {
      ashares=ashares.substr(0,ashares.length-1);
   }

   if (atype=='k') {
     ashares=fixNumberValue(ashares+'k');   // an exsting k is incorporated, so adding k means "millions"
   }

   if (ashares===false) {
     eshares.val('');          // error (not a number), so clear it
   } else {
     if (atype=='$' ) {
         let xx=parseInt(ashares);  // round to nearest doallr)
         useme='$'+xx;
     } else if (atype=='%') {
         useme=ashares+'%';
     } else {
        useme=ashares;
     }
     eshares.val(useme);
   }
   return ashares ;
}


//=====================
// copy the asset mix of an existing portfolio
function copyPortfolio(athis) {
   let ethis=wsurvey.argJquery(athis);
   let pcurrent=ethis.attr('data-name');
   let amess='';

   amess+='<button style="margin-bottom:5px" title="Tips on copying an existing portfolio" onclick="displayHelpMessage(this)" data-div="#copyPortfolioHelp1">?</button>';
   amess+="Select a portfolio to copy: ";

  amess+='<ul class="linearMenu16Pct">';
  for (let acc in portfolioLookup['list']) {
     if (acc==pcurrent) continue ; // can't copy self
     if (portfolioLookup['list'][acc]['isInit']==0) continue ; // uninitialize portfolio
     let ij=portfolioLookup['list'][acc]['ith']  ;
     let xx=portfolioList[ij];
     amess+='<li><input type="button" data-name="'+acc+'" data-current="'+pcurrent+'" value="'+acc+'"   onClick="copyPortfolio2(this)">';
     amess==' <span class="cdescNoteLittle">'+xx['desc']+'</span>';
  }
  amess+='</ul>';

  displayStatusMessage(amess);

//  $('#statusMessage_message').html(amess) ;
//   wsurvey.wsShow.show('#statusDiv',2);
   return 0;

}


//=============
// copy the selected portfolio  (initialziation entry ... 27 june does not support copying a modification. Perhaps later?)
function copyPortfolio2(athis)  {
     
     let notes=[];

    let ethis=wsurvey.argJquery(athis);
    let pname=ethis.attr('data-name');
    let pcurrent=ethis.attr('data-current');
    let pcurrentF=getAssetFamily(pcurrent,1);
    let useScenario=false;
    if (pcurrentF['scenario']!='')  useScenario=pcurrentF['scenario'];

    let copyRows=portfolioInit[pname]['assetList'];

    let etable=$('#portfolioHistory1');
    let eaButtons=etable.find('[name="portfolioTable_assetButtons_1"]');

    for (let ii=0;ii<copyRows.length;ii++) {
      let acopyRow=JSON.parse(JSON.stringify(copyRows[ii])) ;  // clone
      let aname=acopyRow['name'];
      let anameUse=aname;
      if (useScenario!==false)  {            // copy scenario specific assets?
         let anameF=getAssetFamily(aname,1);
         if (anameF['scenario']!='')  {           // a scenario asset -- use the useScenario verison
            anameUse=anameF['family']+'.'+useScenario;
        }
      }
      if (!assetLookup.hasOwnProperty(anameUse)) {
           notes.push('Asset <tt>'+anameUse+'</tt> is not available  ');
         continue ; // no such asset (i.e.; not a useScenario version of this asset)
      }
      acopyRow['name']=anameUse ;       // if scenario is differnt

      let omess=portfolio_checkAssetAdded(aname);  // copyPortfolio2: missingasset? ALready in pmortoflio? Same family?
      if (omess!==false) continue ;          // don't bother showing message

// add it (using this asset's specs from the copiedFrom portofliol

      addARowPortfolioAssetMix(0,acopyRow,1)  ; // copyPortfolio2 : add row to table: a copy of this assetspec. Note use 0 (not mod) to allow these to be modified

    }

    buildPortfolioMenu_priceUpdate(0);      // copyPortfolio2

    if (notes.length>0) {        // possibly some scenario specific assets do not exist
      let nmess='<ul>';
      nmess+='<li>'+notes.join('<li>')+'</ul>';
      displayStatusMessage(nmess);
    } else {
       displayStatusMessage(false);
    }

   return 1;
}

//===========================   usep
// remove a portfolio modification
function showPortfolioHistoryRemove(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-name');
   let ith=ethis.attr('data-which');
   let adate=ethis.attr('data-date');

  let ddata={};

  ddata['todo']='removePortfolioModification';
  ddata['username']=userName;
  ddata['encMd5']=encryptionKey_md5;

  ddata['portfolio']=aname ;  // defaults
  ddata['modification']=adate ;
  ddata['ith']=ith ;

  saveSimInvData(ddata );

 }


//========
// display one of a portfolio's date-specific asset-mixes (init, or a modification)
// called  as  click handler from buttons on  the    showPortfolioViewModify page
// or from showAllPortfolioValues_viewInit

function showPortfolioMix(athis,pname,nth,adate,noRemove) {

  let noPrint=1;
  if (arguments.length<5) noRemove=0;
  if (arguments.length<4) {
    noPrint=0;
    let ethis=wsurvey.argJquery(athis);
    pname=ethis.attr('data-name');

    if (!portfolioInit.hasOwnProperty(pname)) {
       alert('No such portfolio ('+pname+') in portfolioInits ');      // should not happen
       return 0;
    }

    nth=ethis.attr('data-nth');
    adate=ethis.attr('data-date');

     let eul=ethis.closest('#portfolioModificationsList');
     let eli=eul.find('li');
     eli.removeClass('highlightThisLi')
     eli.addClass('notHighlightThisLi')
     eli0=ethis.closest('li');
     eli0.addClass('highlightThisLi')
     eli0.removeClass('notHighlightThisLi')

  }

  let isMod=0;

// pvals is from init or from a modification (of portfolio pname)

  let pVals,acommentModification='' ;
  if (nth==0) {
      pVals=portfolioInit[pname];
  } else {
      let aa=portfolioLookup['list'][pname];
      if (!aa['modDatesSay'].hasOwnProperty(adate)) {
         alert('No such modification ('+nth+') for '+pname);
         return false;
      }
      acommentModification=aa['comments'][adate];
      pVals=portfolioModifications[pname]['list'][adate];
      isMod=1;
  }
//  wsurvey.dumpObj(pVals,1,isMod + ' of '+pname);
  let origBudget=portfolioInit[pname]['original']['budget'];

  let daDate=pVals['dateStamp'];
  let sayDate=pVals['dateStampSay'];
  let nAssets=pVals['totals']['nAsset'];
  let totNetValue=pVals['totalsG']['totNetValue'];
  let totGross=pVals['totals']['totAssetSale'];
  let totYearlyIncome=parseFloat(pVals['totals']['totYearlyIncome']);
  let totYearlyNetRent=parseFloat(pVals['totals']['totYearlyNetRent']);
  let totYearlyRevenue=parseFloat(pVals['totals']['totYearlyRevenue']);

  let totLoanPayYear=parseFloat(pVals['totals']['totLoanPayYear']);


  let dalist={};
  let pValsAssets=pVals['assets'];
  let inputList=pVals['assetList'];
   let amess='';
   amess+='Portfolio <span style="font-size:110%;background-color:lime">'+pname+'</span> on <u>'+sayDate+'</u> :: ';
   amess+=' <span title="Net value (including `Cash`, excluding incomeStreams)"> netValue =<tt>'+wsurvey.addComma(parseInt(totNetValue))+'</tt></span>' ;
   amess+=' <span class="cgrossValue" title="Gross (pre-tax, pre loan payout) value"> Gross value: <tt>'+wsurvey.addComma(parseInt(totGross))+'</tt></span>'

   if (noRemove!=1) {          // suppress if called by showAllPortfolioValues_viewEntry
     amess+='<span name="nshowPortfolioHistoryRemove"  style="border:1px solid blue;margin-left:2em;padding:3px">';
     if (nth!=0) {
       amess+=' &nbsp;<button title="Remove this modification   " onClick="showPortfolioHistoryRemove(this)"  ';
       amess+='     data-name="'+pname+'" data-nth="'+nth+'" data-date="'+daDate+'" >';
       amess+='Remove </button> ';
     }
     amess+='</span>';
   }

   amess+='<span class="cmodComment" ><em>Comment:</em> '+acommentModification+'</span>'
   amess+='<p>';

   amess+='<table border="1" id="portfolioHistory1b" width="98%"   class="cportfolioTable">';

// column names
   amess+='<tr bgcolor="#fbf6bc" class="headerRow">';
   amess+='<td width="1%" title="sort by: type of asset " > </td>';
   amess+='<td   width="10%" ><span  title="Name of an existing asset"><b>Asset Name</b></span>';
   amess+='</th>';
   amess+='<td width="10%"> <span title="# shares. For bonds: the dollar value. For stock: # of shares\nIf stock: (basis fraction)"><b>$ or #shares</b>  <em>price</em></span></td>';
   amess+='<td width="23%">';
   amess+='    <span  class="cgrossValue" ';
   amess+='     title="Value of this asset (pre-tax, pre loan payout) "> Gross value ';
   amess+='</span>';
   amess+=' <span title="basis value (for stocks and properties)" class="portfolioAssetBasis">basis</span>  ';
   amess+=' &vellip;';
   amess+=' </span>';
   amess+=' <span style="float:right;margin-right:0.5em">';
   amess+=' <span title="acquisition cost" class="sayCost">cost</span>  ';
   amess+=' <span title="approximate net value" class="sayNetValue">net Value</span>  ';
   amess+='<span>';
   amess+='</td>';
   amess+='<td width="19%" title="sort by: loan balance  " >';
   amess+=' <u>loan info </u> or <em>growth info</em>  (<tt>per year</tt>)';
   amess+=' </th>';

//
  let loanPayHdr='<span title="total net (after tax) loan payments " class="cloanPayHdr">loanPay</span> ';
  let netRevenueHdr='<span title="total net (after tax) revenues (rents + incomeStreams)"  class="cnetRevenueHdr">netRevenue</span> ';

   amess+='<th width="18%" title="sort by: cash flow (Rent, mortgage payments, income ... " > '+netRevenueHdr+' & '+loanPayHdr+' (per year) </th>';
   amess+='<th width="18%" title="sort by: net value " > <span title="Comment">Comment</span></th>';
   amess+='</tr>';

// the cash row
  amess+='<tr class="portfolioHistoryRowCash"  >';
     amess+='<td > </td>';
   amess+='<td><u>Cash</u> </td>';
   let dacash=wsurvey.addComma(parseInt(pVals['cashAsset'])) ;
   amess+='<td>&nbsp;</td>    ';
   amess+='<td><span title="Remaining (unallocated) cash. If negative: the extra cash needed to obtain asset mix" class="cCashValue"  ><tt>'+dacash+'</tt></span>'
   amess+='</td>';
   amess+='<td>&nbsp;</td>    ';

   let totRevenue_cost=totYearlyRevenue- totLoanPayYear ;
   let totRevenue_costSay=wsurvey.makeNumberK(parseInt(totRevenue_cost),30000,0);
   amess+='<td><span title="(yearlyIncome+yearlyRent)-yearlyLoanPayments"> <tt>'+totRevenue_costSay+'</tt>';
   amess+='<span style="margin-left:1em;border:1px dotted gray;font-size:90%;" title="yearly loan payments">loanPay</span> ';
   amess+=' <span title="Tax info: fraction of tax (either earnings or capital gains) that are taxFree.\nDo losses (netRevenue or Income) offset other income? "  class="ctaxFreeFrac"  style="font-size:85%;float:right;margin-right:0.2em"><em>taxFree | losses </em></span>' ;

   amess+='</td>';

   amess+='<td><span style="font-size:80%">remaining, or (if negative) required, <u>Cash</u></span></td>';
   amess+='</tr>'  ;

// asset rows
// &#127480; S blue  ,  &#127463; B blue,  &#127299;  T box      &#9332; (1)   &#9450; circle 0

  for (let aaName in pValsAssets) {
     if (aaName=='Cash') continue ;

     let a1=pValsAssets[aaName];

     let assetType=getAssetType(aaName);
     let aicon=getAssetType(aaName,'icon');

     let nshares=parseFloat(a1['q']);
     let sharesValue=parseFloat(a1['value']);
     let sharesValueNet=parseFloat(a1['netValue']);
     let yearlyIncome=parseFloat(a1['yearlyIncome']);
     let yearlyNetRent=parseFloat(a1['yearlyNetRent']);
     let revenueYearly=yearlyIncome+yearlyNetRent ;
     let basisThis=parseFloat(a1['basis']);
     let price=parseFloat(a1['price']);
     let loanPayYearly=parseFloat(a1['loanPayYearly']);
     let aCost=parseFloat(a1['cost']);

     let loanAmount=0,loanRate=0,loanTerm=0,loanStart=false,loanOwed=0;
     let isTaxDed=0;

     if (a1['loanSchedule']!==false) {

       loanAmount=  parseFloat(a1['loanSchedule']['amount'])  ;
       loanTerm=  parseFloat(a1['loanSchedule']['term'])  ;
       loanRate=  parseFloat(a1['loanSchedule']['rate'])  ;
       isTaxDed=  parseFloat(a1['loanSchedule']['taxDeduct'])  ;
       loanStart=  parseFloat(a1['loanSchedule']['startDate'])  ;
       loanOwed=  parseFloat(a1['loanOwed'] )  ;
     }

     let taxFreeFrac=doAssetLookup(aaName,'taxFreeFrac',1);
     let acomment=a1['comment'];

     let lossesOffset=doAssetLookup(aaName,'lossesOffsetIncome') ;

     amess+='<tr class="priorityHistoryRow" data-name="'+aaName+'"  >';
     amess+='<td data-_sortuse="'+assetType+'"  >'+aicon+'</td>';

// name cell

     amess+='<td data-_sortuse="'+aaName+'"  >';            // name and comment
     amess+=aaName ;

     let dog=parseInt(nshares*1)/1;      // /100 to have 2 decimal digits
     let dogSay=wsurvey.addComma(dog);
     if (assetType==1 || assetType==2) dogSay='$'+dogSay ;
     if (assetType==4) dogSay='&hellip;'

// # shares

     amess+='<td data-_sortuse="'+nshares+'"  >&nbsp;'+dogSay ;
     let  isPrice='&hellip;';
     if (assetType==0 || assetType==3) {
         isPrice=wsurvey.makeNumberK(price,10000);
         amess+='<span class="cpriceThisDate" title="Price on this date">'+isPrice+'</span>';
     } else {
         amess+='<span class="cpriceThisDate" title="price n.a.">&hellip;</span>';
     }
     amess+='</td>';

// gross/net value cell

     let aValue=wsurvey.makeNumberK(parseInt(sharesValue),100000);
     amess+='<td  title="sort by: gross (pre-tax) value " data-_sortuse="'+sharesValue+'" >';

     if (assetType==3) {
       amess+='  <span title="Price of property (when acquired)" class="cgrossValue">&nbsp; <tt>'+aValue+'</tt></span>';
     } else if (assetType==4) {
       amess+='  <span title="incomeStreams have no sale value (they just produce income)">&hellip; </span>';
     } else {
       amess+='  <span title="Pre-tax value of asset" class="cgrossValue">&nbsp; <tt>'+aValue+'</tt></span>';
     }

     if (assetType==0 || assetType==3) {
       let tbasis=wsurvey.addComma(parseInt(basisThis));
       amess+=' <span title="basis value" class="portfolioAssetBasis">'+tbasis+'</span>';
     }
     let anet=wsurvey.addComma(parseInt(sharesValueNet)) ;
     let costSay=wsurvey.addComma(parseInt(aCost)) ;

     amess+=' <span style="float:right;margin-right:0.5em">';
     amess+=' <span title="acquisition cost (downpayment, etc.) " class="sayCost">'+costSay+'</span>';
     amess+=' <span title="approximate net value (after taxes, etc)" class="sayNetValue"  >'+anet+'</span>';
     amess+=' </span>';
     amess+='     </td>';

// loan/growth cell

     let loanSay='<td data-_sortuse="0">&hellip;</td>' ;
     if (assetType==3) {
        let sayLoanAmount=  wsurvey.makeNumberK(loanAmount,20000,0)   ;
        let sayOwedAmount=  wsurvey.makeNumberK(loanOwed,20000,0)   ;
        let sayLoanRate=loanRate.toFixed(1);
        let sayLoanTerm=parseInt(loanTerm);

        loanSay='<td title="loan balance ..." data-_sortuse="'+loanAmount+'" >';
          loanSay+='<div style="font-size:90%">'    ;
            loanSay+='<span style="display:inline-block;white-space:nowrap;font-size:100%" name="loanStuff"> ';
            loanSay+='<input type="button" value="Loan" title="Click to view loan schedule" ';
            loanSay+='  data-amount="'+loanAmount+'" data-term="'+loanTerm+'" data-rate="'+loanRate+'"  data-taxDed="'+isTaxDed+'"  data-asset="'+aaName+'"   data-start="'+loanStart+'" ';
            loanSay+='       onClick="specifyLoanScheduleC(this)" > ';

        //<u>Loan:</u> ';
        loanSay+=' Owed: <tt>'+sayOwedAmount+'</tt>' ;
        loanSay+=' <span style="float:right;margin-right:1em">&nbsp; |&nbsp; <u>Rate:</u> <tt> '+sayLoanRate+'</tt> &nbsp;|&nbsp;  <u>term:</u> <tt>'+sayLoanTerm+'</tt></span> ';
        loanSay+='</div>';
        loanSay+='</td>';
     }
     if (assetType==0  ) {
        let grates=calcAssetValues_2(aaName,daDate) ;     // no need for startDate
        let sayDiv= grates[4]['dividend'].toFixed(1);
        loanSay='<td title="Dividend rate (yearly)" data-_sortuse="'+loanAmount+'" ><em>Dividend:</em> <tt>'+sayDiv+'</tt></td>'; ;
     }
     if (  assetType==1 || assetType==2) {
        let grates=calcAssetValues_2(aaName,daDate) ;         // no need for startDate
        let sayInt= (100.0*parseFloat(grates[4]['interest'])).toFixed(1);
        let sayAdd=wsurvey.addComma(parseInt(grates[4]['addition']));
        loanSay='<td title="Interest rate (yearly)" data-_sortuse="'+loanAmount+'" >';
        loanSay+='<em> Interest rate:</em><tt> '+sayInt+'%</tt> ' ;
        loanSay+='| <em>Additions: </em><tt> '+sayAdd+'</tt> ';
        loanSay+='</td>'; ;

     }
     amess+=loanSay;

     let revenueYearlySay='&hellip;';
     if (assetType==3 || assetType==4) revenueYearlySay=wsurvey.makeNumberK(parseInt(revenueYearly),40000);

     if (taxFreeFrac==false || !jQuery.isNumeric(taxFreeFrac)) taxFreeFrac=0;
     let ataxfreeEarningsSay=taxFreeFrac.toFixed(2);
     if (assetType==0)    {
        ataxfreeEarnings= ' <span title="Earnings, and capital gains, are fully taxed" class="ctaxFreeFrac"><em>fully taxed</em></span>' ;
     } else if (assetType==1) {
        ataxfreeEarnings= ' <span title="Fraction of yearly interest earnings that are tax free" class="ctaxFreeFrac">'+ataxfreeEarningsSay+'</span>' ;
     } else if (assetType==2) {
        ataxfreeEarnings= ' <span title="Withdrawals are fully taxed (both principal and interest)"  class="ctaxFreeFrac"><em>fully taxed</em></span>' ;
     } else if (assetType==3) {
        ataxfreeEarnings= ' <span title="Fraction of capital gains NOT taxed"  class="ccapGainsFreeFrac">'+ataxfreeEarningsSay+'</span>' ;
     } else if (assetType==4) {
        ataxfreeEarnings= ' <span title="Fraction of yearly income NOT taxed"  class="ctaxFreeFrac">'+ataxfreeEarningsSay+'</span>' ;
     }

     let alossesOffset='<span  title="..." class="ctaxOffset">&hellip;</span>';
     if (assetType==3 ) {
        if (lossesOffset==1) {
            alossesOffset='<span title="-netRevenue offset other income (for tax purposes)" class="ctaxOffset"> &ltcir;</span>';
       } else {
            alossesOffset='<span title="-netRevenue do NOT offset other income (for tax purposes)" class="ctaxOffset"> &#9723;</span>';
       }
     } else    if (assetType==4) {
        if (lossesOffset==1) {
             alossesOffset='<span title="-incomeStreams offset other income (for tax purposes)" class="ctaxOffset"> &ltcir;</span>';
       } else {
            alossesOffset='<span title="-incomeStreams do NOT offset other income (for tax purposes)" class="ctaxOffset"> &hellip;</span>';
       }
     }

// net revenue cell

    amess+='<td data-_sortuse="'+revenueYearly+'"  ><span title="Yearly income + yearly Rent" style="border-bottom:1px dotted blue;margin-left:1em;min-width:4em;display:inline-block">';
    amess+= revenueYearlySay +'</span>';

     if (loanPayYearly>0)   {
        let loanPaySay=wsurvey.makeNumberK(loanPayYearly,10000,0);
        amess+='<span style="margin-left:1.4em;border:1px dotted gray;font-size:90%;" title="yearly loan payments">'+loanPaySay+'</span> ';
     }
     amess+= '<span style="float:right;margin-right:1em">'+ataxfreeEarnings+' '+alossesOffset+'</span>' ;
     amess+='</td>';

// comment

     amess+='<td data-_sortuse="'+sharesValueNet+'"  >'+acomment+'</td>';
     amess+='</tr>';
  }       // aaname

  amess+='</table>';

  if (noPrint==1) return amess ;      // called from showAllPortfolioValues_viewInit

// spot for transcatons
  amess+='<div id="iPortfolioTransactions" class="cPortfolioTransactions" style="display:none" data-made="0"> </div> ';

  $('#mainDiv3b').html(amess);

   showPortfolioViewModify_listMods(0,pname,showTransactions);  // display list of init and mods .. using the showTransactions mode

  wsurvey.sortTable.init('portfolioHistory1b',{'startRow':2});
  return 1;

}



//================     comment
// calculate portfolio value (pre-tax)  -- NOT including Cash.
//
// returns : {'name':,'totals':,'assets':,'dateStamp':,'dateStampSay':};
//
// [0]  totals:  {totAssetSale,totNet, etc...
// [1] assets: [assetName]=  {q   value netValue  ... loanSchedule ...
//
// alist is an array of the assets comprising the portfolio. -- each row his an objet with variables
// Each asset uses a subset of the variables in a row, depending on assetType
//    0 (stock) :   : nShares , basis
//    1 (regular bond) :    nShares
//    2 (tax deferred bond) :nShares
//    3 (property) :   cost (downpayment etc), basis, loanAmount, loanStart,loanTerm,loanRate,loanTaxDeduct,refiCost
//                 if isMod, just    loanOwed and loanPayYearly
//    4 (incomeStream) : cost
//
// the following varialbes are used from alist
//-- returned info  (if not mentioned for a type, 0 or false)
//all : assetType
// 0 ) q, price, value, cost, basis, capGains, taxOnSale, netValue
// 1 ) q, value, cost=value, basis=0, capGains=0, taxOnSale=false, netValue=value
// 2 ) q, value, cost, basis=0, capGains=0, taxOnSale, netValue
// 3 ) q=1, value, cost, basis, capgains, taxOnSale, netValue, yearlyNetRent, yearlyRevenue=yearlyNetRent
//    and   loanOwed, yearlyNetRent, loanPayYearly, loanSchedule
//        loanSchedule is object with: amount,term,rate,taxDeduct,refiCost,startDate, and info figLoanSchedule() stuff
// 4 ) q=0, price=0, value=0, cost, basis=0, capgains=0, taxOnSale=false, yearlyIncome, yearlyRevenue=yearyIncome
//
//read using calsAssetValues (for price, salePrice, netRent, income)  or calcAsset_taxAmount (for taxRate)
//  0 )  price      | taxRate
//  1 ) ...
//  2 ) ...  | taxRate
//  3 ) salePrice, netRent  |   taxRate
//   4) Income    |  constantIncome from assetLookup
//

function portfolioCalcValue(alist,adateStamp,pname,isMod) {

   let vs={};

   let totAssetSale=0,totNetAssetEst=0,totCost=0,totCapGains=0,totTaxOnSale=0,totLoanPayYear=0,totLoanOriginal=0,totLoanOwed=0;
   let nStock=0,nBond=0,nRegular=0,nTaxDefer=0,nProperty=0,nIncome=0,nLoan=0,nAsset=0;
   let totNetStock=0,totNetRegular=0,totNetTaxDeferred=0,totNetIncomeStream=0,totNetProperty=0,totBasis=0,totYearlyIncome=0,totYearlyNetRent=0,totYearlyRevenue=0;
   let totTaxIncomes=0,totTaxDividends=0,totTaxRegular=0,totRefiCost=0,totAcqCost=0,totPurchaseCost=0,totAdditions=0;
//     wsurvey.dumpObj(alist,1,' for pname '+pname);
   for (let i1=0;i1<alist.length;i1++) {

     let goo;
     let aList1=alist[i1];
     let sname=aList1['name'];
     let assetType=aList1['assetType'];
     let incomeStart=(aList1.hasOwnProperty('incomeStart')) ? aList1['incomeStart'] : false;

     let dval=calcAssetValues_2(sname,adateStamp,isMod,incomeStart) ;     // get "current" info (for adateSatmp)  -- incomeStart non-false if "fixed" incomeStream7
     if (dval===false) {
        displayStatusMessage(' (initializing portfolio: '+pname+')',1);
        return false ; //  calcAssetValues_2 will display a statusmessage
   }

//     wsurvey.dumpObj(dval,1,'portfolioCalcValue dval (for '+sname+' on '+adateStamp);

     let qAmount=0,value1=0,net1=0,cost1=0,capGains=0,yearlyIncome=0,yearlyNetRent=0,yearlyRevenue=0,abasis=0,aprice=0,tax1=0,acqCost=0,purchaseCost=0 ;
         loanPayYearly=0,loanAmount=0,loanOwed=0,daLoan=false,incomeStart=false   ;

     if (assetType==0) {
          qAmount=parseFloat(aList1['nShares']);
          aprice=parseFloat(dval[4]['price']);

          value1=qAmount*aprice;
          cost1=value1 ;
          acqCost=0;
          purchaseCost=cost1;
          abasis=parseFloat(aList1['basis']);

          capGains =value1-abasis;           // do NOT use calcAsset_capGainsAmount-- since calcAsset_taxAmount accounts for taxFreeFrac
          tax1= parseFloat(calcAsset_taxAmount(sname,capGains,1));
          net1=(value1-tax1);

          nStock++;
          nAsset++ ;
          totNetStock+=net1;

     } else if (assetType==1  )  {    // nshares is the $ value and cost
          qAmount=parseFloat(aList1['nShares']);

          value1=qAmount;
          net1=value1;

          cost1=value1;
          acqCost=0;
          purchaseCost=cost1;

          capGains=0;
          abasis=0;
          aprice=1.0;
          tax1=false ;
          nRegular++ ;
          nBond++;
          nAsset++ ;
          totNetRegular+=net1 ;

     } else if ( assetType==2)  {    // nshares is the $ expenditure
          qAmount=parseFloat(aList1['nShares']);
          value1=qAmount;

          tax1= parseFloat(calcAsset_taxAmount(sname,value1,1)); // payment of deferred tax is on everything
          let taxRate= parseFloat(calcAsset_taxRate(sname,1));
          net1=value1-tax1;
          cost1=value1*(1-taxRate);    // assume pre-tax income is used to acquire tax deerred bonds, so actual cost is net of reduced income tax
          purchaseCost=cost1;
          acqCost=0;

          capGains=0;

          abasis=0;
          aprice=1.0;
          nBond++;
          nTaxDefer++;
          nAsset++ ;
          totNetTaxDeferred+=net1;

     } else if (assetType==3 ) {

          qAmount=1;
          value1=parseFloat(dval[4]['salePrice']);

          cost1=(aList1.hasOwnProperty('costOrig')) ?  aList1['costOrig'] :  aList1['cost'] ;
          cost1=parseFloat(cost1);
          acqCost=cost1;
          purchaseCost=0 ;

          abasis=parseFloat(aList1['basis']);

          let aloan=parseFloat(aList1['loanAmount']);

          yearlyNetRent=parseFloat(dval[4]['netRent']);  //  should NOT included mortgate (that's done below). NET means net of costs .. NOT after tax!
          yearlyRevenue=yearlyNetRent ;

          if (aloan>0) {
           let istart=aList1['loanStart'];
           if (istart!='') {                  // istart='' if this an info row, not a changeable one
              let aterm=aList1['loanTerm'];
              let arate=parseFloat(aList1['loanRate']);

              let aDeduct=aList1['loanTaxDeduct'];
              let aAmount=aList1['loanAmount'];
              loanOwed=parseFloat(aList1['loanOwed']) ;

              if (!portfolioLoans.hasOwnProperty(pname)  ||
                   !portfolioLoans[pname].hasOwnProperty(istart)  ||
                   !portfolioLoans[pname][istart].hasOwnProperty(sname) ) {     // a new loan!
                     let refi1=(aList1.hasOwnProperty('refiCost')) ? aList1['refiCost'] : 0 ;
                     daLoan={'startDate':istart,
                        'amount':aAmount,'term':aterm,'rate':arate,'taxDeduct':aDeduct,'refiCost':refi1,'owed':loanOwed};  // this is all we need
              }  else {

                  daLoan=portfolioLoans[pname][istart][sname]['loanSchedule'];
                  daLoan['startDate']=istart ;

                  let arefi=(jQuery.isNumeric(aList1['refiCost'])) ? aList1['refiCost'] : 0 ;
                  daLoan['refiCost']=arefi ;
                  totRefiCost+=arefi ;
                  daLoan['cumMonth']={};     // not needed   -- loan is recreated when read back from server (makePortfolioLoans()
                  daLoan['cumYear']={};     // not needed

                  let monthPay=daLoan['monthPay'];
                  let yearPay=daLoan['yearPay'];
                  loanPayYearly=yearPay;
                  nLoan++;
                  loanAmount=aloan;


              } // loan exists

           } else {            // ismod=1
              nLoan++;
              loanAmount=aloan;
              loanPayYearly=parseFloat(aList1['loanPayYearly']) ;
            }
          }            // non 0 loan

          capGains=value1-abasis ;               // do NOT use calcAsset_capGainsAmount-- since calcAsset_taxAmount accounts for taxFreeFrac
          tax1=  calcAsset_taxAmount(sname,capGains,1) ;

         let tnet=net1;
          net1=value1-Math.max(tax1,0);        // pay the cap gains tax (if >0) -- deal with losses when calculating correct total   net value
          net1=net1-loanOwed ;       // and pay off loan

          totNetProperty+=net1 ;

          aprice=value1;
          nProperty++;
          nAsset++ ;

     } else if (assetType==4 ) {
          qAmount=0;
          value1=0;
          net1=0;

          cost1=(aList1.hasOwnProperty('costOrig')) ?  aList1['costOrig'] :  aList1['cost'] ;
          cost1=parseFloat(cost1);
          purchaseCost=0 ;
          acqCost=cost1;

          capGains=0;
          yearlyIncome=dval[4]['income'];
          yearlyRevenue=yearlyIncome ;
          if (doAssetLookup(sname,'constantIncome')==1) incomeStart=aList1['incomeStart'];

          abasis=0;
          aprice=0;
          tax1=false ;
          nIncome++;
          let taxest=calcAsset_taxAmount(sname,yearlyIncome,0) ;
          totNetIncomeStream+=(yearlyIncome-taxest);
     }

     totAssetSale+=value1;
     totNetAssetEst+=net1;
     totCost+=cost1;
     totAcqCost+=acqCost;
     totPurchaseCost+=purchaseCost ;
     totCapGains+=capGains;
     totBasis+=abasis ;

     if (tax1!==false) totTaxOnSale+=tax1;
     totLoanPayYear+=loanPayYearly;

     totLoanOriginal=parseFloat(totLoanOriginal)+parseFloat(loanAmount);
     totLoanOwed=parseFloat(totLoanOwed)+ loanOwed ;

     totYearlyIncome+=yearlyIncome;
     totYearlyNetRent+=yearlyNetRent ;
     totYearlyRevenue+=yearlyRevenue;
     goo={'assetType':assetType,'q':qAmount,'value':value1,'netValue':net1,'cost':cost1,'capGains':capGains,
           'yearlyIncome':yearlyIncome,'yearlyNetRent':yearlyNetRent,'yearlyRevenue':yearlyRevenue,'acqCost':acqCost,'purchaseCost':purchaseCost,
           'basis':abasis,'price':aprice,'taxOnSale':tax1,'loanOwed':loanOwed,'loanPayYearly':loanPayYearly,'loanSchedule':daLoan,
           'incomeStart':incomeStart};

     vs[sname]=goo;
   }    // alist ii ...

// these are "estimated" -- in particular, totNetAsset is summed over individual assets (and does NOT carefully account for negative capital gains)
   let tots={'totAssetSale':totAssetSale,'totNetAssetEst':totNetAssetEst,
            'totCost':totCost,'totAcqCost':totAcqCost,'totPurchaseCost':totPurchaseCost,
            'totCapGains':totCapGains,
             'totTaxOnSale':totTaxOnSale,'totLoanPayYear':totLoanPayYear,'totLoanOriginal':totLoanOriginal,'totLoanOwed':totLoanOwed,'totRefiCost':totRefiCost,
             'totNetStock':totNetStock,'totNetRegular':totNetRegular,'totNetTaxDeferred':totNetTaxDeferred,'totNetIncomeStream':totNetIncomeStream,
             'totNetProperty':totNetProperty,'totBasis':totBasis,

             'totYearlyIncome':totYearlyIncome,'totYearlyNetRent':totYearlyNetRent,'totYearlyRevenue':totYearlyRevenue,
             'nAsset':nAsset,'nStock':nStock,'nBond':nBond,'nRegular':nRegular,'nTaxDefer':nTaxDefer,'nProperty':nProperty,'nIncome':nIncome,'nLoan':nLoan
             };

  let oof=setEntryDate(adateStamp);

   return {'name':pname,'totals':tots,'assets':vs,'dateStamp':adateStamp,'dateStampSay':oof['sayDate']};

}

//==================
// front end to  portfolioCalcValueMenu -- creating an initialization entry by reading stuff from input fields
function   portfolioCalcValueMenu_init(athis) {
   let ethis=wsurvey.argJquery(athis);
    let pname=ethis.attr('data-name');

   let daval=portfolioCalcValueMenu(0,1,pname,0 ) ;

   if (daval==false) return 0 ;      // should not happen
   if (daval['errors'].length>0)  {      //errors
     let amess='<b>There are errors</b> in your initialization entry for <tt>'+pname+'</tt>';
     amess+='<ul>';
     amess+='<li>'+daval['errors'].join('<li>')+'</ul>';
     displayStatusMessage(amess);
     return 0;
   }
   let ebox=$('#portfolioHistory_footer');


   let summA= daval['summary'];
    $('#assetHistory_currentSummary').html(summA).show();
   let ecomment=ebox.find('[name="portfolioHistory_comment"]');

// alert notes -- not errors, but might be unintentional
  let alertMess=portfolioCalcValueMenu_alerts(daval,0,0)
   if (alertMess!='') {
       let bmess='<em>Please note: </em>';
       bmess+=alertMess;
       $('#assetHistory_modifiedSummary').html(bmess);
       $('#assetHistory_modifiedSummary').show();
   } else {
       $('#assetHistory_modifiedSummary').hide();
   }

// show warning
    let tcost=daval['totals']['totCost'];
    let cdiff=daval['cashAsset'] ;
    let abudget=daval['origBudget']
     portfolioCalcValueMenuWarn(cdiff,0,abudget,tcost) ;  // write warning messages?

// enabel comment input field (optional)
   ecomment.show();

}

//=============
// find oddities in current asset mix (i.e.; revenue < loan payments
function portfolioCalcValueMenu_alerts(daval,shorter,totalsOnly) {
  let alerts=[] ;
  if (totalsOnly==0) {
   for (let zasset in daval['assets']) {
      asset1=daval['assets'][zasset];
      if (asset1['assetType']==3) {
         let v1=asset1['acqCost']+asset1['loanOwed'];  //will be same as loanAmount (at initialization)
         dv1=v1-asset1['price'] ;
         if (dv1<-10)  {          // ignore small differences
              let amess;
              if (shorter==0) {
                amess='Property <tt>'+zasset+'</tt>: (acquisition cost + loanAmount) is less than price (is the difference part of your endowment?)';
              } else {
                amess=zasset+'</tt>: costs &lt; price';
             }   // shoter
             alerts.push(amess);
          }   // dv1
      }    // type=3
   }   // zasset
 }     // totalsonly

   let dExpense=daval['totals']['totYearlyRevenue']-daval['totals']['totLoanPayYear'] ;

   if (dExpense<-10) {
       let amess;
       if (shorter==0)   {
          amess='Total revenue (rents+incomes) is less than  loan payments (<u>Cash</u> will decrease over time) ';
      } else {
          amess='totalRevenue &lt; loanPayments';
       }
       alerts.push(amess);
   }

   if (alerts.length>0) {
      let bmess='';
       bmess+='<ul class="tightMenu">';
       bmess+='<li>'+alerts.join('<li>')+'</ul>';
       return bmess;
   } else {
      return '';
   }

    return bmess;


}

//================      assetLookup  cost
// calcuate the value (in $) of a portfolio (mix of assets)
//   -- read data from an onscreen asset mix  menu (init or modify modes)
//   -- call portfolioCalcValue to convert this data into an 'entry' object
//
// returns  ... what portFolioCalcValue returns , plus  more stuff
//
// Reads a menu createe by buildPortfolioMenu -- and which can be added to by the user  (selecting assets, removing, etc.)
//    buildPortfolioMenu invoked via a "init" button on the list of porfolios menu, or as part of a modifcation (by showModifyPortfolio_step2 )
//
// if isMod=1 if this is called from a "created modification" -- it controls some screen output
// if quiet=1, suppress   messages and screen output -- and if there is an input error, return false
// pname : name of this portfolio (this is saved as the 'name' property)
// showSummary: 0 (default) --do not write summary to box, 1: do write summary. Summary is always returned as html text (in the 'summary' property)
 //             2 : do NOT write summary, and do NOT compute "actual" results. This is only used by portfolioCalcValueMenu_modify (since
 //             portfolioCalcValueMenu_modify will calculate acutal results in  a later step

function portfolioCalcValueMenu(isMod,quiet,pname,showSummary ) {

   if (arguments.length<4) showSummary=0;

    let errors=[];        // list of errors IF quiet=1 (otherwise, not filled)
   let comments={} ;
   d1=getCreationDate(1);     // gets the user entered date, or "hidden" fields (as created by buildPortfolioMenu
   if (d1===false) {
       if (quiet!=1) {
          alert('Please enter a proper creation date ');
          return false;
       }
       errors.push('Please enter a proper creation date ') ;
   }

   let  pDateCount=d1['dayCount'];

   let etable=$('#portfolioHistory1');

   let ebaseIth=etable.find('[name="baseEntry_ith"]');
   let base_ith=ebaseIth.val();
   let ebaseDate=etable.find('[name="baseEntry_closestDate"]');
   let base_date=ebaseDate.val();

   let abudget,origBudget ;

  if (isMod==0) {     // is there a legit budget
     let ebudget=etable.find('[name="portfolioBudget"]');
     let abudget0=jQuery.trim(ebudget.val());
     abudget=fixNumberValue(abudget0) ;
     if (abudget===false) {
       if (quiet!=1) {
          alert('Please enter a budget (a number> 0) : '+abudget0);
          return false;
       }
       errors.push('Please enter a budget (a number> 0) : '+abudget0) ;
       return {'errors':errors};       // immediately fatal
     }        // error
     ebudget.attr('data-budget',abudget);
     origBudget=false;

  } else {                // read saved budget
      origBudget=portfolioInit[pname]['original']['budget']
      let enetVal=etable.find('[name="totNet_value"]');
      abudget=parseFloat(enetVal.attr('data-value'));           // use the netValue as the budget  (in % calculatoins)
  }

   let efields=etable.find('.portfolioAssetNameNew');
   let alist=[],eelookup={} ;

   for (let i1=0;i1<efields.length;i1++) {
      let nshares=false,cost=false,aprice=false,abasis=false,loanAmount=false,loanRate=false,loanTerm=false,loanTaxDeduct=false,loanRefinance=false,acomment='';  //  portfolioCalcValueMenu
      let loanOwed=false,loanStart=false,loanPayYearly=false,incomeStart=false,refiCost=false,acqCost=false,purchaseCost=false;

      let aefield=$(efields[i1]);
      let aname=jQuery.trim(aefield.val()).toLowerCase();
      if (aname=='') continue ;
      if (aname=='cash') {          // cash is reserved
         if (quiet!=1) {
           alert('Sorry : `cash` can not be used as an asset name ');
           return false;
         }
         errors.push('Sorry : `cash` can not be used as an asset name ');
         return {'errors':errors};       // immediately fatal

      }
      if (!assetLookup.hasOwnProperty(aname)) {
           if (quiet!=1) {
             alert('Unspecified asset ... '+aname);
             return false;
           }
           errors.push('Unspecified asset ... '+aname);
           return {'errors':errors};       // immediately fatal
      }

      let etr=aefield.closest('tr');
      let aremove=etr.attr('data-remove');
      if (aremove==1) continue ;           // a removed row .. skip!

      let eModStatus=etr.find('[name="modStatus"]');
      let modStatus=0;           // if init, can be modified
       if (eModStatus.length==1) {
           modStatus=eModStatus.val();
       }

//      let aLookup=assetLookup[aname];
      let assetType=doAssetLookup(aname,'assetType',2);

      let etype=etr.find('.portfolioAssetTypeNew');

      if (assetType==0) {            // lookup shares and basis

        let eshare1=etr.find('[name="portfolioShares"]');
         nshares=jQuery.trim(eshare1.val());
        if (nshares=='') nshares='0';

        let bprice=assetValuesCurrent[aname][4]['price'];
        nshares=portfolioCalcValueMenu_readVal(nshares,abudget,bprice,aname,0,quiet);
        if (nshares===false) return false ;       // quiet =0 and an error
        if (typeof(nshares)=='string') {
            errors.push(nshares);
            nshares=0;            // to avoid errors below
        }

        let ebasis=etr.find('[name="portfolioSharesBasis"]');
        abasis=jQuery.trim(ebasis.val());
        if (abasis=='') abasis='100%';
        abasis=portfolioCalcValueMenu_readVal(abasis,bprice*nshares,1.0,aname,0,quiet);
        if (abasis===false) return false ;
        if (typeof(abasis)=='string')  {
            errors.push(abasis);
            abasis=0;                  // to avoid errors below
        } else {
             cost=nshares*bprice;
             purchaseCost=cost;
             acqCost=0;
             eshare1.val(nshares.toFixed(2));
             ebasis.val(abasis.toFixed(0));
        }

    } else if (assetType==1  ) {
        let eshare1=etr.find('[name="portfolioShares"]');
        nshares=jQuery.trim(eshare1.val());
        if (nshares=='') nshares='0';
        nshares=portfolioCalcValueMenu_readVal(nshares,abudget,1.0,aname,0,quiet);

        if (nshares===false) return false ;
        if (typeof(nshares)=='string') {
           errors.push(nshares);
           cost=0;
        } else {
           cost=nshares ;
           eshare1.val(nshares.toFixed(2));
        }
        purchaseCost=cost;
        acqCost=0;

    } else if (assetType==2) {
        let eshare1=etr.find('[name="portfolioShares"]');
        nshares=jQuery.trim(eshare1.val());
        if (nshares=='') nshares='0';
        let txrate=calcAsset_taxRate(2,1)   ;

        let vv1=1.0-txrate;
        nshares=portfolioCalcValueMenu_readVal(nshares,abudget,vv1,aname,0,quiet);
        if (nshares===false) return false ;
        if (typeof(nshares)=='string') {
            errors.push(nshares);
            cost=0;
        } else {
           cost=nshares*(1-txrate);
           eshare1.val(nshares.toFixed(2));
        }
        purchaseCost=cost;
        acqCost=0;

    } else if (assetType==3  ) {

        if (modStatus==0)        { // if 1, can't change
            aprice=assetValuesCurrent[aname][4]['salePrice'];
            let ecost1=etr.find('[name="portfolioShares"]');  // portfolioShares is not a good name for "upfront costs", but wth
            cost=jQuery.trim(ecost1.val());

            if (cost=='') cost='0';
            cost=portfolioCalcValueMenu_readVal(cost,aprice,1.0,aname,false,quiet);
            if (cost===false) return false ;
            if (typeof(cost)=='string') {
                  errors.push(cost);
                  cost=0;  // avoid errors below
            } else {
                  ecost1.val(cost.toFixed(0));
            }
            acqCost=cost;
            purchaseCost=0;

            let ebasis=etr.find('[name="portfolioPropertyBasis"]');
            abasis=jQuery.trim(ebasis.val());
            if (abasis=='') abasis='100%';
            abasis=portfolioCalcValueMenu_readVal(abasis,aprice,1.0,aname,0,quiet);
            if (abasis===false) return false ;
            if (typeof(abasis)=='string') {
                 errors.push(abasis);
           } else {
              ebasis.val(abasis.toFixed(0));
           }
           let eloanAmount=etr.find('[name="portfolioLoanAmount"]');
           loanAmount=jQuery.trim(eloanAmount.val());
           if (loanAmount=='') loanAmount=0;
           loanAmount=portfolioCalcValueMenu_readVal(loanAmount,aprice,1.0,aname,false,quiet);
           if (loanAmount===false) return false ;    // error !

           if (typeof(loanAmount)=='string') {      //  error !
               errors.push(loanAmount);
          } else {
             eloanAmount.val(loanAmount.toFixed(0));       // update input form
             loanTerm=0;loanRate=0;loanTaxDeduct=0;
             if (loanAmount>0) {
               let eloanTerm=etr.find('[name="portfolioLoanTerm"]');
               loanTerm=jQuery.trim(eloanTerm.val());
               if (loanTerm=='') loanTerm='0';
               loanTerm=portfolioCalcValueMenu_readVal(loanTerm,false,1.0,aname,0,quiet);
               if (loanTerm===false) return false ;
               if (typeof(loanTerm)=='string') {
                  errors.push(loanTerm);
               } else {
                  eloanTerm.val(loanTerm.toFixed(0));
               }
               let eloanRate=etr.find('[name="portfolioLoanRate"]');
               loanRate=jQuery.trim(eloanRate.val());
               if (loanRate=='') loanRate='0';
               loanRate=portfolioCalcValueMenu_readVal(loanRate,100,1.0,aname,0,quiet);
               if (loanRate===false) return false ;
               if (typeof(loanRate)=='string') {
                      errors.push(loanRate);
               } else {
                  eloanRate.val(loanRate.toFixed(2));
               }
               let eloanTaxDeduct=etr.find('[name="portfolioLoanTaxDeductInt"]');
               loanTaxDeduct=(eloanTaxDeduct.prop('checked')) ? 1 : 0 ;
             }         // loanamount>0
          }        // loanamount input not an error

          loanOwed=loanAmount;
          loanStart=pDateCount ;

        } else {            // modstatus=1, don't change just read current prepopulated values  -- UNLESS is a refinance

            let eloanAmount=etr.find('[name="portfolioLoanAmount"]');
            loanAmount=parseFloat(jQuery.trim(eloanAmount.val()));

            let eloanOwed=etr.find('[name="portfolioLoanOwed"]');
            loanOwed=parseFloat(jQuery.trim(eloanOwed.val()));

            let eloanPay=etr.find('[name="portfolioLoanPay"]');
            loanPayYearly=parseFloat(jQuery.trim(eloanPay.val()));

            let ecost1=etr.find('[name="portfolioShares"]');  // should  porfolioUpfrontCosts.. but wth

            cost=parseFloat(ecost1.attr('data-orig'));
            acqCost=cost;
            purchaseCost=0;

            let ebasis=etr.find('[name="portfolioPropertyBasis"]');
            abasis=parseFloat(ebasis.attr('data-orig'));
            loanStart='' ;

            let erefi=etr.find('[name="portfolioLoanRefinance"]');   // set to 1 if a refinance was chosen (and not reset)
            loanRefinance=erefi.val();

            if (loanRefinance==1)  {   // a refinance

               let eloanRate=etr.find('[name="portfolioLoanRate"]');
               loanRate=jQuery.trim(eloanRate.val());
               loanRate=parseFloat(loanRate);

               let eloanTerm=etr.find('[name="portfolioLoanTerm"]');
               loanTerm=jQuery.trim(eloanTerm.val());
               loanTerm=parseInt(loanTerm);

               let eTaxd=etr.find('[name="portfolioTaxDeduct"]');
               loanTaxDeduct=parseInt(jQuery.trim(eTaxd.val()));

               let eLcost=etr.find('[name="portfolioRefiCost"]');
               refiCost=parseFloat(jQuery.trim(eLcost.val()));

               loanStart=pDateCount ;

            }

// note: refinance can occur, using stuff added to the form by  portfolio_loanRefinance3

        }

        if (loanAmount>0 && loanTerm<=0 && isMod==0) {
            if (quiet==0) {
               alert('You specified a loan amount for '+aname+' ('+wsurvey.addComma(parseInt(loanAmount))+'), but not the term! ');
               return false ;
            } else {
               errors.push('You specified a loan amount for '+aname+' ('+wsurvey.addComma(parseInt(loanAmount))+'), but not the term! ');
            }
        }

    } else if (assetType==4  ) {

        let isConstant=doAssetLookup(aname,'constantIncome') ;

        if (modStatus==0) {           // allow chage
           let aincome=assetValuesCurrent[aname][4]['income'];     // assetValuesCurrent saved by portfolioBuildMenu

           let ecost1=etr.find('[name="portfolioShares"]');  // portfolioShares is not a good name for upfrontCosts .... but wth
           cost=jQuery.trim(ecost1.val());
           if (cost=='') cost='0';
           cost=portfolioCalcValueMenu_readVal(cost,aincome,1.0,aname,false,quiet);   // can be % of incomeStream
           if (cost===false) return false ;
           if (typeof(cost)=='string') {
             errors.push(cost);
          } else {
              ecost1.val(cost.toFixed(0));
           }
           incomeStart=(isConstant==0) ? false :  pDateCount ;       // use current date if not a mod (otherwise set it to false to flag this modification does NOT effect this incomestrea)

        } else {      // a mod ... no changes

            estart=etr.find('[name="incomeStart"]');    // hidden
            if (estart.length>0)   incomeStart=estart.val();     // used "saved" date
            if (incomeStart=='') incomeStart=false;

            let ecost1=etr.find('[name="portfolioShares"]');  // should  porfolioUpfrontCosts.. but wth
            cost=parseFloat(ecost1.attr('data-orig'));

        }
        if (typeof(cost)=='string')  errors.push(cost);
        purchaseCost=0;
        acqCost=cost;

    }       // acqCost purchaseCost

      let ecomment=etr.find('[name="portfolioComment"]');
      acomment=jQuery.trim(ecomment.val());
      acomment=wsurvey.removeAllTags(acomment);
      acomment.replace(/\n/g, ' ');
      comments[aname]=acomment;

      let aa={'name':aname,'assetType':assetType,'nShares':nshares,'basis':abasis,'costOrig':cost,'priceOrig':aprice,'price':aprice,'cost':cost,
            'loanOwed':loanOwed,'loanStart':loanStart,'loanPayYearly':loanPayYearly,
           'loanAmount':loanAmount,'loanTerm':loanTerm,'loanRate':loanRate,'loanTaxDeduct':loanTaxDeduct,'loanRefinance':loanRefinance,'refiCost':refiCost,
           'incomeStart':incomeStart,'comment':acomment
          };
       alist.push(aa);
   }

   if (errors.length>0) return {'errors':errors};       // immediately fatal

   let daval=portfolioCalcValue(alist,pDateCount,pname,isMod);   // portfolioCalcValueMenu: get $values, etc of the user inputs (using inputs saved in alist)

   daval['baseEntry']={'ith':base_ith,'dateStamp':base_date};

// put comments in to daval['assets'][assetName]
   for (let zname in daval['assets']) {
        let acomment= (comments.hasOwnProperty(zname)) ? comments[zname] : ' ' ;
        daval['assets'][zname]['comment']=acomment ;
   }

// fill in asset summary info cells (that starts with asset price,etc info)

  let eins=etable.find('[name="portfolioAsset"]');
  for (let ii=0;ii<eins.length;ii++) {
     let ein=$(eins[ii]);
     let etr1=ein.closest('.portfolioHistoryRow');
     if (etr1.attr('data-remove')==1) continue ;

     let aname=ein.attr('data-orig');
     let etr=ein.closest('.portfolioHistoryRow');
     let esummary=etr.find('.cportfolioTable1_summaryCell');
     let  tbdSay=addARowPortfolioAssetMix_assetSummary(aname,daval);
     esummary.html( tbdSay);
  }

  let tcost= daval['totals']['totCost'];

  daval['cashAsset']='';           // if isMod=1 will be filled in by _modify

  if (isMod==0)        {  // check difference between costs and budget ...
    let tcost=daval['totals']['totCost'];
    let cdiff=abudget-tcost ;         // abudget is either the original budget (specified at creation), or the current netValue (on modification dat)
    let cdiffSay=wsurvey.addComma(parseInt(cdiff));
    let ercash=etable.find('[name="portfolioCashRemain"]');
    ercash.val(cdiffSay);
    ercash.attr('data-value',cdiff);                  // these might be overwritten (by portfolioCalcValueMenu_modify

     if (quiet!=1) {
        portfolioCalcValueMenuWarn(cdiff,isMod,abudget,tcost) ;  // write warning messages?
     }            // quiet
     daval['cashAsset']=cdiff;
   }

   daval['errors']=errors ;           // array of length=0 signals no errors -- note that if quiet=0 this is ALWAY []
   daval['assetList']=alist ;
   daval['comment']='creation entry' ;
   if (isMod==0) {
      daval['origBudget']= abudget ;
   } else {
      daval['origBudget']= origBudget ;
   }

   daval['totNetAllEst']=daval['totals']['totNetAssetEst']+daval['cashAsset'];   //  overwritten below (if showSummary !==2)


// show the appropriate  col 4 header
  let daheaders=etable.find('.cAllocationHeader');
  daheaders.hide();
  let da1=etable.find('[name="allocationHeader_allocation"]');
  da1.show();

   if (showSummary==2) return daval ;  // don't bother making summary or totalsG  -- it will be done in portfolioCalcValueMenu_modify (the only place where showsummary argument =2

// if here, create some accurate totals, and summary info

   daval['totalsG']=calc_netValues(daval);  // in portfolioCalcValueMenu ... portfolio_totalSummary uses totalsG

    let summA;
    if (isMod==0)  {
          summA=portfolio_initTotalSummary(daval,'<em>to be created</em>',0);
     } else {
       summA=portfolio_totalSummary(daval,'<em>before modification</em>',1);
     }


   daval['summary']=summA ;

   if (showSummary==1)  $('#assetHistory_currentSummary').html(summA).show();

   return daval ;
}

//=====================     showSummary       pDateCount  noChange      aLookup   a1    assetList
// show warning if large Casu
function portfolioCalcValueMenuWarn(cdiff,isMod,abudget,cost) {

  let dmess;
  let cdiffCheck= (Math.abs(cdiff)<budgetAllocationTest) ? 0  : cdiff;  // don't worry if less than $budgetAllocationTest off
  if (cdiffCheck<0) {      // note use of attributes to contain current values (rather than recalling portfolioCalcValue
        if (isMod!=1)  {
          dmess='<div style="padding:5px;background-color:yellow;color:black"><b>Warning:</b> you have allocated <b>'+wsurvey.makeNumberK(-cdiff,9999)+'</b>  more than your budget!</div>';
          dmess+=' You can: retain the difference in <u>Cash</u>; change the #shares of one or more assets; ';
          dmess+='   ... or...   ';
          dmess+='<input type="button" value="adjust your budget"   onClick="portfolioInitBudgetAdjust(this)" ';
          dmess+='  data-budget="'+abudget+'"  data-val="'+cdiff+'" data-cost="'+cost+'"  > ';
        } else {        // mod: warrning only (budget reset not allowed)
           dmess='<div style="padding:5px;background-color:yellow;color:black"><b>Warning:</b> you have allocated '+wsurvey.makeNumberK(-cdiff,9999)+'  more than your current netValue!</div>';
          dmess+=' You can: retain the difference to <u>Cash</u>, or change the #shares of one or more assets. ';
        }
        dmess+='</div>'
        $('#assetHistory_currentSummaryNote').html(dmess).show();
   }
   if (cdiffCheck>0) {
        if (isMod!=1)  {
           dmess='<div style="padding:5px;background-color:#def8d3;color:black"><em>Note</em>: you have <u>not</u> allocated your entire budget to the assets ('+wsurvey.makeNumberK(cdiff,9999)+' remaining)!</div> ';
           dmess+=' You can: retain the difference to <u>Cash</u>; change the #shares of one or more assets; remove an asset ; ';
           dmess+='   ... or...   ';
           dmess+='<input type="button" value="adjust your budget"   onClick="portfolioInitBudgetAdjust(this)" ';
           dmess+='  data-budget="'+abudget+'"  data-val="'+cdiff+'" data-cost="'+cost+'"  > ';

         } else {        // mod: warrning only (budget reset not allowed)
           dmess='<div style="padding:5px;background-color:#def8d3;color:black"><em>Note</em>: you have <u>not</u> allocated your entire budget to match your current netValue ('+wsurvey.makeNumberK(cdiff,9999)+' remaining)!</div> ';
           dmess+=' You can: retain the difference to <u>Cash</u>,  change the #shares of one or more assets, or add an asset';
         }
        dmess+='</div>'
        $('#assetHistory_currentSummaryNote').html(dmess).show();
   }
   if (cdiffCheck==0) {
          dmess='Your budget is fully allocated';
          if (isMod!=1) {
                dmess+='<br>If you have extra <u>Cash</u>, you can ... ';
                dmess+='<input type="button" value="adjust your budget"   onClick="portfolioInitBudgetAdjust(this)" ';
                dmess+='  data-budget="'+abudget+'"  data-val="'+cdiff+'" data-cost="'+cost+'"  > ';
          }
   }
   $('#assetHistory_currentSummaryNote').html(dmess).show();

   return 1;

}

//==================
// Reads input values from a "modify" page.
// The modify page starts with the "grown" values (of a "nearest to chosen date" asset-mix"
// portfolioCalcValueMenu_modify then uses these input values, and the pre-modified   values (the "grown" values)
// These are combined  by portfolioCalcValueMenu_difference to create a new entry
//
// Called by 'calculate modified value' button --  on the menu showing the "grown" values
//   and from reviewPortfolioMod and saveModifiedPortolio
//
// Note that some values are NOT changable (such as loan parameters, and income acquisition costs) -- since they are set when the asset is first added
// and do not change over time.
//
// This uses entryWorking global, that is saved by showModifyPortfolio_step2 (using the return from  growPortfolio)
//

function portfolioCalcValueMenu_modify(athis,pname) {

  if (arguments.length<2) {
    let ethis=wsurvey.argJquery(athis);
    pname=ethis.attr('data-name');
  }

// check for duplicate asset entries
   if (sameAssetFamilyOk==0)  {    //   check for more than one members of a family
     let haveList=portfolioMenu_assetFamily(2);
     let gots={},errs=[];
     for (let a1 in haveList) {
        let afam=haveList[a1];
        if (gots.hasOwnProperty(afam)) {
            errs.push('More than one asset in family: '+afam);
        } else {
           gots[afam]=1;
        }
     }
     if (errs.length>0) {
        let errMess='Problems: <ul><li>'+errs.join('<li>')+'</ul>';
        displayStatusMessage(errMess);
        return 0;
     }
  }    // sameAssetFamilyOk


// read the values (possibly modified by user) in the portoflio table
   currentEntry=portfolioCalcValueMenu(1,1,pname,2);   // in portfolioCalcValueMenu_modify -- read whatever modifications might of been made
   let origCashAsset=currentEntry['cashAsset'];

   if (currentEntry===false ) {
      alert('There are errors in your input. Please fix and try again.\nClick `Calculate portfolio value` for the details! ');
      return 0;
   }

   if (currentEntry['errors'].length>0) {
       let amess='';
       amess+='There are input errors ... please fix them and try again! ';
       amess+='<ul><li>';
       amess+=currentEntry['errors'].join('<li>');
       amess+='</ul>';
      displayStatusMessage(amess);
      return false
   }

  let modifiedEntry=portfolioCalcValueMenu_difference(entryWorking,currentEntry) ;    // the changes due to modification (from the "grown" base)


  modifiedEntry['original']=entryWorking['original'];
  modifiedEntry['changesGrow']=entryWorking['changesGrow'];
   let cashAssetFromEntryWorking=entryWorking['cashAsset'];
   let cashAssetChangeMods=modifiedEntry['changesModify']['netProceeds']-modifiedEntry['changesModify']['totRefiCost'] ;
   modifiedEntry['cashAsset']=cashAssetFromEntryWorking+cashAssetChangeMods ;

  modifiedEntry['totalsG']= calc_netValues(modifiedEntry ,entryWorking)  ; // fix netValues ,etc. Note that portfolioCalcValueMenu was  told NOT to do this!

   modifiedEntry['totNetValue']=modifiedEntry['totalsG']['totNetValue']  ;     // actual


 // update some fields on the portoflio table
  let etable=$('#portfolioHistory1');

 //
  let eccash=etable.find('[name="portfolioCashRemain"]');   // 22  june ... for info purposes (data saved in modifiedEntry)
  let cashRemain=modifiedEntry['cashAsset'];        // accounts for interest during "growth" period .. but modificatnion caused changes used as is
  eccash.attr('data-value',cashRemain);
  let oof=wsurvey.addComma(parseInt(cashRemain));
  eccash.val(oof);

   modifiedEntry['comment'] ='ready to modify (grown entry): '+modifiedEntry['dateStampSay'];

    modifiedEntry['original']=entryWorking['original'];
    modifiedEntry['changesGrow']=entryWorking['changesGrow'];

   let alertMess=portfolioCalcValueMenu_alerts(modifiedEntry,1,1) ;
   let bmess ;
   if (alertMess!='') {
       bmess=alertMess;
   } else {
       bmess='';
   }

// 3 JULY Fix this (for mod, don't report growth stuff, do report mod stuff!
   summA=portfolio_totalSummary(modifiedEntry,'<em>after modification</em>'+bmess,1,1);

   $('#assetHistory_modifiedSummary').html(summA).show();

       let alistNew=[];
      for (let zasset in modifiedEntry['assets']) {
          let z1=modifiedEntry['assets'][zasset];
          let aa={};
          let atype=z1['assetType'];
          aa['name']=zasset;
          aa['assetType']=atype;
          aa['nShares']=z1['q'];
          aa['basis']=z1['basis'];
          aa['cost']=z1['cost'];
//          aa['makeLoan']= (atype==3) ? 0 : false ;
          aa['loanOwed']=z1['loanOwed'];
          let lschedule=z1['loanSchedule'];
          aa['loanStart'] = (lschedule) ? z1['loanSchedule']['startDate'] :  false;
          aa['loanPayYearly'] = (lschedule) ? z1['loanSchedule']['yearPay'] :  false;
          aa['loanAmount'] = (lschedule) ? z1['loanSchedule']['amount'] :  false;

          aa['loanTerm'] = (lschedule) ? z1['loanSchedule']['term'] :  false;
          aa['loanRate'] = (lschedule) ? z1['loanSchedule']['rate'] :  false;
          aa['loanTaxDeduct'] = (lschedule) ? z1['loanSchedule']['taxDeduct'] :  false;

          aa['comment']=z1['comment'] ;

           aa['incomeStart']=z1['incomeStart'];

          alistNew.push(aa);
    }
    modifiedEntry['assetList']=alistNew;      // this can be sent to portfolioCalcValue

    let tnet=modifiedEntry['totNetValue'];       // issue a warning?
    let cashAssetNow=modifiedEntry['cashAsset'];
    portfolioCalcValueMenuWarn(cashAssetNow,1,tnet,false) ;  // write warning messages? false arg means "can NOT adjust")

  return modifiedEntry ;   // ignored if "button" call

}



//=======================     totalsg   portfolioCalcValue    showD
// convert string input into a number
// Handles special cases: xx% becomes percent of abase, $xx becomes # shares at a aprice and a xx expenditure
// aval0  string value read from input field
//  abase: value used to convert xx%
// aprice :value used to conver $xxxx. Can be 1.0, in which case $xxx is same as xxx
// varname: used in error messages
//  minVal : minimum allowed value. If false, no minimum. If a %, always check for 0 to 100

function portfolioCalcValueMenu_readVal(aval0,abase,aprice,varname,minVal,quiet) {

  if (typeof(aval0)=='number') return aval0          ; // seems to be needed when called by portfolioCalcValueMenu_modify
    if (arguments.length< 6) quiet=0;
    if (arguments.length< 5) minVal=false;

    let lastchar=aval0.slice(-1) ;
    let nshares,aval1,aval2;

    if (lastchar=='%') {        // % of base
         if (abase===false) {
            if (quiet!=1) {
               alert(' %input not allowed for for '+varname);
               return false;
            }
            return ' %input not allowed for for '+varname;
         }

         aval1=aval0.substr(0,aval0.length-1);
         aval2=fixNumberValue(aval1);
         if (aval2===false)  {
            if (quiet!=1) {
               alert('Bad %input ('+aval0+') for '+varname);
               return false;
            }
            return 'Bad %input ('+aval0+') for '+varname;
         }
         if (aval2>100.0 || aval2<0.0) {
            if (quiet!=1) {
              alert('Bad %input -- must be a value between 0 and 100 for '+varname);
              return false;
            }
            return 'Bad %input -- must be a value between 0 and 100 for '+varname;
         }

         nshares=((aval2/100.0)*abase)/aprice ;

         return nshares;
      }  // %

      if (aval0.substr(0,1)=='$'  ) {
         aval1=aval0.substr(1,aval0.length-1);
         aval2=fixNumberValue(aval1) ;
         if (aval2===false)  {
            if (quiet!=1) {
               alert('Bad $input ('+aval0+') for '+varname);
               return false;
            }
            return 'Bad $input ('+aval0+') for '+varname ;
         }
         nshares=aval1/aprice ;
         if (minVal!==false) {
            if (nshares<minVal) {
              if (quiet!=1) {
                 alert('Bad $input: must be greater than '+minVal+' ('+aval0+') for '+varname);
                 return false;
              }
              return  'Bad $input: must be greater than '+minVal+' ('+aval0+') for '+varname;
           }     // nsharse<minval
         }    // minval  ne false
         return nshares;

       }    // $

// not xx% or $xx -- read as is
      nshares=fixNumberValue(aval0);
      if (nshares===false) {
         if (quiet!=1) {
            alert('Bad ('+aval0+') for '+varname );
           return false;
         }
         return 'Bad ('+aval0+') for '+varname ;
      }
      if (minVal!==false) {
          if (nshares<minVal) {
              if (quiet!=1) {
                  alert('Bad  input: must be greater than '+minVal+' ('+aval0+') for '+varname);
                 return false;
              }
              return  'Bad  input: must be greater than '+minVal+' ('+aval0+') for '+varname;
          }      // nshares<minVal
        }

      return nshares ;
}

//==============  

// allocate "remaining cash" to an asset
function allocateCashToEmpty(athis,isMod) {
   let ethis=wsurvey.argJquery(athis);

   let pname=ethis.attr('data-name');
   let daVals ;
   if (arguments.length<2) isMod=0
   if (isMod==0) {
       daVals=portfolioCalcValueMenu(isMod,0,pname);  //  allocateCashToEmpty  ..  read user mods,  ... note summary and totalsG are NOT refreshed
   } else {
     daVals=portfolioCalcValueMenu_modify(athis,pname);   // read user modification... but if direct call to portfolioCalcValueMenu  other stuff gets messed up
   }
   if (daVals===false) return 1;
   if (daVals['errors'].length>0) {
           alert('There are errors in your input. Please use `calculate portfolio values` to view them');
           return 1;
   }


   let cdiff=daVals['cashAsset'];
   if (cdiff<0) {
       let summA=daVals['summary'];
       $('#assetHistory_currentSummary').html(summA).show();
       return ;        // can't auto fill if budget already exceeded
   }

   let dalist=daVals['assets'];

   for (let zasset in dalist) {
       let aType=getAssetType(zasset);
       if (aType==2 || aType==3 || aType==4) continue ;  // only autofill regular bonds and stocks
       if (dalist[zasset]['q']>0) continue ;              // not empty
// got a blank row! use it
       let etable=$('#portfolioHistory1AssetRows');
       let echeck=etable.find('[name="portfolioAsset"]');
       let euse=echeck.filter('[data-orig="'+zasset+'"]');
       let etr=euse.closest('.portfolioHistoryRow');
       let efill=etr.find('[name="portfolioShares"]');
       efill.val('$'+cdiff.toFixed(2))        ;
       if (isMod==0) {
          daVals=portfolioCalcValueMenu(isMod,0,pname,1);  //  allocateCashToEmpty ... read again, and update given tweaks done above
       } else {
          daVals=portfolioCalcValueMenu_modify(athis,pname)
       }

       if (daVals===false ) return 1;  // if false, alerts will have been displayed
       if (daVals['errors'].length >0) {
           alert('There are errors in your input. Please use `calculate portfolio values` to view them');
           return 1;
       }
       let summA=daVals['summary'];
       $('#assetHistory_currentSummary').html(summA).show();

       return 1;
   }
  let summA=daVals['summary'];
   $('#assetHistory_currentSummary').html(summA).show();

   alert('Please add another regular bond or stock asset. Or clear the #shares on a regular Bond, or a stock .. it will be assigned $'+wsurvey.addComma(parseInt(cdiff))+' ');
   return 0;

}


//==============================
// save a portfolio assetmix    -- initialization version
function savePortfolioInit(athis) {

  let ethis=wsurvey.argJquery(athis);
  let pname=ethis.attr('data-name');

// first calc portfolio value (even if it was just done)
  let davals=portfolioCalcValueMenu(0,1,pname,0);  //   savePortfolioInit .. reads again... so no need to 'calculate' button (or 'auto fill') first (don't bother with summary refresh)

  if (davals===false || davals['errors'].length>0) {
     alert('An error. Please fix and try again!\nClick `Calculate portfolio value` for the details!  ');  // this should can happen if loan terms are not specified
     return 0;
  }

  if (davals['errors'].length>0)  {         // errors encountred
    let amess='';
    amess+='There are input errors. Please fix them and try again! ';
    amess+='<ul><li>';
    amess+=davals['errors'].join('<li>');
     amess+='</ul>';
    displayStatusMessage(amess);
    return false
  }

  let abudget=davals['origBudget'];
  if (abudget===false) {   // should never be false. If it is, don't bother with confirm
    alert('A budget was not specified (must be a number >0)');
    return false;
}

 let ecc=$('#portfolioHistory_footer');
 let ecc2=ecc.find('[name="portfolioHistory_commentInput"]');
 let pcomment=jQuery.trim(ecc2.val());
   pcomment=wsurvey.removeAllTags(pcomment);
 if (pcomment=='') pcomment='Initialization entry for portfolio '+pname ;

  let drem=davals['cashAsset'];
  if (drem!=0 && warningLevel==0) {                     // a final reminder (suppress if warningLevel>0)
       let alimit=abudget*budgetRemainPct ;         // budgetRemainPct is global
       if (Math.abs(drem)>alimit ) {  // big enought oworry about (> 0.5% of budget?)
         let q ;
         if (drem<0) {
            q=confirm('Your budget is  '+wsurvey.addComma(parseInt(drem))+' less than the cost of your asset-mix. Are you sure you want to save it?');
         } else {
            q=confirm('You have  '+wsurvey.addComma(parseInt(drem))+' remaining in your budget. Are you sure you want to save it?');
         }
          if (!q) {
             portfolioCalcValueMenu(0,0,pname,1) ; // refresh displays
             return 1;
          }
       }
  }

  for (let ij=0;ij<davals['assetList'].length;ij++) {
       a0=davals['assetList'][ij];
       let aname=a0['name'];
       let acomment=davals['assets'][aname]['comment'];
       davals['assetList'][ij]['comment']=acomment;
  }

  let totalsG=calc_netValues(davals);  // 'correct' totals

  let origs={};
  origs['budget']=abudget;
   origs['date']=davals['dateStamp'];
   origs['dateSay']=davals['dateStampSay'];

  origs['totNetValue']=totalsG['totNetValue'];
  origs['totAssetSale']=totalsG['totAssetSale'];
  origs['totNetAsset']=totalsG['totNetAsset'];
  origs['totTaxSellAll']=totalsG['totTaxSellAll'];
  origs['totCapGainTaxSellAll']=totalsG['totCapGainTaxSellAll'];
  origs['totTaxDeferredSellAll']=totalsG['totTaxDeferredSellAll'];
  origs['cashAsset']=totalsG['cashAsset'];
  origs['totPropertySale']=totalsG['totPropertySale'];

   origs['cashAsset']=davals['totals']['cashAsset'];        // totalsG['cashAsset'] accounts for losses, but at this point use the difference between budget and cost
   origs['totBasis']=davals['totals']['totBasis'];
   origs['totCost']=davals['totals']['totCost'];
   origs['totRevenue']=davals['totals']['totYearlyRevenue'];
   origs['totLoanOriginal']=davals['totals']['totLoanOriginal'];
   origs['totLoanPayYear']=davals['totals']['totLoanPayYear'];

   davals['original']=origs;

   davals['isCreation']=1 ;  // somewhat unnecesesary

  origs['totNetValue']=totalsG['totNetValue'];         // use "corrected" values
  origs['totAssetSale']=totalsG['totAssetSale'];
  origs['totNetAsset']=totalsG['totNetAsset'];
  origs['totTaxSellAll']=totalsG['totTaxSellAll'];
  origs['totCapGainTaxSellAll']=totalsG['totCapGainTaxSellAll'];
  origs['totTaxDeferredSellAll']=totalsG['totTaxDeferredSellAll'];
  origs['cashAsset']=totalsG['cashAsset'];          // this cashAsset coudl be differnt than cost-budget  (due to transfer of losses)
  origs['totPropertySale']=totalsG['totPropertySale'];

//  save  info used to regenerate detailed dataon retrieval from server
  let davals0={};
  davals0['name']=pname;
  davals0['specifiedDate']=wsurvey.get_currentTime(31,1);
  davals0['userName']=davals['userName'];
  davals0['dateStamp']=davals['dateStamp'];
  davals0['dateStampSay']=davals['dateStampSay'];
  davals0['userName']=userName;
  davals0['cashAsset']=davals['cashAsset'];
  davals0['assetList']=  davals['assetList'];
  davals0['original']=origs;
  davals0['comment']=pcomment ;
  davals0['baseEntry']=0;            // 0 signals "initial entry"

  let ddata={};
  ddata['todo']='savePortfolioInit';
  ddata['portfolio']=pname;
  ddata['origBudget']=abudget;
  ddata['username']=userName;
  ddata['encMd5']=encryptionKey_md5;

  ddata['list']=davals0 ;   // creteats ['data':encryptedAlls,'encrypt':'' or encryptionKeyMd5
 
   saveSimInvData(ddata);

//  getSimInvData(ddata,'savePortfolioInit',sstuff);

}



//================   buyShare portfolioCalcValueMenu
// adjust  the budget  -- to cover specified asset mix, or whatever  -- only avaiable for portfolio initialization

function portfolioInitBudgetAdjust(athis) {
  let ethis=wsurvey.argJquery(athis);

  let abudget=ethis.attr('data-budget');
  let abudgetSay=wsurvey.addComma(parseInt(abudget));

  let cdiff=ethis.attr('data-val');
  let cdiffSay=wsurvey.addComma(parseInt(cdiff));
  let cost=ethis.attr('data-cost');
  let costSay=wsurvey.addComma(parseInt(cost));


  let amess='';
   amess+='<ul name="nAdjustBudget">';
  amess+='<li>Proposed budget: <tt>'+abudgetSay+'</tt>';
  amess+='<li>Cost of asset-mix: <tt>'+costSay+'</tt>';
  amess+='<li>Difference: <tt>'+cdiffSay+'</tt>';
  amess+='<li>You can set a <u>Cash</u> value: <input type="text" name="cashDesired" value="'+cdiffSay+'" size="6">';
  amess+='<tt>...<em>set to <tt>0</tt> (or empty) to adjust the budget to match your costs</tt></em>';
  amess+='<li><input type="button" onClick="portfolioInitBudgetAdjust2(this)" data-budget="'+abudget+'"  data-cost="'+cost+'" value="Adjust the proposed budget"> (using this <u>Cash</u> value)';
  amess=='</ul>';
  displayStatusMessage(amess);
  toggleStatusMessage(0,0);
}

// =============
// adjust the buget!
function portfolioInitBudgetAdjust2(athis) {
    let ethis=wsurvey.argJquery(athis);
    let abudget=parseFloat(ethis.attr('data-budget'));
    let cost=parseFloat(ethis.attr('data-cost'));
 
    let e1=ethis.closest('[name="nAdjustBudget"]');
    let eval=e1.find('[name="cashDesired"]');
    let aval0=eval.val();
    if (jQuery.trim(aval0)=='') aval0=0;
    let useval=portfolioCalcValueMenu_readVal(aval0,false,1,'CashAvailable',false);
    let  useBudget=parseInt(cost+useval);
    
    let  etable=$('#portfolioHistory1');
    let eb1=etable.find('[name="portfolioBudget"]');
    eb1.val(useBudget);
    eb1.attr('data-budget',useBudget);
    displayStatusMessage(false);
    
    let ebutton=$('#calcPValueButton');
    ebutton.trigger('click');
    return 1;
}
