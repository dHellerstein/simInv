 <?php


$key="myPwd";
$header="a test encryption  : xx :";

 // https://www.php.net/openssl_encrypt
//$key previously generated safely, ie: openssl_random_pseudo_bytes
$plaintext = "message t asfaso be encrypted";

$goo=['mess1'=>'this is message asdf asfd1','arf'=>153.1,'zoob'=>[1,5,122,33]];
print "<pre>The array (origional) "  ;
print_r($goo);
print '</pre>';

$goo1=serialize($goo );  // encode for web transmission
print "<pre>Goo1 (seralize):<br> ";
print_r($goo1);
print '</pre>';

$goo1Encrytped=wEncrypt($goo1,$key,$header );
print "<pre>goo1Encrytped (serialized, enctypred, base64):<br> ";
print_r($goo1Encrytped);
print '</pre>';

$goo2Decrypt=wDecrypt( $goo1Encrytped ,$key,1);  // $goo1Encrytped
print "<pre> goo2Decrypt (serialized):<br>";
print_r( $goo2Decrypt);
print '</pre>';

if ($goo2Decrypt[0]!==false) {
   $goo2=unserialize($goo2Decrypt[1]);
   print "<pre>goo2 (original):<br> ";
    print_r($goo2);
   print '</pre>';
} else {
   print "Error: ";
   print_r($goo2Decrypt[1]);
}
print "<br>";

//=========
// from https://www.php.net/openssl_encrypt
// encrypts plain text $amessText) using $akey.
// returns base64 encoded version of the encrypted text, with 'wEncryt. $message:' prepended
// Thus: wDecrypt looks for 'wEncrypt. xxx :', and removes it. If this is not found (and xxx can be anything, including ""
//       an error is returned
function wEncrypt($amessText,$key,$message=" ") {
  $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
  $iv = openssl_random_pseudo_bytes($ivlen);
  $ciphertext_raw = openssl_encrypt($amessText, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
  $hmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
  $ciphertext = base64_encode( $iv.$hmac.$ciphertext_raw );

  $amessage1=str_replace(':',' ; ',$message);
  return "wEncrypt. $amessage1:". $ciphertext;
}

//--------------
// decrypte text that was encrypted using wEncrypt
// amessEncrypt : message encrypted (and base64'ed) with wEncrypt
// $akey  : key used to encrypt
// return the uncentryped text  or false if an erro
// if verbose is specified and equal 1, then
//   return [true,unencryptedText] if okay
//          [false,errorMessages] if an error  -- errorMessages is an array of erro messages
function wDecrypt($amessEncrypt0,$key,$verbose=0) {

  while(openssl_error_string() !== false);   // clear error s
  $ahead1=substr($amessEncrypt0,0,9);
  if ($ahead1!='wEncrypt.') {
     if ($verbose!=1) return false ;
     return [false,['Not an wEncrypted string (does not start with wEncrypt)']];
  }
  $jpos=strpos($amessEncrypt0,':');
  $amessEncrypt=substr($amessEncrypt0,$jpos);
  $c = base64_decode($amessEncrypt);
  $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
  $iv = substr($c, 0, $ivlen);
  $hmac = substr($c, $ivlen, $sha2len=32);
  $ciphertext_raw = substr($c, $ivlen+$sha2len);
  $original_plaintext = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
  $calcmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
  if (hash_equals($hmac, $calcmac)) { // timing attack safe comparison
       if ($verbose!=1)return $original_plaintext ;
       return [true,$original_plaintext];
   }
  if ($verbose!=1) return false ;

  $errs=[];
   while ($msg = openssl_error_string()) $errs[]= $msg ;

   return [false,$errs];

}


?>
