/*  public asset view and create */

function viewPublicAssets(athis) {
  let bmess='';
 
  if (publicAssetsList===false) {
       bmess='The publicAssets list has not been initialized (publicAssets/assetsUse.js has not been updated)';
       bmess+='<p> Would you like to <input type="button" value="initialize the publicAssets list" onClick="makePublicAssets(this)">';

       displayStatusMessage(bmess);
       toggleStatusMessage(0,1);
       return 1;
  }
 
  bmess+='<div id="publicAssets_table">';
    bmess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#publicAssetsDesc">&#10068;</button>';
   bmess+='Currently available <u>publicAssets</u> ';
   bmess+='<input type="button" onClick="makePublicAssets2_viewType(0,this)" data-show="1" title="toggle view of: stocks " value="'+getAssetType(0,'icon')+'"> ';
   bmess+='<input type="button" onClick="makePublicAssets2_viewType(1,this)" data-show="1" title="toggle view of: bonds" value="'+getAssetType(1,'icon')+'"> ';
   bmess+='<input type="button" onClick="makePublicAssets2_viewType(2,this)"  data-show="1" title="toggle view of: tax deferred bonds" value="'+getAssetType(2,'icon')+'"> ';
   bmess+=' |  ';
   bmess+='<button   style="background-color:#cecdce;border-radius:5px" >&#10133;</button> to add a publicAsset to your ';
   bmess+='<span title="available assetse are ... assets that can be added to a portfolio!" style="font-style:oblique">available assets!</span>';

   let blist=[];
   for (let zasset in publicAssetsList) {
       let zz=publicAssetsList[zasset]  ;
      let specs=zz['specs'];
      let atype=specs['type'];
      let ticon=getAssetType(atype,'iconSpan');

      let alookup=doAssetLookup(zasset,'*');
      let a1='<li  class="publicAssetType_'+atype+'">'
      if (alookup===false) { // already included
         a1+='<button style="background-color:#cecdce;border-radius:5px" data-name="'+zasset+'" title="Add this to your available assets" ';
         a1+='  onClick="makePublicAssets2_addPublicAssets(this)">&#10133;   </button> ';
      }  else {
        a1+='<input  title="This publicAsset has already been added to your available assets" type="button" style="opacity:0.5" value="&#9475; " name="publicAssets_addme_included">&hellip;</label> ';
      }
      a1+='<button onclick="makePublicAssets2_show(this,0)" data-name="'+zasset+'">view entries</button>'+ticon+' <b>'+zasset+'</b> <tt>'+specs['nentries']+'</tt> entries &nbsp;&nbsp; <em>'+specs['desc']+'</em>';

      blist.push(a1);
   }
  let klist='<ul class="boxList2"><li>'+blist.join(blist)+'</ul>';
  bmess+=klist;
  bmess+='</div>';

  $('#mainDiv3').html(bmess);
  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv2');
  wsurvey.wsShow.show('#mainDiv3','show');
 return 1;

}

//===========
// create publicAssets/assetsUse.js


function makePublicAssets(athis){
    let ddata={'todo':'getList' };
    $.ajax({
        url: 'simInv_publicAsset.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {
     makePublicAssets2(response );
   });
   return 1;

}


function makePublicAssets2(response) {

   let bmess='';
   if (response['errMessages'].length>0) {
       bmess+='<b>Problems reading publicAssets .txt files </b>';
       bmess+='<ul><li>'+response['errMessages'].join('<li>')+'</ul>'
       displayStatusMessage(bmess);
       toggleStatusMessage(0,0);
       return 0;
   }


   displayStatusMessage(bmess);
   toggleStatusMessage(0,0);
   let okFreqs={'year':1,'month':1,'day':1};
   let okTypes={'0':1,'1':1,'2':1};
   let errs=[];
   for (let zasset in response['info']) {
     let vvs=response['info'][zasset];
     let zname0=  jQuery.trim(vvs['name']);
     let zname=fixStringRemoves(zname0 );
     if (zname0.toLowerCase()!=zname)  errs.push('Improper name: <tt>'+ zname0+'</tt>');
     let zdesc=fixString(vvs['desc'],2);
        zdesc=wsurvey.removeAllTags(zdesc) ;
     let zdesclong=fixString(vvs['desclong'],2);
        zdesclong=wsurvey.removeAllTags(zdesclong);
     let afreq=jQuery.trim(vvs['freq']).toLowerCase();
     if (!okFreqs.hasOwnProperty(afreq)) errs.push(zname+' has unknown freq: <tt>'+ afreq+'</tt>');

     let atype=jQuery.trim(vvs['type']).toLowerCase();
     if (!okTypes.hasOwnProperty(atype)) errs.push(zname+' has unknown type: <tt>'+ atype+'</tt>');
   }

   if (errs.length>0) {
       bmess+='<b>Problems in  publicAssets specifications</b>';
       bmess+='<ul><li>'+errs.join('<li>')+'</ul>'
       displayStatusMessage(bmess);
       toggleStatusMessage(0,0);
       return 0;
   }


// if here, no errors
   let alist=[];
   let dvals={} ;
   let notes=[];
   let specs={};

   publicAssetsList={};    // global

// info from server ...
   for (let zasset in response['info']) {

     let vvs=response['info'][zasset];
     let vfile=vvs['fileName'];
     let zname=fixStringRemoves(vvs['name'] );
     let zdesc=fixString(vvs['desc'],2);
        zdesc=wsurvey.removeAllTags(zdesc) ;
     let zdesclong=fixString(vvs['desclong'],2);
        zdesclong=wsurvey.removeAllTags(zdesclong);
     let afreq=jQuery.trim(vvs['freq']).toLowerCase();
     let atype=jQuery.trim(vvs['type']).toLowerCase();
     let ticon=getAssetType(atype,'icon');

     if (dvals.hasOwnProperty(zname)) {
        notes.push(zname+' already defined in <tt>'+dvals[zname]+'</tt> (<tt>'+vfile+'</tt> file skipped).')
        continue ;
     }
     dvals[zname]=vfile ;

     specs ={'type':atype,'freq':afreq,'desc':zdesc,'desclong':zdesclong,'nentries':0};
     let dvalsX={};  // lines of data

     for (let ii=0;ii<vvs['csv'].length;ii++) {
         let a0=jQuery.trim(vvs['csv'][ii]);
         if ( a0 =='') continue ;
         if (a0.substr(0,1)==';') continue ;

         let a1=a0.split(',');
         for (let ia=0;ia<a1.length;ia++) a1[ia]=jQuery.trim(a1[ia]);

         let date1,iVar;
         if (afreq=='year') {
             iVar=1;
             date1=setEntryDate(a1[0],1,1,1);
             if (date1==false) errs.push(zname+' has a bad Year: <tt>'+a1[0]+'</tt>')
         } else if (afreq=='month') {
             iVar=2;
             date1=setEntryDate(a1[0],a1[1],1,1);
             if (date1==false) errs.push(zname+' has a bad year, or month: <tt>'+a1[0]+', '+a1[1]+'</tt>')
         } else if (afreq=='day') {
             iVar=3;
             date1=setEntryDate(a1[0],a1[1],a1[2],1);
             if (date1==false) errs.push(zname+' has a bad year, or month, or day : <tt>'+a1[0]+', '+a1[1]+','+a1[2]+'</tt>')
         }

         let aprice=false,adividend=false,ainterest=false;
         if (atype==0) {
             aprice=jQuery.trim(a1[iVar]);
             if (!jQuery.isNumeric(aprice)) {
                errs.push(zname+' has a bad interest price: <tt>'+aprice+'</tt>')
             } else {
                aprice=parseFloat(aprice)
             }
             if (a1.length<iVar+1) {
                adividend=false;
                errs.push(zname+' dividend rate not specified');
             } else {
                adividend=a1[iVar+1];
                adividend=jQuery.trim(a1[iVar+1]);
               if (!jQuery.isNumeric(adividend)) {
                  errs.push(zname+' has a bad dividend rate: <tt>'+adividend+'</tt>')
               } else {
                  adividend=parseFloat(adividend)
               }
            }
         } else if (atype==1 || atype==2) {
             ainterest=jQuery.trim(a1[iVar]);
             if (!jQuery.isNumeric(ainterest)) {
                errs.push(zname+' has a bad interest rate: <tt>'+ainterest+'</tt>')
             } else {
                ainterest=parseFloat(ainterest)
             }
          }

          let idate=date1['dayCount'];
          let dateSay=date1['sayDate'];
          if (dvalsX.hasOwnProperty(idate)) {
             notes.push(zname+'  '+dateSay+' already defined  (<tt>data line skipped</tt>')
             continue ;
          }
          dvalsX[idate]={'dateSay':dateSay,'price':aprice,'interest':ainterest,'dividend':adividend};
     }          // checking price and interest  in each dataline of this asset

     let dd=[];    // sort by date
     for (let jdate in dvalsX) dd.push(jdate);
     dd.sort(mySortNumeric);

     let nentries=dd.length;

     let dvalsXSort={};

     for (let ij=0;ij<dd.length;ij++) {
         dd1=dd[ij];
         dvalsXSort[dd1]=dvalsX[dd1];
     }
     specs['nentries']=nentries;
     publicAssetsList[zname]={'values':dvalsXSort,'specs':specs}

// summary report..
     let asay=ticon+' '+zname+ ' ('+afreq+'). ';
     asay+='<button onClick="makePublicAssets2_show(this,1)" data-name="'+zname+'"><tt>'+nentries+'</tt> entries</button> <em>'+zdesc+'</em>';
     let liSay='<li class="publicAssetType_'+atype+'">'+asay+'</li>'
     alist.push(liSay);

   }

   if (errs.length>0) {
       bmess+='<b>Problems in publicAssets data</b>';
       bmess+='<ul><li>'+errs.join('<li>')+'</ul>'
       displayStatusMessage(bmess);
       toggleStatusMessage(0,0);
       return 0;
   }

   bmess+='<button onClick="makePublicAssets2_save(this)" class="csaveButton" title="Save these public assets (make them accessible to simInv)">Save</button>';
   bmess+='<input type="button" onClick="makePublicAssets2_viewType(0,this)"  data-show="1"  title="toggle view of: stocks " value="'+getAssetType(0,'icon')+'"> ';
   bmess+='<input type="button" onClick="makePublicAssets2_viewType(1,this)"  data-show="1" title="toggle view of: bonds" value="'+getAssetType(1,'icon')+'"> ';
   bmess+='<input type="button" onClick="makePublicAssets2_viewType(2,this)"  data-show="1" title="toggle view of: tax deferred bonds" value="'+getAssetType(2,'icon')+'"> ';

   bmess+='<ul class="boxList2"> '+alist.join('\n')+'</ul>'

   if (notes.length>0) {
    bmess+='<p><b>Notes:</b>';
     bmess+='<ul boxList2><li>'+notes.join('<li>')+'</ul>'
   }

 let amess='<table width="96%" cellpadding="5" rules="cols"><tr> ';
 amess+='<td width="50%">';
 amess+='<div style="border:3px dotted blue;height:80vh;overflow:auto"> ';
 amess+=bmess;
 amess+='</div>';
 amess+='</td>';
 amess+='<td width="55%">';
 amess+='<div id="publicAssets_viewData" style="height:80vh;overflow:auto;display:none"></div>';
 amess+='</td>';
 amess+='</tr></table>';

  $('#mainDiv3').html(amess);
  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv2');
  wsurvey.wsShow.show('#mainDiv3','show');

   return 0;
}


//=== ==
// toggle view by asetype
function makePublicAssets2_viewType(atype,athis) {
   let e1=$('.publicAssetType_'+atype);
   let ethis=wsurvey.argJquery(athis);
   let ion=ethis.attr('data-show');
   if (ion==0) {        // currently hidden -- so shos
      e1.show();
      ethis.attr('data-show',1);
      ethis.removeClass('cPublicAssetTypeHidden');
   }  else {
      e1.hide();
      ethis.attr('data-show',0);
      ethis.addClass('cPublicAssetTypeHidden');
   }

}

//=== ==
// details on a publicAsset
function makePublicAssets2_show(athis,ihow) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-name');
   let specs=publicAssetsList[aname]['specs'];


   let atype=specs['type'] ;
   let ticon=getAssetType(atype,'icon');

  let amess= ticon+' <b>'+aname+'</b> &nbsp;&nbsp;&nbsp;<em>'+specs['desc']+'</em>';
  amess+='<div style="border:1px dotted gray;font-size:90%;margin:3px 3em">'+specs['desclong']+'</div>';

  amess+='<table cellpadding="11" rules="rows"><tr><th>Date</th>';
  if (atype==0) {
      amess+='<td>Price</td><td>Dividend rate</td>';
  } else {
      amess+='<td>Interest rate</td>';
  }
   amess+='</tr>';

  for (let adate in  publicAssetsList[aname]['values']) {
   amess+='<tr>';
    let zz=publicAssetsList[aname]['values'][adate];
     amess+='<td><tt>'+zz['dateSay']+'</td>';
    if (atype==0) {
       amess+='<td><tt>'+zz['price'].toFixed(2)+'</td>';
       amess+='<td><tt>'+zz['dividend'].toFixed(2)+'</td>';
    } else {
       amess+='<td><tt>'+zz['interest'].toFixed(2)+'</td>';
    }
    amess+='</tr>';
  }
  amess+='</table>';
 if (ihow==0) {
   displayStatusMessage(amess);
   toggleStatusMessage(0,0);
 } else {
    $('#publicAssets_viewData').html(amess).show();
 }

}

//==================
// save. to a js file, the public assets
function makePublicAssets2_save(athis) {
 
 let nsave=0;
 for (let arf in publicAssetsList) nsave++ ;
 let pp=JSON.stringify(publicAssetsList);
 let ddata={'todo':'savePublicJs','data':pp,'nsave':nsave};
 $.ajax({
        url: 'simInv_publicAsset.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {
     let bmess=response['message'];
     displayResponseFromServer(bmess,1) ;
//     displayStatusMessage(bmess);
//     toggleStatusMessage(0,0);
    });


}

//=================
// add selected public assets
function makePublicAssets2_addPublicAssets(athis) {
//  let etable=$('#publicAssets_table');
//  let ebuttons=etable.find('[name="publicAssets_addme"]');
//  let edo=ebuttons.filter(':checked') ;
//  for (let ii=0;ii<edo.length;ii++)  {
//      let ado=$(edo[ii]);
//      let aasset=ado.val();
//      domes[aasset]=1;
//  }

 let domes={};
 let ethis=wsurvey.argJquery(athis);
 let aname=ethis.attr('data-name');
 domes[aname]=1 ;

 let bmess='';
 bmess+='<em>Add this public asset .. </em> ';
 bmess+='<ul class="boxList" id="addPublicAssets_list">';
 for (let casset in domes) {
    let hh=publicAssetsList[casset];
    let specs=hh['specs'];
    let atype=specs['type'];
    let ticon=getAssetType(atype,'iconSpan');

    bmess+='<li class="thisAsset">';
    bmess+='<input type="button" value="&#10133; Add this public asset" onClick="makePublicAssets2_addPublicAssets2(this)" data-name="'+casset+'" data-type="'+atype+'"> ';
    bmess+=ticon+' <input type="text" size="20" value="'+casset+'" readonly style="opacity:0.8" name="assetName">  ('+specs['nentries']+' entries) <em>'+specs['desc']+'</em>';
    if (atype==1) {
      bmess+='<br> Fraction of earnings NOT taxed:  ';
      bmess+='  <input name="nbondTaxFrac" value="0.0" title="taxFree fraction (0.0=interest earnings IS fully taxed ... 1.0:  interest earnings are NOT taxed" type="text" size="4"> ';
    }
 }
 bmess+='</ul>';
 displayStatusMessage(bmess);
 toggleStatusMessage(0,0);

  return 1;
}

//===============
// add a public  asset!
// 1: add to assetList
// 2 : add to assetHistory
function   makePublicAssets2_addPublicAssets2(athis) {
   let ethis=wsurvey.argJquery(athis);
   let cname=ethis.attr('data-name');
   let atype=ethis.attr('data-type');
   let eli=ethis.closest('.thisAsset');
   let ename=eli.find('[name="assetName"]');
   let useAssetName0=wsurvey.removeAllTags(ename.val());

   let useAssetName=fixStringRemoves(useAssetName0);

   let afrac=false;
   if (atype==1) {
     let efrac=eli.find('[name="nbondTaxFrac"]');
      afrac=jQuery.trim(efrac.val());

     if (!jQuery.isNumeric(afrac)) {
         alert('Bad taxFree fraction for '+cname);
         return 1;
     }
     afrac=parseFloat(afrac);
     if (afrac<0 || afrac>1.0) {
         alert('Bad taxFree fraction for '+cname+'. Value must be between 0.0 and 1.0');
         return 1;
     }
   }

   let ddata={} ;
   ddata['todo']='saveAssetsPublic';
   ddata['username']=userName;
   ddata['encMd5']=encryptionKey_md5;
   ddata['assetName']=useAssetName0;

// the asset specs
   let doList={};

   let specs=publicAssetsList[cname]['specs'];
   let spec1={'name':useAssetName,'sayname':useAssetName0,
                 'assetType':atype,'taxFreeFrac':afrac,
                'desc':specs['desc'],'descLong':specs['desclong'],
                'lossetsOffsetIncome':0,'constantIncome':0}
   let spoo=[];
   spoo[0]=spec1 ;
   doList['list']=spoo;           // additions  (array of objects, one row per new asset)
   ddata['assetSpecs']=doList;

// the asset history
   let doHist={};
   let listH=[];
   for (let adate in  publicAssetsList[cname]['values']) {
        let vv1=publicAssetsList[cname]['values'][adate];
        alist={};
        alist['date']=parseInt(adate);
        alist['comment']='publicAsset ';
        alist['assetPrice']=vv1['price'];
        alist['assetDividend']=vv1['dividend'];
        alist['assetInterest']=vv1['interest'];
        alist['assetSalePrice']=0;
        alist['assetNetRent']=0;
        alist['assetIncome']=0;
        listH.push(alist);
    }
    doHist['list']=listH;
    doHist['autoAddEntries']=0;
    ddata['assetHistory']=doHist;

    saveSimInvData(ddata);
}
