// ============ library of functions: export and import data from simInv

//==========================
// export data to local machine --
function doExportImport(athis) {

 let allowLocal=simInvLocalStorage['useLocalStorage'];
 if (allowLocal==1) {
     doExportImport_local(athis);
     return 0;
 }

// online mode
  let bmess='';
  let acomment='simInv export data: '+userName+' @ '+wsurvey.get_currentTime(31,1);

  bmess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#exportHelp1">&#10068;</button>';

    bmess+="Export simInv data (asset and portfolio information) as  a .JSON file. <br>";
    bmess+='Comment <input type="text" size="60" title="optional comment" id="iexportComment" value="'+acomment+'">';
    bmess+='<ul>';
    bmess+='<li><label title="Include asset info " ><input type="checkbox" checked id="exportDo_asset"> asset info ?</label>';
    bmess+='<li><label title="Include portfolio info " ><input type="checkbox" checked id="exportDo_portfolio"> portfolio info ?</label>';
    bmess+='<li><label title="Include portfolio loan info " ><input type="checkbox" id="exportDo_loan"> portfolio loan info ?</label>';
    bmess+='</ul>';
    bmess+='<br><input type="button" value="export" onClick="doExportImport1(0)">';
    displayStatusMessage(bmess);
    toggleStatusDiv(0,0);
}

//========================
// export or achive data (online mode)
function doExportImport_0(ifoo) {
  let bmess='';
  
   let allowLocal=simInvLocalStorage['useLocalStorage'];

   if (allowLocal==1) {  // standalone mode
      doExportImport(2) ;
      return 1;
   }

// online mode
  bmess+='';
  
  bmess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#exportArchiveRestoreHelp1">&#10068;</button>';
  bmess+='You can <ul>';
  bmess+='<li><input type="button" value="Export" onClick="doExportImport_export(this)"> data (suitable for use with spreadsheets) ';
  bmess+='<li><input type="button" value="Archive" onClick="doExportImport1_archive(this)"> data (suitable for restoring at a later date)';
  bmess+='<li><input type="button" value="Restore" onClick="doExportImport1_restore(this)"> data (that was archived ... at an earlier date)';
  bmess+='</ul>';
  bmess+='<div id="doExportImport_menus" style="border:2px solid blue;xdisplay:none"></div>';
  displayStatusMessage(bmess);
  toggleStatusDiv(0,0);

}


//==============================
// export json file, with all data, to a new window (to be saved to disk)
// or one can copy it to the clipboard and save manually

function doExportImport_export(iall) {

   let qLocal=simInvLocalStorage['useLocalStorage']==1 ;

   let ecomment=$('#iexportComment');
   let acomment= ecomment.val();
   let doAsset=1,doPortfolio=1,doLoan=1;
   if (iall==0) {
     doAsset=$('#exportDo_asset').prop('checked') ;
     doPortfolio=$('#exportDo_portfolio').prop('checked') ;
     doLoan=$('#exportDo_loan').prop('checked') ;
   }

   acomment=wsurvey.removeAllTags(acomment);
   let adescs={'assetList':'List of assets (with descriptions)' ,
   'assetLookup':'Basic information all assets' ,
   'assetHistory':'History entries for each asset (dividend, price, etc.) ' ,
   'assetDetails':'Expanded information for all assets' ,
   'assetsUsed':'In what portfolios are the assets used' ,
   'portfolioList':'List of portfolios ' ,
   'portfolioLookup':'Basic information on portfolios' ,
   'portfolioInit':'The initialization entries for portfolios' ,
   'portfolioModifications':'Zero, one, or more modifcations for each portfolio' ,
   'portfolioLoans':'Loan information (for all loans in initial or modified portfolios) ' ,
   }  ;

  let atime= wsurvey.get_currentTime(31,2);
  let bigList={};             // fill with the global "storage" arrays
  bigList['comment']=acomment;
  bigList['saveMessage']='Saved on  '+atime+' for user '+userName;
  bigList['varDesc']=adescs ;


  if (doAsset) {
    bigList['assetList']=assetList ;
    bigList['assetLookup']= assetLookup ;
    bigList['assetHistory']= assetHistory ;
    bigList['assetDetails']= assetDetails  ;
    bigList['assetsUsed']= assetsUsed ;
  }

  if (doPortfolio) {
    bigList['portfolioList']= portfolioList ;
    bigList['portfolioLookup']= portfolioLookup;
    bigList['portfolioInit']= portfolioInit ;
    bigList['portfolioModifications']= portfolioModifications;
    bigList['assets']= portfolioModifications;
  }

  if (doLoan) {
     bigList['portfolioLoans']= portfolioLoans   ;
  }

  let bmess='Export data can be displayed as a spreadsheet <br>';
   bmess+='<table cellpadding="5" rules="rows">';
   bmess+='<tr><td><button class="csettingsButton" onClick="doExportImport1a(this)">Preview the exported data ... </button>  </td>';
   bmess+='<td><em>simImv data (JSONized for export!)</em><br>';
   bmess+='<span style="overflow:auto;display:inline-block;font-family:monospace;background-color:#afafaf;height:5em;width:20em" id="iImportExport1a">';
   let b1=JSON.stringify(bigList);
   let vdesc=bigList['varDesc'];
   bmess+=b1+'</span>';
   bmess+='</td></tr>';
   bmess+='<tr><td>Or... you can <input type="button" value="Select what variables" onClick="doExportImport1_select(this)"> to export</td>';
   bmess+='<td><ul id="idoExportImport1_varlist" class="linearMenu20PctH">';
   for (let zvar in bigList) {
      let adesc=(vdesc.hasOwnProperty(zvar)) ? vdesc[zvar] : ' ' ;
      bmess+='<li><label title="'+adesc+'"><input type="checkbox"   name="doExportImport1_var" value="'+zvar+'">'+zvar+'</label>';
    }
   bmess+='</ul>';

   bmess+'</td></tr>';
   bmess+='<tr><td>&#10112; <button onClick="doExportImportMark(1)"> Copy exported data</button> to the clipboard </td>';
   bmess+='<td><span id="iImportExport1a_result" style="color:green;padding:3px;display:none"></span></td>';
   bmess+='</tr>    ';
   bmess+='<tr>    ';
   bmess+='<td>&#10113;Paste it to a text file on your computer';
   bmess+='</td>';
   if (!qLocal) {
         bmess+='<td><em>or</em> <button onClick="doExportImport1_download(this)">download to a file </button> (<tt>simInv_export.json</tt>)</td>';
   }
   bmess+='</tr>';
   bmess+='</table>';

   bmess+='<br><em>Hint:</em> JSON files can be converted into spreadsheet files (such as XLSX, or ODS) using online tools. However, since this JSON file is deeply nested, some of the less sophisticated tools will fail! '


   $('#doExportImport_menus').html(bmess).show();
//  displayStatusMessage(bmess);
 // toggleStatusDiv(0,0);
}

//=============
// select which variables to export 
function doExportImport1_select(athis) {
   let e1=$('#idoExportImport1_varlist');
   let evars=e1.find('[name="doExportImport1_var"]');
   let evars2=evars.filter(':checked');
   let avars={};
   for (let ii=0;ii<evars.length;ii++) {
      let eva1=$(evars2[ii]);
      let avar=eva1.val();
      avars[avar]=1;
   }
   let e2=$('#iImportExport1a');
   let vv=e2.text();
   let vv2=JSON.parse(vv);
   let vv3={};
   for (let a1 in vv2) {
      if (avars.hasOwnProperty(a1)) vv3[a1]=vv2[a1];
   }
   let d1=JSON.stringify(vv3);
   e2.text(d1);


}
//==================  qLocal
// preview export data
function doExportImport1a(athis) {
 let e1=$('#iImportExport1a');
 let v1=e1.text();
 let vv=JSON.parse(e1.text());
 showDebug(vv,'simInv data (for export)');
}

//==============
// echoback this export file
function doExportImport1_download(athis) {
  let e1=$('#iImportExport1a');
  let vv=e1.text();
  wsurvey.submitQuickForm('simInv2.php','post',{'todo':'echoFile','content':vv,'fname':'simInv_export.json'},'export1') ;
  alert('Your browser will download a file (`simInv_export.txt`)  that contains the simInv export data   ...   ');
  return 1;
}


//=====================
// archive current data -- same format as when saving  local data
function doExportImport1_archive(ifoo) {
  let qLocal=simInvLocalStorage['useLocalStorage']==1 ;
  let nowTime=wsurvey.get_currentTime(0)
  let nowTimeSay=wsurvey.get_currentTime(31,1,nowTime)

  let archiveData={};
  archiveData={'date':nowTime,'dateSay':nowTimeSay,'userName':userName,'content':allCurrentData,'archiveDate':nowTime} ;

    let nportfolios=allCurrentData['portfolios']['list'].length;
    let nassets=allCurrentData['assets']['list'].length;

    let arfData=JSON.stringify(archiveData);
    let amess='';
    amess+='<div style="font-size:110%;margin:5px;">simInv data for <u>'+userName+'</u> (on '+nowTimeSay+') has '+nassets+' assets and '+nportfolios+' portfolios.';
    amess+=' To save this data to a file, you can download a file or copy it directly to a local file ... </div>';

    amess+='<div style="border:1px dotted purple;margin-bottom:0.5em">';
    amess+='<em>download a file </em><br> ';
    let fnameSuggest='simInv_'+nowTime+'.txt' ;

    amess+='<div style="margin-left:2em">';
    amess+='Enter a suggested name: <input type="text" size="25" title="Specify a name (it will be the default name used by the browser) " id="iExportImport_fname" value="'+fnameSuggest+'"> ';
    amess+='<br> and then ... ';
    amess+='<input type="button" value="Download (to a file)" title="The browser might ask you where to save this file (and use the suggested name as the default) .." onClick="doExportImport1_archive_online(this)">';
    amess+='</div>';
    amess+='</div>';

    amess+='<div style="border:1px dotted green">';
    amess+='<em>copy it directly to a local file</em> ';
    amess+='<table width="95%" cellpadding="5">';
    amess+='<td width="50%"><ul style="list-style-type: lower-alpha;">';
    amess+='<li><button onClick="doExportImport_local_archive_copy(this)" class="cdoButtonRegular"> ';
    amess+=' Copy the archived information ';
    amess+='</button> (to your clipboard)';
    amess+=' <span id="doExportImport_local_archive_results_copied"  ';
    amess+=   ' title="archived information can now be pasted!" style="color:green;display:none">Copied!';
    amess+='</span>  ';
    amess+='<li>  Cut &amp; paste it to a <u>text</u> file on your computer';
    amess+='<br><em>For example:</em> create/paste/save <tt>simInvArchive_'+userName+'.txt</tt>  with windows Notepad editor';
    amess+='</ul>';
    amess+=' </td>';
    amess+='<td width="50%"> ';
    amess+='You can <button onclick="doExportImport_local_archive_preview(this)" title="View this javaScript object in a new window">Preview</button> the archived information?<br>';
    amess+='<div title="The archived simInv data for user: '+userName+'" id="doExportImport_local_archive_results_string" style="height:3em;width:20em;overflow:auto;background-color:gray;padding:1em">';
    amess+=arfData;
    amess+='</div>';
    amess+='</td>';
    amess+='</tr></table>';
    amess+='</div>';
    amess+='You can <button>restore</button> this data at a later date -- don\'t forget where you saved your  text file &#9786;';

    $('#doExportImport_menus').html(amess).show();

  //  displayStatusMessage(amess,1);
  //  toggleStatusMessage(0,0);



}

//=====================
// echo the archive file back using server
function doExportImport1_archive_online(athis) {
  let e1=$('#doExportImport_local_archive_results_string');
  let vv=jQuery.trim(e1.text());
  let e2=$('#iExportImport_fname');
  let fname=jQuery.trim(e2.val());
   wsurvey.submitQuickForm('simInv2.php','post',{'todo':'echoFile','content':vv,'fname':fname},'export1') ;
   alert('Your browser will download a file using this name (that contains the simInv archive)  ...   ');
}

//========
// copy to clipboard
//https://developer.mozilla.org/en-US/docs/Web/API/Clipboard/writeText
// doe
function doExportImportMark(aa) {

  let e1=$('#iImportExport1a');
  let astuff=jQuery.trim(e1.text());

   navigator.clipboard.writeText(astuff).then(
  () => {
      let e2=$('#iImportExport1a_result');
      e2.html('Copied!').show();
  },
  () => {
    // clipboard write failed
  }
);



// june2023 :  document.execCommand( is to be deprecated, so use above
//       document.querySelector("#iImportExport").select();
//       document.execCommand('copy');
///    wsurvey.selectText('iImportExport','MARK') ;
    return 1;
  }

// ------------
// paste from clipboard
// 28 June 2023 : does NOT work easily in Firefox (permissions have to be enabled)
// https://developer.mozilla.org/en-US/docs/Web/API/Navigator/clipboard
function doExportImport1Paste(athis) {
  let oof=typeof( navigator.clipboard.readText);
  if (oof=='undefined') {                         // firefox doesn't support (without user setting some permissions)
     console.log('clipboard readtext not supported ');
     return false;
  }
  let e1=$('#iImportExport');
  e1.val('');
  navigator.clipboard.readText()
  .then(
  (clipText) =>
    (e1.val(clipText))
   ,
  (clipText) =>
    (alert('not'))
 );



//    (clipText) => (document.querySelector(".cliptext").innerText = clipText)
}


//====================
// restore from a saved archive file on local computer
// that must be pasted into a texbox
function doExportImport1_restore(athis) {
  let bmess='';

  bmess+='<div style="font-family:sans-serif;margin:3px 4em;padding:3px 1em">';
  bmess+='Due to javaScript security: archiving  &amp; restoring simInv data requires user actions. You will need to';
  bmess+=' copy data to (or from) a text file on your computer. It\'s not that hard!'
  bmess+='</div>';
  bmess+='<table width="95%">';
  bmess+='<tr><td width="20%">Copy a simInv archive <br> (from a local file) and  ...</td>';
   bmess+='<td valign="top" width="35%"><em>Paste the contents to this textbox...</em> <br>';
   bmess+='<textarea style="border:4px dotted purple" title="Paste the simInv archive data here!" id="doExportImport1_restore_textarea" nowrap rows="1" cols="40"></textarea>';
   bmess+='<br> <input type="button" value="reset" onClick="doExportImport1_restore_clear(this)">  ';
   bmess+=' <span id="idoExportImport1_restore_preview"  style="border-left:1px solid gray;padding-left:6px;display:none">';
   bmess+=' <button  onClick="doExportImport1_restore_preview(this)">Preview</button> the archived data ';
   bmess+' </span>';

  bmess+='<td width="35%"><button onClick="doExportImport1_restore_validate(this)">Validate</button> the archived data';
  bmess+='<span id="doExportImport1_restore_check" title="Validated!" style="display:none">&#9989; </span>';
  bmess+='<div id="doExportImport1_restore_1" style="border-top:1px dashed gray;display:none">';
  bmess+='<div id="doExportImport1_restore_1b" style="font-size:90%;padding:2px"></div>';
//  bmess+='  <button onClick="doExportImport1_restore_preview(this)">Preview</button> the archived data';
  bmess+='</div> ';
  bmess+='</td>';

  bmess+='</tr>';
  bmess+='</table>';

  bmess+='<div id="doExportImport1_restore_2" style="border:1px dashed green;display:none">';
  bmess+='</div>';
    $('#doExportImport_menus').html(bmess).show();



}

//==================
// valicate the pasted archive file
function doExportImport1_restore_validate(athis) {
 let e1=$('#doExportImport1_restore_textarea');
 let v1=e1.val();
 let vv;

 $('#doExportImport1_restore_1').hide();
 $('#idoExportImport1_restore_preview').hide();
 $('#doExportImport1_restore_2').hide();
 $('#doExportImport1_restore_check').hide();

 try {
    vv=JSON.parse(v1);
} catch(err) {
  let bmess='Problem processing:\n  '+err ;
  alert(bmess) ;
  return 1;
}
 if (!vv.hasOwnProperty('archiveDate') || !jQuery.isNumeric(vv['archiveDate'])) {
    let bmess='This is not a simInv archive file! ';
    bmess+='\nWould you like to view it (using a JSON viewer)? ';
     let q=confirm(bmess);
    if (!q) return 1;
    showDebug(vv,'Viewing JSON data');
    return 1;
 }
  let oof=setEntryDate(vv['archiveDate']);
  let wasuser=vv['userName'];
  let bmess='simInv archive  created by <tt>'+wasuser+'/tt> on  <tt>'+oof.sayDate+'</tt>';
  let nassets=0,nportfolios=0;
  if (vv['content'].hasOwnProperty('assets')) nassets=vv['content']['assets']['list'].length;
  if (vv['content'].hasOwnProperty('portfolios') )    nportfolios=vv['content']['portfolios']['list'].length;
  bmess+='  <em>with</em> <tt>'+nassets+'</tt> assets, <tt>'+nportfolios+'</tt> portfolios ';
  bmess='<ul class="boxList"> ';
  bmess+='<li><button class="cdoButton" onclick="doExportImport1_restore_go(0)" title="restore (overwrite existing content)">Restore</button>   ';
  bmess+='<span style="margin:3px 3em;border:1px dashed yellow;padding:3px">Caution: this will <b>overwrite</b> existing simInv data (for user <u>'+userName+'</u>)</span>';
  bmess+='<li><button class="cdoButton" onclick="doExportImport1_restore_go(1)" title="add assets and portfolios to existing)">Add</button> Add asset and portfolios that are <u>not</u> specified for '+userName   ;
  bmess+='</ul>';

  let fromUser=vv['userName'];
  let onDate=vv['dateSay'];
  let acomment=(vv.hasOwnProperty('comment')) ? vv['comment'] : ' ' ;
  let nassetsX=vv['content']['assets']['list'].length;
  let nportfoliosX=vv['content']['portfolios']['list'].length;
  let gmess='Achive from <tt>'+fromUser+'</tt> on <tt>'+onDate+'</tt>. With <tt>'+nassetsX+'</tt> assets and <tt>'+nportfoliosX+'</tt> portfolios.';
  gmess+='<br>'+acomment;


 $('#idoExportImport1_restore_preview').show();
 $('#doExportImport1_restore_1').show();
 $('#doExportImport1_restore_1b').html(gmess);
 $('#doExportImport1_restore_check').show();
 $('#doExportImport1_restore_2').html(bmess).show();
}

//================
// do the restoration!
// iadd:0 overwrite, 1:add
function doExportImport1_restore_go(iadd) {
  let e1=$('#doExportImport1_restore_textarea');
  let v1=e1.val();
  let vv;

  try {
    vv=JSON.parse(v1);
  } catch(err) {
     let bmess='Problem processing:\n  '+err ;
     alert(bmess) ;
     return 1;
  }
  if (!vv.hasOwnProperty('archiveDate') || !jQuery.isNumeric(vv['archiveDate'])) {
    let bmess='This is not a simInv archive file! ';
    alert(bmess);
    return 1;
 }
 if (iadd==0) {
   let q=confirm('Caution: this will REMOVE existing simInv data (for user `'+userName+'`)\n Are you sure?') ;
   if (!q) return 0;
 }

// do the restores!
  let saveme=JSON.parse(JSON.stringify(vv));   // clone the archived data

  if (!saveme['content']['portfolioModifications'].hasOwnProperty('list') ||  saveme['content']['portfolioModifications']['list']===false ||
      typeof(saveme['content']['portfolioModifications']['list'])=='undefined') saveme['content']['portfolioModifications']['list']={} ;

  saveme['userName']= userName;
  saveme['date']= wsurvey.get_currentTime(0)
  saveme['dateSay']=wsurvey.get_currentTime(31,1 ) ;
  saveme['content']['keyMd5']=encryptionKey_md5;
  saveme['comment']='overwrite restore ';

// settings and viewdates are NOT restored
  let daEncVars=['assets','assetHistory','portfolios','portfolioInit','portfolioModifications']    ;

  let nassetsRetain=0,nassetsAdd=0,nportfoliosRetain=0,nportfoliosAdd=0;

//....overwrite mode ....

  if (iadd==0) {
     for (let iz=0;iz<daEncVars.length;iz++) {
     let zvar=daEncVars[iz],do1;
     if (zvar=='assets') nassetsAdd=saveme['content'][zvar]['list'].length;
     if (zvar=='portfolios') nportfoliosAdd=saveme['content'][zvar]['list'].length;
     if (zvar=='assetHistory') {
         let a1=(saveme['content'][zvar].hasOwnProperty('list'))  ? saveme['content'][zvar]['list'] : {} ;
         let a2=(saveme['content'][zvar].hasOwnProperty('autoAddEntries'))   ?  saveme['content'][zvar]['autoAddEntries']  : {} ;
         let a3={'list':a1,'autoAddEntries':a2};
         delete  saveme['content'][zvar]['autoAddEntries'];
         do1= a3  ;
     } else {
         do1=saveme['content'][zvar]['list'] ;
     }
 
     let t1= simInvEncrypt(do1,encryptionKey) ;
     saveme['content'][zvar]['list']=t1;
    }
  }
  delete saveme['content']['settings'];
  delete saveme['content']['viewDates'];


// ....  add mode   .......
  if (iadd==1) {

    let origData=JSON.parse(JSON.stringify(allCurrentData));

// fix some odd stuff
    if (!origData['assets'].hasOwnProperty('list') || origData['assets']['list']===false )  origData['assets']['list']=[];
    if (!origData['portfolios'].hasOwnProperty('list') || origData['portfolios']['list']===false )  origData['portfolios']['list']=[];
    if (!origData['portfolioInit'].hasOwnProperty('list') || origData['portfolioInit']['list']===false )  origData['portfolioInit']['list']={};
    if (!origData['portfolioModifications'].hasOwnProperty('list') || origData['portfolioModifications']['list']===false ) origData['portfolioModifications']['list']={};
    if (!origData['assetHistory'].hasOwnProperty('list'))  origData['assetHistory']['list']={} ;
    if (!origData['assetHistory'].hasOwnProperty('autoAddEntries'))  origData['assetHistory']['autoAddEntries']={} ;

    let savemeAdd={};
    savemeAdd['date']=saveme['date'];
    savemeAdd['dateSay']=saveme['dateSay'];
    savemeAdd['userName']=saveme['userName'];
    savemeAdd['archiveDate']=saveme['archiveDate'];
    savemeAdd['keyMd5']=saveme['content']['keyMd5'];
    savemeAdd['comment']='add mode restoration';
    savemeAdd['content']={};

// add assets (do not add from archive data if asset already exists)
    let gotAssets={};
    let list1=[];
    for (let ia=0;ia<origData['assets']['list'].length;ia++) {    // keep existing
       let aname= origData['assets']['list'][ia]['name'];
       gotAssets[aname]=1;
       list1.push(origData['assets']['list'][ia]);
       nassetsRetain++ ;
    }
    for (let ia=0;ia<saveme['content']['assets']['list'].length;ia++) {  // add if not in existing
       let aname2=saveme['content']['assets']['list'][ia]['name'];
       if (gotAssets.hasOwnProperty(aname2)) continue ; // do NOT overwrite
       list1.push(saveme['content']['assets']['list'][ia]);
       nassetsAdd++ ;
    }
    savemeAdd['content']['assets']={'list':simInvEncrypt(list1,encryptionKey)} ;

// add assetHistory (do not add from archive data if asset already exists) -- will NOT  add history  for an existing asset (even if no history defined)
    let gotAssetsH={};
    let listH={'list':{},'autoAddEntries':{}};
    for (let aname in  origData['assetHistory']['list']) {    // keep existing
       gotAssetsH[aname]=1;
       listH['list'][aname]=origData['assetHistory']['list'][aname];
       listH['autoAddEntries'][aname]=origData['assetHistory']['autoAddEntries'][aname];
    }
    for (let aname2 in saveme['content']['assetHistory']['list'] ) {  // add if not in existing
       if (gotAssets.hasOwnProperty(aname2)) continue ; // do NOT create
       if (gotAssetsH.hasOwnProperty(aname2)) continue ; // do NOT overwrite
       listH['list'][aname2]=saveme['content']['assetHistory']['list'][aname2];
       listH['autoAddEntries'][aname2]=saveme['content']['assetHistory']['autoAddEntries'][aname2];
    }
    savemeAdd['content']['assetHistory']={'list':simInvEncrypt(listH,encryptionKey)} ;

// add portflioes (do not add from archive data if portfoliow already exists)
    let gotPortfolios={};
    let listP=[];
    for (let ia=0;ia<origData['portfolios']['list'].length;ia++) {    // keep existing
       let pname= origData['portfolios']['list'][ia]['name'];
       gotPortfolios[pname]=1;
       listP.push(origData['portfolios']['list'][ia]);
       nportfoliosRetain++;
    }
    for (let ia=0;ia<saveme['content']['portfolios']['list'].length;ia++) {  // add if not in existing
       let pname2=saveme['content']['portfolios']['list'][ia]['name'];
       if (gotPortfolios.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       listP.push(saveme['content']['portfolios']['list'][ia]);
       nportfoliosAdd++ ;
    }
    savemeAdd['content']['portfolios']={'list':simInvEncrypt(listP,encryptionKey)} ;


// add portflioInts (do not add from archive data if portfoliow already exists)
    let gotPortfolioInits={};
    let listPinits={};
    for (pname in origData['portfolioInit']['list'] ) {    // keep existing
       gotPortfolioInits[pname]=1;
       listPinits[pname]=origData['portfolioInit']['list'][pname] ;
    }
    for (let pname2 in  saveme['content']['portfolioInit']['list']) {  // add if not in existing
       if (gotPortfolios.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       if (gotPortfolioInits.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       listPinits[pname2]=saveme['content']['portfolioInit']['list'][pname2] ;
    }
    savemeAdd['content']['portfolioInit']={'list':simInvEncrypt(listPinits,encryptionKey)} ;


// add portfolioModifications (do not add from archive data if portfoliow already exists)
    let gotPortfolioMods={};
    let listPmods={};
    for (pname in origData['portfolioModifications']['list'] ) {    // keep existing
       gotPortfolioMods[pname]=1;
       listPmods[pname]=origData['portfolioModifications']['list'][pname] ;
    }
    for (let pname2 in  saveme['content']['portfolioModifications']['list']) {  // add if not in existing
       if (gotPortfolios.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       if (gotPortfolioMods.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       listPmods[pname2]=saveme['content']['portfolioModifications']['list'][pname2] ;
    }
    savemeAdd['content']['portfolioModifications']={'list':simInvEncrypt(listPmods,encryptionKey)} ;


    saveme=savemeAdd ;   // used below
  }   // iadd=1

//  ....
// now save the data (overwrite or add)

//    showDebug(saveme,'saveme for saveing  '+iadd,1);

   let ddata={};
   ddata['todo']='restoreAll';
   ddata['username']=userName;
   ddata['data']=saveme;
   ddata['encMd5']=encryptionKey_md5;


    $.ajax({
        url: 'simInv2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function (response) {
     cmess='Restored (for user name <u>'+userName+'</u> : <tt>'+response+'</tt>)';
     if (iadd==1) {
       cmess+='<br>#assets retained='+nassetsRetain +', added='+nassetsAdd+'. #portfolios retained='+nportfoliosRetain +', added='+nportfoliosAdd  ;
     } else {
       cmess+='<br>#assets added='+nassetsAdd+'. #portfolios  added='+nportfoliosAdd  ;
     }
     displayResponseFromServer(cmess,1) ;
   });


}

//==================     keyMd5
// preview restore data
function doExportImport1_restore_preview(athis) {
 let e1=$('#doExportImport1_restore_textarea');
 let v1=e1.val();
  let vv;

 try {
    vv=JSON.parse(v1);
} catch(err) {
  let bmess='Problem processing:\n  '+err ;
  alert(bmess) ;
  return 1;
}
 if (!vv.hasOwnProperty('archiveDate') || !jQuery.isNumeric(vv['archiveDate'])) {
    let bmess='This is not a simInv archive file! ';
    bmess+='\nWould you like to view it (using a JSON viewer)? ';
    let q=confirm(bmess);
    if (!q) return 1;
    showDebug(vv,'Viewing JSON data');
    return 1;
 }
 let oof=setEntryDate(vv['archiveDate']);
 showDebug(vv,'simInv archive data (created on '+oof.sayDate+')');
 return 1;
}

//=========
function doExportImport1_restore_clear(ifoo) {
   $('#doExportImport1_restore_textarea').val('');
   $('#doExportImport1_restore_1').hide();
   $('#doExportImport1_restore_check').hide();
   $('#doExportImport1_restore_2').hide();
   $('#idoExportImport1_restore_preview').hide();

}

//======
// display json stuff in  textarea in external window (using a formatted display)
function doExportImport2(athis) {
   let e1=$('#showAllPortfolioValues_results_1');
   let a1=jQuery.trim(e1.text());
   a1= a1.replace(/\s+/g," ");
   foo=JSON.parse(a1);
   showDebug(foo,'Exported data (assets and portfolio specifications) ... ');   // display 'exported' data
   e1.val(a1);

}


function doExportImport2Mark(athis) {

  let e1=$('#showAllPortfolioValues_results_1');
  let astuff=jQuery.trim(e1.text());

  navigator.clipboard.writeText(astuff).then(
    () => {
        let e2=$('#showAllPortfolioValues_results_1_copied');
        e2.html('Copied!').show();
    },
    () => {
      // clipboard write failed
    }
  );
}


//=======================================
// export/import localStorage data
//==============================
function   doExportImport_local(athis) {
  let bmess='<div style="border:1px solid blue">';
  bmess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#exportHelp2">&#10068;</button>';

  bmess+='<b>Archive, or restore, simInv data </b> (for user <u>'+userName+'</u>) ';
  let acomment='<em> for '+userName+' @ '+wsurvey.get_currentTime(31,1)+'</em>';
  bmess+='<div style="font-family:sans-serif;margin:3px 4em;padding:3px 1em">';
  bmess+='Due to javaScript security: archiving  &amp; restoring simInv data requires user actions. You will need to';
  bmess+=' copy data to (or from) a text file on your computer. It\'s not that hard!'
  bmess+='</div>';
  bmess+='</div>';

  bmess+='You can  &hellip; ';
  bmess+='<menu>';
  bmess+='<li style="list-style-type:\'&#128413;\' ">&nbsp; <button title="Archive simInv data for this user" onClick="doExportImport_local_archive(this)">Archive</button> ';
  bmess+='<em>archive asset &amp; portfolio data</em>   <tt>(write a new file to your computer)</tt>  ';
  bmess+='<div style="margin-left:3em">Optional comment: <input type="text" size="50" id="ilocalArchiveComment" ></div>';
  bmess+='<p>   ';
  bmess+='<li style="list-style-type:\'&#128409;\'  "> &nbsp; <button title="Restore (previously archived) simInv data for this user" onClick="doExportImport_local_restore(this)">Restore</button> ';
  bmess+='<em>restore asset &amp; portfolio data</em> <tt>(read an existing file on your computer)</tt><p> ';
  bmess+='<li style="list-style-type:\'&#129195;\'  "> &nbsp; <button title="Export"" onClick="doExportImport1(1)">Export</button> ';
  bmess+=' <em>simInv data for this user (for use in a spreadsheet, etc) </em> ';

  bmess+='</menu>';
  bmess+='<hr>';

  bmess+='<div id="doExportImport_local_archive_next" style="border:1px solid cyan;margin:1em 3em;display:none;padding;3px;"></div>';
  bmess+='<div id="doExportImport_local_archive_results" style="border:1px solid blue;margin:1em 3em;display:none;padding;3px;">';
  bmess+='</div>';
  displayStatusMessage(bmess);
  toggleStatusMessage(0);
}

//===========
// archive data -- create a stringified file to be saved to local file
function doExportImport_local_archive(bigData,iuse) {
   if (arguments.length<2) iuse=0;

   let nowTime=wsurvey.get_currentTime(0)
   let nowTimeSay=wsurvey.get_currentTime(31,1,nowTime)

   let anameCheck='simInv_'+userName+'@';
   let ilen=anameCheck.length;

   bigData=allCurrentData;

    let nportfolios=bigData['portfolios']['list'].length;
    let nassets=bigData['assets']['list'].length;

    let ec=$('#ilocalArchiveComment');
    let acomment=ec.val();
      acomment=wsurvey.removeAllTags(acomment);
    let zz1={'dateStamp':nowTime,'userName':userName,'dateSay':nowTimeSay,'content':bigData,'archiveDate':nowTime,'comment':acomment};

    let arfData=JSON.stringify(zz1);
    let amess='';
    amess+='<div style="font-size:110%;margin:5px;">simInv data for <u>'+userName+'</u> (on '+nowTimeSay+') has '+nassets+' assets and '+nportfolios+' portfolios.';
    amess+=' To save this data to a file ... </div>';
    amess+='<table width="95%" cellpadding="5">';
    amess+='<td width="50%"><ul style="list-style-type: lower-alpha;">';
    amess+='<li><button onClick="doExportImport_local_archive_copy(this)" class="cdoButtonRegular"> ';
    amess+=' Copy the archived information ';
    amess+='</button> (to your clipboard)';
    amess+=' <span id="doExportImport_local_archive_results_copied"  ';
    amess+=   ' title="archived information can now be pasted!" style="color:green;display:none">Copied!';
    amess+='</span>  ';
    amess+='<li>  Cut &amp; paste it to a <u>text</u> file on your computer';
    amess+='<br><em>For example:</em> create/paste/save <tt>simInvArchive_'+userName+'.txt</tt>  with windows Notepad editor';
    amess+='</ul>';
    amess+=' </td>';
    amess+='<td width="50%"> ';
    amess+='<button onclick="doExportImport_local_archive_preview(this)" title="View this javaScript object in a new window">Preview</button> the archived information?<br>';
    amess+='<div title="The archived simInv data for user: '+userName+'" id="doExportImport_local_archive_results_string" style="height:3em;width:20em;overflow:auto;background-color:gray;padding:1em">';
    amess+=arfData;
    amess+='</div>';
    amess+='</td>';
    amess+='</tr></table>';
    amess+='You can <button>restore</button> this data at a later date -- don\'t forget where you saved your  text file &#9786;';
    
    if (iuse==1) {
       displayStatusMessage(amess,1);
       toggleStatusMessage(0,0);
    } else {
      $('#doExportImport_local_archive_results').html(amess).show();
      $('#doExportImport_local_archive_next').hide();
    }


}

//=============
// copy archived "stringified" file to clipboard
function doExportImport_local_archive_copy(athis) {
  let e1=$('#doExportImport_local_archive_results_string');
  let astuff=e1.text();

   navigator.clipboard.writeText(astuff).then(
  () => {
    $('#doExportImport_local_archive_results_copied').show();
   // clipboard successfully set 
  },
  () => {
    // clipboard write failed
  }
);

return 1;
}

//==========
// display archived info
function doExportImport_local_archive_preview(athis) {
   let e1=$('#doExportImport_local_archive_results_string');
   let astuff=e1.text();
   let vv=JSON.parse(astuff);
   let d2=vv['dateSay'];


   let uu=vv['userName'];
   showDebug(vv,'Previewing. simInv archivable data for: '+uu+' on '+d2);

   $('#doExportImport_local_archive_next').hide();


}

//===========
// restore data -- reads a stringified file saved using  doExportImport_local_archive
function doExportImport_local_restore(athis) {
   $('#doExportImport_local_archive_next').hide();

   let amess='';
   amess+='For user <tt>'+userName+'</tt>. Restore an <em>archived simInv data</em> file (to local storage) -- that was created using <button>archive</button> ... ';
   amess+='<table width="99%" cellpadding="6"><tr>';
   amess+='<td  valign="top" width="55%">';
   amess+='<ul>';
   amess+='<li>View a simInv archive file in a text editor  ';
   amess+='<li>Copy its entire contents to the clipboard    ';
   amess+='<li>Paste into the <span  style="border:4px dotted purple ">textbox</span>       ';
   amess+='<li><button onclick="doExportImport_local_restore_preview(0)" title="View this javaScript object in a new window">Preview</button> it! ';
   amess+='<li><span style="width:4em;display:inline-block;align:right"> You can: </span> '   ;
   amess+='  <button onClick="doExportImport_local_restore_overwrite(0)">Overwrite </button>  ';
   amess+=' <span style="border:1px solid yellow;border-radius:2px" > -- delete existing assets and portfolios</span>   ';
   amess+='<p><span style="width:4em;display:inline-block;align:right"><em >or ...</em></span>';
   amess+='  <button onClick="doExportImport_local_restore_add(0)">Add </button>  ';
   amess+=' <span style="border:1px solid yellow;border-radius:2px"> -- retain existing assets and portfolios</span>';

   amess+='</ul>';
   amess+='</td>  ';
   amess+='<td width="45%"><em>Paste the contents to this textbox...</em> <br>';
   amess+='<textarea style="border:4px dotted purple" title="Paste the simInv archive data here!" id="doExportImport_local_restore_textarea" rows="3" cols="40"></textarea>';
   amess+='<br>You can <input type="button" value="clear" onClick="doExportImport_local_restore_clear(this)"> the textbox';


   let osx=operatingSytem();
   if (osx=='Windows') {
       amess+='<br>Windows hint: ';
       amess+='<ul class="linearMenuHint">';
       amess+='<li> open the file using <tt>Notepad</tt> (or some other text editor),   ';
       amess+='<li> click anywhere on its contents,' ;
       amess+='<li> <tt>ctrl-A</tt> to mark it all, ';
       amess+='<li><tt>ctrl-C</tt> to copy it,  ';
       amess+='<li> click in the <span  style="border:4px dotted purple ">textbox</span>, ';
       amess+='<li>and <tt>ctrl-V </tt>to paste the contents ! ';
       amess+='</ul>';
   }
   amess+='</td></tr>';
   amess+='</table>';
    $('#doExportImport_local_archive_results').html(amess).show();


}
//=-=== preview pasted archived simInv data
function doExportImport_local_restore_preview(iquiet) {
   if (iquiet==0)  $('#doExportImport_local_archive_next').hide();
   if (iquiet==0) $('#doExportImport_local_archive_results').show();
   let e1=$('#doExportImport_local_restore_textarea');
   let astuff=e1.val();

   let a1=jQuery.trim(astuff);
   a1= a1.replace(/\s+/g," ");
   let vv;
   try {
     vv=JSON.parse(a1);
   } catch (e) {
    alert('Unable to read archived data. Perhaps you did not copy all of the text (from the archive file)?\n Error: '+e);
    return false ;
   }

   let d2,uu;
   if (!vv.hasOwnProperty('userName') || !vv.hasOwnProperty('dateSay')) {
      let jmess='This does not seem to be from a simInv archive ... it does not have  a  userName  and a  dateSay ) ';
      jmess+='\nDo you still want to preview it? ';
      let qq=confirm(jmess);
      if (!qq) return false;
      if (iquiet==0)   showDebug(vv,'Previewing json data (not a simInv archive)');
   } else {
       d2=vv['dateSay'];
       uu=vv['userName'];
       if (iquiet==0)   showDebug(vv,'Previewing. simInv archived data for: '+uu+' on '+d2);
   }

   return vv;

}

//===========
// clear "contents to restore" tesxtara
function doExportImport_local_restore_clear(athis) {
   $('#doExportImport_local_archive_next').hide();
   $('#doExportImport_local_archive_results').show();

   let e1=$('#doExportImport_local_restore_textarea');
   e1.val('');
}


//================
// restore archived data (overwrite all existing data) for a user
function doExportImport_local_restore_overwrite(ido) {
   let e1=$('#doExportImport_local_archive_next')  ;
   let nowTime=wsurvey.get_currentTime(0)   ;

   e1.show();
   $('#doExportImport_local_archive_results').hide();

   let  vv=doExportImport_local_restore_preview(1)  ;

   if (vv===false) return 1;
   let d2=vv['dateSay'];
   let uu=vv['userName'];

   let whereLook;
   if (vv.hasOwnProperty('content')) {
       whereLook='content';
   } else {
     if (vv.hasOwnProperty('data')) {
         whereLook='data';
     } else {
            wsurvey.dumpObj(vv,1,'doExportImport_local_restore_overwrite problem: no data or content ');
            return false ;
     }
   }
   let nportfolios=vv[whereLook]['portfolios']['list'].length;
   let nassets=vv[whereLook]['assets']['list'].length;

   if (ido==0) {         // overwrite... show warning

      let pnow=simInv_localVar('portfolios');
      let anow=simInv_localVar('assets');
      let anowAssets='n.a.';

      if (anow.hasOwnProperty('list'))  {
         anowAssets= anow['list'].length;
      } else {

          if (anow.hasOwnProperty('content')) {
              if (anow['content'].hasOwnProperty('list') ) {
                 if (anow['content']['list'].hasOwnProperty('data') ) {
                    anowAssets= anow['content']['list']['data'].length;
                 }
              }
          }
      }

      let amess='';
      amess+='<input  type="button"  value="&#8617;&#65039;" title="go back " onClick="doExportImport_local_restore_goback()">';
      amess+='Restoring: data from: user=<tt>'+uu+'</tt> on <tt>'+d2+'</tt>:  '+nassets+' assets, and '+nportfolios+' portfolios';
      amess+='<br>The current '+pnow['list'].length+ ' portfolios, and '+anowAssets+' assets, will be <b>deleted</b> (they might, or might not, be replaced by portfolios &amp; assets specified in the archive file).';
      amess+='<br><button onClick="doExportImport_local_restore_overwrite(1)" class="cdoButtonModify">Are you ('+userName+') sure? </button>  ' ;
      amess+='<div id="doExportImport_local_archive_next_2" style="background-color:cyan;margin:5px 3em "> ... </div>';
      e1.html(amess).show();
      $('#doExportImport_local_archive_results').hide();
      return 0;
   }

  let googoo=vv[whereLook];
  let res1=[];
  for (let vname in googoo) {
    if (vname=='keyMd5') continue ;
     let vval=googoo[vname] ;
     let q=simInv_localVar(vname,vval);
     if (q===true) {
         res1.push('Saved: '+vname);
     } else {
         res1.push('Problem saving: ' +vname);
     }
   }
   let resmess='Restoring data for user <tt>'+userName+'</tt>';
   resmess+='<ul><li>'+res1.join('<li>')+'</ul>';
   $('#doExportImport_local_archive_next_2').html(resmess).show()

   displayResponseFromServer(resmess,1) ;

   return 1;

}


//================
// add archived data  -- if an asset or portofolio exists, do NOT overwrite
function doExportImport_local_restore_add(athis) {

   let e1=$('#doExportImport_local_archive_next');
   e1.show();

   let encryptionKey_local='';  // suppresse encryption in local (5 aug 2023)

   $('#doExportImport_local_archive_results').hide();

   let  saveme=doExportImport_local_restore_preview(1);
   if (saveme===false) return 1;
   if (!saveme.hasOwnProperty('content')) {
       if (saveme.hasOwnProperty('data')) saveme['content']=saveme['data'];
   }
 
     let nowTime=wsurvey.get_currentTime(0)   ;

    let origData=JSON.parse(JSON.stringify(allCurrentData));

// fix some odd stuff
    if (!origData['assets'].hasOwnProperty('list') || origData['assets']['list']===false )  origData['assets']['list']=[];
    if (!origData['portfolios'].hasOwnProperty('list') || origData['portfolios']['list']===false )  origData['portfolios']['list']=[];
    if (!origData['portfolioInit'].hasOwnProperty('list') || origData['portfolioInit']['list']===false )  origData['portfolioInit']['list']={};
    if (!origData['portfolioModifications'].hasOwnProperty('list') || origData['portfolioModifications']['list']===false ) origData['portfolioModifications']['list']={};
    if (!origData['assetHistory'].hasOwnProperty('list'))  origData['assetHistory']['list']={} ;
    if (!origData['assetHistory'].hasOwnProperty('autoAddEntries'))  origData['assetHistory']['autoAddEntries']={} ;

    let savemeAdd={};
    let nassetsRetain=0,nassetsAdd=0,nportfoliosRetain=0,nportfoliosAdd=0;

// add assets (do not add from archive data if asset already exists)
    let gotAssets={};
    let list1=[];
    for (let ia=0;ia<origData['assets']['list'].length;ia++) {    // keep existing
       let aname= origData['assets']['list'][ia]['name'];
       gotAssets[aname]=1;
       list1.push(origData['assets']['list'][ia]);
       nassetsRetain++ ;
    }
    for (let ia=0;ia<saveme['content']['assets']['list'].length;ia++) {  // add if not in existing
       let aname2=saveme['content']['assets']['list'][ia]['name'];
       if (gotAssets.hasOwnProperty(aname2)) continue ; // do NOT overwrite
       list1.push(saveme['content']['assets']['list'][ia]);
       nassetsAdd++ ;
    }

    savemeAdd['assets']={'list':list1} ;

// add assetHistory (do not add from archive data if asset already exists) -- will NOT  add history  for an existing asset (even if no history defined)
    let gotAssetsH={};
    let listH={'list':{},'autoAddEntries':{}};
    for (let aname in  origData['assetHistory']['list']) {    // keep existing
       gotAssetsH[aname]=1;
       listH['list'][aname]=origData['assetHistory']['list'][aname];
       listH['autoAddEntries'][aname]=origData['assetHistory']['autoAddEntries'][aname];
    }
    for (let aname2 in saveme['content']['assetHistory']['list'] ) {  // add if not in existing
       if (gotAssets.hasOwnProperty(aname2)) continue ; // do NOT create
       if (gotAssetsH.hasOwnProperty(aname2)) continue ; // do NOT overwrite
       listH['list'][aname2]=saveme['content']['assetHistory']['list'][aname2];
       listH['autoAddEntries'][aname2]=saveme['content']['assetHistory']['autoAddEntries'][aname2];
    }
    savemeAdd['assetHistory']={};
    savemeAdd['assetHistory']['list']= listH['list'];
    savemeAdd['assetHistory']['autoAddEntries']= listH['autoAddEntries'];


// add portflioes (do not add from archive data if portfoliow already exists)
    let gotPortfolios={};
    let listP=[];
    for (let ia=0;ia<origData['portfolios']['list'].length;ia++) {    // keep existing
       let pname= origData['portfolios']['list'][ia]['name'];
       gotPortfolios[pname]=1;
       listP.push(origData['portfolios']['list'][ia]);
       nportfoliosRetain++;
    }
    for (let ia=0;ia<saveme['content']['portfolios']['list'].length;ia++) {  // add if not in existing
       let pname2=saveme['content']['portfolios']['list'][ia]['name'];
       if (gotPortfolios.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       listP.push(saveme['content']['portfolios']['list'][ia]);
       nportfoliosAdd++ ;
    }
    savemeAdd['portfolios']={'list':listP } ;


// add portflioInts (do not add from archive data if portfoliow already exists)
    let gotPortfolioInits={};
    let listPinits={};
    for (pname in origData['portfolioInit']['list'] ) {    // keep existing
       gotPortfolioInits[pname]=1;
       listPinits[pname]=origData['portfolioInit']['list'][pname] ;
    }
    for (let pname2 in  saveme['content']['portfolioInit']['list']) {  // add if not in existing
       if (gotPortfolios.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       if (gotPortfolioInits.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       listPinits[pname2]=saveme['content']['portfolioInit']['list'][pname2] ;
    }
    savemeAdd['portfolioInit']={'list':listPinits} ;


// add portfolioModifications (do not add from archive data if portfoliow already exists)
    let gotPortfolioMods={};
    let listPmods={};
    for (pname in origData['portfolioModifications']['list'] ) {    // keep existing
       gotPortfolioMods[pname]=1;
       listPmods[pname]=origData['portfolioModifications']['list'][pname] ;
    }
    for (let pname2 in  saveme['content']['portfolioModifications']['list']) {  // add if not in existing
       if (gotPortfolios.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       if (gotPortfolioMods.hasOwnProperty(pname2)) continue ; // do NOT overwrite
       listPmods[pname2]=saveme['content']['portfolioModifications']['list'][pname2] ;
    }
    savemeAdd['portfolioModifications']={'list':listPmods } ;

// now save locally
     simInv_localVar('portfolios',savemeAdd['portfolios']);
     simInv_localVar('portfolioInit',savemeAdd['portfolioInit']);
     simInv_localVar('portfolioModifications',savemeAdd['portfolioModifications']);
     simInv_localVar('assets',savemeAdd['assets']);
     simInv_localVar('assetHistory',savemeAdd['assetHistory']);

  bmess='<br>#assets retained='+nassetsRetain +', added='+nassetsAdd+'. #portfolios retained='+nportfoliosRetain +', added='+nportfoliosAdd  ;

  displayResponseFromServer(bmess,1) ;

}

//==============================
//=show the "restore" menu (retaining pasted content
function doExportImport_local_restore_goback(athis) {
   $('#doExportImport_local_archive_next').hide();
   $('#doExportImport_local_archive_results').show();
   return 1 ;
}


//=============
function doExportImport_viewResults(athis) {
  let b1=JSON.stringify(viewDates_dataStore);

// get variables, portfolios, and dates ..
  let varList={},dateList={},portfolioList={};
  for (let adate in viewDates_dataStore) {
      if (!dateList.hasOwnProperty(adate)) dateList[adate]=0;
      dateList[adate]++;
      for (let aportfolio in viewDates_dataStore[adate]) {
          if (!portfolioList.hasOwnProperty(aportfolio)) portfolioList[aportfolio]=0;
          portfolioList[aportfolio]++;
          for (let avar in  viewDates_dataStore[adate][aportfolio]) {
             if (!varList.hasOwnProperty(avar)) varList[avar]=0;
             varList[avar]++ ;
          }  // avar
      }          // aportfolio
  }  // adate in ..

// probably overkill (sorting by date)
  let vdates=[];
  for (let adate in dateList) vdates.push(adate);
  vdates.sort(mySortNumeric);

// make header
  let hdrline=['"date"','"dateSay"'];

  for (let aportfolio in portfolioList) {
       for (let avar in varList) {
            let vname=aportfolio+'#'+avar ;
            hdrline.push('"'+vname+'"');
       }
  }

  let allLines=[];
  allLines.push(hdrline);

// add data rows as csv
  for (let idd=0;idd<vdates.length;idd++) {
      let adate=vdates[idd];
      let oof=setEntryDate(adate);
      let sayDate=oof.sayDate;
      let aline=[adate,sayDate];

      for (let aportfolio in portfolioList) {
          for (let avar in varList) {
              let xx=' ';  // missing value
              if (viewDates_dataStore.hasOwnProperty(adate)) {
                 if (viewDates_dataStore[adate].hasOwnProperty(aportfolio)) {
                    if (viewDates_dataStore[adate][aportfolio].hasOwnProperty(avar)) {
                        xx=viewDates_dataStore[adate][aportfolio][avar];
                        if (!jQuery.isNumeric(xx)) {          // get rid of tags and commas
                            xx=wsurvey.removeAllTags(xx);
                            xx= xx.replace(/\,/g, ' ') ;
                            xx='"'+xx+'"';
                        }
                    }
                 }
              }    // adate
              aline.push(xx);
          }    // for  avar
      }     // a portfolio
      allLines.push(aline);
  }      // idd

// now make the csv lines
  let all2=[];
  for (let ii=0;ii<allLines.length;ii++) {
      let bline=allLines[ii].join(',');
      all2.push(bline);
  }
  let all3=all2.join('\n');

  let bmess='';
  bmess+='<button title="Tips" onClick="displayHelpMessage(this)" data-div="#exportResultsHelp1">&#10068;</button>';
//  let bb=JSON.stringify(viewDates_dataStore);
   bmess+='The exported portfolio results can be saved as a .CSV file<br>';
   bmess+='<table cellpadding="5" rules="rows">';
        bmess+='<tr>    ';
        bmess+='<td width="30%"><button onClick="doExportImport_viewResults_mark(this)">Copy results</button> <em>to the clipboard</em>';
        bmess+='<div style="color:green;font-style:oblique;display:none" id="doExportImport_viewResults_copied"></div>';
        bmess+=' </td>';
        bmess+='<td>   ';
        bmess+='<button class="csettingsButton" onClick="doExportImport_viewResults_preview(this)">View its contents (javascript previewer) </button>  ';
        bmess+='<button class="csettingsButton" onClick="doExportImport_viewResults_html(this)">View its contents in an HTML table</button>  ';
        bmess+='<div style="background-color:#afafaf;height:5em;width:40em;overflow:auto" id="iImportExport_viewresults">'+all3+'</div>';

        bmess+='</td></tr>';
   bmess+='</table>';
   bmess+='<em>Hint:</em> The CSV <em>contents</em> can be pasted into most spreadsheet programs, or pasted into an empty text file. '


    displayStatusMessage(bmess);
    toggleStatusDiv(0,0);

    return 0;
}

function doExportImport_viewResults_preview(athis) {
   let e1=$('#iImportExport_viewresults');
   let vv=e1.text();
   let goo1=vv.split('\n');
   let goo2=[];
   for (let ivv=0;ivv<goo1.length;ivv++) {
      let agoo=goo1[ivv];
      let aline=agoo.split(',');
      goo2.push(aline);
   }
//   let vv2=JSON.parse(vv);
   showDebug(goo2,'Viewing portfolio results (as csv)');
}

function doExportImport_viewResults_html(athis) {
  // get variables, portfolios, and dates ..
  let colors=['cyan','lime'];

  let varList={},dateList={},portfolioList={},nvars=0,nportfolios=0;
  for (let adate in viewDates_dataStore) {
      if (!dateList.hasOwnProperty(adate)) dateList[adate]=0;
      dateList[adate]++;
      for (let aportfolio in viewDates_dataStore[adate]) {
          if (!portfolioList.hasOwnProperty(aportfolio)) portfolioList[aportfolio]=0;
          portfolioList[aportfolio]++;
          for (let avar in  viewDates_dataStore[adate][aportfolio]) {
              if (avar=='dateSay') continue ;
             if (!varList.hasOwnProperty(avar)) varList[avar]=0;
             varList[avar]++ ;
          }  // avar
      }          // aportfolio
  }  // adate in ..

  for (let aa in portfolioList) nportfolios++;
  for (let aa in varList) nvars++;

  let vdates=[];
  for (let adate in dateList) vdates.push(adate);
  vdates.sort(mySortNumeric);

// build the table
  let bmess='<table cellpadding="5" border="1"> ';
  bmess+='<colgroup>';
  bmess+='<col style="font-family:monospace">';
  let iport=1;
  for (let aport in portfolioList) {
     iport=1-iport;
     let acolor=colors[iport];
      bmess+='<col span="'+nvars+'" style="background-color:'+acolor+'"> ';
  }
  bmess+='</colgroup>';

  let arow='<tr><th>Date</th>';
  for (let aport in portfolioList) {
      arow+='<th colspan="'+nvars+'">'+aport+'</th>';
  }
  arow+='</tr>';
  bmess+=arow;

  arow='<tr><th>...</th>';
  for (let aport in portfolioList) {
      for (let aa in varList) {
           arow+='<th>'+aa+'</th>';
      }
  }
  
  arow+='</tr>';
  bmess+=arow;

// datalines
 for (let iv=0;iv<vdates.length;iv++) {
    adate=vdates[iv];
    let oof=setEntryDate(adate);
    let arow='<tr><td>'+oof.sayDate+'</td>';
    for (let aport in portfolioList) {
       for (let avar in varList) {

           let xx=viewDates_dataStore[adate][aport][avar];
           xx=wsurvey.removeAllTags(xx);
           arow+='<td><span title="'+aport+' / '+avar+'">'+xx+'</span></td>';
       }
    }
    arow+='</tr>';
    bmess+=arow;
 }
  bmess+='</table>';

   wsurvey.displayInNewWindow('',{'content':bmess});

}

function doExportImport_viewResults_mark(athis) {

  let e1=$('#iImportExport_viewresults');
  let astuff=jQuery.trim(e1.text());

  navigator.clipboard.writeText(astuff).then(
    () => {
        let e2=$('#doExportImport_viewResults_copied');
        e2.html('Copied!').show();
    },
    () => {
      // clipboard write failed
    }
  );
}





