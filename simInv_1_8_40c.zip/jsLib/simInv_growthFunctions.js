// "growth" functions for simInv
//==========

//==========
// "sampling" method of calculating a product of a "liner sequence" of interest rates
//  int1x : starting "yearly interest rate"
//  int2x :  ending yearly interest rage
//  gap  :  # of days of growth (first day growth uses int1x, last day growth uses a bit less than int2x)
// nsamples is an accuracy measure (larger value for better accuracy). If not specified, 5 is used
//
//   int1x and int2x should be 0.xx ... so 4% growth would be  4.0
//    OR --- if isDaily specified and is 1 -- int1x and int2x should be dailyi interest retes (as 1.xxxxx for xxxx%))
//
// NOte: if yearly interest rates provided: daily interest calculated using= exp(ln(rateYearly)/365)
//
// assumes a linear trend in rates


function simInv_interest(int1x,int2x,gap,nsamples,isDaily) {
  if (arguments.length<4 || nsamples===false) nsamples=5;
  if (arguments.length<5 ) isDaily=0;

  if (int1x==0.0 && int2x==0.0) { // no growth
      return [0.0,0] ;
  }

  let I1_day,I2_day ;
  if (isDaily!=1)   {        // int1x and int2x are yearly interest rates. If 1, they are "daily" interest rates delivered as 1.xxxxxx
    let int1=1+(int1x/100),int2=1+(int2x/100);     // convert 4% to 1.04)
     I1_day=Math.exp(Math.log(int1)/365)  ;
     I2_day=Math.exp(Math.log(int2)/365)  ;

  } else {
    I1_day=int1x;
    I2_day=int2x;
   }
   let  g_I=(I2_day - I1_day)/(gap);     // change in daily interest   (per day)

   if (nsamples>gap) nsamples=gap ;
   let ijump=parseInt(gap/nsamples);
   if (ijump>(gap/3)) ijump=parseInt(gap/3);  // at least 3 samples
   if (g_I==0)     nsamples=2 ;          // no change -- minimal samples

   let cumRate1=I1_day;
   let cumRate=1.0;
   let cumLast=1.0;

   let iwas=1 ;
   let idid=1;
   let totfacts=1;
   for (ii=0;ii<1000000;ii++) {
       idid++;                    // # of iterations
       let inext=iwas+ijump;
       let Iuse,ifact;
       if (inext>gap) {
          Iuse=I1_day+  ((gap-1)*g_I);    // daily int on final day
          ifact=gap-iwas;                 // days this will grow
          totfacts+=ifact;
          cumLast=Iuse**ifact;      // last one is special (since it is not ifact periods)
       } else {
          let iarf=inext;
          if (ijump>4) iarf=parseInt(iwas+(inext-iwas)/2) ;   // mid point approx
          totfacts+=ijump;
          Iuse=I1_day+ (iarf*g_I);

          cumRate=cumRate*Iuse;         // aggregate rate
       }
        iwas=inext ;
        if (inext>=gap) break;
   }

   let fcumRate=cumRate1*(cumRate**ijump)*cumLast;

   return [fcumRate,idid] ;

}

//================
// compute sum, of nPeriods, of earnings that start at v0 and end at v1 
//  (each period has earnings v, v ranging between v0 and v1)
// v0 and v1 can negative, 0, or positive
// typically nPeriods is #days, v0 and v1 are daily increments (or decrements),

function assetGrowth_sum(nPeriods,v0,v1 ) {
    if (nPeriods==0) return  0 ;

   if ( (v0*v1)>=0) {    // additions are of the same sign (or are 0)
      let vv1=nPeriods*v0;
      let vv2=nPeriods*((v1-v0)/2) ;
      let vv=vv1+vv2;
      let vvx=vv ;
      return vvx;
   }

// a sign switch
   let dd=Math.abs(v1-v0);
   let dfrac=Math.abs(v0)/dd ;
   let day1= ( nPeriods*dfrac);

   let vv1=(day1*v0)/2 ;
   let vv2=(nPeriods-day1)*v1/2 ;

   let atot=vv1+vv2;
   return atot ;

}


//==============
// Add a fixed amount (totalC), divvied up in chunks (one chunk per day in timespan (tsan).
// Each chunk grows at a yealry interest rate  (rateYear, that doesnt change over time)
//
// This uses   assetGrowth_cumSum_interest --
//  tspan in days, rateYEar yearly rate (i.e. 1.06 for 6%), totalC is total distributed throughout tspan
//   assumes constant interest rate, and constant daily sum
//  Convert yearly rate to daily rate, and totalC to daily amount
function assetGrowth_cumSum_interest_daily(totalC,rateYear,tspan) {

   if (rateYear==1.0) return totalC ;   // no graowth

   let daySum=totalC/tspan,rateDay,dinterest;

   dinterest= Math.log(parseFloat(rateYear))/365.0;
   rateDay=Math.exp(dinterest);

   let vv=assetGrowth_cumSum_interest(daySum,rateDay,tspan) ;
   return vv;
}

// ===================
//   periodic additions of a fixed amount, with the accumulation growing at a periodic rate of interest
//  Assume the addition occurs at end of period
//  addC : per period addition
//  rate1 : per period rate
//  tspan : # of periods
//
// Eg:
//   daily sum: 30
//   daily rate of interest: 1.05
//   # days : 4
//   = 30*(1-1.05^4) / (1-1.05) ==  30*(1-1.2155)/(1-1.05) =  -6.465 / -0.05   = 129.303
//   = 30 + 30*1.05 + 30*1.05^2 + 30*1.05^3     = 129.303
//  == addition at end of period 4 + addition at end of period 3 that grew one period + .. + addition at end of period 1 that grew 3 periods
// https://www.varsitytutors.com/hotmath/hotmath_help/topics/geometric-series
// based on
//  [ a1 * (1-r^n) ]  /  (1-r)

function assetGrowth_cumSum_interest(addC,rate1,tspan) {
   let num=1-(rate1**tspan);
   let denom=1-rate1;
   let vv= addC* (num/denom);
   return vv;
}

//==========================
// calculate value of a stream of additions over a time period: with interest rate and additions following a linear trend
//  startVal : a starting value -- which  will grow using the rate of interest
//  add1 and add2 : yearly additions at begin and end of   period.
//  int1 and int2 : yearly interest rate at being and end of period.  Where xx means xx%
//  gap : length of period (in days)
//  nsamples : optional (a value is determined, as a function of gap, if not specified)
//
// If isDaily specified and =1, then add1 and add2 are daily additions 
//
//  Add1/365 is the addition at the beginning of the first day   (Add1 if isDaily=1)
//  Add2/365 is the addition at the beginning of the last day   (Add2 if isDaily=2)
//  and the number of days= gap
//
// Stylized example: startVal=0, gap=4, add1/365=10, add2/365=22, and constant 2% daily interest rate (which would be a 1379.00 yearly interest))
//      day 1 start: add 10    : which yields : 10  * 1.02 * 1.02  * 1.02 * 1.02
//      day 2 start : add 13   : which yields : 13  * 1.02  * 1.02 * 1.02
//      day 3 start : add 16   : which yields : 13  * 1.02  * 1.02
//      day 4 start : add 19  .. which yields : 13 * 1.02
//      day 5 : no additions...
//    58 in raw additions, +   2.7 in interest earnings
//
//  NOTE That this is a contrived example --- simInv_additions  works with YEARLY rates!
//
// nsamples : intensity of samples. Higher number for greater accuracy. Default is 30 (20 is often good enough)
//           If nsamples> gap/2 -- then no sampling (values for each day are calculated)
//
// returns 5 element array:  [rawAdd,intAdd,startGrowth,endvalue, samplePoints]
// where :
//  [0]   rawAdd  = sum  of additions with NO interest growth,
//  [1]  intAdd   = sum of additions incorporating interest growth,
//  [2]  startGrowth =sum of interest growth of the starting value
//  [3]  endvalue :  startVal + intAdd + startGrowth
//  [4] samplePoints: # of sample points used
//
// For a simpler version (constannt daily addition, unchanging interest rate); see  assetGrowth_cumSum_interest_daily

function simInv_additions(startVal,add1,add2,int1x,int2x,gap,nsamples,isDaily) {

  if (gap<=0)  {           // may happen ...
    return [0,0,0,startVal,0] ;
  }

  if (arguments.length<8) isDaily=0;

  if (arguments.length<7 || !jQuery.isNumeric(nsamples)) {
    if (gap<=50) {
        nsamples=4 ;
    } else if (gap<=150) {
       nsamples=5 ;
    } else if (gap<=366) {
       nsamples=5;
    } else if (gap<=950) {
       nsamples=8;
    } else if (gap<=2000) {
       nsamples=10    ;
    } else if (gap<=4000) {
       nsamples=12   ;
    } else if (gap<=10000) {
       nsamples=16 ;
    } else if (gap<=18000) {
       nsamples=24 ;
    } else if (gap<=40000) {
         nsamples=30;
    } else {
        nsamples=50   ;
    }

  }       // nsample as a function of gap length

  let int1=1+(int1x/100),int2=1+(int2x/100);     // convert 4% to 1.04)
  let I1_day=Math.exp(Math.log(int1)/365)  ;
  let I2_day=Math.exp(Math.log(int2)/365)  ;


// else > 1 day gap
  let A1_day,A2_day;
  if (isDaily==1) {
     A1_day=add1;
     A2_day=add2;
  } else {
    A1_day=add1/365;                       // start of first day growth
    A2_day=add2/365;                        // END of last day growth
  }

  if (gap===1)  {                          // one day gap
     let A1_dayI=(I1_day-1)*A1_day;
     let sgrowth=(I1_day-1)*startVal;
     let endv=startVal+A1_dayI+startGrowth;
     return [A1_day,A1_dayI,sgrowth,endv,1] ;
  }

  let  g_I=(I2_day - I1_day)/(gap);     // change in daily interest   (per day)
  let  g_A=(A2_day-A1_day)/(gap);     // change in daily additions  (per day)

  let sampRate ;        // conver nsamples to # of days between each sample point
  if (gap<4) {           // small gap... do 'em all
     sampRate=1;
  } else {
    sampRate=parseInt(gap/nsamples) ;
    sampRate=Math.max(1,sampRate);   // can't be less than 1
    let s2=parseInt(gap/2);
    sampRate=Math.min(s2,sampRate);   // cant be too large
  }

  vDays=[0];          // always add the  0th day
  for (let dd=0;dd<1000000;dd++) {       // manually  add dd=gap-1 after loop end
    let doday=1+ (dd*sampRate);
    if (doday>=gap-1) break;
    vDays.push(doday)
  }
  vDays.push(gap-1);

  let vFfs_work={}  ;
  let rprimeS=1.0;
 // calculate the "interest growth incoproating" value at the sample points ...
  let jpWas=gap;       // will be bigger than jp
  for (let jp0=vDays.length-1;jp0>=0;jp0--) {        // for each of the "sample pieces" (each piece approximates a triangle wedge of the true rate growth)
     let jp=vDays[jp0];
     x1=A1_day+(jp*g_A);

    let izoo1= I1_day+(jp*g_I) ;
     let izoo2= I1_day+(jpWas*g_I) ;
     let izoo3=(jpWas-jp);

     let rprime1= simInv_interest(izoo1,izoo2,izoo3,false,1) ;     // [fcumRate,idid]

     rprimeS=rprime1[0]*rprimeS ;

     let ffS=x1*rprimeS;      // add value at start of piece, growing at cumulativei interest rate from start of samplePiece until end of period
     vFfs_work[jp]=ffS ;  // save for use below

     jpWas=jp ;           // used in next iteration (next sample  piece)

  }


// account for non-sampled with linear intrpooadion
// ie.; if  day 1 and day 9 have measurements, interploate values for 7 days inbetween (days 2,3,..,8)

  let jdWas=vDays[0];                 // the first sample
  let ffsWas=vFfs_work[0];
  let vZadd={} ;

  for (let jd0=0;jd0<vDays.length;jd0++) {
    let jd=vDays[jd0];

    ffS=vFfs_work[jd]
    let dDays=jd-jdWas ;

    if (jd-jdWas<=1)  {   // no gap to interpoloate
        vZadd[jd]=0;
        jdWas=jd;
        ffsWas=ffS;
        continue;
    }

    let dFfs=ffS-ffsWas;
    let stepFfs=dFfs/dDays ;         // additions per day (of growth) -- i.e.; step 2 has 7, step 3 has 6,...., step 8 has 1
    zadd1=(dDays-1)*ffsWas ;         // sqauare part of polygon (be careful not to double   count sampled steps)
    zadd2=(dDays*(dDays-1)/2) * stepFfs;           // triangle part --  ie; the 7+6+..+1 "stepFFs" chunks in the 7 "days 2..8" rectanlges

    let zadd=(zadd1+zadd2) ;
    vZadd[jd]=zadd;

    jdWas=jd;
    ffsWas=ffS;


  }         // vdays

  let bsumS=0;

  for (let jd0=0;jd0<vDays.length;jd0++) {   // about nsamples long (so not much)
    let jd=vDays[jd0];           // inext ingo vFFs_work and vZadd
    let t1=vFfs_work[jd];         // the measured days
    let t2=vZadd[jd];             // interpolated for other days
    bsumS+=(t1+t2);
  }

// the raw (no interest) sum of additions

let bsumRaw ;
if (A1_day == 0 && A2_day==0)  {        // could happen
   bsumRaw=0 ;
} else {           // sum of daily additions  -- using sum of "chunks" for all days!
   t1=gap*A1_day ;
   let gg=gap*(gap-1)/2 ;        // first day grwoth is A1_day, no growtn after last day
   t2=g_A*gg;
   bsumRaw=t1+t2;
}

  let ag1= simInv_interest(I1_day,I2_day,gap,false,1)  ;

  startGrowth=startVal*(ag1[0]-1) ;

 let endValue=startVal+bsumS+startGrowth
  return [bsumRaw,bsumS,startGrowth,endValue,nsamples] ;

}    // simInv_addtionsS




//==================
// simple growth at yearly rate of interest, over growdays
// iYear: yearly interest rate . eg 3% = 1.03
// daysGap : # of days at this yearly interest rate
function assetGrowth_interestSimple(iYear,daysGap) {
  if (iYear==1) return 1.0 ;

  let dinterest= Math.log(parseFloat(iYear))/365.0;
    let interestP=Math.exp(daysGap*dinterest);
    return interestP ;
}




//=============================
// compute dividends  earned by original stocks and by newly purchased stocks, and newly purchased stock
//   startingStock : starting # of shares
//  divStart : yearly dividends as of start of period   (start of first day)
//  divEnd  : yearly dividends    as of end of period (start of final day)
//  priceStart : price at start of period
//  priceEnd  : price at end of period
//  growDays:  # of days in period
//
//  Assumes daily dividend earnings that are immedately used to purchase additional shares.
//  These then earn dividends (Starting from the day they are obtained)
//
// returns [#shareAftterGrowdays, totalDividendEarningsAfterGrowdays]

function assetGrowth_stock(startingStock,divStart,divEnd,priceStart,priceEnd,growDays) {

  if (growDays==0) {            // no growth...
     return(startingStock,0);
  }

   let dayGap=30 ;                      // smaller values for greater accuray, larger for quicker
   let divStart_daily= divStart/365;     // use daily values
   let divEnd_daily= divEnd/365;

// step through days, by dayGap  day increments, determining newly added stocks and the dividends they will earn

// first: the starting block of stocks generates dividends
   let earningsX1= assetGrowth_sum2(growDays,divStart_daily,divEnd_daily,0,growDays) ;

   let vA=earningsX1*startingStock;

   let dividendCum=vA ;

   let day1,day2=0,n1=startingStock ;

// day by day would be more accurate, but to save procsessing  use a "monthly purchases" approximatin

// at the end of each month, purchase a tranche of  stocks with dividends earned during the month ... and how much this tranche will earn for the rest of the period

   let nNewAll=0;
   for (let jday=1;jday>0;jday++)   {  // leave using break
      let n0=n1;
      day1=day2;
      day2=Math.min(day1+dayGap ,growDays);

      let amult= assetGrowth_dividend2(divStart,divEnd,priceStart,priceEnd,growDays,day1,day2) ;   // use an integra to compute per share growth (assuming instanetious reinvesment)

      n1=amult*n0;          // new amount of shares
      nNew=n1-n0  ;          // the newly added shares (kind of dumb but wth)

      let earningsX= assetGrowth_sum2(growDays,divStart_daily,divEnd_daily,day2,growDays) ;    // per share earnings from acquistion date to end
      let vB=earningsX*nNew;                   // the diviedne earnings  of this   tranche (from this day to end of period)

      nNewAll+=nNew;
      dividendCum+=vB;

      if (day2>=growDays) break;

   }

   let nFinalB= startingStock+nNewAll ;
   return [nFinalB,dividendCum];
}

//==============================
// This is used by   assetGrowth_stock
// calculate per share growth rate if all dividends are reinvseted.
// Given start and end dividend, start and end price, timespan (#days between start and end), and day range WITHIN this timespan
// This uses a formulaic approximation of a "day by day" growth; with a day's growth being the dailyDividend/priceOnThatDay
//
// uses integral of :  ln( 1 +   ((D_0 + g_d*x   ) / (P_0+g_p*x )  )
//
// uses  https://www.integral-calculator.com/
// assumptiosn: dividend determined at start of day, and paid at end
// day count starts at 0
// thus: D0  is the daily dividend determined on the start of day 0
//        It is paid at the start of day 1
//       D0 + (growDays-1)*g_d  is the dividend determined at the start of growDays-1
//          and paid at the start of growDays
//          THUS: D1 is never used exactly -- it would be paid if one more day was added
// This is why "x" (first arg in assetGrowth_dividend_p) has one subracted (ie; the value at the start of day 0 is needed, not at the end of day 0)
//
// day1 and day2 used to find "internal" growth (a part of the 0 to tspan period)

function assetGrowth_dividend2(D0a,D1a,P0a,P1a,tspan,day1,day2 )  {
  if (arguments.length<6) day1=0;
  if (arguments.length<7) day2=tspan;
  if (tspan==0) return  1.0 ;
  if (day1==day2) return 1.0;
  if (day2<day1) return false ;      // must be after
  if (day1<0) day1=0;
  if (day2>tspan) day2=tspan ;

   let D_0=D0a/365;       // daily dividend
   let D_1=D1a/365;
   let P_0=P0a;
   let P_1=P1a;
   if (P_0==P_1) P_1+=0.000001 ; // hack to deal with failure of integral

   let  g_d=(D_1-D_0)/(tspan);     // change in daily dividend
   let  g_p=(P_1-P_0)/(tspan);     // change in price (per day)

   let tspanUse=day2-day1 ;

   P_0_use=P_0+ (day1*g_p);   // price at start of desired time block
   D_0_use=D_0+ (day1*g_d);

  let vv1=assetGrowth_dividend_p(tspanUse-1,P_0_use,D_0_use,g_p,g_d) ;

  let vv0=assetGrowth_dividend_p(-1,P_0_use,D_0_use,g_p,g_d) ;


  return Math.exp(vv1-vv0);

/// internal function
  function  assetGrowth_dividend_p(x,P_0,D_0,g_p,g_d) {


    let t1a=(P_0+D_0) ;
    let t1b1=( (g_p+g_d)*x)+P_0+D_0  ;
    t1b=Math.log(Math.abs(t1b1));
    let num1=t1a*t1b
    let p1=num1/(g_p+g_d);

    let t2a=(g_p*x) + P_0   ;
    let t2b=Math.log(Math.abs(t2a)) ;
    let p2=(P_0*t2b) / g_p ;

    let t3num=(g_d*x) + D_0;
    let t3denom=(g_p*x)+P_0;
    let t3= (t3num/t3denom)+1;
    let p3=x*Math.log(t3);

    let vv=p1+ (-p2) + p3 ;
    return vv;
  }

}

//================
// This is used by   assetGrowth_stock
// sum of linearly changing value, over nperiods
// nperiods : number of periods
//  v0 v1 : value (i.e.; daily dividend) at start & and of period
// t0 t1 : timespan within period to calculate for. If not specified, use 0 and nperiods

function assetGrowth_sum2(nPeriods,v1,v2,t1,t2 ) {
    if (nPeriods==0) return  0 ;
    if (arguments.length<4  || t1<0) t1=0;
    if (arguments.length<5  || t2>nPeriods) t2=nPeriods;
    if (t2==t1) return 0 ;
    if (t2<t1) return false;

    let dv=(v2-v1)/nPeriods;   // change in daily rate

    let v1Use=v1+(dv*t1);
    let v2Use=v1+(dv*t2);

    let nPeriodsUse=t2-t1 ;

   let vv1=nPeriodsUse*v1Use;
   let vv2=nPeriodsUse*((v2Use-v1Use)/2) ;
   let vvx=vv1+vv2;

   return vvx;
}

