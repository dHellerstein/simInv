// read asset specs from a portfolio menu
// isMod=1 : this is a portfolio modification (skips income and annuity, check for refinance
// budget used for % cacluations

function portfolioCalcValueMenu_read(isMod,quiet,pname,abudget,pdateCount) {

   let errors=[];        // list of errors IF quiet=1 (otherwise, not filled)

   let etable=$('#portfolioHistory1');

   let ebaseIth=etable.find('[name="baseEntry_ith"]');
   let base_ith=ebaseIth.val();
   let ebaseDate=etable.find('[name="baseEntry_closestDate"]');
   let base_date=ebaseDate.val();

   let existingAssets={};
   if (isMod==1) {                      // reading modifications .. get list of aready existing assets
         for (let imm=0;imm<simInvDsets['entryWorking']['grown']['assetList'].length;imm++) {
             let aname=simInvDsets['entryWorking']['grown']['assetList'][imm]['name'];
             existingAssets[aname]=imm;
         }
  }        // if isMod=0, existassets is empty

   let efields=etable.find('.portfolioAssetNameNew');
   let alist=[] ;

   for (let i1=0;i1<efields.length;i1++) {

      let nshares=false,cost=false,aprice=false,abasis=false,acomment='' ;
      let loanAmount=false,loanRate=false,loanTerm=false,loanTaxDeduct=false,loanRefinance=false,refiEnabled=false;
      let loanOwed=false,loanStart=false,loanPayYearly=false,incomeStart=false,rmdStart=false,isRefi=false,acqCost=false,purchaseCost=false;
      let addVal=false, doRMD=false,growthFrac=false,nowAge=false;
      let oneOffDate=false,oneOffReceiptOrig=false;
      let origPrice=false,origCost=false;

      let aefield=$(efields[i1]);
      let aname=jQuery.trim(aefield.val()).toLowerCase();
      if (aname=='') continue ;
      if (aname=='cash') {          // cash is reserved
         if (quiet!=1) {
           alert('Sorry : `cash` can not be used as an asset name ');
           return false;
         }
         errors.push('Sorry : `cash` can not be used as an asset name ');
         return {'errors':errors};       // immediately fatal

      }
      if (!assetLookup.hasOwnProperty(aname)) {
           if (quiet!=1) {
             alert('Unspecified asset ... '+aname);
             return false;
           }
           errors.push('Unspecified asset ... '+aname);
           return {'errors':errors};       // immediately fatal
      }

      let etr=aefield.closest('tr');
      let aremove=etr.attr('data-remove');
      if (aremove==1) continue ;           // a removed row .. skip!

      let modStatus=0; ;
      if (existingAssets.hasOwnProperty(aname)) modStatus=1;  // if isMod=0, this will always be 0

      let assetType=doAssetLookup(aname,'assetType',2);

      if (assetType==0) {            // lookup shares and basis

        let eshare1=etr.find('[name="portfolioShares"]');
        let nsharesV=portfolioCalcValueMenu_read_check(eshare1,isMod,0);
        let nshares0=nsharesV[0];;

        aprice=getAssetValue(pdateCount,aname,'price',1);

        if (nsharesV[1]!=0) {
            nshares=parseFloat(nshares0);
        } else {
          nshares=portfolioCalcValueMenu_readVal(nshares0,abudget,aprice,aname,1,quiet);
        }

        if (nshares===false  ) {
            errors.push('Error specifying #shares for '+aname+': '+nshares0 );
            nshares=0;
        }
        if  (typeof(nshares)=='string') {
            errors.push(nshares);
            nshares=0;
        }

        let ebasis=etr.find('[name="portfolioSharesBasis"]');
        let abasisV=portfolioCalcValueMenu_read_check(ebasis,isMod,'100%');
        let abasis0=abasisV[0];
        let sayBasis='';
        if (abasisV[1]!=0) {
             if (abasisV[0]=='100%') {
               abasis=parseFloat(aprice)*parseFloat(nshares) ;  // special case
               sayBasis='100%';        // the default
             } else {
               abasis=parseFloat(abasis0);
               sayBasis=abasis.toFixed(0);    // directly sepcified
             }
        } else {             // convert % to $value
           abasis=portfolioCalcValueMenu_readVal(abasis0,aprice*nshares,1.0,aname,0,quiet);
           sayBasis=abasis.toFixed(0);
        }

        if (abasis===false) {
           errors.push('Bad  basis for '+aname+':' +abasis0)    ;
           abasis=0;
        }
        if (typeof(abasis)=='string')  {
             errors.push('Bad basis value for '+aname+' : ' +abasis0+' : ' +abasis);
             abasis=0;
        }
        cost=nshares*aprice;
        purchaseCost=cost;
        acqCost=0;

        if (modStatus==0)  {
           origPrice=aprice ;
           origCost=cost;
        }

        eshare1.val(nshares.toFixed(2));
        ebasis.val(sayBasis);


      } else if (assetType==1  ) {

        let eshare1=etr.find('[name="portfolioShares"]');
        let nsharesV=portfolioCalcValueMenu_read_check(eshare1,isMod,0);
        let nshares0=nsharesV[0];;
        if (nsharesV[1]!=0) {
            nshares=parseFloat(nshares0);
        } else {
          nshares=portfolioCalcValueMenu_readVal(nshares0,abudget,1.0,aname,1,quiet);
        }

        if (nshares===false) {
            errors.push('Bad nshares for '+aname+':' +nshares0) ;
            nshares=0;
        }
        if (typeof(nshares)=='string') {
           errors.push('Non-numeric? '+nshares);
           cost=0;
        } else {
           cost=nshares ;
           eshare1.val(nshares.toFixed(2));
        }
        purchaseCost=cost;
        acqCost=0;

        let eadd=etr.find('[name="portfolioAdditions"]');
        let addValV=portfolioCalcValueMenu_read_check(eadd,isMod,0);
        let addVal0=addValV[0];
        if (addValV[1]!=0) {
            addVal=parseFloat(addVal0);
        } else {
          addVal=portfolioCalcValueMenu_readVal(addVal0,false,1.0,aname+'_addition',false,quiet);
       }

        if (typeof(addVal)=='string') {
           errors.push(addVal);
           addVal=0;
        }


      } else if (assetType==2) {

        let txrate=calcAsset_taxRate(2,1)   ;
        let vv1=1.0-txrate;

        let eshare1=etr.find('[name="portfolioShares"]');
        let nsharesV=portfolioCalcValueMenu_read_check(eshare1,isMod,0);
        let nshares0=nsharesV[0];;
        if (nsharesV[1]!=0) {
            nshares=parseFloat(nshares0);
        } else {
          nshares=portfolioCalcValueMenu_readVal(nshares0,abudget,1.0,aname,1,quiet);
        }

        if (nshares===false) {
           errors.push('Bad nshares for '+aname+':' +nshares0) ;
           nshares=0;
        }
        if (typeof(nshares)=='string') {
            errors.push('String entry ('+aname+'): '+nshares);
            cost=0; nshares=0;
        } else {
           cost=nshares*(1-txrate);
           eshare1.val(nshares.toFixed(2));
        }
        purchaseCost=cost;
        acqCost=0;
        addVal=0;
        let ermd=etr.find('[name="portfolioAdditionsRMD"]');
        let qrmd=ermd.prop('checked');
        if (qrmd===false) {
           doRMD=0;                 // not an RMD

           let eadd=etr.find('[name="portfolioAdditions"]');

           let addValV=portfolioCalcValueMenu_read_check(eadd,isMod,0);
           let addVal0=addValV[0];
           if (addValV[1]!=0) {
                addVal=parseFloat(addVal0);
           } else {
               addVal=portfolioCalcValueMenu_readVal(addVal0,false,1.0,aname+'_addition',false,quiet);
           }

           if (typeof(addVal)=='string') {
              errors.push(addVal);
              addVal=0;
           }
        } else {          // an rmd

           let eadd2=etr.find('[name="portfolioAdditionsRMD_beneficiary"]');
           if (eadd2.prop('checked')) {
              doRMD=2;   // beneficiary
           } else {
              doRMD=1;  // self
           }
           let eadd3=etr.find('[name="portfolioAdditionsRMD_age"]');
           nowAge=jQuery.trim(eadd3.val());
           if (nowAge=='' || !jQuery.isNumeric(nowAge)) {
                 errors.push('Bad RMD age value for  :  '+aname);
                 nowAge=0;
           }  else {
               nowAge=parseFloat(nowAge);
           }
          rmdStart=pdateCount ;               // when rmd distributions begin


         }       // qrmd


      } else if (assetType==3  ) {

         if (modStatus==0)        {      // if modification, can refinance (but nothing else)

              aprice=getAssetValue(pdateCount,aname,'price',1);
            origPrice=aprice ;

            let ecost1=etr.find('[name="portfolioShares"]');  // portfolioShares is not a good name for "upfront costs", but wth
            let costV=portfolioCalcValueMenu_read_check(ecost1,isMod,0);
            let cost0=costV[0];
            if (costV[1]!=0) { 
                cost=parseFloat(cost0);
            } else {
                cost=portfolioCalcValueMenu_readVal(cost0,aprice,1.0,aname,false,quiet);
            }

            if (cost===false){
                errors.push('Bad cost for '+aname+':' +cost0)   ;
               cost=0;
            }
            if (typeof(cost)=='string') {
                  errors.push(cost);
                  cost=0;  // avoid errors below
            } else {
                  ecost1.val(cost.toFixed(0));
            }

            acqCost=cost;
            purchaseCost=0;
            origCost=cost;

            let ebasis=etr.find('[name="portfolioPropertyBasis"]');
            let abasisV=portfolioCalcValueMenu_read_check(ebasis,isMod,'100%');
            let abasis0=abasisV[0];
            if (abasisV[1]!=0) {
               abasis=parseFloat(abasis0);
            } else {
              abasis=portfolioCalcValueMenu_readVal(abasis0,aprice,1.0,aname,0,quiet);
            }

            if (abasis===false) {
              errors.push('Bad basis for '+aname+':' +abasis0) ;
               abasis=0;
            }
            if (typeof(abasis)=='string') {
                errors.push('Bad basis value for '+aname+' : ' +abasis0);
                abasis=0;
            }
            ebasis.val(abasis.toFixed(0));

            let eloanEnable=etr.find('[name="porfolioLoanEnable"]');
            let loanEnabled=eloanEnable.prop('checked');

            loanAmount=0,loanOwed=0,loanStart=false;
            if (loanEnabled) {

              let eloanAmount=etr.find('[name="portfolioLoanAmount"]');

              loanAmount=jQuery.trim(eloanAmount.val());   let loanAmount0=loanAmount ;
              if (loanAmount=='') loanAmount=0;

              loanAmount=portfolioCalcValueMenu_readVal(loanAmount,aprice,1.0,aname,false,quiet);
              if (loanAmount===false) {
                  errors.push('Bad loanAmount for '+aname+':' +loanAmount0) ;
                  loanAmount=0;
              }
              if (typeof(loanAmount)=='string') {      //  error !
                 errors.push(loanAmount);
                 loanAmount=0;
              }
              eloanAmount.val(loanAmount.toFixed(0));       // update input form
              loanTerm=0;loanRate=0;loanTaxDeduct=0;
              if (loanAmount>0) {
                    let eloanTerm=etr.find('[name="portfolioLoanTerm"]');
                    loanTerm=jQuery.trim(eloanTerm.val()); let loanTerm0=loanTerm;
                    if (loanTerm=='') loanTerm='0';
                    loanTerm=portfolioCalcValueMenu_readVal(loanTerm,false,1.0,aname,1,quiet);
                    if (loanTerm===false){
                        errors.push('Bad loanTerm for '+aname+':' +loanTerm0)    ;
                        loanTerm=0;
                    }
                    if (typeof(loanTerm)=='string') {
                       errors.push(loanTerm);
                       loanTerm=0;
                    } else {
                      eloanTerm.val(loanTerm.toFixed(0));
                    }
                    let eloanRate=etr.find('[name="portfolioLoanRate"]');
                    loanRate=jQuery.trim(eloanRate.val());  let loanRate0=loanRate;
                    if (loanRate=='') loanRate='0';
                    loanRate=portfolioCalcValueMenu_readVal(loanRate,100,1.0,aname,1,quiet);
                    if (loanRate===false) {
                       errors.push('Bad loanRate for '+aname+':' +loanRate0)  ;
                       loanRate=0;
                    }
                    if (typeof(loanRate)=='string') {
                        errors.push(loanRate);
                        loanRate=0;
                    } else {
                       eloanRate.val(loanRate.toFixed(2));
                    }
                    let eloanTaxDeduct=etr.find('[name="portfolioLoanTaxDeductInt"]');
                    loanTaxDeduct=(eloanTaxDeduct.prop('checked')) ? 1 : 0 ;
                    if (loanTerm<=0  || loanRate<0 )  {
                      let er1mess='You specified a loan amount for '+aname+' ('+wsurvey.addComma(parseInt(loanAmount))+'), but the term ('+loanTerm0+') or rate ('+loanRate0+') are misspecified' ;
                      if (quiet==0) {
                          alert(er1mess);
                          return false ;
                      } else {
                          errors.push(er1mess);
                       }
                    }    else {              // loanterm ok
                        loanPayYearly=12* montlyLoanAmount(loanAmount,loanTerm,loanRate) ;
                      }

              }      // loanamont > 0

              loanOwed=loanAmount;
              loanStart=pdateCount ;



            }           // loan enabled

         } else {            // modstatus=1, don't change (use entryWorking info) -- but check for refinance

            let eRefi=etr.find('[name="doRefiButton"]');
            refiEnabled=eRefi.attr('data-enabled');

            if (refiEnabled==1)  {   // a refinance  is specified
               let erefi2=etr.find('[name="refinanceOptions"]');

               let eloanRate=erefi2.find('[name="portfolioLoanRate"]');
               loanRate=jQuery.trim(eloanRate.val());
               loanRate=parseFloat(loanRate);

               let eloanTerm=erefi2.find('[name="portfolioLoanTerm"]');
               loanTerm=jQuery.trim(eloanTerm.val());
               loanTerm=parseInt(loanTerm);

               let eTaxd=erefi2.find('[name="portfolioTaxDeduct"]');
               loanTaxDeduct=(eTaxd.prop('checked')) ? 1 : 0 ;

               let eAmt=erefi2.find('[name="portfolioRefiAmount"]');
               loanAmount=parseFloat(jQuery.trim(eAmt.val()));

               loanStart=pdateCount ;

               if (!jQuery.isNumeric(loanAmount) || !jQuery.isNumeric(loanRate)  || !jQuery.isNumeric(loanTerm) || loanTerm<=0  || loanRate<0 ) {
                 let rrmess='You specified a  refinance, but there is a problem with the amount: ('+loanAmount+'), term ('+loanTerm+'), or rate ('+loanRate+')';
                 if (quiet==0) {
                     alert(rrmess);
                     return false ;
                 } else {
                     errors.push(rrmess);
                 }
               }   else {
                   loanPayYearly=12* montlyLoanAmount(loanAmount,loanTerm,loanRate) ;
               }      // ok data



            }   // refiEnabled
         }         // modstatus


    } else if (assetType==4  ) {        // incomeStream  -- can NOT be changed if 'modificatiohn'

        if (modStatus==0) {

           aincome=getAssetValue(pdateCount,aname,'income',1);

           let ecost1=etr.find('[name="portfolioShares"]');  // portfolioShares is not a good name for upfrontCosts .... but wth

           let costV=portfolioCalcValueMenu_read_check(ecost1,isMod,0);
           let cost0=costV[0];
           if (costV[1]!=0) {
               cost=parseFloat(cost0);
           } else {
               cost=portfolioCalcValueMenu_readVal(cost0,aincome,1.0,aname,false,quiet);   // can be % of incomeStream
           }


          if (cost===false) {
              errors.push('Bad cost for '+aname+':' +loanRate0)  ;
              loanRate=0;
          }
           if (typeof(cost)=='string') {
               errors.push(cost);
               cost=0;
           } else {
                ecost1.val(cost.toFixed(0));
           }
        } else {     // don't read anyting (use entryWorking values)
        }
        purchaseCost=0;
        acqCost=cost;
        origCost=cost;


    } else if (assetType==5  ) {                 // annuity  -- can NOT be changed if 'modificatiohn'

          if (modStatus==0)  {  // don't bother reading anything (use info in entryWorking)


            aincome=getAssetValue(pdateCount,aname,'income',false,1);

            let ecost1=etr.find('[name="portfolioShares"]');  // portfolioShares is not a good name for upfrontCosts .... but wth
            let costV=portfolioCalcValueMenu_read_check(ecost1,isMod,0);
            let cost0=costV[0];
            if (costV[1]!=0) {
               cost=parseFloat(cost0);
            } else {
               cost=portfolioCalcValueMenu_readVal(cost0,aincome,1.0,aname,false,quiet);   // can be % of incomeStream
            }

            if (cost===false) {
               errors.push('Bad cost for '+aname+':' +loanRate0) ;
               cost=0;
            }
            if (typeof(cost)=='string') {
               errors.push(cost);
               cost=0;
            } else {
                ecost1.val(cost.toFixed(0));
            }
            incomeStart=pdateCount ;

            if (typeof(cost)=='string')  errors.push(cost);
          } else {            // if modification, use entryWorking
          }
          purchaseCost=0;
          acqCost=cost;

          origCost=cost;

    } else if (assetType==6  ) {        // oneOff  -- will never be a modificatin

        oneOffReceiptOrig=getAssetValue(pdateCount,aname,'receipt',1);

        oneOffDate=pdateCount ;
        purchaseCost=0;
        acqCost=0;

    } else if (assetType==7  ) {        // expanseStream  -- no portfolio settable attributes
        cost=0;

        purchaseCost=0;
        acqCost=cost;
        origCost=cost;

    }       //  assetType

    let ecomment=etr.find('[name="portfolioComment"]');
    acomment=jQuery.trim(ecomment.val());
    acomment=wsurvey.removeAllTags(acomment);
    acomment.replace(/\n/g, ' ');

    let addedDate= (modStatus==0) ? pdateCount : false  ;       // date added 

    let aa={'name':aname,'assetType':assetType,'nShares':nshares,'basis':abasis,
            'origPrice':origPrice,'price':aprice,'cost':cost,'origCost':origCost,
           'addVal':addVal,'doRMD':doRMD,'nowAge':nowAge,
            'loanOwed':loanOwed,'loanStart':loanStart,'loanPayYearly':loanPayYearly,
           'loanAmount':loanAmount,'loanTerm':loanTerm,'loanRate':loanRate,'loanTaxDeduct':loanTaxDeduct,
           'refiEnabled':refiEnabled,
           'incomeStart':incomeStart,'rmdStart':rmdStart,
            'oneOffDate':oneOffDate,'oneOffReceiptOrig':oneOffReceiptOrig,
            'comment':acomment,'addedDate':addedDate
          };
       alist.push(aa);
   }   // i1

   if (errors.length>0) return {'errors':errors};       // immediately fatal
   return alist ;
}

//==================
// read value of input fields.... if isMod check first for data-change (if 0, use data-orig rather than input fields
// [ value, how] : how=0: from input, 1: data-orig, 2=default
function portfolioCalcValueMenu_read_check(euse,icheck,adef)  {

   if (icheck==1) {              // check for 'no change' flag
          let ichange=euse.attr('data-change');
          if (typeof(ichange)==='undefined' || ichange===null) ichange=1;     // if no data-change attribute, read the input field
          if (ichange==0) {
             let v1=euse.attr('data-orig');
             if (v1===null) return [adef,2];
             return [v1,1];
          }       // if change, read from input field
   }              // if no check for change, read from input field
   v1=jQuery.trim(euse.val());

   if (typeof(v1)=='undefined' || v1=='') return [adef,2];
   return [v1,0];
}
