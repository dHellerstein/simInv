// work with simInv scenarios -- future state-of-the-world
function  showScenarioTable(athis) {

  let bmess=''

  bmess+='<button title="Tips" onclick="displayHelpMessage(this,0,1)" data-div="#showScenarioHelp1">?</button> ';
  bmess+='&#127760; There are '+simInvDsets['scenarioSpecs']['nScenario']+' <u>scenarios</u> available. ';
  if (simInvParams['scenarioUse']!='') bmess+=' <b>'+simInvParams['scenarioUse']+'</b> is being used. ';
  bmess+='<br>You can: ';
  bmess+='<ul class="pointerMenuBlack2">';
  bmess+='<li><input type="button" class="csettingsButton2" value="Create ..." onClick="specifyScenarioTable(this)" data-name="" data-date=""> a new &#127760; <u>scenario</u>; or add an entry to an existing one';
  bmess+='<li><input type="button"  class="csettingsButton2" value="Select, review, or modify  ..." onClick="reviewScenario(this)">  an existing &#127760; <u>scenario</u>   ';
  bmess+='<li><input type="button"  class="csettingsButton2" value="Import / export ..." onClick="importScenario(this)">    &#127760; <u>scenario</u>   ';
  bmess+='</ul>';

   wsurvey.wsShow.show('#mainDiv','show');
   wsurvey.wsShow.hide('#mainDiv2');
   wsurvey.wsShow.show('#mainDiv3','show');
   $('#mainDiv3').html(bmess);

}

//===============
// import or export a scenario
function importScenario(athis) {
  let bmess='';
  bmess+=' <button title="Return to scenario menu"  onClick="showScenarioTable(this)">&#8617;&#65039;</button>' ;

  bmess+='<em>Import</em> or <em>export</em> a &#127760;  <u>scenario</u>  (using JSON-like files)<br>';

  bmess+='<div style="margin:1em 5px 5px 5px;background-color:#efeffa"> Export an existing &#127760;  <u>scenario</u></div> ';
  bmess+='<ul class="linearMenu22Pct">';
  for (let ascenario in  simInvDsets['scenarioSpecs']['entries']) {
     let sbutton;
     sbutton='<button class="cdoButtonRegular"  title="Export this scenario "  ';
     sbutton+='  onClick="importScenario1(this)" data-name="'+ascenario+'">'+ascenario+'</button>';
     bmess+='<li>'+sbutton;
  }
  bmess+='</ul>';

  let amess='';
   amess+='<div id="importScenario1b" style="display:none">';
    amess+='<table width="95%" cellpadding="5">';
    amess+='<td width="50%"> <ul  style="list-style-type: lower-alpha;">';

   amess+='<li> <button   class="csettingsButton2" onClick="simInv_div_Mark(this)" data-div="importScenario_results_string" data-gotit="importScenario_copied" >  ';
    amess+=' Copy the scenario ';
    amess+='</button> (to your clipboard)';

    amess+=' <span id="importScenario_copied"  ';
    amess+=   ' title="scenario information can now be pasted!" style="color:green;display:none">Copied!';
    amess+='</span>  ';
    amess+='<li>  Cut &amp; paste it to a <u>text</u> file on your computer';
    amess+='<br><em>For example:</em> create/paste/save <tt>scenarioSiminv.txt</tt> with windows Notepad editor';
    amess+='</ul>';
    amess+=' </td>';
    amess+='<td width="50%"> ';
    amess+='You can <button  class="csettingsButton2" onclick="importScenario_preview(1)"  title="View this javaScript object in a new window">Preview</button> the';
    amess+=' <input type="button" value="" id="importScenario_preview_name">  scenario multipliers?<br>';

    amess+='<div title="The scenario data for user: '+userName+'" id="importScenario_results_string" style="height:3em;width:20em;overflow:auto;background-color:gray;padding:1em">';

    amess+='</div>';

    amess+='</td>';
    amess+='</tr></table>';
    amess+='You can <button>import</button> this data at a later date -- don\'t forget where you saved your  text file &#9786;';
    amess+='</div>' ;      // idoexportImport_export0

    bmess+= amess;

// ::::::::::::::::::::: import ::::::
  bmess+='<hr>';
  bmess+='<div style="margin:1em 5px 5px 5px;background-color:#efeffa"> Import a &#127760;     <u>scenario</u></div> ';

  bmess+='<div style="font-family:sans-serif;margin:3px 4em;padding:3px 1em" >';
  bmess+='Due to javaScript security:  exporting  &amp; importing  <u>scenario</u> data requires user actions. You will need to';
  bmess+=' copy data to (or from) a text file on your computer. It\'s not that hard!'
  bmess+='</div>';
  bmess+='<table width="95%">';
  bmess+='<tr><td width="20%"><em>Step 1:</em> Copy (to your browser clipboard)  simInv  <u>scenario</u> data  (typically from an export file you saved earlier) and  ...</td>';


   bmess+='<td valign="top" width="6%"><em>Step 2:</em>';
   bmess+='<span style="font-size:66%">Paste it here &rarr; </span>';
   bmess+='</td>';
   bmess+='<td width="29%">';
   bmess+='<textarea   style="border:4px dotted purple" title="Paste the simInv scenario data here!" id="scenario_import_textarea" nowrap rows="1" cols="40"></textarea>';
   bmess+='<br> <input type="button" value="reset" onClick="scenario_import_clear(this)">  ';
   bmess+' </span>';

  bmess+='<td width="35%"><button  class="csettingsButton2" onClick="scenario_import_validate(this)"><em>Step 3:</em> Validate</button> the  <u>scenario</u> data';
  bmess+='<div id="scenario_import_1" style="border-top:1px dashed gray;display:none"></div>';
  bmess+='</div> ';
  bmess+='</td>';

  bmess+='</tr>';
  bmess+='</table>';
  bmess+='<div id="scenario_import_1b" style="padding:2px;display:none"></div>';


// :::; write to screen
  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv2');
  wsurvey.wsShow.show('#mainDiv3','show');
  $('#mainDiv3').html(bmess);
}
//=========
// chose scenario for export
function importScenario1(athis) {
   let ethis=wsurvey.argJquery(athis);
   let ascenario=ethis.attr('data-name');
   if (!simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(ascenario)) { // should never happen
      alert('No such scenario: '+ascenario);
      return 0;
   }
   let ado=jQuery.trim(JSON.stringify(simInvDsets['scenarioSpecs']['entries'][ascenario]));

   $('#importScenario_results_string').text(ado);
   $('#importScenario_preview_name').val(ascenario);
   $('#importScenario1b').show();
}
//===========
// preview scenario to be exported
function importScenario_preview(ido) {
  if (arguments.length<1) ido=1;
  let awhere='importScenario_results_string';
   if (ido==2) awhere='scenario_import_textarea';
   let edo=$('#'+awhere);
   let astuff;
   if (ido==1) {
      astuff=jQuery.trim(edo.text());
   } else {
      astuff=jQuery.trim(edo.val());
   }
   let vv=JSON.parse(astuff);
   let ascenario='';
  if (ido==1) ascenario= $('#importScenario_preview_name').val();

   if (ido==1) {
     showDebug(vv,'Previewing. simInv scenario (for export): '+ascenario,11);
   } else {
     showDebug(vv,'Previewing. imported simInvscenario: '+ascenario,11);
   }

}
//=========
function scenario_import_clear(ifoo) {
   $('#scenario_import_textarea').val('');
   $('#scenario_import_1').hide();
   $('#scenario_import_check').hide();
   $('#scenario_import_2').hide();
   $('#scenario_restore_preview').hide();

}

//====
// validate an imported text block (for proper json structure)
function scenario_import_validate(athis) {
   let e1=$('#scenario_import_textarea');
   let v1=e1.val();
   let vv;

  try {
      vv=JSON.parse(v1);
  } catch(err) {
    let bmess='Problem processing:\n  '+err ;
    alert(bmess) ;
    return 1;
  }
  let sayDates=[];
  for (let adate in vv) {
     if (!vv[adate].hasOwnProperty('multipliers')) {
        bmess='This is not a simInv scenario export file ' ;
        bmess+='\nWould you like to view it (using a JSON viewer)? ';
        let q=confirm(bmess);
        if (!q) return 1;
        showDebug(vv,'Viewing JSON data');
       return 1;
     }
     sayDates.push(vv[adate]['sayDate']);
  }

  let cmess='<input class="csettingsButton2"  type="button" value="Preview" onClick="importscenario_preview(2)"> the '+sayDates.length+' entries in this imported data';
  $('#scenario_import_1').html(cmess).show();

  let bmess='';
  bmess='<em>Step 4:</em> ';
  bmess+='<ul class="boxList"> ';
  bmess+='<li>The name for this &#127760; scenario: <input type="text" value="" id="import_scenario_useName" size="14"> ... and then ... ';
  bmess+='<li><button class="cdoButton" onclick="scenario_import_go(0)" title="add this scenario">Save it!</button>   ';
  bmess+='</ul> ';

  $('#scenario_import_1b').html(bmess).show();

  return 1;

}

//==============
// save imported scenario data ..
function scenario_import_go(athis) {

   let e1=$('#scenario_import_textarea');
   let v1=e1.val();
   let vv;
  try {
      vv=JSON.parse(v1);
  } catch(err) {
    let bmess='Problem processing:\n  '+err ;
    alert(bmess) ;
    return 1;
  }

  let ename=$('#import_scenario_useName');
  let aname=jQuery.trim(ename.val());
  aname=fixString(aname,1).toLowerCase();

  if (aname=='') {
     alert('You did not specify  a name for this scenario ');
     return 0;
  }

  if (jQuery.isNumeric(aname)) {
     alert('You can not use a number as the name of a scenario ');
     return 0;
  }

  if (simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(aname)) {
     let qq=confirm('A `'+aname+'` scenario already exists. Do you want to overwrite it? ');
     if (!qq) return 0;
  }

  simInvDsets['scenarioSpecs']['entries'][aname]=vv ;
  
  let nowTime=wsurvey.get_currentTime(0);
  let vv1={'time':nowTime,'data':simInvDsets['scenarioSpecs']['entries']};

  simInvGlobals['temp']['autoLogonDetails']={'action':'scenarioImport','scenario':aname} ;
  saveSimInvData_scenario(userName,vv1,'Saving imported  scenario ('+aname+') ');
   simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

}

//=======================
// list info on currentlyi specified statesOf the world
function reviewScenario(athis) {
   bmess='';
   bmess+=' <button title="Return to scenario menu"  onClick="showScenarioTable(this)">&#8617;&#65039;</button>Review &amp; modify &#127760; <u>scenario</u>  ';

   if (simInvDsets['scenarioSpecs']['nscenario']==0) {
     bmess='There are no  <u>scenario</u> specified ';
     wsurvey.wsShow.show('#mainDiv','show');
     wsurvey.wsShow.hide('#mainDiv2');
     wsurvey.wsShow.show('#mainDiv3','show');
     $('#mainDiv3').html(bmess);
    return 1;
   }

   bmess+='<table  rules="rows">';
   bmess+='<tr><th>action</th><th>Name</th><th>Entries</th></tr>';

   bmess+='<tr>';
   if (simInvParams['scenarioUse']=='') {
        bmess+='<th><button class="cdoButton"  class="cdoButton"    title="Do NOT use a scenario when determining asset attributes"  ';
        bmess+='  onClick="selectScenario(this)" data-name="">None </button></th>';
   } else {
        bmess+='<th><button class="cdoButtonRegular"  class="cdoButtonRegular"  title="Do NOT use a scenario when determining asset attributes"  ';
        bmess+='  onClick="selectScenario(this)" data-name="">None </button></th>';
   }
   bmess+='<th>&#127760; None</th>';
   bmess+='<td><div style="margin:3px 3em"> Do <u>not</u> use a scenario (when calculating asset attributes)</div></td>';
   bmess+='</tr>';

  for (let ascenario in  simInvDsets['scenarioSpecs']['entries']) {
     let sbutton;
     if (ascenario!==simInvParams['scenarioUse']) {
         sbutton='<button class="cdoButtonRegular"  title="Use this  scenario "  ';
        sbutton+='  onClick="selectScenario(this)" data-name="'+ascenario+'">Select!</button>';
     } else {
         sbutton='<button class="cdoButton"  title="Currently selected scenario "  ';
          sbutton+='  onClick="selectScenario(this)" data-name="'+ascenario+'">Current</button>';
     }

    let vubutton='<input type="button" value="View" onClick="scenarioTable_viewAll(this)" data-name="'+ascenario+'">';
    let delbutton='<input type="button" value="Del" onClick="scenarioTable_delete(this)" data-name="'+ascenario+'" data-date="*" >';
    bmess+='<tr><th>'+sbutton+vubutton+' '+delbutton+'</th><th> '+ascenario+'</th>';
    bmess+='<td><ul class="tighterMenu" style="margin-left:2em">';
    for (let ij=0;ij<simInvDsets['scenarioList'][ascenario].length;ij++) {    // use scenarioList since it is sorted ascending (this ensurses display it in asencing date
      adate=simInvDsets['scenarioList'][ascenario][ij];
      let vubutton2='<input title="view, and modify, this date from this scenario" type="button" value="&#128393; &#128065;" onClick="specifyScenarioTable(this)" data-name="'+ascenario+'" data-date="'+adate+'"> ';
      let delbutton2='<input title="delete this date from this scenario" type="button" value="&#9003;" onClick="scenarioTable_delete(this)" data-name="'+ascenario+'" data-date="'+adate+'" > ';
      let datesay='<span title="'+adate+'">'+simInvDsets['scenarioSpecs']['entries'][ascenario][adate]['sayDate']+'</span>';
      let desc=simInvDsets['scenarioSpecs']['entries'][ascenario][adate]['desc'];
      bmess+='<li><tt>'+vubutton2+delbutton2+datesay+'</tt> : <em>'+desc+'</em>';
    }
    bmess+='</ul>';
    bmess+='</td></tr>';
  }

  bmess+='</table>';

  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv2');
  wsurvey.wsShow.show('#mainDiv3','show');
  $('#mainDiv3').html(bmess);
}
//===================
// use this scenario
function selectScenario(athis) {
   let ethis=wsurvey.argJquery(athis) ;
   let fname=ethis.attr('data-name');
   simInvParams['scenarioUse']=fname;                // set a global
   simInvSummaryResults['recentDisplay']=false ;       // force recreating portoflioValues table...
   scenarioUseSave(fname);
}

//-=============================
// delete a scenario table, or an entry in a scenario table
function  scenarioTable_delete(athis) {
   let ethis=wsurvey.argJquery(athis) ;
   let fname=ethis.attr('data-name');
   let fdate=ethis.attr('data-date');

  if (fdate=='*') {  // dlete entire cenario (all dates)
    let qq=confirm('Are you sure you want to delete the `'+fname+'` scenario?');
    if (!qq) return 0;

   let arf=JSON.parse(JSON.stringify(simInvDsets['scenarioSpecs']['entries']));
   if (!arf.hasOwnProperty(fname)) {
       alert('Unable to find `'+fname+'` in scenario dataset '); // should never happen
       return 0;
   }
   delete arf[fname];

    let nowTime=wsurvey.get_currentTime(0);
    let vv1={'time':nowTime,'data':arf};

   simInvGlobals['temp']['autoLogonDetails']={'action':'scenarioRemove','scenario':fname} ;
   saveSimInvData_scenario(userName,vv1,'<u>'+fname+'</u> deleted from scenario ');
   simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie
   
   return 0
}
// if here, delete a date from an scenario (not the entire fitures
   let arf=JSON.parse(JSON.stringify(simInvDsets['scenarioSpecs']['entries']));
   if (!arf.hasOwnProperty(fname)) {
       alert('Unable to find `'+fname+' in scenario dataset  ... '); // should never happen
       return 0;
   }
   if (!arf[fname].hasOwnProperty(fdate)) {
       alert('Unable to find `'+fname+'` / `'+fdate+'` in scenario dataset  ... '); // should never happen
       return 0;
   }
   
   let oofx=setEntryDate(fdate);
    let qq=confirm('Are you sure you want to delete the '+oofx.sayDate+' entry from the `'+fname+'`  scenario?');
   if (!qq) return 0;

   delete arf[fname][fdate];
    let nowTime=wsurvey.get_currentTime(0);
    let vv1={'time':nowTime,'data':arf};

   simInvGlobals['temp']['autoLogonDetails']={'action':'scenarioRemoveDate','scenario':[fname,fdate]} ;
   saveSimInvData_scenario(userName,vv1,'<u>'+fname+' / '+fdate+'</u> deleted from scenario ');
   simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie
   


}


//================
// quick view of a scenario
function scenarioTable_viewAll(athis) {

  let assetAttributes=[]
  assetAttributes[0]={'price':'stock price','dividend':'yearly dividend'};
  assetAttributes[1]={'interest':'interest rate'};
  assetAttributes[2]={'interest':'tax deferred interest rate'};
  assetAttributes[3]={'price':'sale price of property','rent':'yearly net rent'};
  assetAttributes[4]={'income':' yearly income'};
  assetAttributes[5]={'income':'annuity starting value','growth':'annuity growth as fraction of CPI'};
  assetAttributes[6]={'receipt':' receipt (or cost) of oneOff'};
  assetAttributes[7]={'cost':'yearly expense'};

   let ethis=wsurvey.argJquery(athis);
   let usename=ethis.attr('data-name');
   if (!simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(usename)) {  // should never happen
      alert('No scenario entry: '+usename);
      return 0;
   }
   let nscenario=0,bmess='';
   for (let adate in simInvDsets['scenarioSpecs']['entries'][usename]) nscenario++;

   bmess+='<tt>'+nscenario+'</tt>   dates specified for &#127760; <em>scenario</em>  <u>'+usename+'</u>';

//   for (let adate in simInvDsets['scenarioSpecs']['entries'][usename]) {

    bmess+='<table cellpadding="7" rules="rows">';
    for (let ij=0;ij<simInvDsets['scenarioList'][usename].length;ij++) {    // dates specified for usename scenario
      let adate= simInvDsets['scenarioList'][usename][ij];
      let dd=simInvDsets['scenarioSpecs']['entries'][usename][adate];
      adesc=dd['desc'],saydate=dd['sayDate'];
      bmess+='<tr bgcolor="lime"> <th>'+saydate+'</th><td colspan="3"><em>'+adesc+'</em></td></tr>';

      let inf1=(!simInvDsets['scenarioSpecs']['entries'][usename][adate].hasOwnProperty('inflation')) ? false : simInvDsets['scenarioSpecs']['entries'][usename][adate]['inflation'] ;
      
      if (inf1===false) {
        bmess+='<tr><td>...</td><td><em>Inflation</em><td><span title="no inflation spec">...</td></tr>';
      }  else {
        bmess+='<tr><td>...</td><td><em>Inflation</em><td><span title="yearly inflation">'+inf1.toFixed(3)+'</td></tr>';
      }

      for (let zasset in dd['multipliers']) {
        bmess+='<tr><td>...</td>';
        let dd2=dd['multipliers'][zasset];
        let sayName=dd2['sayname'];
        let atype=dd2['type'];
        let aicon=getAssetType(atype,'icon');

        bmess+='<td>'+aicon+' <u>'+sayName+'</u> </td>';
        for (let anatt in  assetAttributes[atype]) {
            let tval=dd2[anatt];
            let descName=assetAttributes[atype][anatt];
           bmess+='<td><span style="border-bottom:1px dotted blue" title="'+descName+'"> '+anatt+' </span> = <tt>'+tval+'</tt></td>';
        }
// attributes here ...
       bmess+='</tr>';

      }
   }
   bmess+='</table>';
   displayStatusMessage(bmess);
   toggleStatusMessage(0,3);


}

//-===============
// display menu to specify a scenario entry -- perhaps prefilling values (if a modify)
function  specifyScenarioTable(athis) {
   let ethis=wsurvey.argJquery(athis);
   let usename=ethis.attr('data-name');
   let usedate=ethis.attr('data-date');

   let amess='';

   if (usename!='' &&  usedate!=='') {
      amess+=' <button title="Return to review  menu"  onClick="reviewScenario(this)">&#8617;&#65039;</button>  ';
   } else {
      amess+=' <button title="Return to scenario menu"  onClick="showScenarioTable(this)">&#8617;&#65039;</button>  ';
   }

   amess+=' <button title="Tips" onClick="displayHelpMessage(this,0,1)" data-div="#showScenarioHelp1">&#10068;</button>   ';
   if (usename!='' &&  usedate!=='') {
      amess+=' <button class="csaveButton" data-modify="1" title="Save this modified scenario" onClick="scenarioTableSave(this)">Modify this &#127760; scenario</button>   ';
   } else {
     amess+=' <button class="csaveButton"  data-modify="0" title="Save this scenario"  onClick="scenarioTableSave(this)">Save this &#127760; scenario</button>   ';
   }
   amess+='<ul class="boxList2">'

   if (usename!='' &&  usedate!=='') {          // a modify
      amess+='<li> Scenario <input type="text" value="'+usename+'" id="scenario_name"  style="background-color:#eaeaea"  readonly  size="12"> ';
   } else {
      amess+='<li>Specify a name for this scenario:  <input type="text"  ';
      amess+='  title="name for this scenario.\n Spaces and some odd characters will be removed.\n Shorter names are better!"  ';
      amess+=' value="" id="scenario_name" size="12"> ';
      amess+=' ... or select an existing scenario: <select title="Modify an existing scenario" name="existingScenario" size="1">  ';
      amess+='<option onClick="specifyScenarioTable_chose(this)" value="new">New ...</option>';
      for (let ascen in  simInvDsets['scenarioList'])  {
        let ll= simInvDsets['scenarioList'][ascen].length-1
        let adate=simInvDsets['scenarioList'][ascen][ll] ;
         amess+='<option onClick="specifyScenarioTable_chose(this)"  data-date="'+adate+'" value="'+ascen+'">'+ascen+'</option>';
      }
      amess+='</select>';
   }
 
   let adesc='';
   if (simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(usename) && simInvDsets['scenarioSpecs']['entries'][usename].hasOwnProperty(usedate)) {
       adesc=simInvDsets['scenarioSpecs']['entries'][usename][usedate]['desc'];
   }
   amess+='<li>Specify a short description: <input type="text" value="'+adesc+'" id="scenario_desc" size="60"> ';

  if (usedate==='') {
    amess+='<li>Specify a date this occurs ... ';
  } else {
    amess+='<li>Modifying entry on this date ... ';
  }

  amess+='  <span name="scenarioDateSetter" >    '
  let minDate=wsurvey.validateDate(simInvGlobals['theMinYear'] ,1,1).value;
  let maxDate=wsurvey.validateDate(simInvGlobals['theMaxYear'],12,31).value;

   let y1,m1,d1,ismodify;
   if (usedate!='') {              // modifying an exisint entry
     let oof3=setEntryDate(usedate) ;
     if (oof3===false) {
       alert('Problem with date ('+usedate+') in specifyScenarioTable ');
       return 0 ;
     }
     y1=oof3.year;
     m1=oof3.month;
     d1=oof3.day;
     ismodify=1;
     ronly=0;    // 3 jan 2024 ... allow changes (as a wzy to copy an entry)
   }  else {          // use current (or recently specified) date
      let oof1=$(document).data('lastEntryDate');         // and set some defualt values for year/month/day
      y1=parseInt(oof1['year']);
      m1=parseInt(oof1['month']);
      d1=parseInt(oof1['day']);
      ronly=0;
      ismodify=0;
   }  // usedate==''

   let dopts={'minDate':minDate,'maxDate':maxDate,'month3':2,
                 'callback':'scenarioTable_date',
                 'readonly':ronly,
                 'attribs':{'scenario':1,'modify':ismodify}
               };

   let dstring=wsurvey.dateBox_make(y1,m1,d1,dopts);

   amess+=dstring;
   amess+='</span>';

   if (usedate!=='') {
      amess+='<span id="scenarioDate_changeNote" style="border:1px solid yellow;padding:3px;margin:1px 3px 3px 1em;display:none">';
      amess+='Caution: you changed the date! A new entry will be created (or an old one overwritten)';
      amess+='</span>';
   }

   amess+='<li>Inflation on this date. Leave blank for default <input type="number" value="" id="scenarioInflation" >';
   amess+=' <em>Example: 1.05=5%</em>';
   amess+='&nbsp;&nbsp;<button   class="csettingsButton2" title="Find inflation for this date" onClick="specifyScenarioTable_inflation(this)" >Lookup ...</button>';
   amess+='<span style="font-size:80%;border:1px solid yellow;display:none" id="scenarioInflationNote"></span>';
   amess+='</ul>';
   

   amess+=' <button title="Notes" onClick="$(\'#scenarioTable_notes\').toggle()" data-div="#showScenarioHelp1">&#119137;</button>   ';
   amess+='<em>and specify the multipliers </em>... ';

  amess+='<div style="margin:5px 2em;display:none;background-color:#cccfdd;" id="scenarioTable_notes"> For each attribute of an asset (or a generic type of asset), specify a <em>multiplier</em>';
  amess+='<br><em>Multipliers</em> are applied to  the <em>values of asset attributes</em> (such as price, or interest). The  <em>values of asset attributes</em> are calculated value using its asset history. ';


  amess+='<ul class="tightMenu">';
  amess+='<li> <tt>1.0</tt>: do not change  ';
  amess+='<li> less than 1.0 : reduce the value. For example: <tt>0.8</tt> means <tt>80%</tt> of the calculated value ';
  amess+='<li> greater than 1.0 : increase  the value. For example: <tt>1.35</tt> means <tt>35%</tt>  greater than the calculated value ';
  amess+='</ul>';
  amess+='</div>';
  amess+='<table id="scenario_specTable"  cellpadding="5" border="1" xrules="rows">';

  let aicon=getAssetType(0,'icon');
  let arow=scenarioTable_makeRow(0,0,'<em>All stocks</em> &hellip;',0,usename,usedate)
  amess+=arow;

   arow=scenarioTable_makeRow(1,1,'<em>All bonds</em> &hellip;',0,usename,usedate)
  amess+=arow;

   arow=scenarioTable_makeRow(2,2,'<em>All tax-deferred bonds</em> &hellip;',0,usename,usedate)
  amess+=arow;

   arow=scenarioTable_makeRow(3,3,'<em>All properties</em> &hellip;',0,usename,usedate)
  amess+=arow;

   arow=scenarioTable_makeRow(4,4,'<em>All incomes</em> &hellip;',0,usename,usedate)
  amess+=arow;

  arow=scenarioTable_makeRow(5,5,'<em>All annuities</em> &hellip;',0,usename,usedate)
  amess+=arow;

  arow=scenarioTable_makeRow(6,6,'<em>All oneOffs</em> &hellip;',0,usename,usedate)
  amess+=arow;

  arow=scenarioTable_makeRow(7,7,'<em>All expenses</em> &hellip;',0,usename,usedate)
  amess+=arow;

  amess+='<tr xstyle="line-height:13px" bgcolor="#dfdedf"><td colspan="3"> ';
  amess+='<div> you can assign multipliers to ';
  amess+='<button class="cdoButtonRegular" display"="" title="Choose which assets to display" onclick="scenarioTable_pick(this)">&#9935; assets you pick </button>';
  amess+=' (these are used instead of the generic ones specified above)';
  amess+='</div>';
  amess+='</td></tr>'  ;

// any preexisting?
   if (usename!='' &&  usedate!=='') {
      for (let zasset in simInvDsets['scenarioSpecs']['entries'][usename][usedate]['multipliers'])  {
          if (!jQuery.isNumeric(zasset)) {
              let ztype=simInvDsets['scenarioSpecs']['entries'][usename][usedate]['multipliers'][zasset]['type'];
              let zsay=simInvDsets['scenarioSpecs']['entries'][usename][usedate]['multipliers'][zasset]['sayname'];
              arow=scenarioTable_makeRow(zasset,ztype,zsay,1,usename,usedate)
              amess+=arow;
          }
      }            // add custom rows
   }      // modify

   amess+='</table>';


   wsurvey.wsShow.show('#mainDiv','show');
   wsurvey.wsShow.hide('#mainDiv2');
   wsurvey.wsShow.show('#mainDiv3','show');
   $('#mainDiv3').html(amess);


}


//=================
// calculate inflation value for selected data
function specifyScenarioTable_inflation(athis) {
     let lastDateGot;
    for (let jj=0;jj<simInvGlobals['cpiuSeriesUse'].length;jj++) {
        if (simInvGlobals['cpiuSeriesUse'][jj][5]==0) lastDateGot=simInvGlobals['cpiuSeriesUse'][jj][0];
    }

   let csLen=simInvGlobals['cpiuSeriesUse'].length-1;

   let oof=$('[name="scenarioDateSetter"]');
   let dstuff=wsurvey.dateBox_read(oof,1);
   if (dstuff===false) {
      alert('Please enter a properly specified date ');
      return 0;
   }
   let atime=dstuff['value'];

   ayear=dstuff['year'];
   amonth=dstuff['month'];
   aday=dstuff['day'];
   let d1=setEntryDate(ayear,amonth,aday);
   let dcount=d1.dayCount;

   if (dcount<lastDateGot) {
         let goodate=setEntryDate(lastDateGot).sayDate;
         $('#scenarioInflationNote').html('Inflation not set (date is before '+goodate+')' ).show();
          $('#scenarioInflation').val('');
        return 1;
   }
   let infUse=calcInflation(dcount,dcount,3);
   $('#scenarioInflation').val(infUse.toFixed(3) );
   $('#scenarioInflationNote').html('Inflation calculated for '+d1.sayDate ).show();


  return 1;
}

//===========
// seletc an existing scneario name (in create)
function specifyScenarioTable_chose(athis) {
   let ethis=wsurvey.argJquery(athis);
   let ascen=ethis.val();
   if (ascen=='new') {
     $('#scenario_name').val('');
     return 1;
   }

   let adate=ethis.attr('data-date');

   let oofD=setEntryDate(adate);
   let eul=ethis.closest('#mainDiv3');
   let edate=eul.find('[name="dateBoxOuter"]');
   let eyear=edate.find('[name="dateBoxYear"]');
   eyear.val(oofD.year);
   let emonth=edate.find('[name="dateBoxMonth"]');
   emonth.val(oofD.month3);
   let eday=edate.find('[name="dateBoxDay"]');
   eday.val(oofD.day);


   $('#scenario_name').val(ascen);

}


// ------- call back after date set   -- currently does nothing
function scenarioTable_date(ediv,astuff ) {

  let ismod=ediv.attr('data-modify');    // will equal 'today report'
  if (ismod==0) return 0 ; // do nothing
  $('#scenarioDate_changeNote').show();
 }


//==================
// select/deslect asset columns to display
function scenarioTable_pick(athis) {

  let qvis=showStatusMessage(false);
  if (qvis) {
     hideStatusMessage(30);
     return 0;
  }

  let doAssets={};
  for (anasset in assetLookup) {
      if (assetLookup[anasset]['nHistory']==0) continue ;

      let atype=assetLookup[anasset]['assetType'];
      doAssets[anasset]=atype;
  }

  let emenu=$('#assetTable_choseMenu');
  if (emenu.is(':visible')) {
      emenu.hide();
      return 1;
  }

   let bmess='';
  // bmess+='<input type="button" value="x" title="Close this menu" onClick="hideStatusMessage(1)" >  ';
   bmess+='<input type="button" value="&#8704;" title="Select all assets"     onClick="scenarioTable_pick2(0,1)" >  ';
   bmess+='<input type="button" value="&#10672;" title="De-Select all assets" onClick="scenarioTable_pick2(0,0)" >   ';

   bmess+='<em>Select assets (to include in this scenario),</em> and ';
    bmess+=' then   <button  class="calcButton"  onClick="scenarioTable_pick2(this)">specify their multipliers</button> ';
    bmess+='<ul id="iscenarioAssets_pick" class="linearMenu16Pct">';
   for (aname in doAssets) {
     let aicon=getAssetType(aname,'icon');
     bmess+='<li><label title="Specify this asset`s multiplier" > ';
     bmess+='<input type="checkbox"    name="chooseThis" data-name="'+aname+'"  data-type="'+doAssets[aname]+'">'+aicon+' '+aname+'</label>';
  }
  bmess+='</ul>';  // 1 jan 2024 .. firefox doesn't seem to support this


  displayStatusMessage(bmess);
  toggleStatusMessage(0,0);
  showStatusMessage(1);

}

//==========
// add chosen asset to scenario specs table
function scenarioTable_pick2(athis,ido) {
  if (arguments.length<2) ido=false ;

   let showThese={};
   let e1=$('#iscenarioAssets_pick');
   let e2=e1.find('[name="chooseThis" ]');
   let nshow=0;
   for (let ie=0;ie<e2.length;ie++) {
       let ae=$(e2[ie]);
       if (ido===false) {  // find the checked
         if (ae.prop('checked')) {
           let aname=ae.attr('data-name');
           showThese[aname]=ae.attr('data-type') ;
           nshow++;
         }

       } else {  // select or deselect all checkboxes

          if (ido==1) {
             ae.prop('checked',true);
          } else {
            ae.prop('checked',false);
          }
       }
   }

   if (ido!==false) return 0;

   if (nshow==0) return 0 ;  // none chosen
// if here, assets have been chosen ... so add their rows

  let etable=$('#scenario_specTable');
  for (basset in showThese) {
     let atype=showThese[basset];
     let arow=scenarioTable_makeRow(basset,atype,false,1,'','')
     etable.append(arow);
  }
  hideStatusMessage(300);
  return 0;
}

//==========
// create a row for the scenarioAsset multipliers table
function scenarioTable_makeRow(anasset,atype,asay,addRemove,usename,usedate) {
  if (arguments.length<3 || asay===false) asay=anasset;
  if (arguments.length<4) addRemove=false;


  let assetAttributes=[]
  assetAttributes[0]={'price':'stock price','dividend':'yearly dividend'};
  assetAttributes[1]={'interest':'interest rate'};
  assetAttributes[2]={'interest':'tax deferred interest rate'};
  assetAttributes[3]={'price':'sale price of property','rent':'yearly net rent'};
  assetAttributes[4]={'income':' yearly income'};
  assetAttributes[5]={'income':'annuity starting value','growth':'annuity growth as fraction of CPI'};
  assetAttributes[6]={'receipt':' receipt (or cost) of oneOff'};
  assetAttributes[7]={'cost':'yearly expense'};

    let  aicon=getAssetType(atype,'icon');

    let  amess='<tr name="scenarioSpecsRow"><td>';
    if (addRemove==1) amess+='<input type="button" value="&#9003;" title="remove this row" onClick="scenarioTable_removeRow(this)"> ';
    amess+='<input type="hidden" name="dainfo"  data-name="'+anasset+'" data-sayname="'+asay+'"  data-type="'+atype+'">' ;
    amess+= aicon+' <em>'+asay+'</em></td>';
    for (let avar in assetAttributes[atype]) {
      amess+='<td>  ';
      let useval='1.0';
      if (usename!='' && usedate!='') {   // perhaps exsiting value to use?
         useval='1.00';
         if (simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(usename) && simInvDsets['scenarioSpecs']['entries'][usename].hasOwnProperty(usedate)) {
             useval='1.000';
             if (simInvDsets['scenarioSpecs']['entries'][usename][usedate]['multipliers'][anasset].hasOwnProperty(avar)) {
               aval=simInvDsets['scenarioSpecs']['entries'][usename][usedate]['multipliers'][anasset][avar];
               useval=parseFloat(aval).toFixed(2);
             }
         }
      }

      amess+=' <input class="scenarioInput"  style="padding-left:3px;color:darkblue;width:5em"  ';
      amess+='  value="'+useval+'" type="number" min="0.0"  step="0.1"   size="4" data-name="'+avar+'" >';
      amess+=assetAttributes[atype][avar]+'</td>';
    }
    amess+='</tr>';
    return amess;
}

//==========
// remove a "single assset" row
function scenarioTable_removeRow(athis) {
   let ethis=wsurvey.argJquery(athis) ;
   let erow=ethis.closest('[name="scenarioSpecsRow"]');
   erow.remove();
}

//==================
// save this scenario
function  scenarioTableSave(athis) {

   let ethis=wsurvey.argJquery(athis) ;
   let domodify=ethis.attr('data-modify');

   let ename=$('#scenario_name');
   let daname=jQuery.trim(ename.val());
   daname=fixString(daname,1).toLowerCase();

   if (daname=='') {
      alert('Please enter a name for this scenario');
      return 0;
   }

   if (jQuery.isNumeric(daname)) {
      alert('You can not use a number as the name of a scenario: `'+daname+'`');
      return 0;
   }

   let edesc=$('#scenario_desc');
   let dadesc=wsurvey.removeAllTags(jQuery.trim(edesc.val()));


   let oof=$('[name="scenarioDateSetter"]');
   let dstuff=wsurvey.dateBox_read(oof,1);
   if (dstuff===false) {
      alert('Please enter a properly specified date ');
      return 0;
   }
   let atime=dstuff['value'];

   let oofD=setEntryDate(dstuff.year,dstuff.month,dstuff.day);
   let adate=oofD.dayCount ;
   let adateSay=oofD.sayDate ;

   if (domodify==0) {          // don't allow modifications on existing entry (one with this name) ..  must use vu/modify buttons
      daname=daname.toLowerCase();
      if (simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(daname)) {
       if (simInvDsets['scenarioSpecs']['entries'][daname].hasOwnProperty(adate) ) {
         alert('There already is a scenario entry for `'+daname+'` / '+oofD.sayDate+'\n You can modify it using `Review ...`');
         return 0
       }
     }
   }

   let etable=$('#scenario_specTable');
   let etrs=etable.find('[name="scenarioSpecsRow"]');

// inflation:
  let einf=$('#scenarioInflation');
  let ainf=jQuery.trim(einf.val()) ;
   if (ainf!=='' && jQuery.isNumeric(ainf))  {
      ainf=parseFloat(ainf);
      if (ainf>1.5 )   {  // check if really means this
         let ainfSay=(ainf*100).toFixed(1);
         let qq=confirm('You entered an inflation value of ('+ainfSay+'%). Are you sure?\n Hint: to specify 5% inflation, enter 1.05');
         if (!qq) return false;
      }
      if (ainf<0.9)   {  // check if really means this
         let ainfSay=((1-ainf)*100).toFixed(1);
         let qq=confirm('You entered a deflation value of ('+ainfSay+'%). Are you sure?\n Hint: to specify 5% inflation, enter 1.05');
         if (!qq) return false;
      }

   } else {
      ainf=false;        // ignore if not numeric
   }

   let doit={}, errs=[];

   for (let ir=0;ir<etrs.length;ir++) {
     let etr=$(etrs[ir]);

     let e1=etr.find('[name="dainfo"]');
        let basset=e1.attr('data-name');
        let bassetSay=wsurvey.removeAllTags(e1.attr('data-sayname'));
        let btype=e1.attr('data-type');
     doit[basset]={};   // might overwrite prior spec (of specific assets)
       doit[basset]['sayname']=bassetSay ;   // might overwrite prior spec (of specific assets)
       doit[basset]['type']=btype;

     let einputs=etr.find('.scenarioInput');
     for (let i2=0;i2<einputs.length;i2++) {
         let einput=$(einputs[i2]);
         let aname=einput.attr('data-name');
         let aval=jQuery.trim(einput.val());
         if (!jQuery.isNumeric(aval)) {
            errs.push('Non-numeric multiplier for '+bassetSay+'/'+aname+' = '+aval);
            continue;
         }
         let bval=parseFloat(aval);
         if (bval<0) {
            errs.push('Non-positive multiplier for '+bassetSay+'/'+aname+' = '+aval);
            continue;
         }
         doit[basset][aname]=parseFloat(aval);
     }       // einputs
   }    // etrs
  if (errs.length> 0) {
     let say1='Errors:\n'+errs.join('\n * ');
     alert(say1);
     return 0;
  }

  if (!simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(daname)) simInvDsets['scenarioSpecs']['entries'][daname]={};

  simInvDsets['scenarioSpecs']['entries'][daname][adate]={'desc':dadesc,'sayDate':adateSay,'inflation':ainf,'multipliers':doit};

  let nowTime=wsurvey.get_currentTime(0);
  let vv1={'time':nowTime,'data':simInvDsets['scenarioSpecs']['entries']};


  simInvGlobals['temp']['autoLogonDetails']={'action':'scenarioSave','scenario':[daname,adate]} ;
  saveSimInvData_scenario(userName,vv1,'Saving scenario ');
   simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

}

