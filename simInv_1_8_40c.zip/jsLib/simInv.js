// simInv js functions


//=-==============
// toggle display of "welcome" scrreen,  action bar (2nd row)..
// status
//  0: displaying action bar, but not welcome screen
//  1 : displaying both
//  2: display welcome screen
//  3: neither
// 10: same as 1, but don't update data-staut

function toggleActionBar(athis,astatus) {
   let ethis=wsurvey.argJquery(athis);
   let eheader= $('#mainDivHeader');7
   if (arguments.length<2) {
     astatus=ethis.attr('data-status');
     astatus++ ;
   }
   astatus=parseInt(astatus);
   let noUpdate=0;
   if (astatus==10) noUpdate=1;
   if (astatus>3 || astatus<0) astatus=0;

   if (noUpdate==0) ethis.attr('data-status',astatus);

   if (astatus==0) {                // top bar only
      eheader.show();
      eheader.css({'opacity':1.0});
      reShowWelcome(-1);
      $('#mainDiv').css('top','6em');
   } else if (astatus==1) {              // both
      eheader.show();
      eheader.css({'opacity':1.0});
      reShowWelcome(2);
      $('#mainDiv').css('top','6em');
   } else if (astatus==2) {               // welcome screen only
      wsurvey.wsShow.hide('#mainDivHeader',10);
      reShowWelcome(2);
      $('#mainDiv').css({'top':'3em'});
      fitInMainDiv3('');  // fit to main
   } else if (astatus==3) {                 // neither
      wsurvey.wsShow.hide('#mainDivHeader',10);
      reShowWelcome(-1);
      $('#mainDiv').css('top','3em');
      fitInMainDiv3('');  // fit to main

   }
   return 1;

}

//==============
// display "wlecome" messages -- and a table of button actions
function reShowWelcome(makehome) {

 if (makehome==-1)  {   // clsoe selcome scrseen
    wsurvey.wsShow.hide('#mainDiv3',10);
    return 1;
 }

 if (makehome==2)  {
  wsurvey.wsShow.hide('#mainDiv2',10);
 }
 $('#mainDiv3').html(simInvGlobals['welcomeMessage']).show();    // this is why welcomeMessage is global and saved in afterLogon()

  wsurvey.wsShow.show('#mainDiv','show');  // make sure its on top
   wsurvey.wsShow.show('#mainDiv3','show');  // make sure its on top

  fitInMainDiv3('');  // fit to main
 

}




//================
// calculate inflation multipler between two dates, using cpiuSeriesUse
// Dates are specified in simInv dayCount  format (same as unix time -- 1= 2 Jan 1970)
//
// Usage: infMult * priceDate1 = priceDate2
//  infmult is the ratio of cpiDate2/cpiDate1
//
// cpiDaten is  interpolated (if necessary) from values in cpiuSeriesUse (grow at daily rate from cpi of series entry just before daten
// iall=0 (the default): return relative cpi. relativeCpi=  cpiDate2/cpiDate1
//    1= return [relativeCpi, cpiDate1,cpiDate2]
 //         if  date1=date2 and iall=1, return [1.0,false,false]
//    2 = return cpi (from schedule) of date1. Date2 is ignored
//    3  = return yearly inflation on this date  -- interpolating between most recent and next entries  (or just use most recent if after last cpiuSeriesUse entry)
// if problem (dates out of range of cpiuSeriesUse): return false
//   Note that 2100 (assetDetails_farFuture in simInv_params) is used when calculating last entry in cpiuSeriesUse
//        -- so "out of bounds above" lastEntryDate is not likely to happen
//        Out of bounds before uses first entry in cpiuSeriesUse -- by default this is 1 Jan 1984
//
// cpiuSeriesUse array has elements with: [dayCount,year,cpi,dailyInflationRate,yearlyInflationRate,imputeFlag,scenarioFlag,cumInf2023]
//        where the dailyInflationRate and yearlyInflationRate are calculated using an entry and its prior entry

function calcInflation(date1,date2,iall) {

 if (arguments.length<3) iall=0;
   if (date1==date2) {
      if (iall==1) return [1.0,false,false];
      if (iall==0) return 1.0;        // iall=2 : return actual cpi (not relative) below
   }



  date1=parseInt(date1);
  if (iall==2 || iall==3) date2=date1;  // date2 not used if iall=2  or 3... set it to date1 to avoid errors below

  let csLen=simInvGlobals['cpiuSeriesUse'].length-1;
  let firstEntryDate=simInvGlobals['cpiuSeriesUse'][0][0];
  let lastEntryDate=simInvGlobals['cpiuSeriesUse'][csLen][0];

  if (date1>lastEntryDate || date2>lastEntryDate) return false ; // too late!
  if (date1<firstEntryDate || date2<firstEntryDate) return false ; // too soon!


// special case: interpolate inflation value  -- less precise than below, but more robust
 if (iall==3) {
  for (let jj=csLen;jj>=0;jj--) {      // start at the end ...  look for "most recvent" entry (closest entry BEFORE date of interest)
      let ac1=simInvGlobals['cpiuSeriesUse'][jj];
      let acDate=ac1[0];
      if (acDate<=date1)  {                  // this entry is before date1 (never after last entry -- given check above)
          let yearRate= ac1[4] ;
          if (acDate==date1) return yearRate   ;   // exact match, use already calculated yearly inflation rate value
          if (jj==csLen) return yearRate    ;      // after last entry, so use value of last entry
          let ac2=simInvGlobals['cpiuSeriesUse'][jj+1];      // the next (closest in the future) entry
          let acDate2=ac2[0], yearRate2=ac2[4];

          let dgap=acDate2-acDate ;
          let igap=yearRate2-yearRate ;

          let dfrac=(date1-acDate)/dgap ;
          let ainf=yearRate + (igap*dfrac);
          return ainf;
      }              // found date in cpiSeriesUse <= date of interest
   }          // jj

 }    // iall=3

// calculate inflation using cpi values (more precise then interpolationg inflation values)
// cpiuSeriesUse rows: [dayCount,year,cpi,dailyInflationRate,yearlyInflationRate,imputeFlag,scenarioFlag,cumInf2023]

  let cpi1,cpi2,bcpi1,bcpi2;
  for (let jj=csLen;jj>=0;jj--) {      // start at the end ...  look for "most recvent" entry (closest entry BEFORE date of interest)
      let ac1=simInvGlobals['cpiuSeriesUse'][jj];
      if (ac1[0]<=date1)  {      // this entry is before date1 (never after last entry -- given check above)
          bcpi1=ac1[2];
          if (ac1[0]==date1)  {  // exact match
               cpi1=bcpi1 ;
          } else {            // need to interpolate "geometrically" (from prior to next, using "next" inflation rates in an exponential growth)
            date1A=ac1[0];
            dayRateB=simInvGlobals['cpiuSeriesUse'][jj+1][3] ;       // the daily inflation of the "next" entry (its what was used to go from prior entry to this one
            let dgapFind=date1-date1A;
            let ratex=dayRateB**dgapFind ;        //   exponentrial growth of daily inflation   (over time gap)
            cpi1=ratex*bcpi1;                    // is then multipled by CPI of "most recent" entry
          }
          break;
     }
   }

   if (iall==2) return cpi1 ; // just the cpi on date1


  for (let jj=csLen;jj>=0;jj--) {                 //  do it again for  date2 (which might be before or after date1
      let ac2=simInvGlobals['cpiuSeriesUse'][jj];
      if (ac2[0]<=date2)  {      // this entry is before date2 (never after last entry -- given chedk above)
          bcpi2=ac2[2];
          if (ac2[0]==date2)  {
               cpi2=bcpi2;
          } else {            // need to interpolate "geometrially"
            date2A=ac2[0];
            dayRateB=simInvGlobals['cpiuSeriesUse'][jj+1][3] ;       // the daily inflation of the "next" entry (its what was used to go from prior entry to this one
            let dgapFind=date2-date2A;
            let ratex=dayRateB**dgapFind ;         //   exponentrial growth of daily inflation   (over time gap)
            cpi2=ratex*bcpi2;
          }
          break ;
     }
   }

   let rateUse=cpi2/cpi1 ;

   if (iall==1) return [rateUse,cpi1,cpi2];

   return rateUse;

}

//============
// fix cpiuSeries, and extend to lastYearDo
// returns array for dates ... from specified cpis, scenario specified, years after final specified year, and far off in future yea
// Each row: [dayCount,year,cpi,dailyInflationRate,yearlyInflationRate,imputeFlag,scenarioFlag,cumInf_2023]
//
// where the dailyInflationRate and yearlyInflationRate are calculated using this entry and the prior entry  (they are backwards looking)
//   or are based on scenario specified rates
// Note that scenario specified rates are IGNORED if they occur before the final "cpiuSeries" specified rate
//
// imputeFlag is 0 for actual entries (or scenario specs), 1 if imputed
///   usingScRate:
//      if imputeFlag=0 : 0 if using "cpiuSeries"", 1 if "from scenario"
//      if imputeFlag=1 : 0 if using "last 5 years", 1 if "last scenario"  
// cumInf2023 is for info purposes- - cumulative inflation from jan 1 2023 (cpi=300)

function fixCpiuSeries(cpiuSeriesA,inflationAverageTimespan,lastYearDo) {
  let dlist=[];

  let cpiuSeries1= JSON.parse(JSON.stringify(cpiuSeriesA));  // clone this ;

  for (let adate in cpiuSeries1)   dlist.push(parseFloat(adate));
  dlist.sort(mySortNumeric);

  let lastgotDate=dlist[dlist.length-1];

  let oof=setEntryDate(lastgotDate);
  let lastGotYear=oof.year;
  lastGotDayCount=oof.dayCount ;

  let t2=cpiuSeries1[lastgotDate];

  let lookyear=lastGotYear-inflationAverageTimespan;

// go back and find entry before lookyear
  let useDate=dlist[0] ; // if can't find entry far enough back
  for (let ii=dlist.length-1;ii>=0;ii--) {
     let t1=dlist[ii];
     let tyear=setEntryDate(t1).year ;
     if (tyear<lookyear) {
          useDate=t1;
          break;
     }
  }
  let t1=cpiuSeries1[useDate];
  let useDateYear=setEntryDate(useDate).year ;

// computed "average" inflation rate over this "5 year" timespan
  dgap=lastgotDate-useDate;        // # days in 5 (or so) years
  let aratio=t2/t1;
   let v1=Math.log(aratio);
   let v1b=v1/dgap;                 // daily rate to yield aratio
  let dayRateFuture=Math.exp(v1b);
  let inflationRateFuture=dayRateFuture** 365; // convert to yearly rate

  let dlistNew=[];
  for (let jyear=lastGotYear+1;jyear<=lastYearDo;jyear++) {      // ie.;' lastYearDo=2035
     let do1a=setEntryDate(jyear,1,1)
     let do1=do1a.dayCount   ;
     dlistNew.push(do1 );
  }               // dlistNew are "1 jan xxxx after last speciifed cpi entry, until lastYearDo

 let cuse=[]  ;
 for (jj=1;jj<dlist.length;jj++) {      //   calculate "using cpiu specs"
     let j0=dlist[jj-1];
        let a_cpi0=cpiuSeries1[j0];
     let j1=dlist[jj];
        let a_cpi1=cpiuSeries1[j1];
        let j1year=setEntryDate(j1).year;

     let dgap1=j1-j0;
     let aratio1=a_cpi1/a_cpi0;
     let v1=Math.log(aratio1);
     let v1b=v1/dgap1;
     let dayRate1=Math.exp(v1b);
     let inf1=dayRate1**365  ;  // impted yearly length inflation rate (assuming
      let estx=a_cpi1/300.;
     aa=[j1,j1year,a_cpi1,dayRate1,inf1,0,0,estx] ;
     cuse.push(aa);
 }  // specfied entries

// showDebug(cuse,'from specs ',1);

// scenario values?
 let addInfs=[];
 let scUse=simInvParams['scenarioUse'];
 if (scUse!='') {              // make sure the scenario has not been deleted
     if (simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(scUse)) {
        for (let ddate in  simInvDsets['scenarioSpecs']['entries'][scUse]) {
             if (ddate<=lastGotDayCount) continue ;                         // not before last specified cpi
             if (simInvDsets['scenarioSpecs']['entries'][scUse][ddate].hasOwnProperty('inflation')) {
                 let ainf=simInvDsets['scenarioSpecs']['entries'][scUse][ddate]['inflation'] ;
                 if (jQuery.isNumeric(ainf))   {     // a specified inflation rate (not "use default")
                     let oo1=[ddate,ainf];
                     addInfs.push(oo1);
                 }
             }    // 'inflation' exists
        }
     }
    addInfs.sort(fixCpiuSeries_sort)
 }  // scuse

 let kk=cuse.length-1;
 let jaDate=cuse[kk][0];         // date of "last specified"
 let aCpiA=cuse[kk][2];       // cpi of last specified
 let usingScRate=0;

 for (jj=0;jj<dlistNew.length;jj++) {     // impute yearly values  (dlistNew has 1 jan xxxx daycounts)   -- but stop at first "scenario value"
     let jB=dlistNew[jj];
     if (addInfs.length>0) {
         if (jB>=addInfs[0][0]) break ;
     }
     let jByear=setEntryDate(jB).year;

     let dgap1=jB-jaDate;
     let amult=dayRateFuture**dgap1;         // daily inflation, using 5 year avarge
     let aCpiB=amult*aCpiA;
     let estz=aCpiB/300. ;
     let aa=[jB,jByear,aCpiB,dayRateFuture,inflationRateFuture,1,0,estz] ;     // aCpiB is predicted cpi
     cuse.push(aa);

     jaDate=jB;
     aCpiA=aCpiB ;  // do next year...
 }
// showDebug(cuse,'from adding  ',1);

// now add scenario values
  if (addInfs.length>0) {
    let wasDate=cuse[cuse.length-1][0];
    let wasCpi=cuse[cuse.length-1][2];
    let zrate,zrateDay ;
    for (let jj=0;jj<addInfs.length;jj++) {
      let zdate=parseInt(addInfs[jj][0]);
      let zdateYear=setEntryDate(zdate).year;
      zrate=addInfs[jj][1];
      zrateDay=Math.pow(zrate,1.0/365.0);
      let dgap2=zdate-wasDate;
      let amultC=zrateDay**dgap2 ;
      let nowCpi=amultC*wasCpi;
      let estzz=nowCpi/300. ;
      let aa=[zdate,zdateYear,nowCpi,zrateDay,zrate,0,1,estzz] ;     // nowCpi is scenario specified cpi
      cuse.push(aa);
      wasDate=zdate;
      wasCpi=nowCpi   ;
    }

// add  future years (from dlistNew)
 
    for (jj=0;jj<dlistNew.length;jj++) {     // impute yearly values  (dlistNew has 1 jan xxxx daycounts)   -- but stop at first "scenario value"
        let jB=dlistNew[jj];
        if (jB<=wasDate) continue;  // before final scenario specified inflation
        let jbYear=setEntryDate(jB).year ;

        let dgapD=jB-wasDate;
        let amultD=zrateDay**dgapD ;
        let nowCpiD=amultD*wasCpi;
        let estzz3=nowCpiD/300. ;
        let aa=[jB,jbYear,nowCpiD,zrateDay,zrate,1,1,estzz3] ;     // nowCpid is 1 jan  specified cpi (based on last specified simulation cpi)
        cuse.push(aa);

     }  // add more years

//     showDebug(cuse,'from scenarios + more  ',1);

     dayRateFuture=zrateDay  ;   // use this scenario spec  for far future inflatio
     inflationRateFuture=zrate ;
     aCpiA=wasCpi ;
     jaDate=wasDate;
     usingScRate=1;
  }      // scenarios




// and to avoid nans, a far fuiture date. Since linear interpolation is used, this is not going to provide accurate
// results for years after the end of the year range
  jByear=simInvGlobals['assetDetails_farFuture'] ;      // ie; jbYear=2100
  let jB=setEntryDate(jByear,1,1).dayCount;
  let dgap1=jB-jaDate;
  let amult=dayRateFuture**dgap1;
  let finalCpi=amult*aCpiA;

  let estz4=finalCpi/300.;
  aa=[jB,jByear,finalCpi,dayRateFuture,inflationRateFuture,1,usingScRate,estz4] ;

  cuse.push(aa);

//    showDebug(cuse,'final   '+scUse,1);

// each row of cuse is a cpi index.
// [dayCount,year,cpi,dailyInflationRate,yearlyInflationRate,imputeFlag,scenarioFlag
// where the dailyInflationRate and yearlyInflationRate are calculated using this entry and the prior entry  (they are backwards looking)
// imputeFlag is 0 for actual entries (or scenario specs), 1 if imputed
///   usingScRate:
//      if imputeFlag=0 : 0 if using "cpiuSeries"", 1 if "from scenario"
//      if imputeFlag=1 : 0 if using "last 5 years", 1 if "last scenario"
   return cuse ;

}

//===========
// sort inflation value fro this scenario
function  fixCpiuSeries_sort(a,b) {
  let a1=a[0],b1=b[0];
  if (a1>b1) return 1;
  if (a1==b1) return 0
  return -1;
}

//===============
// expand window to fill screen
// 2 arguments  for dirdct call  -- to remove expand class
function fillTheWindow(athis,athis2) {
  let isfull=false,aid,aid2,ethis;
  if (arguments.length==2) {
      aid=athis;
      aid2=athis2;
  } else {
       ethis=wsurvey.argJquery(athis);
     aid=ethis.attr('data-id');
     aid2=ethis.attr('data-id2');
     isfull=ethis.attr('data-full');
  }
 
  let eid=$('#'+aid);
  let eid2=$('#'+aid2);

  if (isfull!==false) {
     isfull=1-isfull;
     ethis.attr('data-full',isfull);
  }
  if (isfull==1) {
     eid.addClass('cmakeWindowFull');
     if (eid2.length>0)  eid2.addClass('cmakeWindowFull2');
     ethis.css({'background-color':'lime'});
     ethis.attr('title','Click to unExpand ');
  } else {
     if (isfull!==false) {
        ethis.css({'background-color':''});
        ethis.attr('title','Click to expand (to fill window) ');
     }
     eid.removeClass('cmakeWindowFull');
     if (eid2.length>0)  eid2.removeClass('cmakeWindowFull2');

  }
  return 1;
 }

//================
// change personal settings
function personalSettings(ido) {

  let bmess='';
  bmess+='<div id="ipersonalSetting">';
  bmess+='<div>';


//   bmess+='<input type="button" value="?" title="Notes" onClick="$(\'#settingsHelp1\').toggle()"> ';
  bmess+='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#settingsHelp1a">?</button>  ';
  bmess+='<button title="View notes " onclick="$(\'.settingsNoteDiv\').toggle()">&#x1d160;</button> ';
  bmess+='You can personalize these settings ';
  bmess+=' ... and then  ';
  bmess+='<button class="csaveButton"  id="ipersonalSettingSaveButton" onClick="personalSettingsSave(this)"> ';
  bmess+='Save them </button> ';
  bmess+='<span style="float:right;margin-right:0.5em"> <input class="csettingsButton" type="button" ';
  bmess+='     value="Diagnostics &hellip;" onClick="viewDiagnostics(1)" > ';

  bmess+='</div>';

  bmess+='<div style="max-height:15em;overflow:auto;margin:1px 1em 1em 5px;padding:2px 5px 1em 5px">';
  bmess+='<b>Financial and estimation parameters ...</b>   ';
    bmess+='<div class="settingsNoteDiv">Changing any of the financial and estimation parameters will clear the quickDisplay information ',
  bmess+='  </div>';

  bmess+='<ul class="boxList">';

  bmess+='<li>Cash interest rates: ';
  bmess+='<span style="display:inline-block;white-space:nowrap"> ';
  bmess+=' <u>Cash</u> &gt; 0.0 : <input size="6" type="text" name="cashInterest" data-orig="'+simInvParams['cashInterest']+'" title="0.0: 0%, 1.0: 100%" value="'+simInvParams['cashInterest']+'">   ';
  bmess+='&#8286; &#8286; <u>Cash</u> &lt; 0.0 : <input size="6" type="text" name="cashPenalty" title="0.0: 0%, 1.0: 100%"   data-orig="'+simInvParams['cashPenalty']+'" value="'+simInvParams['cashPenalty']+'">';
  bmess+='</span>';
  bmess+='<div class="settingsNoteDiv">&nbsp;&nbsp; <em>Example: 0.15 for a 15% tax rate</em></div>';

  bmess+='<li>Tax rates: ';
  bmess+='<span style="display:inline-block;white-space:nowrap"> ';
  bmess+='Income tax rate: <input size="6" type="text" name="taxRate"  title="0.0:%, 1.0:100%" data-orig="'+simInvParams['taxRate']+'"   value="'+simInvParams['taxRate']+'">';
  bmess+='  &#8286; &vellip; Capital gains tax rate: <input  size="6" type="text" title="0.0: 0%, 1.0: 100%" name="capGainsRate"   data-orig="'+simInvParams['capGainsRate']+'"  value="'+simInvParams['capGainsRate']+'">';
  bmess+='</span>';

  bmess+='<li>Number of years to use when estmating <em>future inflation rates</em>. Must be at least 1  ';
  bmess+='<input type="text"  size="2" name="inflationAverageTimespan"  data-orig="'+simInvParams['inflationAverageTimespan']+'" value="'+simInvParams['inflationAverageTimespan']+'">';
  bmess+='</ul>';

  bmess+='<b>Display and formatting parameters ...</b>    ';
  bmess+='<ul class="boxList">';



      bmess+='<li>Reporting range: ';
  bmess+='<span style="display:inline-block;white-space:nowrap"> ';
  bmess+=' first year <input type="text"  size="6" name="firstYearUse"  data-orig="'+simInvParams['firstYearUse']+'" value="'+simInvParams['firstYearUse']+'">';
  bmess+=' to  last year <input type="text"  size="6" name="lastYearUse"  data-orig="'+simInvParams['lastYearUse']+'" value="'+simInvParams['lastYearUse']+'">';
  bmess+='</span> ';
  bmess+='<div class="settingsNoteDiv"><em>These values are used as defaults for the <button>displayDates</button> <u>earliest and latest</u> dates </em>';
  bmess+='</div>';

  bmess+='<li>Use <u>interpolation</u> when calculating portfolio values ';
  bmess+='<input type="hidden"  class="csettingsVal" name="showValuesInterp" value="'+simInvParams['showValuesInterp']+'">';
  if (parseInt(simInvParams['showValuesInterp'])==0) {
     bmess+=' <button class="settingsChoseYN_chosen " data-val="0"   title="Do not use interpolation -- all \'Display\' values are fully calculated" onClick="personalSettings_button(this)">No</button> ';
     bmess+=' <button class="settingsChoseYN "        data-val="1"   title="Use interpolation for  \'calendar\' dates"   onClick="personalSettings_button(this)">Yes</button> ';
  } else {
     bmess+=' <button class="settingsChoseYN "        data-val="0"   title="Do not use interpolation -- all \'Display\' values are fully calculated" onClick="personalSettings_button(this)">No</button> ';
     bmess+=' <button class="settingsChoseYN_chosen " data-val="1"   title="Use interpolation for  \'calendar\' dates"  onClick="personalSettings_button(this)">Yes</button> ';
  }
  bmess+='<div class="settingsNoteDiv">Interpolation speeds up processing, but lessens accuracy. ';
  bmess+=' Interpolation is <u>not</u> used for: init entries, mod entries, and  custom dates.</div>';

  bmess+='<li>Use <u>quickDisplay</u> to display portfolio values ';
  bmess+='<input type="hidden"  class="csettingsVal" name="doQuickDisplay" value="'+simInvParams['doQuickDisplay']+'">';
  if (parseInt(simInvParams['doQuickDisplay'])==0) {
     bmess+=' <button class="settingsChoseYN_chosen " data-val="0"   title="Do not use quickDisplay -- \'Display\' values are calculated and then displayed" onClick="personalSettings_button(this)">No</button> ';
     bmess+=' <button class="settingsChoseYN "        data-val="1"   title="Use quickDisplay for  --  \'Display\' values are read from localStorage (if available) and displayed  "   onClick="personalSettings_button(this)">Yes</button> ';
     bmess+=' <button class="settingsChoseYN "        data-val="fast"   title="Use faster version of quickDisplay for  --  \'Display\' values are read from localStorage (if available) and displayed  "   onClick="personalSettings_button(this)">Fast</button> ';
  } else if (simInvParams['doQuickDisplay']=='fast') {
     bmess+=' <button class="settingsChoseYN " data-val="0"   title="Do not use quickDisplay -- \'Display\' values are calculated and then displayed" onClick="personalSettings_button(this)">No</button> ';
     bmess+=' <button class="settingsChoseYN "        data-val="1"   title="Use quickDisplay for  --  \'Display\' values are read from localStorage (if available) and displayed  "   onClick="personalSettings_button(this)">Yes</button> ';
     bmess+=' <button class="settingsChoseYN_chosen "        data-val="fast"   title="Use faster version of quickDisplay for  --  \'Display\' values are read from localStorage (if available) and displayed  "   onClick="personalSettings_button(this)">Fast</button> ';
  } else {
     bmess+=' <button class="settingsChoseYN " data-val="0"   title="Do not use quickDisplay -- \'Display\' values are calculated and then displayed" onClick="personalSettings_button(this)">No</button> ';
     bmess+=' <button class="settingsChoseYN_chosen "        data-val="1"   title="Use quickDisplay for  --  \'Display\' values are read from localStorage (if available) and displayed  "   onClick="personalSettings_button(this)">Yes</button> ';
     bmess+=' <button class="settingsChoseYN "        data-val="fast"   title="Use faster version of quickDisplay for  --  \'Display\' values are read from localStorage (if available) and displayed  "   onClick="personalSettings_button(this)">Fast</button> ';
  }
  bmess+='<div class="settingsNoteDiv">quickDisplay speeds up display of the portfolio values -- using recent calcluations that are stored in the browser\`s <tt>localStorage</tt>. ';
  bmess+=' When quickDisplay is used, viewing data details requires a re-calculation (which can take time). The <tt>fast</tt> version of quickDisplay is fastest -- but requires a longer re-calculation if details are viewed.';


  bmess+='<li>Default budget: ';
  bmess+=' <input size="8" type="text" name="defaultBudget" title="The default starting budget" value="'+simInvParams['defaultBudget']+'">   ';

  bmess+='<li>Encryption key hint:<input type="text"  size="45" name="encryptionKeyHint" value="'+simInvParams['encryptionKeyHint']+'">';
  bmess+='<div class="settingsNoteDiv"><em> optional: you can use this to help you remember your personal encryption key</em></div>';

  bmess+='<li>Warnings:   ';
  bmess+='<input type="hidden"  class="csettingsVal" name="warningLevel" value="'+simInvParams['warningLevel']+'">';
  if (parseInt(simInvParams['warningLevel'])==0) {
     bmess+=' <button class="settingsChoseYN_chosen " data-val="0"   title="Show all warnings" onClick="personalSettings_button(this)">Show all</button> ';
     bmess+=' <button class="settingsChoseYN "        data-val="1"   title="Show fewer warnings"  onClick="personalSettings_button(this)">Show fewer</button> ';
  } else {
     bmess+=' <button class="settingsChoseYN"           data-val="0"   title="Show all warnings" onClick="personalSettings_button(this)">Show all</button> ';
     bmess+=' <button class="settingsChoseYN_chosen "  data-val="1"   title="Show fewer warnings"  onClick="personalSettings_button(this)">Show fewer</button> ';
  }


  bmess+='<li>How to first display a portfolio`s initialization and modification entries?:<br> ';
  bmess+='<input type="hidden" class="csettingsVal"  name="showTransactions" value="'+simInvParams['showTransactions']+'">';
  let ttss=['settingsChoseYN','settingsChoseYN','settingsChoseYN','settingsChoseYN','settingsChoseYN'],itss=parseInt(simInvParams['showTransactions']);
  ttss[itss]='settingsChoseYN_chosen' ;
  bmess+=' <button class="'+ttss[0]+'"  data-val="0"   title="Small buttons" onClick="personalSettings_button(this)">Small buttons</button> ';
     bmess+=' <button class="'+ttss[1]+'" data-val="1"   title="Larger buttons"   onClick="personalSettings_button(this)">Larger buttons</button> ';
     bmess+=' <button class="'+ttss[2]+'" data-val="2"   title="Larger buttons and summary table"   onClick="personalSettings_button(this)">Larger buttons and summary table</button> ';
     bmess+=' <button class="'+ttss[3]+'"  data-val="3"   title="Small buttons and summary table"   onClick="personalSettings_button(this)">Small buttons and summary table</button> ';
  bmess+=' <button class="'+ttss[4]+'"  data-val="4"   title="Summary table"   onClick="personalSettings_button(this)">Summary table</button> ';

  bmess+='<li>Issue warning if <u>Cash fraction</u> is greater than: ';
  bmess+='<input type="text"  size="4" name="budgetRemainPct" value="'+simInvParams['budgetRemainPct']+'">';
  bmess+='<div class="settingsNoteDiv">If abs(<u>Cash</u>) is gt than this fraction of the budget (or netValue), issue various warning (such as a  <tt>confirm?</tt> when saving)  ';
  bmess+='</div>';

  bmess+='<li>Allow more than one asset from the same <u>family</u> to be in a portfolio. ';
  bmess+='<input type="hidden"  class="csettingsVal" name="sameAssetFamilyOk" value="'+simInvParams['sameAssetFamilyOk']+'">';
  if (parseInt(simInvParams['sameAssetFamilyOk'])==0) {
     bmess+=' <button class="settingsChoseYN_chosen " data-val="0"   title="Do not allow same asset from same family"   onClick="personalSettings_button(this)">No</button> ';
     bmess+=' <button class="settingsChoseYN "        data-val="1"   title="Allow same asset from same family "         onClick="personalSettings_button(this)">Yes</button> ';
  } else {
     bmess+=' <button class="settingsChoseYN "        data-val="0"   title="Do not allow same asset from same family"  onClick="personalSettings_button(this)">No</button> ';
     bmess+=' <button class="settingsChoseYN_chosen " data-val="1"   title="Allow same asset from same family"          onClick="personalSettings_button(this)">Yes</button> ';
  }
  bmess+='<div class="settingsNoteDiv">Example: <tt>coolStock.1</tt> and <tt>coolStock.2</tt> are in the same <u>family</u>.</div>';

  bmess+='<li>Character string to use in headers of CSV export files: ';
  bmess+='<input type="text"  size="4" name="headerSep" value="'+simInvParams['headerSep']+'">';
  bmess+='<div class="settingsNoteDiv">Spaces will <u>not</u> be trimmed -- thus a single space is a legitimate seperator!  ';
  bmess+='<br>Usage example:  asset attributes in <tt>&#128194; Export Assets</tt> ';
  bmess+='</div>';

  bmess+='</ul>';
  bmess+='</div>';

  bmess+='</div>';     ///  ipersonalSetting

  bmess+='<div style="margin:0.5em 1em;border-top:1px solid gray">To update the inflation series, use <button> &#11192; &#206;nflation</button>  <em>(at the top of this page)...</em>';
  bmess+='<br>To change the dates  used by  <button> &#128176; Display </button>, use  <button> &#128197;displayDates</button>';
  bmess+='</div>';

  displayStatusMessage(bmess);
  toggleStatusDiv(0,0);       // make it big

  if (ido==11 && simInvGlobals['settingsHeaderCanHide']==1 ) {        // settings button on simInv header
    let earf=$('#settingsHeader1b');
    if (earf.is(':visible')) {
       earf.fadeOut(50);
    } else {
       earf.hide();
       let ep1=$('#headerLine');
       let ih0= parseInt(ep1.height());
       earf.show()  ;
       let ih1= parseInt(ep1.height());  // if bigger than this... do not show
       let hdiff=Math.abs(ih0-ih1) ;

       earf.hide();
       if (hdiff<4) {
         earf.fadeIn(50);
       }  else {
         $('#settingsHeader1b').css({'text-overflow':'ellipsis','display':'inline-block','width':'12em','height':'1em','overflow':'hidden'});
         earf.fadeIn(150);
       }
    }
  }
}

//=======================
// set a  type=hidden based on button push, and highlight the pushed button
function personalSettings_button(athis ) {
  let ethis=wsurvey.argJquery(athis);
  let ival=ethis.attr('data-val');
  let afind=ethis.attr('data-set');
  let ali=ethis.closest('li');
  let einput=ali.find('.csettingsVal');

  einput.val(ival);
  let goo=einput.attr('name');
  let ebuttons=ali.find('button');
  ebuttons.removeClass('settingsChoseYN settingsChoseYN_chosen');
  ebuttons.addClass('settingsChoseYN');
  ethis.removeClass('settingsChoseYN');
  ethis.addClass('settingsChoseYN_chosen');
  return 1;
}


// ============== save personal settings
function personalSettingsSave(athis) {

   let e1=$('#ipersonalSetting');
   let zchange=0;
// the financial params

   let eint1=e1.find('[name="cashInterest"]');
   let ainterest=jQuery.trim(eint1.val());
   if (!jQuery.isNumeric(ainterest)) {
      alert("Cash interest rate is not a number: "+ainterest);
      return 0;
   }
   let ointerest=eint1.attr('data-orig');
   if  (ainterest!=ointerest) zchange++;


   let eint2=e1.find('[name="cashPenalty"]');
   let apenalty=jQuery.trim(eint2.val());
   if (!jQuery.isNumeric(apenalty)) {
      alert("Cash penalty rate (interest on -Cash)   is not a number: "+apenalty);
      return 0;
   }
   let openalty=eint2.attr('data-orig');
   if  (apenalty!=openalty) zchange++;

   let erate=e1.find('[name="taxRate"]');
   let arate=jQuery.trim(erate.val());
   if (!jQuery.isNumeric(arate)) {
      alert("Income tax rate is not a number: "+arate);
      return 0;
   }
   if (arate<0  || arate>1.0) {
      alert("Income tax rate should be between 0.0 and 1.0: "+arate);
      return 0;
   }
   let orate=erate.attr('data-orig');
   if  (arate!=orate) zchange++;

   let ecapgains=e1.find('[name="capGainsRate"]');
   let acapgains=jQuery.trim(ecapgains.val());
   if (!jQuery.isNumeric(acapgains)) {
      alert("Capital gains tax rate is not a number: "+acapgains);
      return 0;
   }
   if (acapgains<0  || acapgains>1.0) {
      alert("Capital gains tax rate should be between 0.0 and 1.0: "+acapgains);
      return 0;
   }
   let ocapgains=jQuery.trim(ecapgains.attr('data-orig'));
   if  (ocapgains!=acapgains) zchange++;

      let einflationAverageTimespan=e1.find('[name="inflationAverageTimespan"]');
   let ainflationAverageTimespan=jQuery.trim(einflationAverageTimespan.val());
   if (!jQuery.isNumeric(ainflationAverageTimespan)) ainflationAverageTimespan=5 ;
   ainflationAverageTimespan=parseInt(ainflationAverageTimespan);
   if (ainflationAverageTimespan<1  ) ainflationAverageTimespan=1;

   let oAvgT=jQuery.trim(einflationAverageTimespan.attr('data-orig'));
   if  (oAvgT!=ainflationAverageTimespan) zchange++;

   let efirstYear=e1.find('[name="firstYearUse"]');
   let afirstYear=jQuery.trim(efirstYear.val());
   let elastYear=e1.find('[name="lastYearUse"]');
   let alastYear=jQuery.trim(elastYear.val());

   if (!jQuery.isNumeric(afirstYear)) {
      alert("First year is not a number: "+afirstYear);
      return 0;
   }
   if (!jQuery.isNumeric(alastYear)) {
      alert("Last year is not a number: "+alastYear);
      return 0;
   }
   if (afirstYear>alastYear) {
      alert('First year ('+afirstYear+')  is greater than last year ('+alastYear+')');
      return 0;
   }
   if (alastYear>simInvGlobals['theMaxYear'] || afirstYear<simInvGlobals['theMinYear']) {
      let qq=confirm('Your first and last years ('+afirstYear+' to '+alastYear+') are unusual. Are you sure you want to use them?');
      if (!qq) return 0;
   }

   let ofirstYear=jQuery.trim(efirstYear.attr('data-orig'));
//   if  (ofirstYear!=afirstYear) zchange++;
   let olastYear=jQuery.trim(elastYear.attr('data-orig'));
// if  (olastYear!=alastYear) zchange++;


// the display & formatting params
   let ehint=e1.find('[name="encryptionKeyHint"]');   // this is used as is
   let ahint=jQuery.trim(ehint.val());

   let edefaultBudget=e1.find('[name="defaultBudget"]');
   let adefaultBudget=jQuery.trim(edefaultBudget.val());
   adefaultBudget=parseInt(fixNumberValue(adefaultBudget));

   let ewarningLevel=e1.find('[name="warningLevel"]');
   let awarningLevel=jQuery.trim(ewarningLevel.val());
   if (awarningLevel!='1') awarningLevel=0;

   let eshowValuesInterp=e1.find('[name="showValuesInterp"]');
   let ashowValuesInterp=jQuery.trim(eshowValuesInterp.val());
   if (ashowValuesInterp!='1') ashowValuesInterp=0;

   let equickDisplay=e1.find('[name="doQuickDisplay"]');
   let aquickDisplay=jQuery.trim(equickDisplay.val());

   if (aquickDisplay!='1' && aquickDisplay!=='fast') aquickDisplay=0;

   let eshowTranscations=e1.find('[name="showTransactions"]');
   let ashowTransactions=jQuery.trim(eshowTranscations.val());
   if (!jQuery.isNumeric(ashowTransactions) || ashowTransactions<0 || ashowTransactions>4) ashowTransactions=0;
   ashowTransactions=parseInt(ashowTransactions);

   let ebudgetRemainPct=e1.find('[name="budgetRemainPct"]');
   let abudgetRemainPct=jQuery.trim(ebudgetRemainPct.val());
   if (!jQuery.isNumeric(abudgetRemainPct)) abudgetRemainPct=0.005;
   abudgetRemainPct=parseFloat(abudgetRemainPct);
   if (abudgetRemainPct<0 || abudgetRemainPct>1.0) abudgetRemainPct=0.005;

   let eheaderSep=e1.find('[name="headerSep"]');
   let aheaderSep=eheaderSep.val();  // do NOT trim spaces... but do remove tags
   aheaderSep=wsurvey.removeAllTags(aheaderSep);

   let esameAssetFamilyOk=e1.find('[name="sameAssetFamilyOk"]');
   let asameAssetFamilyOk=jQuery.trim(esameAssetFamilyOk.val());
   if (asameAssetFamilyOk!='1') asameAssetFamilyOk=0;

  let ddata={};

// these should match list in scenarioUseSave() below
  ddata['username']=userName;
  ddata['encMd5']=simInvGlobals['encryptionKey_md5'];

  ddata['firstYearUse']=afirstYear ;  // defaults
  ddata['lastYearUse']=alastYear ;
  ddata['defaultBudget']=adefaultBudget;
  ddata['taxRate'] =arate ;  // defaults
  ddata['capGainsRate']=acapgains ;
  ddata['cashInterest']=ainterest;
  ddata['cashPenalty']=apenalty;
  ddata['warningLevel']=awarningLevel;
  ddata['showValuesInterp']=ashowValuesInterp;
  ddata['doQuickDisplay']=aquickDisplay;
  ddata['encryptionKeyHint']=ahint;
  ddata['showTransactions']=ashowTransactions;
  ddata['budgetRemainPct']=abudgetRemainPct;
  ddata['headerSep']=aheaderSep;
  ddata['inflationAverageTimespan']=ainflationAverageTimespan;
  ddata['sameAssetFamilyOk']=asameAssetFamilyOk;
  ddata['hint']=ahint ;

  ddata['scenarioUse']=simInvParams['scenarioUse'] ;             // this is set in its own menu

  let nowTime=wsurvey.get_currentTime(0)
  let dsave={'time':nowTime,'data':ddata };

  simInvGlobals['temp']['autoLogonDetails']={'action':'settings'} ;
  saveSimInvData_settings(userName,personalSettingsSave2,dsave,'Settings saved')

  if (zchange>0) {
     simInv_cacheResults_removeAll(1) ;  // financial params modified? quickDisplay cache no longer valid
  }

}

function personalSettingsSave2(astatus,amess,afoo) {  // callback -- ignore the 'hint' 3rd arg
 displayResponseFromServer(amess,'isettingsButton',0);
 return  ;
}

function scenarioUseSave2(astatus,amess,afoo) {  // callback -- ignore the 'hint' 3rd arg

 displayResponseFromServer(amess,'scenarioTableButton_chosen',0);
 return  ;
}

//====================
// warnings (cache issues, etc)
function personalWarnings(athis) {
  let e1=$('#iWarningsButton');
  let awhat=e1.attr('data-what');

  if (awhat=='fullStorage')    {    // localStorage is full
    let navail=e1.attr('data-info');
    bmess='';
    bmess+= 'Unable to save quickDisplay information to localStorage.   Available= '+wsurvey.addComma(navail) ;
    bmess+='<br>You can <input type="button" value="Selectively  clear localStorage" onClick="simInv_cacheResults_show(1)">';
    displayStatusMessage(bmess);
    toggleStatusMessage(0,3);
  }

  if (awhat=='lastDateIssue')    {    // localStorage is full
    let alist=e1.attr('data-info');
    let blist=alist.split(',');
    let zz='<ul><li>'+blist.join('<li>')+'</ul>';
    bmess='';
    bmess+= 'You have one (or more) portfolios whose last entry is before a Display date. Recommendation: use  <button>displayDates</button> ';
    bmess+=' to change the <tt>Latest date</tt> to an earlier year, <em>or </em> add a custom date after the latest date.';
    bmess+=zz;
    displayStatusMessage(bmess);
    toggleStatusMessage(0,3);
  }

  if (awhat=='slow') {
    let eps1=e1.attr('data-info');
    let tz1=eps1/1000;
    let bmess='Calculating values for the displayDates took '+tz1.toFixed(1)+' seconds. ';
    bmess+='<br>There are several ways to speed up display, using the &#9965; settings menu ';
    bmess+='<ul class="tightMenu">';
    bmess+='<li><em>Interpolation</em>: interpolation uses a weighted averages (of initialization, modification, and custom entries) to calculate values of the calendar-date entries. ';
    bmess+='<br>Interpolation can be much faster, but can yield inaccurate results (especially if there is a lot of variation in asset values)';
    bmess+='<li><em>quickDisplay</em> quickDisplay uses prior results (from earlier sessions) to display values. This is quick, but if you want ';
    bmess+='to view details -- the calculations have to be done. quickDisplay (and its <em>fast</em> variante are most useful if you often '
    bmess+='view the basic values simulations; and do not change them much (and are not interested in the details)';
    bmess+='<li>For both these methods, the user can always force simInv to re-calculate (and display) using Full Calculations';
    bmess+='</ul>';

    displayStatusMessage(bmess);
    toggleStatusMessage(0,3);

  }

}

// ============== save
function scenarioUseSave(fuse) {
// note: if adding a settings, also change list in buildAllSettings in simInv_afterLogon
    let ddata={} ;
    let plist=['cashInterest', 'cashPenalty', 'taxRate', 'capGainsRate', 'firstYearUse',
               'lastYearUse', 'lastYearUse', 'encryptionKeyHint', 'scenarioUse', 'warningLevel','showValuesInterp','doQuickDisplay',
               'showTransactions',  'budgetRemainPct', 'headerSep',
               'inflationAverageTimespan', 'sameAssetFamilyOk', 'additionsFromCash','defaultBudget'];

    for (let im=0;im<plist.length;im++) {
       let aparam=plist[im];
       ddata[aparam]=simInvParams[aparam];
    }  // otherwise, use default set in  simInv_params.js

   ddata['scenarioUse']=fuse;

  let nowTime=wsurvey.get_currentTime(0)
  let dsave={'time':nowTime,'data':ddata };


  simInvGlobals['temp']['autoLogonDetails']={'action':'scenarioSelect'} ;
  saveSimInvData_settings(userName,scenarioUseSave2,dsave,'scenario (future state-of-the-world) saved')
//   simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

}

//================
// create display dates table ..........
function createViewDates(ifoo) {

// set some defaults
 let firstYearUse= simInvParams['firstYearUse']  ;
   let firstYearStuff= setEntryDate(simInvParams['firstYearUse'],1,1)
   let firstYearDayCount=firstYearStuff['dayCount'];
 let lastYearUse=  simInvParams['lastYearUse'] ;
   let lastYearStuff= setEntryDate(simInvParams['lastYearUse'],12,31)
   let lastYearDayCount=lastYearStuff['dayCount'];

 let addEntryDates=2;    // default is init and mod entries
 let addCalendarDates=1;   // default is yearly
 let customDates=[],addCurrentDate;

// read user set values
 let vDates= (simInvDsets.hasOwnProperty('viewDates')) ? simInvDsets['viewDates'] : {} ;


 if (jQuery.isArray(vDates)) {  // pre 1 march 2024 version
     customDates=vDates;
     addCurrentDate=0;
 }   else {

    if (vDates.hasOwnProperty('customDates')) customDates=vDates['customDates'];
    if (vDates.hasOwnProperty('addCurrentDate')) addCurrentDate=vDates['addCurrentDate'];
    if (vDates.hasOwnProperty('addEntryDates'))  addEntryDates=vDates['addEntryDates'];
    if (vDates.hasOwnProperty('addCalendarDates'))  addCalendarDates=vDates['addCalendarDates'];
    if (vDates.hasOwnProperty('firstDateAllow')) {
        firstYearDayCount=vDates['firstDateAllow'];
        firstYearStuff= setEntryDate(firstYearDayCount)  ;
    }
    if (vDates.hasOwnProperty('lastDateAllow'))  {
        lastYearDayCount=vDates['lastDateAllow'];
        lastYearStuff= setEntryDate(lastYearDayCount) ;
    }

 }

  let vmess=' <hr>';
  vmess+='<div style="margin:3px 3em 4px 3em;background-color:#dfeddf">';
  vmess+='<input type="button" value="x" title="close this" onClick="wSurvey.wsShow.hide(this,100)" data-wsshow="-2"> ';
  vmess+='  <button title="Tips" onclick="displayHelpMessage(this)" data-div="#displayDatesHelp">?</button>  ';
  vmess+='<tt>displayDates</tt> are used by   ';
  vmess+='<button  xclass="cdoButtonRegularBig"  >&#128176; Display </button>. On this page you specify what dates to display.';

  vmess+='<br>After making changes ... <span style="margin-left:3em;padding;3px">';
  vmess+='<button onClick="saveViewDates(this,0)" class="csaveButton"> Save these display dates</button> ';
  vmess+='(the various dates will be sorted, with duplicates removed)</span>' ;
  vmess+='</div>';

  let def0=(addEntryDates==0) ? ' checked' : ' ';
  let def1=(addEntryDates==1) ? ' checked' : ' ';
  let def2=(addEntryDates==2) ? ' checked' : ' ';

  let cal0=(addCalendarDates==0) ? ' checked' : ' ';
  let cal1=(addCalendarDates==1) ? ' checked' : ' ';
  let cal2=(addCalendarDates==2) ? ' checked' : ' ';
  let cal4=(addCalendarDates==4) ? ' checked' : ' ';
  let cal12=(addCalendarDates==12) ? ' checked' : ' ';
//  let cal52=(addCalendarDates==52) ? ' checked' : ' ';

  vmess+='<table cellpadding="6" border="2" width="95%"><tr>';    // MAIN table
  vmess+='<td valign="top" width="75%"> ';

  vmess+='<form id="icreateViewDates" name="fdisplayDates">';
  vmess+='<table style="border:1px solid blue;margin:3px 2em;padding:5px" width="95%" cellpadding="5" rules="rows">'; // input form table

    vmess+='<tr><td width="35%">Earliest and latest dates<br>Dates before these are <u>not</u> displayed </td>';
    vmess+='<td width="75%">';
      vmess+='<div>Earliest date: ' ;
      vmess+=' <tt> Year= <input name="viewYear1" size="4" type="text" value="'+firstYearStuff['year']+'"> ' ;
      vmess+=' | Month= <input name="viewMonth1"  size="2" type="text" value="'+firstYearStuff['month']+'">  ' ;
      vmess+=' | Day= <input name="viewDay1" type="text"   size="2" value="'+firstYearStuff['day']+'"> </tt> ';
      vmess+=' &nbsp;&nbsp; <input type="button" value="Reset" title="Use the \'first year\' setting" onClick="createViewDates_reset(1)" >';
      vmess+='</div>';
      vmess+='<div>Latest date:&nbsp;&nbsp; ' ;
      vmess+='  <tt> Year= <input name="viewYear2"  size="4" type="text" value="'+lastYearStuff['year']+'"> ' ;
      vmess+=' | Month= <input name="viewMonth2"  size="2" type="text" value="'+lastYearStuff['month']+'">  ' ;
      vmess+=' | Day= <input name="viewDay2" type="text" size="2"  value="'+lastYearStuff['day']+'"> </tt> ';
      vmess+=' &nbsp;&nbsp; <input type="button" value="Reset" title="Use the \'last year\' setting" onClick="createViewDates_reset(2)" >';
      vmess+='</div>';

    vmess+='</td></tr>';

  vmess+='<tr><td>Display initialization and modification entry dates </td>';
  vmess+='<td >';
  vmess+='<label style="margin:3px 5px;border:1px solid #998899" title="Do not add init and mod entry dates"> <input '+def0+' type="radio" name="naddEntryDates" value="0">No </label> ';
  vmess+='<label style="margin:3px 5px;border:1px solid #998899" title="Add init dates"> <input   '+def1+' type="radio" name="naddEntryDates" value="1">Initialization </label> ';
  vmess+='<label style="margin:3px 5px;border:1px solid #998899"  title="Add init and mod dates"> <input  '+def2+' type="radio" name="naddEntryDates" value="2">Init &amp; Modification </label> ';
 vmess+='<br><em>for all unHidden portfolios</em> ';
  vmess+='</td>';
  vmess+='</tr>';

  vmess+='<tr><td>Display calendar dates? </td>';
  vmess+='<td>';
  vmess+='<label style="margin:3px 5px;border:1px solid #998899" title="Do not add calendar dates"> <input '+cal0+' type="radio" name="nCalendarDates" value="0">No </label> ';
  vmess+='<label style="margin:3px 5px;border:1px solid #998899" title="Add Jan 1 dates (for all years)"> <input  '+cal1+'  type="radio" name="nCalendarDates" value="1">Yearly  </label> ';
  vmess+='<label style="margin:3px 5px;border:1px solid #998899" title="Add Jan 1 and July 1, dates (for all years)"> <input  '+cal2+'  type="radio" name="nCalendarDates" value="2">Semi-annual</label> ';
  vmess+='<label style="margin:3px 5px;border:1px solid #998899" title="Add Jan 1, April 1, and July 1,and Sep 1 dates (for all years)"> <input  '+cal4+'  type="radio" name="nCalendarDates" value="4">Quarterly</label> ';
  vmess+='<label style="margin:3px 5px;border:1px solid #998899" title="Add first of month  (for all months in all years)"> <input  '+cal12+'  type="radio" name="nCalendarDates" value="12">Monthly</label> ';

// 1 march 2024 .. weekly not supported
//  vmess+='<label style="margin:3px 5px;border:1px solid #998899" title="Add first of week  (for all weeks in all years)"> <input  '+cal52+' type="radio" name="nCalendarDates" value="52">Weekly</label> ';
  vmess+='</td>';
  vmess+='</tr>';

  vmess+='<tr><td>Display custom dates?  ';
  vmess+='<br><input type="button" title="Click to add a new display date"  onClick="addARowViewDate(this)" value="Add custom date">';
  if (addCurrentDate==1) {
      vmess+='<p><label><input type="checkbox" id="displayDate_currentDate" checked title="Click to always include the current date (that changes when simInv is run again)">Display for (dynamic) Current Date </label> ';
  } else {
      vmess+='<p><label><input type="checkbox" id="displayDate_currentDate" title="Click to always include the current date (that changes when simInv is run again)">Display for (dynamic) Current Date </label> ';
  }
  vmess+='</td>'

   vmess+='<td>';

// the custom dates table ...
  vmess+='<table style="margin:3px 2em;border:1px solid gray" id="viewDatesTable" rules="cols">';
  vmess+='<tr><td style="width:7em">...</td> <td style="width:7em">Year</td> <td style="width:7em">Month</td> <td style="width:7em">Day</td> </tr>';

  for (let ii=0;ii<customDates.length;ii++) {
      let arf=setEntryDate(customDates[ii]) ;
      vmess+='<tr class="viewDateRow">';
      vmess+='<td><input type="button" value="Remove" title="Remove this display date" onClick="removeViewDateRow(this)"></td>';
      vmess+='<td><input name="viewYear" type="hidden" value="'+arf['year']+'"> '+arf['year']+'</td>';
      vmess+='<td><input name="viewMonth" type="hidden" value="'+arf['month']+'">  '+arf['month']+'</td> ';
      vmess+='<td><input name="viewDay" type="hidden" value="'+arf['day']+'"> '+arf['day']+'</td>';
      vmess+='</tr>';
  }
  vmess+='</table>';   // custom dates dable

  vmess+='</td></tr>';   // entry form table
  vmess+='</table>'

  vmess+='</form>';  // the input form col of the main table
  vmess+='</td>';

  vmess+='<td valign="top"  width="20%">'; // preview col of main table

  vmess+='<button onclick="saveViewDates(this,1)">Preview the dates</button> ';
  vmess+='<div title="preview of specified dates" id="previewDatesTable" style="max-height:50vh;overflow:auto;border:1px solid blue;background-color:#dfdfef">preview here!</div>';

  vmess+='</td></tr></table>';   // main table

  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.show('#mainDiv2','show');
  wsurvey.wsShow.hide('#mainDiv3',122);
  $('#mainDiv2').html(vmess) ;
  return 1;
}

//=========================
// reset a first or last year

function createViewDates_reset(ido) {
   let eform=$('#icreateViewDates');

   if (ido==1) {
      let firstYearUse= simInvParams['firstYearUse']  ;
      let firstYearStuff= setEntryDate(simInvParams['firstYearUse'],1,1)
      let eyear1=eform.find('[name="viewYear1"]');    // earliest date
        eyear1.val(firstYearStuff['year']);
      let emonth1=eform.find('[name="viewMonth1"]');
        emonth1.val(firstYearStuff['month']);
      let eday1=eform.find('[name="viewDay1"]');
        eday1.val(firstYearStuff['day']);


   } else {
     let lastYearUse=  simInvParams['lastYearUse'] ;
     let lastYearStuff= setEntryDate(simInvParams['lastYearUse'],12,31)
      let eyear2=eform.find('[name="viewYear2"]');    // latest date
        eyear2.val(lastYearStuff['year']);
      let emonth2=eform.find('[name="viewMonth2"]');
        emonth2.val(lastYearStuff['month']);
      let eday2=eform.find('[name="viewDay2"]');
        eday2.val(lastYearStuff['day']);
   }
   return 1;
}

// ===========
// add row to display dates table
function addARowViewDate(athis) {
      let ethis=wsurvey.argJquery(athis);

      let arf=setEntryDate(true);
      let vmess='';
      vmess+='<tr class="viewDateRow">';
      vmess+='<td><input type="button" value="Remove" title="Remove this display date ..." onClick="removeViewDateRow(this)"></td>';
      vmess+='<td><input name="viewYear" type="text" size="5" value="'+arf['year']+'" title="year"></td>';
      vmess+='<td><input name="viewMonth"  type="text" size="5" value="'+arf['month']+'" title="month"></td>';
      vmess+='<td><input name="viewDay"  type="text" size="5" value="'+arf['day']+'" title="day"></td>';
      vmess+='</tr>';
      $('#viewDatesTable').append(vmess);

      return 1 ;

}

//==================
// remove row from display date table
function removeViewDateRow(athis) {
   let ethis=wsurvey.argJquery(athis);
   let etr=ethis.closest('.viewDateRow');
   etr.remove();
}

//=================
// save display dates info : 'customDates',addEntryDates','addCalendarDates','firstDateAllow','lastDateAllow','addCurrentDate'}

function saveViewDates(athis,ipreview) {

   let eform=$('#icreateViewDates');

   let etable=eform.find('#viewDatesTable');
   let etrs=etable.find('.viewDateRow');

   let eyear1=eform.find('[name="viewYear1"]');    // earliest date
   let year1=jQuery.trim(eyear1.val());
   let emonth1=eform.find('[name="viewMonth1"]');
   let month1=jQuery.trim(emonth1.val());
   let eday1=eform.find('[name="viewDay1"]');
   let day1=jQuery.trim(eday1.val());
   let arf1=setEntryDate(year1,month1,day1) ;
   if (arf1===false) return ;  //  error alert will be shown if improper date
   let firstStamp=arf1.dayCount;

   let eyear2=eform.find('[name="viewYear2"]');     // latewst date
   let year2=jQuery.trim(eyear2.val());
   let emonth2=eform.find('[name="viewMonth2"]');
   let month2=jQuery.trim(emonth2.val());
   let eday2=eform.find('[name="viewDay2"]');
   let day2=jQuery.trim(eday2.val());
   let arf2=setEntryDate(year2,month2,day2) ;
   if (arf2===false) return ;  //  error alert will be shown if improper date
   let lastStamp=arf2.dayCount ;


   let firstYearUse= simInvParams['firstYearUse']  ;
     let firstYearStuff= setEntryDate(simInvParams['firstYearUse'],1,1)
     let firstYearDayCount=firstYearStuff['dayCount'];
   let lastYearUse=  simInvParams['lastYearUse'] ;
     let lastYearStuff= setEntryDate(simInvParams['lastYearUse'],12,31)
     let lastYearDayCount=lastYearStuff['dayCount'];

     if (lastStamp<=firstStamp) {
         alert('First date is before or equal to last date ');
         return false;
     }

// error if firsttamp and lasttamp not in range
   if (firstStamp<firstYearDayCount || firstStamp>lastYearDayCount ||
      lastStamp<firstYearDayCount || lastStamp>lastYearDayCount ) {
          alert('Earliest, or latest, date is outside of the reporting range ('+firstYearUse+' to '+lastYearUse+'). \n The reporting range can be changed in the \u26ED settings menu ');
          return false;
      }

   let stuff=[];

//custom dates
   for (let ie1=0;ie1<etrs.length;ie1++) {
       let erow=$(etrs[ie1]);
       let eyear=erow.find('[name="viewYear"]');
       let ayear=jQuery.trim(eyear.val());

       let emonth=erow.find('[name="viewMonth"]');
       let amonth=jQuery.trim(emonth.val());

       let eday=erow.find('[name="viewDay"]');
       let aday=jQuery.trim(eday.val());

       let vd1=setEntryDate(ayear,amonth,aday);
       if (vd1===false) return 0;  // alert happens if bad year/month/ or day
       let dayCount=vd1['dayCount'];

       let arf0=setEntryDate(simInvParams['firstYearUse'],1,1)
       if (dayCount<=arf0['dayCount']) {
           alert('Chosen date ('+vd1['sayDate']+') is before the Reporting Range, or before the first portfolio\'s creation date.\n You can change the Reporting Range in \u26ED settings');
           return 1;
       }

       let arf1=setEntryDate(simInvParams['lastYearUse'],12,31)
       if (dayCount>=arf1['dayCount']) {
           alert('Chosen date  ('+vd1['sayDate']+') is after the Reporting Range. \nYou can change the Reporting Range in \u26ED  settings)');
           return 1;
       }
       stuff.push(dayCount);
   }

  stuff=sortNoDuplicates(stuff);   // remove duplicates, sort ascending

// now get init/mod and calendar stuff
   let emi=eform.find('[name="naddEntryDates"]');
   let emi1=emi.filter(':checked');
   let vmi=emi1.val();

   let eci=eform.find('[name="nCalendarDates"]');
   let eci1=eci.filter(':checked');
   let vci=eci1.val();

// current date? (4 april 2024)
   let ect1=eform.find('#displayDate_currentDate');
   let acurrentDate=(ect1.is(':checked')) ? 1 : 0 ;

   let nowTime=wsurvey.get_currentTime(0);

   let saves={'customDates':stuff,'addEntryDates':vmi,'addCalendarDates':vci,'firstDateAllow':firstStamp,'lastDateAllow':lastStamp,'addCurrentDate':acurrentDate};

   if (ipreview==1)  {   // preview first
       previewDateList(saves);
       return 0;
  }

   let ddata={'time':nowTime,'data':saves};
   let okmess='Saving: '+stuff.length+' custom view dates, init/mod='+vmi+', calendar='+vci ;

  simInvGlobals['temp']['autoLogonDetails']={'action':'viewDates'} ;
  saveSimInvData_viewDates(userName,ddata,okmess)
   simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

}

//==================
// preview list of datea, given specs
function  previewDateList(asaves0) {

  let doViewDates= buildDateList(asaves0) ;

  let doViewDatesSay=[];
  for (let idd=0;idd<doViewDates.length;idd++) {
      let d1=doViewDates[idd];
      let d1Say=setEntryDate(d1).sayDate;
      let oo1=[d1,d1Say];
      doViewDatesSay.push(oo1);
  }

   let firstDateAllow=asaves0['firstDateAllow'];      // to dsipaly some bounds
   let lastDateAllow=asaves0['lastDateAllow'];
   let oofX=setEntryDate(firstDateAllow);
   let oofX2=setEntryDate(lastDateAllow);

   let firstDateAllowCount=oofX.dayCount ;
   let lastDateAllowCount=oofX2.dayCount ;

  cmess='';
  cmess+='<br>'+doViewDatesSay.length+' dates (bounded by earliest and latest dates). ';

    cmess+='<table cellpadding="3" rules="rows">';
  for (let idd=0;idd<doViewDatesSay.length;idd++) {
     let jdate=doViewDatesSay[idd] ;
     zcolor='black';
     if (jdate[0]<=firstDateAllowCount) {
         cmess+='<tr><td><span title="Equal to, or before, earliest date" style="background-color:#fbeeba;"><tt>'+doViewDatesSay[idd][0]+'</tt></span></td>';
         zcolor='#fbeeba;';
     } else if  (jdate[0]>=lastDateAllowCount) {
         cmess+='<tr><td><span title="Equal to, or after, latest date" style="background-color:#bcb69f;"><tt>'+doViewDatesSay[idd][0]+'</tt></span></td>';
     } else {
          cmess+='<tr><td><tt>'+doViewDatesSay[idd][0]+'</tt></td>';
     }
     cmess+='<td>'+doViewDatesSay[idd][1]+'</tr>';
     cmess+='</tr>';
  }

  let lastYearStuff= setEntryDate(simInvParams['lastYearUse'],12,31)  ;
   cmess+='<tr><td><span style="color:blue" title="final date of reporting range">'+lastYearStuff.dayCount+'</span></td>';
   cmess+='<td>'+lastYearStuff.sayDate +'</tr>';
   cmess+='</tr>';

  cmess+='</table>  ';

  let epreview=$('#previewDatesTable');
  epreview.html(cmess);

  return 1 ;
}

//=================
// build a array of "view dates", given specifications in asaves
// asaves:   {'customDates' ,'addEntryDates' 'addCalendarDates' ,firstDateAllow,lastDateAllow};
// note: all the dates are in "dayCOunt" format (as returned by setEntryDate: # days since jan 2 1970)
// if conly  or eonly specified, just return the "calendar" or "entry" dates (conly is a addCalendarDates value, eonly a addEntryDates value)
// if conly and only =false, asaves shold have propprties (defaults used if a property is not specified)
//    firstDateAllow  lastDateAllow  customDates  addCalendarDates   addEntryDates

function buildDateList(asaves,conly,eonly) {

   if (arguments.length<2) conly=false;
   if (arguments.length<3) eonly=false;

   let   doViewDates0=[];

   let firstDateAllow,lastDateAllow ;         // probably not necessary to check for existenct in asaves, but wth
   if (asaves.hasOwnProperty('firstDateAllow')) {
      firstDateAllow= asaves['firstDateAllow'] ;
   } else {
      let firstYearStuff= setEntryDate( simInvParams['firstYearUse'] ,1,1) ;
      firstDateAllow=firstYearStuff['dayCount'];
   }
   if (asaves.hasOwnProperty('lastDateAllow')) {
      lastDateAllow= asaves['lastDateAllow'];
   } else {
      let lastYearStuff= setEntryDate(simInvParams['lastYearUse'] ,12,31)   ;
      lastDateAllow=lastYearStuff['dayCount'];
   }

   addCdate=0;
   if (asaves.hasOwnProperty('addCurrentDate')) addCdate=asaves['addCurrentDate'];

   if (conly!==false)  {        // asaves is calendar spec - just use it to return calendar dates
     if (conly==0) return [] ;
     let dlist1=buildDateList_cal(conly,firstDateAllow,lastDateAllow,addCdate) ;
     return dlist1;
   }

   if (eonly!==false)  {        // entries only
     if (eonly==0) return [] ;
     let dlist1b=buildDateList_entries(eonly,firstDateAllow,lastDateAllow) ;
     return dlist1b;
   }

// not a calendar, or entry date, only call

// add start and end of "view dates" range (by default, first and last day of range)
   doViewDates0.push(firstDateAllow);               // the "first date in the range"
   doViewDates0.push(lastDateAllow);               // the "last date in the range"

// add custom dates
  if (asaves.hasOwnProperty('customDates') && jQuery.isArray(asaves['customDates']) ) {
      for (let im=0;im<asaves['customDates'].length;im++) doViewDates0.push(parseInt(asaves['customDates'][im]));    // user specified display dates (saved as dayCounts)
  }

// add current date?
   if (addCdate==1) {
       let zadate=setEntryDate(true).dayCount;
       doViewDates0.push(zadate);
   }
// add calendar dates
   let zcal=(asaves.hasOwnProperty('addCalendarDates')) ? asaves['addCalendarDates'] : 1 ;  // ddfault is yearly
   let calList=buildDateList_cal(zcal,firstDateAllow,lastDateAllow,addCdate) ;  // calendar dates, within range bounds
   for (let icc=0;icc<calList.length;icc++) doViewDates0.push(calList[icc]);

// add entry dates
   let zentry=(asaves.hasOwnProperty('addEntryDates')) ? asaves['addEntryDates'] : 2  ;  // default is both
   let entList=buildDateList_entries(zentry,firstDateAllow,lastDateAllow) ;
   for (let icc=0;icc<entList.length;icc++) doViewDates0.push(entList[icc]);


// sort ...
   doViewDates0.sort(mySortNumeric);         // sort

   let doViewDates=[];
// remove duplicates (after sort)   -- and discard out of bounds
  let wasDate=false;
  for (let mm=0;mm<doViewDates0.length;mm++) {
      let zdate=doViewDates0[mm] ;
      if (zdate<firstDateAllow || zdate>lastDateAllow)   continue;
      if (doViewDates0[mm]!==wasDate) {
         wasDate=doViewDates0[mm];
         doViewDates.push(wasDate );
      }
  }
  return doViewDates  ;

//  internal fucntion:  calendar dates (within range)
  function buildDateList_cal(zcal,day1,day2,addCdate) {
    let dlist0=[];

    let year1= simInvParams['firstYearUse']; // actual year, not dayCount!
    let year2= simInvParams['lastYearUse'];

    if (zcal>0)     {          // 0- do not
     for (let kyear=year1;kyear<=year2;kyear++) {
        if (zcal>0)   {    // jan 1
           let oof3=setEntryDate(kyear,1,1);
           dlist0.push(oof3['dayCount']) ;
        }
        if (zcal>1)   {    //  & july 1
           let oof3=setEntryDate(kyear,7,1);
           dlist0.push(oof3['dayCount']) ;
        }
        if (zcal>2)   {    //  & april 1 and oct 1
           let oof3=setEntryDate(kyear,4,1);
           dlist0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,10,1);
           dlist0.push(oof3['dayCount']) ;
        }
        if (zcal>4)   {    //  & feb1  mar1 may1 jun1 aug1 sep 1 nov1 dec1
           let oof3=setEntryDate(kyear,2,1);
           dlist0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,3,1);
           dlist0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,5,1);
           dlist0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,6,1);
           dlist0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,8,1);
           dlist0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,9,1);
           dlist0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,11,1);
           dlist0.push(oof3['dayCount']) ;
           oof3=setEntryDate(kyear,12,1);
           dlist0.push(oof3['dayCount']) ;
        }
        if (zcal>12)   {    //  & 7 14 and 21 of each month (1 march 2024. .. not currently used)
          let oof3;
          for (let kmonth=1; kmonth<=12; kmonth++ ) {
             oof3=setEntryDate(kyear,kmonth,7);
             dlist0.push(oof3['dayCount']) ;
             oof3=setEntryDate(kyear,kmonth,14);
             dlist0.push(oof3['dayCount']) ;
             oof3=setEntryDate(kyear,kmonth,21);
             dlist0.push(oof3['dayCount']) ;
          }     // kmonth
        }    //  zcal >=12
     }            // kyear
   }  //    addEntryDates_yearly   .. for now, don't support weekly (1 March 2024)
   
   let dlist1=[];
   for (ia=0;ia<dlist0.length;ia++) {     // get rid of out of range (coud do above, but wth do it here
       let zday=dlist0[ia];
       if (zday<day1 || zday>day2) continue    ;
       dlist1.push(zday)
   }
   return dlist1;

  }   // end of buildDateList_cal
  
// internal function: add init and (possibly) mod entry dates   from ALL non-hidden portfolios  (within range))
   function buildDateList_entries(edo,day1,day2) {
      let dlist2=[];
      if (edo==0) return dlist2 ;
      for (let app in portfolioLookup['list']) {        // for all non-hidden portfolios (with at least one history entry (aka: with an initializatiion entry)
         if (portfolioLookup['list'][app]['isHidden']==1) continue ;   // skip hidden portfolios
         if (portfolioLookup['list'][app]['nHistory']==0) continue ; // skip portoflios with no entries

         let mdList=portfolioLookup['list'][app]['modDates'];
         if (mdList.length>0) {
            let nadd= (edo==1) ? 1 : mdList.length;        // just get init entry[0], or get all (init & mod) entries
            for (let ii=0;ii<nadd;ii++) {
               let tt1=parseInt(mdList[ii]);
               if (tt1< day1 || tt1>day2) continue ;  // skip if out of range
               dlist2.push(parseInt(mdList[ii]));
            }         // init & mod entries (for this portfolio)
         }   // mdlist
     }    // app
     return dlist2;
   }              // end of buildDateList_entries


}

//===============
// display help
function displayHelpMessage(athis,amess,iforce,ajump) {

  if (arguments.length<3)  iforce=0;
  if (arguments.length<4)  ajump='';

  let other=false;
  let fromDiv;
  if (arguments.length<2 || amess===false || amess==0)  {
    if (typeof(athis)=='string') {
         fromDiv=athis;
    } else {
        let ethis=wsurvey.argJquery(athis);
        fromDiv=ethis.attr('data-div');
    }
    if (fromDiv=='#encryptionKeyHelp1') other='encryptionHelp'


    let efrom=$(fromDiv);
    if (efrom.length==0) {
      alert('bad fromDiv  (help) ('+fromDiv+')');
      return 0;
    }
     amess=efrom.html();

  }
  $('#helpDiv_message').html(amess);

  let ehd=$('#helpDiv');
  ehd.removeClass('cHelpDivSmaller cHelpDivSmall');
  let ebb=ehd.find('[name="toggleSizeButton"]');
  ebb.attr('data-nowsize',1);

  if (iforce==0) {
    wsurvey.wsShow.show('#helpDiv','toggle');
  } else {
    wsurvey.wsShow.show('#helpDiv','show');
  }

  if (ajump!=''){
    window.location.href = "#"+ajump;
  }

  if (other===false) return 1;
  
// do some customizations
 if (other=='encryptionHelp') {
   let cmess;
   if (simInvGlobals['encryptionKey']!='')  {
      cmess='<div style="border:1px dotted green;padding:3px;margin:1em 4em">Hello <tt>'+userName+'</tt>  -- you have <b>enabled</b> encryption!</div>';
   } else {

     cmess='<div style="border:1px dotted green;padding:3px;margin:1em 4em">Hello <tt>'+userName+'</tt>  -- you have <b>not enabled</b> encryption! Note that encryption can only be enabled when you initialize (on your first logon)</div>';
   }

    $('#encryptionHelp_custom').html(cmess).show();
 }

}

//========
// view rmd schedules
function viewRmdSchedules(ifoo) {
  let amess='<b>Required minimum distribution schedules</b><p>';
  amess+='The values are <em>fractions of current asset value</em> distributed (withdrawn and added to <u>Cash</u>).';
  amess+='<div style="margin:9px 3em">For example: if <tt>my401k</tt> (a <b>self</b> tax defered asset) ';
  amess+=' has a value of  <tt>$30,000</tt> in year 2025, and you specified a RMD with start age of 75 in 2023,';
  amess+='<br>... then the fraction would be  <tt>0.044</tt> (the <tt>77</tt> row in the <b>Self fraction</b> column)';
  amess+='</div>';
  amess+='The different schedules: ';
  amess+='<ul><li><b>Self fraction</b>: if this tax deferred asset is yours -- such as a personal IRA';
  amess+='<li><b>Beneficiary fraction</b>: if this tax deferred asset was acquired by ou -- such as an inherited 401k';
  amess+='</ul>';
  amess+='<table cellpadding="5" rules="rows"><tr><th>Age</th><th>Self fraction</th><th>Beneficiary fraction</th>';
  for (let iage=0;iage<130;iage++) {
    if (!rmdBeneficiary.hasOwnProperty(iage) && !rmdSelf.hasOwnProperty(iage)) continue

    let aline='<tr><td><tt>'+iage+'</tt></td>';
    if (rmdSelf.hasOwnProperty(iage)) {
         let aval=rmdSelf[iage];
         let afrac=1/aval;
          aline+='<td><span title="Self RMD schedule value: '+aval+'">'+afrac.toFixed(3)+'</td>';
    } else {
         aline+='<td> ... </td>';
    }
    if (rmdBeneficiary.hasOwnProperty(iage)) {
         let aval=rmdBeneficiary[iage];
         let afrac=1/aval;
          aline+='<td><span title="Beneficiary RMD schedule value: '+aval+'">'+afrac.toFixed(3)+'</td>';
    } else {
         aline+='<td> ... </td>';
    }

    amess+=aline+'</tr>';
  }
  amess+='</table>';
  wsurvey.displayInNewWindow(0,{'content':amess,'cssFiles':'cssLib/simInv.css','name':'rmdShow','title':'RMD schedule values (by age)'});
}

//==========
//toggle size of hgelpt
//1 = normal size (60% of screen), 2= small (30%) = 3=smaller (15%)
function toggleHelpDiv(athis) {
  let ediv=$('#helpDiv');

  let ethis=wsurvey.argJquery(athis);
  let istatus=ethis.attr('data-nowsize');

  ediv.removeClass('cHelpDivSmaller cHelpDivSmall');

  if (istatus==1) {    //  is big, so srhink
      ediv.addClass('cHelpDivSmall');
      ethis.attr('data-nowsize',2);
  } else if (istatus==2) {    //  is smallg, so srhink some more
      ediv.addClass('cHelpDivSmaller');
      ethis.attr('data-nowsize',3);

  } else {                     // reset to big

      ethis.attr('data-nowsize',1);
  }
  return 1;
}

//==========================
// display a response from the server
// autologon: if 0 or not specified, do not auto logon
//   if 1 : generic autoLogon
//    otherwise: logon, and then autolgon AND (after logon) open up a sub menu (as identified by autoLgon)
// if iClear=1 ; clear   simInvSummaryResults={'ngot':0,'list':{},'vars':[]};
//  iClear=1 when assets, portfolios, or scenarios change. It is NOT 0 if a new scenario is selected

function displayResponseFromServer(amess,autologon,iClear ) {
  if (arguments.length<2) autologon=0;
  if (arguments.length<3) iClear=1;        // assume "clear simInvSummaryResults"
  
  if (iClear==1)  {  // clear   simInvSummaryResults
     simInvSummaryResults['ngot']=0;
     simInvSummaryResults['list']={};
     simInvSummaryResults['vars']=[];
     simInvSummaryResults['wstatus']=false;
     simInvSummaryResults['finalMessage']=false;
     simInvSummaryResults['callFinal']=false;
     simInvSummaryResults['recentDisplay']={};

     $('#iexportImport_button_ct').html(0);
  }

  $('#statusDivServerResponse_message').html(amess);

  wsurvey.wsShow.show('#statusDivServerResponse','show');

  $('#statusDivServerResponse_reload').show();
  $('#statusDivServerResponse_button').attr('data-autologon',autologon)  ; // upon reload (or re-logon)- -- open the autologon menu!

  return 1;
}


//=======
// 5 jan 2024 .. doReload is replacing this in most cases...
// logoff
// iAuto=1 : do an auto logon. Otherwise, just show username in username field (user than clicks logon button)
// doAuto: if exists and not 0, do an auto logon  AND trigger button with this id (i.e.'portfoliosTableButton'
//          if doAuto==1, just auto logon
// userMe : optional -- user name to logon as (otherwise, use the current userName)

function doLogoff(iAuto,athis,userMe) {
  let doAuto='0';                     // no autologon (just fill in username )
   simInvGlobals['logonStarted']=false ;                  // set to true by doLogon. Used by monitorStartup

  if (arguments.length>1 && iAuto==2) {
     let ethis=wsurvey.argJquery(athis);
     doAuto=ethis.attr('data-reload');
     doAuto=jQuery.trim(doAuto);
     if (doAuto==='') doAuto='1';  // the id of a button to trigger. '1' means "just logon, don't trigger a button"
  }
  if (arguments.length<3) userMe=userName;
  let oof;
  if (iAuto==2) {      // auto logon using username, and trigger an action button (using its id)
    oof=window.location.protocol + "//" + window.location.host + window.location.pathname+'?username='+userMe+'&autoLogon='+doAuto ;
  } else {
    oof=window.location.protocol + "//" + window.location.host + window.location.pathname+'?username='+userMe ;
 }
  window.location.href = oof;
}

//==========
// a front end to setEntryDate
// read and process the "creation date -- year month day" (on the asset mix menu)
 function getCreationDate(awhere0) {


// 8 dec 2023 .. not worth it to be clever --- always read from   portfolioMenu_initDateBlock
   let awhere= '#portfolioMenu_initDateBlock';
   let ayear,amonth,aday;
   let astatus=wsurvey.dateBox_read(awhere,1) ;
   if (astatus===false) {
      alert('getCreationDate date error: '+awhere);
      return false;
   }
   if (!jQuery.isPlainObject(astatus)) {
      return false;
   }

   ayear=astatus['year'];
   amonth=astatus['month'];
   aday=astatus['day'];
   let d1=setEntryDate(ayear,amonth,aday);
   return d1;

 }

//==============
// view all help topics (in a new window)
function viewAllHelp(athis) {
   let ehelps=$('.helpBox')
   let stuffJumps=[];

   let amess='';
   let topJump='<a href="#allHelpTop">&#8682;</a> ';
   for (let ie=0;ie<ehelps.length;ie++) {
      let ehelp=$(ehelps[ie]);
      let astuff=ehelp.html();
      let adesc=ehelp.attr('data-desc');
      let ajump='allHelp_'+ie ;
      let tt=[ajump,adesc];
        stuffJumps.push(tt) ;

      let bstuff='<div ';
      bstuff+='    style="font-weight:600;background-color:#eaf3ef;padding:3px 5px 3px 5px;margin:8px 5px 5px 2px;border-top:3px groove black">';
      bstuff+='<a name="'+ajump+'">'+topJump+adesc+'</a>';
      bstuff+='</div>';
      bstuff+='<div style="margin:2px 1em 2px 2em;border-left:1px dotted blue;padding-left;5px"> '+astuff+'</div>';
      amess+=bstuff;
   }

   let jumps='<div style="backgrond-color:#e0f9fc;margin:3px 3em;padding:5px;min-height;2em;max-height:10%;overflow:auto">';
   jumps+='<ul class="linearMenu22Pct">';
   for (let ij=0;ij<stuffJumps.length;ij++) {
       let s1=stuffJumps[ij];
        let a1='<a href="#'+s1[0]+'">'+s1[1]+'</a> ';
        jumps+='<li style="overflow:auto">'+a1;
   }
   jumps+='</ul></div>';
   let bmess='<div style="background-color:cyan;padding:5px;margin:1em 3px"><a name="allHelpTop">simInv:</a> help and tips </div>';
   bmess+=jumps;
   bmess+=amess ;
   bmess+='<div style="border-top:2px dashed black;margin-top:1em;font-style:oblique;font-size:90">end of help and tips ...  </div>';

   displayHelpMessage(0,bmess,1);
}


//============
// calcluate tax on earnings of an asset
// anasset: asset name
// forSale: 0 or 1 (dcefault is 0). 0 if this a "earnings" (nterest, etc) tax rate, 1 if a "sales" (cap gains or withdraw from tax deferred)

function calcAsset_taxRate(anAsset,forSale)  {
   if (arguments.length<2) forSale=0;
  let assetType=getAssetType(anAsset);
  if (assetType===false) return false ;
  let ataxRate=parseFloat(simInvParams['taxRate']);            // global (tax rates
  let aCapGainsRate=parseFloat(simInvParams['capGainsRate']);

  if (assetType==0) {
      if (forSale==0) return ataxRate;     // tax on dividends
      return aCapGainsRate ;             // tax on cap gains (sale  - basis)
  }
  if (assetType==1) {          // rgular bonds
      if (forSale==0){
         let taxFreeFrac=parseFloat(doAssetLookup(anAsset,'taxFreeFrac',1));
         return ((1-taxFreeFrac)*ataxRate ) ;
      }
      return 0 ;          // no tax on cashing out regular bonds
  }

  if (assetType==2) {       // tax ceferred bonds
      if (forSale==0) return 0 ;         // no tax on interest earnings (at time of occurence0
      return ataxRate ;                        //   tax on  full value when cashing out tax-deffered  bonds
  }

  if (assetType==3)  {                   // property
      if (forSale==1) {
         let taxFreeFrac=parseFloat(doAssetLookup(anAsset,'taxFreeFrac',1));
         return ((1-taxFreeFrac)*aCapGainsRate ) ;
      }
      return ataxRate ;       // netRevenue
  }

  if (assetType==4 || assetType==5 || assetType==6  )  {                   // income
      if (forSale==0){
         let taxFreeFrac=parseFloat(doAssetLookup(anAsset,'taxFreeFrac',1));
         return ((1-taxFreeFrac)*ataxRate ) ;
      }
      return 0 ;                        //   income streams can not be sold, so this should never happen
  }

  if (assetType==7  )  {                   // expense
       let taxFreeFrac=parseFloat(doAssetLookup(anAsset,'taxFreeFrac',1));
       return (taxFreeFrac *ataxRate)  ;
  }

}


//============
// calcluate tax on earnings (or sale) of an asset
function calcAsset_taxAmount(anAsset,aValue,forSale) {
  if (arguments.length<3) forSale=0;
  let daRate ;
  if (anAsset=='*capgains') {              // do NOT apply "tax free fraction" (that should be done when determmning avalue)
      daRate=parseFloat(simInvParams['capGainsRate']);
  } else if (anAsset=='*taxdeferred') {
      daRate=parseFloat(simInvParams['taxRate']);
  } else {
     daRate=calcAsset_taxRate(anAsset,forSale);     // can apply  "tax free freaction"
  }
   let daVal=daRate*parseFloat(aValue);

   return daVal
}

//============
// calcluate the "Taxable capital gains" for  an asset -- using its sale price and it basis
// for bonds (Rgulear and tax deferred)-- this is always 0. Also 0 for income streams

function calcAsset_capGainsAmount(anAsset,aValue,abasis) {
  let assetType=getAssetType(anAsset);
  if (assetType===false) return false ;
  if (assetType==1 || assetType==2 || assetType==4 || assetType==5 || assetType==6 || assetType==7) return 0 ;        // these are NOT subject to capital gains. Note that "2" is subject to regular tax
  let capGains0=parseFloat(aValue)-parseFloat(abasis);
  let att =doAssetLookup(anAsset,'taxFreeFrac',1);
  let taxFreeFrac=(att===false || att==='false') ? 0 :  parseFloat(att);
  let daAmount=(1-taxFreeFrac)* capGains0    ;
  return daAmount ;
}

//=================
// confirm a close of a box (used by displayResponseFromServer
// note use of athis -- it is used gby wsShow.hide
function closeConfirm(athis,iwait) {
   let ethis=wsurvey.argJquery(athis);
   let amess=ethis.attr('data-message');
   let q=confirm(amess);
   if (!q) return 0;         // don't hice box
  let aid1=ethis.attr('data-wsshow');

   wsurvey.wsShow.hide(aid1,iwait);
}




//============
// view and set inflation (CPI) info
function doSetInflation(athis) {
     
  let amess='';
    amess+='<div style="border-bottom:1px solid blue;margin:5px 5px 1em 5px;padding:3px 5px 5px 5px">';
    amess+=' <button title="Tips" onClick="displayHelpMessage(this)" data-div="#inflationSeriesHelp1">&#10068;</button>';
    amess+=' <b>Inflation series (by default, CPI-U)</b>. ';
    amess+='You can  <button>Replace</button> or  <input class="cdoButtonRegular" type="button" value="add" onClick="doSetInflation2(this)"> values ... ';
    amess+=' and then <input class="cdoButtonRegular" type="button" value="save the changes" onClick="doSetInflation3(this)" > ';
   amess+=' <span style="float:right;margin-right:2em"> <em> or ... </em>  ';
    amess+='<button class="cdoButtonRegular" onClick="doViewInflation1(this)"> View the working series</button> (with imputed values) ';
    amess+='</span>';
   amess+='</div>';

  displayStatusMessage('....');
  toggleStatusMessage(0,0);
  let mheight=$('#statusDiv').height();
  let mheight2=parseInt(0.84*mheight);

  amess+='<div id="iInflationTableDiv" style="border:5px solid blue;height:'+mheight2+'px;overflow:auto">';
  amess+='<table id="iInflationTable" rules="rows" cellpadding="6">';
  amess+='<tr id="iInflationTableHeader"><td>...</td><td>Date</th><th>CPI value</th></tr>';
  for (let iday in simInvGlobals['cpiuSeries']) {
     amess+='<tr class="inflationRow"> ';
      let oof=setEntryDate(iday);
      let sayDate=oof['sayDate'];
      amess+='<td><input type="button" value="Replace" title="replace this date`s value" onClick="doSetInflation_replace(this)"></td>';
      amess+='<td><span name="theDate" data-value="'+iday+'"  title="dayCount: '+iday+'">'+sayDate+'</span></td>'
      amess+='<td><span name="theValue" data-value="'+simInvGlobals['cpiuSeries'][iday]+'">'+simInvGlobals['cpiuSeries'][iday].toFixed(1)+'</span></td>';
      amess+='<tr>';
  }
  amess+='</table>';
  amess+='</div>';
  displayStatusMessage(amess);
  toggleStatusMessage(0,0);

}

function doSetInflation2(athis) {
   let a1='<tr class="cpiRow">';
   a1+='<td>Date: <tt>Year Month</tt> <input name="newCpiDate" type="text" title="year, month. Example: `2024, 6` for June 2024" size="8"></td>';
   a1+='<td>Amount: <input name="newCpiAmount" type="text" title="CPI (1984=100)" size="8"></td>';
   a1+='</tr>';
   let etable=$('#iInflationTable');
   etable.append(a1);

   let ediv=$('#iInflationTableDiv');
   let ath=ediv.prop("scrollHeight");

   ediv.animate({ scrollTop: ath}, 700);
  return 1;
}

//=======
// save changes to cpiuSeries
function  doSetInflation3(athis) {
   let etable=$('#iInflationTable');
   let enews=etable.find('[name="newCpiDate"]');

   if (enews.length==0) {
      alert('You did not specify any new changes');
      return 0;
   }
   let changes=[];
   for (let inn=0;inn<enews.length;inn++) {
       let eb=$(enews[inn]);
       let bval=jQuery.trim(eb.val());
       if (bval=='') continue ;
       let goo=wsurvey.getWord(bval,0, /[\,\s]+/);
       if (goo.length<2) goo[1]=1;  // assume jan
       let oof=setEntryDate(goo[0],goo[1],1);
       if (oof===false) return 0;
       let dayCount=oof['dayCount'];
       let sayDate=oof['sayDate'];
       let etr=eb.closest('.cpiRow,.inflationRow') ;
       let eamount=etr.find('[name="newCpiAmount"]');
       let amount=jQuery.trim(eamount.val());
 

       if (amount=='') continue ;

       if (!jQuery.isNumeric(amount)) {
          alert('Non-numeric value for CPI ');
          continue;
       }
       let aa=[sayDate,dayCount,amount];
       changes.push(aa);
   }
   if (changes.length==0) {
      alert('No changes were made');
      return 0;
   }


   for (let ii=0;ii<changes.length;ii++) {
        let idate=changes[ii][1];
        let aval=changes[ii][2];
        simInvGlobals['cpiuSeries'][idate]=parseFloat(aval);    // might overwrite existing
   }
   let a1=[];                 // make sure in asceding order and no dups
   for (let idate in simInvGlobals['cpiuSeries']) a1.push(idate);
   let oof=sortNoDuplicates(a1);

   let cpiuTmp={};
   for (let ii=0;ii<oof.length;ii++) {
      let idate=oof[ii];
      cpiuTmp[idate]=simInvGlobals['cpiuSeries'][idate];
   }
   
   simInvGlobals['cpiuSeries']=cpiuTmp;
    let last1=oof[oof.length-1];
    let oofD=setEntryDate(last1);
   let vmess='You added (or changed) '+changes.length+'  entries, and there are now '+oof.length+' entries, in the CPI series (the last entry is on '+oofD.sayDate+')';
//   vmess+='<p>You can <input type="button" value="Save them!" onClick="personalSettings(2)">';
   vmess+='<p>You can <input type="button" value="Save them!" onClick="saveCpiuSeries(1)">';

   displayStatusMessage(vmess);

}

//==========
// replace a value
function  doSetInflation_replace(athis) {
    let ethis=wsurvey.argJquery(athis) ;
    let erow=ethis.closest('.inflationRow');
    let edate=erow.find('[name="theDate"]');
    let adate=edate.attr('data-value');
    let evalue=erow.find('[name="theValue"]');
    let avalue=evalue.attr('data-value');

    let oof=setEntryDate(adate);
    let ayear=oof.year,amonth=oof.month;
   a1=' <br> <input name="newCpiDate" value="'+ayear+' '+amonth+'" type="text" title="year, month " size="8"></td>';
   edate.after(a1);
   a2=' <br> <input name="newCpiAmount" type="text" title="CPI (1984=100)" value="'+avalue+'" size="8"></td>';
   evalue.after(a2);
}
// ===========
// save the curent (perhaps just changed) cpiuSeries
function saveCpiuSeries(ifoo) {
  let oof={},aa={};

  simInvGlobals['temp']['autoLogonDetails']={'action':'cpiuSeries'} ;
  saveSimInvData_cpiuSeries(userName,simInvGlobals['cpiuSeries'],'cpiuSeries updated ');
   simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

  return ;
}

//===================
// view the cpiuSeriesUse series
// each cpiuSeriesUse row is: [dayCount,year,cpi,dailyInflationRate,yearlyInflationRate,imputeFlag,scenarioFlag,cumInf_2023]
function doViewInflation1(athis) {

   let bmess='';
   bmess+='<input title="Return to setInflation menu" type="button" value="&lArr;" onClick="doSetInflation(this)">';
   bmess+=' These inflation values are used by simInv -- they may include imputed values (for years after the last explicit inflation entry)';
   bmess+='<table rules="rows" cellpadding="5">';
   bmess+='<tr><th>Date</th><th>CPI (cumulative)</th><th>Yearly inflation rate</th><th>Source?</th>';


   for (let ii=0; ii<simInvGlobals['cpiuSeriesUse'].length;ii++) {
       acc=simInvGlobals['cpiuSeriesUse'][ii];
       let idate=acc[0];
       let sayDate=setEntryDate(idate).sayDate ;
       let acpi=acc[2].toFixed(1);
       infPct=(acc[4]-1)*100;
       let sayInf=infPct.toFixed(1);
       let isImputed=acc[5];
       let isScenario=acc[6];
       let impSay;
       if (isImputed==0 && isScenario==0) {
            impSay='From CpiU series ';
       } else if (isImputed==0 && isScenario==1) {
            impSay='From Scenario ';
       } else if (isImputed==1 && isScenario==0) {
           impSay='Imputed from series ';
       } else {
           impSay='Imputed from scenario ';
       }

       bmess+='<tr><td>'+sayDate+'</td><td>'+acpi+'</td><td>'+sayInf+'</td><td>'+impSay+'</td></tr>';
   }
   displayStatusMessage(bmess);

}


//======================
// return asset type info by asset name
//  aname: name of asset.
//          Or "0","*sto",  "1","*bon", "2","*tax" , "3","*pro", "4","*inc" ,"5","ann","6","one","exp"
//          If not 0,1,2,3,4,5,6,7 the first 4 characters (case insensitive) are used  -- if the first is not a '*', then this must be the name
//          of an existing asset
//  Special case: aname='*icons' : return array of icons [0,..,7]
//                      '*iconsLong'  : return array of icons + name  [0,..,7] .

// return depends on ahow
//   ahow:  'type' : a 0,1,2,3,4,5,6,7 depending on type of asset. This is the default (if ahow is not specified)
//   ahow : 'say' (or 1) :  a &xxx;aaa string of the type of this asset.
//   ahow : 'saysimple'  :  a  aaa string of the type of this asset (eg; 'bond' or 'stock').
//    ahow: sayslong   : a longer string naming this asset (could be more than one word)
//   ahow : 'icon'  : a &xxx; string (icon of the asset type)
//   ahow : 'iconSpan'  : a &xxx; string (icon of the asset type), surrounded by <span title="asset type'> ...</span>
// returns false if an error (such as a non existing asset, or a *xxx with xxx not one of sto bon tax pro inc.

function getAssetType(aname,ahow) {

    if (arguments.length<2) ahow='type';
    ahow=jQuery.trim(ahow).toLowerCase();

    let asays=['&#127480;tock','&#127463;ond','&#127299;axDefer','&#127477;roperty','&#127470;ncome','&#66304;nnuity','&#120793;off','&#66308;xpense'];
    let aicons=['&#127480;','&#127463;','&#127299;','&#127477;','&#127470;','&#66304;','&#120793;','&#66308;'];
    let alooks={'sto':0,'bon':1,'tax':2,'pro':3,'inc':4,'ann':5,'one':6,'exp':7 } ;
    let asaysSimple=['Stock','Bond','TaxDefer','Property','Income','Annuity','OneOff','Expense'];
    let asaysLong=['Stock','Bond (regular)','Bond (tax deferred)','Property','Income stream','Annuity','oneOff receipt','Expense stream'];

    aname=jQuery.trim(aname);
    if (aname=='*icons') return aicons ;  // special case
    if (aname=='*iconsLong') return asays ;  // special case
    if (aname=='*sayLong') return asaysLong ;  // special case

    let iuse=false;
    let a1=aname.substr(0,1);


    if (a1=='*') {      // *xxx pnemonic for assetType ?
        let a2=a1.substr(1,3).toLowerCase();
        if (!alooks.hasOwnProperty(a2)) {
           alert('getAssetType error: unrecognized asset type: '+a1);
           return false  ;
        }
        iuse=alooks[a2];
    } else if (jQuery.isNumeric(a1)) {    // number for generic asset type
        iuse=parseInt(a1);
        if (iuse<0 || iuse>45) {
           alert('getAssetType error: assetType must be 0,1,2,3, 4 ,5, 6, or 7');
           return false ;
       }
    }

    if (iuse!==false) {  // a generic type
        if (ahow=='icon') return aicons[iuse];
        if (ahow=='iconspan') {
          let ticon=aicons[iuse];
          let t2='<span title="'+asaysLong[iuse]+'">'+ticon+'</span>';
          return t2;
        }
        if (ahow=='saysimple') return asaysSimple[iuse];
        if (ahow=='sayslong') return asaysLong[iuse];
        if (ahow=='say') return asays[iuse];
        return iuse ;
    }

// a named asset: get the asset family
   let aname0=aname;
   let aname1=getAssetFamily(aname0,1);
     aname=aname1['family'];
   if (aname1['variant']!='') aname+='.'+aname1['variant'];

    if (!assetLookup.hasOwnProperty(aname)) return false;
    iuse=doAssetLookup(aname,'assetType','i');
    if (iuse===false) {
        alert('getAssetType error: unknown asset: '+aname0);
        return false ;
    }
    if (ahow=='icon') return aicons[iuse];
    if (ahow=='iconspan') {

          let ticon=aicons[iuse];
          let t2='<span title="'+asaysLong[iuse]+'">'+ticon+'</span>';
          return t2;
     }

    if (ahow=='saysimple') return asaysSimple[iuse];
    if (ahow=='sayslong') return asaysLong[iuse];
    if (ahow=='say') return asays[iuse];
    return iuse;

}

//====================
// return the "asset family" of an asest
//  family.sceanario
// if iall=1 return {'family':,'variant' }  variant a  often '';
//   otherwise just return family as a string

function getAssetFamily(anAsset,iall) {

   if (arguments.length<2) iall=0;

    let tt1=anAsset.split('.');
    if (tt1.length>2) {                    // no more $xxx for income variants (9/22/2023)
       alert('getAssetFamilyError: improper assetName (too many .): '+anAsset);
       return false;
    }

    let afamily=jQuery.trim(tt1[0]);
    if (iall!=1)  return afamily;         // just the fmaily

// return family, variant
    let vv={'family':afamily,'variant':'' };

    if (tt1.length==1) return vv;

   if (tt1.length==2) {
      if (tt1[1].substr(0,1)=='$')  {       // no variant, but a variant
         alert('getAssetFamily : variants deprecated ');
        return false;
      }
      vv['variant']=tt1[1];
      return vv;
   }

}


//============



//================
// retrieve assetLookup variable == by family
// avar=* return the object, otherwise return variable name in object
// toNumber=1 or f : parsefloat result. or 2 or  'i' for parseInt
function doAssetLookup(anAsset,aVar,toNumber0,quiet) {
  if (arguments.length<3) toNumber0=0;
  if (arguments.length<4) quiet=0;
  let tt0=getAssetFamily(anAsset,1);
  aname=tt0['family'];
  if (tt0['variant']!='') aname=aname+'.'+tt0['variant'];

  if (aVar=='*') {
     if (!assetLookup.hasOwnProperty(aname)) return false ;
     return   assetLookup[aname] ;
  }

  if (!assetLookup.hasOwnProperty(aname)) {
     if (quiet!=1) showDebug(assetLookup,'doAssetLookup: no such assetname= '+anAsset+' ... family= '+aname,1);
     let zz=zz3/3;  // force error
     return false;
  }

  if (!assetLookup[aname].hasOwnProperty(aVar)) return false ;

 let aval= assetLookup[aname][aVar] ;
 if (!jQuery.isNumeric(aval)) return aval;   // not numeric, dont try parsefloat or parseint
 let toNumber=jQuery.trim(toNumber0).toLowerCase() ;
 if (toNumber=='1' || toNumber=='f') aval=parseFloat(aval);
 if (toNumber=='2' || toNumber=='i') aval=parseInt(aval);
 return aval;
}

//=================
// fit atable ('tableId') into mainDiv3. If atable not specified, jsut fit maindiv3
function fitInMainDiv3(atable) {
  if (arguments.length<1 || atable=='') atable=false;

 let wh1=$(window).height();
 let wh2=$(window).outerHeight();
 let wh3=$(window).prop('scrollHeight');

 let oy1=$('#mainDiv');
 let oy3=$('#maindiv3');
 if (atable!==false)   oyTable=$('#'+atable);

 let h1=oy1.height();
 let h2=oy1.outerHeight();
 let h3=oy1.prop('scrollHeight');
 let s1=oy1.scrollTop();
 let t1=oy1.position().top;
 let availHeight=wh1-t1;

 let s1a=parseInt(0.95*availHeight);
 let s1b=parseInt(0.90*s1a);
 let s1c=parseInt(0.95*s1b);
 oy1.height(s1a+'px');
 oy3.height(s1b+'px');
 if (atable!==false) oyTable.css({'max-height':s1c+'px' });

 if (wsurvey.isScrollable(oy1)) {
    let s1b2=parseInt(0.96*s1b);
    oy3.height(s1b2+'px');
    let s1c2=parseInt(0.96*s1c);
    if (atable!==false) oyTable.css({'max-height':s1c2+'px','border-bottom':'2px dotted lightgray','padding':'2px 1px 5px 1px'});
   if (wsurvey.isScrollable(oy1)) {
      let s1b2=parseInt(0.92*s1b);
      oy3.height(s1b2+'px');
      let s1c2=parseInt(0.92*s1c);
      if (atable!==false) oyTable.css({'max-height':s1c2+'px','border-bottom':'2px dashed lightgray','padding':'3px 1px 5px 2px'});
   }
 } else {
      if (atable!==false) oyTable.css({ 'padding':'3px 1px 2px 2px'});
 }
 return 1;
}




//======================
// copy contents of a div to clipboard, and note success
// paste assetResults area to clipboard, and show message
function simInv_div_Mark(athis) {
  let ethis=wsurvey.argJquery(athis);
  let adiv=ethis.attr('data-div');
  let agotit=ethis.attr('data-gotit');
  if (typeof(agotit)=='undefined') agotit=false ;

  let e1=$('#'+adiv);
  if (e1.length==0) {
     alert('simInv_div_Mark error: no such id='+adiv);
     return 0;
  }

  let astuff=jQuery.trim(e1.text());

  navigator.clipboard.writeText(astuff).then(
    () => {
       if (agotit!==false) {
          let e2=$('#'+agotit);
          if (e2.length==0)   {
              alert('simInv_div_Mark error: no such (status) id='+agotit);
              return 0;
          }
          e2.show();
       }

    },
    () => {
      // clipboard write failed
    }
  );
}


//=======
// hide the header line
//=======
// hide the header line, and display the "redisplay" button and message
function hidePortfolioHeader(ido,asay) {
  if (arguments.length<2) asay='...';

   let eheader=$('#mainDivHeader');
   eheader.css({'opacity':0.1});
   if (ido==1) {
     eheader.fadeOut(500);
   } else {
      eheader.fadeOut(4);
   }

   let eRedisplay=$('#redisplayHeaderButton');
   eRedisplay.show();

   let eRedisplaySay=$('#redisplayHeaderSay');
   eRedisplaySay.show();
   eRedisplaySay.html(asay);

}

//=======
// rddisplay the header line
function redisplayHeaderLine(athis) {
  let eheader=$('#mainDivHeader');
  eheader.css({'opacity':1.0});
  eheader.show();
  let eRedisplay=$('#redisplayHeaderButton');
  eRedisplay.hide();
   let eRedisplaySay=$('#redisplayHeaderSay');
   eRedisplaySay.hide();

}

//=----------
// esc handler
// if nothing left to hide, reshow header line
function simInvEsc(athis) {
   let ff=wsurvey.wsShow.hideRecent();
   if (ff==0) redisplayHeaderLine(1);
}


//===================
// make a md5 of encryption key, for use with siminv
function simInv_makeEncMd5(akey) {
  let k1= (akey!='') ? md5('simInv_'+akey) : '' ;  // use '' if blank key (that is, no encryptio)
  return k1;
}
