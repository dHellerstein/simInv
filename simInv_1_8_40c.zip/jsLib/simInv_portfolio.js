// portfolio, and portfolio mod, functions

//=============
// find the "baseentry" -- the entry that is "most recent" given a desired date -- for a portfolio
// If 2 args, ith is the modfication entry to change (so no need to do a date search)
// If >2, use theModDate to find entry to modify .
//       and use matchOkay to allow entry to modify to be an existing entry

function portfolio_findBaseEntry(pname,ith,theModDate,matchOkay) {

   let rets={'status':'error','message':'an error',
              'pname':false,'baseDate':false,
             'ith':false,'nextIth':false,'qExact':false,
             'growDays':false,'modDate':false,'modDateSay':false,
             'assets':false,'entry':false };

   let ithBase=false,isAdd='add',qExact=false ;
   let theModDateSay ;

   if (!portfolioInit.hasOwnProperty(pname)) {   // should never happen
        rets['message']='This portfolio ('+pname+') has not been initialized (no initialization)';
        return rets;
   }
   rets['pname']=pname;

   let aLookup=portfolioLookup['list'][pname];       // the existing specifications (init and modifications) of this porfolio

   let nMods= aLookup['nHistory'];
   if (nMods==0) {
        rets['message']='This portfolio ('+pname+') has NOT been initialized (no entries) ';
        return rets;
   }

   let modDates=aLookup['modDates'];        // array of init and mod dates. [0] is init date. If length=0, not initialized!
   let origDate=aLookup['creationDate'] ;           // initialization date of portfolio (mods MUST be AFTER this date)
   let origDateSay=aLookup['creationDateSay'] ;

    if (arguments.length==2)    {       // modify existing
        if (ith==0) {          // should never happen
          rets['message']='Can NOT modify the initialization entry (for '+pname+')' ;
          return rets;
        }
        if (ith>=modDates.length) { // should never happen
          rets['message']='Bad modification entry # = '+ith ;
          return rets;
        }
        let daStamp=modDates[ith];        // ithBase could be the initialization (0) --
        rets['ith']=ith;
        rets['qExact']=1;
        rets['baseDate']=daStamp;
        rets['assets']= aLookup['assetsList'][daStamp];
        rets['entry']=portfolioModifications[pname][daStamp];     // use the dateStamp, not ithUse, as the index

        rets['growDays']=0;  // 0 means exact match

        rets['nextIth']=ithBase+1  ;

        rets['modDate']=daStamp ;
        let oof=setEntryDate(daStamp);
        rets['modDateSay']=oof.sayDate ;
        rets['message']='' ;
        rets['status']='existing';

        return rets;
    }        // modify existing

// a new modification (if matchOkay=0, must not be a date that already has a modification)

    let oof=setEntryDate(theModDate);
    theModDateSay=oof['sayDate'];
    if (theModDate<origDate) {
             rets['message']='The specified modification date ('+theModDateSay+') must be after the creation (the initialization date) of portfolio '+pname+'  ('+origDateSay+')';
             return rets;
     }
     let isMatch=jQuery.inArray(theModDate,modDates);    // is there a modification on this date?  -1 if there is NOT
     if (isMatch==0)   {          //  should be caught above... but wth
           rets['message']='The modification date ('+theModDateSay+') MUST be after the creation (the initialization date) of portfolio '+pname+'  ('+origDateSay+')';
           return rets;
     }
     if (isMatch>0 && matchOkay==0  )   {          //  require  special button to modify existing entry   ?
           let aamess='There already is a modification for portfolio '+pname+' on this date ('+theModDateSay+')';
           aamess+='\n To change an existing modification: use its \uD834\uDF21  button > ';
           rets['message']=aamess;
           return rets;
     }
     if (isMatch>0 && matchOkay==1  )  {
            ithBase=isMatch;
            qExact=true;
     } else {
           ithBase=find_closestDate(modDates,theModDate);  // find the mod (or init) closest to theModDate
           if (ithBase===false) {        // false not the same as 0 !    -- should never happen
              rets['message']='Unable to find a date before '+theModDateSay;
              return false ;
            }
            qExact=false;
     }

     if (nMods>1 && ithBase!=nMods-1 ) {              // inbetween
          if (simInvParams['warningLevel']==0) {
            let lastModDate1=modDates[nMods-1];
            let oof0=setEntryDate(lastModDate1);
            let aamess='Caution: the modification date ('+theModDateSay+') is between the creation date and the last existing modification  ('+oof0['sayDate']+').';
             aamess+='\n This can cause unexpected changes in the values of existing modifications (that occur after '+theModDateSay+').';
             aamess+='\nAre you sure you want to make this modification? ';
            let qq=confirm(aamess);
            if (!qq) {
               rets['status']='cancel';
               return rets;
            }
            isAdd='addBetween';
          }     // warning level

      }     // between


// got a baseentry (init or a mod)   !

    let closestStamp=modDates[ithBase];        // ithBase could be the initialization (0) --
    rets['ith']=ithBase;
    rets['qExact']=qExact;
    rets['baseDate']=closestStamp;
    rets['assets']= aLookup['assetsList'][closestStamp];
    if (ithBase==0)   {  // the initializaton entry is the base
       rets['entry']=portfolioInit[pname];
     } else {                         // a modification is the base
       rets['entry']=portfolioModifications[pname][closestStamp];     // use the dateStamp, not ithUse, as the index
     }
     rets['status']=isAdd;

     rets['growDays']=theModDate-closestStamp;  // 0 means exact match

     if (ithBase<(nMods-1))  rets['nextIth']=ithBase+1  ;

     rets['modDate']=theModDate ;
     rets['modDateSay']=theModDateSay ;
     rets['message']='' ;
     return rets;

}          // portfolio_findBaseEntry

//=============
// show portfolio table, and+ allow adding new portfolio
function showPortfolioTable(athis) {

  redisplayHeaderLine(1);

  let amess='';

  let nHidden=0;
  for (let jj=0;jj<portfolioList.length;jj++) {
      if (portfolioList[jj]['isHidden']==1 ) nHidden++ ;
  }

  amess+='<div style="background-color:tan;font-weight:600">';
  amess+='<input type="button" value="x" onClick="wsurvey.wsShow.hide(this,200)" data-wsShow="#mainDiv3"> ';
  amess+='<span class="biggerName">&#128144; Portfolios</span> ';

  amess+=' <em>You can  </em> <button class="cdoButtonTan" onclick="addARowPortfolio(this)">Add</button> new <em>or</em> ';
  amess+=' <button>Remove </button>  existing &hellip; ';
   amess+=' and then <button   title="Save your changes" >Save!</button>   ';
   amess+='&boxV;  ';
   amess+='<em>Or </em> ...  ';
  amess+=' <button>&#127553;</button> view  asset mix. &boxv; ';
  amess+='<input type="button" value="&#128393;">Modify  asset mix  &boxv;  ';
  amess+=' <button style="background-color:lime">Init</button> initialize an asset mix &boxv; ';
  amess+=' <span class="cnAssetsInPortfolio" title="n: # of assets in this portfolio" >&#128065;</span>Preview asset mix</span>  ';
  amess+='</div>';

  amess+='<div id="portfolioTablePreview" class="cportfolioTablePreview"></div>';

  amess+='<div id="portfolioTableOuter" style="max-height:70%; overflow:auto;margin:0.9em">';
  amess+='<table  border="1" id="portfolioTable" width="95%"   class="cportfolioTable">';

  amess+='<tr class="headerRow">';

  amess+='<td width="24%" > ';
  amess+='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioTableHiddenHelp">?</button>';
  amess+=' <button class="cHideButton" style="font-size:90%" data-show="1" title="Toggle view of hidden portfolios" onclick="showHiddenPortfolios(this)">Hide '+nHidden+'</button>';
  amess+='<button class="cdoButtonTan"  title="Click to add a new row" onClick="addARowPortfolio(this)">Add</button>';
    amess+=' <button class="csaveButton" title="Add new, or remove existing,  portfolios" onClick="saveAllPortfolios(this)">Save!</button>';
  amess+='</td>';

  amess+='<th width="17%" > <span class="choiceNameSay">Name</span> ';
    amess+='<button title="Tips" onClick="wsurvey.wsShow.show(this)" data-wsShow="#portfolioTableHelp1">&#10068;</button>';
  amess+='</th>';
  amess+='<th width="25%"  > <span title="Short description">Desc</span></th>';
  amess+='<th width="32%"  > <span title="Long description">DescLong </span></th>';
  amess+='</tr>';

  amess+='<tr id="portfolioTableHelp1" style="display:none" >';
  amess+='<td  >&hellip;</td>';
  amess+='<td colspan="4">';
  amess+='<ul><li><b>Name</b>:a short name.<br>';
  amess+='It can <u>not</u> contain any of the following characters:<tt> ';
  amess+=' embedded spaces, commas, %,  &, +, *, /, \\, \', ", `, #, !, $, <, >, </tt> or  <tt> | </tt>' ;
  amess+='<br>The Name can include a <tt>family</tt> and (optionally) a <tt>.variant</tt>. Example: <span style="border:1px solid black"><tt><b>mystocks</b>. <em>goodTimes</em></tt></span>';

  amess+='</tt>';
  amess+='<li><b>Desc</b> a several word phrase describing this portfolio.';
  amess+='<li><b>DescLong</b> a longer description (no html)';
  amess+='</td> ';
  amess+='</tr>';

  for (let i1=0;i1<portfolioList.length;i1++) {

    let aportfolio=portfolioList[i1];
    let pname=aportfolio['name'];
    let exists=aportfolio['exists'] ; // 0= not initialized
    let isHidden=aportfolio['isHidden'] ;

    let isInit=0,nHistory=0;
    if (exists==1) {
         alookup=portfolioLookup['list'][pname];
         isInit=alookup['isInit'];
         nHistory=alookup['modDates'].length ;
    }
    if (isHidden==0) {
       amess+='<tr class="portfolioRow"  data-exists="1" data-hidden="0" data-remove="0" data-name="'+pname+'">';
    } else {
       amess+='<tr class="portfolioRow cHideThisPortfolio"   data-exists="1"   data-hidden="1" data-remove="0"  data-name="'+pname+'">';
    }
    amess+='<td><span data-_sortUse="'+nHistory+'"  >';
    if (isHidden==0) {
       amess+=' <button data-status="0" title="hide this portfolio " onclick="hidePortfolioRow(this)">&nbsp;Hide&nbsp;</button> '
    } else {
       amess+=' <button data-status="1"   class="cHiddenPortfolioSpan"   title="hide this portfolio " onclick="hidePortfolioRow(this)">&nbsp;unHide&nbsp;</button> '
    }
    amess+='  <input type="button" value="Remove" title="remove this portfolio" onClick="removePortfolioRow(this,1)"></span>';

    if (isInit>0) {
      let  nHist2=nHistory-1;
      if (nHist2>0) {
        amess+='<input type="button" value="&#127553; '+nHistory+'" title="View  the initial, or '+nHist2+' modifications,  asset mix(es) of this portfolio\nAnd you can add a modification! "  ';
        amess+='   class="cshowPortfolioViewModify"  data-name="'+pname+'" onClick="showPortfolioViewModify(this,1)"  >';
      } else {
        amess+='<input type="button" value="&#127553; '+nHistory+'" title="View   the initial  asset mix(es) of this portfolio\nAnd you can add a modification! "  ';
        amess+='    class="cshowPortfolioViewModify"   data-name="'+pname+'" onClick="showPortfolioViewModify(this,1)"  >';
      }

      amess+='<input type="button" value="&#128393;"  title="Shortcut: modify the asset mix of this portfolio  "  ';
      amess+='     data-name="'+pname+'" onClick="showPortfolioViewModify(this,3)"  >';

    } else {
      amess+='<input class="cshowPortfolioViewModify"  type="button" style="background-color:lime" value="&#9998;Init" title="Initialize this portfolio (what assets it contains)"  ';
      amess+='     data-name="'+pname+'" onClick="buildPortfolioMenu_create(this,0)"  >';    // basic menu, for initialiastion
    }
    amess+='</td>';

    amess+='<td data-_sortuse="'+pname+'"><span name="portfolioName" data-name="'+pname+'" data-dog="snappy" class="cNameSay1">';

    let xaname=getAssetFamily(pname,1);
    let pnameSay='<b>'+xaname['family']+'</b>';
    if (xaname['variant']!='')  pnameSay+='. <span title="The variant"><em>'+xaname['variant']+'</em></span>';

    amess+=pnameSay;
//    amess+=pname;


    let cdateSay='',cdate=0 ;

    if (nHistory>0) {
      cdate=portfolioInit[pname]['dateStamp'];
      cdateSay=portfolioInit[pname]['dateStampSay'];

      let jassets=portfolioInit[pname]['totals']['nAsset'] ;

       amess+=' <button class="cshowPortfolioTablePreview"  value=""   title="Preview: assets, and incomeStream & annuities, in this portfolio" onClick="showPortfolioTablePreview(this)" data-name="'+pname+'" > ';
       amess+='&#128065;'+jassets;
       if (portfolioInit[pname]['totals']['nIncome']>0) amess+=' <span style="color:green;font-size:90%" title="income streams & annuities "> &amp;'+portfolioInit[pname]['totals']['nIncome']+'</span> ';
       amess+='</button>';
       amess+=' <span  style="float:right;margin-right:1em;font-size:80%;font-weight:500;font-style:oblique">'+cdateSay+'</span>';
    }


//    if (someMissing!='') amess+='<div>'+someMissing+'</div>';   // 11 JUNE fix this

    amess+='</td>';

// shor desc
    amess+='<td data-_sortuse="'+cdate+'"><span name="portfolioDesc"  class="cDescSay">'+aportfolio['desc']+'</span></td>';


// long desc and portfolio list
    amess+='<td><div name="portfolioDescLong" class="cDescLongSay">  '+aportfolio['descLong']+'</div>';
    amess+='</td>';
    amess+='</tr>';
  }
  amess+='</table>';
  amess+='</div>';

  $('#mainDiv3').html(amess);
//  $('#portfolioTable').data('removes',[]);  // reset every time table is displayed

  wsurvey.wsShow.show('#mainDiv','show');
  wsurvey.wsShow.hide('#mainDiv1');
  wsurvey.wsShow.hide('#mainDiv2');
  wsurvey.wsShow.show('#mainDiv3','show');

  let asay='<button title="Tips" onclick="displayHelpMessage(this)" data-div="#portfolioHistoryHelp1">&#10068;</button> &#128144; Initialize or modify a <u>portfolio</u>   ... '
  hidePortfolioHeader(2,asay);

  wsurvey.sortTable.init('portfolioTable',{'skipCols':3})


 fitInMainDiv3('portfolioTableOuter');

}

//=================
// toggle view of hidden portfolios
function showHiddenPortfolios(athis) {
    let ethis=wsurvey.argJquery(athis);
   let isShow=parseInt(ethis.attr('data-show'));
   let ug=1-isShow;
   ethis.attr('data-show',ug);

   let etable=$('#portfolioTable');
   let ehides=etable.find('.cHideThisPortfolio');
   let nhides=ehides.length;
   if (nhides==0) return 0;              // no hiddend assets

   if (isShow==1) {    // currentliy  shown -- so hide
       ehides.hide();
       ethis.addClass('hidePortfoliosButtonOn');            // hideAssetsButtonOn
       ethis.html('Unhide ' +nhides+' &hellip; ')
   } else {
       ehides.show();
       ethis.removeClass('hidePortfoliosButtonOn');
       ethis.html('Hide '+nhides+' &hellip; ')
   }


  return ehides.length;
}



//=======================
// preview assets in a portfolio, using basic info

function showPortfolioTablePreview(athis) {
   let ethis=wsurvey.argJquery(athis);
   let pname=ethis.attr('data-name');
   amess='';
   apuse=portfolioLookup['list'][pname]   ;

// ........
   let nEntries=apuse['nHistory'];

   let modList=apuse['modDates'];

  let nmods= modList.length-1 ;  // [0] is init

   daAssets={};
   for (let aa1 in apuse['anyDateAsset']) {     // list of assets NOT in init  (simpler version of what is simInv_showPortfolio.js
      let jIn=apuse['anyDateAsset'][aa1];
      if (jIn==nEntries  ) continue ;  // {
       let initDate=apuse['modDates'][0] ;
       if (apuse['assetsList'][initDate].hasOwnProperty(aa1)) continue ;
       daAssets[aa1]=1 ;
   }

   let cdate=apuse['creationDate'];

   let origBudget=apuse['origBudget'];
   let totNetAssetEst=apuse['totNets'][cdate] ;
   let totNetAllSay=wsurvey.makeNumberK(parseInt(totNetAssetEst),99000);
   amess+='<input type="button" value="x" title="close this" data-wsshow="#portfolioTablePreview" onClick="wsurvey.wsShow.hide(this)"> ';
   let gg=wsurvey.addComma(parseInt(origBudget));
   amess+='Portfolio <b>'+pname+'</b>: initial asset-mix (original budget: <tt>'+gg+'</tt>).<span title="approximate net value">~Net value:</span> <tt> '+totNetAllSay+'</tt>';

   let plist=portfolioInit[pname]['assets']  ;

   amess+='<ul class="linearMenu16Pct">';
   for (let aa in plist) {
      let ztype=parseFloat(plist[aa]['assetType']);
      let aicon=getAssetType(aa,'icon');
      if (ztype!=4) {
        let netVal=parseFloat(plist[aa]['valueNet']);
        let netValSay=wsurvey.makeNumberK(netVal,5000,0);
        amess+='<li>'+aicon+' <u>'+aa+'</u>= <tt>$'+netValSay+'</tt>';
      } else {                      // income stream
        aIncome=0 ;
        if (plist[aa].hasOwnProperty('yearlyIncome')) {
          aIncome=parseFloat(plist[aa]['yearlyIncome']);
        } else if (plist[aa].hasOwnProperty('yearlyAnnuity')) {
          aIncome=parseFloat(plist[aa]['yearlyAnnuity']);
        }
//        let aIncome=parseFloat(plist[aa]['yearlyIncome']);
        let aIncomeSay=wsurvey.makeNumberK(aIncome,10000,0);
        amess+='<li>'+aicon+' <u>'+aa+'</u>= <tt>$'+aIncomeSay+'</tt>';
      }
    }

// note assets in mods (but not in init)
    for (let aa1 in daAssets) {
       amess+='<li><span style="color:blue;opacity:0.6" title="in one or more modification entries">'+aa1+'</span>';
    }
    amess+='</ul>';

  $('#portfolioTablePreview').html(amess);
  wsurvey.wsShow.show('#portfolioTablePreview','show');
  
  
  let etable=$('#portfolioTable');
  let ebuttons=etable.find('.cshowPortfolioTablePreview');
  ebuttons.removeClass('showPortfolioTablePreview2');

  ethis.addClass('showPortfolioTablePreview2');

  return 1;
}

//==============
// add a portfolio
function addARowPortfolio(athis){
   let etable=$('#portfolioTable');

   let amess=''
    amess+='<tr class="portfolioRow portfolioRowNew"  data-exists="0" data-hidden="0" data-remove="0" >';
    amess+='<td> <input type="button" value="Remove this row " onClick="removePortfolioRow(this,0)"></td>';
    amess+='<td> <input type="text" size="12" name="portfolioName" value=""></td>';
    amess+='<td> <input type="text" size="42" name="portfolioDesc" value=""></td>';
    amess+='<td> <textarea rows="2" cols="50" name="portfolioDescLong"></textarea></td>';
    amess+='</tr>';
    etable.append(amess);

   let aamess='After specifying new portfolios to add, and existing portfolios to remove -- click  <button><b>Save!</b></button>';
   aamess+=' &nbsp;&nbsp;&nbsp; ... <em>or</em> <button  name="doPortfolioButton"  class="cdoButtonRegular" onClick="showPortfolioTable(this)">reload the portfolio list </button> <em>without making these changes!</em>';
    $('#portfolioTablePreview').html(aamess);

}

//===============
// hide portfolio row -- this is saved, so that on next logon this asset is not displayed in portfolio table
// but.... it can be readily unhidden
function hidePortfolioRow(athis) {
   let ethis=wsurvey.argJquery(athis);
//   let ishidden=ethis.attr('data-status');
   let etr=ethis.closest('.portfolioRow');
   let ishidden=etr.attr('data-hidden');
   if (ishidden==0) {          // currently unhidden, so  hide
       ishidden=1;
       ethis.attr('data-status',1);   // 16 dec 2023 to be deprecated
       ethis.addClass('cHiddenPortfolioSpan');                 // cHiddenAssetSpan
       ethis.html('unHide');
       etr.addClass('cHideThisPortfolio');                // cHideThisAsset
       etr.attr('data-hidden',1);
   } else {              // currently hidden, so unhide
       ishidden=0;
       etr.removeClass('cHideThisPortfolio');
       ethis.removeClass('cHiddenPortfolioSpan');           // cHiddenAssetSpan
       ethis.attr('data-status',0);      // 16 dec 2023 to be deprecated
       ethis.html('&nbsp;Hide&nbsp;');
       etr.attr('data-hidden',0);
   }

}



//====================
// remove row from list of portfolios
function removePortfolioRow(athis,isExist) {
   let ethis=wsurvey.argJquery(athis);
   let erow=ethis.closest('tr');
   if (isExist==0)  {    // newly added, so not recored .. just remove the row
      erow.remove();
      return 1 ;
   }

// mark this row for removal (or unmark)
  let jrem=erow.attr('data-remove');
  if (jrem==1)   {  // unmark
     erow.attr('data-remove',0);
      erow.css({'opacity':1.0});
  } else {
      erow.attr('data-remove',1);
      erow.css({'opacity':0.2});
  }


//   let pname=erow.attr('data-name');
//   let etable=$('#portfolioTable');
//   let aremoves=etable.data('removes');
//   aremoves.push(pname);
//   etable.data('removes',aremoves);
//   erow.remove();
//  erow.css({'opacity':0.2});


 let aamess='After selecting portfolios to remove or hide, and new ones to add -- click   ';
 aamess+=' <button onClick="scrollPortfoliosTable(this)"><b>Save!</b></button>';
 aamess+='&nbsp;&nbsp;&nbsp;  ... <em>or</em> <button  name="doPortfolioButton"  onClick="showPortfolioTable(this)">reload the portfolio list </button> <em>without making these changes!</em>';
 $('#portfolioTablePreview').html(aamess);

}


//===============
// scroll to top of asset  assetsTableOuter
function scrollPortfoliosTable(athis) {
   let e1=$('#portfolioTableOuter');
    e1.animate({scrollTop:0}, 500);

   let e1b=$('#portfolioTable');
    e1b.animate({scrollTop:0}, 200);
  return 1  ;
}

//====================
// remove row from list of assets in the asset mix of a portfolio
function removePortfolioRowAssetMix(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aname=ethis.attr('data-name');
   let aexists=ethis.attr('data-exists');
   let erow=ethis.closest('tr');

   if (aexists==0)  {            // new entry, just  zap it

      erow.remove();
      let elist=$('#portfolioHistoryAssetList');
      let ebuttons=elist.find('.chighlightAssetButton');
      let e1=ebuttons.filter('[data-name="'+aname+'"]');
      if (e1.length==1) {
         e1.removeClass('chighlightAssetButton');
        e1.attr('data-chosen',0);
      }
  }

// fade it (so it can be recovered easily)
  let aremove=  erow.attr('data-remove');
  if (aremove==1) {
      erow.attr('data-remove',0);
      let etd1=ethis.closest('td');
      etd1.removeClass('removeThisRow');
      let etd2=erow.find( '[name="cell_name"]');
      etd2.removeClass('removeThisRow');
      let etd3=erow.find( '[name="cell_value"]');
      etd3.removeClass('removeThisRow');
//      erow.css({'opacity':1.0,'font-size':'100%'});
  } else {
      erow.attr('data-remove',1);
      let etd1=ethis.closest('td');
      etd1.addClass('removeThisRow');
      let etd2=erow.find( '[name="cell_name"]');
      etd2.addClass('removeThisRow');
      let etd3=erow.find( '[name="cell_value"]');
      etd3.addClass('removeThisRow');

//      erow.css({'opacity':0.2,'font-size':'70%'});
  }

}


//==============
// save the list of  portfolios: old (minus remvoed) + new
function saveAllPortfolios(athis) {
   let etable=$('#portfolioTable');

   let aremoves={};
   let hiddens={};
   let nustuff=[];

   let allList={} ;
   let nowTime=wsurvey.get_currentTime(0);
   let newPortfolios={'time':nowTime,'data':[]};  // assetList will have (date,entries,autoAddEntries)

   let etrs0=etable.find('.portfolioRow');
   let nhidden=0,nremove=0,nretain=0,nadd=0,changeHides=0,aNewPortfolio=false;

// find retained portfolios (and hidden)
   for (let j1=0;j1<etrs0.length;j1++) {
        let aetr=$(etrs0[j1]);
        if (aetr.attr('data-exists')==0) continue ;  // deal with new portfolios below

        let pname=aetr.attr('data-name');
        let isHidden=aetr.attr('data-hidden');
        let isRemove=aetr.attr('data-remove');
        if (isRemove==1) {
           nremove++;
           aremoves[pname]=1  ;    // a hidden portfolio (from before, or just set)
        } else {
           nretain++;
           allList[pname]=1;
        }
        if (isRemove==0 && isHidden==1) {  // hidden irrelevant if a removal
           nhidden++;
           hiddens[pname]=1   ;    // a hidden portfolio (from before, or just set)
        }

   }
  if (nremove>0) {             // double check
    let q=confirm('Are you sure you want to remove '+nremove+' existing portfolios? ');
    if (!q) return 0;
  }

// read new portfolio specs
   let etrs=etable.find('.portfolioRowNew');

   for (let j1=0;j1<etrs.length;j1++) {
      let aetr=$(etrs[j1]);
      if (aetr.hasClass('portfolioRowNew')) {  // new portfolio
         let e1=aetr.find('[name="portfolioName"]')

         let pname0=jQuery.trim(e1.val().toLowerCase());
         if (pname0=='') {
              alert('Portfolio name not specified ');
              return 0;
         }

         if (pname0=='') continue ; // ignore blank

         let pname=fixStringRemoves(pname0);
         if (pname0!==pname) {
             alert('Improper portfolio name: `'+pname0+'`\n Use a different name without any of the following characters: embedded spaces, commas, %, &, +, *, /, \\, \', ", #, !, $, <, >, or  | ');
             return false;
         }
         let oof=pname.split('.');
         if (oof.length>2) {           // too many .
            alert('Improper portfolio name: too many periods: '+pname0+'\n You can specify `portfolioname` or `portfolioname.variant` ');
            return false;
        }

         if (allList.hasOwnProperty(pname)) {
            alert('Portfolio name already used ('+pname+')');
            return 0;
         }


         if (jQuery.isNumeric(jQuery.trim(pname))) {
            alert('You can not use a number as a portfolio name: `'+pname+'`');
            return 0;
         }

         allList[pname]=1;
         if (aNewPortfolio===false) aNewPortfolio=pname;      // used with autoLogon (the first new portoflio specified)

         let e2=aetr.find('[name="portfolioDesc"]')
           let adesc=fixString(jQuery.trim(e2.val()),2);
           adesc=wsurvey.removeAllTags(adesc);
         let e3=aetr.find('[name="portfolioDescLong"]')
           let adescLong= jQuery.trim(e3.val())  ;
           adescLong=wsurvey.removeAllTags(adescLong);
        let arow={'name':pname,'desc':adesc,'descLong':adescLong,'exists':0,'isHidden':0};
        nadd++;
        nustuff.push(arow)

     }   // new row
   }

// build new list --- keep the retains and then add the news
   for (let ip=0;ip<simInvDsets['allCurrentData']['portfolios']['data'].length;ip++)  {     // the retains (tweak isHidden)
       let pname=simInvDsets['allCurrentData']['portfolios']['data'][ip]['name'];
       if (aremoves.hasOwnProperty(pname)) continue  ; // do NOT include in new list
       let aentry= JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['portfolios']['data'][ip]));
       let nowhide=aentry['isHidden'] ;
       if (hiddens.hasOwnProperty(pname))  {   // currently hidden
          if (nowhide==0)  {               // was not hidden ... so a change
              changeHides++;
              aentry['isHidden']=1;
          }
       } else {
          if (nowhide==1)  {               // was not hidden ... so a change
              changeHides++;
              aentry['isHidden']=0;
          }
       }
       newPortfolios['data'].push(aentry);
    }
    for (let ip2=0;ip2<nustuff.length;ip2++) {           // add the new ones
        newPortfolios['data'].push(nustuff[ip2])  ;
    }

    if (nadd==0 && nremove==0 && changeHides==0) {  // no changes, do nothing!
      alert('No portfolios were added, or removed, or hidden/unhidden ');
      return 0;
    }


//  remove stuff from portfolioInit and portfolioModifications?

    let newPortfolioInit={},newPortfolioModifications={};

    if (nremove==0) {
        newPortfolioInit=false;
        newPortfolioModifications=false;
    } else {
       newPortfolioInit={'time':nowTime,'data':{}};
       for (let aport in simInvDsets['allCurrentData']['portfolioInit']['data'] ) {
          if (aremoves.hasOwnProperty(aport)) continue  ; // do NOT include in new portfolio inits
          newPortfolioInit['data'][aport]=JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['portfolioInit']['data'][aport])) ;
       }
       newPortfolioModifications={'time':nowTime,'data':{}};
       for (let aport in simInvDsets['allCurrentData']['portfolioModifications']['data']  ) {
          if (aremoves.hasOwnProperty(aport)) continue  ; // do NOT include in new portfolio inits
          newPortfolioModifications['data'][aport]=JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['portfolioModifications']['data'][aport])) ;
       }
    }

    let bmess=newPortfolios['data'].length  +' portfolios ';
    bmess+=' after '+nretain+' retained, '+nremove+' removed, '+nadd+' added  (and '+nhidden+' hidden) ';
    if (nadd>0) bmess+= '<br> After reloading -- use  <button> &#128065; portfolios</button> to add assets to the newly added portfolios ';

    simInvGlobals['temp']['autoLogonDetails']={'action':'portfolioList','portfolio':aNewPortfolio} ;
    saveSimInvData_portfolioList(userName,newPortfolios,newPortfolioInit,newPortfolioModifications,bmess)  ;
    simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

}



//============   pname
// add a row to mix of a portfolios asset
// isMod: 0 -- initialization, or adding a row to a mod;  1 - modificction
// useThese: prepopulate the row using this info (if isMod=1)
//    useThese is   a row from assetList. Or is empty, if a new row is being added (non-pre-populated)
// doButton: if 1, then highlight this assets button
// jdateStamp: if ismod=1: the date of the modified entry
// awhere: where to find date info

function addARowPortfolioAssetMix(isMod,useThese,doButton,jdateStamp,awhere)  {

   if (arguments.length<3) doButton=0;
   if (arguments.length<4) jdateStamp=false;

   let aname=useThese['name'];
   let assetInputClasses=['stockInputClassSay','bondInputClassSay','bondInputClassSay','propertyInputClass','incomeInputClass','annuityInputClass','oneOffInputClass'];

   let assetType=useThese['assetType'] ;
   let assetIcon=getAssetType(assetType,'icon');
   let assetSay=getAssetType(assetType,1);
   let assetSayLong=getAssetType(assetType,'sayslong');

   let taxFreeFrac =doAssetLookup(aname,'taxFreeFrac',1);

   let ainputClass=assetInputClasses[assetType];

    amess='';
    amess+='<tr class="portfolioHistoryRow portfolioHistoryRowNew"  data-remove="0" >';

// remove, or sell off, column
    amess+='<td  name="cell_remove" data-_sortuse="'+assetType+'" >';
    if (isMod==0) {
       amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="Remove this asset from the asset mix (of this portfolio)"  data-exists="0" ';
       amess+='    onClick="removePortfolioRowAssetMix(this)">&#10060;</button>';
    } else {         // "remove" message    depends on assetTYpe
        if (assetType==0) {
         amess+='<button data-name="'+aname+'"  style="border:1px solid gold;border-radius:4px"  data-exists="1"  ';
         amess+='    name="removeThisRowButton" title="Sell all shares" ';
         amess+='    onClick="removePortfolioRowAssetMix(this)">&#128184;</button>';
        } else if (assetType==1) {
         amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="Convert all bonds to cash "   data-exists="1"';
         amess+='    onClick="removePortfolioRowAssetMix(this)">&#128176;</button>';
        } else if (assetType==1  || assetType==2) {
         amess+='<button data-name="'+aname+'" style="border:1px solid green;border-radius:4px"   data-exists="1" ';
         amess+='      name="removeThisRowButton" title="Convert all bonds to cash (and pay a deferred tax) " ';
         amess+='    onClick="removePortfolioRowAssetMix(this)">&#128176;</button>';

        } else if (assetType==3) {
         amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="Sell the property "  data-exists="1" ';
         amess+='    onClick="removePortfolioRowAssetMix(this)">&#128184;</button>';

        } else if (assetType==4) {
          amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="End this income stream"  data-exists="1" ';
          amess+='    onClick="removePortfolioRowAssetMix(this)">&#128721;</button>';

        } else if (assetType==5) {
          amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="End this annuity"  data-exists="1" ';
          amess+='    onClick="removePortfolioRowAssetMix(this)">&#128721;</button>';

        } else if (assetType==6) {
          amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="Remove this oneOff"  data-exists="1" ';
          amess+='    onClick="removePortfolioRowAssetMix(this)">&#128721;</button>';

        } else if (assetType==7) {
          amess+='<button data-name="'+aname+'"  name="removeThisRowButton" title="End this expense stream"  data-exists="1" ';
          amess+='    onClick="removePortfolioRowAssetMix(this)">&#128721;</button>';
        }
    }
    amess+='</td>';

// asset name == useThese['name'] always exists!
    let mmName= useThese['name'] ;
    let isPublic=doAssetLookup(mmName,'isPublic');

    let mmNameUse= (isPublic==1) ? '<span style="color:brown">&Pscr;</span> '+mmName :  mmName ;
    amess+='<td  name="cell_name"  data-_sortuse="'+mmName+'" class="'+ainputClass+'" > ';

    amess+='<button name="portfolioAsset"  readonly data-orig="'+mmName+'"  value="'+mmName+'"  ';
    if (isPublic!==1) {
       amess+='        class="portfolioAssetNameNew" size="12" title="The asset ">';
    } else {
       amess+='        class="portfolioAssetNameNew" size="12" title="The public asset ">';
    }
    amess+=mmNameUse;
    amess+='</button>';

    let tt1;
    tt1='<span title="'+assetSayLong+'">'+assetIcon+'</span>';

    amess+='<span class="portfolioAssetTypeNew" data-type="'+assetType+'" >';
    amess+=tt1+'</span>';

    amess+='</td>';

// # shares, etc.
    amess+='<td  name="cell_value"  data-_sortuse="'+useThese['nShares']+'"   >';
    let zzclass=' ';
    let zz1Say= (assetType==0 ) ? '&#65283; ' : '&#65284; ' ;     // 83=#,  84=$
    let tbdSay='';

    if (assetType==1)  {         // regular bond
         let usex=useThese['nShares'];
         if (jQuery.isNumeric(usex)) usex=parseFloat(usex).toFixed(0);

         amess+=zz1Say;
         amess+='<input type="hidden" name="modStatus" value="'+isMod+'" > ';
         amess+='<input type="text" name="portfolioShares"   size="8" data-orig="'+usex+'" ';
         amess+='  value="'+usex+'"   class="bondInputClass autoFillShare modReset " ' ;
         amess+=' title="$ value of bonds. Or xx% for #shares  purchased at xx% of budget.\n Hint: nnnK for nnn thousand"    >';
         amess+='<input type="button" class="smallButton" value="%" title="Specify: % of budget to spend on bonds " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
         amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
         amess+=' &Verbar; <span title="yearly additions, or withdrawals">&plusmn;additions</span> ';

         amess+='<input type="text" name="portfolioAdditions"   size="8" data-orig="0" ';
         let dadd=0;
         if (useThese.hasOwnProperty('addVal')) {
            dadd=parseInt(useThese['addVal']);
         }
         amess+='  value="'+dadd+'"   class="bondInputClass " ' ;
         amess+=' title="Yearly amount added to this bond asset. If negative, yearly withdrawals"    >';

         tbdSay='<div class="bondInputClass_say">'+portfolioAssets_currentInfo(aname,jdateStamp)+'</div>';  // written to final column

    } else if ( assetType==2) {         // tax deferred bonds

        let dateSayX='';
        if (jdateStamp!=false) {
             let oof3=setEntryDate(jdateStamp);
            dateSayX=oof3['sayDate'];
        } else {

           let oof3a=getCreationDate(awhere);
            dateSayX=oof3a['sayDate'];
        }

         let usex=useThese['nShares'];
         if (jQuery.isNumeric(usex)) usex=parseFloat(usex).toFixed(0);

         let dadd=0;
         let dormd=0;
         if (useThese.hasOwnProperty('doRMD') && (useThese['doRMD']!==false) && (useThese['doRMD']!=='false' ) ) {
             dormd=parseInt(useThese['doRMD']);
         }
         if (dormd==0)   {
           if (useThese.hasOwnProperty('addVal')) {       // 'addVal' is yearly addition
              dadd=parseInt(useThese['addVal']);          // 'additions' is actual additions (since last mod)
            }
         }

         amess+='<div class="cSharesAddition">';

         amess+='<div class="cSharesAddition1">';
         amess+=zz1Say;
         amess+='<input type="hidden" name="modStatus" value="'+isMod+'" > ';
         amess+='<input type="button" class="smallButton"  value="$" title="Specify: pre-tax $ amount " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
         amess+='<input type="text" name="portfolioShares" size="8" data-orig="'+useThese['nShares']+'"  value="'+usex+'"   class="bondInputClass modReset" ' ;
         amess+=' title=" tax deferred bonds. "    >';
         amess+='<input type="button" class="smallButton" value="%" title="Specify: % of  budget (using pre-tax adjustment) to spend on tax-deferred bonds  " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
         amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of pre-tax dollars " onClick="addARowPortfolioAssetMix_type(this,0)"  >';

         amess+='&nbsp;&verbar;&nbsp';

         let ahide=' ';
         if (dormd==1 || dormd==2) ahide=' style="display:none" ';
         amess+='<span  '+ahide+' class="cportfolioAdditions_amount"  >';  // hidden if rmd
         amess+='  <span title="yearly additions, or withdrawals">&plusmn;additions</span> ';
         amess+='<input type="text" name="portfolioAdditions"   size="6"  style="font-size:90%" data-orig="0" ';
         amess+='  value="'+dadd+'"   class="bondInputClass " ' ;
         amess+=' title="Yearly amount added to this tax deferred bond asset. If negative, yearly withdrawals (such as a RMD)." >  ';
         amess+='</span>';

         amess+=' <span  class="cportfolioAdditions_rmdCheckbox">';        // hide if existing and this is a mod
         amess+='<label  style="background-color:#e6f4d8" title="Use RMD to calculate withdrawals" >';
         let acheck=' ';
         if (dormd==1 || dormd==2) acheck= " checked " ;
         amess+='<input type="checkbox" '+acheck+' onclick="addARowPortfolioAssetMixRMD(this)" name="portfolioAdditionsRMD">';
         amess+='RMD</label> ';
         amess+='<input type="button" style="font-size:80%" value="?" title="What is RMD" onClick="addARowPortfolioAssetMixRMD(this,1)"> ';
         amess+='</span>';

        amess+='<span name="rmdStartSay" style="display:none;margin-left:1em;font-size:80%;font-style:oblique" title="Start date of RMD distribution"></span>';

         amess+='</div>';      // cSharesAddition1


         let ashow2=(dormd==1 || dormd==2) ? '' :  'display:none;' ;
         amess+=' <div style="'+ashow2+'" class="cportfolioAdditions_rmd">';
         amess+='<label  style="background-color:#e6f4d8;" title="Unchecked: use own RMD schedule (starts @ age of ~72)\n Checked: use beneficiary schedule" >';
         amess+=' Beneficiary? ';
         let acheck2=(dormd==1) ? ' ' : ' checked ';
         amess+='<input type="checkbox"  '+acheck2+' name="portfolioAdditionsRMD_beneficiary">';
         amess+='</label> ';
         let aage='';
         if (dormd==1 || dormd==2) aage=parseFloat(useThese['additionsAge']).toFixed(2);

         amess+='&nbsp; Using age= <input type="text" value="'+aage+'" size="3" name="portfolioAdditionsRMD_age" title="Age to use (as of '+ dateSayX+')"> ';
         amess+='</div>';     // cportfolioAdditions_rmd

         let ashow3='display:none;' ;
         amess+=' <div style="'+ashow3+'font-size:90%;border:1px dotted cyan;margin:3px" class="cportfolioAdditions_rmdCheckboxHelp">';
         amess+='<button style="margin-bottom:5px" title="RMD details..." onclick="displayHelpMessage(this)" data-div="#portfolioRMDHelp">?</button>';
         amess+='Check to specify yearly withdrawals using a RMD schedule. ';
         amess+='Uncheck to specify yearly &plusmn; dollar amounts. ';
         amess+='<br>If specifying a RMD: specify an <tt>age</tt> (as of this date='+dateSayX+'). ';
         amess+='</div>';

         amess+='<div>';
         amess+='</div>';  // cSharesAddition
         tbdSay='<div class="bondInputClass_say">'+portfolioAssets_currentInfo(aname,jdateStamp)+'</div>';


     } else if (assetType==0 ) {          //stock

        zz1Say+=' <input type="button" class="smallButton" value="$"  title="Specify: $ amount (to spend on stock shares)" onClick="addARowPortfolioAssetMix_type(this,0)"  >';
        zz1Say+='&nbsp;';
        let usex=useThese['nShares'];
        if (jQuery.isNumeric(usex)) usex=parseFloat(usex).toFixed(2);

        amess+=zz1Say;
        amess+='<input type="hidden" name="modStatus" value="'+isMod+'" > ';
        amess+='<input type="text" data-orig="'+useThese['nShares']+'" name="portfolioShares" size="7" value="'+usex+'"    ' ;
        amess+=' title="# of shares of this stock. Or  \n *  $xx for xx dollars worth (at current price). \n * xx% for at xx% of budget. \nHint: nnnK for nnn thousand"    class="stockInputClass autoFillShare modReset"   >';
        amess+='<input type="button" class="smallButton" value="%" title="Specify: % of budget (to spend on shares)" onClick="addARowPortfolioAssetMix_type(this)"  >';
        amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars (or shares)" onClick="addARowPortfolioAssetMix_type(this)"  >';

         amess+='<span class="portfolioAssetBasis"  >&#65284;Basis:';
             amess+='<input type="text" name="portfolioSharesBasis"    data-orig="100%"   data-noset="0" size="7"  ';
             amess+='       value="100%"  class="stockInputClass"  ';
             amess+=' title="The basis, in $ (used in capital gains calculations).  \n Or, enter nn% (% of $ value of stock shares) -- leave blank for 100% " >';
             amess+='<input type="button" class="smallButton" value="%" title="Specify: % of stock value that is basis " onClick="addARowPortfolioAssetMix_type(this,1)"  >';
        amess+='</span>   ';

        tbdSay='<div class="stockInputClassSay">'+portfolioAssets_currentInfo(aname,jdateStamp)+'</div>';   // 90

     } else if (assetType==3 ) {          // property

        amess+='<div class="cProperty">';
        let useCost=(useThese.hasOwnProperty('acqCost')) ? useThese['acqCost'] : useThese['cost'];
        let useCostSay=useCost;
        if (jQuery.isNumeric(useCost)) useCostSay=wsurvey.addComma(parseInt(useCost));

        amess+='<div name="loanInfoDiv" >';

        amess+=' <input type="hidden" name="modStatus" value="'+isMod+'" > ';

        amess+='<span title="downpayment and other upfront (acquisition) costs">$acqCost</span>: ';
        amess+=' <input type="text" data-orig="'+useCost+'"    class="propertyInputClass" ';
        amess+= ' name="portfolioShares" size="6" value="'+useCostSay+'"    ' ;
        if (isMod==1)  {        // modification
            amess+=' readonly style="opacity:0.6" ';            // one-time costs
            amess+=' title="Upfront costs are specified when portfolio was created (it can not be changed here).\nFor example, the downpayment, and closing costs, of purchasing a house. "  ';
            amess+='  >';
        } else {           // initial, or new property added during a modification
            amess+=' title="Upfront costs. For example, the downpayment, and closing costs, of purchasing a house. \nHint: nnnK for nnn thousand"  ';
            amess+='  >';
            amess+='<input type="button" class="smallButton" value="%" title="Specify: upfront payment as percent of property price " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
            amess+=' <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
         }

// these will be tweaked if this is a modification
         amess+='<span class="portfolioAssetBasis">$Basis:';

         let oyBasis=useThese['basis'] ;
          if (jQuery.trim(oyBasis)=='' )  oyBasis='100%';
          if (jQuery.isNumeric(oyBasis)) oyBasis=wsurvey.addComma(parseInt(oyBasis)) ;

          amess+='<input type="text" name="portfolioPropertyBasis"  class="propertyInputClass"  size="4" style="font-size:90%" value="100%"    data-orig="'+oyBasis+'"   ';
          amess+=' title="The basis, in $ (used in capital gains calculations).  \n Or, enter nn% (% of $ value of property price). Leave blank for 100% " >';
          amess+='<input type="button" class="smallButton" value="%" title="Specify: % of property price  value that is basis " onClick="addARowPortfolioAssetMix_type(this,3)"  >';
          amess+=' <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,3)"  >';
          amess+='</span>   ';
          amess+='<span name="loanYes">';
          amess+='<label style="font-size:90%;background-color:#e6f4d8;display:inline-block;white-space:nowrap" ';
          amess+='        title="Specify a loan (to pay for this property)">';
          amess+='<input type="checkbox" name="porfolioLoanEnable" onClick="addARowPortfolioAssetMix_loanShow(this)"> ';
          amess+='Loan <input type="button" value="?" title="How are loans specified" onClick="addARowPortfolioAssetMixLoanHelp(this)"> ';
          amess+='</label>';
          amess+='</span>';
          amess+='<span name="loanStartDate" style="display:none;margin-left:1em;font-size:80%;font-style:oblique" title="Start date of loan"></span>';
          amess+='<span name="loanOwedNow" style="display:none;color:brown;padding:2px;font-size:80%">filled if mod</span>';

          amess+='<div name="loanSpecsHelp" style="display:none;border:2px dotted cyan;padding:3px;;font-size:90%;display:none"> ';
          amess+='You can specify a <tt>loan</tt> to pay the balance (price - acqCost) of this property.<br>';
          amess+='Specify 4 values: the <span title="The loan amount">$Loan</span>, the term, ';
          amess+=' the yearly interest rate, and if interest payments are tax deductible.<br>';
          amess+='Use  &#128065;  to preview the loan ';
          amess+='</div>';

          let ahide=';display=none;';
          if (useThese['loanAmount']>0) ahide='';
          amess+='<div name="loanSpecs" style="display:none;border:2px dotted blue;padding:3px;;font-size:90%'+ahide+'"> ';
          amess+='<button onClick="specifyLoanScheduleB(this)"  class="cdoButtonQuiet" title="View loan that uses these specs">&#128065;</button> ';
          amess+='<input type="hidden" value="'+aname+'" name="portfolioLoanName" > ';
          amess+=' $Loan: <input type="text" data-orig="'+useThese['loanAmount']+'" title="Amount of loan (in $, or %xx of price).\nEnter 0, or leave blank, to NOT take out a loan" name="portfolioLoanAmount" class="propertyInputClass"  size="7" value="90%"   >';
          amess+='<input type="button" class="smallButton" value="%" title="Specify: % of price (as the loan amount) " onClick="addARowPortfolioAssetMix_type(this,2)"  >';
          amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,2)"  >';

          amess+='<span style="font-size:90%;white-space:nowrap;display:inline-block;margin:1px 1px 1px 3px;padding:1px 1px 1px 5px;border-left:1px dotted blue">';
          amess+=' Term: <input type="text"  data-orig="'+useThese['loanTerm']+'" title="Term (in years\n Leave blank, or enter 0, to NOT take out a loan" name="portfolioLoanTerm" size="2" value=""  class="propertyInputClass2"  >';
          amess+=' | Rate: <input type="text" title="Interest rate as a percent. i.e.; 4.1 for 4.1%" data-orig="'+useThese['loanRate']+'" name="portfolioLoanRate" size="3" value="" class="propertyInputClass2"    >';

          amess+=' | <label>taxDed: <input type="checkbox" checked title="Interest rate payments are tax deductible" name="portfolioLoanTaxDeductInt" value="1" class="propertyInputClass2"   ></label>';
          amess+='</span>';
          amess+='</div>';
          amess+='<div name="refinanceOptions" style="display:none;font-size:95%;background-color:#dffddf" >Refinance options...</div>';
        amess+='</div>';

        tbdSay='<div class="propertyInputClass">'+portfolioAssets_currentInfo(aname,jdateStamp)+'</div>';

     } else if (assetType==4 ) {          //income

        let useCost=(useThese.hasOwnProperty('acqCost')) ? useThese['acqCost'] : useThese['cost'];
        let useCostSay=useCost;
        if (jQuery.isNumeric(useCost)) useCostSay=wsurvey.addComma(parseInt(useCost));

        amess+=' <input type="hidden" name="modStatus" value="'+isMod+'" > ';

        amess+='<span title="acquisition cost" >$acqCost</span>:';
        amess+=' <input type="text" data-orig="'+useCost+'" name="portfolioShares"  class="incomeInputClass" ';
        amess+='  size="7" value="'+useCostSay+'"    ' ;
        if (isMod==1)  {
            amess+=' readonly style="opacity:0.6" ';     // one-time costs
            amess+=' title="Acquisition cost - specified when portfolio was created (it can not be changed here).\n For example, the purchase price of an annuity.  "    ';
            amess+=' >';

        } else {
            amess+=' title="Acquisition cost - specified when portfolio was created (it can not be changed here).\n For example, the purchase price of a small business.  "   ';
            amess+=' >';
            amess+='<input type="button" class="smallButton" value="%" title="Specify: % of yearly income (as the acquisition cost) " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
            amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
        }

        tbdSay='<div class="incomeInputClass">'+portfolioAssets_currentInfo(aname,jdateStamp)+'</div>';


     } else if (assetType==5 ) {          //annuity

        let oof3a=getCreationDate(jdateStamp);

        dateSayI=oof3a.dayCount;

        let useCost=(useThese.hasOwnProperty('acqCost')) ? useThese['acqCost'] : useThese['cost'];
        let useCostSay=useCost;
        if (jQuery.isNumeric(useCost)) useCostSay=wsurvey.addComma(parseInt(useCost));

        amess+=' <input type="hidden" name="modStatus" value="'+isMod+'" > ';
        let astart=dateSayI;
         amess+='<input type="hidden" name="incomeStart" value="'+astart+'" > ';
        amess+='<span title="acquisition cost" >$acqCost</span>:';
        amess+=' <input type="text" data-orig="'+useCost+'" name="portfolioShares"  class="incomeInputClass" ';
        amess+='  size="7" value="'+useCostSay+'"    ' ;
        if (isMod==1)  {
            amess+=' readonly style="opacity:0.6" ';     // one-time costs
            amess+=' title="Acquisition cost - specified when portfolio was created (it can not be changed here).\n For example, the purchase price of an annuity.  "    ';
            amess+=' >';

        } else {    // new row
            amess+=' title="Acquisition cost.\n For example, the purchase price of an annuity. "   ';
            amess+=' >';
            amess+='<input type="button" class="smallButton" value="%" title="Specify: % of annuity (as of acquisition date) as the acquisition cost  " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
            amess+='&nbsp; <input type="button" class="smallButton" value="k" title="Specify: 1000s of dollars " onClick="addARowPortfolioAssetMix_type(this,0)"  >';
        }
        tbdSay='<div class="incomeInputClass">'+portfolioAssets_currentInfo(aname,jdateStamp)+'</div>';

     } else if (assetType==6 ) {          // oneOff

        amess+=' <input type="hidden" name="modStatus" value="'+isMod+'">';
        amess+='<span style="background-color:#dfeddf"  title="receipt from this oneOff recieived on the day after this date!">&#9989;oneOff</span> ';
        tbdSay='<div class="incomeInputClass">'+portfolioAssets_currentInfo(aname,jdateStamp)+'</div>';


     } else if (assetType==7 ) {          // expense

        amess+=' <input type="hidden" name="modStatus" value="'+isMod+'" > ';
        tbdSay='<div class="incomeInputClass">'+portfolioAssets_currentInfo(aname,jdateStamp)+'</div>';

     }   // if assettype==...

    amess+='</td>';     // end of user fillable variables (#shares, etc) column

// summary of this asset column
    amess+='<td   name="cell_netValue"   data-_sortuse="'+useThese['nShares']+'" ><div class="cportfolioTable1_summaryCell"  >';
    amess+=tbdSay;
    amess+='</div></td>';

// comment column of table
    amess+='<td name="cell_pct"  data-_sortuse="'+useThese['nShares']+'"  ><div style="width:100%;overflow:auto"> <input type="text" data-orig="'+useThese['comment']+'" name="portfolioComment" size="30"   value="'+useThese['comment']+'"  title="optional comment"></div></td>';
    amess+='</tr>';

    let emess=$(amess);

    emess.appendTo('#portfolioHistory1AssetRows');

   if (doButton!=1)   return emess;

// update asset button (for this asset)  --- to simulate it was clicked on
  let etable=$('#portfolioHistory1');
  let eaButtons=etable.find('[name="portfolioTable_assetButtons_1"]');

  let ea1=eaButtons.filter('[data-name="'+aname+'"]');
  if (ea1.length!=1) return emess;

  ea1.addClass('chighlightAssetButton');
  ea1.attr('data-chosen',1);


}          // end of addARowPortfolioAssetMix    isMod    getCreationDa

// rmd details
function addARowPortfolioAssetMixRMD(athis,ihelp) {
   if (arguments.length<2) ihelp=0;
   let ethis=wsurvey.argJquery(athis);
   let e0=ethis.closest('.cSharesAddition');
    if (ihelp==1) {
      let e0a=e0.find('.cportfolioAdditions_rmdCheckboxHelp');

      e0a.toggle();
      return 1;
    }

   let qdo=ethis.prop('checked');
   let e0_rmd=e0.find('.cportfolioAdditions_rmd');
   let e0_amount=e0.find('.cportfolioAdditions_amount');
   if (qdo)  { // use rmd to calculate -additions
     e0_rmd.show();
     e0_amount.hide();
   } else {
     e0_rmd.hide();
     e0_amount.show();
   }
   return 1;
}


//===========================
// help for property loan specification
function addARowPortfolioAssetMixLoanHelp(athis) {
  let ethis=wsurvey.argJquery(athis);
  let e0=ethis.closest('.cProperty');
  let e1=e0.find('[name="loanSpecsHelp"]');
  e1.toggle();
}

//=================
// show loan specs for a row (property)
function addARowPortfolioAssetMix_loanShow(athis) {
  let ethis=wsurvey.argJquery(athis);
   let e0=ethis.closest('.cProperty');
   let e1=e0.find('[name="loanSpecs"]');
   e1.toggle();
   if (!e1.is(':visible')) {        // set term =0 if toggled off
         let eterm=e0.find('.propertyInputClass2');
         eterm.val('');
   }
}

//===================
// return html with a summary of totals across  all assets asset in a portfolio mix (quantity,cost cost%, totAssetSale, totAssetSale%, netValue netValue%
// amult used for inflation adjustment (if no inf adjustmemt, amult=1.0)

function portfolio_totalSummary(davals,amess0,isMod,amult ) {
 
  if (arguments.length<4) amult=1.0;
  amult=parseFloat(amult); // probably overkill

  let totvals=davals['grown']['totals'] ;
//  let totvalsGrow=davals['growtn']['totals'] ;
//  if (!davals.hasOwnProperty('totalsAfterGrowth')) {
//     alert('portfolio_totalSummary error: no [totalsAfterGrowth].  ');
//     return false;
//  }

    let nBond=totvals['nBond'];
    let nStock=totvals['nStock'];
    let nProperty=totvals['nProperty'];
    let nAsset=totvals['nAsset'];
    let nIncome=totvals['nIncome'];
    let nExpense=totvals['nExpense'];
    let totCost=totvals['totCost'];

    let totPortfolioValue=totvals['totPortfolioValue']*amult;
    let totAssetSale=totvals['totAssetSale']*amult;
    let totAssetSaleNetAT=totvals['totAssetSaleNetAT']*amult;         // actual, not estimatee (totalsAfterGrowth vs totals)
    let cashAsset=totvals['cashAsset']*amult;

  let amess=''
  if (amess0!==false) amess='<b>Portfolio summary  </b> '+amess0;
  amess+='<ul class="tighterMenu">';
   if (amess0!==false) {
     let  xv1=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totPortfolioValue),90000),amult);
      amess+='<li><span title="Net value, after taxes, including `Cash` "   style="border-bottom:1px dotted blue;font-weight:600">  ';
      amess+='  netValue :<tt> '+xv1+'</tt></span>';
  }
  if (amess0!==false) {
     let tt1=' title="'+nBond+' bonds, '+nStock+' stocks, '+nProperty+' properties" ';
     amess+='<li>non-<u>Cash</u> assets: <span '+tt1+' style="border-bottom:1px dotted blue;font-weight:500"><tt>'+nAsset+'</tt></span>';
     if (nIncome>0) amess+='<span title="# of income streams & annuities " style="font-size:80%"> &amp; <tt>'+nIncome+'</tt> inc </span>';
     if (nExpense>0) amess+='<span title="# of expense streams  style="font-size:80%"> &amp; <tt>'+nExpense+'</tt> inc </span>';
  }
  if (isMod==0 ) {
     let  xv1=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totCost*amult),90000),amult);
      amess+='<li><span title="cost of acquiring assets & incomes" style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500"> ';
      amess+='   Cost:<tt> '+xv1+'</tt></span>';
  } else {
      let  xv1=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totCost*amult),90000),amult);
      amess+='<li><span title="approximate cost of acquiring assets & incomes\nIncludes original outlays, and estimated outlays from reinvestments (from stock dividends and bond interest)"  ';
      amess+='    style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">~Cost:<tt> '+xv1+'</tt></span>';
   }

   amess+='<li> <span title="Gross (pre-tax) value" style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">~pre-tax value:<tt> ';
   let xv2=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totAssetSale*amult),90000),amult);
   amess+= xv2+'</tt></span>';
   let tt1= 'Net value of all assets (after taxes and loan payouts) -- NOT including  `Cash` \n ... '+nBond+' bonds, '+nStock+' stocks, '+nProperty+' properties  ';
   amess+='<li><span  title="'+tt1+'"  ';
   let xv2b=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totAssetSaleNetAT),90000),amult);
   amess+='    style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">netValueAssetAT:<tt> '+xv2b+'</tt></span>';



   let totPeriod= davals['grown']['totPeriod'];

       let totRevenue_period=totPeriod['totRevenuePeriod_AT']*amult;
       let totTaxOnRevenue_period=totPeriod['totTaxOnRevenuePeriod']*amult;
       let totLoanPaid_period=totPeriod['totLoanPayPeriod_AT']*amult;
       let totLoanOwed=totPeriod['totLoanOwed']*amult;

       amess+='<li><div style="border-top:1px dotted tan"> ' ;
       amess+='<span title="Since portfolio initialization (or last modification): netRevenue (from properties) + yearly income streams & annuities(after tax).\n Net revenue can be negative (i.e.; property taxes), but does NOT include loan payments"  ';
       amess+='     style="color:darkgreen; border-bottom:1px dotted blue;font-weight:500"> ';
       let xv2c=portfolio_totalSummary_sayval(wsurvey.makeNumberK(totRevenue_period,50000),amult);
       amess+=  ' &#120491;netRevenue :<tt> '+xv2c+'</tt></span> ';
       amess+=' <span title="Since portfolio initialization (or last modification):  tax paid on all incomeStreams, annuities, and netRents\n Does not include taxes on dividend and bond (interest) earnings"  ';
       amess+='     style="color:darkgreen;border-bottom:1px dotted blue;font-weight:500"> ';
       let xv2d=portfolio_totalSummary_sayval(wsurvey.makeNumberK(totTaxOnRevenue_period,50000),amult);
       amess+=  '  &hellip; tax: <span style="font-family:monospace" title="the tax paid"> '+xv2d+'</span></span> ';
       amess+='</div>';

       amess+='<li><span title="Since portfolio initialization (or last modification): loan payments (principal and afterTax_interest)" ';
       amess+='    style="color:#f77f7f;border-bottom:1px dotted blue;font-weight:500">';
       let xv2e=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totLoanPaid_period),30000),amult);

       amess+= '  &#120491;loanPayment <tt> '+xv2e+'</tt></span>';
       amess+=' &hellip; <span title="Remaining balance on all loans" style="color:red;border-bottom:1px dotted blue;font-weight:500">unpaidLoans<tt> ';

       let xv2f=portfolio_totalSummary_sayval(wsurvey.makeNumberK(parseInt(totLoanOwed*amult),90000),amult);
       amess+=xv2f+'</tt></span>';

    amess+='</ul>';

 // changes?
   let amessC='';
   if (davals.hasOwnProperty('summaryChanges') && davals['summaryChanges']!==false) {    // changes ... these are NOT inflation adjusted
//       let cmods=davals['changed'];
//       let summaryAll=cmods['summary'];

       let summaryAll=davals['totalsNet'];

       let dasummary=davals['summaryChanges'];
        let nremove=0,nnew=0,nchange=dasummary['changeList'].length,noneoffs=0;

       for (let arf in dasummary['removeList']) nremove++ ;
       for (let arf in dasummary['newList']) nnew++ ;
       for (let arf in dasummary['oneOffListNew']) noneoffs++ ;

       let tsales=wsurvey.makeNumberK(dasummary['totSales'],40000,0);
       let tpurchases=wsurvey.makeNumberK(dasummary['totPurchases'],40000,0);
       let totCashChange=dasummary['totCashChange'] ;      // changes   due to sales & purchase of a modification
       let totCashChangeSay=wsurvey.makeNumberK(totCashChange,50000);

        amessC+=' <div><b>Portfolio modifications </b> ';
        amessC+='<br> #remove=<tt>'+nremove+'</tt>, #add=<tt>'+nnew+'</tt>, #change=<tt>'+nchange+'</tt>, #oneOffs=<tt>'+noneoffs+'</tt>';

        let totProceedsAT=wsurvey.makeNumberK(summaryAll['totAssetSaleNetAT'],40000,0);
        let totTax=wsurvey.makeNumberK(summaryAll['totTaxPaid'],40000,0);
        let nowCash=wsurvey.makeNumberK(summaryAll['cashAsset'],40000,0);
        amessC+='<br><u>netAssetAT</u>= <tt>'+totProceedsAT+'</tt> (after tax of: <tt>'+totTax+'</tt>)<br>'
        amessC+='<u>Cash</u>=<tt>'+nowCash+ '</tt>  ';

        amessC+='<br>&nbsp;&nbsp; <u>Cash</u> change: <tt>'+totCashChangeSay+'</tt> &nbsp; ';
        amessC+=' <span title="[net (after tax) sales minus cost of acquisitions]" style="font-family:monospace;font-size:85%">';
        amessC+='['+tsales+' - '+tpurchases+']</span>';
        amessC+='</div>';

   }                // cmods   summaryAll   daentry

  return [amess,amessC];

  function portfolio_totalSummary_sayval(atext,amult) {
      amult=parseFloat(amult);
      if (amult==1.0) {
          return '<tt>'+atext+'</tt>';
      } else {
         return '<em>'+atext+'</em>';
      }
  }
}

//=========================
// show summary of a initialize portfolio

// return html with a summary of totals across  all assets asset in a portfolio mix (quantity,cost cost%, totAssetSale, totAssetSale%, netValue netValue%
//  totals:  object created by portfolioCalcValue -- total (across all assets) values. Some are estimated (not taking accouint of losses)
//   totalsAfterGrowth :    smaller set of totals, but take account of losses (calculated in calc_netValues).  Not currently used here


function portfolio_initTotalSummary(davals,amess0) {

 let totNetAllEst=davals['totNetAllEst'];
 let totCost=davals['totals']['totCost'];

 let totAll=davals['totals']['totAssetSale'];
 let totNetAssetsEst=davals['totals']['totAssetSaleNetAT'];

 let totNetRevenue=davals['totals']['totYearlyRevenueAT'];
 let totLoanPayments=davals['totals']['totLoanPayYear'];
 let totLoanOwed=davals['totals']['totLoanOwed'];
 let nAsset=davals['totals']['nAsset'];
 let nStock=davals['totals']['nStock'];
 let nBond=davals['totals']['nBond'];
 let nExpense=davals['totals']['nExpense'];
 let nProperty=davals['totals']['nProperty'];
 let nIncome=davals['totals']['nIncome'];
 let nLoan=davals['totals']['nLoan'];

   amess='<b>Portfolio summary </b> '+amess0; //  (<em>before modification</em>)';
   amess+='<ul class="tighterMenu">';
   amess+='<li><span title="Net value, including `Cash` "   style="border-bottom:1px dotted blue;font-weight:600">  ';
   amess+='  ~netValue :<tt> '+wsurvey.makeNumberK(totNetAllEst,90000,0)+'</tt></span>';

  let tt1=' title="'+nBond+' bonds, '+nStock+' stocks, '+nProperty+' properties" ';
   amess+='<li>non-<u>Cash</u> assets: <span '+tt1+' style="border-bottom:1px dotted blue;font-weight:500"><tt>'+nAsset+'</tt></span>';
   if (nIncome>0) amess+='<span title="# of income streams" style="font-size:80%"> &amp; <tt>'+nIncome+'</tt> inc </span>';
   if (nExpense>0) amess+='<span title="# of expense streams" style="font-size:80%"> &amp; <tt>'+nExpense+'</tt> inc </span>';

   amess+='<li><span title="cost of acquiring assets & incomes" style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500"> ';
   amess+='   Cost:<tt> '+wsurvey.makeNumberK(totCost,90000,0)+'</tt></span>';

  amess+='<li> <span title="Gross (pre-tax) value" style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">~pre-tax value:<tt> ';
  amess+=     wsurvey.makeNumberK(totAll,90000,0)+'</tt></span>';

  amess+='<li><span title="Approximate net  value -- the `sales` value of all assets; after paying capital gains & tax deferred taxes, and after paying off loans)\n Does NOT include `Cash` "  ';
  amess+='    style="padding-left:1.2em;border-bottom:1px dotted blue;font-weight:500">~netValueAsset:<tt> '+wsurvey.makeNumberK(totNetAssetsEst,90000,0)+'</tt></span>';

   amess+='<li><span title="Revenue: incomeStreams, annuities, and property rents"   style="border-bottom:1px dotted blue;font-weight:600">  ';
   amess+='   Revenue:<tt> '+wsurvey.makeNumberK(totNetRevenue,90000,0)+'</tt></span>';

   amess+='<li><span title="Loan payments (pre-tax)    style="border-bottom:1px dotted blue ">  ';
   amess+='   Loans:<tt> '+wsurvey.makeNumberK(totLoanPayments,90000,0)+'</tt></span>';
   amess+='<span title="amount owed -- after first payment "> (<tt>'+wsurvey.makeNumberK(totLoanOwed,90000,0)+'</tt>)</span>'


  amess+='</ul>';

  return amess;
}



//===================
// return summary of an asset in a portfolio mix (quantity,cost cost%, totAssetSale, totAssetSale%, netValue netValue%
// percenst are of total (tocal cost, totalValue, totNetAssetEst
// called by portfolioCalcValueMenu
function addARowPortfolioAssetMix_assetSummary(aname,davals) {

 let totals=davals['totals'];

 let astuff=davals['assets'][aname];

 let myCost=parseFloat(astuff['cost']);
 let myValue=parseFloat(astuff['value']);
 let myNetValue=parseFloat(astuff['valueNetAT']);

 let myCostPctSay=makePct(myCost,totals['totCost'],0,'...');
 let myValuePctSay=makePct(myValue,totals['totAssetSale'],0,'...');
 let myNetValuePctSay=makePct(myNetValue,totals['totAssetSaleNetAT'],0,'...');

 let amess='';

 let aprice=parseFloat(davals['assets'][aname]['price']).toFixed(1);
 let qq=parseInt(davals['assets'][aname]['q']);
 let say1= (davals['assets'][aname]['assetType']==0)  ?  '(~ '+aprice+'*'+qq +')' : ' ' ;
 amess+='<span  title="Acquisition Cost '+say1+'" class="cmyCost_span">'+wsurvey.makeNumberK(myCost,30000);
 amess+=     '  <span  title="as % of total cost" class="cmyCostPct_span">'+ myCostPctSay+'</span></span> ';
 amess+='<span title="Pre tax (and pre loan payback) value" asset" class="cmyValue_span">'+wsurvey.makeNumberK(myValue,30000);
 amess+=     ' <span  title="as % of total value" class="cmyValuePct_span">'+ myValuePctSay+'</span> </span>';
 amess+='<span title="After tax (and after loan payback) value" class="cmyNetValue_span">'+wsurvey.makeNumberK(myNetValue,30000) ;
 amess+=   ' <span title="as % of netValue of portoflio (after repaying all loans and paying all capital gains taxes) " class="cmyNetValuePct_span">'+ myNetValuePctSay+'</span></span> ';

 let atype=astuff['assetType'];


 let myNetRevenue=astuff['yearlyRevenue'] - astuff['loanPayYearly'];
 if (atype==2) {
    let aadd=parseInt(astuff['addVal'] ) ;
    amess+='<span title="Yearly additions, or withdrawals (if negative) -- these are drawn (or added to) `Cash`" class="cmyNetRevenue_span">'+wsurvey.addComma(parseInt(aadd))+'</span>';

  }  else if (atype==3) {
    amess+='<span title="Yearly Rents + Yearly loan payments" class="cmyNetRevenue_span">'+wsurvey.addComma(parseInt(myNetRevenue))+'</span>';
 } else if (atype==4) {
    let aincome=parseInt(astuff['yearlyIncome'] ) ;
    amess+='<span title="Yearly income" class="cmyNetRevenue_span">'+wsurvey.makeNumberK(aincome,30000)+'</span>';
 } else if (atype==5) {
    let aincome=parseInt(astuff['yearlyAnnuity'] ) ;
    amess+='<span  class="cmyNetRevenue_span">'+wsurvey.makeNumberK(aincome,30000)+'</span>';

 } else if (atype==6) {
    let areceipt=parseInt(astuff['oneoffReceipt'] ) ;
    amess+='<span  title="oneOff receipt (+ for income, - for cost)" class="cmyNetRevenue_span">'+wsurvey.makeNumberK(areceipt,30000)+'</span>';

 } else if (atype==7) {
    let aexpense=parseInt(astuff['yearlyExpense'] ) ;
    amess+='<span title="Yearly expense" class="cmyNetRevenue_span">'+wsurvey.makeNumberK(aexpense,30000)+'</span>';

 } else {
    amess+='<span  class="cmyNetRevenue_span"> &hellip;</span>';
 }
 return amess;
 
 function makePct(anum,adenom,idef,saybad) {
     if (!jQuery.isNumeric(anum)) return saybad;
     if (!jQuery.isNumeric(adenom)) return saybad;
     if (adenom==0) return saybad ;
     let vv=100*anum/adenom;
     let vv2=vv.toFixed(idef);
     return vv2+'%';
 }


}


//=================
// return basic info (price, dividend, etc) (given current creation/modificatio ndate

function portfolioAssets_currentInfo(aname,jdate)  {

  let etable=$('#portfolioHistory1');
   if (typeof(jdate)=='undefined') {
    alert(aname+' '+jdate+'  undefined in portfolioAssets_currentInfo ' );
       let nojdate=noJdate1/51351;
       return 0;
   }
  if (arguments.length<2) {
      let oof1=getCreationDate('#portfolioMenu_initDateBlock');
      jdate=oof1.dayCount;
  }

   myValues=getAssetValue(jdate,aname,false,1 );

    if (myValues===false) {
       showDebug(myValues,'error: no entry for asset '+aname+' for  '+jdate,1);
       let noDateSaved=whyNoDate/6 ;
       return false;
   }

  let assetType=myValues['type'];
  let tbdSay='no info'  ;

   if (assetType==0) {
          let sprice= parseFloat(myValues['price']);

          let sdividend =parseFloat(myValues['dividend'])  ;
          let grate=100*sdividend/sprice;
          tbdSay='Price: '+sprice.toFixed(0)+', dividend='+sdividend.toFixed(1) +'  (growth='+grate.toFixed(1)+'%)' ;

   } else if (assetType==1) {
          let irate= parseFloat(myValues['interest']) ;
          let taxrate0=calcAsset_taxRate(aname,0);
          let ztaxrate= taxrate0 *100  ;
          tbdSay='Interest rate: '+irate.toFixed(1)+', taxRate='+ztaxrate.toFixed(1)+'%' ;

   } else if (assetType==2) {
          let irate= parseFloat(myValues['interest']) ;
          tbdSay='Tax-deferred interest rate: '+irate.toFixed(1) ;

   } else if (assetType==3) {
          let sprice=parseFloat(myValues['price']);
          let srent=parseFloat(myValues['rent']);
          let saleCost=parseFloat(myValues['saleCost']);
          if (!jQuery.isNumeric(saleCost)) saleCost=0;
          let taxrate0=calcAsset_taxRate(aname,1);
          let ztaxrate= taxrate0 *100  ;
          tbdSay='Price:: '+wsurvey.makeNumberK(sprice,1000000,0) +', Rent = '+srent.toFixed(0)+', capGainsTax='+ztaxrate.toFixed(1)+'%';
          tbdSay+=', saleCost = '+saleCost.toFixed(0)  ;

   } else if (assetType==4) {
          let sincome=parseFloat(myValues['income']);
          let taxrate0=calcAsset_taxRate(aname,0);
           let ztaxrate= taxrate0 *100  ;
             tbdSay='<span title="Yearly income" > Income: '+wsurvey.makeNumberK(parseInt(sincome),100000);
             tbdSay+=' </span>';
          tbdSay+=', taxRate='+ztaxrate.toFixed(0)+'%' ;

   } else if (assetType==5) {
       let grate,sincome;
       sincome=parseFloat(myValues['income']);
       grate= parseFloat(myValues['growthFrac']);
       let taxrate0=calcAsset_taxRate(aname,0);
       let ztaxrate= taxrate0 *100  ;
       let grateSay=(grate*100).toFixed(1);
       tbdSay='<span title="Base value of annuity ...  "> Annuity: '+wsurvey.makeNumberK(parseInt(sincome),100000);
       tbdDay=' Yearly growth: '+grateSay;
       tbdSay+=', taxRate='+ztaxrate.toFixed(0)+'%' ;

   } else if (assetType==6) {
          let sreceipt=parseFloat(myValues['receipt']);
             tbdSay='<span title="oneOff receipt" > Receipt: '+wsurvey.makeNumberK(parseInt(sreceipt),100000);
             tbdSay+=' </span>';

//          let taxrate0=calcAsset_taxRate(aname,0);         // 13 feb 2024 ... oneoffs are assumed to be post-tax
//         let ztaxrate= taxrate0 *100  ;
//          tbdSay+=', taxRate='+ztaxrate.toFixed(0)+'%' ;

   } else if (assetType==7) {
          let aexpense=parseFloat(myValues['expense']);
          let taxrate0=calcAsset_taxRate(aname,0);
           let ztaxrate= taxrate0 *100  ;
             tbdSay='<span title="Yearly income" > Expense: '+wsurvey.makeNumberK(parseInt(aexpense),100000);
             tbdSay+=' </span>';
          tbdSay+=', taxRate='+ztaxrate.toFixed(0)+'%' ;
   }

   return tbdSay ;
}


//===============   
// process one of the helper buttons for entering a numeric value (%, $, or k)

function addARowPortfolioAssetMix_type(athis,isbasis) {
  if (arguments.length<2) isbasis=0;
  let useme;
   let ethis=wsurvey.argJquery(athis);
   let atype=ethis.val();     // k % or $
   let etd=ethis.closest('td');
   let eshares,ispct=0,isdollar=0;
   if (isbasis==0) {
       eshares=etd.find('[name="portfolioShares"]');
   } else if (isbasis==2) {
       eshares=etd.find('[name="portfolioLoanAmount"]');
   } else if (isbasis==3) {
       eshares=etd.find('[name="portfolioPropertyBasis"]');
   } else {
       eshares=etd.find('[name="portfolioSharesBasis"]');
   }

// clear any $,%,or k from the number input field
   let ashares=jQuery.trim(eshares.val());
   if (ashares=='') ashares='0';
   let aprefix='';
   let a1=ashares.substr(0,1);
   if (a1=='$'  ) {
     ashares=ashares.substr(1);
   }
   if (a1=='#'  ) {
     ashares=ashares.substr(1);
   }

   let a2=ashares.substr(ashares.length-1,1);
   if (a2=='%') {
      ashares=ashares.substr(0,ashares.length-1);
   }

   if (atype=='k') {
     ashares=fixNumberValue(ashares+'k');   // an exsting k is incorporated, so adding k means "millions"
   }

   if (ashares===false) {
     eshares.val('');          // error (not a number), so clear it
   } else {
     if (atype=='$' ) {
         let xx=parseInt(ashares);  // round to nearest doallr)
         useme='$'+xx;
     } else if (atype=='%') {
         useme=ashares+'%';
     } else {
        useme=ashares;
     }
     eshares.val(useme);
   }
   return ashares ;
}


//=====================
// copy the asset mix of an existing portfolio
function copyPortfolio(athis) {
   let ethis=wsurvey.argJquery(athis);
   let pcurrent=ethis.attr('data-name');
   let amess='';

   amess+='<button style="margin-bottom:5px" title="Tips on copying an existing portfolio" onclick="displayHelpMessage(this)" data-div="#copyPortfolioHelp1">?</button>';
   amess+="Select a portfolio to copy: ";

  amess+='<ul class="linearMenu16Pct">';
  for (let acc in portfolioLookup['list']) {
     if (acc==pcurrent) continue ; // can't copy self
     if (portfolioLookup['list'][acc]['isInit']==0) continue ; // uninitialize portfolio
     let ij=portfolioLookup['list'][acc]['ith']  ;
     let xx=portfolioList[ij];
     amess+='<li><input type="button" data-name="'+acc+'" data-current="'+pcurrent+'" value="'+acc+'"   onClick="copyPortfolio2(this)">';
     amess==' <span class="cdescNoteLittle">'+xx['desc']+'</span>';
  }
  amess+='</ul>';

  displayStatusMessage(amess);

   return 0;

}


//=============
// copy the selected portfolio  (initialziation entry ... 27 june does not support copying a modification. Perhaps later?)
function copyPortfolio2(athis)  {

     let notes=[];
     let oof3a=getCreationDate('#portfolioMenu_initDateBlock');
     let  dateStamp=oof3a.dayCount  ;

    let ethis=wsurvey.argJquery(athis);
    let pname=ethis.attr('data-name');
    let pcurrent=ethis.attr('data-current');
    let pcurrentF=getAssetFamily(pcurrent,1);
    let useVariant=false;
    if (pcurrentF['variant']!='')  useVariant=pcurrentF['variant'];

    let copyRows=portfolioInit[pname]['assetList'];

    let etable=$('#portfolioHistory1');
    let eaButtons=etable.find('[name="portfolioTable_assetButtons_1"]');
    let nExists=0,nNotFamily=0,nAdd=0;
    for (let ii=0;ii<copyRows.length;ii++) {
      let acopyRow=JSON.parse(JSON.stringify(copyRows[ii])) ;  // clone
      let aname=acopyRow['name'];
      let anameUse=aname;
      if (useVariant!==false)  {            // copy variant specific assets?
         let anameF=getAssetFamily(aname,1);
         if (anameF['variant']!='')  {           // a variant asset -- use the useVariant verison
            anameUse=anameF['family']+'.'+useVariant;
        }
      }
      if (!assetLookup.hasOwnProperty(anameUse)) {
          nNotFamily++ ;
           notes.push('Asset <tt>'+anameUse+'</tt> is not available  ');
         continue ; // no such asset (i.e.; not a useVariant version of this asset)
      }
      acopyRow['name']=anameUse ;       // if variant is differnt

      let omess=portfolio_checkAssetAdded(aname);  // copyPortfolio2: missingasset? ALready in pmortoflio? Same family?

      if (omess!==false) {
         nExists++;
         continue ;          // don't bother showing message
      }

// add it (using this asset's specs from the copiedFrom portfolio

      addARowPortfolioAssetMix(0,acopyRow,1,dateStamp)  ; // copyPortfolio2 : add row to table: a copy of this assetspec. Note use 0 (not mod) to allow these to be modified
      nAdd++ ;

    }  // copyrows

    let nmess='<ul>';
    nmess+='<li>'+copyRows.length+' assets in <b>'+pname+'</b>';
    nmess+='<li> #added= <tt>'+nAdd+'</tt>, #alreadySpecified=<tt>'+nExists+'</tt>';
    if (notes.length>0) {        // possibly some variatn specific assets do not exist
       nmess+='<li><ol type="i">'+notes.join('<li>')+'</ol>';
    }
    nmess+='</ul>';
    displayStatusMessage(nmess);

   return 1;
}

//===========================
// remove a portfolio modification
// 12 feb 2024... there is some copy stuff in here that is probably deprecate
function showPortfolioHistoryRemove(athis) {
   let ethis=wsurvey.argJquery(athis);
   let pname=ethis.attr('data-name');
//   let ith=ethis.attr('data-which');
   let ith=ethis.attr('data-nth');
   let adate=ethis.attr('data-date');
   let nowTime=wsurvey.get_currentTime(31,1);

  let newList={'time':nowTime,'data':{}};
   let nmods=0;
   for (let aport in simInvDsets['allCurrentData']['portfolioModifications']['data']) {  // copy
     if (aport!=pname) {
       newList['data'][aport]=JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['portfolioModifications']['data'][aport])) ;
     }  else {
        for (let atime in simInvDsets['allCurrentData']['portfolioModifications']['data'][aport]) {
          nmods++ ;
          if (atime!=adate) {            // if match, then do NOT copy (ie; remove!)
              if (!newList['data'].hasOwnProperty(aport)) newList['data'][aport]={};
              newList['data'][aport][atime]=JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['portfolioModifications']['data'][aport][atime]));
          }
        }  // for atime
     }    // aport !=pname
  }     // aport in allcurtendata

  let dateSay=setEntryDate(adate).sayDate ;
  let okmess='Removing modification on '+dateSay+' from '+nmods+' modifications of portfolio '+pname ;

   simInvGlobals['temp']['autoLogonDetails']={'action':'portfolioModification','portfolio':pname} ;
  saveSimInvData_portfolioModification(userName,newList,okmess)  ;
    simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

 }


//========
// display one of a portfolio's date-specific asset-mixes (init, or a modification)
// called  from     showAllPortfolioValues_viewEntry    (simInv_showPortfolio.js)
//      use all the arguments
// or  as  click handler from 2 buttons created by showPortfolioViewModify   (simInv_portofolio_initModify.js)
//        -- one for  the "init"  entry, one and one for each of "mod" entries
//      (one argument, read other args from data- attriburtes

function showPortfolioMix(athis,pname,nth,adate,noRemove,hiLiteVar) {
  
  let noPrint=1;
  if (arguments.length<5) noRemove=0;              // only needed if called as click handler
  if (arguments.length<6) hiLiteVar=false;          // only needed if called as click handler

  if (arguments.length<4) {                    // only needed if called as click handler
    noPrint=0;
    let ethis=wsurvey.argJquery(athis);
    pname=ethis.attr('data-name');

    if (!portfolioInit.hasOwnProperty(pname)) {
       alert('No such portfolio ('+pname+') in portfolioInits ');      // should not happen
       return 0;
    }

    nth=ethis.attr('data-nth');
    adate=ethis.attr('data-date');

    let eul=ethis.closest('#portfolioModificationsList');
    let eli=eul.find('li');
    eli.removeClass('highlightThisLi')
    eli.addClass('notHighlightThisLi')
    eli0=ethis.closest('li');
    eli0.addClass('highlightThisLi')
    eli0.removeClass('notHighlightThisLi')

  }   // arguments < 4

  let isMod=0;

// pvals is from init or from a modification (of portfolio pname)

  let pVals,acommentModification='' ;
  if (nth==0) {
      pVals=portfolioInit[pname];
      acommentModification=pVals['comment'] ;
  } else {
      let aa=portfolioLookup['list'][pname];
      if (!aa['modDatesSay'].hasOwnProperty(adate)) {
         alert('No such modification ('+nth+') for '+pname);
         return false;
      }
      acommentModification=aa['comments'][adate];

      pVals=portfolioModifications[pname][adate];
      isMod=1;
  }

  let origBudget=portfolioInit[pname]['original']['budget'];

 let daDate=(pVals.hasOwnProperty('dateStamp')) ? pVals['dateStamp'] : pVals['endDate'];

  let sayDate=pVals['dateStampSay'];
  let nAssets=pVals['totals']['nAsset'];

  let dalist={};
   let pValsAssets=JSON.parse(JSON.stringify(pVals['assets']));
  let inputList=pVals['assetList'];


// the list of assets table ....
   let amess='';

   amess+='<div id="portfolioHistory1bOuter" style="height:50vh;margin-bottom:1em;overflow:auto">';
   amess+='<table border="1" id="portfolioHistory1b" width="98%"   class="cportfolioTable">';

// column names
   amess+='<tr bgcolor="#fbf6bc" class="headerRow">';
   amess+='<td width="1%" title="sort by: type of asset " > </td>';
   amess+='<td   width="10%" ><span  title="Name of an existing asset"><b>Asset Name</b></span>';
   amess+='</th>';
   amess+='<td width="14%"> <span title="# shares. For bonds: the dollar value. For stock: # of shares\nIf stock: (basis fraction)"><b>$ or #shares</b> </span>';
   amess+='<span title="For stocks, or properties: the sale price" style="float:right;margin-right:5px"> <em>price</em> </span>';
   amess+='</td>';
   amess+='<td width="23%">';
   amess+='    <span  class="cgrossValue" ';
   amess+='     title="Value of this asset (pre-tax, pre loan payout) "> Gross value ';
   amess+='</span>';
   amess+=' <span title="basis value (for stocks and properties)" class="portfolioAssetBasis">basis</span>  ';
//   amess+=' &vellip;';
   amess+=' </span>';
   amess+=' <span style="float:right;margin-right:0.5em">';
   amess+=' <span title="acquisition cost" class="sayCost">cost</span>  ';
   amess+=' <span title="approximate net value" class="sayNetValue">net Value</span>  ';
   amess+='<span>';
   amess+='</td>';
   amess+='<td width="16%" title="sort by: loan balance  " >';
   amess+=' <u>asset information</u>  (<tt>per year</tt>)';
   amess+=' </td>';

   let netRevenueHdr='<span title="Yearly net rents (after tax)\nYearly loan payments (before tax deductions)"  class="cnetRevenueHdr">netRent &amp; loan</span> ';
   let  taxPayHdr='<span class="ctaxHdr">';
   taxPayHdr+=' <span title="Percent (of income, earnings, or capital gains) that are taxFree\n 0%:fully taxed \n 100%: no tax" class="ctaxFreeFrac"><em>%taxFree</em></span> ';
//   taxPayHdr+=' <span title="Do losses (netRevenue or Income) offset other income? "  class="ctaxOffset"  ><em>losses</em></span>' ;
   taxPayHdr+='</span>';
   amess+='<td width="18%" title="sort by: cash flow (Rent, mortgage payments, income ... " > '+netRevenueHdr+' '+taxPayHdr+'<tt> </td>';

   amess+='<th width="18%" title="sort by: net value " > <span title="Comment">Comment</span></th>';
   amess+='</tr>';

// the cash row
  amess+='<tr class="portfolioHistoryRowCash"  >';
     amess+='<td > </td>';
   amess+='<td><u>Cash</u> </td>';
   let cashv=parseInt(pVals['cashAsset']);
   let dacash=wsurvey.addComma(cashv) ;
   amess+='<td>&nbsp;</td>    ';
   amess+='<td><span title="Remaining (unallocated) cash. If negative: the extra cash needed to obtain asset mix" class="cCashValue"  >';
   if (cashv>=0) {
     amess+='<tt>'+dacash+'</tt></span>'
   } else {
     amess+='<span style="color:red"> <tt>'+dacash+'</tt></span>'
   }
   amess+='</td>';
   amess+='<td>&nbsp;</td>    ';

   amess+='<td>';

   amess+='</td>';

   amess+='<td><span style="font-size:80%" title="if negative, required `Cash`">remaining, or required, <u>Cash</u></span></td>';
   amess+='</tr>'  ;

 let avDates=getAssetValueInfo(false,1);
  if (!avDates.hasOwnProperty(adate)) {                     // should never happen
    alert('Error in  showPortfolioMix: asset values not updated for '+adate);
    return false;
 }

// the rows for the assets ...
 let ijij=0;
  let totGross=0,totNet=0,totIncome=0,totIncomeNet=0,totRent=0,totRentNet=0,loanStuff=0;
  let totExpense=0,totExpenseAT=0 ;


  let assetComments={};
  for (let m1=0;m1<pVals['assetList'].length;m1++) {      // 25 oct 2023 : not in 'assets' object, so copy from list
      let aname=pVals['assetList'][m1]['name'];
      assetComments[aname]=pVals['assetList'][m1]['comment'];
  }

  for (let aaName in pValsAssets) {             // ---- for each asset in the portfolio ....  .............

     if (aaName=='Cash') continue ;
     let isPublic=doAssetLookup(aaName,'isPublic');

     let addGross=0,addNet=0,addIncome=0,addIncomeNet=0,addRent=0,addRentNet=0,addExpense=0,addExpenseAT=0 ;
     ijij++ ;

     let assetType=getAssetType(aaName);
     let aicon=getAssetType(aaName,'icon');

     let aValues=getAssetValue(adate,aaName,false,1) ;      // asset attributes (not portfolio specific)

     let a1=pValsAssets[aaName];            // attribure (#shares, etc) of this asset in this portfolio

     qhilite=0;
     if (hiLiteVar!=='' && aaName==hiLiteVar) qhilite=1 ;

     if (qhilite==1) {
          amess+='<tr class="priorityHistoryRow priorityHistoryRowHilite" data-name="'+aaName+'"  >';     // icon col
     } else {
          amess+='<tr class="priorityHistoryRow" data-name="'+aaName+'"  >';     // icon col
     }

     amess+='<td data-_sortuse="'+assetType+'"  >'+aicon+'</td>';
     amess+='<td data-_sortuse="'+aaName+'"  > ';            // name
     
     let aaNameSay= (isPublic==1) ? '<span style="color:brown" title="a public asset">&Pscr;</span>'+aaName : aaName ;
     let aaNameUse=aaName;
     if (pVals.hasOwnProperty('summaryChanges') && pVals['summaryChanges'].hasOwnProperty('newList') && pVals['summaryChanges']['newList'].hasOwnProperty(aaName)) {
         aaNameUse='<div title="asset added" class="portfolioMix_added">'+aaNameSay+'</div>';
     }
     if (pVals.hasOwnProperty('summaryChanges') && pVals['summaryChanges'].hasOwnProperty('changeList') && jQuery.inArray(aaName,pVals['summaryChanges']['changeList'])>-1) {
         aaNameUse='<div  title="asset modified" class="portfolioMix_change">'+aaNameSay+'</div>';
     }
     if (pVals.hasOwnProperty('summaryChanges') && pVals['summaryChanges'].hasOwnProperty('oneOffListNew') && pVals['summaryChanges']['oneOffListNew'].hasOwnProperty(aaName)) {
         aaNameUse='<div title="oneOff added" class="portfolioMix_oneOff">'+aaNameSay+'</div>';
     }

     amess+=aaNameUse ;
     amess+='</td>';


// col 3: #shares, or $ value, or yearly income,... (depends on type)
    let t1=showPortfolioMix_cell3(aaName,assetType,adate,a1,aValues);

    let amess1=t1[0];
    let annuityStuff=t1[1];    // to save some procssing
    amess+=amess1;

// cell 4: gross & net values, cost, basis
    t1=showPortfolioMix_cell4(aaName,assetType,adate,a1,aValues,annuityStuff);
    amess1=t1[0];    // [1] not currently used
    addGross=t1[1];
    addNet=t1[2];
    addIncome=t1[3];
    addIncomeNet=t1[4];
    addExpense=t1[5];
    addExpenseAT=t1[6];

    amess+=amess1;

// cell 5: asset info

   let adetails=(pVals.hasOwnProperty('grown')) ? pVals['grown']['assetDetails'][aaName] : {}  ;
   let aassets= pVals['assets'][aaName]    ;
   let amod= (pVals.hasOwnProperty('mod')) ?  pVals['assets'][aaName] : {} ;
    t1=showPortfolioMix_cell5(aaName,assetType,adate,a1,aValues,annuityStuff,ijij,pname,adetails,aassets,amod );
    amess1=t1[0];    // [1] not currently used
    loanStuff=t1[1];
    amess+=amess1;


// cell 6: revenue and loan
    t1=showPortfolioMix_cell6(aaName,assetType,adate,a1,aValues,annuityStuff,ijij,loanStuff);
    amess1=t1[0];    // [1] not currently used
    addRent=t1[1];
    addRentNet=t1[2];
    amess+=amess1;

// comment column
   let acomment=assetComments[aaName];
   amess1='<td data-_sortuse="'+ijij+'"  >'+acomment+'</td>';
   amess+=amess1;
   totGross+=addGross;
   totNet+=addNet;
   totIncome+=addIncome;
   totIncomeNet+=addIncomeNet ;
   totRent+=addRent;
   totRentNet+=addRentNet;
   totExpense+=addExpense; 
   totExpenseAT+=addExpenseAT;
  }     //  next aaname (assst rows)

  amess+='</table>';

  let daremoves=[];
  if (pVals.hasOwnProperty('summaryChanges') && pVals['summaryChanges'].hasOwnProperty('removeList') ) {
    for (let da1 in pVals['summaryChanges']['removeList']) {
        daremoves.push(da1);
    }
  }
  if (daremoves.length>0)  {
     let sayRemoves='<div class="portfolioMix_dropLine">Dropped assets: ';
     sayRemoves+='<span class="portfolioMix_drop">'+daremoves.join('</span><span class="portfolioMix_drop">')+'</span>';
     amess+=sayRemoves;
 }

  let totNet2=totNet+pVals['cashAsset'];


  let totRevenue=totIncome+totRent;
  let totRevenueNet=totIncomeNet+totRentNet ;
  
   let amessTop='';
   amessTop+='Portfolio <span style="font-size:110%;background-color:lime">'+pname+'</span> on <span title="'+daDate+'" style="text-decoration:underline">'+sayDate+'</span> :: ';
   amessTop+=' <span title="Net value -- after taxes ('+parseInt(totNet)+' +  `Cash`)"> netValue  =<tt>'+wsurvey.addComma(parseInt(totNet2))+'</tt></span>' ;
   amessTop+=' <span class="cgrossValue" title="Gross (pre-tax, pre loan payout) value"> Gross value: <tt>'+wsurvey.addComma(parseInt(totGross))+'</tt></span>'
   amessTop+=' <span class="cgrossValueIncome" title="Net yearly:  after tax revenue (rents + incomeStreams +annuities) = '+parseInt(totRevenue)+' minus taxes">netRevenue<tt>= '+wsurvey.addComma(parseInt(totRevenueNet))+'</tt></span>'
   amessTop+=' <span class="cgrossValueExpense title="Net yearly: after tax expenses) = '+parseInt(totExpense)+' minus taxes">netExpenses<tt>= '+wsurvey.addComma(parseInt(totExpenseAT))+'</tt></span>'

   if (noRemove!=1) {          // suppress if called by showAllPortfolioValues_viewEntry
     amessTop+='<span name="nshowPortfolioHistoryRemove"  style="border:1px solid blue;margin-left:2em;padding:3px">';
     if (nth!=0) {
       amessTop+=' &nbsp;<button title="Remove this modification   " onClick="showPortfolioHistoryRemove(this)"  ';
       amessTop+='     data-name="'+pname+'" data-nth="'+nth+'" data-date="'+adate+'" >';
       amessTop+='Remove </button> ';
     }
     amessTop+='</span>';
   }
   amessTop+='<span class="cmodComment" ><em>Comment:</em> '+acommentModification+'</span>'

// -- put it togther ...  .
  let amessBig=amessTop+'<p>'+amess;
  amessBig+='</div>';

  if (noPrint==1) return amessBig ;      // called from showAllPortfolioValues_viewInit

// spot for transcations
   amessBig+='<div id="iPortfolioTransactions" class="cPortfolioTransactions" style="display:none" data-made="0"> .... .... </div> ';

  $('#mainDiv3b').html(amessBig);

    showPortfolioViewModify_listMods(0,pname,simInvParams['showTransactions'],1);  // display list of init and mods .. using the showTransactions mode

  wsurvey.sortTable.init('portfolioHistory1b',{'startRow':2});

// resize   portfolioHistory1bOuter (in   mainDiv3b)
   fixmyheight_maindiv3b(1)
  return 1;


}

//=======
// fix height of portfolioHistory1bOuter in mainDIv3 in maindiv

function fixmyheight_maindiv3b(ii) {
   let emain=$('#mainDiv');
   let heightMain=parseInt(emain.height());
   let itry=heightMain-10 ;
   let itry2=heightMain-14 ;

   let emain3b=$('#mainDiv3b');
   emain3b.height(itry+'px');

   let etable=emain.find('#portfolioHistory1bOuter');
   emain3b.height(itry2+'px');

   let heightMain3b=parseInt(emain3b.height());

   let ntries=0;
   for (let ido=0;ido<20;ido++) {        // shrink 3b and 1bouter until mainDiv scrollbars are gone
     let sc2=(wsurvey.isScrollable(emain))  ? 1 : 0 ;
     if (sc2==1) {
         ntries++;
          let i1=parseInt(0.97*heightMain3b) ;
          emain3b.height(i1+'px');
          heightMain3b=emain3b.height();
          let i2=i1-4 ;
          etable.height(i2+'px');
     }
   }

   return 1 ;

}


// helper functions
function showPortfolioMix_cell3(aaName,assetType,adate,a1,aValues) {
 
     let amess1='',other={};
     if (assetType==0) {               // bond
       let nshares=(a1.hasOwnProperty('q')) ? parseFloat(a1['q'])   : parseFloat(a1['nShares']) ;    // 12 feb 2024.. should change 'q' to 'nShares'
       let aprice=parseFloat(aValues['price']);
       amess1='<td data-sortUse="'+nshares+'">';
       let nsharesSay=wsurvey.makeNumberK(parseInt(nshares),10000);
       amess1+='<span title="# of shares: "'+parseInt(nshares)+'">'+nsharesSay+'</span>';
       let apriceSay=aprice.toFixed(2);
       if (aprice>1000) apriceSay=wsurvey.makeNumberK(parseInt(aprice),10000);
       amess1+='<span class="cpriceThisDate" title="Current price">'+apriceSay+'</span>';
       amess1+='</td>';

     } else if (assetType==1) {           // bond
       let nshares=(a1.hasOwnProperty('q')) ? parseFloat(a1['q'])  : parseFloat(a1['nShares']) ;    // 12 feb 2024.. should change 'q' to 'nShares'
       amess1='<td data-sortUse="'+nshares+'">';
       let nsharesSay=wsurvey.makeNumberK(parseInt(nshares),10000);
       amess1+='<span title="Dollars in this asset:'+parseInt(nshares)+'">$'+nsharesSay+'</span>';
       amess1+='<span class="cpriceThisDate" title="price n.a. ...">&hellip;</span>';
       amess1+='</td>';

    } else if (assetType==2) {           // tax defered bond
       let nshares=(a1.hasOwnProperty('q')) ? parseFloat(a1['q'])  : parseFloat(a1['nShares']) ;    // 12 feb 2024.. should change 'q' to 'nShares'
       amess1='<td data-sortUse="'+nshares+'">';
       let nsharesSay=wsurvey.makeNumberK(parseInt(nshares),10000);
       amess1+='<span title="Pre-tax dollars in this tax deferred asset: '+parseInt(nshares)+'"">$'+nsharesSay+'</span>';
       amess1+='<span class="cpriceThisDate" title="price is 1.0 per dollar">&hellip;</span>';
       amess1+='</td>';

    } else if (assetType==3) {           // property
       amess1='<td data-sortUse="3">';
       amess1+='<span title="One unit of this property">&hellip;</span>';

       let origPrice=parseFloat(a1['origPrice']) ;
       let origPriceSay=wsurvey.makeNumberK(parseInt(origPrice),10000);
       amess1+='<span  class="cpriceThisDate"  title="Original price of property: '+parseInt(origPrice)+'">$'+origPriceSay+'</span>';
       amess1+='</td>';

    } else if (assetType==4) {           // income
        amess1='<td data-sortUse="4">';
       let aincome=parseFloat(aValues['income']);
       aincomeSay=wsurvey.makeNumberK(parseInt(aincome),10000);
       amess1+='<span style="color:green" title="Yearly income stream: '+parseInt(aincome)+'"> $'+aincomeSay+'</span>';
       amess1+='<span class="cpriceThisDate" title="price n.a.">&hellip;</span>';
       amess1+='</td>';

    } else if (assetType==5) {           // annuity

      amess1='<td data-sortUse="1">';
      let astart=a1['incomeStart'];            //    aincomeBase=parseFloat(aValues['income']);
      let vv=calcAnnuityValue(aaName,astart,adate)  ;     // [baseValue,baseGrowth,calcValue,day1,day2,dointerp,growthRateAgg]
      let aincome=vv[2];
       aincomeSay=wsurvey.makeNumberK(parseInt(aincome),10000);
       amess1+='<span  style="color:darkgreen" title="Current yearly annuity: '+parseInt(aincome)+' "> $'+aincomeSay+'</span>';
       amess1+='<span class="cpriceThisDate" title="price n.a.">&hellip;</span>';
       amess1+='</td>';
       other=vv;                             // used to save repetitive processing

    } else if (assetType==6) {           // oneOff
        amess1='<td data-sortUse="4">';
       let areceipt=parseFloat(aValues['receipt']);
       areceiptSay=wsurvey.makeNumberK(parseInt(areceipt),10000);
       amess1+='<span  style="color:#63794f;" title="oneOff receipt: '+parseInt(areceipt)+'"> $'+areceiptSay+'</span>';
       amess1+='</td>';

    } else if (assetType==7) {           // expense
        amess1='<td data-sortUse="4">';
       let aexpense=parseFloat(aValues['expense']);
       aexpenseSay=wsurvey.makeNumberK(parseInt(aexpense),10000);
       amess1+='<span style="color:green" title="Yearly expense stream: '+parseInt(aexpense)+'"> $'+aexpenseSay+'</span>';
//       amess1+='<span class="cpriceThisDate" title="price n.a.">&hellip;</span>';
       amess1+='</td>';

    }               // cell 3
    return [amess1,other];
}


//=========
// cell 4: gross value or original, basis, cost, net value
function showPortfolioMix_cell4(aaName,assetType,adate,a1,aValues,annuityStuff) {
   let amess1='',addNet=0,addGross=0,addRevenue=0,addRevenueNet=0,addExpense=0,addExpenseAT=0;

   if (assetType==0) {               // bond
       let nshares=(a1.hasOwnProperty('q')) ? parseFloat(a1['q'])  : parseFloat(a1['nShares']) ;    // 12 feb 2024.. should change 'q' to 'nShares'

       let aprice=parseFloat(aValues['price']);
        let gvalue=nshares*aprice;
       amess1='<td data-sortUse="'+gvalue+'">';
       let valueSay=wsurvey.makeNumberK(parseInt(gvalue),10000);
       amess1+='<span class="cgrossValue" title="$ value of shares">$'+valueSay+'</span>';

       let abasis=parseFloat(a1['basis']);
       let abasisSay=wsurvey.makeNumberK(parseInt(abasis),10000);
       amess1+='<span class="portfolioAssetBasis" title="basis">$'+abasisSay+'</span>';

       amess1+=' <span style="float:right;margin-right:0.5em">';

       let acost=parseFloat(a1['cost']);
       let acostSay=wsurvey.makeNumberK(parseInt(acost),10000);
       amess1+='<span class="sayCost" title="cost of purchase of shares">$'+acostSay+'</span>';

       let capGains=gvalue-abasis;            // 25 jan 2024 -- may need tweaking (to correct for approximateion errors)

       let tax1= parseFloat(calcAsset_taxAmount(aaName,capGains,1)) ;
       let   net1=(gvalue-tax1);
       let net1Say=wsurvey.makeNumberK(parseInt(net1),10000);

       amess1+='<span  class="sayNetValue"  style="float:right;margin-right:1em"  title="net value (capital gains tax='+parseInt(tax1)+')">$'+net1Say+'</span>';
       amess1+='</span>';

       addGross=gvalue;
       addNet=net1;

     } else if (assetType==1) {           // bond

//       let gvalue=parseFloat(a1['q']) ;
       let gvalue=(a1.hasOwnProperty('q')) ? parseFloat(a1['q'])  : parseFloat(a1['nShares']) ;    // 12 feb 2024.. should change 'q' to 'nShares'
       amess1='<td data-sortUse="'+gvalue+'">';
       let valueSay=wsurvey.makeNumberK(parseInt(gvalue),10000);
       amess1+='<span   class="cgrossValue"  title="$ value of asset">$'+valueSay+'</span>';

       amess1+='<span class="portfolioAssetBasis" title="basis n.a.">&hellip;</span>';

       amess1+=' <span style="float:right;margin-right:0.5em">';

       let acost=parseFloat(a1['cost']);
       let acostSay=wsurvey.makeNumberK(parseInt(acost),10000);
       amess1+='<span class="sayCost" title="cost of purchase">$'+acostSay+'</span>';

       let  net1=gvalue;
       let net1Say=wsurvey.makeNumberK(parseInt(net1),10000);
       amess1+='<span  class="sayNetValue"   style="float:right;margin-right:1em" title="net value (no taxes on withdrawal)">$'+net1Say+'</span>';
       amess1+='</span>';
       amess1+='</td>';

       addGross=gvalue;
       addNet=net1;


    } else if (assetType==2) {           // tax defered bond
//       let gvalue=parseFloat(a1['q']) ;
       let gvalue=(a1.hasOwnProperty('q')) ? parseFloat(a1['q'])  : parseFloat(a1['nShares']) ;    // 12 feb 2024.. should change 'q' to 'nShares'
       amess1='<td data-sortUse="'+gvalue+'">';
       let valueSay=wsurvey.makeNumberK(parseInt(gvalue),10000);
       amess1+='<span  class="cgrossValue"  title="$ value of asset">$'+valueSay+'</span>';

       amess1+='<span class="portfolioAssetBasis" title="basis n.a.">&hellip;</span>';

       amess1+=' <span style="float:right;margin-right:0.5em">';

       let acost=parseFloat(a1['cost']);
       let acostSay=wsurvey.makeNumberK(parseInt(acost),10000);
       amess1+='<span class="sayCost" title="cost of purchase">$'+acostSay+'</span>';

       let atax=calcAsset_taxAmount(aaName,gvalue,1);
       let net1=gvalue-atax;
       let net1Say=wsurvey.makeNumberK(parseInt(net1),10000);
       amess1+='<span  class="sayNetValue"  style="float:right;margin-right:1em"  title="net value (tax on withdrawal='+parseInt(atax)+')" )">$'+net1Say+'</span>';
       amess1+='</span>';
       amess1+='</td>';

       addGross=gvalue;
       addNet=net1;


    } else if (assetType==3) {           // property
       let nowPrice=parseFloat(aValues['price']);
       let nowPriceSay=wsurvey.makeNumberK(parseInt(nowPrice),10000);
       amess1='<td data-sortUse="'+nowPrice+'">';
       amess1+='<span class="cgrossValue" title="Current sale price of property: '+parseInt(nowPrice)+'">$'+nowPriceSay+'</span>';

       let abasis=parseFloat(a1['basis']);
       let abasisSay=wsurvey.makeNumberK(parseInt(abasis),10000);
       amess1+='<span class="portfolioAssetBasis" title="basis: '+parseInt(abasis)+'">$'+abasisSay+'</span>';

       amess1+=' <span style="float:right;margin-right:0.5em">';

       let acost=parseFloat(a1['cost']);
       let acostSay=wsurvey.makeNumberK(parseInt(acost),10000);
       amess1+='<span class="sayCost" title="Acquisition cost (when acquired)">$'+acostSay+'</span>';

       let loanOwed=parseFloat(a1['loanOwed']);    
       if (!jQuery.isNumeric(loanOwed)) loanOwed=0;
       let nowValue= nowPrice-loanOwed;
       let capGains=nowPrice-abasis;
       let tax1= parseFloat(calcAsset_taxAmount(aaName,capGains,1)) ;
       let net1=nowValue-tax1;
       let net1Say=wsurvey.makeNumberK(parseInt(net1),10000);
       amess1+='<span  class="sayNetValue"   style="float:right;margin-right:1em"  title="net value: '+parseInt(net1)+'  \n after loan balance='+parseInt(loanOwed)+', and capital gains tax='+parseInt(tax1)+'">$'+net1Say+'</span>';
        amess1+='</span>';

       amess1+='</td>';

       addGross=nowPrice;
       addNet=net1;


    } else if (assetType==4 ) {           //  incomeStream
       let aincome=parseFloat(aValues['income']);
       amess1='<td data-sortUse="'+aincome+'">';
       aincomeSay=wsurvey.makeNumberK(parseInt(aincome),10000);
       amess1+='<span  class="cgrossValueIncome"  title="Yearly income stream: '+parseInt(aincome)+'"> $'+aincomeSay+'</span>';

       amess1+='<span class="portfolioAssetBasis" title="basis n.a.">&hellip;</span>';

         amess1+=' <span style="float:right;margin-right:0.5em">';

       let acost=(a1.hasOwnProperty('acqCost')) ? parseFloat(a1['acqCost']) : parseFloat(a1['origCost'])   ;

       let acostSay=wsurvey.makeNumberK(parseInt(acost),10000);
       amess1+='<span class="sayCost" title="Acquisition cost  ... ">$'+acostSay+'</span>';

       let tax1= parseFloat(calcAsset_taxAmount(aaName,aincome,0)) ;
       let net1=aincome-tax1;
       let net1Say=wsurvey.makeNumberK(parseInt(net1),10000);
       amess1+='<span  class="sayNetValueIncome"   style="float:right;margin-right:1em"  title="After tax value  (tax='+parseInt(tax1)+')">$'+net1Say+'</span>';
       amess1+='</span>';

        amess1+='</td>';

       addRevenue=aincome;
       addRevenueNet=net1 ;

    } else if (assetType==5) {           // annuity ... annuityStuff:  [baseValue,baseGrowth,calcValue,day1,day2,dointerp,growthRateAgg]
    
       let aincome=parseFloat(annuityStuff[2]);
       amess1='<td data-sortUse="'+aincome+'">';
       aincomeSay=wsurvey.makeNumberK(parseInt(aincome),10000);
       amess1+='<span  class="cgrossValueIncome"  title="Yearly annuity: '+parseInt(aincome)+'"> $'+aincomeSay+'</span>';

       amess1+='<span class="portfolioAssetBasis" title="basis n.a.">&hellip;</span>';

       amess1+=' <span style="float:right;margin-right:0.5em">';


       let acost=(a1.hasOwnProperty('acqCost')) ? parseFloat(a1['acqCost']) : parseFloat(a1['origCost'])   ;
       let acostSay=wsurvey.makeNumberK(parseInt(acost),10000);
       amess1+='<span class="sayCost" title="Acquisition cost  ">$'+acostSay+'</span>';

       let tax1= parseFloat(calcAsset_taxAmount(aaName,aincome,0)) ;
       let net1=aincome-tax1;
       let net1Say=wsurvey.makeNumberK(parseInt(net1),10000);
       amess1+='<span  class="sayNetValueIncome" style="float:right;margin-right:1em" title="After tax value  (tax='+parseInt(tax1)+')">$'+net1Say+'</span>';
       amess1+='</span>';

       amess1+='</td>';

       addRevenue=aincome;
       addRevenueNet=net1 ;

    } else if (assetType==6) {           //  oneOff
       let areceipt=parseFloat(aValues['receipt']);
       amess1='<td data-sortUse="'+areceipt+'">';
       areceiptSay=wsurvey.makeNumberK(parseInt(areceipt),10000);
       amess1+='<span  class="cgrossValueIncome"  title="oneOff receipt: '+parseInt(areceipt)+'"> $'+areceiptSay+'</span>';

       amess1+='<span  class="sayNetValueIncome"   style="float:right;margin-right:1em"  title="oneOffs have no asset value">0</span>';

       amess1+='</td>';

       addRevenue=0;
       addRevenueNet=0 ;

    } else if (assetType==7 ) {           //  expenseStream
       let aexpense=parseFloat(aValues['expense']);
       amess1='<td data-sortUse="'+aexpense+'">';
       aexpenseSay=wsurvey.makeNumberK(parseInt(aexpense),10000);
       amess1+='<span  class="cgrossValueIncome"  title="Yearly expense stream: '+parseInt(aexpense)+'"> $'+aexpenseSay+'</span>';

//       amess1+='<span class="portfolioAssetBasis" title="basis n.a.">&hellip;</span>';

       amess1+=' <span style="float:right;margin-right:0.5em">';

       let tax1= parseFloat(calcAsset_taxAmount(aaName,aexpense,0)) ;
       let net1=aexpense-tax1;
       let net1Say=wsurvey.makeNumberK(parseInt(net1),10000);
       amess1+='<span  class="sayNetValueExpense"   style="float:right;margin-right:1em"  title="After tax cost  (tax='+parseInt(tax1)+')">$'+net1Say+'</span>';
       amess1+='</span>';

        amess1+='</td>';
        addExpense=aexpense;
        addExpenseAT=net1 ;

    }

    return [amess1,addGross,addNet,addRevenue,addRevenueNet,addExpense,addExpenseAT];
}

//=======
// cel l5: asset info
function   showPortfolioMix_cell5(aaName,assetType,adate,a1,aValues,annuityStuff,ijij,pname,adetails,aasset,amod) {


  let amess1='',loanStuff=0;

  if (assetType==0) {    //    stodks
       amess1='<td data-sortUse="'+ijij+'">';
       let adividend=parseFloat(aValues['dividend']) ;
       let aSay=adividend.toFixed(2);
       if (adividend>99) aSay=wsurvey.makeNumberK(adividend,100);
       amess1+='<span title="per share yearly dividend "><em>Dividend</em>: '+aSay+'</span>';
       amess1+='</td>';

   } else if (assetType==1) {   // regular bonds

       amess1='<td data-sortUse="'+ijij+'">';
       let ainterest=parseFloat(aValues['interest']) ;
       let aSay=ainterest.toFixed(1);
       let aadd ;
       if (amod.hasOwnProperty('addVal')) {    // a modification (with a specified addition )
           aadd=amod['addVal'];
       } else    {
           aadd=(adetails.hasOwnProperty('addValYearly')) ? parseFloat(adetails['addValYearly']) : parseFloat(aasset['addValYearly']) ;    // init stores addValYearlin a1
       }
       let aaddSay=wsurvey.makeNumberK(aadd,100);

       amess1+='<span title="Yearly interest rate. I "><em>Interest</em>: '+aSay+'%</span>';
       amess1+=' <span style="margin-left:0.5em;border-left:1px solid gray;padding:5px"  ';
       amess1+='    title="Yearly additions (drawn from `Cash`).\n If negative, withdrawals added to `Cash`: '+parseInt(aadd)+'"><em>Add</em>: $'+aaddSay+'</span>';
       amess1+='</td>';

   } else if (assetType==2) {   // tax deferred bonds

       amess1='<td data-sortUse="'+ijij+'">';
       let ainterest=parseFloat(aValues['interest']) ;
       let aSay=ainterest.toFixed(1);
       amess1+='<span title="Yearly interest rate.   "><em>Interest</em>:&nbsp;'+aSay+'%</span> ';
       if (amod.hasOwnProperty('addVal')) {    // a modification (with a specified addition )
           aadd=amod['addVal'];
       } else   {
          aadd=(adetails.hasOwnProperty('addValYearly')) ? parseFloat(adetails['addValYearly']) : parseFloat(aasset['addValYearly']) ;    // init stores addValYearlin a1
       }
       let aaddSay=wsurvey.makeNumberK(aadd,100);

       let doRMD=parseInt(a1['doRMD']);
       if (doRMD==0) {
         amess1+='<span  style="margin-left:0.5em;border-left:1px solid gray;padding:5px" title="Yearly additions (drawn from `Cash`).\n If negative, withdrawals send to `Cash`: '+parseInt(aadd)+'"><em>Add</em>:&nbsp;$'+aaddSay+'</span> ';
       } else {                                                         // rmd
          amess1+='<span  style="margin-left:0.5em;border-left:1px solid gray;padding:5px" title="RMD distribution (current per year amount): '+parseInt(aadd)+'">';
          amess1+='<em>Add</em>:&nbsp;$'+aaddSay+'</span> ';

          let startAge=a1['nowAge'];
          let aStart= (a1.hasOwnProperty('rmdStart')) ? parseInt(a1['rmdStart']) : parseInt(a1['incomeStart']);
          let dd=(parseInt(adate)-aStart)/365.0;
          let  nowAge=startAge+dd;
          let nowAgeSay=nowAge.toFixed(1);
          let afact=growPortfolio_rmdFrac(nowAge,doRMD);
          let sayFrac=afact.toFixed(2);
          let btype=(doRMD==1) ? 'Self' : 'Beneficiary';
          amess1+='<span  style="margin-left:0.5em;border-left:1px solid gray;padding:5px"  ';
          amess1+='      title="Current RMD ('+btype+') fraction (of asset value) -- at age '+nowAgeSay+'">';
          amess1+='<em>RMD&nbsp;weight</em>:&nbsp;'+sayFrac+'</span>';
       }
       amess1+='</td>';

   } else if (assetType==3) {   // property ... include loan info

          amess1='<td data-sortUse="'+ijij+'">';
          let qLoan=true;
          if (a1.hasOwnProperty('loanSchedule')) {    // used in init entries
              if (a1['loanSchedule']===false) qLoan=false;
          } else if (a1.hasOwnProperty('loanStart')) {        // used in mod entries
              if (a1['loanStart']===false) qLoan=false;
          }
          if (qLoan===false) {
             amess1+='&hellip;';
          } else {

             let loanOrig,arate,aterm,isDeduct,loanStart,refiEnabled;
             if (a1.hasOwnProperty('loanSchedule')) {          // used in init entries
                loanOrig= parseFloat(a1['loanSchedule']['amount']);
                arate=parseFloat(a1['loanSchedule']['rate']);
                aterm=parseFloat(a1['loanSchedule']['term']);
                isDeduct=a1['loanSchedule']['taxDeduct'];
                loanStart=a1['loanSchedule']['startDate'];
                refiEnabled=false
             } else {                                     // used in mod entries
                loanOrig= parseFloat(a1['loanAmount']);
                arate=parseFloat(a1['loanRate']);
                aterm=parseFloat(a1['loanTerm']);
                isDeduct=a1['loanTaxDeduct'];
                loanStart=a1['loanStart'];
                refiEnabled=a1['refiEnabled'];
             }
             let arf=getLoanInfo(pname,loanStart,aaName,loanOrig,adate,arate,aterm,isDeduct,pname);
             loanStuff=arf;
             let owed=arf['loanOwed'];
             let owedSay=wsurvey.makeNumberK(parseInt(owed),100);
             let sayRate=arate.toFixed(1);
             let sayTerm=parseInt(aterm);
             amess1+='<input type="button" value="Vu" title="Click to view loan schedule"  ';
             amess1+='      data-amount="'+loanOrig+'" data-term="'+aterm+'" data-rate="'+arate+'" data-taxded="'+isDeduct+'"  ';
             amess1+= '      data-asset="'+aaName+'" data-start="'+loanStart+'" onclick="specifyLoanScheduleC(this)">&nbsp;';
             amess1+='<span title="Outstanding loan. Original loan='+parseInt(loanOrig)+'"><em>Owed</em>:&nbsp;$'+owedSay+'</span> ';
             amess1+='<span style="border-left:1px solid gray;font-size:90%;margin-left:0.25em;padding:2px"   title="Interest rate"><em>Rate</em>:&nbsp;'+sayRate+'</span>';
             amess1+='<span style="font-size:90%;margin-left:0.25em;border-left:1px dotted gray;padding:2px"   title="Term (years)"><em>Term</em>:&nbsp;'+sayTerm+'</span>';
          }
       amess1+='</td>';

   } else if (assetType==4) {   // income -- nothing to report
       amess1='<td data-sortUse="'+ijij+'">';
       amess1+='&hellip;  ';
       amess1+='</td>';

   } else if (assetType==5) {   // annuity -- base values      [baseValue,baseGrowth,calcValue,day1,day2,dointerp,growthRateAgg]
        amess1='<td data-sortUse="'+ijij+'">';
       let baseIncome=parseFloat(annuityStuff[0]) ;
       aincomeSay=wsurvey.makeNumberK(parseInt(baseIncome),10000);
       amess1+='<span title="Annuity starting income (used to compute current annuity): '+parseInt(baseIncome)+'"><em>base</em>: $'+aincomeSay+'</span>';

       let baseGrowth=parseFloat(annuityStuff[1]) ;
       let sayGrowth=baseGrowth.toFixed(2);
       amess1+='<span style="font-size:90%;margin-left:0.25em;border-left:1px solid gray;padding:2px" title="CPI fraction -- `annuity starting income` grows using this fraction of CPI  "><em>weight</em>: '+sayGrowth+'</span>';
       amess1+='</td>';

   } else if (assetType==6) {   // oneOff -- nothing to report
       amess1='<td data-sortUse="'+ijij+'">';
       amess1+='&hellip;  ';
       amess1+='</td>';

   } else if (assetType==7) {   // income -- nothing to report
       amess1='<td data-sortUse="'+ijij+'">';
       amess1+='&hellip;  ';
       amess1+='</td>';

    }
    
   return [amess1,loanStuff];
}

//========
// revenue / loan / tax  colupmn
function showPortfolioMix_cell6(aaName,assetType,adate,a1,aValues,annuityStuff,ijij,loanStuff) {
   let amess1,other=0,other2=0;

    amess1='<td  data-_sortuse="'+ijij+'"  >';
    if (assetType==0) {               // bond
       amess1='<td data-sortUse="0">';

       amess1+='<span style="float:right;margin-right:0.5em">';
       amess1+='<span title="On withdrawal, capital gains are fully taxed  " class="ctaxFreeFrac"><em>fully taxed</em></span>';
//       amess1+='       <span title="..." class="ctaxOffset">&hellip;</span>';
       amess1+='</span>';
       amess1+='</td>';

     } else if (assetType==1) {           // bond
       amess1='<td data-sortUse="1">';
       let aTaxFree=parseFloat(aValues['taxFreeFrac']);
       let apct=100*aTaxFree;
       let sayTaxFree=apct.toFixed(0);
       amess1+='<span style="float:right;margin-right:0.5em">';
       amess1+='<span title="% of yearly interest earnings that are tax free" class="ctaxFreeFrac">'+apct+'%</span>';
//       amess1+='       <span title="..." class="ctaxOffset">&hellip;</span>';
       amess1+='</span>';

       amess1+='</td>';
    } else if (assetType==2) {           // tax defered bond
       amess1='<td data-sortUse="2">';
       amess1+='<span style="float:right;margin-right:0.5em">';
       amess1+='<span title="Withdrawals of tax-deferred assets are fully taxed" class="ctaxFreeFrac"><em>fully taxed</em> </span>';
//       amess1+='       <span title="..." class="ctaxOffset">&hellip;</span>';
       amess1+='</span>';
       amess1+='</td>';

    } else if (assetType==3) {           // property
       amess1='<td data-sortUse="3">';
       let ataxFrac=parseFloat(aValues['taxFreeFrac']);
       let apct=100*ataxFrac;
         let sayAtaxFrac=apct.toFixed(0);

       let arent=parseFloat(aValues['rent']);
         let sayArent=wsurvey.makeNumberK(parseInt(arent),10000);

       let tax1= parseFloat(calcAsset_taxAmount(aaName,arent,0)) ;
       let netRent=arent-tax1;


       amess1+='<span  title="Yearly rents (net of costs, pre tax)"   style="color:green;padding:3px;font-family:monospace">'+sayArent+'</span>';
       if  (a1.hasOwnProperty('loanSchedule') && a1['loanSchedule']!==false) {
          let yearPay=parseFloat(loanStuff['yearPay']);
          let sayYearPay= wsurvey.makeNumberK(parseInt(yearPay),40000);
          amess1+='<span  title="Yearly loan payments (pre-tax)" style="border-left:1px solid black;padding:3px;font-family:monospace">'+sayYearPay+'</span>';
       } else {
          amess1+='<span   style="border-bottom:1px dotted blue;margin-left:1em;min-width:4em;display:inline-block">&hellip;</span>';
       }

       amess1+='<span style="float:right;margin-right:0.5em">';
       amess1+='<span title="Fraction of capital gains (when sold) that are tax free" class="ctaxFreeFrac">'+sayAtaxFrac+'%</span>';

       amess1+='</span>';
       amess1+='</td>';

       other=arent;
       other2=netRent

    } else if (assetType==4) {           // income
        amess1='<td data-sortUse="4">';
       let aincome=parseFloat(aValues['income']);
       let ataxFrac=parseFloat(aValues['taxFreeFrac']);
       let apct=100*ataxFrac;
         let sayAtaxFrac=apct.toFixed(0);

       amess1+='<span style="float:right;margin-right:0.5em">';
       amess1+='<span title="Fraction of yearly income that is tax free" class="ctaxFreeFrac">'+apct+'%</span>';

        amess1+='</span>';
        amess1+='</td>';

    } else if (assetType==5) {           // annuity
       amess1='<td data-sortUse="5">';
       let aincome=parseFloat(aValues['income']);
       let ataxFrac=parseFloat(aValues['taxFreeFrac']);
       let apct=100*ataxFrac;
         let sayAtaxFrac=apct.toFixed(0);

       amess1+='<span style="float:right;margin-right:0.5em">';
       amess1+='<span title="Fraction of yearly annuity that is tax free" class="ctaxFreeFrac">'+apct+'%</span>';

        amess1+='</span>';
        amess1+='</td>';

    } else if (assetType==6) {           // oneOff
        amess1='<td data-sortUse="6">';
       let areceipt=parseFloat(aValues['receipt']);
       let ataxFrac=parseFloat(aValues['taxFreeFrac']);
       let apct=100*ataxFrac;
         let sayAtaxFrac=apct.toFixed(0);

       amess1+='<span style="float:right;margin-right:0.5em">';
       amess1+='<span title="Fraction of oneOff receipt that is tax free" class="ctaxFreeFrac">'+apct+'%</span>';

        amess1+='</span>';
        amess1+='</td>';

    } else if (assetType==7) {           // expense
        amess1='<td data-sortUse="7">';
       let aexpense=parseFloat(aValues['expense']);
       let ataxFrac=parseFloat(aValues['taxFreeFrac']);
       let apct=100*ataxFrac;
         let sayAtaxFrac=apct.toFixed(0);

       amess1+='<span style="float:right;margin-right:0.5em">';
       amess1+='<span title="Fraction of yearly expense that offsets other income (as a tax deduction)" class="ctaxFreeFrac">'+apct+'%</span>';

        amess1+='</span>';
        amess1+='</td>';

    }
    return [amess1,other,other2] ;
}


//================
// calculate portfolio value (pre-tax)  -- NOT including Cash.
//
// returns : {'name':,'totals':,'assets':,'dateStamp':,'dateStampSay':};
//
// [0]  totals:  {totAssetSale,totNet, etc...
// [1] assets: [assetName]=  {q   value netValue  ... loanSchedule ...
//
// alist is an array of the assets comprising the portfolio. -- each row  is an object with variables
// Each asset uses a subset of the variables in a row, depending on assetType
//    0 (stock) :   : nShares , basis
//    1 (regular bond) :    nShares
//    2 (tax deferred bond) :nShares
//    3 (property) :   cost (downpayment etc), basis, loanAmount, loanStart,loanTerm,loanRate,loanTaxDeduct,refiCost
//                 if isMod, just    loanOwed and loanPayYearly
//    4 (incomeStream) : cost
//    5 (annuity) : baseValue growth currentValue
//    6  (oneOff)
//    7 (expense)
//
//    let daval0= portfolioCalcValue(alist1['assetList'], adateStamp,pjname,0) ;  // get some totals
//
// adateStamp: datestamp of this calculation (used to determine asset values)
//  pname: name of portfolio
//
// Note: 3 start dates can be uses (that are specific to a single asset added to a single portfolio)
//  Start of an RMD "addition" (tax deferred asset) -- when a RMD distribution starts (specified when tax deferred bond added to portfolio AND a RMD 'add" is specified)
//  Start of a loan -- specified when a property is add to portfolio AND a loan is speciifed)
//  Start of an annuity -- specified when an annuity is added  to a portfolio -- used to specify a "start value" of an annuity, which then grows at fraction of CPI

function portfolioCalcValue(alist,adateStamp,pname,isMod,amess) {
 
 if (arguments.length<5) amess='';

   let vs={};

   let nStock=0,nBond=0,nRegular=0,nTaxDefer=0,nProperty=0,nIncome=0,nLoan=0,nIncomeStream=0,nAsset=0,nAnnuity=0,nOneOff=0,nExpense=0 ;
   let nRentNeg=0,nRentPos=0;

   let totAssetSale=0, totAssetSaleNet=0,totAssetSaleNetAT=0,  totCost=0,  totAcqCost=0,    totPurchaseCost=0,   totCapGains=0,  totBasis=0,
       totLoanPayYear=0,totLoanPayYearAT=0, totLoanOriginal=0,   totLoanOwed=0,
       totYearlyAnnuity=0,totYearlyAnnuityAT=0,
       totYearlyIncome=0, totYearlyIncomeAT=0,
       totYearlyNetRent=0, totYearlyNetRentAT=0,
       totYearlyRevenue=0,  totYearlyRevenueAT=0 ;
       totYearlyRentPos=0,totYearlyRentNeg=0;

   let totRegular=0,totTaxDeferred=0,totStock=0,totProperty=0,totPropertyNet=0,totPropertyNetAT=0,  totCapGainsTaxable=0,totOneOff=0;
   let totPropertySaleCost=0;
   let  totStockAT=0,totRegularAT=0,totTaxDeferredAT=0;
   let totAdditionsYearly=0,totTaxOnLiquidation =0;

   let totOneOffReceipt_pending=0 ;  // 9 march 2024.. not used elsewhere but retain for now

   let totYearlyExpense=0,totYearlyExpenseAT=0;

   let oneOffDateX='foo';

   for (let i1=0;i1<alist.length;i1++) {

     let qAmount=0,value1=0,value1Net=0,value1NetAT=0,
         cost1=0,capGains=0,
         yearlyIncome=0,yearlyNetRent=0,yearlyRevenue=0,yearlyAnnuity=0,yearlyExpense=0,
         abasis=0,aprice=0,tax1=0,acqCost=0,purchaseCost=0,saleCost=0,
         loanPayYearly=0, loanPayYearlyAT=0,loanAmount=0,loanOwed=0,daLoan=false,incomeStart=false,rmdStart=false ,addVal=false,doRMD=false,nowAge=false,
         annuityBase=false,annuityGrowth=false,
         origPrice=false,oneOffDate=false;

     let oneOffReceipt_pending=false ; //  9 march 2024.. not used elsewhere but retain for now

     let goo;
     let aList1=alist[i1];
     let sname=aList1['name'];
     let assetType=aList1['assetType'];

     let dval;
     dval=getAssetValue(adateStamp,sname);
      if (dval===false)   {
           alert('Unable to read assetValues for '+adateStamp+'/'+ sname);
           let whyBadValuea=whyBadValue1a/10 ;
           return false ;
     }


     if (assetType==0) {
          qAmount=parseFloat(aList1['nShares']);
          aprice=dval['price'];

          value1=qAmount*aprice;
          value1Net=value1;

          cost1=value1 ;
          acqCost=0;
          purchaseCost=cost1;
          abasis=parseFloat(aList1['basis']);

          capGains=value1Net-abasis;
          if (Math.abs(capGains)<0.001) capGains=0;   // 25 jan 2024 ... this is dont to account forsmall approximation errors

          tax1= parseFloat(calcAsset_taxAmount(sname,capGains,1));
          tax1=Math.max(tax1,0);

          value1NetAT=value1Net-tax1 ;

          nStock++;
          nAsset++ ;

          totCapGains+=capGains ;

          totCapGainsTaxable+=capGains;            // stocks capital gains fully taxed
          totStock+=value1Net ;
          totStockAT+=value1NetAT ;

     } else if (assetType==1  )  {    // nshares is the $ value and cost
          qAmount=parseFloat(aList1['nShares']);

          value1=qAmount;
          value1Net=value1;
          value1NetAT=value1;
          
          addVal=parseFloat(aList1['addVal']);

          cost1=value1;
          acqCost=0;
          purchaseCost=cost1;

          capGains=0;
          abasis=0;
          aprice=1.0;
          tax1=false ;
          nRegular++ ;
          nBond++;
          nAsset++ ;
          totRegular+=value1Net ;
          totRegularAT+=value1NetAT ;
          totAdditionsYearly+=addVal;

     } else if ( assetType==2)  {    // nshares is the $ expenditure

          qAmount=parseFloat(aList1['nShares']);
          value1=qAmount;
          value1Net=qAmount;

          tax1= parseFloat(calcAsset_taxAmount(sname,value1Net,1)); // payment of deferred tax is on everything
          let ztaxRate= parseFloat(calcAsset_taxRate(sname,1));
          value1NetAT=value1Net-tax1;

          cost1=value1*(1-ztaxRate);    // assume pre-tax income is used to acquire tax deerred bonds, so actual cost is net of reduced income tax
          purchaseCost=cost1;
          acqCost=0;

          capGains=0;

          addVal=parseFloat(aList1['addVal']) ;
          doRMD=parseInt(aList1['doRMD']) ;

           if (doRMD>0) {
              if (!aList1.hasOwnProperty('rmdStart')){
                  let aerr={'errorMessage':'no rmdStart','portfolio':pname,'asset':sname,'date':adateStamp};
                  simInvDsets['qStatusList']['errors'].push('No rmdStart attribute for bond asset '+sname+' in portfolio '+pname+' on '+adateStamp);
                  false ;
              } else {
                 rmdStart=  aList1['rmdStart'] ;
              }
               nowAge=aList1['nowAge']  ;
               let ddays=adateStamp-rmdStart;
               let anage2=nowAge+(ddays/365);

               let afact=growPortfolio_rmdFrac(anage2,doRMD);
               addVal=qAmount*afact;
           }

          abasis=0;
          aprice=1.0;
          nBond++;
          nTaxDefer++;
          nAsset++ ;
          totTaxDeferred+=value1Net ;
          totTaxDeferredAT+=value1NetAT;

          totAdditionsYearly+=addVal;

     } else if (assetType==3 ) {
          qAmount=1;
          value1= dval['price'];      // current value
          if (value1===false)   {         // if a mod ... look it up
             value1=getAssetValue(adateStamp,sname,'price','no price available for this property: '+sname ) ;
         }
          value1Net=value1;          // adjsuted below if loan owed

          aprice=value1;

           saleCost=dval['saleCost'];
           if (!jQuery.isNumeric(saleCost)) saleCost=0;

          value1Net=value1Net-saleCost   ;

          origPrice=aList1['origPrice'];    // price when added to portfolio

          cost1=(aList1.hasOwnProperty('origCost')) ?  aList1['origCost'] :  aList1['cost'] ;
          cost1=parseFloat(cost1);
          acqCost=cost1;
          purchaseCost=0 ;

          let refi1=(aList1.hasOwnProperty('refiCost')) ? aList1['refiCost'] : 0 ;

          abasis=parseFloat(aList1['basis']);

          yearlyNetRent=parseFloat(dval['rent']);  //  should NOT included mortgate (that's done below). NET means net of costs .. NOT after tax!
          taxRent=  calcAsset_taxAmount(sname,yearlyNetRent,0) ;

          if (yearlyNetRent>0) {
              nRentPos++;
              totYearlyRentPos+=yearlyNetRent ;
          } else if (yearlyNetRent<0) {
              nRentNeg++;
              totYearlyRentNeg+=yearlyNetRent;
          }

          yearlyRevenue=yearlyNetRent ;

          let aloan=parseFloat(aList1['loanAmount']);
          if (aloan>0) {
            let istart=aList1['loanStart'];
            nLoan++;
            let aterm=aList1['loanTerm'];
            let arate=parseFloat(aList1['loanRate']);
            let aDeduct=aList1['loanTaxDeduct'];
            let aAmount=aList1['loanAmount'];
            let forceIt=(isMod==0) ? 1 : 0 ;
            let daLoan0=getLoanInfo(pname,istart,sname,aAmount,adateStamp,arate,aterm,aDeduct,forceIt);  // force reation of loan
            loanAmount=aAmount;
            loanOwed=daLoan0['loanOwed'];

            value1Net=value1Net-loanOwed;

            loanPayYearly=daLoan0['yearPay'];
            loanPayYearlyAT=loanPayYearly;
            if (aDeduct==1) {
               let loanPayYearlyTax=calcAsset_taxAmount(sname,loanPayYearly,0) ;
               loanPayYearlyAT =loanPayYearly-loanPayYearlyTax;
            }

            daLoan={'startDate':istart,
                    'amount':aAmount,'term':aterm,'rate':arate,'taxDeduct':aDeduct,'refiCost':refi1,'owed':loanOwed};  // this is all we need

           }            // non 0 loan

           capGains=value1-abasis ;               // do NOT use calcAsset_capGainsAmount-- since calcAsset_taxAmount accounts for taxFreeFrac
           tax1=  calcAsset_taxAmount(sname,capGains,1) ;   // note that saleCost does NOT reduce capital gains
           tax1=Math.max(tax1,0);
           value1NetAT=value1Net-Math.max(tax1,0) ;

           let tfree=doAssetLookup(sname,'taxFreeFrac',1);
           totCapGainsTaxable+= ( (1-tfree)*capGains) ;  // fraction of capGains subject to capital gains tax

           totProperty+=value1 ;
           totPropertyNet+=value1Net ;
           totPropertyNetAT+=value1NetAT ;

           totPropertySaleCost+=saleCost ;

           totCapGains+=capGains ;

           totYearlyNetRent+= yearlyNetRent ;
           totYearlyNetRentAT+=(yearlyNetRent-taxRent) ;

           totYearlyRevenue+=yearlyNetRent;
           totYearlyRevenueAT+=(yearlyNetRent-taxRent) ;

           totLoanPayYear+=loanPayYearly;
           totLoanPayYearAT+=loanPayYearlyAT;
           totLoanOriginal+=parseFloat(loanAmount);
           totLoanOwed+=loanOwed ;

           nProperty++;
           nAsset++ ;

     } else if (assetType==4 ) {

          qAmount=0;
          value1=0;
          value1Net=0;
          value1NetAT=0;
          cost1=(aList1.hasOwnProperty('origCost') && aList1['origCost']!==false ) ?  aList1['origCost'] :  aList1['cost'] ;
          cost1=parseFloat(cost1);
          purchaseCost=0 ;
          acqCost=cost1;

          capGains=0;
          yearlyIncome=dval['income'];
          yearlyRevenue=yearlyIncome ;

          abasis=0;
          aprice=0;
          tax1=false ;
          nIncome++;
          nIncomeStream++ ;

          let taxest=calcAsset_taxAmount(sname,yearlyIncome,0) ;

          totYearlyIncome+=yearlyIncome;            // incoem from incomeStreams AND from annuities
          totYearlyRevenue+=yearlyIncome;            // incoem from incomeStreams AND from annuities
          totYearlyIncomeAT+=(yearlyIncome-taxest);
          totYearlyRevenueAT+=(yearlyIncome-taxest);

     } else if (assetType==5 ) {            // annuities are computed using incomeStart

          qAmount=0;
          value1=0;
          value1Net=0;
          value1NetAT=0;

          cost1=(aList1.hasOwnProperty('origCost') && aList1['origCost']!==false ) ?  aList1['origCost'] :  aList1['cost'] ;
          cost1=parseFloat(cost1);
          purchaseCost=0 ;
          acqCost=cost1;

          capGains=0;

          incomeStart=(aList1.hasOwnProperty('incomeStart')) ? aList1['incomeStart'] : adateStamp;

          let zz1=calcAnnuityValue(sname,incomeStart,adateStamp)   ;  //[baseValue,baseGrowth,calcValue,day1,day2,dointerp,growthRateAgg]

          yearlyAnnuity=zz1[2];
          yearlyRevenue=yearlyAnnuity ;
          annuityBase=zz1[0];
          annuityGrowth=zz1[1];
          abasis=0;
          aprice=0;
          tax1=false ;
          nIncome++;
          nAnnuity++ ;

          let taxest=calcAsset_taxAmount(sname,yearlyAnnuity,0) ;

          totYearlyAnnuity+=yearlyAnnuity;            // incoem from incomeStreams AND from annuities
          totYearlyRevenue+=yearlyAnnuity;            // incoem from incomeStreams AND from annuities

          totYearlyAnnuityAT+=(yearlyAnnuity-taxest);
          totYearlyRevenueAT+=(yearlyAnnuity-taxest);

     } else if (assetType==6 ) {    // one off
           qAmount=0;
          value1=0;
          value1Net=0;
          value1NetAT=0;
          cost1=0;
          purchaseCost=0 ;
          capGains=0;
          abasis=0;
          aprice=0;
          oneOffReceipt_pending=dval['receipt'];  // 9 march 2024.. not used elsewhere but retain for now
          oneOffDate=(aList1.hasOwnProperty('oneOffDate')) ? aList1['oneOffDate'] : adateStamp;
          if (oneOffDate==adateStamp)   {                   // oneOff received on this date
             tax1=false ;
             nOneOff++ ;
             let taxest=calcAsset_taxAmount(sname,oneOffReceipt_pending,0) ; 
             totOneOffReceipt_pending+=(oneOffReceipt_pending);   // 9 march 2024.. not used elsewhere but retain for now
          }

     } else if (assetType==7 ) {

          qAmount=0;
          value1=0;
          value1Net=0;
          value1NetAT=0;
          purchaseCost=0 ;
          acqCost=0;

          capGains=0;
          yearlyExpense=dval['expense'];

          abasis=0;
          aprice=0;
          tax1=false ;
          nExpense++;

          let taxest=calcAsset_taxAmount(sname,yearlyExpense,0) ;

          totYearlyExpense+=yearlyExpense;            // incoem from incomeStreams AND from annuities
          totYearlyExpenseAT+=(yearlyExpense-taxest);


     }          //

// totals across all assets

     totAssetSale+=value1;
     totAssetSaleNet+=value1Net;
     totAssetSaleNetAT+=value1NetAT;

     totCost+=cost1;
     totAcqCost+=acqCost;

     totPurchaseCost+=purchaseCost ;
     totBasis+=abasis ;

     if (tax1!==false) totTaxOnLiquidation+=tax1;

     goo={'assetType':assetType,'q':qAmount,
          'value':value1,'valueNet':value1Net,'valueNetAT':value1NetAT,'cost':cost1,'capGains':capGains,
           'yearlyIncome':yearlyIncome,'yearlyAnnuity':yearlyAnnuity,'yearlyNetRent':yearlyNetRent,'yearlyRevenue':yearlyRevenue,
           'yearlyExpense':yearlyExpense,
           'acqCost':acqCost,'purchaseCost':purchaseCost,
           'origPrice':origPrice,'addValYearly':addVal,'addVal':addVal,'doRMD':doRMD,'nowAge':nowAge,'rmdStart':rmdStart,
           'basis':abasis,'price':aprice,'taxOnSale':tax1,'saleCost':saleCost,
           'loanOwed':loanOwed,'loanPayYearly':loanPayYearly,'loanOriginal':loanAmount,'loanSchedule':daLoan,
           'incomeStart':incomeStart,'annuityBase':annuityBase,'annuityGrowth':annuityGrowth,
            'oneOffDate':oneOffDate};

     goo['oneOffReceipt_pending']=oneOffReceipt_pending;  // 9 march 2024.. not used elsewhere but retain for now


     vs[sname]=goo;


   }    // this asset (alist ii) ...   ............


   let totYearlyCashInflow= totYearlyIncome+totYearlyAnnuity+totYearlyRentPos ;
   let totYearlyCashOutflow = totLoanPayYear +totYearlyExpense+Math.abs(totYearlyRentNeg)   ;
   let totYearlyCashFlow=totYearlyCashInflow-totYearlyCashOutflow  ;

// these are "estimated" -- in particular, totAssetSaleNetAT after tax sum over individual assets (but does NOT carefully account for negative capital gains)
   let tots={'totAssetSale':totAssetSale,'totAssetSaleNet':totAssetSaleNet,'totAssetSaleNetAT':totAssetSaleNetAT,
             'totStock':totStock,'totStockAT':totStockAT,
             'totRegular':totRegular,'totRegularAT':totRegularAT,
             'totTaxDeferred':totTaxDeferred,'totTaxDeferredAT':totTaxDeferredAT,
             'totProperty':totProperty,'totPropertyNet':totPropertyNet,'totPropertyNetAT':totPropertyNetAT,
             'totPropertySaleCost':totPropertySaleCost,
             'totCost':totCost,'totAcqCost':totAcqCost,'totPurchaseCost':totPurchaseCost,
             'totCapGains':totCapGains,'totCapGainsTaxable':totCapGainsTaxable,
             'totTaxOnLiquidation':totTaxOnLiquidation,
             'totLoanPayYear':totLoanPayYear,'totLoanPayYearAT':totLoanPayYearAT,
             'totLoanOriginal':totLoanOriginal,
             'totLoanOwed':totLoanOwed,
             'totBasis':totBasis,
             'totYearlyNetRent':totYearlyNetRent,'totYearlyNetRentAT':totYearlyNetRentAT,
             'totYearlyIncome':totYearlyIncome, 'totYearlyIncomeAT':totYearlyIncomeAT,
             'totYearlyAnnuity':totYearlyAnnuity, 'totYearlyAnnuityAT':totYearlyAnnuityAT,
             'totYearlyRevenue':totYearlyRevenue,'totYearlyRevenueAT':totYearlyRevenueAT,
             'totAdditionsYearly':totAdditionsYearly,
             'totYearlyExpense':totYearlyExpense,'totYearlyExpenseAT':totYearlyExpenseAT,
             'totYearlyRentPos':totYearlyRentPos,'totYearlyRentNeg':totYearlyRentNeg,
             'totYearlyCashInflow':totYearlyCashInflow,'totYearlyCashOutflow':totYearlyCashOutflow,'totYearlyCashFlow':totYearlyCashFlow,
             'nAsset':nAsset,'nStock':nStock,'nBond':nBond,'nRegular':nRegular,'nExpense':nExpense,
             'nTaxDefer':nTaxDefer,'nProperty':nProperty,'nIncome':nIncome,'nLoan':nLoan,
             'nIncomeStream':nIncomeStream,'nAnnuity':nAnnuity,'nOneOff':nOneOff,
             'nRentPos':nRentPos,'nRentNeg':nRentNeg,

             };

//  if (pname=='silly') showDebug(tots,'togs on '+adateStamp,1);

    tots['totOneOffReceipt_pending']= totOneOffReceipt_pending ;  // 9 march 2024.. not used elsewhere but retain for now

   let oof=setEntryDate(adateStamp);

   return {'name':pname,'totals':tots,'assets':vs,'dateStamp':adateStamp,'dateStampSay':oof['sayDate']};

}   //      addVal

//==================
// front end to  portfolioCalcValueMenu_init2 -- creating an initialization entry by reading stuff from input fields

function portfolioCalcValueMenu_init(athis,pname,iwhere) {

   if (arguments.length<2) {
     let ethis=wsurvey.argJquery(athis);
     pname=ethis.attr('data-name');
   }
   if (arguments.length<2) iwhere=0;

   let daval=portfolioCalcValueMenu_init2(pname,iwhere) ;        // THIS DOES THE WORK !!!
   if (daval['errors'].length>0)  {      //errors
     let amess='<b>There are errors</b> in your initialization entry for <tt>'+pname+'</tt>';
     amess+='<ul>';
     amess+='<li>'+daval['errors'].join('<li>')+'</ul>';
     displayStatusMessage(amess);
     return daval;
   }

   let summA= daval['summary'];                             // display the overall summary
    $('#assetHistory_currentSummary').html(summA).show();


// alert notes -- not errors, but might be unintentional
  let alertMess=portfolioCalcValueMenu_alerts(daval,0,0)  ;
   if (alertMess!='') {
       let bmess='<div class="alertsNotes">  </div>';
       bmess+=alertMess;
       $('#assetHistory_alerts').html(bmess);
       $('#assetHistory_alerts').show();
   } else {
       $('#assetHistory_alerts').hide();
   }

// show warning
    let tcost=daval['totals']['totCost'];
    let cdiff=daval['cashAsset'] ;
    let abudget=daval['origBudget']
    portfolioCalcValueBudgetWarn(cdiff,0,abudget,tcost,pname) ;  // portfolioCalcValueMenu_init write warning messages?

// enabel comment input field (optional)
   let ebox=$('#portfolioSummary');
   let ecomment=ebox.find('[name="portfolioHistory_comment"]');
   ecomment.show();

   return daval ;
}


//================
// calcuate the value (in $) of a portfolio (mix of assets)  -- initialiation
//   -- read data from an onscreen asset mix  menu (init or modify modes)   -- using portfolioCalcValueMenu
//   -- call portfolioCalcValue to convert this data into an 'entry' object

function portfolioCalcValueMenu_init2(pname,iwhere) {
   if (arguments.length<2) iwhere=0;

   let comments={} ;
   let errors=[];
   let quiet=0;

   d1=getCreationDate('#portfolioMenu_initDateBlock');     // gets the user entered date
   if (d1===false) {
          errors.push('Please enter a proper creation date');
          return {'errors':errors};       // immediately fatal
   }

   let  pDateCount=d1['dayCount'];

   let etable=$('#portfolioHistory1');

   let ebaseIth=etable.find('[name="baseEntry_ith"]');
   let base_ith=ebaseIth.val();
   let ebaseDate=etable.find('[name="baseEntry_closestDate"]');
   let base_date=ebaseDate.val();

   let abudget,origBudget ;

  let ebudget=etable.find('[name="portfolioBudget"]');
     let abudget0=jQuery.trim(ebudget.val());
     abudget=fixNumberValue(abudget0) ;
     if (abudget===false) {
          errors.push('Please enter a budget (a number> 0) : '+abudget0);
          return {'errors':errors};       // immediately fatal
     }        // error
   ebudget.attr('data-budget',abudget);
   origBudget=false;

   alist=portfolioCalcValueMenu_read(0,1,pname,abudget,pDateCount)    ;         // read assets from menu (init, no immediate error reporting)

   if (alist.hasOwnProperty('errors')) {                        // errors?
       let errors=alist['errors'];
       if (errors.length>0) return {'errors':errors};       //   fatal   errrors
   }

   for (let ic=0;ic<alist.length;ic++) {       // list of comments (for each asset)
       let aname=alist[ic]['name'];
       let acomment=jQuery.trim(alist[ic]['comment']);
       comments[aname]=acomment;
   }
// ---- calculate porfololio value using asset read above (pulled from menu!)

   let daval=portfolioCalcValue(alist,pDateCount,pname,0);   // in portfolioCalcValueMenu_init2: calcluate $values, etc of the user inputs (using inputs saved in alist)
   daval['baseEntry']={'ith':0,'dateStamp':pDateCount};

// put comments in to daval['assets'][assetName]
   for (let zname in daval['assets']) {
        let acomment= (comments.hasOwnProperty(zname)) ? comments[zname] : ' ' ;
        daval['assets'][zname]['comment']=acomment ;
   }

// fill in asset summary info cells ( price,etc info)

  let eins=etable.find('[name="portfolioAsset"]');
  for (let ii=0;ii<eins.length;ii++) {
     let ein=$(eins[ii]);
     let etr1=ein.closest('.portfolioHistoryRow');
     if (etr1.attr('data-remove')==1) continue ;

     let aname=ein.attr('data-orig');
     let etr=ein.closest('.portfolioHistoryRow');
     let esummary=etr.find('.cportfolioTable1_summaryCell');      // an asset-row-specific cell
     let  tbdSay=addARowPortfolioAssetMix_assetSummary(aname,daval);

     esummary.html(tbdSay);
  }

  daval['cashAsset']='';

  let tcost=daval['totals']['totCost'];
  let cdiff=abudget-tcost ;         // abudget is either the original budget (specified at creation), or the current netValue (on modification dat)
  let cdiffSay=wsurvey.addComma(parseInt(cdiff));
  let ercash=etable.find('[name="portfolioCashRemain"]');
  ercash.val(cdiffSay);
  ercash.attr('data-value',cdiff);                  // these might be overwritten (by portfolioCalcValueMenu_modify

   portfolioCalcValueBudgetWarn(cdiff,0,abudget,tcost,pname) ;  //  portfolioCalcValueMenu_init2 write warning messages?
   daval['cashAsset']=cdiff;

   daval['errors']=errors ;           // always [] (otherwise returned above)
   daval['assetList']=alist ;
   daval['comment']='creation entry' ;
   daval['origBudget']= abudget ;

   daval['totals']['totNetAllEst']=daval['totals']['totAssetSaleNetAT']+daval['cashAsset'];
   daval['totNetAllEst']= daval['totals']['totNetAllEst'] ;


// show the appropriate  col 4 header
  let daheaders=etable.find('.cAllocationHeader');
  daheaders.hide();
  let da1=etable.find('[name="allocationHeader_allocation"]');
  da1.show();

// if here, create some accurate totals, and summary info

   daval['totalsAfterGrowth']=calc_netValues(daval);  // in portfolioCalcValueMenu ... portfolio_totalSummary uses totalsAfterGrowth
   daval['madeBy']='portfolioCalcValueMenu_init2';
   
    let  summA=portfolio_initTotalSummary(daval,'<em>to be created</em>',0);
   daval['summary']=summA ;

    $('#assetHistory_currentSummary').html(summA).show();

   return daval ;

}

//=============
// find oddities in current asset mix (i.e.; revenue < loan payments -- INITIALIZATION VERSION
function portfolioCalcValueMenu_alerts(daval,shorter,totalsOnly) {

  let alerts=[] ;
  if (totalsOnly==0) {
   for (let zasset in daval['assets']) {
      let asset1=daval['assets'][zasset];
      if (asset1['assetType']==3) {
         let v1a=asset1['acqCost'],v1b=asset1['loanOriginal'];
         let v1=v1a+v1b;              //will be same as loanAmount (at initialization)
         dv1=v1-asset1['price'] ;
         let amess;
         if (dv1<-10)  {          // ignore small differences
              let dv1Say=wsurvey.addComma(parseInt(Math.abs(dv1)));
              if (shorter==0) {
                amess='Property <tt>'+zasset+'</tt>: acquisition cost ('+wsurvey.addComma(parseInt(v1a))+') ';
                amess+= ' + loanAmount ('+wsurvey.addComma(parseInt(v1b))+') is '+dv1Say+' less than price  ';
                amess+= '('+wsurvey.addComma(parseInt(asset1['price']))+'). ';
                amess+='Is the difference part of your endowment?';
              } else {
                amess=zasset+'</tt>: costs &lt; price';
             }   // shoter
             alerts.push('<div class="alertsNotesWarning">'+amess+'</div>');
          }   // dv1
      }    // type=3
      if (asset1['assetType']==0) {         // stock -- check if basis is odd
         let amess;
         let abasis=asset1['basis'];
         let valuex=asset1['valueNet'];
         if ((valuex*1.1)<abasis) {
                amess='Stock <tt>'+zasset+'</tt>: basis ('+wsurvey.addComma(parseInt(abasis))+') ';
                amess+= ' is greater than its value ('+wsurvey.addComma(parseInt(valuex))+'). ';
                amess+='Did you respecify the #shares, and forget to change the basis?  ';
                alerts.push('<div class="alertsNotesWarning">'+amess+'</div>');
         }
     }             // type=0

   }   // zasset
 }     // totalsonly

   let dExpense=daval['totals']['totYearlyRevenue']-daval['totals']['totLoanPayYear'] ;

   if (dExpense<-10) {
       let amess;
       if (shorter==0)   {
          amess='Total revenue (rents+incomes) is less than  loan payments (<u>Cash</u> will decrease over time) ';
      } else {
          amess='totalRevenue &lt; loanPayments';
       }
       alerts.push('<div class="alertsNotesWarning">'+amess+'</div>');
   }

   if (alerts.length>0) {
       let bmess='';
       bmess+='<ul class="fingerMenu">';
       bmess+='<li>'+alerts.join('<li>')+'</ul>';
       return bmess;
   } else {
      return '';
   }



}

//=============
// find oddities in current asset mix (i.e.; revenue < loan payments -- INITIALIZATION VERSION
function portfolioCalcValueMenu_alerts_Mod(daval) {
  let shorter=0;
  let clist=daval['changed']['portfolioValue']['assets'];
  let retainList=daval['changed']['modifiedEntry']['summary']['retainList'];
  let alerts=[] ;
   for (let zasset in clist) {
      let asset1=clist[zasset];
      let atype=asset1['assetType'];
      if (asset1['assetType']!==3) continue ;
      if (jQuery.inArray(zasset,retainList)<0) {       // a new property
         let v1a=asset1['acqCost'],v1b=asset1['loanOwed'],aprice=asset1['price'];
         let v1=v1a+v1b;              //will be same as loanAmount (at initialization)
         dv1=v1-aprice ;
           if (dv1<-10)  {          // ignore small differences
               let amess;
               if (shorter==0) {
                amess='Property <tt>'+zasset+'</tt>: acquisition cost ('+wsurvey.addComma(parseInt(v1a))+') ';
                amess+= ' + loanAmount ('+wsurvey.addComma(parseInt(v1b))+')  is  '+wsurvey.addComma(Math.abs(parseInt(dv1))) +' less than price ('+wsurvey.addComma(parseInt(aprice))+'). ';
                amess+='Is the difference part of your endowment?';

               } else {
                 amess=zasset+'</tt>: costs &lt; price';
               }   // shoter
               alerts.push(amess);
            }   // dv1

      }   // zasset
   }      // for

   let totLoanPayYearAT=daval['changed']['portfolioValue']['totals']['totLoanPayYearAT']    ;
   let totYearlyRevenueAT=daval['changed']['portfolioValue']['totals']['totYearlyRevenueAT']  ;
   let dExpense=totYearlyRevenueAT-totLoanPayYearAT ;

   if (dExpense<-10) {
       let amess;
       if (shorter==0)   {
          amess='Total yearly revenue (rents+incomes+annities) is less than  loan payments (<u>Cash</u> will decrease over time) ';
      } else {
          amess='totalRevenue &lt; loanPayments';
       }
       alerts.push(amess);
   }

   if (alerts.length>0) {
      let bmess='';
       bmess+='<ul class="fingerMenu">';
       bmess+='<li>'+alerts.join('<li>')+'</ul>';
       return bmess;
   } else {
      return '';
   }

    return bmess;


}


//=====================
// show warning (assetHistory_currentSummaryNote) if oddities (such as mortgate + acqCost != price)
// used by init (assetHistory_currentSummaryNote container in  portfolioSummary main container )

function portfolioCalcValueBudgetWarn(cdiff,isMod,abudget,cost,pname) {

  let dmess;
  let cdiffCheck= (Math.abs(cdiff)<simInvGlobals['budgetAllocationTest']) ? 0  : cdiff;  // don't worry if less than $budgetAllocationTest off
  if (cdiffCheck<0) {      // note use of attributes to contain current values (rather than recalling portfolioCalcValue
        if (isMod!=1)  {
          dmess='<div style="padding:5px;background-color:yellow;color:black">';
          dmess+='<b>Warning:</b> you have allocated <b>'+wsurvey.makeNumberK(-cdiff,9999)+'</b>  more than your budget!</div>';
          dmess+=' You can: have a negative amount in <u>Cash</u>; change the #shares of one or more assets; ';
          dmess+='   ... or...   ';
          dmess+='<input type="button" value="adjust your budget"   onClick="portfolioInitBudgetAdjust(this)" ';
          dmess+='  data-budget="'+abudget+'"  data-val="'+cdiff+'" data-cost="'+cost+'"  data-name="'+pname+'" > ';
        } else {        // mod: warrning only (budget reset not allowed)
           dmess='<div style="padding:5px;background-color:yellow;color:black"><b>Warning:</b> you have allocated '+wsurvey.makeNumberK(-cdiff,9999)+'  more than your current netValue!</div>';
          dmess+=' You can: retain the difference to <u>Cash</u>, or change the #shares of one or more assets. ';
        }
        dmess+='</div>'
        $('#assetHistory_currentSummaryNote').html(dmess).show();
   }
   if (cdiffCheck>0) {
        if (isMod!=1)  {
           dmess='<div style="padding:5px;background-color:#def8d3;color:black"><em>Note</em>:';
           dmess+=' you have <u>not</u> allocated your entire budget to the assets ('+wsurvey.makeNumberK(cdiff,9999)+' remaining)!</div> ';
           dmess+=' You can: retain the difference in <u>Cash</u>; change the #shares of one or more assets; remove an asset ; ';
           dmess+='   ... or...   ';
           dmess+='<input type="button" value="adjust your budget"   onClick="portfolioInitBudgetAdjust(this)" ';
           dmess+='  data-budget="'+abudget+'"  data-val="'+cdiff+'" data-cost="'+cost+'" data-name="'+pname+'"   > ';

         } else {        // mod: warrning only (budget reset not allowed)
           dmess='<div style="padding:5px;background-color:#def8d3;color:black"><em>Note</em>: you have <u>not</u> allocated your entire budget to match your current netValue ('+wsurvey.makeNumberK(cdiff,9999)+' remaining)!</div> ';
           dmess+=' You can: retain the difference to <u>Cash</u>,  change the #shares of one or more assets, or add an asset';
         }
        dmess+='</div>'
        $('#assetHistory_currentSummaryNote').html(dmess).show();
   }
   if (cdiffCheck==0) {
          dmess='Your budget is fully allocated';
          if (isMod!=1) {
                dmess+='<br>If you have extra <u>Cash</u>, you can ... ';
                dmess+='<input type="button" value="adjust your budget"   onClick="portfolioInitBudgetAdjust(this)" ';
                dmess+='  data-budget="'+abudget+'"  data-val="'+cdiff+'" data-cost="'+cost+'"  data-name="'+pname+'"  > ';
          }
   }
   $('#assetHistory_currentSummaryNote').html(dmess).show();

   return 1;

}

//==================
// Reads input values from a "modify" page.
// The modify page starts with the "grown" values (of a "nearest to chosen date" asset-mix"
// portfolioCalcValueMenu_modify then uses these input values, and the pre-modified   values (the "grown" values)
// These are combined  by portfolioCalcValueMenu_difference to create a new entry
//
// Called by 'calculate modified value' button --  on the menu showing the "grown" values
//   and from reviewPortfolioMod and saveModifiedPortfolio
//
// Note that some values are NOT changable (such as loan parameters, and income acquisition costs) -- since they are set when the asset is first added
// and do not change over time.
//
// This uses entryWorking global, that is saved by showModifyPortfolio_step2
//

function portfolioCalcValueMenu_modify(athis,pname) {
  let etable=$('#portfolioHistory1');

  let statusMessages=[],statusSummary='';

  if (arguments.length<2) {
    let ethis=wsurvey.argJquery(athis);
    pname=ethis.attr('data-name');
  }

// check for duplicate asset entries
   if (simInvParams['sameAssetFamilyOk']==0)  {    //   check for more than one members of a family
     let haveList=portfolioMenu_assetFamily(2);
     let gots={},errs=[];
     for (let a1 in haveList) {
        let afam=haveList[a1];
        if (gots.hasOwnProperty(afam)) {
            errs.push('More than one asset in family: '+afam);
        } else {
           gots[afam]=1;
        }
     }
     if (errs.length>0) {
        let errMess='Problems: <ul><li>'+errs.join('<li>')+'</ul>';
        displayStatusMessage(errMess);
        return false;
     }
  }    // sameAssetFamilyOk


  let mdate=simInvDsets['entryWorking']['endDate'];
  let abudget=parseFloat(simInvDsets['entryWorking']['totalsNet']['totPortfolioValue']);

   currentEntry=portfolioCalcValueMenu_read(1,1,pname,abudget,mdate)    ;         // read assets from menu (init, no immediate error reporting)

   if (currentEntry===false ) {         // this shuld never happen
      alert('There are errors in your input. Please fix and try again.\nClick `Calculate portfolio value` for the details! ');
      return false ;
   }

  if (currentEntry.hasOwnProperty('errors')) {         // this can happen!
       if (currentEntry['errors'].length>0) {
         let amess='';
         amess+='There are input errors ... please fix them and try again! ';
         amess+='<ul><li>';
         amess+=currentEntry['errors'].join('<li>');
         amess+='</ul>';
         displayStatusMessage(amess);
         return false
      }
   }


   if (currentEntry.length==0) {       // 3 dec 2023 ... clearing all assets is acceptable ?  might revisit this!--
      statusMessages.push('You did not specify any assets (in your modification of portfolio '+pname+')');
   }


// fill in some values

   for (let ic1=0;ic1<currentEntry.length;ic1++) {
      let cur1=currentEntry[ic1];
      let atype=cur1['assetType'];

      if (atype==2 ) {
         let aname=cur1['name'];
         if (simInvDsets['entryWorking']['grown']['assetDetails'].hasOwnProperty(aname)) {       // existing asset
           if  (simInvDsets['entryWorking']['grown']['assetDetails'][aname]['doRMD']!=0) {
            currentEntry[ic1]['doRMD']=simInvDsets['entryWorking']['grown']['assetDetails'][aname]['doRMD'];
            currentEntry[ic1]['rmdStart']=simInvDsets['entryWorking']['grown']['assetDetails'][aname]['rmdStart'];
            currentEntry[ic1]['nowAge']=simInvDsets['entryWorking']['grown']['assetDetails'][aname]['nowAge'];
           }
       }                           // existing asset with rmd
     }

     if (atype==4 ) {
         let aname=cur1['name'];
         if (simInvDsets['entryWorking']['grown']['assetDetails'].hasOwnProperty(aname)) {       // existing asset
            currentEntry[ic1]['origCost']=simInvDsets['entryWorking']['grown']['assetDetails'][aname]['acqCost'];
         }
     }
     if (atype==5) {
         let aname=cur1['name'];
         if (simInvDsets['entryWorking']['grown']['assetDetails'].hasOwnProperty(aname)) {       // existing asset
            currentEntry[ic1]['origCost']=simInvDsets['entryWorking']['grown']['assetDetails'][aname]['acqCost'];
            currentEntry[ic1]['incomeStart']=simInvDsets['entryWorking']['grown']['assetDetails'][aname]['incomeStart'] ;
         }
     }
   }

  delete simInvDsets['entryWorking']['changed'];

   let cashAsset0=simInvDsets['entryWorking']['grown']['cash'];

   let priorEntryGrown=simInvDsets['entryWorking']['grown']['assetList'];

   let modifiedEntry=portfolioCalcValueMenu_difference(pname,mdate,priorEntryGrown,currentEntry);

  simInvDsets['entryWorking']['changed']={};
   let cashChange=modifiedEntry['summary']['totCashChange'];
   let cashAfterMod=cashAsset0+cashChange;

  simInvDsets['entryWorking']['changed']['cashChange']=cashChange ;
  simInvDsets['entryWorking']['changed']['cashAsset']=cashAfterMod ;
  simInvDsets['entryWorking']['changed']['modifiedEntry']=modifiedEntry ;

   let modPortfolioValue= portfolioCalcValue(modifiedEntry['assetList'],mdate,pname) ;

  simInvDsets['entryWorking']['changed']['portfolioValue']=modPortfolioValue ;

  modPortfolioValue['cashAsset']= cashAfterMod ;

  let afterModSummary= calc_netValues(modPortfolioValue ,'Summary after asset modifications')  ; // fix netValues ,etc. Note that portfolioCalcValueMenu was  told NOT to do this!

  simInvDsets['entryWorking']['changed']['summary']=afterModSummary ;

// change display: budget
  let eccash=etable.find('[name="portfolioCashRemain"]');   // 22  june ... for info purposes (data saved in modifiedEntry)
  eccash.attr('data-value',cashAfterMod);
  let oof=wsurvey.addComma(parseInt(cashAfterMod));
  eccash.val(oof);
  atitle='Remaining cash AFTER modifications. If negative, additional cash required to obtain asset mix (this is automatically calculated)';
  eccash.attr('title',atitle)


  let summC=portfolio_totalSummary(simInvDsets['entryWorking'],'<span title="Modified portfolio (after growth, and changes in asset mix)"><em>Modified </em></span>',1);
  statusSummary=summC[1];

   let alertMess=portfolioCalcValueMenu_alerts_Mod(simInvDsets['entryWorking']) ;
   if (alertMess!='') statusMessages.push(alertMess);

   let tnet=simInvDsets['entryWorking']['changed']['summary']['totAssetSaleNetAT'];

   modPortfolioValue['statusSummary']=statusSummary ;
   modPortfolioValue['statusMessage']=statusMessages ;

   return  modPortfolioValue  ;


}



//=======================
// convert string input into a number
// Handles special cases: xx% becomes percent of abase, $xx becomes # shares at a aprice and a xx expenditure
// aval0  string value read from input field
//  abase: value used to convert xx%
// aprice :value used to conver $xxxx. Can be 1.0, in which case $xxx is same as xxx
// varname: used in error messages
//  minVal : minimum allowed value. If false, no minimum. If a %, always check for 0 to 100


function portfolioCalcValueMenu_readVal(aval0,abase,aprice,varname,minVal,quiet) {

  if (typeof(aval0)=='number') return aval0          ; // seems to be needed when called by portfolioCalcValueMenu_modify
    if (arguments.length< 6) quiet=0;
    if (arguments.length< 5) minVal=false;

    let lastchar=aval0.slice(-1) ;
    let nshares,aval1,aval2;

    if (lastchar=='%') {        // % of base
         if (abase===false) {
            if (quiet!=1) {
               alert(' %input not allowed for '+varname);
               return false;
            }
            return ' %input not allowed for '+varname;
         }

         aval1=aval0.substr(0,aval0.length-1);
         aval2=fixNumberValue(aval1);
         if (aval2===false)  {
            if (quiet!=1) {
               alert('Bad %input ('+aval0+') for '+varname);
               return false;
            }
            return 'Bad %input ('+aval0+') for '+varname;
         }
         if (aval2>100.0 || aval2<0.0) {
            if (quiet!=1) {
              alert('Bad %input -- must be a value between 0 and 100 for '+varname);
              return false;
            }
            return 'Bad %input -- must be a value between 0 and 100 for '+varname;
         }

         nshares=((aval2/100.0)*abase)/aprice ;


         return nshares;
      }  // %

      if (aval0.substr(0,1)=='$'  ) {
         aval1=aval0.substr(1,aval0.length-1);
         aval2=fixNumberValue(aval1) ;
         if (aval2===false)  {
            if (quiet!=1) {
               alert('Bad $input ('+aval0+') for '+varname);
               return false;
            }
            return 'Bad $input ('+aval0+') for '+varname ;
         }
         nshares=aval1/aprice ;
         if (minVal!==false) {
            if (nshares<minVal) {
              if (quiet!=1) {
                 alert('Bad $input: must be greater than '+minVal+' ('+aval0+') for '+varname);
                 return false;
              }
              return  'Bad $input: must be greater than '+minVal+' ('+aval0+') for '+varname;
           }     // nsharse<minval
         }    // minval  ne false
         return nshares;

       }    // $

// not xx% or $xx -- read as is
      nshares=fixNumberValue(aval0);
      if (nshares===false) {
         if (quiet!=1) {
            alert('Bad ('+aval0+') for '+varname );
           return false;
         }
         return 'Bad ('+aval0+') for '+varname ;
      }
      if (minVal!==false) {
          if (nshares<minVal) {
              if (quiet!=1) {
                  alert('Bad  input: must be greater than '+minVal+' ('+aval0+') for '+varname);
                 return false;
              }
              return  'Bad  input: must be greater than '+minVal+' ('+aval0+') for '+varname;
          }      // nshares<minVal
        }

      return nshares ;
}

//==============

// allocate "remaining cash" to an asset
function allocateCashToEmpty(athis ) {
   let ethis=wsurvey.argJquery(athis);

   let pname=ethis.attr('data-name');
   let daVals,atotals  ;
   let statusMessages=[];
   let ismod=ethis.attr('data-ismod');
   if (ismod==0) {
     daVals=portfolioCalcValueMenu_init(0,pname);  //  allocateCashToEmpty  ..  read user mods,  ... note summary and totalsAfterGrowth are NOT refreshed
     if (daVals===false) return 1;
   } else {
     daVals=portfolioCalcValueMenu_modify(athis,pname);   // allocateCashToEmpty  ...read user modification... but if direct call to portfolioCalcValueMenu  other stuff gets messed up
     if (daVals===false) return 1;
     statusMessages=daVals['statusMessages'];       // not used here
   }
   let cdiff=daVals['cashAsset'];

   if (daVals.hasOwnProperty('errors') && daVals['errors'].length>0) {
           alert('There are errors in your input. Please use `calculate portfolio values` to view them');
           return 1;
   }

   if (cdiff<0) {
      if (ismod==0) {
         let summA=daVals['summary'];
         $('#assetHistory_currentSummary').html(summA).show();
      } else {
         $('#assetHistory_currentSummaryNote').html('Your budget is over allocated (by '+Math.abs(parseInt(cdiff))+')').show();
      }
       return ;        // can't auto fill if budget already exceeded

   }

   let dalist=daVals['assets'];
   for (let zasset in dalist) {
       let aType=getAssetType(zasset);
       if (aType!==0 &&  aType!==1 ) continue ;  // only autofill regular bonds and stocks
       if (dalist[zasset]['q']>0) continue ;              // not empty
 
// got a blank row! use it
       let etable=$('#portfolioHistory1AssetRows');
       let echeck=etable.find('[name="portfolioAsset"]');
       let euse=echeck.filter('[data-orig="'+zasset+'"]');
       let etr=euse.closest('.portfolioHistoryRow');
       let efill=etr.find('[name="portfolioShares"]');
       efill.val('$'+cdiff.toFixed(2))        ;      // note use of $ prefix (to force conversion of $stock to #shares)

       if (ismod==0) {                //   read again, and update given tweaks done above
         daVals=portfolioCalcValueMenu_init(0,pname);
       } else {
          daVals=portfolioCalcValueMenu_modify(athis,pname)  ; // allocateCashToEmpty (retest)
       }

       if (daVals===false ) return 1;  // if false, alerts will have been displayed
       if (daVals.hasOwnProperty('errors') && daVals['errors'].length >0) {    // this should not happen....
           alert('There are errors in your input. ');
           return 1;
       }

       return 1;
   }
  let summA=daVals['summary'];
   $('#assetHistory_currentSummary').html(summA).show();

   if (ismod==1) {
         $('#assetHistory_currentSummaryNote').html('Please add another regular bond or stock asset. Or clear the #shares on a regular Bond, or a stock .. it will be assigned its current value + $'+wsurvey.addComma(parseInt(cdiff)));
   } else {
      alert('Please add another regular bond or stock asset. Or clear the #shares on a regular Bond, or a stock .. it will be assigned $'+wsurvey.addComma(parseInt(cdiff))+' ');
   }
   return 0;

}

//==============================
// preview a portfolio, and then display save button
function  savePortfolioPreview(athis,pname) {
  if (arguments.length<2) {
    let ethis=wsurvey.argJquery(athis);
     pname=ethis.attr('data-name');
  }
  let davals=portfolioCalcValueMenu_init2(pname) ;

// if errors.... try again

  if (davals===false  ) {
     alert('An error. Please fix and try again!\nClick `Calculate portfolio value` for the details!  ');  // this should can happen if loan terms are not specified
     return 0;
  }

  if (davals['errors'].length>0)  {         // errors encountred
    let amess='';
    amess+='There are input errors: please fix them and try again! ';
    amess+='<ul><li>';
    amess+=davals['errors'].join('<li>');
    amess+='</ul>';
    displayStatusMessage(amess);
    return false
  }

   if (davals['assetList'].length==0) {
       alert('You did not specify any assets (for portfolio '+pname+')');
       return false;
   }

   let abudget=davals['origBudget'];
   if (abudget===false) {   // should never be false. If it is, don't bother with confirm
      alert('A budget was not specified (must be a number >0)');
      return false;
   }

// no fatal erros .. some warnings?
  let drem=davals['cashAsset'];
 $('#icalcPortfolioValue_budgetWarn').hide();
  if (drem!=0 && simInvParams[' warningLevel']==0) {                     // a final reminder (suppress if warningLevel>0)
       let alimit=abudget*simInvParams['budgetRemainPct'] ;
       if (Math.abs(drem)>alimit ) {  // big enought oworry about (> 0.5% of budget?)
         let wmess;
         if (drem<0) {
            wmess='Your budget is  '+wsurvey.addComma(parseInt(drem))+' less than the cost of your asset-mix. Are you sure you want to save this portfolio?';
         } else {
            wmess='You have  '+wsurvey.addComma(parseInt(drem))+' remaining in your budget. Are you sure you want to save this portfolio?';
         }
         $('#icalcPortfolioValue_budgetWarn').html(wmess);
         $('#icalcPortfolioValue_budgetWarn').fadeIn(500);
       }
  }

// show it!
   portfolioCalcValueMenu_init(0,pname,1);
    wsurvey.wsShow.show('#portfolioSummary','show');       // show the summary container

//   $('#portfolioSummary').show();     // show the summary container

  $('#icalcPortfolioValue_init').show();     // show the appropriate help button
  $('#icalcPortfolioValue_mod').hide();
  $('#portfolioSummary_pname').val(pname);   // used when saving portfolio 
  let asay='   initialization entry for portfolio  <b>'+pname+'</b> ';
  $('#portfolioSummary_header_name').html(asay);  // header line
  let asay2='Save initialization entry for <b>'+pname+'</b> ';
  $('#portfolioSummary_header_saveButton').html(asay2);

  return 1;
}

//==============================
// save a portfolio assetmix    -- initialization version
function savePortfolioInit(athis) {

  let ee1=$('#portfolioSummary_pname');  // a hack -- use "hidden" element
  let pname=ee1.val();

// always do this (even if user just called it)

   let davals=portfolioCalcValueMenu_init2(pname) ;

// these should not be necessary (given call to preview), but wth
  if (davals===false  ) {
     alert('An error. Please fix and try again!\nClick `Calculate portfolio value` for the details!  ');  // this should can happen if loan terms are not specified
     return 0;
  }

  if (davals['errors'].length>0)  {         // errors encountred
    let amess='';
    amess+='There are input errors. Please fix them and try again! ';
    amess+='<ul><li>';
    amess+=davals['errors'].join('<li>');
     amess+='</ul>';
    displayStatusMessage(amess);
    return false
  }

   if (davals['assetList'].length==0) {
       alert('You did not specify any assets (for portfolio '+pname+')');
       return false;
   }

  let abudget=davals['origBudget'];
  if (abudget===false) {   // should never be false. If it is, don't bother with confirm
    alert('A budget was not specified (must be a number >0)');
    return false;
}

// --- end of probably not necessary checks

 let ecc=$('#portfolioSummary');
 let ecc2=ecc.find('[name="portfolioHistory_commentInput"]');
 let pcomment=jQuery.trim(ecc2.val());
   pcomment=wsurvey.removeAllTags(pcomment);
 if (pcomment=='') pcomment='Initialization entry for portfolio '+pname ;

 for (let ij=0;ij<davals['assetList'].length;ij++) {
       a0=davals['assetList'][ij];
       let aname=a0['name'];
       let acomment=davals['assets'][aname]['comment'];
       davals['assetList'][ij]['comment']=acomment;
  }

  let totalsAfterGrowth=calc_netValues(davals);  // 'correct' totals

   davals['isCreation']=1 ;  // somewhat unnecesesary

  let origs={};
  origs['budget']=abudget;
   origs['date']=davals['dateStamp'];
   origs['dateSay']=davals['dateStampSay'];

  origs['totNetValue']=totalsAfterGrowth['totAssetSaleNetAT']+totalsAfterGrowth['cashAsset'];
  origs['totAssetSale']=totalsAfterGrowth['totAssetSale'];
  origs['totNetAsset']=totalsAfterGrowth['totAssetSaleNetAT'];
  origs['totTaxSellAll']=totalsAfterGrowth['totTaxPaid'];
  origs['totCapGainTaxSellAll']=totalsAfterGrowth['totCapGainTax'];
  origs['totTaxDeferredSellAll']=totalsAfterGrowth['totDeferredTax'];
  origs['cashAsset']=totalsAfterGrowth['cashAsset'];
  origs['totPropertySale']=totalsAfterGrowth['totPropertySale'];

   origs['totBasis']=davals['totals']['totBasis'];
   origs['totCost']=davals['totals']['totCost'];
   origs['totRevenue']=davals['totals']['totYearlyRevenue'];
   origs['totLoanOriginal']=davals['totals']['totLoanOriginal'];
   origs['totLoanPayYear']=davals['totals']['totLoanPayYear'];
   origs['totLoanPayYearAT']=davals['totals']['totLoanPayYearAT'];


//  save  info used to regenerate detailed dataon retrieval from server
  let davals0={};
  davals0['name']=pname;
  davals0['specifiedDate']=wsurvey.get_currentTime(31,1);
  davals0['userName']=davals['userName'];
  davals0['dateStamp']=davals['dateStamp'];
  davals0['dateStampSay']=davals['dateStampSay'];
  davals0['userName']=userName;

  davals0['cashAsset']=davals['cashAsset'];
  davals0['assetList']=  davals['assetList'];

  davals0['original']=origs;
  davals0['comment']=pcomment ;
  davals0['baseEntry']=0;            // 0 signals "initial entry"

  let ddata={};
  ddata['todo']='savePortfolioInit';
  ddata['portfolio']=pname;
  ddata['origBudget']=abudget;
  ddata['username']=userName;
  ddata['encMd5']=simInvGlobals['encryptionKey_md5'];

  ddata['list']=davals0 ;   // creteats ['data':encryptedAlls,'encrypt':'' or encryptionKeyMd5

  if (simInvDsets['allCurrentData']['portfolioInit']['data'].hasOwnProperty(pname)) {   // should never happen
       alert('The '+pname+' portfolio has already been initialized. You can delete it and recreate it, but you can not modify it');
       return 0;
   }

  let newList=JSON.parse(JSON.stringify(simInvDsets['allCurrentData']['portfolioInit']['data']));
  newList[pname]=davals0 ;
  let nowTime=wsurvey.get_currentTime(0);
  let newPortfolios={'time':nowTime,'data':newList};

  let nassets=newPortfolios['data'][pname]['assetList'].length;
  let abudgetSay=wsurvey.addComma(parseInt(newPortfolios['data'][pname]['original']['budget']));
  let dateStampSay=newPortfolios['data'][pname]['dateStampSay'];
  let amess='portfolio '+pname+' initialized  on '+dateStampSay+' with '+nassets+' assets; using a budget= $'+abudgetSay;

   simInvGlobals['temp']['autoLogonDetails']={'action':'portfolioInit','portfolio':pname} ;
   saveSimInvData_portfolioInit(userName,newPortfolios,amess)  ;
    simInv_cacheResults_removeAll(1) ;  // modification to portfolios -- cache no longer valie

}


//================   buyShare portfolioCalcValueMenu
// adjust  the budget  -- to cover specified asset mix, or whatever  -- only avaiable for portfolio initialization

function portfolioInitBudgetAdjust(athis) {
  let ethis=wsurvey.argJquery(athis);

  let abudget=ethis.attr('data-budget');
  let abudgetSay=wsurvey.addComma(parseInt(abudget));

  let cdiff=ethis.attr('data-val');
  let cdiffSay=wsurvey.addComma(parseInt(cdiff));
  let cost=ethis.attr('data-cost');
  let costSay=wsurvey.addComma(parseInt(cost));
  
  let pname=ethis.attr('data-name');


  let amess='';
   amess+='<ul name="nAdjustBudget">';
  amess+='<li>Proposed budget: <tt>'+abudgetSay+'</tt>';
  amess+='<li>Cost of asset-mix: <tt>'+costSay+'</tt>';
  amess+='<li>Difference: <tt>'+cdiffSay+'</tt>';
  amess+='<li>You can set a <u>Cash</u> value: <input type="text" name="cashDesired" value="'+cdiffSay+'" size="6">';
  amess+='<tt>...<em>set to <tt>0</tt> (or empty) to adjust the budget to match your costs</tt></em>';
  amess+='<li><input type="button" onClick="portfolioInitBudgetAdjust2(this)" data-name="'+pname+'" data-budget="'+abudget+'"  data-cost="'+cost+'" value="Adjust the proposed budget"> (using this <u>Cash</u> value)';
  amess=='</ul>';
  displayStatusMessage(amess);
  toggleStatusMessage(0,0);
}

// =============
// adjust the buget!
function portfolioInitBudgetAdjust2(athis) {
    let ethis=wsurvey.argJquery(athis);
    let abudget=parseFloat(ethis.attr('data-budget'));
    let cost=parseFloat(ethis.attr('data-cost'));
    let pname=ethis.attr('data-name')  ;

    let e1=ethis.closest('[name="nAdjustBudget"]');
    let eval=e1.find('[name="cashDesired"]');
    let aval0=eval.val();
    if (jQuery.trim(aval0)=='') aval0=0;
    let useval=portfolioCalcValueMenu_readVal(aval0,false,1,'CashAvailable',false);
    let  useBudget=parseInt(cost+useval);

    let  etable=$('#portfolioHistory1');
    let eb1=etable.find('[name="portfolioBudget"]');
    eb1.val(useBudget);
    eb1.attr('data-budget',useBudget);
    displayStatusMessage(false);

    savePortfolioPreview(0,pname);

//    let ebutton=$('#calcPValueButton');
//    ebutton.trigger('click');
    return 1;
}
