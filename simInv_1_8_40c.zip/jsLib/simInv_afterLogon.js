// simInv afterLogon functions

//==============
// return from  retrieval of data == from server or local storage
// calledly by checkUserExistsOnline2() : if onLine mode and server storage assigned, or onLineStorage chosen
// called by doLogon2_local if local storage (standAlone, onLine mode local storage assigned, or onLineMode local storage chosen)
// responseFromServer may be encrypted
// qReload=ture, and doAutoARchive, appears if this is a reload
//
// do a bunch of processing, and then show the basic menus  -- or if a reload, show a specific menu

// catch syntax errors, etc.  These errors will be stored so that monitorStartup can deal with them
function afterLogon(responseFromServerA,qisReload,doAutoArchive) {

     if (arguments.length<2) qisReload=false   ; // only used if
     if (arguments.length<3) doAutoArchive=false   ; // only used if  qReload=true
//   responseFromServerA has had json.parse operations, and decryption, done on it

// show a please wait message  -- it is removed when the processing of server data is done.

   displayStatusMessage('Hello <tt>'+userName+'</tt>. Please wait while simInv initializes  .... <div id="waitForLogon"></div> ');

   window.setTimeout(function() {  // and recall this... to process the response
       try {

          let rr=afterLogon_build(responseFromServerA,qisReload)   ;    // ******** THIS DOES THE WORK ***********

          if (rr==1) {    //
             if (qisReload) {

                if (simInvDsets['qStatusList']['errors'].length>0) {
                  let foo='<ul>'+simInvDsets['qStatusList']['errors'].join('<li>')+'</ul>';
                  displayStatusMessage(foo);
                  toggleStatusMessage(0,5);
                  let gotError=afterLogon_err/3;   // force failur
                  return 0;
                }
                 if (simInvDsets['qStatusList']['warnings'].length>0) {
                  let foo='<ul>'+simInvDsets['qStatusList']['warnings'].join('<li>')+'</ul>';
                  displayStatusMessage(foo);
                  toggleStatusMessage(0,3);
                  return 0;
                }

                afterLogon_reload(doAutoArchive) ;  // display stuff (menus, or  choice in a menu) if this is a reload

                if (doAutoArchive) {  // auto archive!
                   autoArchiveMake(1);   //  call to server or local storatge-- callback saves to global vars (so don't wait for return)
                }
             } else {
                clearTimeout(simInvGlobals['monitorStartup_id']);  // immediate
                monitorStartup(0,0) ;   // 0,0 to signal "no error was thrown"
             }
             return rr ;
          }
       } catch(ex) {
           let rrmess='\n ... '+ex.name+': '+ex.message ;
           if (ex.hasOwnProperty('lineNumber')) rrmess+='\n (@lineNumber '+ex.lineNumber+')';
           if (ex.hasOwnProperty('fileName')) rrmess+='\n(in file '+ex.fileName +')';

           simInvDsets['qStatusList']['errors'].push(rrmess);
           simInvDsets['qStatusList']['complete']=false;        // make sure that monitorStartup sees a problem
           if (simInvGlobals['monitorStartup_id']!==false)  {
               clearTimeout(simInvGlobals['monitorStartup_id']);  // immediate
               monitorStartup(0,1) ;   // 0,1 to signal "error was thrown"
           }
          return 0
       }
    },50);

    return 1;

}

//=============================
// open selected menu, if this is a reload

function afterLogon_reload(qAutoArchive) {
  if (simInvGlobals['temp']['autoLogonDetails']===false) return 0;
  $('#statusDivServerResponse').hide();
   hideStatusDiv(0);

  let aaction=simInvGlobals['temp']['autoLogonDetails']['action'];

  if (aaction=='settings') {
     personalSettings(12);
     return 1;
  }

  if (aaction=='scenarioSelect') {
     reviewScenario(1);
     return 1;
  }

   if (aaction=='viewDates') {
     createViewDates(1);
     return 1;
  }

  if (aaction=='cpiuSeries') {
     doSetInflation(1);
     return 1;
  }

  if (aaction=='publicAsset') {
     viewPublicAssets(1);
     return 1;
  }

  if (aaction=='assetsSave') {
     showAssetTable(1);
     let zasset=simInvGlobals['temp']['autoLogonDetails']['asset'] ;
      let etable=$('#assetsTable');
      let etrs=etable.find('.assetRow');
      let et1=etrs.filter('[data-name="'+zasset+'"]');
      if (et1.length==1) {
         let edo=et1.find('.cButtonAssetHistory');      // the init button
         window.setTimeout(function(){edo.trigger('click');},100);
      }
     return 1;

  }

  if (aaction=='assetHistorySave') {
     showAssetTable(1);
     let zasset=simInvGlobals['temp']['autoLogonDetails']['asset'] ;
      let etable=$('#assetsTable');
      let etrs=etable.find('.assetRow');
      let et1=etrs.filter('[data-name="'+zasset+'"]');
      if (et1.length==1) {
         let edo=et1.find('.cButtonAssetHistory');      // the init button
         window.setTimeout(function(){edo.trigger('click');},100);
      }
     return 1;
  }

  if (aaction=='portfolioList') {
     showPortfolioTable(1);

     let aportfolio=simInvGlobals['temp']['autoLogonDetails']['portfolio'] ;
      let etable=$('#portfolioTable');
      let etrs=etable.find('.portfolioRow');
      let et1=etrs.filter('[data-name="'+aportfolio+'"]');
      if (et1.length==1) {
         let edo=et1.find('.cshowPortfolioViewModify');      // the init button
         window.setTimeout(function(){edo.trigger('click');},100);
      }
     return 1;
  }

  if (aaction=='portfolioModification') {
      showPortfolioTable(1);
      let aportfolio=simInvGlobals['temp']['autoLogonDetails']['portfolio'] ;
      let etable=$('#portfolioTable');
      let etrs=etable.find('.portfolioRow');
      let et1=etrs.filter('[data-name="'+aportfolio+'"]');
      if (et1.length==1) {
         let edo=et1.find('.cshowPortfolioViewModify');      // the view  init and mods button
         window.setTimeout(function(){edo.trigger('click');},100);
      }
     return 1;
  }
  if (aaction=='portfolioInit') {
      showPortfolioTable(1)    ;
      let aportfolio=simInvGlobals['temp']['autoLogonDetails']['portfolio'] ;
      let etable=$('#portfolioTable');
      let etrs=etable.find('.portfolioRow');
      let et1=etrs.filter('[data-name="'+aportfolio+'"]');
      if (et1.length==1) {
         let edo=et1.find('.cshowPortfolioViewModify');              // the view  init and mods button
         window.setTimeout(function(){edo.trigger('click');},100);
      }
     return 1;
  }


}


//=================================================================
// this does the work of building simInv data (assets, portfolios,etc) for display and manipuation
// Note:  responseFromServer may actualy be from local storage!

function afterLogon_build(responseFromServer,qReload) {

// logon error?
   if (responseFromServer.hasOwnProperty('error') && responseFromServer['error']===true)  {
     clearTimeout(simInvGlobals['monitorStartup_id']);  // got an error now, so don't wait and check for error!
      let bmess=responseFromServer['errorMessage'] ;
      bmess+='<br>You can ... <button class="cdoButton"  onClick="doLogoff(1)">logon again</button>';
     displayStatusMessage(bmess);
     return 0;
   }

// if here, logon okay (encryption key matches);

   let qLocal= simInvDsets['simInvLocalStorage']['enabled'] ;

  simInvDsets['allCurrentData']= JSON.parse(JSON.stringify(responseFromServer));     // this is what is modifeid, and sent to server, when assets etc are changed

  let response ;
  simInvDsets['qStatusList']['responseStatus']=true ;    // got a response from server (or local) -- but not verified (that is has all the components)

  response=afterLogon_build_extract(responseFromServer,qLocal);

  if (response!==false) simInvDsets['qStatusList']['responseStatusVerified']=true ;    // got response that is verified ...

  if (simInvGlobals['doDebug']==1) {
    if (qLocal) {
       showDebug(response,'simInv data for '+userName+' (local storage)',1);   // enable this (set doDebug at top of file) to view response --- which might be a php error message
    } else {
       showDebug(response,'simInv data for '+userName+' (server storage)',1);   // enable this (set doDebug at top of file) to view response --- which might be a php error message
    }
  }   // do debug


   shortcut.add("esc",simInvEsc,{
	'type':'keydown',
 	'propagate':true,
	'disable_in_input':true,
	'target':document
   });

   $('#iToggleActionBar').prop('disabled',false);
   $('#header_floatRight').show()  ; // display the settings, etc in the header

  buildAllSettings(response)  ; // user specific settings: defaults are globals set in  simInv_params.js ....
  for (let iyear in simInvGlobals['cpiuSeries']) simInvGlobals['cpiuSeries'][iyear]=parseFloat(simInvGlobals['cpiuSeries'][iyear]) ;   // inflation series used in several places

  setupScenario(response) ; // setup scenarioSpecs, change top row "chosen scenarios" span

  simInvGlobals['cpiuSeriesUse']=fixCpiuSeries(simInvGlobals['cpiuSeries'],simInvParams['inflationAverageTimespan'],simInvParams['lastYearUse']);

   if (simInvGlobals['cacheStuff']['cacheDisplayResults']==='fast') {
      simInvDsets['allCurrentData2']= JSON.parse(JSON.stringify(response));     // used if fast quickDisplay
   }

// create internal datasets from the response ...

  assetList=response['assets'] ;                // assetList is a global

  let assetHistoryOrig=response['assetHistory'] ;

  portfolioList=response['portfolios'] ;       // a global -- not encrypted

  let entryComments=setupPortfolios(response) ; // basic setup for globals portfolioInit and portfolioModifications
  if (entryComments!==false) simInvDsets['qStatusList']['setupPortfolios']=true;

// create assetLookup global from the assetlist and history

  assetLookup=makeAssetLookup(assetList,assetHistoryOrig );
  simInvDsets['qStatusList']['setupAssetLookup']=true;

 // does a number of quality control checks (are there missing or "too late" assets
  simInvDsets['qStatusList']['setupAssetUsedErrors']=makeAssetsUsed1(assetLookup);      // creates   assetsUsed -- returns # of errors

  if (simInvDsets['qStatusList']['setupAssetUsedErrors']>0)  {
      simInvDsets['qStatusList']['assetsNeedFixing']=true ;
      let apmess=showAssetProblems(1) ;
      simInvDsets['qStatusList']['warnings'].push(apmess);
  }

// update assethistory global (add imputed values using inflation?)  -- do this even if asset errors!
     updateAssetHistory_inflation(assetHistoryOrig, simInvParams['lastYearUse']) ;

// build asseValue cumulative stuff

// 1 march 2024 .. go rid of call to makeAssetValus_... do it  in  export or assetHistoryHtml)

// make some portfolios-with-values globals (SKIP this if asset errors, hence assetsNeedFixing=true, detected above )
  if (simInvDsets['qStatusList']['assetsNeedFixing']!==true ) {     // no asset errors detected (could be 0, which means "no problem yet detdted", so "build" the portfolios (init and mods)

// asset details are ready for use  ..... so create the portfolio databases from the asset-mixed retrieved from server
// note that since asset characteristics may be changed, the re-created portfolio (its netValue etc) CAN be different than
// the values when first specified.
// Hence: simInv recreates each time it loads, rather than save & retrieve   "working" portfolio datasests from the server (or local stoage) the server
//
    if (simInvGlobals['cacheStuff']['cacheDisplayResults']==='fast') {       // if 'fast', do nothing
         simInv_notes('fast quickEntry:  portfolio Init entries not processed ');
         simInv_notes('fast quickEntry: portfolio Modification entries not processed ');
         simInvDsets['qStatusList']['setupPortfolioInit']!==true ; // get by status monitor
         simInvDsets['qStatusList']['setupPortfolioMod']=0;
         simInvDsets['qStatusList']['setupPortfolioLookup']= true;
   } else {
      simInvDsets['qStatusList']['setupPortfolioInit']= makePortfolioInitValues(1)  ;    // changes global portfolioInit -- adds current values!
      simInv_notes(portfolioList.length+ ' portfolio Init entries processed ');

     if (simInvDsets['qStatusList']['setupPortfolioInit']!==false) {            // portfolioInit okay (no asset errors found)
        portfolioLookup=makePortfolioLookup(entryComments );  // portfolioLookup global    -- is used by  makePortfolioModifyValue
        simInvDsets['qStatusList']['setupPortfolioMod']=makePortfolioModifyValue(1)  ;    // modifies global portfolioModifications
        simInvDsets['qStatusList']['setupPortfolioLookup']= true;
        let nInits= makePortfolioLookupFix(1)  ; // update totnets in portfolioLookup using recalcualted portfolioModifications  (and get # of mod entries)
        simInv_notes(nInits + ' portfolio Modification entries processed ');
        makeViewDatesAll(1) ;          // augment the siminvDsets['viewDates'] (this used portfolioLookup global

     }
   }             // fast ...


  }       // no asset errors  - so portfolio builds were attempted

// now display stuff ...

  $('#mainDivHeader').show();

  $('#logonDiv').hide();
  let amm='<ul class="boxList">';

  let eaB=$('#assetsTableButton');
   let assetNeedInit=0;

   for (let baa in assetLookup) {
      if (assetLookup[baa]['nHistory']==0) {
          assetNeedInit=1;
          break;
      }
   }

  eaB.html('&#128065; '+assetList.length+' assets ');
  if (assetNeedInit==1) {                           // at least one asset needs initialization
      eaB.addClass('cdoButton')   ;
  } else {
      eaB.removeClass('cdoButton')
  }

//  do any portfolios need "initialzation" (specification of the intial asset mix) -- if so, highlgith the main menu bar Porrtoflio button!
  let portfolioNeedInit=0;
  for (let pfoo in portfolioLookup['list']) {
     if (portfolioLookup['list'][pfoo]['isInit']==0) {
        portfolioNeedInit=1;
        break;
     }
  }

  let ebB=$('#portfoliosTableButton');
  ebB.html('&#128065; '+portfolioList.length+' portfolios ');
  if (portfolioNeedInit==1) {
       ebB.addClass('cdoButton')   ;        // highlight in lime (signal a portfolio needs initialziation)
  } else {
      ebB.removeClass('cdoButton')
  }

  let ebF=$('#scenarioTableButton');
  ebF.html('&#128065; '+simInvDsets['scenarioSpecs']['nScenario']+' scenarios ');

  showSomeSettings1(1) ;      // show  some of the more important settings

  if (qLocal) {   // standalone or onlineWithLocal

      if ( simInvDsets['simInvLocalStorage']['onLineLocalStorage']===false) {    // standALone mode must use local file storage
         $('#standAloneMode').show();
         document.title='simInv: simulating investment alternatives -- standAlone mode ';
         $('#modeMessage').html('standAlone');
      } else {                // local file storage, onLine mode
         $('#localOnlineMode').show();
         document.title='simInv: simulating investment alternatives -- online mode w/local storage';
         $('#modeMessage').html('online (local storage)');
      }

  } else {                     // online
      document.title='simInv: simulating investment alternatives -- online mode ';
      $('#modeMessage').html('online ');

      if (simInvGlobals['encryptionKey']!='')  {
        let eenc=$('#encryptOn') ;
        eenc.show();
      } else {
         let eenc=$('#encryptOff') ;
         eenc.show();
      }
 }

  if (simInvGlobals['settingsHeaderCanHide']!=1) $('#settingsHeader1b').show();   // not toggleable, always show

  let tmess=writeBigMenu(1) ;

 simInvGlobals['welcomeMessage']=tmess ;  // save in global welcomeMessage for later re-display
  $('#mainDiv3').html(simInvGlobals['welcomeMessage']);
  wsurvey.wsShow.show('#mainDiv','show');  // make sure its on top
  wsurvey.wsShow.show('#mainDiv3','show');  // make sure its on top
  fitInMainDiv3('');

// populate  publicAssetsList
  simInvDsets['qStatusList']['publicAssetsOkay']=false ;
  if (typeof( publicAssets_current)=='undefined') {         // publicAssets_current is a  function defined in publicAssets/assetsUs.js -- that returns a stringified js object containing publicAssets info
     let gmess='' ;
      if (!qLocal) gmess='<br>You can <button class="cdoButtonRegular" name="doPublicAssetButton2" title="Initialize public assets" onclick="viewPublicAssets(this)" >Initialize public assets (step 1)</button>';
     simInvDsets['qStatusList']['warnings'].push('Note: publicAssets have not been initialized! '+gmess+'<p> See readme.txt for details ');
     simInvDsets['publicAssetsList']=false;
  } else {
    let palist=publicAssets_current(1);
    if (palist==false) {
       simInvDsets['qStatusList']['warnings'].push('Note: publicAssets are missing, or have not been initialized!! See readme.txt for details ');
   } else {
      simInvDsets['publicAssetsList']=JSON.parse(palist);
      simInvDsets['qStatusList']['publicAssetsOkay']=true;
   }
  }    // note that problems with publicAssets do NOT effect useability of everythign else -- assets and portfolios can be used normally. But adding publicAssets is disabled



// show the welcome sceen for new users?
  if (!qReload) {
  if (simInvParams['warningLevel']==0) {
     if (assetList.length==0) {   // no assets (hence no portfolios -- a new user!
        displayHelpMessage('#simWelcome',false,1) ;
     }
  }
  }

// Error or warnings -- show them, disable buttons, ....
  let gotErrors=false;                  // errors occurred? .. a couple of ways of checking (the 2nd is should be redundant)
  if (!simInvDsets['qStatusList'].hasOwnProperty('setupPortfolioLookup') ||   simInvDsets['qStatusList']['setupPortfolioLookup']===false ) gotErrors=false
  if (simInvDsets['qStatusList']['errors'].length>0) gotErrors=true;

  if (!gotErrors)  {           // no errors .. so check for warnings
       if (simInvDsets['qStatusList']['warnings'].length>0)  {           // warnings occured -- display them! typically  setupAssetUsedErrors>0
          wsurvey.wsShow.show('#statusDiv','show');  // make sure its on top
          let wmess= simInvDsets['qStatusList']['warnings'].join('<hr>');
          wmess+='<hr>You can view  information on   <input type="button" value="startup status" onclick="viewDiagnostics_show(1,2)">  ';
          if (simInvGlobals['enableAutoArchive']>0) wmess+=', or you can <input type="button" value="recover your data" onClick="autoArchive(3)"> from an archive ';
            wmess+='<div id="viewDiagnosticMessages2" style="border:1px dotted blue;margin:1em 1em;display:none">';
          wmess+=' </div>';
          displayStatusMessage(wmess);

          toggleStatusDiv(0,0)    ;
       }    else {                        // no warnings or errorsa
         simInvDsets['qStatusList']['autoLogonOkay']=true;      // no errors, no warnigns  ...   used by autologon -- if true, autologon can occur.
       }      // warnings (given no errors)

       if (simInvDsets['qStatusList']['assetsNeedFixing']  ) {        // if assetup errors, disable portfolio setup (user must fix assets)
           $('[name="doPortfolioButton"]').prop('disabled',true); // don't allow portfolio mods (need to fix assets first)
           $('[name="doDisplayButton"]').prop('disabled',true); // don't allow displays (need to fix assets first)
        }               // note: in conrast to errors, asset actions are allowed (they are encouraged!)

        if (!simInvDsets['qStatusList']['publicAssetsOkay']) {     // problem with public assets won't prevent most work (just can't add public assets)
            $('[name="doPublicAssetButton"]').prop('disabled',true); // don't allow asset actins
        }

  } else {        // errors have orrured...  disable actions. Let monitorStartup report warnings and errors that need to be fixed!

        $('[name="doPortfolioButton"]').prop('disabled',true); // don't allow portfolio mods (need to fix assets first)
        $('[name="doDisplayButton"]').prop('disabled',true); // don't allow displays (need to fix assets first)
        $('[name="doAssetButton"]').prop('disabled',true); // don't allow asset actins
        $('[name="doPublicAssetButton"]').prop('disabled',true); // don't allow asset actins
   }

//  note that this is in addition to warnings written!

// change header line
  $('#userNameInHeader').html(userName);
  $('#descNoteInHeader').hide();

  simInvDsets['qStatusList']['starting']=false;       // this is used by some functions (if true, stuff saved in qStatusList
  let jj=100/0;

// Just about done --- set a flag for checkStartingFailure to use (and flash a message)

  if (!gotErrors)  {
      if (simInvDsets['qStatusList']['assetsNeedFixing']===0)   simInvDsets['qStatusList']['assetsNeedFixing']=false ;     // not anywere above, so make it false
      simInvDsets['qStatusList']['complete']=true;             // flag of success (same as qStatusListComplete)
      if (simInvDsets['qStatusList']['warnings'].length==0) {
         if (!qReload) {
           displayStatusMessage('simInv initialization completed ')  ;   // don't flash message if warnings are displayed
           displayStatusMessage(false,0,1000);  // and fadeit out after a second
         }
      }
  } else {                      // a failure --
      simInvDsets['qStatusList']['complete']=false;             // flag of success (same as qStatusListComplete)
      if (!qReload) {
         clearTimeout(simInvGlobals['monitorStartup_id']);  // immediate clear timeout, and then call...
         monitorStartup(0,2) ;   // 0,2 to signal "simInv data problem"
      }
  }

  return 1;   // ready for user action (or failure handler)


// ----------------- local functions -----------

// --------- show some personal settings
// less importants settings are not displayed on main screen (but are shown when settings menu is opened)

  function showSomeSettings1(ifoo2) {
    $('#headerBarRight').show();

    $('#iCashInterest').html(simInvParams['cashInterest']);
    $('#iCashPenalty').html(simInvParams['cashPenalty']);

    $('#itaxRateValue').html(simInvParams['taxRate']);
    $('#icapitalGainsValue').html(simInvParams['capGainsRate']);
    $('#ifirstYearUse').html(simInvParams['firstYearUse']);
    $('#ilastYearUse').html(simInvParams['lastYearUse']);

   $('#simInvIntro_ver').html(simInvGlobals['versionNumber']);  // versionNumber is global (set in simInv_params.js)

   $('#encryptOn').hide() ;     // one of these four will be shown
   $('#encryptOff').hide() ;
   $('#standAloneMode').hide();
   $('#localOnlineMode').hide();
   return 1;
}



  // build user specific settings (overwrite global defaults)   -- save to allSettings global
  // also save cpiuSeries
  function buildAllSettings(response) {

// this should  be same as in scenarioUseSave() in simInv.js
    let plist=['cashInterest', 'cashPenalty', 'taxRate', 'capGainsRate', 'firstYearUse',
               'lastYearUse', 'lastYearUse', 'encryptionKeyHint', 'scenarioUse', 'warningLevel','showValuesInterp','doQuickDisplay',
               'showTransactions', 'budgetRemainPct', 'headerSep',
               'inflationAverageTimespan', 'sameAssetFamilyOk', 'additionsFromCash','defaultBudget'];

    for (let im=0;im<plist.length;im++) {
       let aparam=plist[im];
       if (response['settings'].hasOwnProperty(aparam)) simInvParams[aparam]=response['settings'][aparam];
    }  // otherwise, use default set in  simInv_params.js
    simInvGlobals['cpiuSeries']=(response.hasOwnProperty('cpiuSeries')  ) ? response['cpiuSeries'] : simInvGlobals['cpiuSeries'];


// use doQuickDisplay in user configurable parameters  to set value of    simInvGlobals['cacheStuff']={'cacheDisplayResults']
   let doqu=simInvParams['doQuickDisplay'] ;
   if (doqu!='1' && doqu!='fast') doqu=0;
   if (doqu==1) doqu=true;
   if (doqu==0) doqu=false;
   simInvGlobals['cacheStuff']['cacheDisplayResults']=doqu;


    return 1;
  }

// write the big menu, with some specifics
  function writeBigMenu(ifoo1) {
    let tmess='';
    tmess+='<div style="margin:0.25em 2em;padding:1em">';
    tmess+='<input type="button" value="x" title="close this welcome screen" onClick="reShowWelcome(-1)"> ';

    tmess+='Hello <b>'+userName+'</b>! simInv is ready to use! You can ... <p>';

    tmess+='<ul class="boxList2">';

    tmess+='<li><span class="cdoButtonRegularFooOuter ">';
    tmess+=' <button  class="xcdoButtonRegularFoo csettingsButton"   name="doDisplayButton"  onClick="showAllPortfolioValuesStart(0)"> &#128176; Display </button> ';
    tmess+='</span>';
    tmess+=' : display trends in portfolio results  -- the netValue, etc. for currently specified portfolios  ';

    tmess+='<br> <em>and</em> &hellip;  ';
    tmess+='<br> <span class="cdoButtonRegularFooOuter">'
    tmess+='<button   class="csettingsButton"  name="doDisplayButton"    onClick="createViewDates(0)">&#128197;displayDates</button>';
    tmess+='</span>';
    tmess+=' : change what dates to use  (when displaying trends in portfolio results)';

    tmess+='<li><span class="cdoButtonRegularFooOuter">';
    tmess+='<button  class="csettingsButton " name="doAssetButton"  onClick="showAssetTable(this)" > &#128065; assets</button>';
    tmess+='</span>';
    tmess+=' : view, or modify '+assetList.length+' assets .. or add a new one ';

     tmess+='<br><em>or ...</em><br>';
     tmess+='<span class="cdoButtonRegularFooOuter">';
     tmess+='<button  class="csettingsButton" name="doAssetButton"   title="Add a history entry for an asset " onClick="showAssetHistory(this)" >&#128476; vu</button> ';
     tmess+='</span>';
     tmess+=' : compressed view ';

    tmess+='<li><span class="cdoButtonRegularFooOuter">' ;
    tmess+='  <button class="csettingsButton"   name="doPublicAssetButton"  title="View/Create public asset" onClick="viewPublicAssets(this)" >&#127760;Public</button> ';
    tmess+='</span>';
    tmess+=' : view (and add to available assets)  simInv`s <em>public assets</em>.';

    tmess+='<li><span class="">';
    tmess+='<button onClick="showAllAssetDetailsHtml(this)"   name="doAssetButton"  >&#128463;Info</button> ';
    tmess+='</span>';
    tmess+=' : view trend information on the assets (the history of their price, interest, etc.)  ';

    tmess+='<li><span class="cdoButtonRegularFooOuter">';
    tmess+='<button  class="csettingsButton"  name="doPortfolioButton"  onclick="showPortfolioTable(this)"> &#128065; portfolios </button> ';
    tmess+='</span>';
    tmess+=' : view, or modify  '+portfolioList.length+' portfolios .. or add a new one! ' ;

    tmess+='<li><span class="cdoButtonRegularFooOuter">';
    tmess+=' <button  class="csettingsButton" name="doScenarioButton"   onClick="showScenarioTable(this)"> &#127760; scenarios </button>';
    tmess+='</span>';
    tmess+=' : view, or modify  '+simInvDsets['scenarioSpecs']['nScenario']+' scenario .. or add a new one! ' ;


    tmess+='<li><span class="cdoButtonRegularFooOuter">';
    tmess+='<button class="cdoButtonRegularFoo"  onclick="personalSettings(this)">&#9965;</button> ';
    tmess+='</span>';
    tmess+=' : change personal settings ';

    tmess+='<li><span class="cdoButtonRegularFooOuter">';
    tmess+='<button  class="cdoButtonRegularFoo"  onclick="doSetInflation(this)">&#11192; &#206;nflation</button> ';
    tmess+='</span>';
    tmess+=' : view and modify  (CPI) schedule';

    tmess+='<li><span class="cdoButtonRegularFooOuter">';
    tmess+=' <button class="cdoButtonRegularFoo" onclick="doExport_menu(this)">&#128194;</button> ';
    tmess+='</span>';
    tmess+=' : export results and data ';

    tmess+='<li> or &hellip; <input class="csettingsButton" type="button" value="&#10068;Intro" " onclick="wsurvey.wsShow.show(this)" data-wsshow="#simInvHelp"> <em>to view an introdution ... and other online help!</em>';

   tmess+='<li><input class="cdoButtonRegular" id="iToggleActionBar2" type="button" value="&#8962;" title="Hide welcome screen, show actions bar" data-status="10" onclick="toggleActionBar(this)"> ';
   tmess+='Hide  this welcome screen, and display the actions bar ';
    tmess+='</ul>';
    tmess+='</div>';
    return tmess
  }        // local function writeBigMenu

}     // ::::::: end of afterLogon  :::::::

//=====
// create global vars by extracting from the resonse from the server (or localStorage)
// note that server response has already been decrypted and unstringifies... so not quite raw resposne
// settings, assetHistory, portofolioInit, and  portfolioModifications are objects
// viewDates should be an object (but check if array, and convert if necessary)
// assets, and portfolios are arrays

function afterLogon_build_extract(responseZ,qLocal) {
 
  let response0={};      // temporary
  let daGetVars=['settings','cpiuSeries','assets','assetHistory','portfolios','portfolioInit','portfolioModifications','scenario','viewDates'] ;   // variables to extract from responseFromServer

  for (let iz=0;iz<daGetVars.length;iz++) {

   let zvar=daGetVars[iz];

   if (zvar=='settings') {                     // show alwaysb be availablet (created during initialization)
     if (responseZ[zvar].hasOwnProperty('data')) {
        response0[zvar]=responseZ[zvar]['data'];
     } else {
        response0[zvar]=responseZ[zvar] ;
     }
//     wsurvey.dumpObj( response0[zvar],1,'seeett');
   }

   if (zvar=='cpiuSeries') {                     // show alwaysb be availablet (created during initialization)
     if ( responseZ[zvar].hasOwnProperty('data')) {
        response0[zvar]=responseZ[zvar]['data'];
     } else {
        response0[zvar]=responseZ[zvar] ;
     }
   }

   if (zvar=='assets') {
        response0[zvar]=responseZ[zvar]['data'];
   }

   if (zvar=='assetHistory')  {
        response0[zvar]=responseZ[zvar]['data'];
        for (let aaname in response0[zvar]) {
           if (!response0[zvar][aaname].hasOwnProperty('entries') )  response0[zvar][aaname]['entries']=[] ;
        }
   }

   if (zvar=='portfolios') {
        response0[zvar]=responseZ[zvar]['data'];

   }

   if (zvar=='portfolioInit') {
        response0[zvar]=responseZ[zvar]['data'];
   }

   if (zvar=='portfolioModifications') {
        response0[zvar]=responseZ[zvar]['data'];
   }

   if (zvar=='scenario') {
        response0[zvar]=responseZ[zvar]['data'];
   }

   if (zvar=='viewDates') {           // fix if pre 1 march 2024 format...
        let tt0=responseZ[zvar]['data'];          
        let tt1;
        if (jQuery.isArray(tt0)) {   // check for pre march 1 2024 format (array of dates)
           tt1={'customDates':tt0};
        } else {
           if (!jQuery.isPlainObject(tt0)){
              tt1={} ;          // should not happen, but wth
           } else {
              tt1=tt0;
           }
          if (!tt1.hasOwnProperty('customDates')) tt1['customDates']=[];    // for now, don't set defaults for addEntryDates and addCalendarDates

        }
        if (!tt1.hasOwnProperty('firstDateAllow')) {       // if this is first logon -- need to initilaize. These are set & saved with displayDates
            let oof1=setEntryDate(2020,1,1);
            let oof2=setEntryDate(2025,12,31);
            tt1['firstDateAllow']=oof1.dayCount;
            tt1['lastDateAllow']=oof2.dayCount;
            tt1['addEntryDates']=2;       // init and mod
            tt1['addCalendarDates']=1;      // yearly calendar dates
            tt1['addCurrentDate']=0;     // do not add current date
        }
        simInvDsets['viewDates']=tt1;   // note that this is augmented by makeViewDatesAll (after portfolioLookup is created)


   }

  }  // dogetvars

   if (jQuery.isNumeric(simInvGlobals['lastUpdateDate']) && simInvGlobals['lastUpdateDate']>1) {
      if (qLocal) {
         simInvGlobals['lastUpdateDateSay']= wsurvey.get_currentTime(31,1,simInvGlobals['lastUpdateDate']);
      } else {
         simInvGlobals['lastUpdateDateSay']= wsurvey.get_currentTime(31,1,simInvGlobals['lastUpdateDate']);
      }
   }

  return response0;

 }

//=============
// create the assetLookup Hash Table
// uses ahist for  autoAddEntries, and first/last  date variables

function makeAssetLookup(alist,ahist) {

  let ahash={};

  for (let i1=0;i1<alist.length;i1++) {  // each entry in assetList

    if (typeof(alist[i1])=='undefined') makeAssetLookupError=undefinedOne/3 ;   // fatal error

     let dname=alist[i1]['name'];
     ahash[dname]={};
     for (let agoo in alist[i1]) {
        if (agoo!='name')   ahash[dname][agoo]=alist[i1][agoo];
     }

     ahash[dname]['nHistory']=0;
     ahash[dname]['firstDateInHistoryList']=false;

     let nHistory=0,firstEntryDate=false ;
     let d0=0;
     let earliestEntryDate=false;
     let latestEntryDate=false ;
     let growths={};
     let acqValues={};

     if (ahist.hasOwnProperty(dname) && ahist[dname].hasOwnProperty('entries') ) {
        nHistory= ahist[dname]['entries'].length   ;
     } else {
          nHistory=0;
          growths=false;
          acqValues=false;
          earliestEntryDate=false  ;
          latestEntryDate=false;
          firstEntryDate=false;
          ahash[dname]['entries']=[];
          d0=false;
         ahash[dname]['autoAddEntries']=false;
     }

     if (nHistory>0) {        // 'entries' exists
            d0=ahist[dname]['entries'][0]['date'];
            let oof=setEntryDate(d0);
            firstEntryDate=oof['sayDate'];
            earliestEntryDate=111111111111;
            latestEntryDate=-1111111111111 ;
            for (let ik=0;ik<nHistory;ik++) {
               let arf=ahist[dname]['entries'][ik];
               let kdate=parseInt(arf['date']);
               earliestEntryDate=Math.min(kdate,earliestEntryDate);
               latestEntryDate=Math.max(kdate,latestEntryDate);
               growths[kdate]=arf['assetIncomeGrowth'];
               acqValues[kdate]=arf['assetIncome'];

           }
     }     // nhistory>0

     ahash[dname]['nHistory']=nHistory;
     ahash[dname]['date']=d0;                     // 30 jan 2024 ... kind of redundant...
     ahash[dname]['firstEntryDateSay']=firstEntryDate;
     ahash[dname]['earliestEntryDate']=earliestEntryDate;      // 30 jan 2024 .. should be same as firstDateInHistoryList
     ahash[dname]['latestEntryDate']=latestEntryDate;

     ahash[dname]['growths']=growths;
     ahash[dname]['acqValues']=acqValues;

     if (ahist.hasOwnProperty(dname)) {
       ahash[dname]['autoAddEntries']=ahist[dname]['autoAddEntries'] ;
     }
     ahash[dname]['nImputed']=0;                         // updated by    updateAssetHistory_inflation


     if (nHistory>0)   {
         ahash[dname]['firstDateInHistoryList']=ahist[dname]['entries'][0]['date'];   // should be same as earliestEntryDate
     } else {
         ahash[dname]['firstDateInHistoryList']=false;
     }

  } // entries in assetlist

  return ahash;
}

//===================
// INfo on the "used" assets --- what portfolios (init or mod) entries do they appear in
// If there are assets in a portfolio that are NOT initialized-- record those
// returns
//  nErrs: # of assets with a problem
//  nMissing: # of assets that are NOT defined (perhaps ones that were deleted after being added to a still existing potfolio
//  nNoHistory : # of assets that do NOT have any history  (perhaps ones that were deleted, and reinitialze, after being added to a still existing potfolio
//  nOkay: # of used assets with a history
// List:  object with assetNames -- properties are exist (# of history entries), portfolios (what portfolios appears in)
//    assetName
//      exist: # of history entries
//      portfolios:
//           pname : array of entries -- the date of the entry.   0 if "initialiation" entry, otherwise dateStamp of a mod 
//        entries: # of portfolios appears in
//        type : asset type
//
// someDates: earliest and latest dates (across all assets and portfolios)
//    earliestPortfolioEntry and  lastPortfolioEntry: min/max date of portfolios entries (init and mods)
//    earliestAssetEntry  and lastAssetEntry: min/max date of asset history entries
//    earliestEntryBoth  and lastEntryBoth : min/max of the above
//
//  returns 0 if no problem, otherise # of errors

function makeAssetsUsed1(assetLookup) {
  let assetAll={};
  let earliestAssetEntry=11111111111111111 ;
  let earliestPortfolioEntry=11111111111111111 ;

  let lastAssetEntry=-11111111111111111 ;
  let lastPortfolioEntry=-11111111111111111 ;

 for (let aport in portfolioInit) {
    let dstamp=parseInt(portfolioInit[aport]['dateStamp']);
    earliestPortfolioEntry=Math.min(earliestPortfolioEntry,dstamp);
    lastPortfolioEntry=Math.max(earliestPortfolioEntry,dstamp);
   if (!portfolioInit[aport].hasOwnProperty('assetList')) {
       showDebug(portfolioInit ,'Problem: no assetList in initialization entry for portfolio '+aport,1);
        portfolioInit[aport]['assetList']=[];
   }
    for (let ij=0;ij<portfolioInit[aport]['assetList'].length ;ij++) {
       let dateStamp=portfolioInit[aport]['dateStamp'];
       let assetI=portfolioInit[aport]['assetList'][ij]['name'] ;
       let assetT=portfolioInit[aport]['assetList'][ij]['assetType'] ;
        if (!assetAll.hasOwnProperty(assetI)) assetAll[assetI]={'nHistory':-1,'portfolios':{},'initDates':{},'firstUseDates':{},'nPortfolios':0,'type':false  };
        if (!assetAll[assetI]['portfolios'].hasOwnProperty(aport))  {
            assetAll[assetI]['type']=assetT ;
            assetAll[assetI]['portfolios'][aport]=[];
            assetAll[assetI]['nPortfolios']++ ;
        }
        assetAll[assetI]['portfolios'][aport].push(0)   ;      // 0 signals "init entry"
        assetAll[assetI]['initDates'][aport]=dateStamp   ;      // date for the '0' portfolios row!
        assetAll[assetI]['firstUseDates'][aport]=dateStamp   ;      // if asset in is a portfolio init, that's the earliest date it can appear in that portfolio
    }
 }

 for (let aport in portfolioModifications) {
    for (let adate in portfolioModifications[aport] ) {
       let dstamp=parseInt(adate);
       earliestPortfolioEntry=Math.min(earliestPortfolioEntry,dstamp);
       lastPortfolioEntry=Math.max(earliestPortfolioEntry,dstamp);
       for (let ij=0;ij<portfolioModifications[aport][adate]['assetList'].length;ij++ ) {
          let assetI=portfolioModifications[aport][adate]['assetList'][ij]['name']  ;

          if (!assetAll.hasOwnProperty(assetI)) assetAll[assetI]={'nHistory':-1,'portfolios':{},'initDates':{},'firstUseDates':{},'nPortfolios':0,'type':false,'initDate':false };
          if (!assetAll[assetI]['portfolios'].hasOwnProperty(aport)) {
              assetAll[assetI]['type']=portfolioModifications[aport][adate]['assetList'][ij]['assetType']  ;
              assetAll[assetI]['portfolios'][aport]=[];
              assetAll[assetI]['nPortfolios']++ ;
              assetAll[assetI]['initDates'][aport]=false   ;      // false signals "does not appear in initialization entry:
              assetAll[assetI]['firstUseDates'][aport]=dstamp   ;      // typically first mod is earliest
          }
          assetAll[assetI]['portfolios'][aport].push(adate)   ;    // non-0 values are mod dates
          assetAll[assetI]['firstUseDates'][aport]=Math.min(dstamp,assetAll[assetI]['firstUseDates'][aport])   ;     // just in case mods are not in date order

       }       // ij in assetlist
    }            //adate
 }          // aport

 let nMissing=0,nNoHistory=0,nOkay=0;

 for (let zasset in assetAll) {                 // backfill nHistory-- if no such asset (perhaps it was deleted) nHistory will be -1. Or it could be 0 (assetHistory got deleted?)
     if (!assetLookup.hasOwnProperty(zasset)) {
         nMissing++;                                // appears in at least one portfolio entry... but not defined (perhaps was deleted)
         continue ;   // nHistory stays at -1
     }
     let jh=assetLookup[zasset]['nHistory'];
     assetAll[zasset]['nHistory']=jh ;
     let aearly=assetLookup[zasset]['earliestEntryDate'];
     assetAll[zasset]['earliestEntryDate']=aearly ;
     if (jh==0) {
         nNoHistory++;
     } else {
         nOkay++;
         let aearly=assetLookup[zasset]['earliestEntryDate'];
         let alate=assetLookup[zasset]['latestEntryDate'];
         earliestAssetEntry=Math.min(earliestAssetEntry,aearly);
         lastAssetEntry=Math.max(lastAssetEntry,alate);
     }
 }

// # assets used by portfolios that do NOT start soon enough (first time asset appears in a portfolio init/mods entries is BEFORE the first asset history entry
// and for fun, what assets are NOT in any portfolio entry

 let nEarlyMissing=0,nOkay2=0;
 let earlyMissing={};

  let notUsed=[],used=[];
  for (let gasset in assetLookup ) {
     if (!assetAll.hasOwnProperty(gasset)) {
        notUsed.push(gasset);
     } else {
        used.push(gasset) ;
        earlyMissing[gasset]=[];
        let firstHistory=assetLookup[gasset]['earliestEntryDate'];
        for (let passet in assetAll[gasset]['firstUseDates']) {
            let pfirstUse=assetAll[gasset]['firstUseDates'][passet];
            if (firstHistory>pfirstUse) {     // a problem!
              if (earlyMissing[gasset].length==0)  {
                 nEarlyMissing++;
                 earlyMissing[gasset][0]=pfirstUse;
               }
               earlyMissing[gasset].push(passet);
               earlyMissing[gasset][0]=Math.min(pfirstUse, earlyMissing[gasset][0]);
            }    // firstHistory>pfirstUse
        }       // passet loop (checking firstUseDates
        if  (earlyMissing[gasset].length==0) nOkay2++ ;
     }    // used notused
  }

 let someDates={};
  someDates['earliestPortfolioEntry']=earliestPortfolioEntry;
  someDates['lastPortfolioEntry']=lastPortfolioEntry;

  someDates['earliestAssetEntry']=earliestAssetEntry;
  someDates['lastAssetEntry']=lastAssetEntry;

  someDates['earliestEntryBoth']=Math.min(earliestAssetEntry,earliestPortfolioEntry);
  someDates['lastEntryBoth']=Math.max(lastAssetEntry,lastPortfolioEntry);

 let nerrs=nMissing+nNoHistory+nEarlyMissing;
 assetsUsed={'nErrs':nerrs,'nMissing':nMissing,'nNoHistory':nNoHistory,'nEarlyMissing':nEarlyMissing,'nOkay':nOkay,'nUsedOkay':nOkay2,'list':assetAll,'someDates':someDates,
     'used':used,'notUsed':notUsed,'earlyMissing':earlyMissing}  ; // assetsUsed is a global

// btw: notUsed (that do NOT appear in any portfolio) are ignored (their history status can be ignored)
// nEarlyMissing, nMissing. and nNoHistory >0 is a error -- some how one of the assets got messed up, and a portfolio that needs it can get a mearue

 return nerrs ;

} // makeAssetsUsed1


//===================
// missing or flawed assets -- show a warning screen
function showAssetProblems(ifoo) {
 
  let bmess='';
  bmess+='<b>Asset definition errors</b><br>';
  bmess+='There are one (or more) assets specified in one (or more) portfolios that are <u>improperly</u> defined (perhaps you deleted them)!<br>';
  bmess+='You <u>must</u> correctly specify these assets. <br>';
  bmess+='<table border=1" xrules="rows" cellpadding="4" width="90%">';
  bmess+='<tr><th width="15%">Asset</th> <th width="35%">Status</th ><th width="35%">Appears in portfolios ...</th></tr>';

  let errmess={};
  goterr=0;

  for (let zasset in assetsUsed['list']){
     let gg=assetsUsed['list'][zasset];
     let vprob=[];
     let gotEntries=false,noexist=false;

     if (gg['nHistory'] <0) {
         if (!errmess.hasOwnProperty(zasset)) errmess[zasset]=[];
         errmess[zasset].push('Not specified');
         t1v=assetsUsed['list'][zasset]['firstUseDates'];
         vprob[0]=11111111111 ;   //  starting min
         for (let tport in t1v) {
             vprob.push(tport);
             vprob[0]=Math.min(vprob[0],assetsUsed['list'][zasset]['firstUseDates'][tport]);
         }
         goterr++;
         noexist=true;

     } else if (gg['nHistory']==0) {
         if (!errmess.hasOwnProperty(zasset)) errmess[zasset]=[];
         vprob=assetsUsed['earlyMissing'][zasset] ;  // earlyMissing?
         goterr++;
         t1v=assetsUsed['list'][zasset]['firstUseDates'];
         vprob[0]=11111111111 ;   //  starting min
         for (let tport in t1v) {
             vprob.push(tport);
             vprob[0]=Math.min(vprob[0],assetsUsed['list'][zasset]['firstUseDates'][tport]);
         }
     } else {
        gotEntries=true;
        vprob=assetsUsed['earlyMissing'][zasset] ;  // earlyMissing?
     }
     let nvprob=vprob.length ;
     if (nvprob>0) {
           let histFirst= gg['earliestEntryDate'] ;
           let portFirst=vprob[0];
           let histFirstSay= (gotEntries) ? setEntryDate(histFirst).sayDate : '<tt>not specified</tt>' ;
           let portFirstSay=setEntryDate(portFirst).sayDate ;
           let nprobs=nvprob-1;          // [0] contains "earliest portfolio entry date" (for this asset). could be init entry, or a modification
           let aerr=nprobs+' portfolios include this asset <b>before</b> its first assetHistory entry on '+histFirstSay;
           aerr+='<br>You must specify an asset history entry on (or before): <b>'+portFirstSay +'</b>';
           if (!noexist) {     // asset exists but needs earlier history
               aerr+='<br> <input type="button" value="Add a history entry" title="Add a history entry for this asset)" data-adddate="'+portFirst+'"   data-name="'+zasset+'" ';
               aerr+='   onclick="addEmptyRowToAssetHistory(this,1)" >' ;
           }  else {
               aerr+='<br> <input type="button" value="Add a new asset" title="Add a new asset" data-adddate="'+portFirst+'"   data-name="'+zasset+'" ';
               aerr+='   onclick="addEmptyRowToAssetHistory(this,0)" >' ;
           }
           if (!errmess.hasOwnProperty(zasset)) errmess[zasset]=[];
           errmess[zasset].push(aerr) ;
           goterr++;

      }
    }
    if (goterr==0) {           // should never happen (fatal error)
       showDebug(assetsUsed,'Asset specification errors reported, but could not ascertain any! ',1);
       let whyNoErrors=whyNoError1/35151;
       return 0;
    }
    for (let zasset in errmess) {
         let aa=[];
         for (let pp1 in assetsUsed['list'][zasset]['portfolios']) {
            sayPp1=pp1;
            if (jQuery.inArray(pp1,assetsUsed['earlyMissing'][zasset])>-1) sayPp1='<span style="text-decoration:underline" title="an entry starts too early">'+pp1+'</span>';
            aa.push(sayPp1);
         }

       let aicon=getAssetType(zasset,'say')   ;
       if (aicon===false) aicon='...';
       let aline='<tr><td>'+aicon+' <u>'+zasset+'</u></th>';
       let errs1='<ul class="thinnerMenu"><li>'+errmess[zasset].join('<li>')+'</ul>';
       aline +='<td>'+errs1+'</td>';
       bmess+=aline ;
         bmess+='<td>'+aa.join(' &vellip; ')+'</td>';
         bmess+='</tr>';
     }

     bmess+='</table>';

     return bmess ;

}


///===============
// setup portfolioInit and portfolioModifications
function setupPortfolios(response) {      // arguments are clones of resposne from server

  let entryComments={} ;

  portfolioInit= JSON.parse(JSON.stringify(response['portfolioInit']));  // clone to make global ;
  for (let apname in portfolioInit) {
      entryComments[apname]={};
      let adate=portfolioInit[apname]['dateStamp'];
      entryComments[apname][adate]=portfolioInit[apname]['comment'];
  }

  portfolioModifications={};            // the global, to be built in pieces, to ensure ascending order (in dates)

// sort in date-ascending order
  let portfolioModifications_1=response['portfolioModifications'] ;

  for (let pname in portfolioModifications_1 ) {

    portfolioModifications[pname]={};
    let darray=[];
    for (let dstamp in portfolioModifications_1[pname]) {   // make a sortable list
       darray.push(dstamp);
    }
    darray.sort(mySortNumeric);    // sorted by data -- the modifications of pname

//  start with earliest frist
    for (let idd=0;idd<darray.length;idd++) {
      let dstamp=darray[idd] ;
      portfolioModifications[pname][dstamp]= JSON.parse(JSON.stringify(portfolioModifications_1[pname][dstamp])) ;  // clone
       entryComments[pname][dstamp]=portfolioModifications_1[pname][dstamp]['modComment'];
    }
  }  // damods


   return entryComments;   //  portfolioInit and portfolioModifications (globals) a modified in place
}              // setupPortoflios

//====================
// assign values to the assets in the portfolios, based on dates. Also compute some summary stats

function  makePortfolioInitValues(ifoo)  {
   let errlist=[];

// re create full portfolioInit from what was saved on server -- using currently specified prices, etc
 for (let pjname in portfolioInit) {
    let alist1=portfolioInit[pjname];
    let adateStamp=alist1['dateStamp'];

    let daval0= portfolioCalcValue(alist1['assetList'], adateStamp,pjname,0,' from makePortfolioInitValues' ) ;  // get some totals

    if (daval0===false)  return false ;         // error looking up asset value ...   showDebug will have displayed a message (without asking for user permission)

    let origBudget=parseFloat(alist1['original']['budget']);
    let cashAssetOrig=parseFloat(alist1['cashAsset']);
    let cashAsset=cashAssetOrig  ;             // the presumption is the init entry  does NOT change even if historical prices change -- you got the assets and you got the Cash
    daval0['cashAsset']=cashAsset;

    let totNetAssetEst=parseFloat(daval0['totals']['totAssetSaleNetAT']);
    let totNetValue=totNetAssetEst +  cashAsset   ;
    portfolioInit[pjname]['cashAsset']=cashAsset;
    portfolioInit[pjname]['totNetValue']=totNetValue;

    portfolioInit[pjname]['totals']=daval0['totals'];

    portfolioInit[pjname]['assets']=daval0['assets'];
    portfolioInit[pjname]['totals']=daval0['totals'];

//returns {cashAsset totAssetSale totAssetSaleNet totAssetSaleNetAT totPortfolioValue totCapGainTax totDeferredTax totTaxPaid totPropertySale}
    let totalsAfterGrowth=calc_netValues(daval0,cashAsset); // ,pjname+' gog') ;     // more accurate net value measure (includes losses,  and capital gains, appropriately)

    portfolioInit[pjname]['totalsAfterGrowth']=totalsAfterGrowth;
    portfolioInit[pjname]['madeBy']='makePortfolioInitValues';

    portfolioDates[pjname]={'addedDate':{},'addedDatePrice':{},'addedDateCost':{},'modifiedDate':{}} ;  // a global

    let totAdds=0;
    for (let im=0;im<alist1['assetList'].length;im++) {
        let aname=alist1['assetList'][im]['name'];
        let qexists=doAssetLookup(aname,'*');  // does this asset exist?
        if (qexists===false)  {
           errlist.push('Asset `'+aname+'` in portfolio `'+pjname+'` does not exist');
        } else {

          if (qexists['nHistory']==0) {
             errlist.push('Asset `'+aname+'` in portfolio `'+pjname+'` has no entries');
          } else {
             let acomment=alist1['assetList'][im]['comment'];
             portfolioInit[pjname]['assets'][aname]['comment']=acomment;

          }  // nhistory
        }

        let atype= daval0['assets'][aname]['assetType'];

// include addedDate and modifiedDate

         portfolioDates[pjname]['addedDate'][aname]= alist1['assetList'][im]['addedDate'];  // portfolioDates is a global
         portfolioDates[pjname]['modifiedDate'][aname]=false;

        if (atype==0 || atype==1 || atype==2 ){
           portfolioDates[pjname]['addedDatePrice'][aname]= daval0['assets'][aname]['price'];
           portfolioDates[pjname]['addedDateCost'][aname]= daval0['assets'][aname]['purchaseCost'];
        } else if (atype==3 || atype==4 || atype==5  || atype==6     ) {
           portfolioDates[pjname]['addedDatePrice'][aname]= daval0['assets'][aname]['price'];
           portfolioDates[pjname]['addedDateCost'][aname]= daval0['assets'][aname]['acqCost'];
        }

        portfolioInit[pjname]['assets'][aname]['addedDate']=portfolioDates[pjname]['addedDate'][aname];
        portfolioInit[pjname]['assets'][aname]['modifiedDate']= portfolioDates[pjname]['modifiedDate'][aname];
        portfolioInit[pjname]['assets'][aname]['addedDatePrice']= portfolioDates[pjname]['addedDatePrice'][aname];
        portfolioInit[pjname]['assets'][aname]['addedDateCost']=  portfolioDates[pjname]['addedDateCost'][aname];

    }
   let gg1=growPortfolioDo(pjname,portfolioInit[pjname]['assetList'],portfolioInit[pjname]['cashAsset'],adateStamp,false,adateStamp,'initialization',0,0)  ;

  }

// update portfolioList global  (set exist flag to 1 for portfolios with an initialization entry... 'exists' should be 'isInit'
  for (let iz=0;iz<portfolioList.length;iz++ ) {         // update exists in portfolioList
    let zname=portfolioList[iz]['name'];
    if (portfolioInit.hasOwnProperty(zname)) {
       portfolioList[iz]['exists']=1;
    }
  }

  if (errlist.length>0) {                  // this should not happen --  makePortfolioInitValues should not be called if asset errors are detected in makeAssetsUsed1()
     let arf='Errors were found in the asset definitions. Please add these assets, or remove portfolios with these assets !';
     for  (iarf=0;iarf<errlist.length;iarf++) arf+='\n * '+errlist[iarf];
     alert(arf);
  }



 return true ;          // portfolioInit is global     daval0      v1

}            //    makePortfolioInitValues

// ==============================
// recreate portfolios from asset-mixes saved on server

function makePortfolioModifyValue(ifoo) {

 let new1={};
 let ith=0;
 let cvars=['name','dateStamp','dateStampSay','cashAsset','assetList'];

 for (let pname in portfolioModifications  ) {
//     if (portfolioLookup['list'][pname]['isHidden']==1 ) continue ; // 9 march 2024: do NOT skip -- need to calculate for use in Portfolios button 

    let p0ValsZ= JSON.parse(JSON.stringify(portfolioInit[pname]));  // clone this ;
    let p0Vals={},cashAsset ;
    for (let ia=0;ia<cvars.length;ia++) {
       let avar=cvars[ia];
       p0Vals[avar]=p0ValsZ[avar];
    }
    let assetList1=p0Vals['assetList'];
    let cashAsset1=p0Vals['cashAsset'];
    let date1=p0Vals['dateStamp'];
    let ithBase=0;          // the base for the "first modfication" is the init

// make sure to start with earliest first  (since later portfolios use growth/etc of the prior portfolio

    for (let idd=1;idd<portfolioLookup['list'][pname]['modDates'].length;idd++) {
        let date2=portfolioLookup['list'][pname]['modDates'][idd] ;

        let assetList2= portfolioModifications[pname][date2]['assetList'] ;  // the asset-mix from this modification
        let modComment=portfolioModifications[pname][date2]['modComment'] ;

        let mentry= makeModPortfolio(pname,assetList1,cashAsset1,date1,assetList2,date2,modComment,ithBase) ;   // rebuild this moified portfolio (in simINv_growportfolio.js)

         mentry['assets']={};            // used below

        if (mentry===false) return false ;              // problem with making portfolios  -- recorded in simInvDsets['qStatusList']['errors']

// fix addedDate and modifiedDate vars

       for (let ij=0;ij<assetList2.length;ij++) {
          let aaname=assetList2[ij]['name'];
          let addDate=assetList2[ij]['addedDate'];
          let modDate=assetList2[ij]['modifiedDate'];

          if (addDate!==false)  {                                  // portfolioDates is global
            portfolioDates[pname]['addedDate'][aaname]= addDate;  // newly added
            portfolioDates[pname]['modifiedDate'][aaname]= false;
            portfolioDates[pname]['addedDatePrice'][aaname]= assetList2[ij]['origPrice']; // 18 nov 2023 :  may be incorrect (may depend on assettype)
            portfolioDates[pname]['addedDateCost'][aaname]= assetList2[ij]['origCost'];
          }
          if (modDate!==false)  portfolioDates[pname]['modifiedDate'][aaname]= modDate;

          mentry['assets'][aaname]={} ;
          for (let vvar in assetList2[ij]) mentry['assets'][aaname][vvar]=assetList2[ij][vvar] ;

          mentry['assets'][aaname]['ith']=ij;        // extra stuff
          mentry['assets'][aaname]['addedDate']=portfolioDates[pname]['addedDate'][aaname];
          mentry['assets'][aaname]['modifiedDate']= portfolioDates[pname]['modifiedDate'][aaname];
          mentry['assets'][aaname]['addedDatePrice']= portfolioDates[pname]['addedDatePrice'][aaname];
          mentry['assets'][aaname]['addedDateCost']=  portfolioDates[pname]['addedDateCost'][aaname];
      }       // fix addedDate and modifiedDate vars

// and save it
      portfolioModifications[pname][date2]=mentry;

      p0Vals=mentry;  // the next mod uses this mod as the "baseEntry"
      assetList1=mentry['assetList'];
      cashAsset1=mentry['cash'];       // use this when creating NEXT modification of this portoflio (in this loop)
      date1=date2;
      ithBase++ ;                  // this is now the "base" for the next modification

   }           // dstamp

 }  // pname
 return true ;    // portfolioModifications is global

}          // makePortfolioModifyValue


//=================
// used to recreate portfolios from asset-mixes saved on server
// grow a base portfolio (yielding a "grown portoflio)
//   (the base can be the initialization entry, or the most recent modification)
// AND then change asset mix --
// Thus: changes (specified by the user on an earlier date and saved in modAssetList) are from a "grown" prior entry
//      (with a "grown" Cash)

function makeModPortfolio(pname,baseAssetList,baseCash,startDate,modAssetList,modDate,modComment,ithBase) {
  let bb=growPortfolioDo(pname,baseAssetList,baseCash,startDate,modAssetList,modDate,modComment,ithBase,ithBase+1) ;
  return bb ;
}

//===========================
// 28 march 2024 .. no longer used
// create the simInvDsets['portfolioLastViewDate' -- "grown" values of portfolio on the lastViewDate
/*
function makePortfolioLastViewDate(i) {
   let lastDate=simInvDsets['viewDates']['lastDateAllow'];

    for (let pname in portfolioInit) {            // add for all portfolios, even it they have no modifications
       let LL1=portfolioLookup['list'][pname];
       if (LL1['nHistory']==0 || LL1['isHidden']==1 ) continue ; // don't bother if a portfolio is empty or hidden
       let modDates=LL1['modDates']   ;
       if (lastDate<=LL1['creationDate']) continue    ;        // last date before creation of this portfolio -- skip

       let im1=jQuery.inArray(lastDate,modDates)


       let alistUse=false,baseEntryNum,date1 ;
       if (LL1['modDates'].length==1 || modDates[1]>=lastDate)   {  // no modifications, or first mod occurs after this date -- so grow this from the init
            baseEntryNum=0;
            date1=LL1['creationDate'] ;
            alistUse=portfolioInit[pname];
       } else {                                   // grow from the mod before lastDate
           let dlen=modDates.length;
           for (let idd=dlen-1;idd>0;idd--) {     // given above check, lastdate always > craetionDate
              let trydate=modDates[idd];
              if (lastDate>trydate) {
                  alistUse=portfolioModifications[pname][trydate];
                  baseEntryNum=idd;
                  date1=trydate;
                  break;
              }
           }
       }
       let assetList1=JSON.parse(JSON.stringify(alistUse['assetList']));
       let cashAsset1=alistUse['cashAsset'];

       simInvDsets['portfolioLastViewDate'][pname]={'baseEntry':baseEntryNum,'modDate':lastDate};
       simInvDsets['portfolioLastViewDate'][pname]['data']=makeModPortfolio(pname,assetList1,cashAsset1,date1,false,lastDate,'lastDate value',baseEntryNum) ;   // rebuild this moified portfolio (in simINv_growportfolio.js)
  }

// saves to portfolioLastViewDate global
}
*/

//===============
// create portfolio lookup "hash"   -- use portfolioHistory  and portfolioInit globals

function  makePortfolioLookup(entryComments) {

  let aplist=portfolioList;             // portfolioList is global
   plookup={'list':{},'info':{}};

   let date1=111111111111111111111 ;
   let date2=-11111111111111111111 ;
   let nPortfolios=0;
   let allDates=[];

   for (let iP1=0;iP1<aplist.length;iP1++) {       // list of portfolios (including those with no info in portfolioInit)

     let anyDateAsset={} ;  // assets that appear in any entry of this portofpil
     let modDates=[];        // the dates of the porfolio's entry (will be sorted)

     let totNets={},cashAsset={},nAssets={},modDatesSay={},comments={},assetsList={},descs={};

     let pname=aplist[iP1]['name'];
     let pdesc=aplist[iP1]['desc'];
     descs[pname]=pdesc;

     if (!portfolioInit.hasOwnProperty(pname)) {    // no entry in portfolioInit
          plookup['list'][pname]={'ith':iP1,'isInit':0,'origbudget':false,'nHistory':0,
               'creationDate':false,'creationDateSay':'','isHidden':0,'desc':pdesc };
          continue;
     } else  if (portfolioInit[pname]['assetList'].length==0) {          // an entry with no assets (could happen if someone removed all the assets from an existing portfolio init entry )
          plookup['list'][pname]={'ith':iP1,'isInit':0,'origbudget':false,'nHistory':0,
                'creationDate':false,'creationDateSay':'','isHidden':0 ,'desc':pdesc };
          continue ;
     }

// init is useeable... first entry (ith:0) in plookup  (for this portfolio) is the init
     let nHistory=1;      // # of entries (init + mods) for this portoflio

     let creationDate=parseInt(portfolioInit[pname]['dateStamp']) ;
     let creationDateSay=portfolioInit[pname]['dateStampSay'] ;
     let origBudget=parseInt(portfolioInit[pname]['original']['budget']);
     let dohide=parseInt(aplist[iP1]['isHidden']);

     modDates.push(creationDate) ;        // this is sorted after all mod dates are found for this portfolio

     let assetsListNow={},nassets0=0;
     for (let io=0;io<portfolioInit[pname]['assetList'].length;io++) {
         let daname=portfolioInit[pname]['assetList'][io]['name'];

         assetsListNow[daname]=portfolioInit[pname]['assetList'][io]['assetType'];
         if (!anyDateAsset.hasOwnProperty(daname)) anyDateAsset[daname]=0;
         anyDateAsset[daname]++ ;
         nassets0++;
     }
     assetsList[creationDate]= assetsListNow ;
     nAssets[creationDate]=nassets0 ;

     allDates.push(parseInt(creationDate));     // used for info variables
     date1=Math.min(date1,creationDate);
     date2=Math.max(date2,creationDate);
     nPortfolios++;         // init is one of the entries!

// modDates is sorted (by date) array... that contains dateStamps used in the totNets, etc data objects
      totNets[creationDate]=parseFloat(portfolioInit[pname]['totNetValue']);           // these are stored in info
      cashAsset[creationDate]=parseFloat(portfolioInit[pname]['cashAsset']);           // these are stored in info

      modDatesSay[creationDate]=setEntryDate(creationDate).sayDate;
      comments[creationDate]= (entryComments[pname].hasOwnProperty(creationDate)) ? entryComments[pname][creationDate] : false;

// now for the modifications ...

     if (portfolioModifications.hasOwnProperty(pname)) {

     for (let adate1 in  portfolioModifications[pname]) {   // adate1 is the mod date
          allDates.push(parseInt(adate1));

          modDates.push(parseInt(adate1)) ;
          let assetsListNow={},nassets0=0;
          for (let io=0;io<portfolioModifications[pname][adate1]['assetList'].length;io++) {
             let aname2=portfolioModifications[pname][adate1]['assetList'][io]['name'];
             assetsListNow[aname2]=1;
             nassets0++;
             if (!anyDateAsset.hasOwnProperty(aname2)) anyDateAsset[aname2]=0;
             anyDateAsset[aname2]++ ;
          }

          assetsList[adate1]= assetsListNow ;
          nAssets[adate1]=nassets0 ;

          cashAsset[adate1]=parseFloat(portfolioModifications[pname][adate1]['summary']['cashAsset']);
          totNets[adate1]=parseFloat(portfolioModifications[pname][adate1]['summary']['totPortfolioValue']);
          modDatesSay[adate1]=setEntryDate(adate1).sayDate ;

            comments[adate1]= (entryComments[pname].hasOwnProperty(adate1)) ? entryComments[pname][adate1] : false ;

          nHistory++;
     }             //  adate1
     }           //  .hasOwnProperty(pname)) {

     let oof=sortNoDuplicates(modDates);          // int and mod dates

      plookup['list'][pname]={'ith':iP1,'isInit':1,'origBudget':origBudget,'nHistory':nHistory,'isHidden':dohide,
          'desc':descs[pname],
           'creationDate':creationDate,'creationDateSay':creationDateSay,
           'modDates':oof,'assetsList':assetsList,
           'totNets':totNets,'cashAssets':cashAsset,'nAssets':nAssets,'modDatesSay':modDatesSay,'comments':comments
        }
        let nAnyDateAsset=0;
        for (let foo in anyDateAsset) nAnyDateAsset++;

        plookup['list'][pname]['anyDateAsset']=anyDateAsset  ;
        plookup['list'][pname]['nAnyDateAsset']=nAnyDateAsset  ;

  }           // pname

// got all inits and mods....

  let oof2=sortNoDuplicates(allDates);

  plookup['info']['allDates']=oof2;
  plookup['info']['firstDateInit']=date1;
  plookup['info']['lastDateInit']=date2;
  plookup['info']['nPortfolios']=nPortfolios;

  return plookup;

}        // makePortfolioLookup


//=================
// fix some stuffi n portfolioLookup global (using portfolioModificatiosn global
function  makePortfolioLookupFix(i1)  {
   let nInits=0;
    for (let apname in portfolioModifications) {
       for (let adate in  portfolioModifications[apname])  {
          nInits++;
          portfolioLookup['list'][apname]['totNets'][adate]=portfolioModifications[apname][adate]['totalsNet']['totPortfolioValue'];
       }
    }
    return nInits ;
}

// --------------------
// augment   siminvDsets['viewDates'] (this uses portfolioLookup global

function makeViewDatesAll(ifoo) {
   let tt1=simInvDsets['viewDates'];           // this will be an object (possibly empty, possiblyi with just a 'customDates'  property

   let cdo=(tt1.hasOwnProperty('addCalendarDates')) ?   tt1['addCalendarDates'] : 0 ;
   let calA=buildDateList(tt1,cdo,false) ;      // use firstDateAllow and lastDateAllow that can be in tt1

   let edo=(tt1.hasOwnProperty('addEntryDates')) ?   tt1['addEntryDates'] : 2 ;
   let entA=buildDateList(tt1,false,edo) ;

   let allA=buildDateList(tt1)  ;  // use defaults if not specified in tt0

   let csay={};
   for (let ic=0;ic<allA.length;ic++) {
       let zday=allA[ic];
       let dobj=setEntryDate(zday);
       let zsay=dobj.sayDate;
       let isCal=jQuery.inArray(zday,calA);
       let isEnt=jQuery.inArray(zday,entA);
       let isCust=jQuery.inArray(zday,tt1['customDates']);

       let ta={'say':zsay,'calendar':isCal,'entry':isEnt,'custom':isCust};  // -1 signals NOT a calendar,entry, or custom date
       csay[zday]=ta;
   }

  tt1['calendar']=calA;
  tt1['entries']=entA;
  tt1['all']=allA ;
  tt1['allSay']=csay;


  simInvDsets['viewDates']=tt1;

  return 1;
}


//======================
//setup scenarioList and scenarioSpecs
function setupScenario(aresponse) {
  simInvDsets['scenarioSpecs']={};
  simInvDsets['scenarioSpecs']['nScenario']=0;
  simInvDsets['scenarioList']={};

//  check for  specnear specs
  let nScenario=0;
  simInvDsets['scenarioSpecs']['entries']=JSON.parse(JSON.stringify(aresponse['scenario'] ));                 // details on  scnarioes
  for (let ascenario in simInvDsets['scenarioSpecs']['entries']) {
     nScenario++;
     let dateList=[];
     for (let adate in simInvDsets['scenarioSpecs']['entries'][ascenario]) dateList.push(adate);
     dateList.sort(mySortNumeric);
     simInvDsets['scenarioList'][ascenario]=dateList;
  }

  simInvDsets['scenarioSpecs']['nScenario']=nScenario;
  let fuse=jQuery.trim(aresponse['settings']['scenarioUse']) ;
  simInvDsets['scenarioSpecs']['chosen']=fuse ;

//  a scenario is selected  ?

  $('#scenarioTableButton_chosen').html();
  if (fuse!='') {
     if (simInvDsets['scenarioSpecs']['entries'].hasOwnProperty(fuse)) {
        $('#scenarioTableButton_chosen').html(fuse);
        $('#scenarioTableButton_chosen').attr('title','Using this scenario');
        simInvParams['scenarioUse']=fuse;  // could happen if selected as current, but at a later time was deleted
     } else {
         simInvParams['scenarioUse']='';  // could happen if selected as current, but at a later time was deleted
     }
  } else {
        simInvParams['scenarioUse']='';
        $('#scenarioTableButton_chosen').html('&hellip;');
        $('#scenarioTableButton_chosen').attr('title','No scenario chosen');
        simInvParams['scenarioUse']='';  // could happen if selected as current, but at a later time was deleted
  }
}
