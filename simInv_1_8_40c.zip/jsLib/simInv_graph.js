// graphic display of Display (summary) variables


//==================
// graphical view of Display data  -- show/hide the window
function showPortfolioValuesGraph(athis,ido) {
  let ison,ethis;

  let useVars={'totPortfolioValue':'totValue',
              'nAsset':'#assets',
              'cashAsset':'Cash',
              'totAssetSale':'grossAsset',
              'totAssetSaleNet':'netAsset',
              'totYearlyIncome':'incomes',
              'totYearlyAnnuity':'annuities',
              'totYearlyNetRent':'rent',
              'totYearlyRentPos':'+rent',
              'totYearlyRentNeg':'-rent',
              'totYearlyExpense':'expenses',
              'totLoanPayYear':'loanPay' ,
              'totLoanOwed':'loanOwed',
              'totStock':'stocks',
              'totRegular':'bonds',
              'totTaxDeferred':'bondsTaxDef',
              'totProperty':'property' ,
              'totPropertyNet':'propertyNet',
              'totYearlyIncomeAT':'incomesAT',
              'totYearlyAnnuityAT':'annuitiesAT',
              'totYearlyRevenueAT':'revenueAT',
              'totYearlyExpenseAT':'expensesAT',
              'totYearlyNetRentAT':'rentAT',
              'totAssetSaleNetAT':'assetNetAT',
              'totLoanPayYearlyAT':'loanPayAT',
              'totRegularAT':'bondAT',
              'totTaxDeferredAT':'bondsTaxDefAT',
              'totPropertyNetAT':'propertyNetAT',
              'totStockAT':'stockAT',
              'totOneOffsReceived':'oneOffs',
              'totYearlyCashInflow':'cashIn',
              'totYearlyCashOutflow':'cashOut',
              'totYearlyCashFlow':'cashInOut'};

  let useDesc={'totPortfolioValue':'Total portoflio value, after loans and taxes paid. Includes Cash ',
              'nAsset':'# of assets in this portfolio (at this time)',
              'cashAsset':'Value of Cash asset',
              'totAssetSale':'Gross asset value (before loans and taxes)',
              'totAssetSaleNet':'Net value of assets (after loans, before taxes)',
              'totYearlyIncome':'Total yearly income from incomeStreams (pre-tax)',
              'totYearlyAnnuity':'Total yearly income from anniites (pre-tax)',
              'totYearlyNetRent':'Total yearly income from rents=positiveRents - negativeRents (pre-tax))',
              'totYearlyRentPos':'Total yearly income from positive rents ',
              'totYearlyRentNeg':'Total yearly expenses from netative  rents' ,
              'totYearlyExpense':'Total yearly expenses',
              'totLoanPayYear':'Total yearly loan payments (pre-tax)' ,
              'totLoanOwed':'Total amount of loans still owed',
              'totStock':'Value of stocks (pre tax)',
              'totRegular':'Value of regular bonds',
              'totTaxDeferred':'Value of tax-deferred bonds (pre-tax)',
              'totProperty':'Value of property (pre loan payback, pre tax)' ,
              'totPropertyNet':'Value of properties (after loan payback, pre tax)',
              'totYearlyIncomeAT':'Total yearly income from incomeStreams (after-tax)',
              'totYearlyAnnuityAT':'Total yearly income from anniites (after-tax)',
              'totYearlyRevenueAT':'Income+ annuities+rents (after tax)',
              'totYearlyExpenseAT':'Total expenses, including possible tax offsets)',
              'totYearlyNetRentAT':'Total rental income after-tax',
              'totAssetSaleNetAT':'Total net asset sale (after loans, after before taxes)',
              'totLoanPayYearlyAT':'Total yearly loan payments (after tax-offsets included)',
              'totRegularAT':'Regular bonds (after-tax)',
              'totTaxDeferredAT':'Tax deferred bonds (after-tax)',
              'totPropertyNetAT':'Total property (after loan payback, after capital gains tax)',
              'totStockAT':'Total stock (after capital gains tax)',
              'totOneOffsReceived':'One offs recently received' ,
              'totYearlyCashInflow':'TCash inflows (incomes, annuities, +rents)',
              'totYearlyCashOutflow':'Cash outflows (expenses, loan payments, -rents)',
              'totYearlyCashFlow':'Net cash (inflows-outflows)'};


  if (arguments.length>1) {
     ethis=$('#graphDivButton');
     ison=1;    // force off
  } else {
    ethis=wsurvey.argJquery(athis);
    ison=ethis.attr('data-ison');
  }
  let egraph=$('#graphDiv');
  let gHeight=egraph.height();
  let gWidth=egraph.width();

  let eheader=$('#mainDivHeader');
  if (ison==1) {              // is on ... so turn off
      wsurvey.wsShow.hide(egraph,200);
      ethis.attr('data-ison',0);
      wsurvey.wsShow.show(eheader);
      return 1;
}
// else .. show variable selection menu
   wsurvey.wsShow.show(egraph);
   wsurvey.wsShow.hide(eheader);
   ethis.attr('data-ison',1);
 
   let portfolios={};
   let dates=[],datesL={};
   for (let aport in  simInvDsets['showValues_summary1']) {
      if (portfolioLookup['list'][aport]['isInit']==0 || portfolioLookup['list'][aport]['nHistory']==0) continue ;
      if (portfolioLookup['list'][aport]['isHidden']==1) continue ;
      portfolios[aport]=portfolioLookup['list'][aport]['desc'];
      for (let adate in  simInvDsets['showValues_summary1'][aport]) {
           if (!datesL.hasOwnProperty(adate)) {
              dates.push(adate);
              datesL[adate]=1;
           }
       }
   }

   dates.sort(mySortNumeric);

   let plist='Select a portfolio:' ;
   plist+='<ul  style="max-height:7em;overflow:auto"  class="linearMenu17PctHigh" >';
   for (let aport in portfolios) {
       let asay=portfolios[aport];
       plist+='<li><label   title="'+asay+'"  style="font-size:90%"><input  onClick="showPortfolioValuesGraph_chose(this)" style="display:none;opacity:0" type="radio" name="usePort" data-var="'+aport+'">'+aport+'</label>';
   }
   plist+='</ul>';

   let vlist='';
   vlist+='<input type="button" value="All" title="Select all variables" onClick="showPortfolioValuesGraph_allVars(1)"> ';
   vlist+='Select a variable: ';
   vlist+='<span id="selectGraphVar_desc" style="font-style:oblique;color:blue;font-size:90%">... </span>';
   vlist+='<ul   style="max-height:7em;overflow:auto"   id="selectPlotVarList" class="linearMenu17PctHigh">';
   for (let avar in useVars) {
       let asay=useVars[avar];
       vlist+='<li><label  style="font-size:90%">';
       vlist+=' <input onClick="showPortfolioValuesGraph_chose(this)" style="display:none;opacity:0" type="radio"  ';
       vlist+='  data-desc="'+useDesc[avar]+'" name="useVar" data-var="'+avar+'">';
       vlist+=asay+'</label>';

   }
   vlist+='</ul>';

   let stuff='<div style="background-color:#dfdadb;padding:3px">';
   stuff+='Select one (or more) pairs of <tt> portofolio &amp; variable</tt> to plot (select one pair at a time).';
   stuff+=' ... and then ';
   stuff+='<button onClick="showPortfolioValuesGraph_save(0)"  class="cdoButtonRegular" title="Save to a csv">Save</button>  ... or ... ';
   stuff+='<button onClick="showPortfolioValuesGraph_plot(1)" class="cdoButtonRegular"  title="Save to a csv">Plot</button> ';
   stuff+='<span style="float:right;margin-right:2em">';
   
   let didInf=($('#showInflationAdjustedCheck').val()==1) ? 'checked' : ''  ;

   stuff+='<label style="padding:3px 5px;border:1px dotted gray" title="Save (or plot) inflation adjusted values (using current date as base)"> <input  '+didInf+' type="checkbox" id="showPortfolioGraph_infAdj"> &real;eal</label>&nbsp;';
   stuff+='<button onClick="$(\'#ishowPortfolioValuesGraph_options\').toggle()" class="cdoButtonRegular"  title="More options">Options</button></span> ';

   stuff+='<div style="display:none;margin:3px 1em;border:1px dotted gray"  id="ishowPortfolioValuesGraph_options" class="cshowPortfolioValuesGraph_options">';

   stuff+='<input type="button" value="x" onClick="$(\'#ishowPortfolioValuesGraph_options\').hide()"> Options ... ';
   stuff+='<ul class="tighterMenu">';
   stuff+='<li><label title="Display plot line ">Lines: <input type="checkbox" checked  name="sgraph_dlines"></label>  | ';
   stuff+='<label title="Display plot points ">Points: <input type="checkbox" checked  name="sgraph_dpoints"></label> | ';
   stuff+='<label title="Display values">Values: <input type="checkbox"  name="sgraph_dtext"></label> ';

   let oof3=setEntryDate(true);
   if (didInf=='')   {
     stuff+='<li>Title: <input type="text" size="60" name="sGraph_title" value="simInv: plot of selected variable on '+oof3.sayDate+'"> ';
   } else {
     stuff+='<li>Title: <input type="text" size="60" name="sGraph_title" value="simInv: plot of selected variable on '+oof3.sayDate+' (inflation adjusted)"> ';
   }
   stuff+='<li>Y axis title: <input type="text" size="60" name="sGraph_yaxis" value="Values"> ';
   stuff+='<li>      ';
   stuff+='yMin: <input  title="minimum of y axis, blank to use min observeds value" type="text" size="5" name="sgraph_ymin"> |  ';
   stuff+='yMax: <input  title="maximum of y axis, blank to use max observeds value" type="text" size="5" name="sgraph_ymax">  | ';
   stuff+='<label>Display out-of-range y values: <input type="checkbox" checked name="sgraph_outOfRange" > || '
   stuff+='xMin: <input  title="minimum of x axis, blank to use min observeds value" type="text" size="5" name="sgraph_xmin"> |  ';
   stuff+='xMax: <input  title="maximum of x axis, blank to use max observeds value" type="text" size="5" name="sgraph_xmax">  ';
   stuff+='<li>Line colors (as a csv): <input title="a csv of: color names, or #rrggbb coloCodes" type="text" size="50" name="sgraph_colors" value="green,blue,orange,red,brown,cyan">';
   stuff+='<li>Point symbols (as a csv): <input title="a csv of: 1 or 2 letter point codes: such as C T S D X + CP SP and DP. Or N for no point symbols " type="text" size="50" name="sgraph_symbols" value="C,T,S,D,X,+">';
   stuff+='<li>Line specs (as a csv of <tt>height dotted</tt> pairs): <input title="a csv of: space seperated pairs of line height (in px) and dot pattern (0:solid, 10=dash) " type="text" size="40" name="sgraph_lines" value="3 0, 3 0, 3 0, 3 0, 3 0, 3 0">';


   stuff+='</ul>';
   stuff+='</div>';

   stuff+='<form name="selectGraphicPortfolioN" id="selectGraphicMenu" onsubmit="return false;">';
   stuff+='<table border="1" width="98%" cellpadding="5">';
   stuff+='<tr>';
   stuff+='<td valign="top"    width="23%">'+plist+'</td>';
   stuff+='<td valign="top"   width="55%">'+vlist+'</td>';

   stuff+='<td  valign="top" width="22%">';
   stuff+='<span id="selectGraphic_list_count1" title="# of variables to be plotted" style="font-size:80%;font-style:oblique;padding:2px 5px">...</span>';
   stuff+='<button onClick="showPortfolioValuesGraph_pick(this)">Add selected portfolio/attribute</button>';
   stuff+='<ul style="max-height:7em;overflow:auto" id="selectGraphic_list" class="tighterMenu">';
   stuff+='</ul>'
   stuff+='</td>';
   stuff+='</tr>';
   stuff+='</table>';
   stuff+='</form>';

   stuff+='<div id="selectGraphVar_saveBox" class="cviewResults_results" style="display:none">';
   stuff+='<input type="button" value="x" onClick="$(\'#selectGraphVar_saveBox\').hide()"> ';
   stuff+='<b>Selected plotting variables ... </b>';
   stuff+='<input type="button" value="Copy results to clipboard" onclick="simInv_div_Mark(this)"  ';
   stuff+='   data-div="selectGraphVar_saveBoxB" data-gotit="selectGraphVar_saveBoxGotit"> ';
   stuff+='<span  style="display:none" id="selectGraphVar_saveBoxGotit">Plot variables copied to clipboard ...</span> ';

   stuff+='<div id="selectGraphVar_saveBoxB"  >  ';
   stuff+='</div>';

   stuff+='</div>';

   stuff+='<hr size="4"> ';

   stuff+=' <div id="myCanvas_info" style="margin:3px 5px;background-color:#dfdadb"></div>';


  let aheightuse=parseInt(Math.max(200,0.60*gHeight));
  let awidthuse=parseInt(Math.max(400,0.99*gWidth));

   stuff+=' <canvas id="myCanvas" data-height="'+aheightuse+'" data-width="'+awidthuse+'"height="'+aheightuse+'" width="'+awidthuse+'">plot!</canvas> ';
   $('#graphDiv1').html(stuff);

   $('#selectGraphic_list').data('dates',dates);

}
//==========
//select all vars
function showPortfolioValuesGraph_allVars(ifoo) {
   let elist=$('#selectPlotVarList');
   let elis=elist.find('[name="useVar"]');

   for (let ij=0;ij<elis.length;ij++) {
       let eli1=$(elis[ij]);
       eli1.trigger('click');

      showPortfolioValuesGraph_pick(0);;
   }
}

//===========
// highlight choice
function showPortfolioValuesGraph_chose(athis) {
   let ethis=wsurvey.argJquery(athis);
   let eul=ethis.closest('ul');
   let einputs=eul.find('li');
   eli=ethis.closest('li');
   if (eli.hasClass('highlightThisLi')) { // double click
        showPortfolioValuesGraph_pick(0);
        return 1;
   }

   einputs.removeClass('highlightThisLi');
   eli.addClass('highlightThisLi') ;
   let adesc=ethis.attr('data-desc');
   $('#selectGraphVar_desc').html(adesc);

   return 1;
}
//====================
// add portofoli/attribute to plot list
function showPortfolioValuesGraph_pick(athis) {

  let e1=$('#selectGraphicMenu');

  let e1a=e1.find('[name="usePort"]');
  let e1b=e1a.filter(':checked');

  let e2a=e1.find('[name="useVar"]');
  let e2b=e2a.filter(':checked');

  if (e1b.length==0 || e2b.length==0) {
     alert('You must choose a portfolio and a variable! ');
     return 0;
  }

  let aport=e1b.attr('data-var');
  let avar=e2b.attr('data-var');

  let elist=$('#selectGraphic_list');
  let elis=elist.find('li');

  let afoo=aport+'@'+avar;
  let aSayfoo=aport+' / '+avar;

  let egot=elist.find('[data-what="'+afoo+'"]');
  if (egot.length>0) return 0;  // already chosen

  let oink='<li data-var="'+avar+'" data-portfolio="'+aport+'" data-what="'+afoo+'" ><button title="remove this" style="font-size:90%" onClick="showPortfolioValuesGraph_unpick(this)">&#9003;</button> '+aSayfoo;

  $('#selectGraphic_list').append(oink);


  window.setTimeout(function() {
    let elis=elist.find('li');
    let ect=$('#selectGraphic_list_count1');
    ect.html(elis.length);
  },100);  // allow dom to setetle

  return 1;
}


// =============
// remove from plot vars list
function showPortfolioValuesGraph_unpick(athis) {

   let ethis=wsurvey.argJquery(athis);
   let eli=ethis.closest('li');
   eli.remove();
   
  let elist=$('#selectGraphic_list');

  window.setTimeout(function() {
    let elis=elist.find('li');
    let ect=$('#selectGraphic_list_count1');
    ect.html(elis.length);
  },100);  // allow dom to setetle

}


//========================
// save to csv (the plot variable values
function showPortfolioValuesGraph_save(ifoo) {
  
   dateNow=setEntryDate(true).dayCount ;
 
  let ereal=$('#showPortfolioGraph_infAdj');
  let doInfAdj=ereal.prop('checked');

   let elist=$('#selectGraphic_list');
   let adates=elist.data('dates');
   let eli=elist.find('li');
   let ado=[],adoSay=[];
   let dcsv=[];
   for (let ii=0;ii<eli.length;ii++) {
      let e1=$(eli[ii]);
      let avar=e1.attr('data-var');
      let aport=e1.attr('data-portfolio');
      aa=[aport,avar];
      ado.push(aa);
      adoSay.push('"'+aport+'/'+avar+'"');
   }
   dcsv[0]=adoSay.join(',');
   let datas=[];
   let sdata=simInvDsets['showValues_summary1'] ;
   datas[0]=JSON.parse(JSON.stringify(adates));

   for (let jj=0;jj<ado.length;jj++) {
       let aport=ado[jj][0];
       let avar=ado[jj][1];
       let data0=[];
       for (let idd=0;idd<adates.length;idd++) {
          let idate=adates[idd] ;
          let x1='';
          if (sdata.hasOwnProperty(aport)) {
             if (sdata[aport].hasOwnProperty(idate)) {
                 if (sdata[aport][idate].hasOwnProperty(avar)) {
                    x1=sdata[aport][idate][avar];
                    if (doInfAdj) {
                       let acpi= calcInflation(dateNow,idate,1);
                       if (avar!='nassets') x1=x1/acpi[0] ;
                    }
                 }
             }
          }
          data0.push(x1);
       }
       datas[jj+1]=data0;
   }
  if (ifoo==1) return [ado,datas] ;  // used by _plot


   for (let idd=0;idd<adates.length;idd++) {
      let row1=[];
      for (let ivv=0;ivv<datas.length;ivv++) {
         let x1=datas[ivv][idd];
         row1.push(x1);
      }
      let ccc=row1.join(',');
      dcsv[idd+1]=ccc;
   }
   let dcsv2=dcsv.join('\n');


//   alert(dcsv2);
    $('#selectGraphVar_saveBox').show() ;
   $('#selectGraphVar_saveBoxB').html(dcsv2) ;


//   wsurvey.dumpObj(ado,1,'adoadatesdd');
//   showDebug(datas,'datas ',1);
}

//========================
// plot  (the plot variable values
function showPortfolioValuesGraph_plot(ifoo) {
   let dd=showPortfolioValuesGraph_save(1);
   let dstuff=[];
   let dspecs={};
   let dnames=dd[0];
   let dvals=dd[1];

   let dvar=dnames[0];
   let adates=[],adatesOrig=[];
   let maxY=-111111111111,minY=1111111111 ;
   let nvars=dvals.length-1 ;

   for (let jj=0;jj<dvals[0].length;jj++) {
      let dd1=dvals[0][jj];
      adatesOrig[jj]=dd1;
      let oof1=setEntryDate(dd1);
      adates[jj]=oof1.year+(oof1.dayOfYear/367.0);
   }

   for (let j1=1;j1<dvals.length;j1++) {
   for (let jj=0;jj<dvals[j1].length;jj++) {
      let dd1=dvals[j1][jj];
      maxY=Math.max(maxY,dd1);
      minY=Math.min(minY,dd1);
   }
   }

 let colors=['green','blue','orange','red','brown','cyan'];
 let symbols=['C','T','S','D','X','+'];
 let lineHs=[3,3,3,3,3,3];      // 3 pixel thick
 let lineDs=['0','0','0','0','0','0'];  // not dotted

 if (nvars>symbols.length) {  // augment defaults to be sufficient for all vars
     nadd=nvars-symbols.length;
     for (kk=0;kk<nadd;kk++) {
       colors.push('cyan');
       symbols.push('C');
       lineHs.push(3);
       lineDs.push(0);
     }
 }

 let ecanvas=$('#myCanvas');
 let aheight=ecanvas.attr('data-height');
 let awidth=ecanvas.attr('data-width');

// read options menu
 let eoptions=$('#ishowPortfolioValuesGraph_options');

 let doRenders=[];
 let ep1=eoptions.find('[name="sgraph_dlines"]');;
 if  (ep1.prop('checked')) doRenders.push('lines') ;
 let ep2=eoptions.find('[name="sgraph_dpoints"]');;
 if  (ep2.prop('checked')) doRenders.push('points') ;
 let ep3=eoptions.find('[name="sgraph_dtext"]');;
 if  (ep3.prop('checked')) doRenders.push('text') ;

 if (doRenders.length==0) {
    alert('Please choose lines, points, or text (to plot) ');
    return 1;
 }

 let etitle=eoptions.find('[name="sGraph_title"]');
   let otitle=jQuery.trim(etitle.val());
 let eytitle=eoptions.find('[name="sGraph_yaxis"]');
   let oytitle=jQuery.trim(eytitle.val());
 let eymax=eoptions.find('[name="sgraph_ymax"]');
   let ayMax=jQuery.trim(eymax.val());
   if (ayMax=='') ayMax=maxY ;
   ayMax=fixNumberValue(ayMax);
 let eymin=eoptions.find('[name="sgraph_ymin"]');
   let ayMin=jQuery.trim(eymin.val());
   if (ayMin=='') ayMin=minY ;
   ayMin=fixNumberValue(ayMin);
 let eyrange=eoptions.find('[name="sgraph_outOfRange"]');
   let skipYout=(eyrange.prop('checked')) ? 0 : 1;

 let exmax=eoptions.find('[name="sgraph_xmax"]');
   let axMax=jQuery.trim(exmax.val());
 let exmin=eoptions.find('[name="sgraph_xmin"]');
   let axMin=jQuery.trim(exmin.val());

 let ecolors=eoptions.find('[name="sgraph_colors"]');
 let acolors=jQuery.trim(ecolors.val());
 let vcolors=acolors.split(',');
 for (ic1=0;ic1<vcolors.length;ic1++) {
      let ccolor=jQuery.trim(vcolors[ic1]);
      if (ccolor!==''  )  colors[ic1]=ccolor ;
 }

 let esymbols=eoptions.find('[name="sgraph_symbols"]');
 let asymbols=jQuery.trim(esymbols.val());
 let vsymbols=asymbols.split(',');
 for (ic1=0;ic1<vsymbols.length;ic1++) {
      let asymb=jQuery.trim(vsymbols[ic1]);
      if (asymb!==''  )    symbols[ic1]=asymb ;
 }

 let elines=eoptions.find('[name="sgraph_lines"]');
 let aLines=jQuery.trim(elines.val());
 let vLines=aLines.split(',');
 for (ic1=0;ic1<vLines.length;ic1++) {
      let alineX=jQuery.trim(vLines[ic1]);
      if (alineX!==''  ) {
          let oof3=alineX.split(' ');
          if (oof3.length<2) oof3[1]=0;  // the dotted
          let lineH=oof3[0];
          if (lineH=='') lineH=3;
          lineHs[ic1]=parseInt(lineH);
          let lineD=oof3[1];
          if (lineD=='') lineD=0;
          lineDs[ic1]=parseInt(lineD);
      }
 }
// end of options

// used in the key
  let datexts=[],dasymbols=[];
  for (let ij=0;ij<dnames.length;ij++) {
      let aa=dnames[ij][0]+'/'+dnames[ij][1]  ;
      datexts.push(aa);
      let bb={'pt':symbols[ij],'ps':10,'pc':colors[ij]}
      dasymbols.push(bb);
  }

   let key={'show':1,
          'xmargins':{'left':2,'bottom':10,'top':10,'right':5},
          'globalCompositeOperation':'source-over',
          'opacity':0.9,
          'backgroundColor':'#f1f2f3,white,white,#f1f2f3',
          'borderColor':'green',
          'title':'Key',
          'titleFont':'italic 10pt Arial ' ,
          'titleColor':'blue' ,
          'textFont':'8pt Arial',
          'textColor':'',
          'symbolSize':6,
          'rowPad':3,
          'rowLineColor':'gray  ',
          'texts':datexts,
          'symbols':dasymbols
   }

   let chartMargin = {'top':40,'left':115,'bottom':75,'right':150} ;   // could use aheight and awidth
   let wasChartSpecs='',xrange=axMin+','+axMax+',5',yrangeUse=ayMin+','+ayMax+',6';

// a seoperate graph for each portfolio/variable
   for (iz=0;iz<dnames.length;iz++) {
     let idSay=dnames[iz][0]+'/'+dnames[iz][1]  ;
     let dspecs={},dstuff=[];;
     for (let jj=0;jj<dvals[0].length;jj++) {   // create datapoints to be plotted
        let ax=parseFloat(adates[jj]);
        let oof=setEntryDate(adatesOrig[jj]);
        let idSay2=idSay+' '+oof.sayDate;
        let ay=dvals[1+iz][jj];
       let alabel= wsurvey.makeNumberK(ay,1000);
        let tt={'x':ax,'y':ay,'ID':idSay2,'L':alabel}  ;
        dstuff.push(tt);
      }

      dspecs['dataPoints']=dstuff;
      if (iz==0) {                          // do these on first graph
        dspecs['clearAll']=1 ;   // clears if first (so will clear a prior plot)
        dspecs['chartDisplay']=4 ;  // draw enveryghing
        dspecs['title']=otitle;
        dspecs['xLabel']='Year ';
        dspecs['yLabel']=oytitle;
        dspecs['titleFont']='12pt arial';
        dspecs['refLinesY']='0.0 gray dashed ' ;
        dspecs['axisTicFont']='8pt Arial';

      } else  {
        dspecs['clearAll']=0 ;   // do not clear
        dspecs['chartDisplay']=1 ;  // only display the points
      }

      dspecs['ignoreBad']=1;
      dspecs['lineColor']=colors[iz];
      dspecs['lineWidth']=lineHs[iz];
      dspecs['lineDotted']=lineDs[iz];
      dspecs['dataPointType']=symbols[iz];
      dspecs['dataPointSize']=lineHs[iz]+3;
      dspecs['dataPointColor']=colors[iz] ;
      dspecs['yRange']=yrangeUse;
      dspecs['yPrec']='%8.1f'   ;
      dspecs['xPrec']='%6.2f'   ;
      dspecs['xRange']=xrange ;
      dspecs['skipYout']=skipYout;
      dspecs['chartMargin']=chartMargin ;
      dspecs['clickFunc']=myClickFunction  ;

      dspecs['renderTypes']=doRenders;
      dspecs['chartSpecs']=wasChartSpecs;

      let arf=wsurvey.canvasChart.render('myCanvas', dspecs);
      wasChartSpecs=arf[1];     // used in next graph draw (to keep "mouse click readable" info for prior portfolio/variable plots)
  }


// key  -- write after all plots are drawn
   let dspecs3={};
    dspecs3['dataPoints']={};
    dspecs3['chartDisplay']=-2 ;
    dspecs3['clearAll']=0;
    dspecs3['chartMargin']=chartMargin ;
    dspecs3['renderTypes']=[wsurvey.canvasChart.renderType.lines, wsurvey.canvasChart.renderType.points];
    dspecs3['chartKey']=key;
    dspecs3['chartSpecs']=wasChartSpecs;
    let arf3=wsurvey.canvasChart.render('myCanvas', dspecs3);



}


function myClickFunction(evt,locData) {
  if (evt.type!='mouseup') return 1;
  xyInfo=wsurvey.canvasChart.renderMouseXY(evt)   ;
  let awhat=xyInfo['shape']['obsInfo']['ID'];
  let ax =xyInfo['value']['x']  ;
  let ayear=parseInt(ax);
  let aday=parseInt( (ax-ayear)*367);
   let aval=xyInfo['value']['y']
  let avalSay=parseFloat(aval.toFixed(0));
  $('#myCanvas_info').html(awhat+ ' entry (<tt> for ~  day '+aday+' of '+ayear+' </tt>) =  '+wsurvey.addComma(avalSay) );
}
