// indexDb support for siminv

var howSayList=['','','standAlone','online assigned local','onLine chose local','onLine chose server' ]; // used in initUserData_indexDb a status variable (jsut for info purposes)

function simInv_indexDbAvailable(type) {
  let storage;
  if (!window.indexedDB) return false;
  return true ;
}


//================
// look for simInv_users  database. If not existent, create with several objectStores
// the callback is called with  callback(qStatus,message)
// qstatuss sture or false: false: some kind of failure, true: ready to use.
//  if true, message is:
//      1 : normal start (simInv_users already exists
//      2 : initialization (should happen on first logon) -- simInv_users was created
//  if false, message is an error string

 function checkDatabaseExists_indexDb(callback  ) {

  let myDbName='simInv_users';
  const DBOpenRequest = window.indexedDB.open(myDbName,1);
  let astatus=0;

//  event handlers
  DBOpenRequest.onerror = (event) => {
    DBOpenRequest.close();
    let amess= 'Unable to open indexDb simInv_users: '+DBOpenRequest.error;
    callback(false,amess);
  };    // on DBOpenRequest error

  DBOpenRequest.onsuccess = (event) => {               // this fires AFTER   DBOpenRequest.onupgradeneeded

    if (astatus==0)  {                  // the value set to at top of this function -- if not changed, nothing was done hence database exists
        callback(true,1) ;
    } else if (astatus==2) {              // 2: simInv_userList database initialized
       callback(true,2);
    } else {          // should never get here ... but if so an error
       callback(false,'unknown error onsuccess');
    }
  }

// initialization of database ... several objectStores  -- only need on first logon (on this browser/machine)
  DBOpenRequest.onupgradeneeded = (event) => {
     let db2= event.target.result;
     astatus=2;
     db2.onerror = (event) => {
         astatus=3;
     }
     const objectStore = db2.createObjectStore('users', { keyPath: 'name' });
     objectStore.createIndex('initDate', 'initDate', { unique: false });
     objectStore.createIndex('updateDate', 'updateDate', { unique: false });

     const objectStore1 = db2.createObjectStore('userList', { keyPath: 'name' });
     objectStore1.createIndex('initDate', 'initDate', { unique: false });
     objectStore1.createIndex('updateDate', 'initDate', { unique: false });
     objectStore1.createIndex('how', 'how', { unique: false });
     objectStore1.createIndex('nLogons', 'nLogons', { unique: false });

     const objectStore2 = db2.createObjectStore('autoArchive', { keyPath: 'name' });
     objectStore2.createIndex('initDate', 'initDate', { unique: false });

     const objectStore3 = db2.createObjectStore('manualArchive', { keyPath: 'name' });
     objectStore3.createIndex('initDate', 'initDate', { unique: false });

//     const objectStore4 = db2.createObjectStore('removedArchive', { keyPath: 'name' });
//     objectStore4.createIndex('initDate', 'initDate', { unique: false });

  };      // onupgradeneeded

}


//============================
// check if user exists in local storage database
// callback (status,message)
// status:0 - failure
//      1 : user exists in database
//      2: user does NOT exist

function checkUserExists_indexDb(auser,callback) {
  let storeName='users';
  let myDbName='simInv_users';
  let astatus=0 ;  // 0=error,1=exists,2=does not exit
  let agot='unable to look for: '+auser ;

  const DBOpenRequest = window.indexedDB.open(myDbName,1);
  DBOpenRequest.onsuccess = (event) => {
     let db = DBOpenRequest.result;
     const transaction = db.transaction( storeName  , 'readonly');

     transaction.oncomplete = () => {                // :::::::::::::::  this is what calls the callback !!! ::::::::::::  /
        db.close();
        callback(astatus,agot);
     };

     transaction.onerror = () => {
        agot='Unable to look for entry for '+auser+' : ' +transaction.error ;
        callback(0,agot);
     }

     let objectStore=transaction.objectStore(storeName) ;
     let findUser = objectStore.get(auser);       // check if user record exists
     findUser.onsuccess = function (e) {
         if (e.target.result=== null || typeof(e.target.result)=='undefined') {
                agot='No entry for: '+auser;
                astatus=2;
                return ;
         } else {       // got it, so delete
            agot='Entry exists for: '+auser;
            astatus=1;
         }
      }      //  findUser.onsuccess
  }   // DBOpenRequest.onsuccess
}

// ========================
// initialize  data for a  simInv_user --
//   checkUserExists_indexDb should be called beforehand to insure its a new record
// but check just in case
// ahow: 2: standalone, 3 online assigned local, 4 online chose local, 5 online chose server
//    rdata: initialization data. Or false (if ahow=5)
// return status, stuff
//   status =0 : stuff is an error message
//          1 : stuff is  initialized   data  object


function initUserData_indexDb(auser,callback,ahow,saveData) {

  let storeNames=['users','userList'];
  let storeName='users';
  let storeNameList='userList';

  let nowTime=wsurvey.get_currentTime(0);
  let astatus=0, amess='';

  let myDbName='simInv_users';
  const DBOpenRequest = window.indexedDB.open(myDbName,1);

//  event handlers
  DBOpenRequest.onerror = (event) => {
    db.close();
    let amess= 'Unable to open indexDb simInv_users: '+ DBOpenRequest.error ;
    callback(0,amess,ahow);
  };    // on DBOpenRequest error

  DBOpenRequest.onsuccess = (event) => {
     let astatus=0;
     let db = DBOpenRequest.result;
     const transaction = db.transaction( storeNames , 'readwrite');

     transaction.oncomplete = () => {                // :::::::::::::::  this is what calls the callback !!! ::::::::::::  /
       db.close();
       callback(astatus,rdata,ahow);
     };

     transaction.onerror = () => {    // set astatus, and exit (oncomplete will then callback
        db.close();
        callback(0,'Unable to open indexDb store: '+transaction.error,ahow) ;
     };

    transaction.onabort = () => {    // a transaction.abort() block wil set amess
        db.close();
        callback(0,amess,ahow) ;
     };


     let objectStore=transaction.objectStore(storeName) ;     // first write to users
     let findUser = objectStore.get(auser);       // check if user record exists

     findUser.onsuccess = function (e) {
         if (e.target.result!== null  && typeof(e.target.result)!='undefined') {   // got a user... can not initialize!
             amess='User already exists';
             transaction.abort();
         }   // if no user, add record
         rdata={'name':auser};
         rdata['initDate']=nowTime;
         rdata['updateDate']=nowTime;
         rdata['dinfo']=saveData ;
         rdata['how']=ahow;             // 5 is special (chose server storage)
         rdata['howSay']=howSayList[ahow];              // howSayList is global set at top of this file

         const writeEm = objectStore.add(rdata);

         writeEm.onsuccess = (event) => {         // now write to userList

              let objectStore2=transaction.objectStore(storeNameList) ;
              let ruserData={'name':auser};
              let tt2= (ahow==5) ? false : nowTime;
              ruserData['initDate']=tt2;
              ruserData['updateDate']=nowTime;
              ruserData['how']=ahow;
              ruserData['howSay']=howSayList[ahow];
              ruserData['nLogons']=0 ;
              const writeEm2 = objectStore2.add(ruserData);

              writeEm2.onerror = (event) => {         // now write to userList
                  amess='Unable to save record to userList: '+writeEm2.error  ;
                  transaction.abort();
               }
              writeEm2.onsuccess = (event) => {         // now write to userList
                  astatus=1;                       // success! users and userlist have recorded added for auser
               }

         }     // writeEm.onsuccess

         writeEm.onerror = (event) => {         // now write to userList
                  amess='Unable to save record to users:  '+writeEm.error;
                  transaction.abort();
         }

      }   //  findUser.onsuccess

    }   //   DBOpenRequest.onsuccess


}      // initUserData_indexDb

//=============================
// get data of existing user -- note this is called after checkUserExists_indexDb, so assumption is the user exists
// so if failure, its an error    -- astatus=0 and agot is error message
function getUserData_indexDb(auser,callback ) {
  let storeName='users';
  let myDbName='simInv_users';
  let agot='unable to get data: '+auser ;
  let astatus=0;

  const DBOpenRequest = window.indexedDB.open(myDbName,1);
  DBOpenRequest.onsuccess = (event) => {
     let db = DBOpenRequest.result;
     const transaction = db.transaction( storeName   , 'readonly');

     transaction.oncomplete = () => {                // :::::::::::::::  this is what calls the callback !!! ::::::::::::  

        db.close();
        callback(astatus,agot);
     };

     transaction.onerror = () => {
        agot='Unable to read  entry for '+auser+' : '+ transaction.error;
        callback(0,agot );
     }

     let objectStore=transaction.objectStore(storeName) ;
     let getUser = objectStore.get(auser);       // check if user record exists
     getUser.onsuccess = function (e) {
         if (e.target.result=== null || typeof(e.target.result)=='undefined') {
                agot='No entry for: '+auser;
                astatus=0;

         } else {       //  got a user, so return value for this user
              astatus=1;
              agot=getUser.result;
         }   // if non null on findUser
      }      //  findUser.onsuccess =
  }   // DBOpenRequest.onsuccess
}    // getUserData_indexDb_exists function


//==============================
// add (or change) data of a simInv user
//  auser: user name (initialized in local storage)
//   acallback: function to call after indexDb transaction complete.
//   stuff is an array of seperate things to save (such as assets, assethistory)
//   If any of these seperate "save" fails, NONE are retained
//    each row is object with ['avar','aval']
//  nowTime: js time. If true, compute it
// okmess : message to use in acallback if success. Short default used if not specified
//
// avar MUST be one of the fields in the user-data:
// acallback(astatus,amess)
//   astatus=0 error, amess is error message
//   atatus=1 okay, amess is value of okmess (or a short success message if okmess not specified)
//

function addUserData_indexDb(auser,acallback,stuff,nowTime,okmess,arg1) {

  if (!jQuery.isArray(stuff)) {
     alert( 'addUserData_indexDb: stuff is not an array ('+auser+')');
     let addDataError=notArray/3551;          // force fatal error
  }

   if (arguments.length<4 || nowTime===true) nowTime=wsurvey.get_currentTime(0);
   if (arguments.length<5) okmess='Data saved';
   if (arguments.length<6) arg1=false  ;

  let storeNames=['users','userList'];
  let storeName='users';
  let storeNameList='userList';
  let myDbName='simInv_users';

  let amess='unable to add data: '+auser ;  // will be overwitten with more specific error message
  let astatus=0;                       // assume failure

  const DBOpenRequest = window.indexedDB.open(myDbName,1);
  DBOpenRequest.onsuccess = (event) => {
     let db = DBOpenRequest.result;
     const transaction = db.transaction( storeNames   , 'readwrite');

     transaction.oncomplete = () => {                // :::::::::::::::  this is what hopefully calls the callback !!! ::::::::::::  /
        db.close();
        let omess= (astatus==1) ? okmess : 'save status unknown ';  // astatus should always be 1... but wth
        acallback(astatus,omess,arg1);
     };

     transaction.onerror = () => {
        amess='Unable to add data for '+auser+' : '+transaction.error ;
        acallback(0,amess,arg1 );
     }

     transaction.onabort = () => {      // .abort() used ... amess will be specified before
        amess='(for '+auser+'): '+amess;
        acallback(0,amess,arg1 );
     }

     let objectStore=transaction.objectStore(storeName) ;
     let getUser = objectStore.get(auser);       // add to this record...
     getUser.onsuccess = function (e) {
          if (e.target.result=== null || typeof(e.target.result)=='undefined') {
                amess='No entry in users (data) ';
                transaction.abort();
         }
         let zdata=getUser.result;
         if (!zdata.hasOwnProperty('dinfo')) {
              amess='Can not save: no dinfo property specified' ;
              transaction.abort();      // any error means NONE of the info in stuff is saved
         }
// for each row of stuff
         for (let iss=0;iss<stuff.length;iss++) {
             let avar=stuff[iss]['avar'];
             let  aval=stuff[iss]['aval'];
             if (!zdata['dinfo'].hasOwnProperty(avar)) {
                 amess='Can not save: '+avar+': not a supported variable' ;
                 showDebug(zdata,amess,1);
                 transaction.abort();
             }
             zdata['dinfo'][avar]=aval;
         }
         zdata['updateDate']=nowTime;

         const addTheData = objectStore.put(zdata);
         addTheData.onerror = (event) => {
               amess='Unable to save: '+addTheData.error ;
               transaction.abort();
         }
         addTheData.onsuccess= (event) => {     // now change updateDate in userLIst
             let objectStore2=transaction.objectStore(storeNameList) ;
             let getUser2 = objectStore2.get(auser);       // add to this record...
             getUser2.onsuccess = function (e) {
                if (e.target.result=== null || typeof(e.target.result)=='undefined') {
                  amess='No userList entry';
                  transaction.abort();
               }
               let zdata2=getUser2.result;
               zdata2['updateDate']=nowTime;
               const addTheData2 = objectStore2.put(zdata);
               addTheData2.onerror = (event) => {
                   amess='Unable to update userlist: '+addTheData2.error;
                   transaction.abort();
               }
               addTheData2.onsuccess = (event) => {
                   astatus=1;                          // only place where astatus=1
                   amess='Data added for '+auser ;
               }
             }  //  getUser2.onsuccess
         }      // addthedata.on success

      }   // getuser.onsuccess

  }   // DBOpenRequest.onsuccess
}


//============
// get userList
function getUserList_indexDb(callback) {
  let storeName='userList';
  let myDbName='simInv_users';
  let agot ;
  const DBOpenRequest = window.indexedDB.open(myDbName,1);
  DBOpenRequest.onsuccess = (event) => {
     let db = DBOpenRequest.result;
     const transaction = db.transaction( storeName  , 'readwrite');

     transaction.oncomplete = () => {                // :::::::::::::::  this is what calls the callback !!! ::::::::::::
        db.close();
        callback(agot);
     };

     transaction.onerror = () => {
        agot=false;;
     }

     let objectStore=transaction.objectStore(storeName) ;
     const getAllRequest = objectStore.getAll();
     getAllRequest.onsuccess = () => {
        agot=getAllRequest.result ;
     }
     getAllRequest.onerror = () => {
        agot=false;
     }
  }   // DBOpenRequest.onsuccess
}

//===================
// remove auser from users and userList
function  removeUser_indexDb(auser,callback,isonline) {
   if (arguments.length<3) isonline=0;
  let storeNames=['users','userList'];
  let storeName='users';
  let storeNameList='userList';
  let myDbName='simInv_users';
  let amess='unable to delete: '+auser ;

  const DBOpenRequest = window.indexedDB.open(myDbName,1);
  DBOpenRequest.onsuccess = (event) => {
     let db = DBOpenRequest.result;
     const transaction = db.transaction( storeNames  , 'readwrite');

     transaction.oncomplete = () => {                // :::::::::::::::  this is what calls the callback !!! ::::::::::::  /
        db.close();
        callback(amess);
     };

     transaction.onerror = () => {     // generic error
        amess='Unable to delete entry for '+auser+' : '+transaction.error;
        callback(amess);
     }

     transaction.onabort = () => {     // transaction.abort error
        callback(amess);
     }

     let objectStore=transaction.objectStore(storeName) ;
     let findUser = objectStore.get(auser);       // check if user record exists
     findUser.onerror = function (e) {
           amess='Uable to find entry for: '+auser;
           transaction.abort();
     }

     findUser.onsuccess = function (e) {

         if (e.target.result=== null || typeof(e.target.result)=='undefined') {
                amess='No entry for: '+auser;
                transaction.abort();
         }
         const delUser = objectStore.delete(auser) ;
         delUser.onsuccess = () => {
            let objectStore2=transaction.objectStore(storeNameList) ;
            const delUser2 = objectStore2.delete(auser) ;
            delUser2.onsuccess = () => {
                  amess='Entry deleted: '+auser;
             }   // delUser2.onsucess
            delUser2.onerror = () => {
               amess='Unable to delete entry from ('+auser+') userList: entry NOT deleted ' ;
               transaction.abort();
            }   // delUser2.onsucess
         }   // delUser.onsuccess
         delUser.onerror = () => {
                 amess='Unable to delete entry from ('+auser+') users: entry NOT deleted ' ;
                 transaction.abort();
         }

      }      //  findUser.onsuccess =
  }   // DBOpenRequest.onsuccess
}    // removeUser_indexDb


// :::::::::::::::::::::; archive functions :::::::::::::::::
///======================
// get auto and manual archive status
function  archiveInfo_indexDb(auser,callback) {
  let myDbName='simInv_users';
   let storeNames=['autoArchive','manualArchive'];
   let storeNameA='autoArchive';
   let storeNameM='manualArchive';
   let amess='Unable to read archive info,',astatus=0;
    let manualStuff=false;
    let autoStuff=false;

  const DBOpenRequest = window.indexedDB.open(myDbName,1);
  DBOpenRequest.onsuccess = (event) => {
     let db = DBOpenRequest.result;
     const transaction = db.transaction( storeNames  , 'readonly');

     transaction.oncomplete = () => {                // :::::::::::::::  this is what calls the callback !!! ::::::::::::  /
        db.close();
        let ares={'manual':manualStuff,'auto':autoStuff}; // these can be false (to flag no archive info available)
        callback(1,ares);
     };

     transaction.onerror = () => {
        amess='Unable to read archive info for '+auser+' : '+ transaction.error;
        callback(0,amess );
     }
    transaction.onabort = () => {
        db.close();
        callback(0,amess) ;
     };

// get manual archive info
     let objectStoreM=transaction.objectStore(storeNameM) ;
     let getManual = objectStoreM.get(auser);       // check if user record exists
        getManual.onerror = (event) => {
               amess='Archiving information not enabled in local storage: '+getManual.error ;
               transaction.abort();
        }

        getManual.onsuccess = function (e) {
           if (e.target.result=== null || typeof(e.target.result)=='undefined') {
                manualStuff=false;
           } else {       //  got a user, so return value for this user
              manualStuff=getManual.result;;
           }

// get auto archive info
           let objectStoreA=transaction.objectStore(storeNameA) ;
           let getAuto = objectStoreA.get(auser);       // check if user record exists
           getAuto.onsuccess = function (e) {
              if (e.target.result=== null || typeof(e.target.result)=='undefined') {
                  autoStuff=false;
              } else {
                autoStuff=getAuto.result;
              }
           }   // getAuto.onsuccess

        }      // getManual.onsuccess



   }   // DBOpenRequest.onsuccess

}    // archiveInfo_indexDb function


///======================
// copy current to auto or manual archive auto
function  makeArchive_indexDb(auser,awhich,callback) {

  let myDbName='simInv_users';
  let storeName='users',storeNameA,storeNames;
  if (awhich=='auto') {
       storeNames=['autoArchive','users'];
     storeNameA='autoArchive' ;
  } else {
       storeNames=['manualArchive','users'];
     storeNameA='manualArchive'   ;
  }

  let nowTime=wsurvey.get_currentTime(0);

  let amess='unable to get data: '+auser ;
  let astatus=0;

  const DBOpenRequest = window.indexedDB.open(myDbName,1);

  DBOpenRequest.onsuccess = (event) => {
     let db = DBOpenRequest.result;
     const transaction = db.transaction( storeNames   , 'readwrite');

     transaction.oncomplete = () => {                // :::::::::::::::  this is what calls the callback !!! ::::::::::::  /
        db.close();
        callback(astatus,amess,awhich);
     };

     transaction.onabort = () => {    // a transaction.abort() block wil set amess
        db.close();
        callback(astatus,amess,awhich) ;
     };

     transaction.onerror = () => {
        amess='Error saving '+awhich+' archive, for '+auser+' : '+ transaction.error;
        callback(astatus,amess,awhich );
     }

     let objectStore=transaction.objectStore(storeName) ;
     let getUser = objectStore.get(auser);       // check if user record exists
     getUser.onsuccess = function (e) {
         if (e.target.result=== null || typeof(e.target.result)=='undefined') {
                amess='No entry for: '+auser;
                astatus=0;
                transaction.abort();
         }
         let zdata=getUser.result;     // the current simInv data for this user
         zdata['archiveDate']=nowTime;

         let objectStore2=transaction.objectStore(storeNameA) ;

         const addTheData = objectStore2.put(zdata);
         addTheData.onsuccess= (event) => {     // now change updateDate in userLIst
                   astatus=1;                          // only place where astatus=1
                   amess=awhich+' archive created for '+auser ;
         }
         addTheData.onerror = (event) => {
                   amess='Unable to update '+awhich+' archive: '+addTheData.error;
                   transaction.abort();
         }
     }       // getuser on success

  }   // DBOpenRequest.onsuccess
}    // makeArchive_indexDb function



//================================
///======================
// copy auto or manual archive to current
function  restoreArchive_indexDb(auser,awhich,callback) {

  let myDbName='simInv_users';
  let storeName='users',storeNameA,storeNames;
  if (awhich=='auto') {
      storeNames=['autoArchive','users'];
      storeNameA='autoArchive' ;
  } else {
      storeNames=['manualArchive','users'];
      storeNameA='manualArchive'   ;
  }

  let nowTime=wsurvey.get_currentTime(0);

  let amess='unable to get data: '+auser ;
  let astatus=0;
  let archiveDate=false;

  const DBOpenRequest = window.indexedDB.open(myDbName,1);

  DBOpenRequest.onsuccess = (event) => {
     let db = DBOpenRequest.result;
     const transaction = db.transaction( storeNames   , 'readwrite');

     transaction.oncomplete = () => {                // :::::::::::::::  this is what calls the callback !!! ::::::::::::  /
        db.close();
        callback(astatus,amess,awhich,archiveDate);
     };

     transaction.onabort = () => {    // a transaction.abort() block wil set amess
        db.close();
        callback(astatus,amess,awhich,archiveDate) ;
     };

     transaction.onerror = () => {
        amess='Error restoring '+awhich+' archive, for '+auser+' : '+ transaction.error;
        callback(astatus,amess,awhich,archiveDate );
     }

     let objectStoreA=transaction.objectStore(storeNameA) ;
     let getUser = objectStoreA.get(auser);       // check if user record exists in archive
     getUser.onsuccess = function (e) {
         if (e.target.result=== null || typeof(e.target.result)=='undefined') {
                amess='No '+awhich+' archive entry for: '+auser;
                astatus=0;
                transaction.abort();
         }

         let zdataA=getUser.result;     // the awhich archive simInv data for this user
         archiveDate=zdataA['archiveDate'];
         let objectStoreC=transaction.objectStore(storeName) ;

         const addTheDataC = objectStoreC.put(zdataA);
         addTheDataC.onsuccess= (event) => {     // now change updateDate in userLIst
                   astatus=1;                          // only place where astatus=1
                   amess=awhich+' archive restored for '+auser ;
         }
         addTheDataC.onerror = (event) => {
                   amess='Unable to restore from simInv internal '+awhich+' archive: '+addTheData.error;
                   transaction.abort();
         }
     }       // getuser on success

  }   // DBOpenRequest.onsuccess

}    // restoreArchive_indexDb function



