// global parameters used by simInv.
// These are the defaults... many of which can be personallized

// Note: if this file becomes damaged, you can restore it from simInv/other/index_html.original --
//        copy simInv/other/simInv_params_js.original to simInv/simInv_params.js

function simInv_initParams(ifoo) {

 try {

// users can override these using the settings menu   ::::

   let taxRate=0.20  ;            // tax rate on revenuds (interest or dividends, or withdrawals from tax deferred, rents from properties, income and annuities, expenses)
   let capGainsRate=0.10  ;       // capital gains taxr ate  (sale of stocks and properties)

   let firstYearUse=2020 ;        // when to start calculations of portfolio values (first day of this year)
   let lastYearUse=2035  ;          // 0 means "use end of this year". Otherwise, end of

   let cashInterest=0.01 ;         // interested earned for the Cash asset (if Cash gt 0)
   let cashPenalty=0.06 ;          // interest charged for the Cash asset (if Cash lt 0)

   let encryptionKeyHint=''        // optional  hint to remember encryption key

   let scenarioUse='';             //  name of futurs (state-of-the-world) to use, '' or 0 means "do not apply multipliers"

   let warningLevel=0;             // 0=show warnings, 1=suppress most of the warnings
   let showValuesInterp=1 ;           // if 1, use interpolation to compute display values for calendar entries. 0 to calculate fully (more time consjming)

   let doQuickDisplay=0  ;    // 0=do NOT use localStorage to cache Display results, 1=Do use, 'fast': use aggressively

   let showTransactions=1 ;        // start with this display of a portfolios entry: 0=small buttons, 1=large buttons, 2=large buttons and table, 3=small buttons and table, 4=table
   let budgetRemainPct=0.005  ;    // if remaining Abs(cash)  gt this fraction of budget (or netValue), issue a "confirm" box (and other warnings)
   let sameAssetFamilyOk=0 ;       // 0 do not allow multiple assets from the same family in a portfolio, 1 do allow (asset name = family.variant)

   let defaultBudget=100000;       // default budget to use when creating initial portfolio entry

   let inflationAverageTimespan=5 ; // number of years to use to calculate "after last entry" inflation

   let headerSep=' : ' ;            // character to use in header lines of CSV export files. Spaces are NOT trimmed! Careful about using  : -- some spreadsheets treat it as control code

// ::::::::: Users can NOT override these in their settings  ::::

  let assetDetails_farFuture=2100 ;   // a year in the future used to "linear interpolate" asset values AFTER the date of the last entry inan  asset`s history (using the same attribues as the last entry)

   let  theMinYear= 1950  ;             // ask user if year entered is less than this (when specifying assets,etc)
   let  theMaxYear=2100 ;               // ask query if year entered is greater than this

   let budgetAllocationTest =3.0        // how close  (in $) is close enough for "entire budget allocated to assets " message to be displayed (rather than a warning message)

   let settingsHeaderCanHide =1;        // if 1, clicking settings button (on top row) toggles view of the `important` settings. If 0,  `important`  settings are always displayed

   let  welcomeMessage='Welcome to simInv' ;  // this is overwritten by afterLogon()


// :::::::::  .... do NOT change below here ....  ::::::::::::::::::::::::::

// simInvGlobals and simInvParams are globals (initialized in index.html) that are used in simInv functions.

   simInvParams['taxRate']=taxRate  ;
   simInvParams['capGainsRate']=capGainsRate;
   simInvParams['firstYearUse']=firstYearUse ;
   simInvParams['lastYearUse']=lastYearUse
   simInvParams['cashInterest']=cashInterest ;
   simInvParams['cashPenalty'] =cashPenalty ;
   simInvParams['encryptionKeyHint']=encryptionKeyHint  ;
   simInvParams['scenarioUse']=scenarioUse;
   simInvParams['warningLevel']=warningLevel;
   simInvParams['showValuesInterp'] =showValuesInterp ;
   simInvParams['showTransactions']=showTransactions ;
   simInvParams['budgetRemainPct']=budgetRemainPct  ;
   simInvParams['sameAssetFamilyOk']=sameAssetFamilyOk ;
   simInvParams['defaultBudget']=defaultBudget;
   simInvParams['inflationAverageTimespan']=inflationAverageTimespan ;
   simInvParams['headerSep']=headerSep ;

// these are NOT user changeable

//additionsFromCash: 1 is recommendd. 0: additions to bonds do NOT come from Cash, 1: come from Cash  (8 Dec 12 : not tested when =0 -- change at your own risk)
   simInvParams['additionsFromCash']=1 ;

   simInvParams['showPortoflio_splashDelay']=500 ;        // time (milliseconds) that "calculating portoflio values" display to fadeout (once calculations are done)

// some other parametes ...
  simInvGlobals['assetDetails_farFuture']=assetDetails_farFuture ;   // a year in the future used to "linear interpolate" asset values AFTER the date of the last entry inan  asset`s history (using the same attribues as the last entry)
  simInvGlobals['theMinYear']= theMinYear  ;             // ask user if year entered is less than this (when specifying assets,etc)
  simInvGlobals['theMaxYear']=theMaxYear ;               // ask query if year entered is greater than this
  simInvGlobals['budgetAllocationTest'] =budgetAllocationTest        // how close  (in $) is close enough for "entire budget allocated to assets " message to be displayed (rather than a warning message)
  simInvGlobals['settingsHeaderCanHide'] =settingsHeaderCanHide;        // if 1, clicking settings button (on top row) toggles view of the `important` settings. If 0,  `important`  settings are always displayed
  simInvGlobals['welcomeMessage']=welcomeMessage  ;  // this is overwritten by afterLogon()


 simInvGlobals['checkStatusWait']=15;   // max # of seconds to wait before checking logon status: should be at least 5 seconds
                          // if 0, do NOT run the startup failure test. However, if set to 0, auto archiving will NOT occur
                          //  After this seconds: if simInv startup doesn't complete (afterLogon_build() is done)
                          //  simIv checks if logon & proccessing was successful. If not, several choices are offered

 simInvGlobals['enableAutoArchive'] = 1   ;  // if 1, auto archiving is enabled -- on each logon, if no error ... then monitorStartup instructs server to save data as "last good data"
                            //  if 0 (or not 1), do NOT autoarchive. Note that if checkStatusWait=0, enableAutoArchive is ignored (auto archiving will not be done)
                            //  if 2 : auto archive disabled, but manual archive allowed

 simInvGlobals['versionNumber'] ='1.8.40' ;

 } catch(ex) {
           let rrmess=ex.name+': '+ex.message ;
           if (ex.hasOwnProperty('lineNumber')) rrmess+=' (@lineNumber '+ex.lineNumber+')';
           if (ex.hasOwnProperty('fileName')) rrmess+=' (in file '+ex.fileName +')';
      return rrmess;
 }

  return true;
}

