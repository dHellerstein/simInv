<?php

// ============
// php for simInv: publicAssets

session_start() ;
ob_start();

$curDir1=getcwd();             // will be xxx/yyy/simInv/phpLib ... strip out /phpLib
$len1=strlen($curDir1);
$len2=$len1-7;
$curDir=substr($curDir1,0,$len2);

$todo=$_REQUEST['todo'];

 if ($todo=='savePublicJs') {  // save the publicAssets array (for later use)

     $vuse=$_REQUEST['data'];
      $nsave=$_REQUEST['nsave'];
     $curdate=date("Y-m-d H:i:s" );
     $bfile.="//simInv publicAssets ($curdate) \n\n ";
     $bfile.="function publicAssets_current(ido) { \n ";
     $bfile.="let useString='$vuse' ; \n ";
     $bfile.="return useString ; \n ";
     $bfile.="}\n\n";


    $daFile=$curDir.'/publicAssets/assetsUse.js';
    $ii=file_put_contents($daFile,$bfile);
    $rets=[];
    if ($ii===false) {
        $rets['message']= "Unable to save to $dafile ";
    } else {
        $amess= "$nsave publicAssets saved to $daFile ";
        $rets['message']=$amess;
    }

     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests ;
     exit ;
  }

// otherwise ..............

// :::  save / retreive publicAsset .txt files

 $daDir=$curDir.'/publicAssets/inputData';
 $aget=$daDir.'/*.txt';
 $ff=glob($aget);

 $bnames=[];
 $rets=[];
 $messages=[];
 $errMessages=[];
 $ados=['name'=>false,'desc'=>'','freq'=>false,'type'=>false,'desclong'=>''];
 foreach ($ff as $ith=>$fullName) {
     $bname=basename($fullName,'.txt');
     $aah=file_get_contents($fullName);
     $didLine=false;
      if ($aah===false) {
         $errMessages[]="publicAttributes error: Unable to retrieve $bname   ";
         $nerrs++;
      } else {
          $blines=explode("\n",$aah);
          for  ($ii=0;$ii<count($blines);$ii++) {
              $aval=$blines[$ii];
              $aval2=trim(preg_replace('/\t+/', '', $aval))  ;
              if ($aval2=='') {
                 $didLine=$ii;
                 break ;  // end of headers
              }
              if (substr($aval2,0,1)==';') continue;
              $aval3=explode(':',$aval2,2);
              $ado=strtolower(trim($aval3[0]));
              if (array_key_exists($ado,$ados) ===false) {
                  $errMessages[]="publicAttributes error: error in $bname: unknown keyword= $ado   ";
                  $nerrs++;
                  $didLine=false;
                  break;
              } else {
                $ados[$ado]=trim($aval3[1]);
              }
          }   // blines
// get the data
         if ($ii!==false) {
            $dlines=[];
             for  ($ii=($didLine+1);$ii<count($blines);$ii++) {
              $dline=trim(preg_replace('/\t+/', '', $blines[$ii]  )) ;      // tabs mess up json.parse

                if ($dline=='') continue;
                if (substr($dline,0,1)==';') continue;
                $csvline=str_getcsv($dline);
                $dlines[]=$dline;
//                $dlines[]=$csvline;
             }
             $ados['csv']=$dlines;
         }
          $ados['fileName']=$bname;
          $rets[$bname]=$ados;

          $messages[]="Asset: $bname ";


       }   //aah


  }  // file

   $stuff=['info'=>$rets,'messages'=>$messages,'errMessages'=>$errMessages];

   ob_end_clean();   // remove prints and other crap
   $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests ;
   exit ;



?>
