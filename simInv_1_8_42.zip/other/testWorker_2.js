
onmessage = function(e) {
  console.log('Worker: Message received from main script );
  let a1=e.data[0],a2=e.data[1];
  const result = a1+a2 ;



// a fake delay
  let date1=Date.now();
  let dateT=date1,nsecs=0;

   for (let mm=1;mm>0;mm++) {
        date2=Date.now();
        let ddiff=date2-date1;
        if (ddiff>8000) {
           let smess0=mm+' pause done at '+date2;
           console.log(smess0);
           let tt=[false,smess0];
           postMessage(tt);
           break ;
       }
       let d2=date2-dateT
       if (d2>1000) {
           nsecs++ ;
           let smess=nsecs+' seconds after '+mm;
           console.log(smess);
           let tt=[false,smess];
           postMessage(tt);
           dateT=date2;
      }

  } // for mm

  if (isNaN(result)) {
    postMessage([true,'Please write two numbers']);
  } else {
     let workerResult = 'Result: ' + result;

     console.log('Worker: '+date1+' Posting message back to main script '+a1+','+a2);
     let aa=' : The result='+ result ;
     let bb=[true,aa];
     postMessage(bb);
  }

 }     // onmessage


