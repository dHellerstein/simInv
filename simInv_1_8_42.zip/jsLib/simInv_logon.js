// logon functions for simInv

//==================
// logon -- check if this username is initialized; either on server or local storage
// this is ONLY called from a button on the main menu (specified in index.html)
// will eventually call afterLogon() or checkUserExistsOnline() (which eventually calls afterLogon)
// THUS: return is not used, as this is an event driven call
//   AND there are a number of asynchroous functions called -- either to get data from "local dbStorage" or "from the server"

function doLogon(ifoo) {

   let e1= $('#iUserName');
   let aval=jQuery.trim(e1.val());
   if (aval.indexOf('@')>-1 || aval.indexOf('!')>-1 || aval.indexOf(' ')>-1) {
      alert(' Invalid user name (it can not contain @, !, or spaces) ');
      return 0;
   }
   if (aval=='') {
      alert(' You must enter a user name ');
      return 0;
   }
   aval2=fixString(aval,1);
   if (aval2!=aval) {
      alert('Please enter a single word');
      return 0;
   }
  userName=aval2.toLowerCase();         // set this global
  simInvGlobals['userName']=userName ;  // might be used (5 jan 2024)

  let eKey=$('#iEncryptionKey');
  let encryptionKeyT=eKey.val();          // global
  simInvGlobals['encryptionKey']=jQuery.trim(fixString(encryptionKeyT,1).toLowerCase());        // trimmed, lower case, no odd characters
  simInvGlobals['encryptionKey_md5']= (simInvGlobals['encryptionKey']!='') ? simInv_makeEncMd5(simInvGlobals['encryptionKey']) : '' ;

  let qLocal=  simInvDsets['simInvLocalStorage']['enabled'];

  if (qLocal===false)  {     // onLine storage  -- or perhaps user chooses
       checkUserExistsOnline(userName);        //  online with server storage ... checkUserExistsOnline calls checkUserExistsOnline2 that calls afterLogon()
       return  ;
  }

// If here ... local storage. standalone mode, or onLine with local storage OR user chosen storage ?

// first: does user exist (on the server)?

     checkUserExists_indexDb(userName,doLogon_localB) ;

}


//=========   :::: local :::::::
// Callback from checkUserExists_indexDb()
// After checking if this user has been initialized in simInv local storage
// status could be "chose server" (so logon to server), existing local, or new user (so initialize this user in local storage)
function doLogon_localB(astatus,amess) {
   let bmess='';
   if (astatus===0) {            
       bmess+='<tt>'+amess+'</tt><br>';
       bmess+='There is a problem with your local storage. See <a href="readme.txt" target="readme">readme.txt</a> for further information ';
       simInv_errorMessage(bmess);
       return 0;
   }

   if (astatus==1)   {           // existing user with local storage -- perhaps  previously  "online chose local  storage"

     if (simInvGlobals['encryptionKey']!='') {
        displayStatusMessage('Note: when using local storage, an encryption key is <b>not</b> used');
        window.setTimeout(function() {
            getUserData_indexDb(userName,doLogon2_local);  // aleady existing user...
        },1500);
       return ;
     }  else {
            getUserData_indexDb(userName,doLogon2_local);  // aleady existing user...
     }
     return 1;
   }

// if here (astatus=2), no such user -- so initialize (or relogon) !
   clearTimeout(simInvGlobals['monitorStartup_id']);  // relogon should occur, so stop this failure monitor
   initUserLocal(1);        // displays a message and exits (so no return value)
   return ;
}

//===================
// callback from getUserData_indexDb()
//  got data! so logon continues
// if qok=0 -- error, show messages
//   and  rdata=error message if qok=0;
//
// otherwise
//    adata properties: name initdate updateDate how howSay rdata
//       rdata properties: settings assets assetHistory portfolios portfolioInit, portfolioModifications,scenario, viewDates updateDate
//         or
//       false (if online chose server storage)

function doLogon2_local(qok,adata) {     // return from  getUserData_indexDb

   if (qok===0)  {           // fatal error -- show message and hide everything else
      simInv_errorMessage(adata);
      return 0
   }

   simInvGlobals['originalServerResponse']= JSON.parse(JSON.stringify(adata));  //   this is used by diagnostics (clone it to avoid possible issues)

   if (adata['dinfo']===false)  {  // a "online chose server storage"
      simInvGlobals['logonStarted']=false;                   // used by monitorStartup -- will be set true by checkUserExistsOnline2
      simInvDsets['simInvLocalStorage']['enabled']=false;    // needs this if onLine with previously chosen server storage
      checkUserExistsOnline(1);        //  online with server storage ... checkUserExistsOnline calls checkUserExistsOnline2 that calls afterLogon()
      return ;
   }


// else... local storage (perhaps online mode with local storage)
   simInvGlobals['lastUpdateDate']=adata['updateDate'] ;                                    // set some globals (note that lastUpdateDateSay is set in afterLogon)

   simInvGlobals['logonStarted']=true;                   // used by monitorStartup
    simInvDsets['simInvLocalStorage']['enabled']=true;    // needs this if onLine with previously chosen local storage
   simInv_indexDbStorageStats( simInvDsets['simInvLocalStorage']['enabled']) ;       // enable local storage button
   let arf=adata['dinfo'] ;      // dont return some of the metadata
   arf['updateDate']=simInvGlobals['lastUpdateDate'] ;
   afterLogon(arf);        // doLogon2_local: responseData has been read from local storage
}

// ============== :: online ::
// check that user exists (online mode).
// if no username -- error messages
// if username, but no settings --save global settings (and encMd5) and relogon
// if global settings -- afterLogon (read all data)
// called by doLogon

function checkUserExistsOnline(ifoo) {

    let ddata={'todo':'checkUserExists','username':userName};     // ask server if this username exists
    $.ajax({
        url: 'phpLib/simInv2.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {       // user does exist

     checkUserExistsOnline2(response);

   });
}

//===========
// callback from checkUserExistsOnline (online mode)
/// If no initialized, give user an option to initialize (using a call to checkUserExistsOnline2_init)
// 0: ready, 1:no username speciifed, 2: no such user,3: no settings
function checkUserExistsOnline2(response,asay) {
  if (arguments.length<2){
      astat=response[0];
      asay=response[1] ;
   } else {
      astat=response;
   }
   let amess;

   if (jQuery.isArray(response)) {
       amess=response[1];
       astat=parseInt(response[0]);
   }
   if (astat==1)  { // no user name -- should never happen
      clearTimeout(simInvGlobals['monitorStartup_id']);  // relogon should occur, so stop this failure monitor

       let amess="Please specify a username ";
       displayStatusMessage(amess,2);
       toggleStatusMessage(0,0);
       return 0 ;
   } else if (astat==2) {   // no such user
      clearTimeout(simInvGlobals['monitorStartup_id']);  // relogon should occur, so stop this failure monitor
       displayStatusMessage('<hr>'+amess,2);
       toggleStatusMessage(0,0);
       return 0;
   } else if (astat==4) {   // essential data files missing
      clearTimeout(simInvGlobals['monitorStartup_id']);  // relogon should occur, so stop this failure monitor
       displayStatusMessage('<hr>'+amess,2);
       toggleStatusMessage(0,0);
       return 0;
   }


// first time logon? create settings file (usijng default settings)

   if (astat==3) {
     initUserOnline(1);
     return 1;
   }

// if here, NOT a first time logon -- so get user data and contine .

    simInvGlobals['logonStarted']=true;                                  // global used by monitorStartup

    let ddata={'todo':'getData','username':userName,'encMd5':simInvGlobals['encryptionKey_md5']};   
    $.ajax({
        url: 'phpLib/simInv2.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {

        if (response.hasOwnProperty('error') && response['error']===true) {
              clearTimeout(simInvGlobals['monitorStartup_id']);  // relogon should occur, so stop this failure monitor
              displayStatusMessage(response['errorMessage']);
              toggleStatusMessage(0,0);
             return 1;
        }

       let response2x=simInvData_unstringify(response,simInvGlobals['encryptionKey']);   // decrypt and unstringify -- the return is a js array or object
       if (response2x===null) return false ;

      simInvGlobals['lastUpdateDate']=response2x[1]['updateDate']*1000 ;      // updateDate is php time (not milliseconds)

      simInvGlobals['originalServerResponse']= JSON.parse(JSON.stringify(response2x));  //  this is used by diagnostics (clone it to avoid possible issues)

      let response3=checkUserExistsOnline2_tweak(response2x);  // tweak structure to be what afterLogon expects (to match local storage structure)

      afterLogon(response3);          //  checkUserExistsOnline2 (after unstringify)
   });


   return 1 ; ;
}      // checkUserExistsOnline2


//==============
// tweak structure of response-from-server, to match the structure used by afterLogon

function  checkUserExistsOnline2_tweak(responseX) {
   let dsets={'assets':1,'assetHistory':2,'viewDates':2,            // 1= array, 2 : object
     'portfolios':1,'portfolioInit':2,'portfolioModifications':2,'scenario':2};

   let updateDates=responseX[0];
   let daResponse=responseX[1];

  let nuResponse={};

  if (!daResponse.hasOwnProperty('settings') || !jQuery.isPlainObject(daResponse['settings'] )) simInvDsets['qStatusList']['errors'].push('No, or bad, settings property in server response');
  if (!daResponse.hasOwnProperty('cpiuSeries') || !jQuery.isPlainObject(daResponse['cpiuSeries'] )) simInvDsets['qStatusList']['errors'].push('No, or bad, cpiuSeries property in server response ');

  let atime= (updateDates.hasOwnProperty('settings')) ? updateDates['settings'] : false ;
  nuResponse['settings']={} ;

  if (daResponse['settings'].hasOwnProperty('data')) {
    for (let aa in  daResponse['settings']['data']) nuResponse['settings'][aa]=daResponse['settings']['data'][aa];

  } else {
    for (let aa in  daResponse['settings']) nuResponse['settings'][aa]=daResponse['settings'][aa];
  }

  let atime2= (updateDates.hasOwnProperty('cpiuSeries')) ? updateDates['cpiuSeries'] : false ;
  nuResponse['cpiuSeries']={'time':atime,'data':{}};
  for (let aa in  daResponse['cpiuSeries']) nuResponse['cpiuSeries']['data'][aa]=daResponse['cpiuSeries'][aa];

  for (let aa2 in dsets) {

     if (daResponse[aa2]===false || updateDates[aa2]===false) {
        if (dsets[aa2]==1) {           // array
           nuResponse[aa2]={'time':false,'data':[]}
        } else {                                        // object
           nuResponse[aa2]={'time':false,'data':{}}
        }
     } else {
        let ktime=updateDates[aa2]  ;
        let kdata=daResponse[aa2]['data'];
       nuResponse[aa2]={'time':ktime,'data':kdata}
     }
  }
  return nuResponse ;

}




