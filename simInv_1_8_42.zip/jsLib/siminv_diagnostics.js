// simInv diagnostics

//===========
// called by user if a long wait... check some diagnostics stats
function viewDiagnostics(ifoo) {

   let amess='<div class="cDiagnostics1" id="iviewDiagnostics">  ';
   let amode=whatMode(1) ;
   amess+=amode;

   let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;

   if (qLocal) {
      amess+='<span title="Timestamp: '+simInvGlobals['lastUpdateDate']+'" style="float:right;margin-right:1em;font-style:oblique">most recent <u>local</u> data update on '+simInvGlobals['lastUpdateDateSay'];
   } else {
      amess+='<span  title="Timestamp: '+simInvGlobals['lastUpdateDate']+'"  style="float:right;margin-right:1em;font-style:oblique">last <u>onLine</u> data update on '+simInvGlobals['lastUpdateDateSay'];
   }
   amess+='</span>';

   amess+='</div>';
   amess+='<a href="monitorStartup.txt" class="cdoButtonRegular" title="View notes on startup failure" target="readme">&#119137;</a>';
   amess+='<em>You can ...</em>';
    
   amess+='<ul>';
   amess+='<li>View the <input type="button" value="startup status" onClick="viewDiagnostics_show(1)" > (what simInv startupSteps were completed)  ';
    if (simInvDsets['qStatusList']['errors'].length>0) amess+=' -- with error messages ';
   amess+='<li>View the <input type="button" value="raw response from the server" onClick="viewDiagnostics_show(2)"> ';
   amess+='<li>View the <input type="button" value="working data" onClick="viewDiagnostics_show(3)"> ';
   amess+='<li>View <input type="button" value="technical and other notes" onClick="simInv_notes(1,1)"> ';
   amess+='<li>  <input type="button" value="quickDisplay" onClick="simInv_cacheResults_show(1)"> (view, clear, etc)';
   amess+='</ul>' ;

 
   if (simInvGlobals['autoArchiveStatus']!==false) {
      amess+='<div id="viewDiagnosticMessages" style="border:1px solid blue;margin:1em 1em; "><u>Auto archive results:</u> '+simInvGlobals['autoArchiveStatus']+'</div>';
   } else {
     amess+='<div id="viewDiagnosticMessages" style="border:1px solid blue;margin:1em 1em;display:none"> </div>';
   }

   displayStatusMessage(amess);
   showStatusMessage(400);
   toggleStatusDiv(4,0);
   return 1;
  
  
  
  //-------------- local functions 
  function whatMode(ii) {
      let qLocal= simInvDsets['simInvLocalStorage']['enabled'] ;
      let myMode='';
     if (qLocal) {   // standalone or onlineWithLocal

      if (simInvDsets['simInvLocalStorage']['onLineLocalStorage']===false) {    // standALone mode must use local file storage
         myMode+=' standAlone mode ';
      } else {                // local file storage, onLine mode
         myMode+=' online mode w/local storage';
      }

  } else {                     // online
      myMode+=' online mode ';
      $('#modeMessage').html('online ');

      if (simInvGlobals['encryptionKey']!='')  {
         myMode+=' (encryption enabled) ' ;
      } else {
         myMode+=' (encryption not enabled) ' ;
      }
  }
  return myMode ;
}
// ----- end of local functions

 
}

//=======
// some showDebug frontends
function viewDiagnostics_show(ido,awhere) {

  if (arguments.length<2) awhere='';
  let smessages={'complete':'startup successful?',
     'responseStatus':'response received from server (or local storage) ',
     'responseStatusVerified':'simInv data extracted from the response',
     'setupAssetLookup':'asset list built ',
     'setupAssetUsedErrors':'assets validated: the number of asset with problems ' ,
     'assetsNeedFixing':'are there problems with asset that require user action' ,
     'setupPortfolioInit':'portfolio initializaton entries  validated' ,
     'setupPortfolioMod':'portfolio modification entries  validated' ,
     'setupPortfolioLookup':'list of all portfolio entries  validated' ,
     'publicAssetsOkay':'public assets are available' ,
     'autoLogonOkay':'Are autologon actions allowed (did simInv start quickly and successfully) '
   }

  if (ido==1) {                    // qLocalStatus
    let amess='<div style="background-color:#dfdfef"> ';
    amess+='<input type="button" value="x" onClick="$(\'#viewDiagnosticMessages\').hide()" >';
    amess+='simInv startup status .... ';
    amess+='</div>';
    amess+='<table cellpadding="4" rules="rows" style="margin:5px 2em">';
    let freport=simInvDsets['qStatusList']['finalReport'];
    if (freport===false) {
          amess+='<tr><th>please wait ... </th><td><em>simInv status test still active...</em></td><tr>';
    } else {
       amess+='<tr><th>... </th><td><em>'+simInvDsets['qStatusList']['finalReport']+'</em></td><tr>';
    }
    let asuccess= (simInvDsets['qStatusList']['complete']) ? '<u>Yes</u>' : '<span style="color:red;font-weight:600">No -- some kind of error was detected</span>';
    amess+='<tr><th>Succesful completion: </th><td> '+asuccess+' </td><tr>';

    amess+='<tr><th>Errors: </th><td>'+simInvDsets['qStatusList'].errors.join(' <hr> ' )+'</td><tr>';
    amess+='<tr><th>Warnings: </th><td>'+simInvDsets['qStatusList'].warnings.join(' <hr> ' )+'</td><tr>';

    for (let a1 in smessages) {
      amess+='<tr><th>'+smessages[a1]+'</th>'
      let tt1='';    
      if (a1=='assetsNeedFixing') {       // special case
             let tt0=simInvDsets['qStatusList'][a1];
             if (typeof(tt0)=='undefined' || tt0===0) {
                tt1='<span style="color:red">Prior error: not validated </span>';
             } else if (tt0===true) {
                 tt1='<span style="color:red">Fixes required</span>';
             } else {
                 tt1='Assets are okay';
             }
     } else if (a1=='setupAssetUsedErrors') {
             if (typeof(simInvDsets['qStatusList'][a1])=='undefined' || simInvDsets['qStatusList'][a1]===false) {
                tt1='<span style="color:red">Prior error: not validated </span>';
             } else if (simInvDsets['qStatusList'][a1]===0) {
                 tt1='No fixes required ';
             } else {
                 tt1='<span style="color:red">'+simInvDsets['qStatusList'][a1]+' assets required attention (initialization, or addition of an asset history entry)</span>';
             }

     } else  {
          if (typeof(simInvDsets['qStatusList'][a1])=='undefined') {
              tt1='<span style="color:red">Prior error: not validated </span>';
          } else if (simInvDsets['qStatusList'][a1]===true) {
             tt1='Yes';
          } else if  (simInvDsets['qStatusList'][a1]===false)  {
              tt1='<span style="color:red">No</span>';
          }
      }
      tt1='<tt>'+tt1+'</tt>';
      amess+='<td>'+tt1+'</td>';
      amess+='</tr>';
    }

    amess+='</table>';
    let aid='#viewDiagnosticMessages'+awhere;
    $(aid).html(amess).show();

  } else if (ido==2) {
    showDebug(simInvGlobals['originalServerResponse'],'The raw response from the server (or from local storage)',11);
  } else if (ido==3) {
    showDebug(simInvDsets['allCurrentData'],'The parsed response from the server (or from local storage) -- simInv internal datasets are built from this ',11);

  }

  return 1;
}


