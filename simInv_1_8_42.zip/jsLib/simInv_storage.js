// on line storage initialization: step 1, save
//data0 ={'time':nowTime,'userName':userName,'encMd5':encryptionKey_md5};
// 25 dec 2023 : usekey is NOT used by this function

function saveSimInvData_saveEncMd5(userName,callback,data0,okmess,myhint,usekey) {
   let nowTime=wsurvey.get_currentTime(0);
   let ddata={'userName':userName,'data':data0 };
   $.ajax({
        url: 'phpLib/simInv_saveEncMd5.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
        if (response[0]==1) {      // okay
          callback(1,okmess,myhint,usekey);
        } else {                                                                                                                                               
          callback(0,response[1],myhint,usekey);
        }
   });

}        // saveSimInvData_saveEncMd5

//=====================
// save personal settings, and default cpiUseries  -- local or on server. This is done when a user is initialized


function saveSimInvData_settingsInit(userName,acallback,aSettings,acpiuSeries,dahint,okmess,usekey,enableAutoArchive)  {

    let nowTime=wsurvey.get_currentTime(0);
    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
    if (qLocal) {                  // hint NOT saved (as seperate store object) with local storage 23 dec 2023
       let stuff=[];
       let stuff1={};
         stuff1['avar']='settings';
         stuff1['aval']={'time':nowTime,'data':aSettings};
       stuff.push(stuff1);
       let stuff2={};
         stuff2['avar']='cpiuSeries';
         stuff2['aval']={'time':nowTime,'data':acpiuSeries};
       stuff.push(stuff2);
       
       let stuff3={};
         stuff3['avar']='viewDates';
         stuff3['aval']={'time':nowTime,'data':simInvDsets['viewDates']};
       stuff.push(stuff3);

       addUserData_indexDb(userName,acallback,stuff,true,okmess) ;  
       return 1 ;
    }

// ::::: if here ...   save to server  --  two steps ::::::::::

// 16 dec 2023 --   for now save settings (dsata0) as  unencrypted, even though encryptionKey_md5 may not be ''

   ddata=saveSimInvData_makeArg(userName,'settings',aSettings,usekey);
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
        saveSimInvData_settingsInit2(response,userName,acallback,acpiuSeries,dahint,okmess,usekey,enableAutoArchive);
   });

   return ;
}


//====  call back after saving settigns .. now save cpiuseries
function saveSimInvData_settingsInit2(response,userName,acallback,acpiuSeries,dahint,okmess,usekey,enableAutoArchive)  {

   if (!jQuery.isArray(response))  {   // if not an array, probably an error message
      wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_settingsInit2');
      let errorInPhp=saveSimInvData_settingsInit2_err/55;
      return ;
  }          // fatal error

  okmess=response[1]+'<hr>'+okmess;

// now update cpiuseries
   let ddatabx=saveSimInvData_makeArg(userName,'cpiuSeries',acpiuSeries,usekey) ;
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabx
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
         saveSimInvData_settingsInit3(response,userName,acallback,dahint,okmess,usekey,enableAutoArchive);
   });
}



//====  call back after saving cpiuseries  .. now save hint
function saveSimInvData_settingsInit3(response,userName,acallback,dahint,okmess,usekey,enableAutoArchive)  {

   if (!jQuery.isArray(response))  {   // if not an array, probably an error message
      wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_settingsInit3');
      let errorInPhp=saveSimInvData_settingsInit3_err/55;
      return ;
  }          // fatal error

  okmess=response[1]+'<hr>'+okmess;

// now update hint
 if (jQuery.trim(dahint)=='') dahint='No hint specified ';
   let ddatabx=saveSimInvData_makeArg(userName,'hint',dahint,usekey)      ;
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabx
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
         saveSimInvData_settingsInit4(response ,userName,acallback,okmess,usekey,enableAutoArchive);
   });
}

// after saving hint... now create auto archive dirs
function saveSimInvData_settingsInit4(response ,userName,acallback,okmess,usekey,enableAutoArchive) {    // callback after saving cpiuSeries
   if (!jQuery.isArray(response))  {   // if not an array, probably an error message
      wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_settingsInit4');
      let errorInPhp=saveSimInvData_settingsInit4_err/55;
      return ;
  }          // fatal error

  if (enableAutoArchive==0)  {     // do NOT enable autoarchive
     saveSimInvData_settingsInit5('Auto archive NOT enabled' ,userName,acallback,okmess,usekey)
     return 0
  }

// if here create auto archive dirs

  let amd5=simInv_makeEncMd5(usekey);
  let ddata1={'username':userName,'todo':'setupArchiveDirs','encMd5':amd5};
   $.ajax({
        url: 'phpLib/simInv2.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata1
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
         saveSimInvData_settingsInit5(response ,userName,acallback,okmess,usekey );
   });


}

// after creating auto archive dires..
function saveSimInvData_settingsInit5(response ,userName,acallback,okmess,usekey ) {    // callback after saving cpiuSeries
  if (jQuery.isPlainObject(response) && response.hasOwnProperty('error')  && response['error']===true)  {
      alert('error in saveSimInvData_settingsInit5: '+response['errorMessage'] );
      let errorInPhp=saveSimInvData_settingsInit5_err_b/55;
      return ;
  }
   okmess=response +'<br>'+okmess;
   acallback(response ,okmess,usekey);

}
// END of settings / cpiuseries default save


//=======++==============
// save settings  -- local or on server

function saveSimInvData_settings(userName,callback,asettings,okmess ) {
    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
    if (qLocal) {
        let stuff=[];
         let stuff2={};
         stuff2['avar']='settings';
         stuff2['aval']=asettings ;
       stuff.push(stuff2);
       addUserData_indexDb(userName,callback,stuff,true,okmess) ;
       return 1 ;
    }           // local storage

// ::::: if here ...   save to server  ::::::::::

   let ddata=saveSimInvData_makeArg(userName,'settings',asettings,simInvGlobals['encryptionKey']) ;

   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage

      if (!jQuery.isArray(response))  {   // if not an array, probably an error message
         wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_settings ');
         let errorInPhp=saveSimInvData_settings_err/55;
         return ;
       }          // fatal error
        let myhint= asettings['encryptionKeyHint'];
        if (response[0]==1) {
          let bmess=response[1]+'<hr>'+okmess;
          callback(1,bmess,myhint);
        } else {
          callback(0,response[1],'');
        }
   });

   return ;
}


// ===========================
// ============== save view dates ==============

function saveSimInvData_viewDates(userName,viewDates,okmess) {
    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
    if (qLocal) {
        let stuff=[];
         let stuff2={};
         stuff2['avar']='viewDates';
         stuff2['aval']=viewDates;
       stuff.push(stuff2);
       addUserData_indexDb(userName,saveSimInvData_callbackLocal,stuff,true,okmess,'valueDatesButton') ;  
       return 1 ;
   }

// :::: server storage if here

   let ddata=saveSimInvData_makeArg(userName,'viewDates',viewDates,simInvGlobals['encryptionKey']) ;

   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage

      if (!jQuery.isArray(response))  {   // if not an array, probably an error message
         wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_viewDates.php');
         let errorInPhp=saveSimInvData_viewDates_err/55;
         return ;
       }          // fatal error
       okmess=response[1]+'<br>'+okmess;
       displayResponseFromServer(okmess,'valueDatesButton');
   });

   return ;
}

// ===========================
// ============== save cpiu  ==============

function saveSimInvData_cpiuSeries(userName,aSeries,okmess) {
    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
    if (qLocal) {
        let stuff=[];
         let stuff2={};
         stuff2['avar']='cpiuSeries';
         stuff2['aval']=aSeries;
       stuff.push(stuff2);
       addUserData_indexDb(userName,saveSimInvData_callbackLocal,stuff,true,okmess,'isetInflation') ; // use same callback as for saving assets efaultUserSettings is global
       return 1 ;
   }

// :::: server storage if here

   let ddata=saveSimInvData_makeArg(userName,'cpiuSeries',aSeries,simInvGlobals['encryptionKey']) ;
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage

      if (!jQuery.isArray(response))  {   // if not an array, probably an error message
         wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_cpiuSeries.php');
         let errorInPhp=saveSimInvData_cpiuSeries_err/55;
         return ;
       }          // fatal error
       okmess=response[1]+'<br>'+okmess;
       displayResponseFromServer(okmess,'isetInflation',1);
   });

   return ;
}


// ===========================
// ============== save the assets ==============
// possibly save assetHistory if there were removals

function saveSimInvData_assetsSave(userName,newAssets,newAssetHistory,okmess) {

    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;

    if (qLocal) {
        let stuff=[];
       let stuff1={};
         stuff1['avar']='assets';
         stuff1['aval']=newAssets;
       stuff.push(stuff1);
       let stuff2={};
         stuff2['avar']='assetHistory';
         stuff2['aval']=newAssetHistory;
       stuff.push(stuff2);

       addUserData_indexDb(userName,saveSimInvData_callbackLocal,stuff,true,okmess,'assetsTableButtonHistory') ;  
       return 1 ;
     }       // end of save to local .......


// ::::: if here ...   save to server  ::::::::::

   let ddata=saveSimInvData_makeArg(userName,'assets',newAssets,simInvGlobals['encryptionKey'])  ;   
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddata
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
        saveSimInvData_assetsSave2(response,userName,newAssetHistory,okmess);
   });

   return ;
}


//====  call back after saving asssets
function saveSimInvData_assetsSave2(response,userName,newAssetHistory,okmess)  {
   if (!jQuery.isArray(response))  {   // if not an array, probably an error message
      wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_assetsSave');
      let errorInPhp=saveSimInvData_settings_err/55;
      return ;
  }          // fatal error

  okmess=response[1]+'<hr>'+okmess;

// now update assethistory

   let ddatabX=saveSimInvData_makeArg(userName,'assetHistory',newAssetHistory,simInvGlobals['encryptionKey']) ;  
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage

         saveSimInvData_assetsSave3(response ,okmess);
   });
}


function saveSimInvData_assetsSave3(response ,okmess) {    // callback after saving assetHistory

   okmess=response[1]+'<br>'+okmess;
   displayResponseFromServer(okmess,'assetsTableButtonHistory',1);
}

// END of save assets (and assetHistory)

// ===========================
//===========  save the   assetHistory    ========
//similar to save asset history in saveAssets

function saveSimInvData_assetHistorySave(userName,newAssetHistory,okmess) {

    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
    if (qLocal) {
        let stuff=[];
         let stuff2={};
         stuff2['avar']='assetHistory';
         stuff2['aval']=newAssetHistory;
       stuff.push(stuff2);

       addUserData_indexDb(userName,saveSimInvData_callbackLocal,stuff,true,okmess,'assetsTableButtonHistory') ; // use same callback as for saving assets efaultUserSettings is global
       return 1 ;
     }

// ::::; if here, save to server ::::::::::

   let ddatabX2=saveSimInvData_makeArg(userName,'assetHistory',newAssetHistory,simInvGlobals['encryptionKey']) ;  
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX2
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
        saveSimInvData_assetHistorySave2(response ,okmess);
   });
}

// callback after saving assethistory (slightly different thatn saving assethistory afte changing assets)
function saveSimInvData_assetHistorySave2(response ,okmess) {    // callback after saving assetHistory
  okmess=response[1]+'<br>'+okmess;
  displayResponseFromServer(okmess,'assetsTableButtonHistory',1);
}


// ===========================
//============  save portoflio list   ===============
// (and possibly portoflioinit and portofliomodifications if there were removes
function saveSimInvData_portfolioList(userName,adata,adataInit,adataMod,okmess) {
    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
    if (qLocal) {
         let stuff=[];
         let stuff2={};

         stuff2['avar']='portfolios';
         stuff2['aval']=adata;
         stuff.push(stuff2);

         if (adataInit!==false) {
            let stuff2={};
            stuff2['avar']='portfolioInit';
            stuff2['aval']=adataInit;
            stuff.push(stuff2);
         }
         if (adataMod!==false) {
            let stuff2={};
            stuff2['avar']='portfolioModifications';
            stuff2['aval']=adataMod;
            stuff.push(stuff2);
         }
          addUserData_indexDb(userName,saveSimInvData_callbackLocal,stuff,true,okmess,'portfoliosTableButton') ; // use same callback as for saving assets efaultUserSettings is global
         return 1 ;
     }

// ::::; if here, save to server  -- several steps ::::::::::

   let ddatabX2=saveSimInvData_makeArg(userName,'portfolios',adata,simInvGlobals['encryptionKey']) ;  

   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX2
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
        saveSimInvData_portfolioList2(userName,response ,adataInit,adataMod,okmess);
   });

 }

// portfolio list saved, now save init (if it changed)
function saveSimInvData_portfolioList2(userName,response ,adataInit,adataMod,okmess) {
   if (!jQuery.isArray(response))  {   // if not an array, probably an error message
      wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_portfolioList2');
      let errorInPhp=saveSimInvData_portfolioList2_err/55;
      return ;
  }          // fatal error
  okmess=response[1]+'<hr>'+okmess;
  if (adataInit===false)   {   // no changes in portoflioInit -- perhaps in mod?
      saveSimInvData_portfolioList3([1,'portfolioInit unchanged'] ,userName,adataMod,okmess);
      return ;
  }

// now update portfolioInit

   let ddatabX =saveSimInvData_makeArg(userName,'portfolioInit',adataInit,simInvGlobals['encryptionKey']) ;  
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
         saveSimInvData_portfolioList3(response, userName,adataMod,okmess);
   });
}

// ========================

// portfolioInit might of been saved... maybe save portfolioModifications
function  saveSimInvData_portfolioList3(response,userName ,adataMod,okmess) {

   if (!jQuery.isArray(response))  {   // if not an array, probably an error message
      wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_portfolioList3');
      let errorInPhp=saveSimInvData_portfolioList3_err/55;
      return ;
   }          // fatal error
   okmess=response[1]+'<br>'+okmess;     // prepend  'portfolioInit status message'
   if (adataMod===false)   {   // no changes in portfolioModifications ... so done! -- perhaps in mod?
       amess ='portfolioModifications unchanged <br>'+okmess;
       displayResponseFromServer(amess,'portfoliosTableButton',1);
       return ;
   }


//===========================
// now update portfolioModifications
 
   let ddatabX =saveSimInvData_makeArg(userName,'portfolioModifications',adataMod,simInvGlobals['encryptionKey']) ; 
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX
   }).always(function (response) {      // reponse=1 is success. Otherwise returns with error mesesage
         saveSimInvData_portfolioList4(response,okmess);
   });
}

// callback after saving portfolioModificatons
function saveSimInvData_portfolioList4(response ,okmess) {    // callback after saving portfolioModificatons

  okmess=response[1]+'<br>'+okmess;                          // might be error mesesage
  displayResponseFromServer(okmess,'portfoliosTableButton',1);
}

// End of change portfolios (and portfolioInit and portfolioModifications


// ===========================
// ==================    save portoflioInit    =======
function saveSimInvData_portfolioInit(userName,adata,okmess) {
    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
    if (qLocal) {
        let stuff=[];
         let stuff2={};
         stuff2['avar']='portfolioInit';
         stuff2['aval']=adata;
       stuff.push(stuff2);
       addUserData_indexDb(userName,saveSimInvData_callbackLocal,stuff,true,okmess,'portfoliosTableButton') ; // use same callback as for saving assets efaultUserSettings is global
       return 1 ;
     }
     
// ::::; if here, save to server


   let ddatabX2=saveSimInvData_makeArg(userName,'portfolioInit',adata,simInvGlobals['encryptionKey']) ;  
   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX2
   }).always(function (response) {      // might be error mesesage


      if (!jQuery.isArray(response))  {   // if not an array, probably an error message
         showDebug(response['responseText'],' error in saveSimInvData_portfolioInit',1);
         let errorInPhp=saveSimInvData_portfolioInit_err/55;
         return ;
       }          // fatal error
      okmess=response[1]+'<br>'+okmess;
      displayResponseFromServer(okmess,'portfoliosTableButton',1);
   });

 }

//===================
// ==================    save portfolioModifications    =======
function saveSimInvData_portfolioModification(userName,adata,okmess) {
    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
    if (qLocal) {
        let stuff=[];
         let stuff2={};
         stuff2['avar']='portfolioModifications';
         stuff2['aval']=adata;
       stuff.push(stuff2);
       addUserData_indexDb(userName,saveSimInvData_callbackLocal,stuff,true,okmess,'portfoliosTableButton') ; // use same callback as for saving assets efaultUserSettings is global
       return 1 ;
     }


// ::::; if here, save to server

   let ddatabX2=saveSimInvData_makeArg(userName,'portfolioModifications',adata,simInvGlobals['encryptionKey']) ; 

   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX2
   }).always(function (response) {      // might be error mesesage

      if (!jQuery.isArray(response))  {   // if not an array, probably an error message
         wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_portfolioModification');
         let errorInPhp=saveSimInvData_portfolioModification_err/55;
         return ;
      }
      okmess=response[1]+'<br>'+okmess;
      displayResponseFromServer(okmess,'portfoliosTableButton',1);
   });

}
//===================
// ==================    save scenarios    =======
function saveSimInvData_scenario(userName,adata,okmess) {
    let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
    if (qLocal) {
        let stuff=[];
         let stuff2={};
         stuff2['avar']='scenario';
         stuff2['aval']=adata;
       stuff.push(stuff2);
       addUserData_indexDb(userName,saveSimInvData_callbackLocal,stuff,true,okmess,'scenarioTableButton_chosen') ; // use same callback as for saves
       return 1 ;
     }


// ::::; if here, save to server
 
   let ddatabX2=saveSimInvData_makeArg(userName,'scenario',adata,simInvGlobals['encryptionKey']) ;  

   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX2
   }).always(function (response) {      // might be error mesesage

      if (!jQuery.isArray(response))  {   // if not an array, probably an error message
         wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_portfolioModification');
         let errorInPhp=saveSimInvData_portfolioModification_err/55;
         return ;
      }
      okmess=response[1]+'<br>'+okmess;

      displayResponseFromServer(okmess,'scenarioTableButton_chosen');
   });

}


//===================
// ==================    save a public asset    =======
// saves stuff to 'assets' and to 'assetHistory'
function saveSimInvData_publicAsset(userName,assetB,assetH,okmess,useAssetName) {

   let qLocal=  simInvDsets['simInvLocalStorage']['enabled'] ;
   if (qLocal) {
       let stuff=[];
       let stuff1={};
         stuff1['avar']='assets';
         stuff1['aval']=assetB;
       stuff.push(stuff1);
       let stuff2={};
         stuff2['avar']='assetHistory';
         stuff2['aval']=assetH;
       stuff.push(stuff2);
     addUserData_indexDb(userName,saveSimInvData_callbackLocal,stuff,true,okmess,'assetsTableButton') ; // use same callback as for saving assets efaultUserSettings is global
     return 1 ;
   }

// ::::; if here, save to server

   let ddatabX2=saveSimInvData_makeArg(userName,'assets',assetB,simInvGlobals['encryptionKey']) ;  

   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX2
   }).always(function (response) {      // might be error mesesage

      if (!jQuery.isArray(response))  {   // if not an array, probably an error message
         wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_publicAsset');
         let errorInPhp=saveSimInvData_publicAsset_error/55;
         return ;
      }
      okmess=response[1]+'<br>'+okmess;
      saveSimInvData_publicAsset2(userName,aname,assetH,okmess)
   });

}

// === now save updated assetHistory (current assetHIstory with public asset appended
function saveSimInvData_publicAsset2(userName,aname,assetH,okmess) {
   let ddatabX2=saveSimInvData_makeArg(userName,'assetHistory',assetH,simInvGlobals['encryptionKey']) ;  

   $.ajax({
        url: 'phpLib/simInv_saveData.php',
        type: 'POST',
        dataType: 'json',
        cache:false,
        data: ddatabX2
   }).always(function (response) {      // might be error mesesage

      if (!jQuery.isArray(response))  {   // if not an array, probably an error message
         wsurvey.dumpObj(response['responseText'],1,' error in saveSimInvData_publicAsset2');
         let errorInPhp=saveSimInvData_publicAsset2_error/56;
         return ;
      }
      okmess=response[1]+'<br>'+okmess;
      displayResponseFromServer(okmess,'assetsTableButtonHistory',1);
  });
  return ;
}


// ::::::::::::; helper functions :::::::::::::::
//==================  ============================
//a generic call back for saveSimInvData actions -- used by local functions
// (this is called from portfolioModifications)
function saveSimInvData_callbackLocal(astatus,amess) {
      displayResponseFromServer(amess );
     return 1;
}


// -----
// make the data object to send to siminv_saveData.php
// will encrypt if encryption enabled (and one of the encVars)
function saveSimInvData_makeArg(userName,aname,aval,akey) {

   let encList= {'assets':1,'assetHistory':1,'portfolios':1,'portfolioInit':1,'portfolioModifications':1,'scenario':1};
   let nowTime=wsurvey.get_currentTime(0);
   let ddata  ;
   let amd5=simInv_makeEncMd5(akey);
   if (akey!==false && jQuery.trim(akey)!=='' && encList.hasOwnProperty(aname) ) {                 // encryption needs to be done
       let ddataXX2=simInvEncrypt(aval,akey);
       ddata={'userName':userName,'data':ddataXX2,'time':nowTime,'encMd5':amd5,'which':aname};  // the encrypted info is used for 'data'
   } else {
       let ddataXX=JSON.stringify(aval);   // stringifiy to avoid php messing up when it stringifies
       ddata={'userName':userName,'data':ddataXX,'time':nowTime,'encMd5':amd5,'which':aname};     // amd5='' if no encryption
   }

   return ddata;
}                 // userName is a global

