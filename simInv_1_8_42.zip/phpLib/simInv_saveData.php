<?php

// ============
// php for simInv -- save dataset for a user
// $_REQUEST must contain the following
//  userName : who the user is. If no username specific directory exists, or no encMd5.json file exists, failure
//  data must  be specified --  In almost all cases it is serialized, and it could also be encrypted (the serialization is encrypted)
//  encMd5 must be specified -- the server compares to the users saved encMd5 (if no match, failure)

session_start() ;
ob_start();

  $curDir1=getcwd();             // will be xxx/yyy/simInv/phpLib ... strip out /phpLib
  $len1=strlen($curDir1);
  $len2=$len1-7;
  $curDir=substr($curDir1,0,$len2);


// fields in request missing?

  if (!array_key_exists('userName',$_REQUEST)) {       
       saveData_error("No username ...  specified");
  } else {
      $auser=$_REQUEST['userName'];
  }

  if (!array_key_exists('data',$_REQUEST))  saveData_error("No data specified");   // exits directly
  if (!array_key_exists('encMd5',$_REQUEST))  saveData_error('No encryption key specified (not even an empty one)' );   // exits directoly
  if (!array_key_exists('which',$_REQUEST))  saveData_error('Dataset to be saved not specified ' );   // exits directoly
  if (!array_key_exists('time',$_REQUEST))  saveData_error('Timestamp not specified ' );   // exits directoly

  $awhich=$_REQUEST['which'];

  $daDir=$curDir.'/data/'.$auser;
  if (trim($auser)=='' || !is_dir($daDir)) {
     saveData_error("No such user: $auser");   // exits directly
  }

// must specify encryption info (md5 of encryption key, or '' if no encryption)

// check for valid encryption (which can be 'no encryption') -- compare saved encMd5 with the one send in this request
  $myEncMd5=$_REQUEST['encMd5'] ;  // could be  blank
  $savedMd5='';$ahint=0;  // used if no encryption key file
  $xxx=readEncKey($auser,$curDir);
  if ($xxx[0]!== false)  {
     $savedMd5=$xxx[1];
  } else {
     saveData_error($xxx[1]);
  }
  if ($savedMd5!= $myEncMd5) {   // both are blank is also allowed
    if ($savedMd5==='') {
       saveData_error('You do not need an encryption key  ')  ;
    } else {
       $ahint=false;
       $tryHint=$daDir.'/hint.json';  // see if hint available
       $gotHint=file_exists($tryHint);
       if ($gotHint) {               // if no hint file, hint is   ''
          $aa=file_get_contents($tryHint);
          if ($aa!==false) {
             $va=unserialize($aa);
             if (array_key_exists('dinfo',$va)) $ahint =$va['dinfo'] ;
          }
       }
       $amess="You did not specify the correct encryption key ($awhich) ... ";
       if ($ahint!='') $amess.='<br>Hint: <tt>'.$ahint.'</tt>';
       saveData_error($amess)  ;
    }
  }

// if here, encryption key is okay (perhaps an empty one)

  $awhich=$_REQUEST['which'];
  $theData=$_REQUEST['data'];
  $atime=$_REQUEST['time'];

  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/'.$awhich.'.json';

  $aa=['time'=>$atime,'dinfo'=>$theData ];
  $da2=serialize($aa);

// 29 dec 2023
// the above serialize is a bit (but not fully) redundant.
// Why? javascript callers will typically use JSON.serialize on the data fields sent this php script
// This avoids problems with php saving (via serialize or json_encode) arrays with 0 length -- php just drops them :(

  $nn=file_put_contents($try,$da2);
  if ($nn===false)  {
    saveData_error("Could not save: $awhich : in: $try ");
  }

// set timestamp file in main
  $tstamp= simInv_updateTimestamp($auser,'') ;
  $dateTime='could not create datestamp (update and archiving info may not be accurate)';
  if ($tstamp!==false)  $dateTime = date('Y-m-d H:i:s', $tstamp);

  saveData_okay("Saved: $awhich (on $dateTime)" ) ;
  exit;       // should never get here


//==============
// return a problem response [0,messat]
function saveData_error($amess) {
  ob_end_clean();   // remove prints and other crap
  $vv=[0,$amess];
  $vsuggests=json_encode($vv, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit ;
}

//===========
// return a sucess response [1,message]'
function saveData_okay($amess) {
  ob_end_clean();   // remove prints and other crap
  $vv=[1,$amess];
  $vsuggests=json_encode($vv, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit ;
}

// ===========
// read the user's encryption key md5 (created at initialization, and can not be changed
function readEncKey($auser,$curDir) {

  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/encMd5.json';
  $gotEncKey=file_exists($try);
  if ($gotEncKey) {
      $aa=file_get_contents($try);
      if ($aa===false) return [false,"Unable to retrieve encryption key MD5 file: $try "];
      $va=unserialize($aa);
      if ($va===false)  return [false,"Problem reading encryption key MD5 file: $try "]  ;
      if (!array_key_exists('encMd5',$va)) return [false,'encryption information not specified'];
      return [true,$va['encMd5']] ;
  }
  return [false,'encryption information not saved.'];  // no such file

}

//=============
// create a timeSTamp file for user in a subdirectory  -- such as 'auto' or 'maual' .. .if asub=='', in main dir for this user
function  simInv_updateTimestamp($auser,$asub='') {
  global $curDir;
  $daDir=$curDir.'/data/'.$auser;
  if (!is_dir($daDir)) return false ;      // should never happen

  if (trim($asub)=='') {
     $usedir=$daDir ;
  } else {
     $usedir=$daDir.'/'.$asub;
     if (!is_dir($usedir)) return false ;      // should never happen
  }

  $afile=$usedir.'/lastUpdate.dat';
  $atime=time();
  $nbytes=file_put_contents($afile,$atime);
  return $atime ;
}



?>
