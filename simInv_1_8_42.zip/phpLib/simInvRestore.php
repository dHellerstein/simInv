<?php

// ============
// php for simInv -- restore data    -- note use of json_decode (there are problems sending the archived (jsonish) file here without first stringifying

session_start() ;

$curDir1=getcwd();             // will be xxx/yyy/simInv/phpLib ... strip out /phpLib
$len1=strlen($curDir1);
$len2=$len1-7;
$curDir=substr($curDir1,0,$len2);

 
// add some php functions

if (!array_key_exists('username',$_REQUEST))  doReturnError("No username specified");   // exits directoly
$auser=$_REQUEST['username'];  // must exist
$daDir=$curDir.'/data/'.$auser;
if (!is_dir($daDir)) {
   doReturnError("No such user: $auser");   // exits directoly
}


// for all requests, ....


 if (!array_key_exists('encMd5',$_REQUEST))  doReturnError('No encryption key specified (not even an empty one)','encKey',1);   // exits directoly

$myEncMd5=$_REQUEST['encMd5'] ;  // could be  blank

$savedMd5='';  // used if no encryption key file
$xxx=readEncKey($auser,$curDir);

if ($xxx!== false) {
  $savedMd5=$xxx['encMd5'];
}
if ($savedMd5!= $myEncMd5) {   // both are blank is aslso allowed  .. 29 dec 2023 ... this should never happen
    if ($savedMd5==='') {
       doReturnError("You do not need an encryption key, $savedMd5 saved, you gave $myEncMd5")  ;
    } else {       //29 de 2023.. don't bother looking for hint
       $amess='You did not specify the correct encryption key';
       doReturnError($amess)  ;
    }
}

// "logon" ok (username exists, encryption key matches

  $daDir=$curDir.'/data/'.$auser;

  $delFiles=[] ;                       // data files to delete (no info available)
  $saves=[];
  $errs=[]; $overwrites=[];
   $times=[];
   foreach ($_REQUEST['data']['content'] as $avar=>$avals) {
     $atime=$avals['time'];
     $theData=$avals['data'];

     $times[$avar]="$avar $atime ".gettype($atime);

     if ($atime==false || $atime=='false') {
        $delFiles[]=$avar ;
        continue ;
    }

     $awhich=$avar;
     $fnameUse=$awhich.'.json';
     $try=$daDir.'/'.$fnameUse ;

     $aa=['time'=>$atime,'dinfo'=>$theData ];
     $da2=serialize($aa);

     $qexist=file_exists($try);
     if ($qexist) $overwrites[]=$awhich ;
     $nn=file_put_contents($try,$da2);
     if ($nn===false)  {
        $errs[]="Could not save: $awhich : in: $try ";
     } else {
        $saves[]=$awhich ;
     }
  }

// no data datasets, files should be removed (if they exist)
  foreach ($delFiles as $ith=>$fname) {
        $tryD=$daDir.'/'.$fname.'.json';
        if (file_exists($tryD)) {
            $qq=unlink($tryD);
           if ($qq===false) $errs[]="Unable to delete $tryD ";
        }
  }

  ob_end_clean();   // remove prints and other crap
  $amess='Restored: '.implode(', ',$saves);
  $amess.='<br>... overwritten: '.implode(', ',$overwrites);
  $amess.='<br>Deleted (no data for this): '.implode(', ',$delFiles);
 // $amess.='<br>'.implode(' | ',$times);

  if (count($errs)>0) $amess.='<br>Errors: <ul><li>'.implode('<li>',$errs).'</ul>';
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print_r($vsuggests);
  exit;


// ===========
// return current users "first used" encryption key
function readEncKey($auser,$curDir) {

  $daDir=$curDir.'/data/'.$auser;
  $try=$daDir.'/encMd5.json';
  $gotEncKey=file_exists($try);

  if ($gotEncKey) {
      $aa=file_get_contents($try);
      if ($aa===false) {
         doReturnError("Unable to retrieve encryption key MD5 file: $try ");
      } else {
        $va=unserialize($aa);
        if ($va===false) {
           doReturnError("Problem reading encryption key MD5 file: $try ")  ;
        } else {
           return $va ;
        }
     }
  }


  return  false ;     // if no encKeyMd5 ever saved, use a value of ''
}

//=============  ::::::::::::::::::::::::  =======================
// error return
function doReturnError($amess,$acondition='',$avalue='') {
     $rets=[];
     $rets['error']=true;
     $rets['errorMessage']=$amess;
     if ($acondition!='') $rets[$acondition]=$avalue;

    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
}


?>

