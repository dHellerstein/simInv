You can use this directory to store archived data -- in standAlone mode, or onLine mode with local storage!
